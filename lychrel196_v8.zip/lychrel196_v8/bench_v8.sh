#!/usr/bin/env bash
# v8 build, gate and A/B against v6r3 (the production engine) on the RTX 4050 Laptop.
#   ./bench_v8.sh build              build all binaries (v8 at J=8/4/16, baseline v6r3, emulators, reference)
#   ./bench_v8.sh resources          registers / stack / local memory per binary (tb_kernel)
#   ./bench_v8.sh gate               exactness gate - must pass before any timing
#   ./bench_v8.sh ab FILE ITER       COPY of a production checkpoint: interleaved A/B, GPU events + power
#   ./bench_v8.sh sustained FILE ITER CFG   100,000 steps each: production (v6r3:860) vs CFG
#   ./bench_v8.sh runmode            finite run-mode check (3 chunks) against the reference
# Configurations are ENGINE:TILE with ENGINE one of
#   v6r3 (production binary) | v8 (hybrid, J=8) | v8j4 | v8j16 | v8off (v8 binary with --hybrid=0)
# Never point FILE at the live production checkpoint: use a copy. Timing needs the GPU to itself:
# pause production (search/STOP) first and resume from latest.json afterwards.
set -euo pipefail
ARCH=${ARCH:-sm_89}
CK=checkpoint_4942464.txt; START=4942464
NV="nvcc -O3 -std=c++17 -arch=$ARCH"
K=${K:-128}
mkdir -p bench
log() { echo "$@" | tee -a bench/summary.txt; }
median() { sort -n | awk '{a[NR]=$1} END{print a[int((NR+1)/2)]}'; }
mean() { awk '{s+=$1; n++} END{if (n) printf "%.3f", s/n; else print "NA"}'; }
ref_for() {
  local f=bench/ref_$(basename $1)_$2.txt
  [ -f $f ] || { echo "building CPU reference ($2 steps)..." >&2; ./bench/ref $1 $2 $f; }
  echo $f
}
run1() {  # run1 BIN args... ; stderr -> bench/last.txt (+ appended to bench/log.txt)
  local b=$1; shift
  $b "$@" 2> bench/last.txt >/dev/null || { cat bench/last.txt; return 1; }
  cat bench/last.txt >> bench/log.txt
}
devus() { grep -oE 'device_us_per_step=[0-9.]+' bench/last.txt | tail -1 | cut -d= -f2; }
reps() { grep -oE 'replays=[0-9]+' bench/last.txt | tail -1 | cut -d= -f2; }
binof() {
  case "${1%%:*}" in
    v6r3) echo bench/v6r3 ;; v8) echo ./cuda196_v8 ;; v8j4) echo bench/v8_j4 ;; v8j16) echo bench/v8_j16 ;;
    v8off) echo "./cuda196_v8 --hybrid=0" ;; *) echo "unknown engine ${1%%:*}" >&2; exit 2 ;;
  esac
}
tileof() { echo "${1##*:}"; }
runcfg() {  # runcfg CFG IN STEPS OUT IT
  local b; b=$(binof $1)
  local bin=${b%% *} extra=""; [ "$b" != "$bin" ] && extra=${b#* }
  run1 $bin $2 $3 $4 $5 $K --tile=$(tileof $1) $extra
}
# timed run with power sampling: timed CFG IN STEPS OUT IT  -> sets US, W, MHZ
timed() {
  local cfg=$1 in=$2 steps=$3 out=$4 it=$5
  rm -f bench/pw.csv
  nvidia-smi --query-gpu=power.draw,clocks.sm --format=csv,noheader,nounits -lms 100 > bench/pw.csv 2>/dev/null &
  local smi=$!
  runcfg $cfg $in $steps $out $it || { kill $smi 2>/dev/null || true; return 1; }
  kill $smi 2>/dev/null || true; wait $smi 2>/dev/null || true
  US=$(devus)
  W=$(awk -F', *' '$2 > 1000 {s+=$1; n++} END{if (n) printf "%.2f", s/n; else print "NA"}' bench/pw.csv)
  MHZ=$(awk -F', *' '$2 > 1000 {s+=$2; n++} END{if (n) printf "%.0f", s/n; else print "NA"}' bench/pw.csv)
}
case "${1:-}" in
build)
  $NV cuda196_v8.cu -o cuda196_v8
  $NV -DTB_J=4 cuda196_v8.cu -o bench/v8_j4
  $NV -DTB_J=16 cuda196_v8.cu -o bench/v8_j16
  (cd baseline_v6r3 && $NV cuda196_v6r3.cu -o ../bench/v6r3)
  g++ -O3 -march=native -fopenmp -std=c++17 emu196_v8.cpp -o emu196_v8
  g++ -O3 -march=native -fopenmp -std=c++17 -DTB_CHECK_HYBRID -DTB_CHECK_GROWTH emu196_v8.cpp -o bench/emu196_v8_check
  (cd baseline_v6r3 && g++ -O3 -march=native -fopenmp -std=c++17 emu196_v6r3.cpp -o ../bench/emu196_v6r3)
  gcc -O2 tools/ref.c -o bench/ref
  ;;
resources)
  for b in ./cuda196_v8 bench/v8_j4 bench/v8_j16 bench/v6r3; do
    ru=$(cuobjdump --dump-resource-usage $b 2>/dev/null | grep -A1 'tb_kernel' | grep -oE 'REG:[0-9]+|STACK:[0-9]+' | tr '\n' ' ')
    sec=$(cuobjdump -sass $b | awk '/Function : .*tb_kernel/{f=1; next} /Function : /{f=0} f')
    [ -n "$sec" ] || { log "$b: tb_kernel section not found in SASS"; continue; }
    log "$b: $ru STL=$(grep -c STL <<< "$sec" || true) LDL=$(grep -c LDL <<< "$sec" || true) REDUX=$(grep -c REDUX <<< "$sec" || true) SASS_lines=$(wc -l <<< "$sec")"
  done
  log "  (expected: v8 STL/LDL equal to v6r3's - those are the v6r3 path's rare calls; REDUX > 0 in v8)"
  ;;
gate)
  log "== CPU emulator checks (same kernel code; hybrid blocks cross-checked against the v6r3 path)"
  python3 tests/quiet_bits.py ./bench/emu196_v8_check 6 | tail -1 | tee -a bench/summary.txt
  python3 tests/stress_hybrid.py ./bench/emu196_v8_check 12 | tail -1 | tee -a bench/summary.txt
  log "== GPU exactness"
  for f in "--mode=step" "--mode=tb" "--mode=tb --tile=4 --K=7" "--mode=tb --tile=4 --halo=4 --K=64 --window=128" \
           "--mode=tb --tile=8 --halo=4 --K=256 --window=512" "--mode=tb --tile=64 --K=1000" "--mode=tb --tile=860" \
           "--mode=tb --tile=1000" "--mode=tb --hybrid=0"; do
    log "GPU exactness suite v8: $f"
    ENGINE_FLAGS="$f" python3 tests/test_exact.py ./cuda196_v8 | tail -1 | tee -a bench/summary.txt
  done
  for b in bench/v8_j4 bench/v8_j16; do
    log "GPU exactness suite (default tb + forced failures) with $b"
    ENGINE_FLAGS="--mode=tb" python3 tests/test_exact.py ./$b | tail -1 | tee -a bench/summary.txt
    ENGINE_FLAGS="--mode=tb --tile=8 --halo=4 --K=256 --window=512" python3 tests/test_exact.py ./$b | tail -1 | tee -a bench/summary.txt
  done
  log "GPU differential v6r3 vs v8 (random large inputs with planted carry chains, random K/tile):"
  python3 tests/diff_engines.py ./bench/v6r3 ./cuda196_v8 1 100 | tail -1 | tee -a bench/summary.txt
  python3 tests/diff_engines.py ./bench/v6r3 ./bench/v8_j16 2 50 | tail -1 | tee -a bench/summary.txt
  log "GPU hybrid stress (many long carry chains) vs big integers:"
  python3 tests/stress_hybrid.py ./cuda196_v8 20 | tail -1 | tee -a bench/summary.txt
  log "GPU palindromes a few steps in, and inputs with quiet regions:"
  python3 tests/pal_later.py ./cuda196_v8 4 | tail -1 | tee -a bench/summary.txt
  python3 tests/quiet_bits.py ./cuda196_v8 6 | tail -1 | tee -a bench/summary.txt
  log "GPU growth edge cases:"
  python3 tests/test_growth_edge.py ./cuda196_v8 60 | tail -1 | tee -a bench/summary.txt
  R=$(ref_for $CK 2000)
  for cfg in v8:860 v8:1000 v8j4:860 v8j16:860 v8off:860 v6r3:860; do
    runcfg $cfg $CK 2000 bench/g2000.txt $START
    cmp -s bench/g2000.txt $R && log "$cfg +2000 == reference: PASS (replays=$(reps))" || log "$cfg +2000: MISMATCH"
  done
  ;;
ab)
  IN=${2:?checkpoint COPY}; IT=${3:?its iteration}; STEPS=${STEPS:-5000}; ROUNDS=${ROUNDS:-3}
  CFGS=${CFGS:-"v6r3:860 v8:860 v8:940 v8:1000 v8j16:860 v8j4:860 v8off:860"}
  : > bench/ab.tsv
  runcfg v6r3:860 $IN 500 bench/warm.txt $IT || true   # warm-up
  timed v6r3:860 $IN $STEPS bench/ab_ref.txt $IT        # trusted output for this input
  for r in $(seq 1 $ROUNDS); do
    for cfg in $CFGS; do
      timed $cfg $IN $STEPS bench/ab_out.txt $IT
      cmp -s bench/ab_out.txt bench/ab_ref.txt && ok=PASS || { ok=MISMATCH; log "$cfg round $r: OUTPUT MISMATCH vs v6r3:860"; }
      J=$(awk -v w=$W -v u=$US 'BEGIN{ if (w == "NA") print "NA"; else printf "%.4f", w * u / 1000 }')  # mJ/step
      printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" $cfg $r $US $W $MHZ $J $(reps) $ok | tee -a bench/ab.tsv
    done
  done
  log "A/B at $(basename $IN) iteration $IT, K=$K, $STEPS steps x $ROUNDS interleaved rounds (cfg: engine:tile)"
  log "  cfg          median_us/step  mean_us/step  vs v6r3:860  mean_W  mean_MHz  mean_mJ/step  replays  outputs"
  base=$(awk -F'\t' '$1=="v6r3:860"{print $3}' bench/ab.tsv | median)
  for cfg in $CFGS; do
    md=$(awk -F'\t' -v c=$cfg '$1==c{print $3}' bench/ab.tsv | median)
    mn=$(awk -F'\t' -v c=$cfg '$1==c{print $3}' bench/ab.tsv | mean)
    w=$(awk -F'\t' -v c=$cfg '$1==c && $4!="NA"{print $4}' bench/ab.tsv | mean)
    mz=$(awk -F'\t' -v c=$cfg '$1==c && $5!="NA"{print $5}' bench/ab.tsv | mean)
    mj=$(awk -F'\t' -v c=$cfg '$1==c && $6!="NA"{print $6}' bench/ab.tsv | mean)
    rp=$(awk -F'\t' -v c=$cfg '$1==c{s+=$7} END{print s}' bench/ab.tsv)
    ok=$(awk -F'\t' -v c=$cfg '$1==c && $8!="PASS"{bad++} END{print bad ? "MISMATCH" : "all PASS"}' bench/ab.tsv)
    rel=$(awk -v b=$base -v m=$md 'BEGIN{printf "%+.2f%%", (b / m - 1) * 100}')
    log "  $(printf '%-12s %14s %13s %12s %7s %9s %13s %8s  %s' $cfg $md $mn "$rel" $w $mz $mj $rp "$ok")"
  done
  log "  ('vs v6r3:860' = speed change, positive = faster. Replays must stay ~0: each costs an exact per-step redo.)"
  ;;
sustained)
  IN=${2:?checkpoint COPY}; IT=${3:?its iteration}; CFG=${4:?config, e.g. v8:860}; STEPS=${STEPS:-100000}
  for cfg in v6r3:860 $CFG; do
    timed $cfg $IN $STEPS bench/sus_$cfg.txt $IT
    log "sustained $STEPS steps $cfg: device_us_per_step=$US mean_W=$W mean_MHz=$MHZ replays=$(reps)"
  done
  cmp -s bench/sus_v6r3:860.txt bench/sus_$CFG.txt && log "  outputs identical: PASS" || log "  outputs DIFFER: MISMATCH"
  ;;
runmode)
  rm -rf bench/rm && mkdir -p bench/rm && cp $CK bench/rm/
  (cd bench/rm && ../../cuda196_v8 run $CK $START run --chunk=1000 --keep=2 --steps=3000 --tile=860 2>> ../log.txt)
  R=$(ref_for $CK 3000)
  p=$(python3 -c "import json;print(json.load(open('bench/rm/run/latest.json'))['path'])")
  cmp -s bench/rm/$p $R && log "run mode +3000 == reference: PASS" || log "run mode: MISMATCH"
  python3 - <<'EOF' | tee -a bench/summary.txt
import hashlib, json, re
j = json.load(open('bench/rm/run/latest.json'))
d = re.sub(r'[^0-9]', '', open('bench/rm/' + j['path']).read())
print('latest.json digits-only sha256:', 'PASS' if hashlib.sha256(d.encode()).hexdigest() == j['sha256'] and len(d) == j['digits'] else 'MISMATCH',
      '| engine =', j.get('engine'))
EOF
  ;;
*) echo "usage: $0 build|resources|gate|ab FILE ITER|sustained FILE ITER CFG|runmode"; exit 1 ;;
esac
