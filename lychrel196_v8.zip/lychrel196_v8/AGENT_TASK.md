# Task for the local agent (RTX 4050): v8 (control tape + register micro-windows)

Production runs v6r3 (K=128, tile 860) toward the 999,999,999 milestone. **Do this after the
milestone comparison report is done**, unless the user says otherwise. Results must be
byte-identical to v6r3.

Timing needs the GPU to itself: pause with `search/STOP` (finishes the current chunk), run the
task, resume from `latest.json`, and confirm the service is running again. One GPU job at a time.
The gate is long (the emulator checks run on the CPU); production can stay paused or, if the user
prefers, resume during the CPU-only part and pause again for the GPU parts.

## What changes (README.md has the reasoning)
- A tiny kernel computes each launch's growth bits ahead of time ("control tape").
- Interior blocks run 8 steps per barrier: each thread keeps its 4 words plus one halo word on each
  side in registers, certifies its own window, and syncs every 8 steps instead of every step.
- Edge and middle blocks keep the v6r3 path. Certification failures replay exactly, as before.
- Speed is genuinely unknown: fewer barriers and shared-memory trips vs 1.5× arithmetic under the
  35 W cap. Measure.

## Steps
1. `./bench_v8.sh build` then `./bench_v8.sh resources`. Report the lines.
2. `./bench_v8.sh gate`. **Everything must PASS**: emulator cross-checks (hybrid vs v6r3 path, per
   step), 9 GPU exactness configurations, J=4/16 builds, differential vs v6r3, hybrid stress with
   long carry chains, palindromes inside windows, growth edge cases, +2000 vs CPU reference at
   tiles 860 and 1000 and `--hybrid=0`.
3. `./bench_v8.sh ab <COPY of the newest checkpoint> <its iteration>`. Defaults: K=128, 5,000 steps,
   3 interleaved rounds of v6r3:860 (production), v8 at tiles 860/940/1000, v8 J=16 and J=4 at 860,
   and v8 with `--hybrid=0` at 860. Every output is compared with v6r3's. Reports median/mean
   µs/step, power, clock, energy per step and **replays**. This is the deciding table.
4. If a configuration is at least 5% faster by median with replays = 0:
   `./bench_v8.sh sustained <COPY> <iteration> <best cfg>` (100,000 steps each).
5. `./bench_v8.sh runmode`.
6. Resume production unchanged and confirm it is running. Send back `bench/summary.txt`,
   `bench/ab.tsv` and `bench/log.txt`.

## Deciding (the user's call)
- Switch only if the sustained run is ≥ 5% faster with zero replays and identical output, and
  only with the user's go-ahead, at a chunk boundary, resuming from `latest.json`, keeping the
  current milestone/stop settings. Keep the v6r3 binary for rollback.
- Otherwise keep v6r3. Report the table either way: it tells us whether removing synchronisation
  is worth recomputing halos on this power-capped GPU.

## Rules
- Benchmarks only on a copy of a checkpoint, never the live file.
- Every step's palindrome status is checked; certification failures replay.
- Measured numbers only.
