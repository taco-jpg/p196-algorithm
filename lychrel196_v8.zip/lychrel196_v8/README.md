# 196 reverse-and-add v8: control tape + register micro-windows (the outside review's idea)

```bash
nvcc -O3 -std=c++17 -arch=sm_89 cuda196_v8.cu -o cuda196_v8
./cuda196_v8 checkpoint_4942464.txt 20000 out.txt 4942464 128 --tile=860              # benchmark (same CLI)
./cuda196_v8 run <checkpoint> <iteration> search --chunk=1000000 --keep=3 --K=128 --tile=860   # long search
./cuda196_v8 ... --hybrid=0                                                           # v6r3 behaviour
```

Same arithmetic, certification, replay, command line, checkpoint format and `latest.json` fields as
v6r3 (engine field `cuda196_v8`; bench lines add `hybrid=` and `J=`). Results are byte-identical.

## The idea, and what was built

The v6r2 profile showed the time going to waiting, not work: the per-step barrier was the #1 stall
and shared-memory round trips the #4. The review proposed (1) a mod-5 encoding of the pair sums,
(2) a separate "control tape" of growth bits, (3) independent register-resident micro-tiles that
communicate rarely. v8 implements (2) and (3) inside the existing time-blocked design:

- **Control tape.** Before each launch a 64-thread kernel runs the prefix tile alone for the launch's
  K steps (the same code and certification every block's prefix already uses) and writes g_0..g_{K-1}
  plus a certified flag. Cost: ~0.2 ms per 128-step launch, under 1% at production size.
- **Hybrid interior blocks.** Each thread owns one 4-word group. It loads the group plus one halo
  word on each side (6 words) into registers and runs `TB_J` steps (default 8) with no barrier and
  no shared-memory traffic, taking g from the tape. Then it writes its 4 words; one barrier; next
  window. Per 128-step launch: 16 barriers instead of 128, and shared-memory loads/stores once per 8
  steps instead of every step. The price: 6 words computed for every 4 kept (1.5× arithmetic).
- **Per-thread certification.** Each thread tracks a certified interval inside its window with the
  same rule as `track_step` (window-local, so unknown values outside it cannot leak in), starting
  from the certified spans its neighbours published at the last window end. A block whose owned
  groups are not all certified at a window end, or whose tape is uncertified, fails and the window
  replays exactly with the per-step kernel, as before. Long carry chains therefore cost replays,
  never correctness. With a 32-pair halo and 8 steps, a failure needs ≥ 25 pairs of 9-runs
  crossing one window edge in 8 steps; estimated far below one per production launch. `TB_J=16`
  halves the barriers again but fails noticeably more often (the A/B reports replays).
- Block 0 (the outer edge) and the 1–2 blocks near the middle keep the unchanged v6r3 path.
- Not done: the mod-5 encoding. Counted in bit-sliced form it saves ~25% of the non-growth step's
  logic, but growth steps need an extra digit-equality test for the palindrome check that roughly
  cancels it. It can be a later variant if v8's structure wins.

## Checked here (no NVIDIA GPU: CPU emulator running the same kernel code, clang + ptxas for sm_89)

- **Cross-check build** (`-DTB_CHECK_HYBRID`): every certified hybrid block is recomputed through the
  v6r3 path and must give identical owned words and identical per-step mismatch bits. Inputs with
  quiet regions (most pair sums 0, so blocks' mismatch bits switch on inside windows): 11,040 blocks,
  242,027 block-steps without mismatch, all identical, at J = 4, 8 and 16.
- **Stress with planted carry chains** under the soundness checker: 30/30 exact at each of J = 4/8/16,
  17,042 hybrid blocks, 256–414 of them failed certification and replayed, 0 soundness violations.
- Exactness suite ALL PASS in 9 configurations incl. tiles 860 and 1000 and `--hybrid=0`.
- Differential vs v6r3: 150/150 (J=8), 100/100 (J=16), 100/100 (J=4) byte-identical.
- Growth edge cases 195/195. Palindromes at step 3 (inside a window) reported exactly, with hybrid
  blocks active. +2000 steps on the 2.05M checkpoint at tiles 96/736/860/1000 == CPU reference.
- Compiled (clang + ptxas, sm_89): tb_kernel 128 registers, 0 spills; local-memory instructions
  identical to v6r3's (all in the v6r3 path's rare calls), none in the hybrid path. Tape kernel 154
  registers (one 64-thread block, irrelevant).

## Expected speed (honest)

Unknown, and I mean it. Removed: 7/8 of the barriers and of the shared-memory traffic, the two
biggest stalls. Added: 1.5× arithmetic, which costs energy on a GPU pinned at its 35 W cap (3
blocks/SM lost 8.7% that way). It could be −20% or +30%. My estimates were too high six times and
too low once (v6r3). The A/B decides. Switch only on ≥ 5% sustained, with zero extra replays.

## Files

| file | purpose |
|---|---|
| `cuda196_v8.cu` | CUDA backend: v4 per-step kernel, tape kernel, time-blocked kernel (hybrid + v6r3 paths) |
| `emu196_v8.cpp` | CPU emulator, same kernel code (`EMU_CERTCHECK=1`, `-DTB_CHECK_HYBRID`, `-DTB_CHECK_GROWTH`) |
| `bits_tb8.h` | engine: v6r3 + `hy_window`, `hy_track`, `hy_init_spans`, spans in shared memory |
| `driver8.h` | v6r3 driver + `--hybrid=0/1` |
| `bench_v8.sh` | `build`, `resources`, `gate`, `ab`, `sustained`, `runmode` |
| `tests/stress_hybrid.py` | planted carry chains: hybrid failures must replay, never corrupt |
| `tests/quiet_bits.py` | per-step palindrome votes inside windows (with the cross-check build) |
| `tests/pal_later.py` | palindromes a few steps in, reported at the exact iteration |
| `tests/` (others) | exactness suite, differential test, growth edge cases |
| `baseline_v6r3/` | the production engine, for A/B |
| `tools/ref.c` | independent schoolbook reference |
