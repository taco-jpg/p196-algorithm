# 196 reverse-and-add v6: lean time-blocked kernel

```bash
nvcc -O3 -std=c++17 -arch=sm_89 cuda196_v6.cu -o cuda196_v6
./cuda196_v6 checkpoint_4942464.txt 20000 out.txt 4942464 256          # benchmark (same CLI as v5)
./cuda196_v6 run <checkpoint> <iteration> run_v6 --chunk=1000000 --keep=3   # long search
```

Same exact arithmetic as v4/v5 (bit-sliced folded pair sums), same command line, same checkpoint
format and `latest.json` fields (plus `device_us_per_step_last_chunk`). v6 removes overhead from the
time-blocked kernel's inner loop. See AGENT_TASK.md for what changed, what was verified, and the test
and benchmark order.

| file | purpose |
|---|---|
| `cuda196_v6.cu` | CUDA backend: v4 per-step kernel (fallback), v6 time-blocked kernel, GPU event timing |
| `emu196_v6.cpp` | CPU emulator running the same kernel code (`EMU_CERTCHECK=1` soundness mode) |
| `bits_core.h` | v4 per-step arithmetic (GPU-validated, unchanged) |
| `bits_tb6.h` | v6 time-blocked arithmetic: guard-padded tiles, fast/general paths, certification |
| `driver6.h` | bench mode, run mode, verification windows, replay, timing |
| `bench_v6.sh` | `gate`, `ab`, `big`, `sweep`, `profile`, `clocks` |
| `tests/test_exact.py` | exactness suite (`ENGINE_FLAGS` passes options) |
| `tests/diff_v5_v6.py` | differential test: v6 must equal v5 byte for byte |
| `baseline_v5/` | v5 sources for A/B |
| `tools/ref.c` | independent schoolbook reference |

Remaining ideas, ordered by expected value once the profile is in: give the per-step certification
tracking its own warp (threads 0/1 still do serial bookkeeping each step), pass neighbour words with
warp shuffles, convert checkpoints to decimal on the GPU at 100M+ digits.
