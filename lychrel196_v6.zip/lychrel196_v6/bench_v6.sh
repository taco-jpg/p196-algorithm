#!/usr/bin/env bash
# v6 build, gate, A/B against v5, sweep and profiling on the RTX 4050.
#   ./bench_v6.sh gate              build everything + GPU exactness gate (must pass first)
#   ./bench_v6.sh ab                2.05M checkpoint, 20,000 steps: v5 vs v6, 5 interleaved runs
#   ./bench_v6.sh big FILE ITER     28.2M-digit checkpoint, 2,000 steps: v5 vs v6 (+ CPU reference)
#   ./bench_v6.sh sweep [FILE ITER] K x tile x block-size x register-cap sweep (default: 2.05M checkpoint)
#   ./bench_v6.sh profile FILE ITER Nsight Compute profile of the time-blocked kernel (needs ncu)
#   ./bench_v6.sh clocks            GPU clocks/power while a run is active (needs working NVML)
set -euo pipefail
ARCH=${ARCH:-sm_89}
CK=checkpoint_4942464.txt; START=4942464
mkdir -p bench
log() { echo "$@" | tee -a bench/summary.txt; }
now() { date +%s.%N; }
median() { sort -n | awk '{a[NR]=$1} END{print a[int((NR+1)/2)]}'; }
timed() { local s e; s=$(now); "$@" >/dev/null 2>>bench/log.txt; e=$(now); echo "$e - $s" | bc; }
ref_for() {  # ref_for INPUT STEPS -> path of CPU reference output
  local f=bench/ref_$(basename $1)_$2.txt
  [ -f $f ] || { echo "building CPU reference ($2 steps)..." >&2; ./bench/ref $1 $2 $f; }
  echo $f
}
devus() { grep -oE 'device_us_per_step=[0-9.]+' bench/log.txt | tail -1 | cut -d= -f2; }
build() {
  nvcc -O3 -std=c++17 -arch=$ARCH cuda196_v6.cu -o cuda196_v6
  nvcc -O3 -std=c++17 -arch=$ARCH -DTB_MINBLOCKS=1 cuda196_v6.cu -o bench/cuda196_v6_mb1
  nvcc -O3 -std=c++17 -arch=$ARCH -DTB_THREADS=512 cuda196_v6.cu -o bench/cuda196_v6_t512
  (cd baseline_v5 && nvcc -O3 -std=c++17 -arch=$ARCH cuda196_v5.cu -o ../bench/cuda196_v5)
  g++ -O3 -march=native -fopenmp -std=c++17 emu196_v6.cpp -o emu196_v6
  (cd baseline_v5 && g++ -O3 -march=native -fopenmp -std=c++17 emu196_v5.cpp -o ../bench/emu196_v5)
  gcc -O2 tools/ref.c -o bench/ref
}
case "${1:-}" in
gate)
  build
  for f in "--mode=step" "--mode=tb" "--mode=tb --tile=4 --K=7" "--mode=tb --tile=4 --halo=4 --K=64 --window=128"; do
    log "GPU exactness suite: $f"
    ENGINE_FLAGS="$f" python3 tests/test_exact.py ./cuda196_v6 | tail -1 | tee -a bench/summary.txt
  done
  for b in bench/cuda196_v6_mb1 bench/cuda196_v6_t512; do
    log "GPU exactness suite (default tb) with $b"
    ENGINE_FLAGS="--mode=tb" python3 tests/test_exact.py ./$b | tail -1 | tee -a bench/summary.txt
  done
  log "GPU differential v5 vs v6 (random large inputs, random K/tile):"
  python3 tests/diff_v5_v6.py ./bench/cuda196_v5 ./cuda196_v6 1 100 | tail -1 | tee -a bench/summary.txt
  ./cuda196_v6 $CK 2000 bench/g2000.txt $START 2>>bench/log.txt
  ./emu196_v6  $CK 2000 bench/e2000.txt $START 2>>bench/log.txt
  cmp bench/g2000.txt bench/e2000.txt && log "GPU v6 == CPU emulator at +2000: PASS"
  R=$(ref_for $CK 2000); cmp bench/g2000.txt $R && log "GPU v6 == reference at +2000: PASS"
  ;;
ab)
  STEPS=20000; R=$(ref_for $CK $STEPS)
  : > bench/t_v5.txt; : > bench/t_v6.txt; : > bench/d_v6.txt
  ./cuda196_v6 $CK 1000 bench/warm.txt $START >/dev/null 2>&1 || true
  for r in 1 2 3 4 5; do
    echo $(timed ./bench/cuda196_v5 $CK $STEPS bench/o_v5.txt $START 256) >> bench/t_v5.txt
    echo $(timed ./cuda196_v6 $CK $STEPS bench/o_v6.txt $START 256) >> bench/t_v6.txt
    devus >> bench/d_v6.txt
  done
  cmp bench/o_v5.txt $R && a=PASS || a=MISMATCH; cmp bench/o_v6.txt $R && b=PASS || b=MISMATCH
  log "2.05M, $STEPS steps: v5 wall median $(median < bench/t_v5.txt) s ($a) | v6 wall median $(median < bench/t_v6.txt) s ($b) | v6 GPU-event median $(median < bench/d_v6.txt) us/step"
  log "host compute (both, last runs):"; grep -E "us_per_step" bench/log.txt | tail -2 | tee -a bench/summary.txt
  ;;
big)
  BIG=${2:?28M checkpoint file}; BIT=${3:?its iteration}; STEPS=${STEPS:-2000}
  R=$(ref_for $BIG $STEPS)
  t5=$(timed ./bench/cuda196_v5 $BIG $STEPS bench/o_big_v5.txt $BIT 256)
  l5=$(grep -E "us_per_step" bench/log.txt | tail -1)
  t6=$(timed ./cuda196_v6 $BIG $STEPS bench/o_big_v6.txt $BIT 256)
  l6=$(grep -E "us_per_step" bench/log.txt | tail -1)
  cmp bench/o_big_v5.txt $R && a=PASS || a=MISMATCH; cmp bench/o_big_v6.txt $R && b=PASS || b=MISMATCH
  log "28M, $STEPS steps: v5 wall $t5 s ($a) | v6 wall $t6 s ($b)"
  log "  v5: $l5"; log "  v6: $l6"
  ;;
sweep)
  IN=${2:-$CK}; IT=${3:-$START}; STEPS=${STEPS:-20000}; R=$(ref_for $IN $STEPS)
  for bin in ./cuda196_v6 ./bench/cuda196_v6_mb1 ./bench/cuda196_v6_t512; do
    for K in 128 256 512 1024; do
      for T in 0 256 512 736 800 960; do
        $bin $IN $STEPS bench/o_sw.txt $IT $K --tile=$T >/dev/null 2>>bench/log.txt || { log "$bin K=$K tile=$T FAILED"; continue; }
        cmp -s bench/o_sw.txt $R && ok=PASS || ok=MISMATCH
        line=$(grep -E "us_per_step" bench/log.txt | tail -1)
        log "$bin K=$K tile=$T $ok $(echo "$line" | grep -oE 'device_us_per_step=[0-9.]+|replays=[0-9]+' | tr '\n' ' ')"
      done
    done
  done
  ;;
profile)
  IN=${2:?checkpoint}; IT=${3:?iteration}
  ncu --kernel-name tb_kernel --launch-skip 5 --launch-count 1 --set full -o bench/tb_profile \
      ./cuda196_v6 $IN 4096 bench/o_prof.txt $IT 256
  ncu --import bench/tb_profile.ncu-rep --page details --print-units base > bench/tb_profile.txt
  log "profile written: bench/tb_profile.ncu-rep and bench/tb_profile.txt (look at: issue slot utilization,"
  log "  warp stall reasons [barrier, short_scoreboard, wait], achieved occupancy, registers/thread)"
  ;;
clocks)
  nvidia-smi --query-gpu=name,clocks.sm,clocks.max.sm,power.draw,power.limit,temperature.gpu,utilization.gpu \
             --format=csv -l 2
  ;;
*) echo "usage: $0 gate|ab|big FILE ITER|sweep [FILE ITER]|profile FILE ITER|clocks"; exit 1 ;;
esac
