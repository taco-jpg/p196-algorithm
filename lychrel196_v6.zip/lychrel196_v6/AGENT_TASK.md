# Task for the local agent (RTX 4050) — v6 lean kernel

The production search keeps running on v5 the whole time. v6 is tested next to it; switch only if it
passes the gate **and** is measurably faster at 28M digits.

## What v6 changes (results are bit-identical to v5)
1. **Guard-padded tiles**: every shared-memory plane has zeroed guard words, so the six words each
   thread-group reads need no range checks. Range-checked loads remain only in the rare carry scans.
2. **Fast path**: interior groups (99.4% of all groups at 2M digits) run branch-free code without
   masks, with 128-bit shared-memory stores. Groups near word 0, the middle, or a partial mismatch range
   use the unchanged v5 path. Rare carry scans are out-of-line functions (no register cost on the hot path).
3. **Growth steps**: the previous pair's high digit comes from a bitwise digit4 + shift instead of
   per-word scalar code.
4. **GPU event timing**: `device_seconds` / `device_us_per_step` in the log and in run-mode `latest.json`.
5. `--mode=step` no longer copies the state every batch (v5 regression fixed); digit limit raised to
   ~2.147e9 (past 1 billion).
6. Build options: `-DTB_THREADS=512`, `-DTB_MINBLOCKS=1|2`.

Measured before handing over (no NVIDIA GPU here; SASS for sm_89 via ptxas + nvdisasm):

| hot-path instructions per 4-word group | v5 | v6 |
|---|---|---|
| no growth (59% of steps) | 402 | 305 (−24%) |
| growth (41% of steps) | 731 | 392 (−46%) |
| weighted | 537 | 341 (−36%) |

tb_kernel: 116 registers, 0 spills (v5: 128 registers, 40-byte spill). **Expected: about 1.3–1.5x at
28M digits — an estimate, not a measurement.**

Verified in the CPU emulator (identical kernel code): exactness suite ALL PASS in step / tb / tiny-tile /
forced-certification-failure modes; soundness checker 0 violations; v5-vs-v6 differential 200/200
identical on random 600–30,000-digit inputs with long 9-runs; 2.05M checkpoint +2,000 == reference;
run mode == reference with correct latest.json hash. **Not yet run on a GPU.**

## Steps
1. `./bench_v6.sh gate` — builds everything; GPU exactness suite in 4 configurations plus the two build
   variants; GPU differential v5 vs v6; GPU vs emulator and vs reference at +2,000. All must PASS.
2. `./bench_v6.sh big <copy of latest production checkpoint> <its iteration>` — **the deciding number**:
   v5 vs v6 at the real size, both checked against the CPU reference.
3. `./bench_v6.sh ab` — 2.05M digits, 20,000 steps, 5 interleaved runs.
4. `./bench_v6.sh sweep <28M checkpoint> <iteration>` with `STEPS=2000` — K × tile × block size × register cap.
   Report the best `device_us_per_step` and confirm `replays=0` and PASS everywhere.
5. `./bench_v6.sh profile <28M checkpoint> <iteration>` (if Nsight Compute `ncu` is installed) and
   `./bench_v6.sh clocks` during a run (reboot first if NVML still reports a driver/library mismatch).
   Report the top stall reasons, achieved occupancy and sustained SM clock / power limit.
6. If v6 passes 1 and is faster in 2: stop the v5 run with Ctrl-C (it finishes the current chunk and
   leaves a consistent checkpoint), then resume with v6 from `latest.json`:
   `./cuda196_v6 run <path from latest.json> <iteration from latest.json> run_v6 --chunk=1000000 --keep=3`
   plus the best K/tile from step 4.

## Rules
- Never run benchmarks against the live production checkpoint file — use a copy.
- Every step's palindrome status is checked; certification failures must replay, never be ignored.
- Report measured numbers only; keep v5 in production if v6 is not faster or not exact.
