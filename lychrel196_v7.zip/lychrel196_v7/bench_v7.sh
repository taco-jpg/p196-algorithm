#!/usr/bin/env bash
# v7 build, gate, A/B against v6r2 (the production engine), sweep and phase profile on the RTX 4050.
#   ./bench_v7.sh build              build all binaries (GPU variants, baseline v6r2, emulators, tests)
#   ./bench_v7.sh resources          registers / stack / local memory / shuffles per binary (tb_kernel)
#   ./bench_v7.sh gate               exactness gate - must pass before anything else
#   ./bench_v7.sh big FILE ITER      28M+ COPY: v6r2 vs v7, 3 interleaved runs + phase profiles + SM clock
#   ./bench_v7.sh small              2.05M checkpoint, 20,000 steps: v6r2 vs v7 + profiles
#   ./bench_v7.sh sweep FILE ITER    COPY: v7 builds x K x tile (STEPS=2000 default)
#   ./bench_v7.sh runmode            finite run-mode check (3 chunks) against the reference
# Never point FILE at the live production checkpoint: use a copy. Benchmarks need the GPU to
# themselves: pause production (search/STOP) first, with the user's agreement.
set -euo pipefail
ARCH=${ARCH:-sm_89}
CK=checkpoint_4942464.txt; START=4942464
NV="nvcc -O3 -std=c++17 -arch=$ARCH"
mkdir -p bench
log() { echo "$@" | tee -a bench/summary.txt; }
median() { sort -n | awk '{a[NR]=$1} END{print a[int((NR+1)/2)]}'; }
ref_for() {
  local f=bench/ref_$(basename $1)_$2.txt
  [ -f $f ] || { echo "building CPU reference ($2 steps)..." >&2; ./bench/ref $1 $2 $f; }
  echo $f
}
run1() {  # run1 BIN args... ; stderr -> bench/last.txt (+ appended to bench/log.txt)
  local b=$1; shift
  $b "$@" 2> bench/last.txt >/dev/null || { cat bench/last.txt; return 1; }
  cat bench/last.txt >> bench/log.txt
}
devus() { grep -oE 'device_us_per_step=[0-9.]+' bench/last.txt | tail -1 | cut -d= -f2; }
mhz() { grep -oE 'sm_clock_mhz=[0-9.]+' bench/last.txt | tail -1 | cut -d= -f2; }
tilev() { grep -oE ' tile=[0-9]+' bench/last.txt | head -1 | cut -d= -f2; }
proflines() { { grep '^\[prof\]' bench/last.txt || true; } | sed 's/^/    /' | tee -a bench/summary.txt; }
V7S="./cuda196_v7 bench/v7_p bench/v7_p2 bench/v7_t256 bench/v7_t256mb1 bench/v7_t512"
BINS="$V7S bench/v6r2 bench/v6r2_p"
case "${1:-}" in
build)
  $NV cuda196_v7.cu -o cuda196_v7
  $NV -DTB_PROF cuda196_v7.cu -o bench/v7_p
  $NV -DTB_PROF -DTB_WORK_REPEAT=2 cuda196_v7.cu -o bench/v7_p2
  $NV -DTB_THREADS=256 cuda196_v7.cu -o bench/v7_t256
  $NV -DTB_THREADS=256 -DTB_MINBLOCKS=1 cuda196_v7.cu -o bench/v7_t256mb1
  $NV -DTB_THREADS=512 cuda196_v7.cu -o bench/v7_t512
  (cd baseline_v6r2 && $NV cuda196_v6r2.cu -o ../bench/v6r2 && $NV -DTB_PROF cuda196_v6r2.cu -o ../bench/v6r2_p)
  g++ -O3 -march=native -fopenmp -std=c++17 emu196_v7.cpp -o emu196_v7
  g++ -O3 -march=native -fopenmp -std=c++17 -DTB_CHECK_GROWTH emu196_v7.cpp -o bench/emu196_v7_check
  g++ -O2 -std=c++17 -I. tests/unit_v7.cpp -o bench/unit_v7
  gcc -O2 tools/ref.c -o bench/ref
  ;;
resources)
  for b in $BINS; do
    ru=$(cuobjdump --dump-resource-usage $b 2>/dev/null | grep -A1 'tb_kernel' | grep -oE 'REG:[0-9]+|STACK:[0-9]+' | tr '\n' ' ')
    sec=$(cuobjdump -sass $b | awk '/Function : .*tb_kernel/{f=1; next} /Function : /{f=0} f')
    [ -n "$sec" ] || { log "$b: tb_kernel section not found in SASS"; continue; }
    log "$b: $ru STL=$(grep -c STL <<< "$sec" || true) LDL=$(grep -c LDL <<< "$sec" || true) SHFL=$(grep -c SHFL <<< "$sec" || true) SASS_lines=$(wc -l <<< "$sec")"
  done
  ;;
gate)
  ./bench/unit_v7 | tee -a bench/summary.txt
  for f in "--mode=step" "--mode=tb" "--mode=tb --tile=4 --K=7" "--mode=tb --tile=4 --halo=4 --K=64 --window=128" \
           "--mode=tb --tile=8 --halo=4 --K=256 --window=512" "--mode=tb --tile=64 --K=1000"; do
    log "GPU exactness suite v7: $f"
    ENGINE_FLAGS="$f" python3 tests/test_exact.py ./cuda196_v7 | tail -1 | tee -a bench/summary.txt
  done
  for b in bench/v7_t256 bench/v7_t256mb1 bench/v7_t512 bench/v7_p; do
    log "GPU exactness suite (default tb + forced failures) with $b"
    ENGINE_FLAGS="--mode=tb" python3 tests/test_exact.py ./$b | tail -1 | tee -a bench/summary.txt
    ENGINE_FLAGS="--mode=tb --tile=8 --halo=4 --K=256 --window=512" python3 tests/test_exact.py ./$b | tail -1 | tee -a bench/summary.txt
  done
  log "GPU differential v6r2 vs v7 (random large inputs, random K/tile):"
  python3 tests/diff_engines.py ./bench/v6r2 ./cuda196_v7 1 100 | tail -1 | tee -a bench/summary.txt
  log "GPU growth edge cases (next number starts with many pair-sum-9 pairs; must replay, stay exact):"
  python3 tests/test_growth_edge.py ./cuda196_v7 60 | tail -1 | tee -a bench/summary.txt
  R=$(ref_for $CK 2000)
  for b in $BINS; do
    run1 $b $CK 2000 bench/g2000.txt $START
    cmp -s bench/g2000.txt $R && log "$b +2000 == reference: PASS" || log "$b +2000: MISMATCH"
  done
  run1 bench/emu196_v7_check $CK 2000 bench/e2000.txt $START
  cmp -s bench/e2000.txt $R && log "CPU emulator (self-check build) +2000 == reference: PASS" || log "emulator +2000: MISMATCH"
  ;;
big|small)
  if [ "$1" = big ]; then IN=${2:?checkpoint COPY}; IT=${3:?its iteration}; STEPS=${STEPS:-2000}; K=${K:-128}; TP=${TILEP:-736}
  else IN=$CK; IT=$START; STEPS=${STEPS:-20000}; K=${K:-256}; TP=${TILEP:-0}; fi
  T7S=${TILE7:-"0 736"}   # v7 tiles to compare: 0 = auto, 736 = the production tile (2 blocks/SM)
  R=$(ref_for $IN $STEPS)
  : > bench/dp.txt; for T in $T7S; do : > bench/dn_$T.txt; done
  run1 ./cuda196_v7 $IN 200 bench/warm.txt $IT $K || true
  for r in 1 2 3; do
    run1 bench/v6r2 $IN $STEPS bench/op.txt $IT $K --tile=$TP
    cmp -s bench/op.txt $R || { log "v6r2 MISMATCH vs reference"; exit 1; }
    devus >> bench/dp.txt
    for T in $T7S; do
      run1 ./cuda196_v7 $IN $STEPS bench/on.txt $IT $K --tile=$T
      cmp -s bench/on.txt $R || { log "v7 tile=$T MISMATCH vs reference"; exit 1; }
      devus >> bench/dn_$T.txt; echo "$(tilev)" > bench/tv_$T.txt; mz=$(mhz)
    done
  done
  log "$1 ($STEPS steps, K=$K): GPU-event us/step median v6r2=$(median < bench/dp.txt) (tile $TP; runs $(tr '\n' ' ' < bench/dp.txt))"
  for T in $T7S; do
    log "  v7 tile=$T (used $(cat bench/tv_$T.txt)): median $(median < bench/dn_$T.txt) (runs $(tr '\n' ' ' < bench/dn_$T.txt))"
  done
  log "  all outputs PASS vs reference | v7 SM clock ${mz} MHz"
  T1=$(echo $T7S | awk '{print $1}')
  for b in bench/v6r2_p bench/v7_p bench/v7_p2; do
    t=$T1; [ $b = bench/v6r2_p ] && t=$TP
    for tt in $t $( [ $b = bench/v6r2_p ] || echo $T7S | cut -s -d' ' -f2- ); do
      run1 $b $IN $STEPS bench/oq.txt $IT $K --tile=$tt
      cmp -s bench/oq.txt $R && ok=PASS || ok=MISMATCH
      log "  $b tile=$tt (used $(tilev)) ($ok) GPU-event us/step=$(devus)"; proflines
    done
  done
  ;;
sweep)
  IN=${2:?checkpoint COPY}; IT=${3:?its iteration}; STEPS=${STEPS:-2000}; R=$(ref_for $IN $STEPS)
  for b in ./cuda196_v7 bench/v7_t256mb1 bench/v7_t512; do
    for K in 128 256 512; do
      for T in 0 608 736 864 992 1248; do
        run1 $b $IN $STEPS bench/o_sw.txt $IT $K --tile=$T || { log "$b K=$K tile=$T FAILED"; continue; }
        cmp -s bench/o_sw.txt $R && ok=PASS || ok=MISMATCH
        log "$b K=$K tile=$T(used $(tilev)) $ok device_us_per_step=$(devus) sm_clock_mhz=$(mhz) $(grep -oE 'replays=[0-9]+' bench/last.txt | tail -1)"
      done
    done
  done
  ;;
runmode)
  rm -rf bench/rm && mkdir -p bench/rm && cp $CK bench/rm/
  (cd bench/rm && ../../cuda196_v7 run $CK $START run --chunk=1000 --keep=2 --steps=3000 2>> ../log.txt)
  R=$(ref_for $CK 3000)
  p=$(python3 -c "import json;print(json.load(open('bench/rm/run/latest.json'))['path'])")
  cmp -s bench/rm/$p $R && log "run mode +3000 == reference: PASS" || log "run mode: MISMATCH"
  python3 - <<'EOF' | tee -a bench/summary.txt
import hashlib, json, re
j = json.load(open('bench/rm/run/latest.json'))
d = re.sub(r'[^0-9]', '', open('bench/rm/' + j['path']).read())
print('latest.json digits-only sha256:', 'PASS' if hashlib.sha256(d.encode()).hexdigest() == j['sha256'] and len(d) == j['digits'] else 'MISMATCH',
      '| sm_clock_mhz_last_chunk =', j.get('sm_clock_mhz_last_chunk'))
EOF
  ;;
*) echo "usage: $0 build|resources|gate|big FILE ITER|small|sweep FILE ITER|runmode"; exit 1 ;;
esac
