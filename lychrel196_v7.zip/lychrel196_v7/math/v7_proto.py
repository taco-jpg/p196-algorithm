# v7 chunk algorithm prototype (exact semantics planned for bits_tb7.h), checked against big ints.
# Tile = pairs [P0, P0 + 32*Wt) in transposed layout: word u, lane k  <->  pair P0 + k*Wt + u.
# Each "thread" handles C consecutive words (all lanes). Carry-ins come from scanning the stable
# current state (scan-back for the low chain, scan-forward for the high chain, with lane wrap).
import random, sys
sys.set_int_max_str_digits(0)
M = 0xFFFFFFFF
C = 8

def pairs(s): n = len(s); return [int(s[n-1-j]) + int(s[j]) for j in range((n+1)//2)]
def below(x): return 0 if x <= 0 else (M if x >= 32 else (1 << x) - 1)

def to_tile(S, P0, Wt):
    W = [[0]*5 for _ in range(Wt)]
    for k in range(32):
        for u in range(Wt):
            p = P0 + k*Wt + u
            v = S[p] if 0 <= p < len(S) else 0
            for q in range(5):
                if (v >> q) & 1: W[u][q] |= 1 << k
    return W
def from_tile(W, P0, Wt, h):
    out = [0]*h
    for k in range(32):
        for u in range(Wt):
            p = P0 + k*Wt + u
            if 0 <= p < h: out[p] = sum(((W[u][q] >> k) & 1) << q for q in range(5))
    return out

def Gof(p): return (p[4] | (p[3] & (p[2] | p[1]))) & M
def Pof(p): return (~p[4] & p[3] & ~p[2] & ~p[1] & p[0]) & M
def digit4(p, c, kk):
    cc = c; w0 = p[0] ^ cc; cc &= p[0]; w1 = p[1] ^ cc; cc &= p[1]; w2 = p[2] ^ cc; cc &= p[2]; w3 = p[3] ^ cc
    r1 = w1 ^ kk; bo = ~w1 & kk; r2 = w2 ^ bo; bo = ~w2 & bo; dd = w3 ^ kk; r3 = dd ^ bo
    return [w0 & M, r1 & M, r2 & M, r3 & M]

def step_tile(W, Wt, P0, n, g, mid_tile):
    """one step of the whole tile, chunk by chunk; returns new tile words"""
    h = (n + 1) // 2; h1 = (n + g + 1) // 2
    hr = h - P0; qh, rh = divmod(hr, Wt) if hr >= 0 else (-1, 0)
    def mh(u):  # lanes whose pair at word u is < h
        if not mid_tile: return M
        if hr <= 0: return 0
        return below(qh + (1 if u < rh else 0))
    # middle carry (low carry into pair hpos), tile-relative scan pair by pair
    def is9(p):
        if p < 0 or p >= 32*Wt: return 0
        k, u = divmod(p, Wt); return (Pof(W[u]) >> k) & 1
    def ge10(p):
        if p < 0 or p >= 32*Wt: return 0
        k, u = divmod(p, Wt); return (Gof(W[u]) >> k) & 1
    mid = 0
    if mid_tile:
        hpos = (h if n % 2 == 0 else h - 1) - P0
        q = hpos - 1
        while q >= 0 and is9(q): q -= 1
        mid = ge10(q) if q >= 0 else 0
    def GhPh(u, shift_up=0):
        # high-chain generate/propagate at word u (positions >= h generate 'mid')
        G, P = Gof(W[u]), Pof(W[u]); m = mh(u)
        return ((G & m) | ((M & ~m) if mid else 0)) & M, P & m
    out = [None]*Wt
    for u0 in range(0, Wt, C):
        S = [W[u0+i] for i in range(C)]
        G = [Gof(x) for x in S]; P = [Pof(x) for x in S]
        # ---- low carry into word u0: scan back with wrap (shift up by lanes)
        carry, unres, j, sh = 0, M, u0 - 1, 0
        Sp = None
        while True:
            if j < 0: j = Wt - 1; sh += 1
            Gj, Pj = Gof(W[j]), Pof(W[j])
            Gj = (Gj << sh) & M; Pj = (Pj << sh) & M
            if Sp is None: Sp = [(W[j][q] << sh) & M for q in range(5)]; Gp, Pp = Gj, Pj
            carry |= unres & Gj; unres &= Pj
            if not unres: break
            j -= 1
        at = [carry]
        for i in range(C): at.append((G[i] | (P[i] & at[i])) & M)
        # ---- high carry into word u0+C-1 from above: scan forward with wrap (shift down)
        carry, unres, j, sh = 0, M, u0 + C, 0
        while True:
            if j >= Wt: j = 0; sh += 1
            Gj, Pj = GhPh(j)
            vac = (M & ~(M >> sh)) if sh else 0          # lanes shifted in from beyond the top
            Gj = (Gj >> sh) | (vac if (mid_tile and mid) else 0); Pj = Pj >> sh
            carry |= unres & Gj; unres &= Pj
            if not unres: break
            j += 1
        bt = [0]*(C+1); bt[C] = carry
        for i in range(C-1, -1, -1):
            Gh, Ph = GhPh(u0+i); bt[i] = (Gh | (Ph & bt[i+1])) & M
        # ---- update
        res = []
        if not g:
            for i in range(C):
                cw = S[i]; m = mh(u0+i)
                a, b, aup, bdn = at[i] & m, bt[i+1] & m, at[i+1] & m, bt[i] & m
                t0 = a ^ b; t1 = a & b
                v1 = cw[0] ^ t1; cc = cw[0] & t1; v2 = cw[1] ^ cc; cc &= cw[1]; v3 = cw[2] ^ cc; cc &= cw[2]; v4 = cw[3] ^ cc
                k1 = aup ^ bdn; k2 = aup & bdn
                r1 = v1 ^ k1; bo = ~v1 & k1
                dd = v2 ^ k2; r2 = dd ^ bo; bo = (~v2 & k2) | (~dd & bo)
                dd = v3 ^ k1; r3 = dd ^ bo; bo = (~v3 & k1) | (~dd & bo)
                dd = v4 ^ k2; r4 = dd ^ bo
                res.append([x & m for x in (t0, r1, r2, r3, r4)])
        else:
            # previous pair's high digit for word u0: from Sp (word u0-1, or word Wt-1 shifted up)
            bprev = bt[0]
            hprev = digit4(Sp, bprev, (Gp | (Pp & bprev)) & M)
            if u0 == 0 and P0 == 0:                     # global pair -1: the new leading digit 1
                hprev = [(hprev[0] & ~1) | 1, hprev[1] & ~1, hprev[2] & ~1, hprev[3] & ~1]
            for i in range(C):
                cw = S[i]; m = mh(u0+i)
                a, b, aup, bdn = at[i] & m, bt[i+1] & m, at[i+1] & m, bt[i] & m
                lo = digit4(cw, a, aup); hi = digit4(cw, b, bdn)
                hs = hprev; hprev = hi
                if mid_tile and n % 2 == 0:             # centre pair h: 2*hi_{h-1}
                    if 0 <= hr < 32*Wt:
                        kc, uc = divmod(hr, Wt)
                        if u0 + i == uc:
                            bm = 1 << kc; lo = [(lo[q] & ~bm) | (hs[q] & bm) for q in range(4)]
                m1 = mh1(u0+i, h1, P0, Wt) if mid_tile else M
                cc = 0; o = []
                for q in range(4):
                    x, y = lo[q], hs[q]; o.append((x ^ y ^ cc) & m1); cc = (x & y) | (cc & (x ^ y))
                o.append(cc & m1); res.append(o)
        for i in range(C): out[u0+i] = res[i]
    return out

def mh1(u, h1, P0, Wt):
    r = h1 - P0
    if r <= 0: return 0
    q, rr = divmod(r, Wt); return below(q + (1 if u < rr else 0))

def growth_of(S, n):  # b_{-1}
    h = len(S); hp = h if n % 2 == 0 else h - 1
    a = 0
    for j in range(hp): a = 1 if S[j] >= 10 else (a if S[j] == 9 else 0)
    b = a
    for j in range(h-1, -1, -1): b = 1 if S[j] >= 10 else (b if S[j] == 9 else 0)
    return b

def check(s, Wt_extra=0):
    n = len(s); S = pairs(s); h = len(S)
    g = growth_of(S, n)
    Wt = max(32, ((h + 31)//32 + 31)//32*32) + 32*Wt_extra
    W = to_tile(S, 0, Wt)
    mid_tile = 32*Wt > h
    Wn = step_tile(W, Wt, 0, n, g, mid_tile)
    r = str(int(s) + int(s[::-1]))
    got = from_tile(Wn, 0, Wt, (len(r)+1)//2)
    # also everything beyond h' must be zero
    for k in range(32):
        for u in range(Wt):
            p = k*Wt + u
            if p >= (len(r)+1)//2:
                assert all(((Wn[u][q] >> k) & 1) == 0 for q in range(5)), ("nonzero beyond h", s)
    assert got == pairs(r), (s, got[:10], pairs(r)[:10])
    assert n + g == len(r)

random.seed(5); cnt = 0
s = '196'
for k in range(400):
    check(s, k % 2); s = str(int(s) + int(s[::-1])); cnt += 1
for t in range(1500):
    Ln = random.randint(1, 4000)
    d = [random.randint(0, 9) for _ in range(Ln)]
    for _ in range(random.randint(0, 5)):
        a0 = random.randint(0, Ln // 2); LL = random.randint(1, 300)
        for j in range(a0, min(a0 + LL, Ln // 2)): d[Ln - 1 - j] = 9 - d[j]
    if d[0] == 0: d[0] = 1
    check(''.join(map(str, d)), random.randint(0, 2)); cnt += 1
print(f"v7 chunk algorithm exact on {cnt} cases")
