// bits_tb7.h - time-blocked exact bit-plane engine, v7: transposed tiles.
// Shared verbatim by the CUDA kernel (cuda196_v7.cu) and the CPU emulator (emu196_v7.cpp).
//
// Same arithmetic as bits_core.h (v4, GPU-validated) and the v5/v6 time-blocked engines; the
// certified results are identical. What changes is how a tile sits in shared memory:
//
//  TRANSPOSED TILE. A tile is the pair range [P0, P0 + 32*Wt) (Wt words, a multiple of 32).
//  Word u, lane (bit) k holds pair P0 + k*Wt + u. Each lane is a contiguous run of Wt pairs.
//  The carry recurrences a_{j+1} = G_j | P_j a_j and b_{j-1} = G_j | P_j b_j then run along
//  the word index with one 3-input logic op per word for all 32 lanes at once - no 64-bit adds,
//  no bit reversals. Neighbour values a_{j+1}, b_{j-1} and the growth shift hi_{j-1} are simply
//  the neighbouring words.
//
//  CHUNKS. Each worker thread handles C (=8) consecutive words. Its carry-ins come from the
//  stable current state (read-only during the step): scan back from word u0-1 until every lane
//  has met a non-9 pair (low chain), scan forward from word u0+C (high chain). A scan that runs
//  off the end of a lane continues in the neighbouring lane (shift by one lane); off the tile it
//  sees zeros (the tile semantics of v5/v6). So there is still exactly one barrier per step.
//
//  MIDDLE. A tile that contains pair h (rare: one block, or the prefix tile of small numbers)
//  runs the same code with masks: pairs >= h 'generate' the middle carry in the high chain
//  (equivalent to propagating it), outputs beyond the new h are zeroed, the even-n centre pair
//  takes 2*hi_{h-1} in growth steps.
//
//  LOAD/STORE. Global memory keeps the natural layout. A block stages its words in shared
//  memory and transposes 32x32 bit blocks (warp shuffles on the GPU, the same algorithm on
//  arrays in the emulator), once per launch in each direction.
//
//  Certification (interval tracking), growth from a prefix tile, palindrome counting, failure
//  replay and thread roles (warp 1 tracks, everyone else works) are as in v6r2. The tracker
//  takes a fast path (three independent probes) and falls back to the exact v5 loop otherwise.
#pragma once
#include "bits_core.h"
#if (defined(TB_COUNT_PATHS) || defined(TB_CHECK_GROWTH)) && !defined(__CUDA_ARCH__)
#include <atomic>
#include <cstdio>
#include <cstdlib>
#endif

#if defined(__CUDA_ARCH__)
#define TB_UNROLL _Pragma("unroll")
#else
#define TB_UNROLL
#endif

namespace tb {
using bits::u32;
using bits::u64;

static const int KMAX = 1024;
#ifndef TB_THREADS
#define TB_THREADS 192  // v7 default: 5 worker warps + 1 tracking warp; 0 spills on sm_89 (see README)
#endif
static const int THREADS = TB_THREADS;
static_assert(TB_THREADS >= 96 && TB_THREADS % 32 == 0, "v7 needs warp 1 for tracking plus workers");
#ifndef TB7_C
#define TB7_C 8
#endif
static const int C = TB7_C;  // words per worker chunk
static_assert(C == 8, "v7 uses 8-word chunks (growth is decided from the first 8 pairs; see ph_work)");

#if defined(TB_COUNT_PATHS) && !defined(__CUDA_ARCH__)
static std::atomic<long long> g_fast{0}, g_mid{0}, g_trk_fast{0}, g_trk_slow{0}, g_scan_extra{0};
#define TB_COUNT(x) (x)++
#else
#define TB_COUNT(x)
#endif
#if defined(TB_CHECK_GROWTH) && !defined(__CUDA_ARCH__)
static std::atomic<long long> g_growth_checks{0};
#endif

// ---------------------------------------------------------------- small helpers
BHD u32 umulhi32(u32 a, u32 b) {
#ifdef __CUDA_ARCH__
  return __umulhi(a, b);
#else
  return (u32)(((u64)a * b) >> 32);
#endif
}
BHD int ctz32(u32 x) {
#ifdef __CUDA_ARCH__
  return __ffs(x) - 1;
#else
  return __builtin_ctz(x);
#endif
}
// ceil(2^32 / d): floor(p / d) == umulhi(p, magic) for p * d < 2^32 (here p < 32*Wt, Wt < 11585)
BHD u32 magic_for(int d) { return (u32)(0xFFFFFFFFull / (u32)d) + 1u; }
BHD u32 below(int x) { return x <= 0 ? 0u : (x >= 32 ? 0xFFFFFFFFu : ((1u << x) - 1u)); }
BHD u32 shl(u32 x, int s) { return s >= 32 ? 0u : (x << s); }
BHD u32 shr(u32 x, int s) { return s >= 32 ? 0u : (x >> s); }

// Bank-conflict-free placement inside a transposed buffer: word u lives at swz(u). It swaps the
// two 4-word halves of every chunk whose index has bit 2 set, so the 128-bit accesses of any 8
// consecutive threads (one shared-memory phase) hit 8 different 4-bank groups. Involution.
BHD int swz(int u) { return u ^ ((u >> 3) & 4); }
// transposed view: logical word u of plane q at s[q*stride + swz(u)]; pairs [P0, P0 + 32*Wt)
struct TV { const u32* s; int stride, Wt, P0; u32 magic; };
BHD void tld(const TV& v, int u, u32 p[5]) {
  const int x = swz(u);
  TB_UNROLL
  for (int q = 0; q < 5; ++q) p[q] = v.s[q * v.stride + x];
}
BHD u32 pbits_P(const TV& v, int u) { u32 p[5]; tld(v, u, p); return bits::Pof(p); }
// pair-level lookups (absolute pair index); outside the tile the state reads as 0
BHD int t_bit(const TV& v, int pabs, bool wantG) {
  const int rel = pabs - v.P0;
  if (rel < 0 || rel >= 32 * v.Wt) return 0;
  const int k = (int)umulhi32((u32)rel, v.magic), u = rel - k * v.Wt;
  u32 p[5]; tld(v, u, p);
  return (int)(((wantG ? bits::Gof(p) : bits::Pof(p)) >> k) & 1u);
}
BHD int t_is9(const TV& v, int p) { return t_bit(v, p, false); }
BHD int t_ge10(const TV& v, int p) { return t_bit(v, p, true); }

// ---------------------------------------------------------------- 32x32 bit transpose
// Lane i holds row i (bit j = M[i][j]); afterwards lane j holds column j (bit i = M[i][j]).
// Five butterfly stages. The emulator runs the identical stages on an array.
#ifdef __CUDACC__
__device__ __forceinline__ u32 transpose32_lane(u32 x, int lane) {
  const u32 mk[5] = {0x0000FFFFu, 0x00FF00FFu, 0x0F0F0F0Fu, 0x33333333u, 0x55555555u};
#pragma unroll
  for (int i = 0, s = 16; i < 5; ++i, s >>= 1) {
    const u32 y = __shfl_xor_sync(0xFFFFFFFFu, x, s);
    const u32 m = mk[i];
    x = (lane & s) ? ((x & ~m) | ((y & ~m) >> s)) : ((x & m) | ((y & m) << s));
  }
  return x;
}
#endif
static inline void transpose32_array(u32 x[32]) {
  const u32 mk[5] = {0x0000FFFFu, 0x00FF00FFu, 0x0F0F0F0Fu, 0x33333333u, 0x55555555u};
  for (int i = 0, s = 16; i < 5; ++i, s >>= 1) {
    const u32 m = mk[i];
    for (int l = 0; l < 32; ++l) {
      if (l & s) continue;
      const u32 a = x[l], b = x[l ^ s];
      x[l] = (a & m) | ((b & m) << s);
      x[l ^ s] = (b & ~m) | ((a & ~m) >> s);
    }
  }
}

// ---------------------------------------------------------------- the step for one chunk
// Owned-pair ranges for palindrome counting, relative to the tile: [lo, hi)
struct Own { int qlo, rlo, qhi, rhi; };
BHD Own own_of(const TV& v, int plo_rel, int phi_rel) {
  Own o;
  if (phi_rel <= plo_rel) { o.qlo = 32; o.rlo = 0; o.qhi = 0; o.rhi = 0; return o; }  // empty
  o.qlo = (int)umulhi32((u32)plo_rel, v.magic); o.rlo = plo_rel - o.qlo * v.Wt;
  o.qhi = (int)umulhi32((u32)phi_rel, v.magic); o.rhi = phi_rel - o.qhi * v.Wt;
  return o;
}
BHD u32 own_mask(const Own& o, int u) {
  return below(o.qhi + (u < o.rhi ? 1 : 0)) & ~below(o.qlo + (u < o.rlo ? 1 : 0));
}
// Lanes whose pair at word u is below x (x relative to the tile start): mask for the middle tile
BHD u32 lanes_below(int xr, int qx, int rx, int u) { return xr <= 0 ? 0u : below(qx + (u < rx ? 1 : 0)); }

// One step for words [u0, u0+C) of tile v, written to d (same layout). Returns bit 0 = owned
// mismatch. For the global word 0 chunk on the unmasked path it also returns the new state's
// first non-9 pair among pairs 0..C-1 (lane 0): bit 1 = found, bit 2 = growth, bits 3.. = pair.
// SH (GPU, fast path only): the four neighbour words on each side come from the neighbouring
// lanes' registers by warp shuffle; lane l holds chunk i, lane l-1 chunk i-1 (worker mapping is
// contiguous inside a warp). All lanes of the warp must call this together (see ph_work); `act`
// = this lane has a real item (inactive lanes compute a duplicate and do not store).
// In the emulator SH reads the same words from shared memory (identical values).
template <bool MID, bool SH>
BHD u32 chunk_step(const TV& v, u32* __restrict__ d, int n, int g, int u0, const Own& own, int lane, bool act) {
  const int Wt = v.Wt;
  // ---- middle-tile geometry (compile-time absent on the fast path)
  int hr = 0, qh = 0, rh = 0, h1r = 0, qh1 = 0, rh1 = 0;
  u32 midc = 0;
  if (MID) {
    const int h = (n + 1) / 2, h1 = (n + g + 1) / 2;
    hr = h - v.P0; h1r = h1 - v.P0;
    if (hr > 0) { qh = (int)umulhi32((u32)hr, v.magic); rh = hr - qh * Wt; }
    if (h1r > 0) { qh1 = (int)umulhi32((u32)h1r, v.magic); rh1 = h1r - qh1 * Wt; }
    // middle carry: low carry into pair h (n even) or h-1 (n odd), scanning pairs downward
    int q = ((n % 2 == 0) ? h : h - 1) - 1;
    while (q >= v.P0 && t_is9(v, q)) --q;
    midc = (q >= v.P0 && t_ge10(v, q)) ? 0xFFFFFFFFu : 0u;
  }
  // ---- load the chunk (vector loads), G and P per word
  u32 S[C][5];
  const int hsw = (u0 >> 3) & 4;  // swizzle: logical half h of this chunk sits at offset 4*h ^ hsw
  TB_UNROLL
  for (int q = 0; q < 5; ++q) {
    const u32* row = v.s + q * v.stride + u0;
#ifdef __CUDA_ARCH__
    TB_UNROLL
    for (int i = 0; i < C; i += 4) {
      const uint4 w4 = *reinterpret_cast<const uint4*>(row + (i ^ hsw));
      S[i][q] = w4.x; S[i + 1][q] = w4.y; S[i + 2][q] = w4.z; S[i + 3][q] = w4.w;
    }
#else
    for (int i = 0; i < C; ++i) S[i][q] = row[i ^ hsw];
#endif
  }
  u32 G[C], P[C];
  TB_UNROLL
  for (int i = 0; i < C; ++i) { G[i] = bits::Gof(S[i]); P[i] = bits::Pof(S[i]); }

  // ---- low carry into word u0: three words below (neighbour lane, or shared memory), then a
  // rare loop while some lane is still inside a run of pair-sum 9
  u32 Sp[5], Gp, Pp;  // the word just below (for growth): word u0-1, or word Wt-1 shifted up a lane
  u32 cl, unres;
  int j, sh;
  bool lowDone = false;
  if (SH) {
    const bool lowOK = lane >= 1 && u0 >= C;  // lane-1 holds chunk u0-C of the same tile
#ifdef __CUDA_ARCH__
    const u32 g7 = __shfl_up_sync(0xFFFFFFFFu, G[C - 1], 1), p7 = __shfl_up_sync(0xFFFFFFFFu, P[C - 1], 1);
    const u32 g6 = __shfl_up_sync(0xFFFFFFFFu, G[C - 2], 1), p6 = __shfl_up_sync(0xFFFFFFFFu, P[C - 2], 1);
    const u32 g5 = __shfl_up_sync(0xFFFFFFFFu, G[C - 3], 1), p5 = __shfl_up_sync(0xFFFFFFFFu, P[C - 3], 1);
    const u32 g4 = __shfl_up_sync(0xFFFFFFFFu, G[C - 4], 1), p4 = __shfl_up_sync(0xFFFFFFFFu, P[C - 4], 1);
    u32 s7[5] = {0, 0, 0, 0, 0};
    if (g) {  // block-uniform
      TB_UNROLL
      for (int q = 0; q < 5; ++q) s7[q] = __shfl_up_sync(0xFFFFFFFFu, S[C - 1][q], 1);
    }
#else
    u32 g7 = 0, p7 = 0, g6 = 0, p6 = 0, g5 = 0, p5 = 0, g4 = 0, p4 = 0, s7[5] = {0, 0, 0, 0, 0};
    if (lowOK) {  // emulator: the neighbour lane's registers hold exactly these words
      u32 r1[5], r2[5], r3[5];
      tld(v, u0 - 1, s7); tld(v, u0 - 2, r1); tld(v, u0 - 3, r2); tld(v, u0 - 4, r3);
      g7 = bits::Gof(s7); p7 = bits::Pof(s7); g6 = bits::Gof(r1); p6 = bits::Pof(r1); g5 = bits::Gof(r2); p5 = bits::Pof(r2);
      g4 = bits::Gof(r3); p4 = bits::Pof(r3);
    }
#endif
    if (lowOK) {
      TB_UNROLL
      for (int q = 0; q < 5; ++q) Sp[q] = s7[q];
      Gp = g7; Pp = p7;
      cl = g7 | (p7 & (g6 | (p6 & (g5 | (p5 & g4)))));  // four words from the neighbour lane
      unres = p7 & p6 & p5 & p4;
      j = u0 - 4; sh = 0;
      lowDone = true;
    }
  }
  if (!lowDone) {
    if (!MID && u0 >= 3) {  // interior chunk: words u0-1..u0-3, no lane wrap
      u32 r1[5], r2[5];
      tld(v, u0 - 1, Sp); tld(v, u0 - 2, r1); tld(v, u0 - 3, r2);
      Gp = bits::Gof(Sp); Pp = bits::Pof(Sp);
      const u32 P1 = bits::Pof(r1);
      cl = Gp | (Pp & (bits::Gof(r1) | (P1 & bits::Gof(r2))));
      unres = Pp & P1 & bits::Pof(r2);
      j = u0 - 3; sh = 0;
    } else {  // first chunks of a tile: the scan may wrap into the lane below
      j = u0 - 1; sh = 0;
      if (j < 0) { j = Wt - 1; sh = 1; }
      u32 r0[5]; tld(v, j, r0);
      TB_UNROLL
      for (int q = 0; q < 5; ++q) Sp[q] = shl(r0[q], sh);
      Gp = bits::Gof(Sp); Pp = bits::Pof(Sp);
      cl = Gp; unres = Pp;
      TB_UNROLL
      for (int e = 0; e < 2; ++e) {
        if (--j < 0) { j = Wt - 1; ++sh; }
        u32 r[5]; tld(v, j, r);
        const u32 Gj = shl(bits::Gof(r), sh), Pj = shl(bits::Pof(r), sh);
        cl |= unres & Gj; unres &= Pj;
      }
    }
  }
  while (unres) {  // rare
    TB_COUNT(g_scan_extra);
    if (--j < 0) { j = Wt - 1; ++sh; }
    u32 r[5]; tld(v, j, r);
    const u32 Gj = shl(bits::Gof(r), sh), Pj = shl(bits::Pof(r), sh);
    cl |= unres & Gj; unres &= Pj;
  }
  u32 at[C + 1];  // at[i] = low carry into word u0+i
  at[0] = cl;
  TB_UNROLL
  for (int i = 0; i < C; ++i) at[i + 1] = G[i] | (P[i] & at[i]);

  // ---- high chain generate/propagate (positions >= h generate the middle carry)
  u32 Gh[C], Ph[C];
  TB_UNROLL
  for (int i = 0; i < C; ++i) {
    if (MID) {
      const u32 m = lanes_below(hr, qh, rh, u0 + i);
      Gh[i] = (G[i] & m) | (midc & ~m); Ph[i] = P[i] & m;
    } else { Gh[i] = G[i]; Ph[i] = P[i]; }
  }
  // ---- high carry into word u0+C-1 from above: three words above, then a rare loop
  u32 ch;
  bool highDone = false;
  if (SH) {
    const bool highOK = lane <= 30 && u0 + C < Wt;  // lane+1 holds chunk u0+C of the same tile
#ifdef __CUDA_ARCH__
    const u32 g0 = __shfl_down_sync(0xFFFFFFFFu, G[0], 1), p0 = __shfl_down_sync(0xFFFFFFFFu, P[0], 1);
    const u32 g1 = __shfl_down_sync(0xFFFFFFFFu, G[1], 1), p1 = __shfl_down_sync(0xFFFFFFFFu, P[1], 1);
    const u32 g2 = __shfl_down_sync(0xFFFFFFFFu, G[2], 1), p2 = __shfl_down_sync(0xFFFFFFFFu, P[2], 1);
    const u32 g3 = __shfl_down_sync(0xFFFFFFFFu, G[3], 1), p3 = __shfl_down_sync(0xFFFFFFFFu, P[3], 1);
#else
    u32 g0 = 0, p0 = 0, g1 = 0, p1 = 0, g2 = 0, p2 = 0, g3 = 0, p3 = 0;
    if (highOK) {
      u32 r0[5], r1[5], r2[5], r3[5];
      tld(v, u0 + C, r0); tld(v, u0 + C + 1, r1); tld(v, u0 + C + 2, r2); tld(v, u0 + C + 3, r3);
      g0 = bits::Gof(r0); p0 = bits::Pof(r0); g1 = bits::Gof(r1); p1 = bits::Pof(r1); g2 = bits::Gof(r2); p2 = bits::Pof(r2);
      g3 = bits::Gof(r3); p3 = bits::Pof(r3);
    }
#endif
    if (highOK) {
      ch = g0 | (p0 & (g1 | (p1 & (g2 | (p2 & g3)))));  // four words from the neighbour lane
      unres = p0 & p1 & p2 & p3;
      j = u0 + C + 3; sh = 0;
      highDone = true;
    }
  }
  if (!highDone) {
    if (!MID && u0 + C + 2 < Wt) {  // interior chunk: words u0+C..u0+C+2, no lane wrap
      u32 r0[5], r1[5], r2[5];
      tld(v, u0 + C, r0); tld(v, u0 + C + 1, r1); tld(v, u0 + C + 2, r2);
      const u32 P0w = bits::Pof(r0), P1 = bits::Pof(r1);
      ch = bits::Gof(r0) | (P0w & (bits::Gof(r1) | (P1 & bits::Gof(r2))));
      unres = P0w & P1 & bits::Pof(r2);
      j = u0 + C + 2; sh = 0;
    } else {  // last chunks of a tile (or the middle tile): may wrap into the lane above
      j = u0 + C; sh = 0;
      if (j >= Wt) { j = 0; sh = 1; }
      unres = 0xFFFFFFFFu; ch = 0;
      TB_UNROLL
      for (int e = 0; e < 3; ++e) {
        if (e > 0 && ++j >= Wt) { j = 0; ++sh; }
        u32 r[5]; tld(v, j, r);
        u32 Gj = bits::Gof(r), Pj = bits::Pof(r);
        if (MID) { const u32 m = lanes_below(hr, qh, rh, j); Gj = (Gj & m) | (midc & ~m); Pj &= m; }
        Gj = shr(Gj, sh); Pj = shr(Pj, sh);
        if (MID) Gj |= midc & ~shr(0xFFFFFFFFu, sh);  // lanes shifted in from beyond the top: >= h
        ch |= unres & Gj; unres &= Pj;
      }
    }
  }
  while (unres) {  // rare
    TB_COUNT(g_scan_extra);
    if (++j >= Wt) { j = 0; ++sh; }
    u32 r[5]; tld(v, j, r);
    u32 Gj = bits::Gof(r), Pj = bits::Pof(r);
    if (MID) { const u32 m = lanes_below(hr, qh, rh, j); Gj = (Gj & m) | (midc & ~m); Pj &= m; }
    Gj = shr(Gj, sh); Pj = shr(Pj, sh);
    if (MID) Gj |= midc & ~shr(0xFFFFFFFFu, sh);
    ch |= unres & Gj; unres &= Pj;
  }
  u32 bt[C + 1];  // bt[i] = high carry into word u0+i-1 (bt[C]: into the chunk's top word)
  bt[C] = ch;
  TB_UNROLL
  for (int i = C - 1; i >= 0; --i) bt[i] = Gh[i] | (Ph[i] & bt[i + 1]);

  // ---- owned-pair masks for palindrome counting (uniform over the chunk except at 2 chunks)
  // Outside the middle tile the owned boundaries are multiples of 32 pairs relative to the tile
  // (32*o0w, 32*o1w, 32*bw), so they fall on chunk boundaries: one mask per chunk.
  const bool ownUniform = !MID || !((u0 < own.rlo && own.rlo < u0 + C) || (u0 < own.rhi && own.rhi < u0 + C));
  const u32 ownU = own_mask(own, u0);
#if defined(TB_CHECK_GROWTH) && !defined(__CUDA_ARCH__)
  if (!MID) {  // self-check build: the per-chunk mask must equal every per-word mask
    for (int i = 0; i < C; ++i)
      if (own_mask(own, u0 + i) != ownU) { fprintf(stderr, "owned mask not uniform at u0=%d\n", u0); abort(); }
  }
#endif
  u32 diff = 0;
  u32 res = 0;
  // the update runs in halves of 4 words, each stored right away (fewer live registers)
  u32 hprev[4] = {0, 0, 0, 0};
  int kc = -1, uc = -1;  // even n: centre pair h takes 2*hi_{h-1}
  if (g) {  // previous pair's high digit for word u0 (word u0-1, or word Wt-1 of the lane below)
    const u32 bp = bt[0];
    bits::digit4(Sp, bp, Gp | (Pp & bp), hprev);
    if (u0 == 0 && v.P0 == 0) {  // global pair -1: the new leading digit 1
      hprev[0] = (hprev[0] & ~1u) | 1u; hprev[1] &= ~1u; hprev[2] &= ~1u; hprev[3] &= ~1u;
    }
    if (MID && (n % 2 == 0) && hr >= 0 && hr < 32 * Wt) { kc = qh; uc = rh; }
  }
  TB_UNROLL
  for (int hb = 0; hb < C; hb += 4) {
  u32 out[4][5];
  if (!g) {
    TB_UNROLL
    for (int i = hb; i < hb + 4; ++i) {
      const u32* cw = S[i];
      u32 a = at[i], b = bt[i + 1], aup = at[i + 1], bdn = bt[i];
      u32 m = 0xFFFFFFFFu;
      if (MID) { m = lanes_below(hr, qh, rh, u0 + i); a &= m; b &= m; aup &= m; bdn &= m; }
      const u32 t0 = a ^ b, t1 = a & b;
      const u32 v1 = cw[0] ^ t1; u32 cc = cw[0] & t1;
      const u32 v2 = cw[1] ^ cc; cc &= cw[1];
      const u32 v3 = cw[2] ^ cc; cc &= cw[2];
      const u32 v4 = cw[3] ^ cc;
      const u32 k1 = aup ^ bdn, k2 = aup & bdn;
      const u32 r1 = v1 ^ k1; u32 bo = ~v1 & k1;
      u32 dd = v2 ^ k2; const u32 r2 = dd ^ bo; bo = (~v2 & k2) | (~dd & bo);
      dd = v3 ^ k1;     const u32 r3 = dd ^ bo; bo = (~v3 & k1) | (~dd & bo);
      dd = v4 ^ k2;     const u32 r4 = dd ^ bo;
      u32* o = out[i - hb];
      o[0] = t0 & m; o[1] = r1 & m; o[2] = r2 & m; o[3] = r3 & m; o[4] = r4 & m;
      diff |= t0 & (ownUniform ? ownU : own_mask(own, u0 + i));
    }
  } else {
    TB_UNROLL
    for (int i = hb; i < hb + 4; ++i) {
      const u32* cw = S[i];
      u32 a = at[i], b = bt[i + 1], aup = at[i + 1], bdn = bt[i];
      if (MID) { const u32 m = lanes_below(hr, qh, rh, u0 + i); a &= m; b &= m; aup &= m; bdn &= m; }
      u32 lo[4], hi[4];
      bits::digit4(cw, a, aup, lo);
      bits::digit4(cw, b, bdn, hi);
      u32 hs[4];
      TB_UNROLL
      for (int q = 0; q < 4; ++q) { hs[q] = hprev[q]; hprev[q] = hi[q]; }
      u32 m1 = 0xFFFFFFFFu;
      if (MID) {
        if (u0 + i == uc) {
          const u32 bm = 1u << kc;
          TB_UNROLL
          for (int q = 0; q < 4; ++q) lo[q] = (lo[q] & ~bm) | (hs[q] & bm);
        }
        m1 = lanes_below(h1r, qh1, rh1, u0 + i);
      }
      u32 dq = 0, cc = 0;
      u32* o = out[i - hb];
      TB_UNROLL
      for (int q = 0; q < 4; ++q) {
        const u32 x = lo[q], y = hs[q];
        dq |= x ^ y;
        o[q] = (x ^ y ^ cc) & m1;
        cc = (x & y) | (cc & (x ^ y));
      }
      o[4] = cc & m1;
      diff |= dq & (ownUniform ? ownU : own_mask(own, u0 + i));
    }
  }
  // ---- store this half (vector stores, swizzled position)
  if (act) {
    TB_UNROLL
    for (int q = 0; q < 5; ++q) {
      u32* row = d + q * v.stride + u0 + (hb ^ hsw);
#ifdef __CUDA_ARCH__
      *reinterpret_cast<uint4*>(row) = make_uint4(out[0][q], out[1][q], out[2][q], out[3][q]);
#else
      for (int i = 0; i < 4; ++i) row[i] = out[i][q];
#endif
    }
  }
  // Growth of the next step, from this thread's own registers only. In a transposed tile pairs
  // 0..127 run along lane 0 across many words owned by other threads, which have not necessarily
  // written them yet - so never read them here. Lane 0 of this chunk = pairs hb..hb+3 (+u0 = 0).
  if (u0 == 0 && v.P0 == 0 && !(res & 2u)) {
    const int hn = (n + g + 1) / 2;  // pairs of the new state
    TB_UNROLL
    for (int i = 3; i >= 0; --i)
      if (hb + i < hn && !(bits::Pof(out[i]) & 1u)) res = 2u | ((bits::Gof(out[i]) & 1u) << 2) | ((u32)(hb + i + 1) << 3);
  }
  }  // halves
  // all of the new state's pairs are in this chunk and none is non-9: growth_find's answer is -1
  if (u0 == 0 && v.P0 == 0 && !(res & 2u) && (n + g + 1) / 2 <= C) res = 2u;
  return res | (diff != 0 ? 1u : 0u);
}

// ---------------------------------------------------------------- certified interval tracking
struct Track { int L, R, rightReal; };
// exact v5 rule (pair by pair)
BHD int track_step_exact(const TV& v, Track& tr, int n, int g) {
  const int h = (n + 1) / 2;
  if (tr.rightReal) {
    int q = h - 1;
    while (q >= tr.L && t_is9(v, q)) --q;
    if (q < tr.L && tr.L > 0) return 0;
  }
  int nL, nR;
  if (tr.L == 0) nL = 0;
  else {
    int q = tr.L;
    while (q < tr.R && t_is9(v, q)) ++q;
    if (q >= tr.R) return 0;
    nL = q + 1;
  }
  if (tr.rightReal) nR = (n + g + 1) / 2;
  else {
    int r = tr.R - 1;
    while (r >= tr.L && t_is9(v, r)) --r;
    if (r < tr.L) return 0;
    nR = g ? r + 1 : r;
  }
  tr.L = nL; tr.R = nR;
  return nL < nR;
}
// v7 fast path: the three first probes are independent; if none hits a 9 (or an edge case) the
// result is the same as the exact rule's first iteration; otherwise defer to the exact rule.
BHD int track_step(const TV& v, Track& tr, int n, int g) {
  const int h = (n + 1) / 2;
  const bool useM = tr.rightReal != 0, useL = tr.L > 0, useR = tr.rightReal == 0;
  const bool edge = (useM && h - 1 < tr.L) || (useL && tr.L >= tr.R) || (useR && tr.R - 1 < tr.L);
  const int pm = useM ? h - 1 : -1, pl = useL ? tr.L : -1, pr = useR ? tr.R - 1 : -1;
  const int any9 = (pm >= 0 && t_is9(v, pm)) | (pl >= 0 && t_is9(v, pl)) | (pr >= 0 && t_is9(v, pr));
  if (edge || any9) { TB_COUNT(g_trk_slow); return track_step_exact(v, tr, n, g); }
  TB_COUNT(g_trk_fast);
  const int nL = useL ? tr.L + 1 : 0;
  const int nR = tr.rightReal ? (n + g + 1) / 2 : (g ? tr.R : tr.R - 1);
  tr.L = nL; tr.R = nR;
  return nL < nR;
}
// growth from a left-anchored certified tile (first non-9 pair below h is >= 10)
BHD int growth_find(const TV& v, int n, int* g) {  // first non-9 pair among the first 128 (-1: none)
  const int h = (n + 1) / 2;
  const int lim = h < 128 ? h : 128;
  for (int q = 0; q < lim; ++q)
    if (!t_is9(v, q)) { *g = t_ge10(v, q); return q; }
  *g = 0;
  return -1;
}
static const int Q_UNKNOWN = 0x3FFFFFFF;  // never < R: forces certification failure
BHD int growth_ok(int q, const Track& tr, int n) {
  const int h = (n + 1) / 2;
  return q >= 0 ? q < tr.R : (h <= 128 && tr.rightReal && tr.R >= h);
}

// ---------------------------------------------------------------- tile geometry
BHD int round32(int x) { return (x + 31) & ~31; }
BHD int halo_words(int K) { return ((K + K / 4 + 64 + 31) / 32 + 3) & ~3; }
BHD int len_max(int TW, int HW, int K) { return round32(TW + 2 * HW + K / 64 + 16); }
BHD int prefix_words(int HW) { return HW + 4; }
BHD int plen_max(int PW, int K) { return round32(PW + K / 64 + 16); }

struct Conf { int K, TW, HW, PW, lenMax, plenMax, Wcap; };
struct State {  // per block, in shared memory
  int n0, h0, maxw;
  int o0w, o1w, bw, len, plen;
  int ssT, ssP;  // staging strides (odd: conflict-free transposes)
  u32 magT, magP;
  int dead, okT, okP;
  int gq[2];
  Track tr, ptr;
  long long clk0;                // block 0: SM clock / GPU timer at kernel start (clock report)
  unsigned long long gt0;
  int gS[KMAX + 1];
};
// plane strides: capacity + 32 words (room for the padded staging layout)
BHD int tstride(const Conf& c) { return c.lenMax + 32; }
BHD int pstride(const Conf& c) { return c.plenMax + 32; }
BHD size_t state_bytes() { return (sizeof(State) + 15) & ~(size_t)15; }
BHD size_t smem_bytes(const Conf& c) { return state_bytes() + sizeof(u32) * 5 * 2 * (size_t)(tstride(c) + pstride(c)); }
BHD u32* tile_buf(u32* base, const Conf& c, int par) { return base + (size_t)par * 5 * tstride(c); }
BHD u32* pre_buf(u32* base, const Conf& c, int par) { return base + (size_t)10 * tstride(c) + (size_t)par * 5 * pstride(c); }
BHD TV tile_view(const State& S, u32* base, const Conf& c, int par) {
  TV v; v.s = tile_buf(base, c, par); v.stride = tstride(c); v.Wt = S.len; v.P0 = 32 * S.bw; v.magic = S.magT; return v;
}
BHD TV pre_view(const State& S, u32* base, const Conf& c, int par) {
  TV v; v.s = pre_buf(base, c, par); v.stride = pstride(c); v.Wt = S.plen; v.P0 = 0; v.magic = S.magP; return v;
}
BHD int odd_stride(int L32) { return L32 | 1; }

// thread roles: warp 1 tracks (thread 32 the tile, 33 the prefix), all other threads work
static const int TRACK_TID = 32;
BHD bool is_worker(int tid) { return tid < TRACK_TID || tid >= TRACK_TID + 32; }
BHD int worker_index(int tid) { return tid < TRACK_TID ? tid : tid - 32; }
BHD int num_workers(int nth) { return nth - 32; }

// ---------------------------------------------------------------- phases
// Phase 1 (thread 0): geometry of block `blk` (same certification geometry as v5/v6).
BHD void ph_setup(State& S, const Conf& c, int blk, int n0) {
  S.n0 = n0;
  S.h0 = (n0 + 1) / 2;
  S.maxw = (S.h0 + c.K / 2 + 2 + 31) / 32;
  S.o0w = blk * c.TW;
  S.o1w = S.o0w + c.TW < c.Wcap ? S.o0w + c.TW : c.Wcap;
  S.dead = S.o0w >= S.maxw;
  int bw = S.o0w - c.HW;
  S.bw = bw < 0 ? 0 : (bw & ~3);
  long long R0 = 32LL * (S.o1w + c.HW);
  if (R0 > S.h0) R0 = S.h0;
  int rightReal = (R0 == S.h0);
  int endw = S.o1w + c.HW;
  if (rightReal && S.maxw + 1 > endw) endw = S.maxw + 1;
  S.len = round32(endw - S.bw);
  if (S.len > c.lenMax) S.len = c.lenMax;  // cannot happen with len_max(); kept as a guard
  S.tr.L = 32 * S.bw; S.tr.R = (int)R0; S.tr.rightReal = rightReal;
  long long pR0 = 32LL * c.PW;
  if (pR0 > S.h0) pR0 = S.h0;
  int prr = (pR0 == S.h0);
  int pend = c.PW;
  if (prr && S.maxw + 1 > pend) pend = S.maxw + 1;
  S.plen = round32(pend);
  if (S.plen > c.plenMax) S.plen = c.plenMax;
  S.ptr.L = 0; S.ptr.R = (int)pR0; S.ptr.rightReal = prr;
  S.ssT = odd_stride(S.len / 32); S.ssP = odd_stride(S.plen / 32);
  S.magT = magic_for(S.len); S.magP = magic_for(S.plen);
  S.okT = S.okP = 1;
}
// Phase 2a (all threads): global natural words -> staging (parity-1 buffers), relative word
// w = k*L32 + m stored at k*ss + m.
BHD void ph_load_global(const State& S, const Conf& c, u32* base, const u32* src, int tid, int nth) {
  const int ts = tstride(c), ps = pstride(c);
  u32* st = tile_buf(base, c, 1);
  const int L32 = S.len / 32;
  for (int i = tid; i < 5 * S.len; i += nth) {
    const int q = i / S.len, w = i - q * S.len, k = w / L32, m = w - k * L32, gk = S.bw + w;
    st[q * ts + k * S.ssT + m] = gk < c.Wcap ? src[(size_t)q * c.Wcap + gk] : 0u;
  }
  u32* sp = pre_buf(base, c, 1);
  const int P32 = S.plen / 32;
  for (int i = tid; i < 5 * S.plen; i += nth) {
    const int q = i / S.plen, w = i - q * S.plen, k = w / P32, m = w - k * P32;
    sp[q * ps + k * S.ssP + m] = w < c.Wcap ? src[(size_t)q * c.Wcap + w] : 0u;
  }
}
// Transposition work items: (tile|prefix, plane q, block m). Item list: tile 5*L32, prefix 5*P32.
BHD int tr_items(const State& S) { return 5 * (S.len / 32) + 5 * (S.plen / 32); }
BHD void tr_item(const State& S, const Conf& c, u32* base, int it, int par_nat, int par_tr,
                 u32** nat, int* natStride, u32** trw, int* xr) {
  const int nt = 5 * (S.len / 32);
  if (it < nt) {
    const int L32 = S.len / 32, q = it / L32, m = it - q * L32;
    *nat = tile_buf(base, c, par_nat) + q * tstride(c) + m; *natStride = S.ssT;
    *trw = tile_buf(base, c, par_tr) + q * tstride(c) + 32 * m;
    *xr = (m & 1) << 2;  // swz(32m + l) = 32m + (l ^ xr)
  } else {
    const int P32 = S.plen / 32, i2 = it - nt, q = i2 / P32, m = i2 - q * P32;
    *nat = pre_buf(base, c, par_nat) + q * pstride(c) + m; *natStride = S.ssP;
    *trw = pre_buf(base, c, par_tr) + q * pstride(c) + 32 * m;
    *xr = (m & 1) << 2;
  }
}
// Phase 2b (warp-level): staging (natural, parity 1) -> transposed (parity 0), all items.
// Phase 5a (warp-level): transposed (parity f) -> staging (natural, parity f^1), tile only.
#ifdef __CUDACC__
__device__ __forceinline__ void ph_transpose_in(const State& S, const Conf& c, u32* base, int tid, int nth) {
  const int lane = tid & 31, warp = tid >> 5, nw = nth >> 5, items = tr_items(S);
  for (int it = warp; it < items; it += nw) {
    u32 *nat, *trw; int ns, xr;
    tr_item(S, c, base, it, 1, 0, &nat, &ns, &trw, &xr);
    const u32 x = nat[lane * ns];
    trw[lane ^ xr] = transpose32_lane(x, lane);
  }
}
__device__ __forceinline__ void ph_transpose_out(const State& S, const Conf& c, u32* base, int f, int tid, int nth) {
  const int lane = tid & 31, warp = tid >> 5, nw = nth >> 5, items = 5 * (S.len / 32);
  for (int it = warp; it < items; it += nw) {
    u32 *nat, *trw; int ns, xr;
    tr_item(S, c, base, it, f ^ 1, f, &nat, &ns, &trw, &xr);
    const u32 t = trw[lane ^ xr];
    nat[lane * ns] = transpose32_lane(t, lane);
  }
}
#endif
static inline void ph_transpose_in_host(const State& S, const Conf& c, u32* base) {
  const int items = tr_items(S);
  for (int it = 0; it < items; ++it) {
    u32 *nat, *trw; int ns, xr; u32 x[32];
    tr_item(S, c, base, it, 1, 0, &nat, &ns, &trw, &xr);
    for (int l = 0; l < 32; ++l) x[l] = nat[l * ns];
    transpose32_array(x);
    for (int l = 0; l < 32; ++l) trw[l ^ xr] = x[l];
  }
}
static inline void ph_transpose_out_host(const State& S, const Conf& c, u32* base, int f) {
  const int items = 5 * (S.len / 32);
  for (int it = 0; it < items; ++it) {
    u32 *nat, *trw; int ns, xr; u32 x[32];
    tr_item(S, c, base, it, f ^ 1, f, &nat, &ns, &trw, &xr);
    for (int l = 0; l < 32; ++l) x[l] = trw[l ^ xr];
    transpose32_array(x);
    for (int l = 0; l < 32; ++l) nat[l * ns] = x[l];
  }
}
// Phase 3 (thread 0): growth of the first step (prefix tile, transposed, parity 0).
BHD void ph_init(State& S, const Conf& c, u32* base) {
  int g;
  const int q = growth_find(pre_view(S, base, c, 0), S.n0, &g);
  if (!growth_ok(q, S.ptr, S.n0)) S.okP = 0;
  S.gS[0] = g;
}
// Step t, concurrently with the work: warp 1 tracks.
BHD void ph_track(State& S, const Conf& c, u32* base, int t, int n, int tid) {
  if (tid != TRACK_TID && tid != TRACK_TID + 1) return;
  const bool tile = tid == TRACK_TID;
  if (!(tile ? S.okT : S.okP)) return;
  const int g = S.gS[t];
  if (!tile && t > 0 && !growth_ok(S.gq[t & 1], S.ptr, n)) { S.okP = 0; return; }  // check g_t
  TV v;
  v.s = tile ? tile_buf(base, c, t & 1) : pre_buf(base, c, t & 1);
  v.stride = tile ? tstride(c) : pstride(c);
  v.Wt = tile ? S.len : S.plen;
  v.P0 = tile ? 32 * S.bw : 0;
  v.magic = tile ? S.magT : S.magP;
  Track tr = tile ? S.tr : S.ptr;
  const int ok = track_step(v, tr, n, g);
  if (tile) { S.tr = tr; S.okT = ok; } else { S.ptr = tr; S.okP = ok; }
}
// Step t work for one thread: worker i takes items i, i+W, ... of [prefix chunks][tile chunks].
// Item 0 is prefix words 0..C-1, done by thread 0, which then sets g_{t+1}.
BHD u32 ph_work(State& S, const Conf& c, u32* base, int t, int n, int tid, int nth) {
  if (!is_worker(tid)) return 0;
  const int g = S.gS[t], par = t & 1;
  const int h = (n + 1) / 2, h1 = (n + g + 1) / 2;
  const int P0t = 32 * S.bw;
  const int plo = 32 * S.o0w;
  long long phl = 32LL * S.o1w;
  const int phi = phl < h1 ? (int)phl : h1;
  const bool midT = 32LL * (S.bw + S.len) > h, midP = 32LL * S.plen > h;
  const int np = S.plen / C, items = np + S.len / C, nw = num_workers(nth);
  const TV vp = pre_view(S, base, c, par), vt = tile_view(S, base, c, par);
  u32* pd = pre_buf(base, c, par ^ 1);
  u32* td = tile_buf(base, c, par ^ 1);
  const Own ownT = own_of(vt, plo - P0t, phi - P0t);
  Own ownP; ownP.qlo = 32; ownP.rlo = 0; ownP.qhi = 0; ownP.rhi = 0;  // prefix: never counted
  u32 mism = 0, gr = 0;
  const int wi = worker_index(tid), lane = tid & 31;
  if (!midT && !midP) {  // every block except the one holding the middle: fast path only
    // Warp-uniform trip count (shuffles need the whole warp): lane holds item b + wi; lanes past
    // the end recompute the last item without storing. Views recomputed per item from scalars.
    for (int b = 0; b < items; b += nw) {
      int i = b + wi;
      const bool act = i < items;
      if (!act) i = items - 1;
#if defined(TB_CHECK_GROWTH) && !defined(__CUDA_ARCH__)
      if (lane >= 1 && worker_index(tid - 1) != wi - 1) { fprintf(stderr, "worker mapping not contiguous\n"); abort(); }
#endif
      const bool pre = i < np;
      TV v;
      v.s = pre ? pre_buf(base, c, par) : tile_buf(base, c, par);
      v.stride = pre ? pstride(c) : tstride(c);
      v.Wt = pre ? S.plen : S.len;
      v.P0 = pre ? 0 : P0t;
      v.magic = pre ? S.magP : S.magT;
      Own ow;
      if (pre) { ow.qlo = 32; ow.rlo = 0; ow.qhi = 0; ow.rhi = 0; }
      else ow = own_of(v, plo - P0t, phi - P0t);
      TB_COUNT(g_fast);
      const u32 r = chunk_step<false, true>(v, pre ? pre_buf(base, c, par ^ 1) : tile_buf(base, c, par ^ 1), n, g,
                                            C * (pre ? i : i - np), ow, lane, act);
      if (act) {
        mism |= r & 1u;
        if (i == 0) gr = r;
      }
    }
  } else
  for (int i = wi; i < items; i += nw) {  // the block holding the middle: no shuffles
    const bool pre = i < np;
    TV v;  // selected by value (a reference to one of two locals would force local memory)
    v.s = pre ? vp.s : vt.s; v.stride = pre ? vp.stride : vt.stride; v.Wt = pre ? vp.Wt : vt.Wt;
    v.P0 = pre ? vp.P0 : vt.P0; v.magic = pre ? vp.magic : vt.magic;
    u32* d = pre ? pd : td;
    const int u0 = C * (pre ? i : i - np);
    Own ow;
    ow.qlo = pre ? ownP.qlo : ownT.qlo; ow.rlo = pre ? ownP.rlo : ownT.rlo;
    ow.qhi = pre ? ownP.qhi : ownT.qhi; ow.rhi = pre ? ownP.rhi : ownT.rhi;
    u32 r;
    if (pre ? midP : midT) { TB_COUNT(g_mid); r = chunk_step<true, false>(v, d, n, g, u0, ow, lane, true); }
    else { TB_COUNT(g_fast); r = chunk_step<false, false>(v, d, n, g, u0, ow, lane, true); }
    mism |= r & 1u;
    if (i == 0) gr = r;
  }
  if (tid == 0) {
    int gn, q;
    if (gr & 2u) {  // determined from thread 0's own registers (first non-9 pair among pairs 0..C-1)
      gn = (int)((gr >> 2) & 1u);
      q = (int)(gr >> 3) - 1;
    } else {        // pairs 0..C-1 all sum to 9 (~1e-8 per step): undetermined. growth_ok rejects
      gn = 0;       // Q_UNKNOWN at the next step, the block fails and the window replays exactly.
      q = Q_UNKNOWN;
    }
#if defined(TB_CHECK_GROWTH) && !defined(__CUDA_ARCH__)
    if (gr & 2u) {
      int g2;
      const int q2 = growth_find(pre_view(S, base, c, par ^ 1), n + g, &g2);
      if (q2 != q || g2 != gn) { fprintf(stderr, "growth mismatch t=%d q=%d/%d g=%d/%d\n", t, q, q2, gn, g2); abort(); }
      ++g_growth_checks;
    }
#endif
    S.gq[(t + 1) & 1] = q;
    S.gS[t + 1] = gn;
  }
  return mism;
}
// After K steps (thread 0): certification verdict for the owned pairs.
BHD int ph_verdict(const State& S, int nK) {
  const int hK = (nK + 1) / 2;
  long long phl = 32LL * S.o1w;
  const int phi = phl < hK ? (int)phl : hK;
  return S.okT && S.okP && S.tr.L <= 32 * S.o0w && S.tr.R >= phi;
}
// Phase 5b (all threads): owned natural words (staging, parity f^1) -> global.
BHD void ph_store_global(const State& S, const Conf& c, u32* base, u32* dst, int f, int tid, int nth) {
  const u32* st = tile_buf(base, c, f ^ 1);
  const int ts = tstride(c), L32 = S.len / 32;
  const int a = S.o0w - S.bw, nwd = S.o1w - S.o0w;
  for (int i = tid; i < 5 * nwd; i += nth) {
    const int q = i / nwd, w = a + (i - q * nwd), k = w / L32, m = w - k * L32;
    dst[(size_t)q * c.Wcap + S.bw + w] = st[q * ts + k * S.ssT + m];
  }
}

}  // namespace tb
