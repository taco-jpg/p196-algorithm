# Task for the local agent (RTX 4050): v7 transposed engine

Production runs v6r2. v7 is a new time-blocked engine: the kernel's inner arithmetic is rewritten.
Everything around it is unchanged: driver, run mode, checkpoints, certification, replay, the v4
per-step verification kernel.
Results must be bit-identical to v6r2.

**The GPU is busy with production.** Benchmarks taken while it runs are invalid, and the gate would slow
production. Pause it the way you did for v6r2 (`search/STOP`; it finishes the current million-step chunk
and saves). Resume afterwards from `latest.json`, exactly as before.

## What changed and why (details in README.md)
- **Transposed tiles.** Carry chains become one 3-input logic op per word for 32 lanes at once.
  Common-path SASS per word, measured here with clang + ptxas: **33 / 48** instructions (no-growth /
  growth step) vs **76 / 100** for v6r2.
- **8-word chunks per thread.** Neighbour words come by warp shuffle, so there is still one barrier per step.
- **Swizzled shared-memory layout.** 128-bit accesses are conflict-free. Estimated ~12 shared-memory
  wavefronts per word vs ~20 for v6r2.
- **Faster certification tracker.** Three independent probes, with the exact v5 loop as fallback.
- **Default block 192 threads.** 159 registers, 0 spills (clang build; your nvcc build may differ;
  `resources` reports it).
- **New measurement:** `sm_clock_mhz` in every bench line and `sm_clock_mhz_last_chunk` in run-mode
  `latest.json`. It is the sustained SM clock, measured inside the kernel (block 0's cycle counter vs the
  GPU's ns timer). It answers the 1,605 MHz question from the v6r2 profile without NVML.

## Correctness work done before handing over (CPU emulator runs the same kernel code)
- Python model of the chunk algorithm: exact against big integers on 1,900 cases.
- Exactness suite ALL PASS in step, tb, tiny tile, two forced-failure configurations and
  tile=64/K=1000. It ran on a self-check build that aborts on any register-derived growth bit that
  differs from the shared-memory search, or any non-uniform owned-pair mask on the fast path.
  192, 128, 256 and 512 threads per block all pass.
- Soundness checker: 0 violations in 6 mixed configurations. The certified/failed block counts are
  identical to v6r2's.
- Differential vs v6r2 120/120 identical, vs v5 100/100. A 10M-digit random number with planted 9-runs
  at 4 K/tile settings == reference.
- Growth edge cases: exact, and they trigger the intended replays.
- Unit tests: 32×32 transpose, a lane-by-lane simulation of the GPU shuffle transpose, the fast division
  for every tile width, the mask functions.
- A real bug was found and fixed along the way. An early draft computed the growth bit from words other
  threads were still writing; it was silently wrong in 12 of 78 edge cases. The edge-case test exists
  for it and is part of the gate.
- **Not yet run on a GPU.** The shuffle mechanics only run on the GPU, so the GPU gate is the check for them.

## Steps
1. `./bench_v7.sh build` then `./bench_v7.sh resources`.
2. `./bench_v7.sh gate`: unit tests; 6 GPU suite configurations; 4 build variants × 2 configurations;
   v6r2-vs-v7 differential (100 random); growth edge cases; every binary + emulator vs reference at
   +2,000. **All must PASS.** Your persistent test harness is fine for the suite.
3. `./bench_v7.sh big <COPY of the newest production checkpoint> <its iteration>`: v6r2 (K=128,
   tile=736, the production setting) vs v7 at the auto tile and at 736, GPU events, 3 interleaved runs, plus phase
   profiles and the SM clock. **This is the deciding number.** `TILE7="0 736 992"` sets the v7 tiles.
4. `./bench_v7.sh sweep <COPY> <iteration>`: 3 builds × K∈{128,256,512} × 6 tiles. Report the best
   `device_us_per_step` (PASS, replays=0) and the clock column.
5. `./bench_v7.sh small` and `./bench_v7.sh runmode`.
6. Send back `bench/summary.txt` and `bench/log.txt`.

## Deciding
- Switch production to v7 only if step 2 passes completely **and** v7 is faster than v6r2 at the
  production size (median of 3, GPU events, same input), and only with the user's go-ahead (as for v6r2).
  Use the best K/tile from the sweep. Keep the v6r2 binary for rollback.
- If v7 is slower or anything fails: keep v6r2 and report the profile lines. They show whether the
  workers, the tracker (warp 1) or the barrier limit the step.
- In production, the `replays` count should stay near zero. The new "undetermined growth" path costs one
  window replay roughly every 10⁸ steps; report it if replays are much more frequent.

## Rules
- Benchmarks only on a copy of a checkpoint, never the live file.
- Every step's palindrome status is checked; certification failures replay.
- Measured numbers only.
