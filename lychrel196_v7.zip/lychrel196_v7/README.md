# 196 reverse-and-add v7: transposed tiles

```bash
nvcc -O3 -std=c++17 -arch=sm_89 cuda196_v7.cu -o cuda196_v7
./cuda196_v7 checkpoint_4942464.txt 20000 out.txt 4942464 256                   # benchmark (same CLI)
./cuda196_v7 run <checkpoint> <iteration> run_v7 --chunk=1000000 --keep=3        # long search
```

Same exact arithmetic, command line, checkpoint format and `latest.json` fields as v5–v6r2, plus a new
field `sm_clock_mhz_last_chunk` (and `sm_clock_mhz=` in bench output). It is the sustained SM clock,
measured inside the kernel without NVML.

## What changed (the time-blocked engine is new; everything around it is v6r2)

**1. Transposed tiles.** A tile of `Wt` words holds pairs `[P0, P0+32·Wt)`. Word `u`, bit `k` holds
pair `P0 + k·Wt + u`, so each of the 32 lanes is a contiguous run of `Wt` pairs. The carry recurrences
`a_{j+1} = G_j | P_j·a_j` and `b_{j-1} = G_j | P_j·b_j` then run along the word index, with one 3-input
logic op per word for all 32 lanes at once. There are no 64-bit adds and no bit reversals. The
neighbour values `a_{j+1}`, `b_{j-1}` and the growth shift `hi_{j-1}` are just the neighbouring words.

**2. Chunks of 8 words per thread, one barrier per step.** A thread finds its carry-ins in the stable
current state: the four words below and above its chunk. Those words sit in the neighbouring lanes'
registers and arrive by warp shuffle. A rare loop continues while some lane is still inside a run of
pair-sum 9. Scans that run off a lane continue in the neighbouring lane; off the tile they see zeros,
which are the v5/v6 tile semantics.

**3. Bank-conflict-free shared memory.** Word `u` is stored at `u ^ ((u>>3)&4)`, so the 128-bit loads and
stores of any 8 consecutive threads hit 8 different bank groups. Estimated shared-memory traffic:
~12 wavefronts per word, against ~20 for v6r2.

**4. Middle tile.** The block holding pair `h` (one per launch) runs the same code with masks: pairs
≥ h generate the middle carry, outputs beyond the new `h` are zeroed, and in growth steps with even n
the centre pair takes `2·hi_{h-1}`.

**5. Natural layout in global memory.** Each block stages its words and transposes 32×32 bit blocks
(5 warp-shuffle stages; the emulator runs the same stages on arrays) once per launch in each direction.

**6. Faster certification tracker.** Three independent first probes. If one hits a 9 or an edge case,
it falls back to the exact v5 loop, which is ~15% of steps.

**7. Growth bit from thread 0's own registers only.** In a transposed tile, pairs 0..127 run along
lane 0 across many threads' words, so thread 0 must not read them during the step. If the new number's
first 8 pairs all sum to 9 (~1 in 10⁸ steps), the bit is "undetermined". The tracker then rejects it,
the block fails and the window replays exactly with the per-step kernel. An early v7 draft read those
words and could compute a wrong growth bit silently; `tests/test_growth_edge.py` catches that draft,
and passes on this code, on v6r2 and on v5.

## Measured before handing over (no NVIDIA GPU here; clang + ptxas 12.x for sm_89, CPU emulator)

| common-path SASS instructions per word | no-growth step | growth step |
|---|---:|---:|
| v6r2 fast group (4 words) | 76 | 100 |
| v7 chunk (8 words, shuffle path) | 33 | 48 |

- tb_kernel: 159 registers, 0 spills, 0 stack at the default 192 threads per block.
- The 256- and 512-thread builds spill at the 128-register cap (128 bytes). They are included only for the sweep, along with
  256 + MINBLOCKS=1 (181 registers, no spills).
- **Not yet run on a GPU.** Instruction counts are not speed. My last three estimates came in low: v6
  was slower, v6r was 1.48× where I estimated up to 2×, and v6r2 was 1.10× where I estimated 1.3–1.5×.
  For v7 my estimate is **1.2–1.6× over v6r2 at 28M+ digits**; the profile will show what limits it.

## Files

| file | purpose |
|---|---|
| `cuda196_v7.cu` | CUDA backend: v4 per-step kernel (verification/replay), v7 time-blocked kernel, SM clock |
| `emu196_v7.cpp` | CPU emulator, same kernel code (`EMU_CERTCHECK=1` soundness; `-DTB_CHECK_GROWTH` self-checks) |
| `bits_core.h` | v4 per-step arithmetic (GPU-validated, unchanged) |
| `bits_tb7.h` | v7 engine: transposes, chunk step, carries, tracking, phases |
| `driver7.h` | bench mode, run mode, verification windows, replay, timing, clock report |
| `prof.h` | `-DTB_PROF` phase profiler, `-DTB_WORK_REPEAT=2` ablation |
| `bench_v7.sh` | `build`, `resources`, `gate`, `big`, `small`, `sweep`, `runmode` |
| `tests/test_exact.py` | exactness suite (`ENGINE_FLAGS` passes options) |
| `tests/diff_engines.py` | differential test between two engines |
| `tests/test_growth_edge.py` | numbers whose next iterate starts with many pair-sum-9 pairs |
| `tests/unit_v7.cpp` | transpose (incl. a simulation of the shuffle algorithm), fast division, masks |
| `math/v7_proto.py` | Python model of the chunk algorithm, exact vs big integers |
| `baseline_v6r2/` | the production engine, for A/B |
| `tools/ref.c` | independent schoolbook reference |
