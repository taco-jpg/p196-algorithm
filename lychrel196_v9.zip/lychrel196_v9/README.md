# 196 reverse-and-add v9: warp windows, pipe balancing, per-window mod-9 fingerprint

```bash
nvcc -O3 -std=c++17 -arch=sm_89 cuda196_v9.cu -o cuda196_v9                     # default build
./cuda196_v9 run <checkpoint> <iteration> search --chunk=1000000 --keep=3 --K=128 --tile=940
nvcc ... -DTB_THREADS=512 -DTB_PIPEBAL=1 ...  # options, see below (512 threads: --tile up to 1900)
```

Same arithmetic, certification, replay, command line, checkpoint format and `latest.json` fields as
v8b (engine field `cuda196_v9`; bench lines add `pipebal=`, `fp=` and `fp_replays=`). Results are
byte-identical. Includes everything in v8b (64-bit digit counts up to ~4.29e9 digits, ISF, mod-9 and
cross-check tools), so v9 can replace v8b for the November digit-limit switch.

## What changes

**1. Warp windows (the main change).** The v8 profile showed the ALU pipe 86% busy, with 74.5 ALU
instructions per 32-pair word per step. About a third of that was v8's halo: every thread computed
6 words to keep 4. In v9 the 32 lanes of a warp share one window:

- lane l holds group 30w + l − 1 (4 words). Lanes 1..30 are kept; lanes 0 and 31 hold the
  neighbouring warps' edge groups as a 128-pair halo on each side. 32 groups computed per 30 kept,
  instead of 6 words per 4.
- the only data that cross a lane boundary each step are two carry bits (the low carry chain going
  up, the high chain going down) and, in growth steps, the 4 digit planes of the boundary pair. They
  move by warp shuffle, which runs on a different unit from the integer ALU.
- a carry bit computed from the sending lane's edge word alone is exact unless that whole word is
  pair-sum 9 (all 32 pairs). Then, and only then (~1e-32 per word; planted in the tests), the warp
  resolves every lane's carry-in with an exact sequential scan.
- certification: one interval per warp, the same track_step rule v8 used per thread, with unknown
  carries at the window edges taken as 0 (outside the interval). Windows that lose coverage of an
  owned group fail and replay exactly, as before.
- the halo is now 128 pairs, so windows can be long: default `TB_J=32` (4 barriers per 128-step
  launch). v8 needed J=8 because its halo was 32 pairs.
- tile limit = 30 groups per warp: 940 words at 256 threads, 1060 at 288, 1900 at 512. Larger tiles
  print a warning and run the slower v6r3 path.

**2. Pipe balancing (`-DTB_PIPEBAL=1`).** Shifts and small adds become multiply-adds, which run on the
FMA pipe (5.6% busy in the v8 profile): `(a >> 1) | (t << 31)` = `t·2^31 + mulhi(a, 2^31)`, etc. The
multipliers come from the launch configuration so the compiler cannot turn them back into shifts.
The 64-bit carry-chain adds stay on the ALU: ptxas splits a 64-bit multiply-add into a multiply plus
the same adds (checked in the SASS), so moving them only added instructions.

**3. mod-9 fingerprint per window (`--fp=1`, default).** For every number, x + rev(x) ≡ 2x (mod 9).
So after m steps the state must satisfy E' = 2^m·E (mod 9), with E = 2·ΣS_j − [n odd]·S_mid computed
on the GPU from the pair sums (one pass over the state per 8,192-step window, ~1 ms at 360M digits).
Any single flipped bit changes E. A mismatch after a time-blocked window replays it exactly from the
backup, like a certification failure; a mismatch after the per-step reference kernel stops the run
(a hardware fault). This matters because the laptop GPU has no ECC memory.

**4. The emulator runs the GPU's lane code.** The CPU emulator executes the 32 lanes of each warp as
cooperating fibers (`warp_ops.h`): every shuffle or vote switches lanes, and the result is computed
as CUDA defines it. So the tests exercise the kernel's own per-lane code, including the shuffles.
Build it with `-fcf-protection=none` (x86-64 only).

## Instruction counts (compiled here with clang + ptxas for sm_89; static counts, not measured)

One step of one thread/lane (4 words), common path, same compiler for both:

| | v8b hybrid thread (6 words, keeps 4) | v9 warp lane (4 words) |
|---|---:|---:|
| no-growth step, all instructions | 449 | 287 |
| no-growth step, ALU-pipe instructions | ~384 | ~225 |
| growth step, all instructions | 534 | 346 |
| growth step, ALU-pipe instructions | ~468 | ~288 |

With 30 of 32 lanes kept, that is roughly 1.45–1.6× fewer ALU instructions per useful word. Both
columns include some rarely executed code (tracker continuations; the shuffle fallback for diverged
warps), so the GPU's executed counts will differ. Options, same method:

- `TB_PIPEBAL`: ALU −8 (no growth) / −24 (growth) per lane-step, FMA +6 / +39.
- `TB_QUINARY` (base-5): no-growth 277 vs 287, but growth 420 vs 346. In v9's compiled code base-5
  is about 8% worse on average. It stays as an option because the A/B is cheap; expect it to lose.

## Checked here (CPU emulator with the GPU's lane code; clang + ptxas for sm_89)

- **Hybrid cross-check builds** (every certified hybrid block recomputed through the v6r3 path; owned
  words and per-step mismatch bits must be identical): the 2.05M checkpoint +2000 steps at tile 940
  (256 threads), 900 (base-5), 1060 (288 threads + base-5 + J=12), 1900 (512 threads), J=8 and J=1:
  all identical, 240–832 hybrid blocks each, output == reference. Quiet-region inputs: 6,956 blocks,
  118,766 quiet block-steps identical, in every build.
- **Stress** (soundness checker on: every certified block equals the per-step result): planted 9-runs:
  8/8; halo 4 words (forces tile-edge failures): 10/10 with 817 failed and replayed hybrid blocks;
  9-runs up to 400 pairs (longer than the 128-pair halo): 10/10 with 128 failures; 0 violations
  everywhere. The rare exact carry scan ran (25 times in one stress input) and matched the v6r3 path.
- Exactness suite ALL PASS in 9 configurations (incl. `--hybrid=0`, `--fp=0`, forced failures, tile
  940) and for the base-5 and 512-thread builds. Differential vs v8b: 60/60, 40/40, 40/40 identical.
  Growth edge cases 93/93, palindromes inside windows exact.
- **Fingerprint**: a bit flipped after launch 1, 3, 9 or 16 was caught every time (fp_replays=1) and
  the output equalled the reference; with `--fp=0` the same flip produced a wrong result.
- **64-bit, end to end:** the random 2,147,483,600-digit number, 250 steps (crossing 2^31 digits),
  default build at tile 940: identical to the schoolbook reference, 71,390 hybrid blocks, 0 replays,
  fingerprint consistent across the 2^31 line.
- `bench_v9.sh` itself ran end to end here (build, gate, runmode, a short ab) with the emulator
  standing in for nvcc's binaries. Everything passed except the two "GPU, flip after launch" lines,
  which need the real CUDA binary (the emulator reads `EMU_FAULT`, not `V9_FAULT`).
- Compiled for sm_89 (clang + ptxas): 128 registers for 256/512 threads; the warp-window step loop has
  no local-memory instructions in any build. 288/320 threads get 96 registers; the spills are in the
  v6r3 path only, as in v8b.
- **Not run here**: nothing on a GPU (no NVIDIA GPU in this workspace), and not nvcc (clang compiled
  the same source). The gate runs both.

## Expected speed (honest)

If the kernel stays ALU-bound at the same clock, 1.45–1.6× fewer ALU instructions would mean up to
~1.4× faster. Two things will take part of it: the 35 W cap, and the shuffle latency on each step's
critical path. My guess is **+10–35% over v8 at the same tile**, most likely around +20%. Pipe
balancing: maybe +0–5%. 512 threads with tile 1900: unknown, because the tiles are twice as wide but
there is only one block per SM. Base-5: likely slower. The A/B decides.

## Files

| file | purpose |
|---|---|
| `cuda196_v9.cu`, `emu196_v9.cpp` | CUDA backend / CPU emulator (same kernel code) |
| `bits_tb9.h` | engine: v8b + warp windows (`wy_window`, `wy_track`, `wy_resolve`), pipe balancing |
| `warp_ops.h` | warp primitives: CUDA intrinsics, and the emulator's 32-fiber warps |
| `bits_core.h`, `driver9.h` | v4 per-step arithmetic; host driver + mod-9 fingerprint |
| `bench_v9.sh` | `build`, `resources`, `gate`, `big64`, `ab`, `sustained`, `runmode` |
| `tools/` | schoolbook reference, ISF writer, mod-9 identity, weekly cross-check, SASS loop check |
| `tests/` | exactness, differential, hybrid stress (`ENGINE_FLAGS`, `STRESS_LONG=1`), quiet regions, palindromes in windows, growth edges, base-5 unit test |
| `baseline_v8/`, `baseline_v8b/` | the production engine and v8b, for A/B |
