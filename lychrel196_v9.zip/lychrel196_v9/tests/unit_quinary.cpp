// Exhaustive check of the v8b base-5 pair-sum arithmetic against plain integers.
// Every lane of a 32-bit word is an independent case, so each call checks 32 combinations.
#include <cstdio>
#include <cstdlib>
#include <vector>
#include "bits_tb9.h"
using bits::u32;
static int S_of(const u32 p[5], int lane) { int v = 0; for (int q = 0; q < 5; ++q) v |= (int)((p[q] >> lane) & 1u) << q; return v; }
static void set_lane(u32 p[5], int lane, int S) { for (int q = 0; q < 5; ++q) p[q] = (p[q] & ~(1u << lane)) | ((u32)((S >> q) & 1) << lane); }
static int d(int S, int c) { return (S + c) % 10; }
int main() {
  long long checked = 0, bad = 0;
  // 1. conversions: every S in 0..18, round trip and the quinary fields
  for (int S = 0; S <= 18; ++S) {
    u32 p[5] = {0, 0, 0, 0, 0};
    for (int l = 0; l < 32; ++l) set_lane(p, l, S);
    u32 q[5] = {p[0], p[1], p[2], p[3], p[4]};
    tb::bin2quin(q);
    const int M = (int)(q[0] & 1) | (int)(q[1] & 1) << 1 | (int)(q[2] & 1) << 2, H = q[3] & 1, G = q[4] & 1;
    if (M != S % 5 || H != (S / 5) % 2 || G != S / 10 || (int)((q[3] & q[2]) & 1) != (S == 9)) { ++bad; printf("bin2quin S=%d\n", S); }
    tb::quin2bin(q);
    for (int k = 0; k < 5; ++k) if (q[k] != p[k]) { ++bad; printf("roundtrip S=%d\n", S); break; }
    ++checked;
  }
  // 2. no-growth update: all (S, a, b)
  std::vector<int> cs;
  for (int S = 0; S <= 18; ++S) for (int a = 0; a < 2; ++a) for (int b = 0; b < 2; ++b) cs.push_back(S * 4 + a * 2 + b);
  for (size_t i0 = 0; i0 < cs.size(); i0 += 32) {
    u32 p[5] = {0, 0, 0, 0, 0}; u32 A = 0, B = 0; int n = 0;
    for (int l = 0; l < 32 && i0 + l < cs.size(); ++l, ++n) {
      const int c = cs[i0 + l]; set_lane(p, l, c / 4); A |= (u32)((c >> 1) & 1) << l; B |= (u32)(c & 1) << l;
    }
    tb::bin2quin(p);
    const u32 dw = tb::quin_ng(p, A, B);
    tb::quin2bin(p);
    for (int l = 0; l < n; ++l) {
      const int c = cs[i0 + l], S = c / 4, a = (c >> 1) & 1, b = c & 1;
      const int want = d(S, a) + d(S, b), got = S_of(p, l);
      const int wd = d(S, a) != d(S, b), gd = (int)((dw >> l) & 1u);
      if (want != got || wd != gd) { ++bad; printf("ng S=%d a=%d b=%d want %d/%d got %d/%d\n", S, a, b, want, wd, got, gd); }
      ++checked;
    }
  }
  // 3. growth update: all (Sx, Sy, a, b)
  cs.clear();
  for (int Sx = 0; Sx <= 18; ++Sx) for (int Sy = 0; Sy <= 18; ++Sy) for (int a = 0; a < 2; ++a) for (int b = 0; b < 2; ++b)
    cs.push_back(((Sx * 19 + Sy) * 2 + a) * 2 + b);
  for (size_t i0 = 0; i0 < cs.size(); i0 += 32) {
    u32 px[5] = {0, 0, 0, 0, 0}, py[5] = {0, 0, 0, 0, 0}; u32 A = 0, B = 0; int n = 0;
    for (int l = 0; l < 32 && i0 + l < cs.size(); ++l, ++n) {
      const int c = cs[i0 + l], b = c & 1, a = (c >> 1) & 1, Sy = (c >> 2) % 19, Sx = (c >> 2) / 19;
      set_lane(px, l, Sx); set_lane(py, l, Sy); A |= (u32)a << l; B |= (u32)b << l;
    }
    tb::bin2quin(px); tb::bin2quin(py);
    const u32 dw = tb::quin_g(px, A, B, py[0], py[1], py[2], py[3]);
    tb::quin2bin(px);
    for (int l = 0; l < n; ++l) {
      const int c = cs[i0 + l], b = c & 1, a = (c >> 1) & 1, Sy = (c >> 2) % 19, Sx = (c >> 2) / 19;
      const int want = d(Sx, a) + d(Sy, b), got = S_of(px, l);
      const int wd = d(Sx, a) != d(Sy, b), gd = (int)((dw >> l) & 1u);
      if (want != got || wd != gd) { ++bad; if (bad < 20) printf("g Sx=%d Sy=%d a=%d b=%d want %d/%d got %d/%d\n", Sx, Sy, a, b, want, wd, got, gd); }
      ++checked;
    }
  }
  printf("unit_quinary: %lld cases, %lld mismatches: %s\n", checked, bad, bad ? "FAIL" : "PASS");
  return bad ? 1 : 0;
}
