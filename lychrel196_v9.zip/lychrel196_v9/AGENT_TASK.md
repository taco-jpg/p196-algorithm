# Task for the local agent (RTX 4050): v9 (warp windows, pipe balancing, mod-9 fingerprint)

Production runs v8 (K=128, tile 1000). **Do this after the milestone comparison report**, unless
the user says otherwise. v9 contains everything in v8b (64-bit digit counts, ISF, mod-9 and
cross-check tools), so if v9 passes it can replace v8b for the switch that must happen before about
November 15. If both packages are on hand, run this one first; fall back to v8b if v9 fails its gate.
Results must be byte-identical to v8.

Pause with `search/STOP` (finishes the current chunk) for anything that uses the GPU, resume from
`latest.json`, confirm the service runs again. One GPU job at a time. The CPU-only parts (emulator
checks, the big64 CPU reference) can run while production runs, if the user agrees.

## What changes (README.md has the details)
- **Warp windows:** the 32 lanes of a warp share one register window and pass the two carry bits
  that cross each lane boundary by shuffle. 32 groups are computed per 30 kept (v8: 6 words per 4).
  Windows run 32 steps per barrier (the halo is 128 pairs now). Tile limit: 940 at 256 threads,
  1060 at 288, 1900 at 512.
- **Pipe balancing** (option): some shifts and adds run as multiply-adds on the idle FMA pipe.
- **mod-9 fingerprint** every 8,192-step window: a flipped bit makes the window replay exactly. A
  mismatch in the per-step reference kernel stops the run (hardware fault).
- Build options are separate binaries, so the A/B measures each one.

## Steps
1. `./bench_v9.sh build`, then `./bench_v9.sh resources`. Report the lines. Every v9 binary must
   show `STL/LDL in loop=0` for the warp-window loop.
2. `./bench_v9.sh gate`. **Everything must PASS**, including the 4 fingerprint lines (an injected bit
   flip must be caught, on the emulator and on the GPU).
3. `./bench_v9.sh big64`: a 2,147,483,600-digit number, 250 steps. If the v8b run already built the
   reference, reuse it: `BIGDIR=<v8b package>/bench/big64 ./bench_v9.sh big64`.
4. `./bench_v9.sh ab <COPY of the newest checkpoint> <its iteration>`: v8:1000 (production) vs v8b
   and the v9 builds at their largest tiles (v9:940/900, v9pb, v9j16, v9q, v9t288:1060,
   v9t512:1900, v9t512pb:1900). 5,000 steps, 3 interleaved rounds, power and energy. **Replays must
   be 0** for a configuration to count.
5. Best configuration (median, replays 0) vs production: `./bench_v9.sh sustained <COPY> <iter> <cfg>`.
6. `./bench_v9.sh runmode`. Resume production, confirm it runs. Send back `bench/summary.txt`,
   `bench/ab.tsv`, `bench/log.txt`.

## Deciding (the user's call)
- Switch to the fastest v9 configuration that is ≥ 5% faster sustained, with 0 replays and identical
  output, at a chunk boundary, resuming from `latest.json`, keeping the milestone/stop settings. Keep
  v8 for rollback.
- If no v9 configuration qualifies, switch to v8b as planned (required before ~November 15).

## In production on v9
- `fp_replays` should stay 0. Any fingerprint replay means a state bit changed without the code
  changing it: report it with the iteration and keep the run going (the replay fixed that window).
- If the run stops with "mod-9 fingerprint mismatch in the per-step kernel": do not restart blindly.
  Report it, restore from the last archive whose cross-check passed, and run `tools/crosscheck.sh`.
- Keep the v8b routines: ISF dumps at milestones, `bench/mod9` on every archive, the weekly
  cross-check (`tools/crosscheck.sh ./cuda196_v9 ...`).

## Rules
- Benchmarks only on a copy of a checkpoint, never the live file.
- Every step's palindrome status is checked; certification failures replay.
- Measured numbers only.
