# Task for the local agent (RTX 4050, CUDA)

Goal: decide **with measurements** whether the bit-sliced engine (`cuda196_bits.cu`) is
faster than the previous zip's kernel (`baseline/main_old.cu`) and than the user's existing
production CUDA build (0.828 s / 20,000 steps from the same checkpoint), **without losing exactness**.
Do not exaggerate. If the new engine is not faster, say so and keep the old one in production.

What has been verified before handing over (no NVIDIA GPU was available):
- `bits_core.h` (the GPU arithmetic) runs unchanged inside the CPU emulator `emu196_bits`, which
  matches an independent reference: 196 for 30,000 steps (odd batch 37), the 2,046,548-digit
  checkpoint +2,000 steps, 2,000 tiny inputs, 300 adversarial runs of 9s across word boundaries,
  delayed palindromes (24 / 55 / 261 steps), checkpoint naming with odd batches.
- `cuda196_bits.cu` compiles for sm_89 (clang + ptxas: 60 registers, no spills).
  **It has never been executed on a GPU.** Treat the first GPU run as untrusted until step 3 passes.

## Steps

1. Build
   ```bash
   nvcc -O3 -std=c++17 -arch=sm_89 cuda196_bits.cu -o cuda196_bits
   g++ -O3 -march=native -fopenmp -std=c++17 emu196_bits.cpp -o emu196_bits
   ```
   Fix any nvcc-specific compile issue without changing the arithmetic in `bits_core.h`.

2. CPU emulator sanity (should print ALL PASS):
   `python3 tests/test_exact.py ./emu196_bits`

3. GPU exactness (must print ALL PASS before any timing is trusted):
   `python3 tests/test_exact.py ./cuda196_bits`
   then: `./cuda196_bits checkpoint_4942464.txt 2000 g2000.txt 4942464 64` and
   `./emu196_bits  checkpoint_4942464.txt 2000 e2000.txt 4942464 64` → `cmp g2000.txt e2000.txt`.

4. Head-to-head benchmark (same checkpoint, 20,000 steps, 3 runs, medians, outputs checked against
   an independent CPU reference): `./bench_vs_old.sh 20000 64 32`
   Also run the user's existing production build on the same 20,000 steps if it is on the machine
   and report all three medians. Sweep the new engine's batch: 16, 32, 64, 128, 256.

5. Report: median seconds for each engine, µs/step, speedup vs old zip and vs production,
   sha256 of the iteration-4,962,464 output, and whether every output matched the reference.

6. Only after 3–5 pass: long run with checkpoints every 20,000 steps:
   `python3 run_forever.py --input checkpoint_4942464.txt --start 4942464 --chunk 20000 --batch 64 --engine ./cuda196_bits --output-dir run`

## Optional optimisations (each must re-pass step 3 and be A/B timed; keep only real wins)

- Each thread recomputes the growth bit `g` by scanning word 0 (cheap, cached). Computing it once per
  block into shared memory may help slightly.
- Several words per thread (e.g. 4) to amortise neighbour loads; or warp-shuffle the neighbour planes.
- Expect the per-step cost to be dominated by launch/graph overhead (~32K threads of light work).
  The big next win is **time blocking**: one block keeps a tile of planes in shared memory and runs K
  steps (e.g. 64–256) before writing back. It is exact if the tile tracks its certified interval:
  after each step the valid range shrinks by one pair on each side plus any run of pair-sum 9 at the
  edge; the growth bits for all K steps are computable in advance from the outermost pairs only
  (a tiny pre-pass), and the block containing the middle uses the true middle boundary. If a block's
  certified range ever fails to cover the pairs it owns, discard and recompute that window with the
  per-step kernel. See README "Next level".
- Metal port for the M1 Max: `bits_core.h` maps almost 1:1 to MSL (`reverse_bits`, `ulong`).

## Rules
- Every step's palindrome flag must be checked (the driver does this; keep it).
- Never introduce a carry-scan cutoff; the scans in `bits_core.h` are unbounded on purpose.
- Report measured numbers only; label estimates as estimates.
