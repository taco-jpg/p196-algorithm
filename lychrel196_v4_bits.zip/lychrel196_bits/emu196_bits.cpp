// emu196_bits.cpp - CPU backend running the exact same bits::step_word as the
// CUDA kernel, word by word. Used to verify the GPU arithmetic without a GPU,
// and usable as a (slower) CPU engine. Build: g++ -O3 -march=native -fopenmp
#include <cstring>
#include "driver.h"
using bits::u32;

struct EmuBackend {
  std::vector<u32> s[2], bk;
  int n[2] = {0, 0}, nbk = 0, cur = 0, Wcap = 0;
  const char* name() { return "cpu-emulator(bits_core.h)"; }
  void init(const std::vector<u32>& pl, int n0, int W, int) {
    Wcap = W; s[0] = pl; s[1].assign(pl.size(), 0); n[0] = n0; n[1] = n0; cur = 0;
  }
  void run(int count, std::vector<unsigned>& bad) {
    bad.assign(count, 0);
    for (int i = 0; i < count; ++i) {
      const u32* src = s[cur].data();
      u32* dst = s[1 - cur].data();
      const int nn = n[cur];
      int g0 = 0;
      unsigned any = 0;
      // every word is independent given src (same as one CUDA thread per word)
#pragma omp parallel for reduction(| : any) schedule(static)
      for (int w = 0; w < Wcap; ++w) {
        int g = 0;
        if (32LL * w > (nn + 2) / 2 + 32) continue;  // same skip as the CUDA kernel
        any |= bits::step_word(src, dst, Wcap, nn, w, &g);
        if (w == 0) g0 = g;
      }
      bad[i] = any;
      n[1 - cur] = nn + g0;
      cur = 1 - cur;
    }
  }
  void backup() { bk = s[cur]; nbk = n[cur]; }
  void restore() { s[cur] = bk; n[cur] = nbk; }
  void download(bool previous, std::vector<u32>& pl, int& nn) {
    int k = previous ? 1 - cur : cur;
    pl = s[k]; nn = n[k];
  }
};

int main(int argc, char** argv) {
  try {
    EmuBackend be;
    return drv::run(be, argc, argv);
  } catch (const std::exception& e) {
    fprintf(stderr, "ERROR %s\n", e.what());
    return 2;
  }
}
