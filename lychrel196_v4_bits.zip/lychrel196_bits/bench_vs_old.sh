#!/usr/bin/env bash
# Head-to-head on the RTX 4050: old zip kernel (baseline/main_old.cu) vs bit-sliced kernel.
# Same checkpoint, same STEPS, 3 runs each, median wall time. Outputs must be byte-identical
# to each other AND to an independent CPU reference (tools/ref.c).
# usage: ./bench_vs_old.sh [STEPS=20000] [BATCH_NEW=64] [BATCH_OLD=32]
set -euo pipefail
STEPS=${1:-20000}; BN=${2:-64}; BO=${3:-32}
CK=checkpoint_4942464.txt; START=4942464; END=$((START+STEPS))
ARCH=${ARCH:-sm_89}
mkdir -p bench
nvcc -O3 -std=c++17 -arch=$ARCH cuda196_bits.cu -o cuda196_bits
nvcc -O3 -std=c++17 -arch=$ARCH baseline/main_old.cu -o bench/cuda196_old
gcc -O2 tools/ref.c -o bench/ref
if [ ! -f bench/ref_$END.txt ]; then
  echo "building CPU reference for $STEPS steps (single core, a few minutes)..."
  ./bench/ref $CK $STEPS bench/ref_$END.txt
fi
median() { sort -n | awk '{a[NR]=$1} END{print a[int((NR+1)/2)]}'; }
timeit() { local s e; s=$(date +%s.%N); "$@" 2>>bench/log.txt; e=$(date +%s.%N); echo "$e - $s" | bc; }
for eng in old new; do
  : > bench/t_$eng.txt
  for r in 1 2 3; do
    if [ $eng = old ]; then t=$(timeit ./bench/cuda196_old $CK $STEPS bench/out_old.txt $START $BO)
    else t=$(timeit ./cuda196_bits $CK $STEPS bench/out_new.txt $START $BN); fi
    echo "$t" >> bench/t_$eng.txt
  done
done
cmp bench/out_new.txt bench/ref_$END.txt && echo "new kernel output == CPU reference: PASS" || echo "new kernel output: MISMATCH"
cmp bench/out_old.txt bench/ref_$END.txt && echo "old kernel output == CPU reference: PASS" || echo "old kernel output: MISMATCH"
MO=$(median < bench/t_old.txt); MN=$(median < bench/t_new.txt)
echo "old (main_old.cu, batch $BO): median ${MO}s for $STEPS steps  -> $(echo "scale=2; 1000000*$MO/$STEPS" | bc) us/step"
echo "new (cuda196_bits, batch $BN): median ${MN}s for $STEPS steps -> $(echo "scale=2; 1000000*$MN/$STEPS" | bc) us/step"
echo "speedup old/new: $(echo "scale=2; $MO/$MN" | bc)x   (wall time incl. file I/O and startup)"
echo "sha256 new output: $(sha256sum bench/out_new.txt | cut -d' ' -f1)"
