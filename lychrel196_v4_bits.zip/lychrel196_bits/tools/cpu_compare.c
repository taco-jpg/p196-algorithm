// Head-to-head on one CPU core, same input, same steps:
//   zip : the per-pair kernel from main.cu (scan for nearest non-9), run as a loop over "threads"
//   bits: bit-sliced closed form (5 bit-planes, two big binary additions per step)
// usage: cmp CHECKPOINT STEPS OUT_ZIP OUT_BITS
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
typedef unsigned __int128 u128;
typedef uint64_t u64;
static double now(void) { struct timespec t; clock_gettime(CLOCK_MONOTONIC, &t); return t.tv_sec + t.tv_nsec * 1e-9; }

// ---------------- zip algorithm (main.cu step kernel, verbatim logic) ----------------
static inline int hd(int n) { return (n + 1) / 2; }
static int growth(const uint8_t* s, int n) { for (int i = 0; i < hd(n); i++) { int v = s[i]; if (v != 9) return v >= 10; } return 0; }
static int midcarry(const uint8_t* s, int n) { for (int i = hd(n) - 1; i >= 0; i--) { int v = s[i]; if (v != 9) return v >= 10; } return 0; }
static inline int lc(const uint8_t* s, int i) { for (int j = i - 1; j >= 0; j--) { int v = s[j]; if (v != 9) return v >= 10; } return 0; }
static inline int hc(const uint8_t* s, int n, int i, int mid) { for (int j = i + 1; j < n - hd(n); j++) { int v = s[j]; if (v != 9) return v >= 10; } return mid; }
static inline int dg(int x) { return x >= 10 ? x - 10 : x; }
static inline int low(const uint8_t* s, int i) { return dg(s[i] + lc(s, i)); }
static inline int high(const uint8_t* s, int n, int i, int mid) { return dg(s[i] + hc(s, n, i, mid)); }
static int zip_step(const uint8_t* src, uint8_t* dst, int n, int* bad) {
  int g = growth(src, n), m = midcarry(src, n), h = hd(n + g), any = 0;
  for (int tid = 0; tid < h; tid++) {
    int lo, hi, val, mis = 0;
    if (g) {
      if (tid == 0) { lo = low(src, 0); val = lo + 1; mis = lo != 1; }
      else if ((n % 2) == 0 && tid == hd(n)) { hi = high(src, n, hd(n) - 1, m); val = 2 * hi; }
      else { lo = low(src, tid); hi = high(src, n, tid - 1, m); val = lo + hi; mis = lo != hi; }
    } else {
      if ((n % 2) != 0 && tid == hd(n) - 1) { lo = low(src, tid); val = 2 * lo; }
      else { lo = low(src, tid); hi = high(src, n, tid, m); val = lo + hi; mis = lo != hi; }
    }
    dst[tid] = (uint8_t)val; any |= mis;
  }
  *bad = any;
  return n + g;
}

// ---------------- bit-sliced closed form ----------------
// S'_j = 2 S_j + a_j + b_j - 10 (a_{j+1} + b_{j-1})   (no growth)
// low carries a = carries of (G|P) + G ; high carries b = same, bit-reversed, from the middle.
static inline u64 rbit(u64 x) { return __builtin_bitreverse64(x); }
typedef struct { u64* p[5]; int n; int W; } Planes;
static u64 *G, *P, *A, *B, *T[8];
static inline u64 hmask(int k, int h) {  // bits of word k that are < h
  long lo = 64L * k;
  if (lo + 64 <= h) return ~0ULL;
  if (lo >= h) return 0;
  return (1ULL << (h - lo)) - 1;
}
static inline int bit(const u64* v, int j) { return (v[j >> 6] >> (j & 63)) & 1; }
// returns 1 if N_{t+1} is a palindrome
static int bits_step(Planes* S, Planes* D) {
  const int n = S->n, h = (n + 1) / 2, W = S->W;
  const int nw = (h + 1 + 63) / 64;  // words covering bits 0..h
  u64 **s = S->p, **d = D->p;
  for (int k = 0; k < nw; k++) {
    u64 s0 = s[0][k], s1 = s[1][k], s2 = s[2][k], s3 = s[3][k], s4 = s[4][k];
    G[k] = s4 | (s3 & (s2 | s1));
    P[k] = ~s4 & s3 & ~s2 & ~s1 & s0;
  }
  // low carries: one long binary addition, word by word
  u64 c = 0;
  for (int k = 0; k < nw; k++) {
    u64 x = G[k] | P[k];
    u128 t = (u128)x + G[k] + c;
    A[k] = (u64)t ^ x ^ G[k];
    c = (u64)(t >> 64);
  }
  const int ah = bit(A, h), ah1 = bit(A, h - 1);
  // high carries: same addition on bit-reversed words, from the middle outward
  c = (n % 2 == 0) ? ah : ah1;
  for (int k = nw - 1; k >= 0; k--) {
    u64 m = hmask(k, h);
    u64 x = (G[k] | P[k] | ~m), gk = G[k] & m;  // pairs >= h just pass the middle carry through
    u64 xr = rbit(x), gr = rbit(gk);
    u128 t = (u128)xr + gr + c;
    B[k] = rbit((u64)t ^ xr ^ gr);
    c = (u64)(t >> 64);
  }
  const int g = (int)c;  // carry out of the top digit
  int pal;
  if (!g) {
    u64 diff = 0, bprev = 0;
    D->n = n;
    for (int k = 0; k < nw; k++) {
      u64 m = hmask(k, h);
      u64 a = A[k] & m, b = B[k] & m;
      u64 aup = (A[k] >> 1) | (k + 1 < W ? A[k + 1] << 63 : 0);  // a_{j+1}
      u64 bdn = (b << 1) | bprev;                                // b_{j-1}, b_{-1} = g = 0
      bprev = b >> 63;
      diff |= a ^ b;
      // V = 2S + a + b  (6 bit-planes)
      u64 t0 = a ^ b, t1 = a & b;
      u64 v0 = t0;
      u64 v1 = s[0][k] ^ t1, cc = s[0][k] & t1;
      u64 v2 = s[1][k] ^ cc; cc &= s[1][k];
      u64 v3 = s[2][k] ^ cc; cc &= s[2][k];
      u64 v4 = s[3][k] ^ cc; cc &= s[3][k];
      u64 v5 = s[4][k] ^ cc;
      // subtract 10*k1 + 20*k2 : subtrahend bits (1,2,3,4) = (k1,k2,k1,k2)
      u64 k1 = (aup ^ bdn) & m, k2 = aup & bdn & m;
      u64 r1 = v1 ^ k1, bo = ~v1 & k1;
      u64 dd = v2 ^ k2, r2 = dd ^ bo; bo = (~v2 & k2) | (~dd & bo);
      dd = v3 ^ k1;  u64 r3 = dd ^ bo; bo = (~v3 & k1) | (~dd & bo);
      dd = v4 ^ k2;  u64 r4 = dd ^ bo; bo = (~v4 & k2) | (~dd & bo);
      u64 r5 = v5 ^ bo;  // result <= 18 so bit 5 cancels
      (void)r5;
      d[0][k] = v0 & m; d[1][k] = r1 & m; d[2][k] = r2 & m; d[3][k] = r3 & m; d[4][k] = r4 & m;
    }
    for (int k = nw; k < W; k++) for (int q = 0; q < 5; q++) d[q][k] = 0;
    pal = diff == 0;
  } else {
    // growth: S'_j = lo_j + hi_{j-1}, hi_{-1} = 1, and (n even) S'_h = 2 hi_{h-1}
    const int n1 = n + 1, h1 = (n1 + 1) / 2, nw1 = (h1 + 1 + 63) / 64;
    u64 *lo[4] = {T[0], T[1], T[2], T[3]}, *hi[4] = {T[4], T[5], T[6], T[7]};
    u64 bprev = 1;  // b_{-1} = g = 1
    for (int k = 0; k < nw1; k++) {
      u64 m = hmask(k, h);
      u64 a = A[k] & m, b = B[k] & m;
      u64 aup = (A[k] >> 1) | (k + 1 < W ? A[k + 1] << 63 : 0);
      u64 bdn = (b << 1) | bprev; bprev = b >> 63;
      u64 q[2] = {a, b}, sub[2] = {aup & m, bdn & m};
      for (int side = 0; side < 2; side++) {  // digit = S + carry_in - 10*carry_out
        u64 cc = q[side];
        u64 w0 = s[0][k] ^ cc; cc &= s[0][k];
        u64 w1 = s[1][k] ^ cc; cc &= s[1][k];
        u64 w2 = s[2][k] ^ cc; cc &= s[2][k];
        u64 w3 = s[3][k] ^ cc; cc &= s[3][k];
        u64 w4 = s[4][k] ^ cc;
        u64 kk = sub[side];  // subtract 10 = bits 1 and 3
        u64 r1 = w1 ^ kk, bo = ~w1 & kk;
        u64 r2 = w2 ^ bo; bo = ~w2 & bo;
        u64 dd = w3 ^ kk; u64 r3 = dd ^ bo; bo = (~w3 & kk) | (~dd & bo);
        (void)w4;
        u64** o = side ? hi : lo;
        o[0][k] = w0 & m; o[1][k] = r1 & m; o[2][k] = r2 & m; o[3][k] = r3 & m;
      }
    }
    if (n % 2 == 0) for (int q = 0; q < 4; q++) if (bit(hi[q], h - 1)) lo[q][h >> 6] |= 1ULL << (h & 63);
    u64 diff = 0, carry[4] = {1, 0, 0, 0};  // hiS_0 = 1
    for (int k = 0; k < nw1; k++) {
      u64 m = hmask(k, h1), hs[4];
      for (int q = 0; q < 4; q++) { hs[q] = ((hi[q][k] << 1) | carry[q]) & m; carry[q] = hi[q][k] >> 63; }
      u64 l[4] = {lo[0][k] & m, lo[1][k] & m, lo[2][k] & m, lo[3][k] & m};
      for (int q = 0; q < 4; q++) diff |= l[q] ^ hs[q];
      u64 cc = 0;
      for (int q = 0; q < 4; q++) { u64 x = l[q], y = hs[q]; d[q][k] = x ^ y ^ cc; cc = (x & y) | (cc & (x ^ y)); }
      d[4][k] = cc;
    }
    for (int k = nw1; k < W; k++) for (int q = 0; q < 5; q++) d[q][k] = 0;
    D->n = n1;
    pal = diff == 0;
  }
  return pal;
}

// ---------------- io ----------------
static char* readline_all(const char* f, int* n) {
  FILE* fp = fopen(f, "r"); if (!fp) { perror(f); exit(1); }
  fseek(fp, 0, SEEK_END); long L = ftell(fp); fseek(fp, 0, SEEK_SET);
  char* s = malloc(L + 1); size_t r = fread(s, 1, L, fp); s[r] = 0; fclose(fp);
  *n = (int)strcspn(s, "\r\n "); s[*n] = 0; return s;
}
static void write_next(const char* f, const uint8_t* S, int n) {  // pairs of N_k -> N_{k+1}
  char* v = malloc(n + 2); int c = 0;
  for (int i = 0; i < n; i++) { int a = S[i < n - 1 - i ? i : n - 1 - i] + c; v[n - i] = '0' + a % 10; c = a / 10; }
  FILE* o = fopen(f, "w");
  if (c) { v[0] = '1'; fwrite(v, 1, n + 1, o); } else fwrite(v + 1, 1, n, o);
  fputc('\n', o); fclose(o); free(v);
}
int main(int argc, char** argv) {
  int n0; char* s = readline_all(argv[1], &n0); int steps = atoi(argv[2]);
  int h0 = (n0 + 1) / 2, hmax = (n0 + steps + 1) / 2 + 128;
  uint8_t* S0 = malloc(hmax); for (int i = 0; i < h0; i++) S0[i] = s[n0 - 1 - i] - '0' + s[i] - '0';

  // zip
  uint8_t *x = calloc(hmax, 1), *y = calloc(hmax, 1); memcpy(x, S0, h0);
  int n = n0, bad, pals = 0; double t = now();
  for (int k = 0; k < steps - 1; k++) { n = zip_step(x, y, n, &bad); pals += !bad; uint8_t* z = x; x = y; y = z; }
  double tz = (now() - t) / (steps - 1);
  write_next(argv[3], x, n);

  // bits
  int W = hmax / 64 + 4;
  Planes PA = {{0}, n0, W}, PB = {{0}, n0, W};
  for (int q = 0; q < 5; q++) { PA.p[q] = calloc(W, 8); PB.p[q] = calloc(W, 8); }
  G = calloc(W, 8); P = calloc(W, 8); A = calloc(W, 8); B = calloc(W, 8);
  for (int q = 0; q < 8; q++) T[q] = calloc(W, 8);
  for (int j = 0; j < h0; j++) for (int q = 0; q < 5; q++) if ((S0[j] >> q) & 1) PA.p[q][j >> 6] |= 1ULL << (j & 63);
  Planes *cur = &PA, *nxt = &PB; int palb = 0;
  t = now();
  for (int k = 0; k < steps - 1; k++) { palb += bits_step(cur, nxt); Planes* z = cur; cur = nxt; nxt = z; }
  double tb = (now() - t) / (steps - 1);
  int hb = (cur->n + 1) / 2; uint8_t* Sb = malloc(hb);
  for (int j = 0; j < hb; j++) { int v = 0; for (int q = 0; q < 5; q++) v |= bit(cur->p[q], j) << q; Sb[j] = v; }
  write_next(argv[4], Sb, cur->n);
  printf("digits %d -> %d after %d steps\n", n0, n + (growth(x, n)), steps);
  printf("zip  algorithm: %8.1f us/step  (palindromes flagged: %d)\n", tz * 1e6, pals);
  printf("bit-sliced    : %8.1f us/step  (palindromes flagged: %d)\n", tb * 1e6, palb);
  printf("speed ratio zip/bits: %.1fx\n", tz / tb);
  return 0;
}
