# 196 reverse-and-add: bit-sliced exact engine (CUDA + CPU emulator)

Drop-in replacement for the previous zip's `main.cu`: same command-line arguments, same
checkpoint format (one decimal number per file), same `run_forever.py` workflow.

```bash
nvcc -O3 -std=c++17 -arch=sm_89 cuda196_bits.cu -o cuda196_bits
./cuda196_bits checkpoint_4942464.txt 20000 out_4962464.txt 4942464 64
```

## What changed, mathematically

Kept from the previous zip: the folded state `S_j = d_j + d_{n-1-j}` (pair sums 0..18, half the
digits) and its growth/centre case structure. Everything about how a step is computed is new.

With `G_j = (S_j >= 10)` and `P_j = (S_j == 9)`:

| | |
|---|---|
| low carries `a` | `a_0 = 0`, `a_{j+1} = G_j \| P_j·a_j` — **the carry bits of the binary sum (G\|P) + G** |
| high carries `b` | `b_{h-1}` = `a_h` (n even) or `a_{h-1}` (n odd), `b_{j-1} = G_j \| P_j·b_j` — the same sum on bit-reversed words |
| growth | `g = b_{-1}` |
| step, no growth | **`S'_j = 2·S_j + a_j + b_j − 10·(a_{j+1} + b_{j−1})`** |
| step, growth | `S'_j = lo_j + hi_{j−1}`, `lo_j = S_j + a_j − 10a_{j+1}`, `hi_j = S_j + b_j − 10b_{j−1}`, `hi_{−1} = 1`; n even adds `S'_h = 2·hi_{h−1}` |
| palindrome | no growth: `N_{t+1}` is a palindrome **iff `a_j = b_j` for every j** |

Why the identity holds: digit `j` of `N + rev N` is `m_j = T_j + c_j − 10c_{j+1}` with the symmetric
pre-carry vector `T_j = S_{min(j,n−1−j)}`. Pair j's low digit uses `(a_j, a_{j+1}) = (c_j, c_{j+1})`, its high
digit uses `(b_j, b_{j−1}) = (c_{n−1−j}, c_{n−j})`; add the two. Both digits of a pair start from the same
`S_j`, so they are equal iff their incoming carries are equal — the palindrome criterion.

Consequence: one step is **two big binary additions plus a fixed 7-input boolean function per pair**,
so the state is stored as 5 bit-planes and one 32-bit instruction processes 32 pairs at once
(bit-slicing). The 2,046,548-digit state is 640 KB. Carries that cross a 32-pair word are resolved by
scanning to the nearest word that is not entirely pair-sum 9 (probability ≈ 10^-32 per word) — exact,
no cutoff.

Side result: on the checkpoint, `a_j = b_j` holds for 50.15% of pairs, so a palindrome there has
probability ≈ 10^-306,672. Computation cannot settle the 196 problem; this engine is for speed.

## Measured so far (CPU only — no NVIDIA GPU was available)

Same algorithms in C on one CPU core, same input, outputs identical to a schoolbook reference
(`tools/cpu_compare.c`):

| input | old zip algorithm | bit-sliced | ratio |
|---|---|---|---|
| checkpoint 4,942,464 (+2,000 steps, 2.05M digits) | 4,792 µs/step | 331 µs/step | 14.5× |
| 196 from scratch, 30,000 steps | 12.3 µs/step | 0.9 µs/step | 14.0× |

This shows ~14× less work per step. **The GPU speedup is unmeasured.** The CUDA kernel compiles for
sm_89 but has not run on a GPU; `AGENT_TASK.md` has the test-then-benchmark procedure.

## Files

| file | purpose |
|---|---|
| `bits_core.h` | the step (shared by GPU kernel and CPU emulator) |
| `cuda196_bits.cu` | CUDA engine: one thread per 32-pair word, CUDA graphs per batch (both buffer parities, so odd batches use graphs too), per-block palindrome flag (no per-thread atomics) |
| `emu196_bits.cpp` | CPU emulator: runs `bits_core.h` word by word (OpenMP); same CLI |
| `driver.h` | I/O, checkpoints (reconstructs N_k from the state of step k−1), palindrome replay |
| `tests/test_exact.py` | exactness suite for any engine with this CLI |
| `bench_vs_old.sh` | GPU head-to-head vs `baseline/main_old.cu`, 3 runs, medians, reference check |
| `run_forever.py` | chunked long run (`--engine ./cuda196_bits`) |
| `baseline/main_old.cu` | previous zip's kernel, unchanged, for the comparison |
| `math/identity_test.py` | checks the step identity and palindrome criterion on 200k random numbers |
| `math/bitslice.py` | the whole algorithm in ~100 lines of pure Python on big integers (3.6 ms/step on the checkpoint) |
| `tools/cpu_compare.c` | single-core C comparison: old algorithm vs bit-sliced |
| `tools/ref.c` | independent schoolbook reference |
| `checkpoint_4942464.txt` | 2,046,548-digit checkpoint at iteration 4,942,464 |

## Next level: time blocking

Each step currently launches a kernel of ~32K light threads, so launch/graph overhead will likely
dominate. In folded form a step is local (pair j depends on pairs j−1..j+1 plus runs of 9s), so a block
can keep a tile of planes in shared memory and run K steps per launch, exactly, by tracking the
certified interval (shrinks one pair per side per step plus edge 9-runs). Growth for the next K steps
depends only on the outermost pairs and can be precomputed. The whole 640 KB state fits in the
4050's combined shared memory. Details in `AGENT_TASK.md`.
