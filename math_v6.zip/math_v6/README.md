# Math round (after v5): what was tried, what holds, what it buys

python3 crt_proof.py        # CRT state rules, all 176 cases
python3 growth_identity.py  # closed form for growth steps, 100k growing steps vs big integers
python3 recount.py          # needs yosys-abc: strict, verified 3-input-LUT (= LOP3) counts

Results (3-input LUTs = NVIDIA LOP3 instructions, netlists checked for fan-in <= 3 and simulated):
- no-growth pair update: binary encoding (v4) 35 by ABC / 27 hand-written; CRT encodings 24-28.
- growth steps need a mod-5 adder in CRT (~18 LUTs), which cancels the gain.
- current kernel: ~6.95 SASS instructions per pair per step, of which only ~2.1 are logic (LOP3);
  the rest is bookkeeping (bounds checks, address math, scans/branches, moves).
