# Growth-step identity, checked against big integers on random numbers whose next step grows.
#   S'_j = S_j + S_{j-1} + a_j + b_{j-1} - 10 (a_{j+1} + b_{j-2})
# boundary: S_{-1} = 0, b_{-1} = g = 1, b_{-2} = 0 (gives the new leading digit 1);
# even n: the new centre pair j = h uses the "high side" values on both sides:
#   S'_h = 2 S_{h-1} + 2 b_{h-1} - 20 b_{h-2}
import random, sys
sys.set_int_max_str_digits(0)
def pairs(s): n = len(s); return [int(s[n-1-i]) + int(s[i]) for i in range((n+1)//2)]
def carries(S, n):
    h = len(S); G = [x >= 10 for x in S]; P = [x == 9 for x in S]
    a = [0]*(h+1)
    for j in range(h): a[j+1] = int(G[j] or (P[j] and a[j]))
    b = [0]*h; b[h-1] = a[h] if n % 2 == 0 else a[h-1]
    for j in range(h-1, 0, -1): b[j-1] = int(G[j] or (P[j] and b[j]))
    g = int(G[0] or (P[0] and b[0]))
    return a, b, g
def growth_step(S, n):
    h = len(S); a, b, g = carries(S, n); assert g == 1
    Sx = lambda j: S[j] if j >= 0 else 0
    bx = lambda j: b[j] if j >= 0 else (1 if j == -1 else 0)
    h1 = (n + 2) // 2; out = []
    for j in range(h1):
        if n % 2 == 0 and j == h:
            out.append(2 * Sx(h-1) + 2 * bx(h-1) - 20 * bx(h-2))
        else:
            out.append(S[j] + Sx(j-1) + a[j] + bx(j-1) - 10 * (a[j+1] + bx(j-2)))
    return out
random.seed(7); tested = 0
while tested < 100000:
    L = random.randint(1, 60)
    s = str(random.randint(1, 9)) + ''.join(random.choice('0123456789') for _ in range(L - 1))
    if random.random() < 0.3:  # long runs of pair-sum 9
        s = ''.join(random.choice('09' * 3 + '5') for _ in range(L)).lstrip('0') or '9'
    r = str(int(s) + int(s[::-1]))
    if len(r) == len(s): continue
    assert growth_step(pairs(s), len(s)) == pairs(r), s
    tested += 1
print(f"growth identity exact on {tested} growing steps (random + 9-run inputs, odd and even n)")
