# Exhaustive proof of the CRT ("tens flag, mod 2, mod 5") update rules for one pair.
# State of a pair:  q = [S>=10],  p = S mod 2,  m = S mod 5   (S = pair sum 0..18)
# Carries in:       a = low carry a_j,  b = high carry b_j
inc5 = lambda m: (m + 1) % 5
def enc(S): return (int(S >= 10), S % 2, S % 5)
def dec(q, p, m):                      # inverse on valid states
    r = [x for x in range(10) if x % 2 == p and x % 5 == m][0]
    return 10 * q + r
ok = 0
for S in range(19):
    q, p, m = enc(S); assert dec(q, p, m) == S
    # carry generate/propagate need only q, p, m:
    G, P = int(S >= 10), int(S == 9)
    assert G == q and (G | P) == (q | (p & (m == 4)))
    r = S % 10
    for a in (0, 1):
        for b in (0, 1):
            # ground truth (no growth): S' = lo + hi with lo = (S+a) mod 10, hi = (S+b) mod 10
            Sn = (r + a) % 10 + (r + b) % 10
            # CRT rule
            c0, c1 = a ^ b, a & b
            h = p ^ (m & 1)                       # r >= 5
            m4 = int(m == 4)
            qn = (1 - (m4 & (a | b))) if h else (m4 & c1)
            pn = c0                                # <- parity of next state = a XOR b
            mn = (2 * m + a + b) % 5
            assert (qn, pn, mn) == enc(Sn), (S, a, b)
            # palindrome: digits equal  <=>  a == b  <=>  pn == 0
            assert (((r + a) % 10) == ((r + b) % 10)) == (pn == 0)
            ok += 1
# growth rule: S' = lo_j + hi_{j-1} for arbitrary digit pairs (lo, hi in 0..9)
for lo in range(10):
    for hi in range(10):
        pl, ml, ph, mh = lo % 2, lo % 5, hi % 2, hi % 5
        s = ml + mh; k = int(s >= 5)
        hl, hh = pl ^ (ml & 1), ph ^ (mh & 1)      # lo>=5, hi>=5
        qn = int(hl + hh + k >= 2)                 # majority
        assert (qn, pl ^ ph, s % 5) == enc(lo + hi), (lo, hi)
        ok += 1
print(f"CRT update rules: all {ok} cases exact (76 no-growth, 100 growth)")
