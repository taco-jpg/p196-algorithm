from lut3 import synth
GRAY = {0: 0, 1: 1, 2: 3, 3: 2, 4: 4}
def upd(enc):
    inv = {v: k for k, v in enc.items()}; U = {}
    for code, S in inv.items():
        r = S % 10
        for a in (0, 1):
            for b in (0, 1): U[(code << 2) | (a << 1) | b] = format(enc[(r + a) % 10 + (r + b) % 10], '05b')
    return U
binS = {S: S for S in range(19)}
for name, mc in (('gray', GRAY), ('binary m', {i: i for i in range(5)}), ('best-scan', {0: 0, 1: 1, 2: 3, 3: 2, 4: 5})):
    crt = {S: (int(S >= 10) << 4) | ((S % 2) << 3) | mc[S % 5] for S in range(19)}
    print(f'CRT {name:9s}: no-growth update {synth(7, 5, upd(crt), "c")[0]} LUT3 (verified)')
print(f'binary S (v4): no-growth update {synth(7, 5, upd(binS), "b")[0]} LUT3 (verified)')
