# Strict 3-input LUT synthesis with ABC: every netlist is checked for fan-in <= 3 and
# simulated exhaustively against the specification (accounting for read_pla -z complement).
import subprocess, re, os
SCRIPTS = [
 "strash; if -K 3 -a",
 "strash; dc2; if -K 3 -a",
 "strash; resyn2; if -K 3 -a",
 "strash; dch -f; if -K 3 -a",
 "strash; if -K 3 -a; mfs2; strash; dch; if -K 3 -a",
 "strash; dc2; dch; if -K 3 -a; mfs2; strash; dc2; if -K 3 -a",
 "strash; &get -n; &deepsyn -T 8; &put; if -K 3 -a",
]
def pla(nin, nout, rows):
    L = [f'.i {nin}', f'.o {nout}', '.type fd']
    for i in range(1 << nin): L.append(format(i, f'0{nin}b') + ' ' + rows.get(i, '-' * nout))
    return '\n'.join(L + ['.e', ''])
def parse(txt):
    ins = re.search(r'\.inputs (.*)', txt).group(1).split(); outs = re.search(r'\.outputs (.*)', txt).group(1).split()
    blocks = re.findall(r'\.names ([^\n]*)\n((?:[01\-]+ [01]\n|[01]\n)*)', txt)
    by = {b[0].split()[-1]: b for b in blocks}
    return ins, outs, by
def evaluate(ins, outs, by, vals):
    env = dict(zip(ins, vals))
    def ev(s):
        if s in env: return env[s]
        hdr, cover = by[s]; inp = hdr.split()[:-1]; rows = [r for r in cover.strip().split('\n') if r]
        if not inp: env[s] = int(rows[0]) if rows else 0; return env[s]
        v = [ev(x) for x in inp]; hit = 0; on = 1
        for r in rows:
            pat, o = r.split(); on = int(o)
            if all(p == '-' or int(p) == b for p, b in zip(pat, v)): hit = 1
        env[s] = hit if on == 1 else 1 - hit
        return env[s]
    return [1 - ev(o) for o in outs]   # -z complement
def synth(nin, nout, rows, tag='x'):
    fn = f'/tmp/claude-0/l3_{os.getpid()}_{tag}'
    open(fn + '.pla', 'w').write(pla(nin, nout, rows)); best = None
    for sc in SCRIPTS:
        r = subprocess.run(['yosys-abc', '-q', f'read_pla -z {fn}.pla; {sc}; write_blif {fn}.blif'], capture_output=True, text=True)
        if not os.path.exists(fn + '.blif'): continue
        txt = open(fn + '.blif').read(); os.remove(fn + '.blif')
        ins, outs, by = parse(txt)
        used = set()
        def walk(s):
            if s in used or s not in by: return
            used.add(s)
            for x in by[s][0].split()[:-1]: walk(x)
        for o in outs: walk(o)
        if any(len(by[s][0].split()) - 1 > 3 for s in used): continue
        luts = sum(1 for s in used if len(by[s][0].split()) > 1)
        ok = all(''.join(map(str, evaluate(ins, outs, by, [(i >> (nin - 1 - k)) & 1 for k in range(nin)]))) == o
                 for i, o in rows.items())
        if ok and (best is None or luts < best[0]): best = (luts, txt)
    return best
