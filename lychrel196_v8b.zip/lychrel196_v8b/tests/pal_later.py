#!/usr/bin/env python3
"""Palindromes that appear a few steps in (not at the first step of a hybrid window).
Searches large random numbers with mostly small pair sums and a few large ones until the first
palindrome comes at step >= 3, then checks the engine reports exactly that iteration.
usage: python3 tests/pal_later.py ENGINE [CASES]"""
import os, random, re, subprocess, sys, tempfile
sys.set_int_max_str_digits(0)
eng = os.path.abspath(sys.argv[1]); want = int(sys.argv[2]) if len(sys.argv) > 2 else 6
random.seed(5); T = tempfile.mkdtemp(); found = bad = tries = 0
def ra(x): return x + int(str(x)[::-1])
while found < want and tries < 20000:
    tries += 1
    n = random.choice([12000, 20001, 30000]); h = (n + 1) // 2
    S = [random.randint(0, 1) for _ in range(h)]      # doubles to <= 8 over several steps
    for _ in range(random.randint(1, 3)): S[random.randint(1, h - 2)] = random.choice([5, 6, 10, 11, 12])
    if n % 2: S[h - 1] = 2 * random.randint(0, 1)
    d = [0] * n
    for j, s in enumerate(S):
        a = random.randint(max(0, s - 9), min(9, s))
        if j == n - 1 - j: a = s // 2
        d[j] = a; d[n - 1 - j] = s - a
    if d[0] == 0: continue
    x = int(''.join(map(str, d))); first = None
    for t in range(1, 12):
        x = ra(x); st = str(x)
        if st == st[::-1]: first = t; break
    if not first or first < 3: continue
    found += 1
    open(f'{T}/in.txt', 'w').write(''.join(map(str, d)) + '\n')
    for K, tile in ((8, 4), (64, 8), (128, 32)):
        r = subprocess.run([eng, f'{T}/in.txt', '200', f'{T}/out.txt', '0', str(K), f'--tile={tile}'], capture_output=True, text=True)
        m = re.search(r'PALINDROME at iteration (\d+)', r.stderr); hb = re.search(r'hybrid blocks=(\d+)', r.stderr)
        got = int(m.group(1)) if m else None
        if got != first:
            bad += 1; print(f'MISMATCH n={n} K={K} tile={tile}: expected palindrome at {first}, engine {got}\n{r.stderr[-300:]}')
        else:
            print(f'ok n={n} K={K} tile={tile}: palindrome at {first} (hybrid blocks {hb.group(1) if hb else "n/a"})')
print(f'later palindromes: {found} numbers x 3 configurations, {bad} mismatches')
sys.exit(1 if bad or found == 0 else 0)
