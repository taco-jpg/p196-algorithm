// Plain schoolbook reverse-and-add reference: ref INPUT STEPS OUTPUT
// v8b: buffers sized from the input file (no fixed limit), 64-bit indices throughout.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int c, char** v) {
  if (c < 4) { fprintf(stderr, "usage: ref INPUT STEPS OUTPUT\n"); return 2; }
  FILE* f = fopen(v[1], "rb"); if (!f) return 1;
  fseek(f, 0, SEEK_END); long long fs = ftell(f); fseek(f, 0, SEEK_SET);
  long steps = atol(v[2]);
  size_t cap = (size_t)fs + (size_t)steps + 64;
  char *a = malloc(cap), *b = malloc(cap);
  if (!a || !b) { fprintf(stderr, "out of memory\n"); return 1; }
  size_t n = fread(a, 1, (size_t)fs, f); fclose(f);
  while (n && (a[n - 1] == '\n' || a[n - 1] == '\r' || a[n - 1] == ' ')) --n;
  a[n] = 0;
  for (long s = 0; s < steps; s++) {
    int cy = 0;
    for (size_t i = 0; i < n; i++) { int z = a[n - 1 - i] - '0' + a[i] - '0' + cy; b[n - i] = (char)('0' + z % 10); cy = z / 10; }
    if (cy) { b[0] = '1'; memcpy(a, b, n + 1); n++; } else { memcpy(a, b + 1, n); }
    a[n] = 0;
  }
  FILE* o = fopen(v[3], "wb"); fwrite(a, 1, n, o); fputc('\n', o); fclose(o);
  return 0;
}
