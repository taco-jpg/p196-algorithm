// isf CHECKPOINT ITERATION OUTPUT [SEED]  - write a checkpoint as an "Istvan-Standard Format" file,
// the format p196.org uses to compare and verify results (as written by p196_mpi's write_isf):
//   automatic save #CCCCC          CRC-16 (poly 0x1021, init 0xFFFF) of everything from the
//   Initial value:    196          "Iteration:" line to the end, printed as 5 decimal digits
//   Iteration:        <iteration>
//   Number of digits: <digits>
//   <digits, most significant first, 70 per line>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned short crc1021(unsigned short crc, unsigned char data) {
  unsigned short x = (unsigned short)(((crc >> 8) ^ data) & 0xff);
  x ^= x >> 4;
  return (unsigned short)((crc << 8) ^ (x << 12) ^ (x << 5) ^ x);
}
int main(int c, char** v) {
  if (c < 4) { fprintf(stderr, "usage: isf CHECKPOINT ITERATION OUTPUT [SEED]\n"); return 2; }
  FILE* f = fopen(v[1], "rb"); if (!f) { perror(v[1]); return 1; }
  fseek(f, 0, SEEK_END); long long fs = ftell(f); fseek(f, 0, SEEK_SET);
  char* d = malloc((size_t)fs + 1); if (!d) { fprintf(stderr, "out of memory\n"); return 1; }
  size_t n = fread(d, 1, (size_t)fs, f); fclose(f);
  size_t m = 0;
  for (size_t i = 0; i < n; ++i) if (d[i] >= '0' && d[i] <= '9') d[m++] = d[i];  // digits only
  if (m == 0 || d[0] == '0') { fprintf(stderr, "not a positive decimal\n"); return 1; }
  const char* seed = c > 4 ? v[4] : "196";
  char head[256], body[192];
  int hl = snprintf(head, sizeof head, "Initial value:    %s\n", seed);
  int bl = snprintf(body, sizeof body, "Iteration:        %s\nNumber of digits: %zu\n", v[2], m);
  unsigned short crc = 0xFFFF;
  for (int i = 0; i < bl; ++i) crc = crc1021(crc, (unsigned char)body[i]);
  for (size_t i = 0; i < m; ++i) {
    crc = crc1021(crc, (unsigned char)d[i]);
    if ((i + 1) % 70 == 0 || i + 1 == m) crc = crc1021(crc, '\n');
  }
  FILE* o = fopen(v[3], "wb"); if (!o) { perror(v[3]); return 1; }
  fprintf(o, "automatic save #%05d\n", crc);
  fwrite(head, 1, (size_t)hl, o); fwrite(body, 1, (size_t)bl, o);
  for (size_t i = 0; i < m; i += 70) {
    size_t k = m - i < 70 ? m - i : 70;
    fwrite(d + i, 1, k, o); fputc('\n', o);
  }
  if (fclose(o)) { perror("write"); return 1; }
  fprintf(stderr, "ISF written: %s (%zu digits, iteration %s, crc %05d)\n", v[3], m, v[2], crc);
  return 0;
}
