// gen_digits N SEED OUTPUT : N random decimal digits (first digit non-zero), for large-size tests
#include <stdio.h>
#include <stdlib.h>
int main(int c, char** v) {
  if (c < 4) { fprintf(stderr, "usage: gen_digits N SEED OUTPUT\n"); return 2; }
  long long n = atoll(v[1]); unsigned long long x = strtoull(v[2], 0, 10) * 0x9E3779B97F4A7C15ull + 1;
  FILE* o = fopen(v[3], "wb"); static char buf[1 << 20]; long long done = 0;
  while (done < n) {
    int k = 0;
    for (; k < (int)sizeof buf && done < n; ++k, ++done) {
      x ^= x << 13; x ^= x >> 7; x ^= x << 17;
      int d = (int)((x >> 32) % 10);
      if (done == 0 && d == 0) d = 7;
      buf[k] = (char)('0' + d);
    }
    fwrite(buf, 1, (size_t)k, o);
  }
  fputc('\n', o); fclose(o); return 0;
}
