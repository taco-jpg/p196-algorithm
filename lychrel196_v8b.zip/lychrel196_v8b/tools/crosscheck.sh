#!/usr/bin/env bash
# Weekly independent check for a GPU without ECC memory: recompute the steps between two saved
# checkpoints with the v4 per-step kernel (a different code path from production's time-blocked
# kernel) and require an identical result, plus the mod-9 identity.
#   tools/crosscheck.sh ENGINE CK_A ITER_A CK_B ITER_B
# Uses the GPU: pause production first (search/STOP), resume afterwards. Copies only.
set -euo pipefail
ENG=${1:?engine binary}; A=${2:?checkpoint A}; IA=${3:?iteration A}; B=${4:?checkpoint B}; IB=${5:?iteration B}
DIR=$(dirname "$0"); OUT=$(mktemp -d)/crosscheck_$IB.txt
[ "$IB" -gt "$IA" ] || { echo "ITER_B must be > ITER_A"; exit 2; }
"$DIR/../bench/mod9" "$A" "$IA" "$B" "$IB" || { echo "crosscheck $IA -> $IB: FAIL (mod-9 identity) - stop production and report"; exit 1; }
echo "per-step kernel: $((IB - IA)) steps from $IA ..."
"$ENG" "$A" $((IB - IA)) "$OUT" "$IA" 64 --mode=step 2> "$OUT.log" || { tail -3 "$OUT.log"; exit 1; }
grep -oE 'device_us_per_step=[0-9.]+' "$OUT.log" | tail -1
if cmp -s "$OUT" "$B" || cmp -s <(tr -cd '0-9' < "$OUT") <(tr -cd '0-9' < "$B"); then
  echo "crosscheck $IA -> $IB: PASS (per-step kernel reproduces the production checkpoint)"
else
  echo "crosscheck $IA -> $IB: FAIL - stop production and report; restore from the last archive that passed"
  exit 1
fi
rm -f "$OUT" "$OUT.log"
