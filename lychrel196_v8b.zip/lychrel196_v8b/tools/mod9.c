// mod9 FILE_A ITER_A FILE_B ITER_B - free consistency check between two checkpoints of the same
// run. rev(x) has x's digit sum, so x' = x + rev(x) = 2x (mod 9) and x_B = 2^(B-A) x_A (mod 9).
#include <stdio.h>
#include <stdlib.h>
static int dsum9(const char* p, long long* nd) {
  FILE* f = fopen(p, "rb"); if (!f) { perror(p); exit(1); }
  static unsigned char buf[1 << 22]; size_t k; unsigned long long s = 0; long long n = 0;
  while ((k = fread(buf, 1, sizeof buf, f)) > 0)
    for (size_t i = 0; i < k; ++i) if (buf[i] >= '0' && buf[i] <= '9') { s += buf[i] - '0'; ++n; }
  fclose(f); *nd = n; return (int)(s % 9);
}
int main(int c, char** v) {
  if (c < 5) { fprintf(stderr, "usage: mod9 FILE_A ITER_A FILE_B ITER_B\n"); return 2; }
  long long na, nb, ia = atoll(v[2]), ib = atoll(v[4]);
  if (ib < ia) { fprintf(stderr, "ITER_B must be >= ITER_A\n"); return 2; }
  int a = dsum9(v[1], &na), b = dsum9(v[3], &nb);
  long long e = (ib - ia) % 6;  // 2 has order 6 mod 9
  int p = 1; for (long long i = 0; i < e; ++i) p = p * 2 % 9;
  int want = a * p % 9;
  printf("mod9: A=%s (%lld digits) = %d, B=%s (%lld digits) = %d, expected %d: %s\n", v[1], na, a, v[3], nb, b, want,
         b == want ? "PASS" : "FAIL");
  return b == want ? 0 : 1;
}
