# 196 reverse-and-add v8b: past 2.147 billion digits, room for wider tiles, base-5 option, record tools

```bash
nvcc -O3 -std=c++17 -arch=sm_89 cuda196_v8b.cu -o cuda196_v8b                          # default build
./cuda196_v8b run <checkpoint> <iteration> search --chunk=1000000 --keep=3 --K=128 --tile=1000
nvcc ... -DTB_THREADS=288 -DTB_QUINARY=1 -DTB_J=12 ...                                # options, see below
```

Same arithmetic, certification, replay, command line, checkpoint format and `latest.json` fields as
v8 (engine field `cuda196_v8b`; bench lines add `threads=` and `quinary=`). Results are identical.

## What changes

1. **64-bit digit counts (required).** v8 stops at ~2.147e9 digits because the digit count is a
   32-bit `int`; at production speed that is about November 21. v8b keeps the count in 64 bits
   everywhere (host, kernels, device buffers, checkpoint I/O). Pair indices stay 32-bit
   (h = ceil(n/2) < 2^31), so the new limit is ~4.29e9 digits, roughly March 2027 at today's speed.
   Also: the bench/run modes free the decimal input after loading, and the decimal output is built
   without a 1 GB side array, which matters at 2e9+ digits. `tools/ref.c` no longer has a fixed size
   limit (the old one silently capped inputs at ~68M digits).
2. **Slimmer block state.** `gS[1025]` (4 KB of shared memory per block) becomes a 2-entry ring plus a
   bitmask. With **288 threads** (`-DTB_THREADS=288`), hybrid blocks can take up to 288 groups:
   tiles up to ~1120 fit 2 blocks/SM (v8's 256 threads capped it at 1000). v8's A/B showed speed
   still rising at 1000.
3. **Any window length** (`-DTB_J=1..32`). `TB_J=12`: 25% fewer syncs than 8; the 32-pair margin
   should still hold (16 did not). The A/B's replay count says whether it does.
4. **Base-5 window arithmetic** (`-DTB_QUINARY=1`). Inside hybrid windows each pair sum is kept as
   S = M + 5H + 10G. Then "carry generated" is a stored bit, "carry propagates" is H & M2, and the new
   digit is M + 5H + c − 10Pc (G cancels). Roughly a quarter fewer logic operations in no-growth
   steps; about even in growth steps (the palindrome test needs a digit comparison). Converted at
   window load/store, so tiles, checkpoints and the verification kernel stay binary.
5. **Record tools.**
   - `tools/isf.c`: writes a checkpoint in p196.org's ISF format. Byte-identical to Dolbeau's own
     `write_isf`, and his `read_isf` reads it back (tested on this package's checkpoint, a short
     number, and a 140-digit line-boundary case).
   - `tools/mod9.c`: x' = 2x (mod 9), so any two checkpoints of the run must satisfy
     x_B = 2^(B−A) x_A (mod 9). Free, catches most single-digit corruption.
   - `tools/crosscheck.sh`: weekly check for a GPU without ECC memory. Recomputes the steps between
     two saved checkpoints with the separate v4 per-step kernel and requires an identical result
     (plus mod-9). Caught both a changed digit and two swapped digits in tests.

## Checked here (CPU emulator running the same kernel code; clang + ptxas for sm_89)

- **64-bit, end to end:** a random 2,147,483,600-digit number, 250 steps (it passes 2^31 digits
  around step 116), emulator == independent schoolbook reference. See `big64` for the GPU run.
- Base-5 arithmetic: exhaustive over every input of every formula (1,539 cases, 0 mismatches).
- Cross-check builds (hybrid blocks recomputed through the v6r3 path, per-step votes and owned words
  identical) for the default, base-5, and 288-thread + base-5 + J=12 builds; J=10 and 12 cover
  windows that straddle 32-bit words. Quiet-region inputs: 9,280 blocks / 213,063 quiet block-steps
  identical per build. Stress with planted carry chains: all exact, 200+ hybrid failures replayed per
  build, 0 soundness violations.
- Exactness suites ALL PASS and differential vs v8 60/60 for the default, base-5 and 288-thread builds.
  +2000 steps on the 2.05M checkpoint == reference at tiles 1000 and 1100.
- Compiled (clang + ptxas): default, base-5 and J=12 use 128 registers; the hybrid path has no
  local-memory traffic (the only spill is 4 bytes in the v6r3 path, used by 2 blocks per launch).
  **288-thread builds get 96 registers** (18 warps per SM leave 5 warps on some scheduler partitions,
  16,384 registers each), with 160 bytes of spills, all of them in the v6r3 path; the hybrid
  window loop has none. 16 warps per SM is the most that fits at more than 96 registers, so this is
  the only way to more threads per SM. `resources` shows nvcc's numbers on the target.

## Expected speed (honest)

From the 64-bit change: about 0 (the hybrid path does not use the digit count). Wider tiles with 288
threads: maybe +3–8% if nvcc keeps the registers. J=12: maybe +2–4% if replays stay 0. Base-5: maybe
+3–8%. Combined perhaps +10–15%, not multiplied guarantees; the A/B decides each one. **Even at equal
speed, production must be on v8b before ~November 15** because of the digit limit.

## Files

| file | purpose |
|---|---|
| `cuda196_v8b.cu`, `emu196_v8b.cpp` | CUDA backend / CPU emulator (same kernel code) |
| `bits_tb8b.h`, `bits_core.h`, `driver8b.h` | engine, v4 per-step arithmetic, host driver |
| `bench_v8b.sh` | `build`, `resources`, `gate`, `big64`, `ab`, `sustained`, `runmode` |
| `tools/ref.c`, `tools/gen_digits.c` | schoolbook reference (no size limit), big random inputs |
| `tools/isf.c`, `tools/mod9.c`, `tools/crosscheck.sh` | ISF output, mod-9 identity, weekly cross-check |
| `tests/unit_quinary.cpp` | exhaustive base-5 arithmetic test |
| `tests/*.py` | exactness, differential, hybrid stress, quiet regions, palindromes in windows, growth edges |
| `baseline_v8/` | the production engine, for A/B |
