# Task for the local agent (RTX 4050): v8b (64-bit digits, wider tiles, base-5, record tools)

Production runs v8 (K=128, tile 1000) toward the 999,999,999 milestone. **Do this after the
milestone comparison report**, unless the user says otherwise. Results must be identical to v8.

Pause with `search/STOP` (finishes the current chunk) for anything that uses the GPU, resume from
`latest.json`, confirm the service runs again. One GPU job at a time. The CPU-only parts (emulator
checks, the big64 CPU reference) can run while production runs, if the user agrees.

## Why
- **Required:** v8 cannot go past ~2.147e9 digits (32-bit digit count). Production reaches that around
  November 21. v8b's limit is ~4.29e9 digits. Production must move to v8b before ~November 15 even
  if no option is faster.
- Optional speed: 288 threads (tiles up to ~1120), J=12, base-5 window arithmetic. Each is a separate
  build so the A/B measures each one.
- Tools: ISF output (p196.org format), mod-9 identity, weekly per-step cross-check.

## Steps
1. `./bench_v8b.sh build`, then `./bench_v8b.sh resources`. Report the lines, especially registers
   and STL/LDL of the 288-thread builds (2 blocks of 288 threads allow at most 112 registers).
2. `./bench_v8b.sh gate`. **Everything must PASS.**
3. `./bench_v8b.sh big64`: a 2,147,483,600-digit random number, 250 steps (crosses 2^31 digits),
   v8b and the all-options build vs the CPU reference. Needs ~6 GB free RAM for the reference,
   ~7 GB disk, ~2.2 GB GPU memory; the CPU reference takes tens of minutes and can run while
   production runs (it is CPU-only); the two GPU runs need the GPU.
4. `./bench_v8b.sh ab <COPY of the newest checkpoint> <its iteration>`: v8:1000 (production) vs
   v8b:1000, v8bq:1000, v8bj12:1000, v8bt:1000/1100, v8btq:1100, v8btqj12:1100. 5,000 steps,
   3 interleaved rounds, power and energy. **Replays must be 0** for a configuration to count.
5. Best configuration (median, replays 0) vs production: `./bench_v8b.sh sustained <COPY> <iter> <cfg>`.
6. `./bench_v8b.sh runmode`. Resume production, confirm it runs. Send back `bench/summary.txt`,
   `bench/ab.tsv`, `bench/log.txt`.

## Deciding (the user's call)
- Switch to v8b in any case before ~November 15 (digit limit). With the user's go-ahead, at a chunk
  boundary, resuming from `latest.json`, keeping the milestone/stop settings. Keep v8 for rollback.
- Use the fastest configuration that is ≥ 3% faster sustained with 0 replays; otherwise plain v8b at
  tile 1000.

## New routines (once production is on v8b; the user decides schedule and destinations)
- **Milestones:** `bench/isf <checkpoint> <iteration> <out.isf>` for the 1e9-iteration state and every
  100M digits; keep the ISF files with the archives.
- **Every archive:** `bench/mod9 <previous archive> <its iter> <new archive> <its iter>` must PASS.
- **Weekly (GPU, ~20 min paused):** `tools/crosscheck.sh ./cuda196_v8b <checkpoint at I> I <checkpoint at I+1000000> I+1000000`
  on two consecutive kept checkpoints. FAIL → stop production, report, restore from the last archive
  whose cross-check passed.

## Rules
- Benchmarks only on a copy of a checkpoint, never the live file.
- Every step's palindrome status is checked; certification failures replay.
- Measured numbers only.
