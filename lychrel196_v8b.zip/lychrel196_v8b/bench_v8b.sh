#!/usr/bin/env bash
# v8b build, gate and A/B against v8 (the production engine) on the RTX 4050 Laptop.
#   ./bench_v8b.sh build              all binaries: v8b variants, baseline v8, emulators, tools
#   ./bench_v8b.sh resources          registers / stack / local memory per binary (tb_kernel)
#   ./bench_v8b.sh gate               exactness gate - must pass before any timing
#   ./bench_v8b.sh big64              64-bit test: a 2,147,483,600-digit number crosses 2^31 digits
#   ./bench_v8b.sh ab FILE ITER       COPY of a production checkpoint: interleaved A/B with power
#   ./bench_v8b.sh sustained FILE ITER CFG   100,000 steps each: production (v8:1000) vs CFG
#   ./bench_v8b.sh runmode            finite run-mode check (3 chunks) + ISF + mod-9 of the result
# Configurations are ENGINE:TILE. Engines:
#   v8 (production) | v8b (64-bit, J=8) | v8bq (+ base-5) | v8bj12 (J=12) | v8bt (288 threads)
#   v8btq (288 + base-5) | v8btqj12 (288 + base-5 + J=12)
# Never point FILE at the live production checkpoint: use a copy. Timing needs the GPU to itself:
# pause production (search/STOP) first and resume from latest.json afterwards.
set -euo pipefail
ARCH=${ARCH:-sm_89}
CK=checkpoint_4942464.txt; START=4942464
NV="nvcc -O3 -std=c++17 -arch=$ARCH"
K=${K:-128}
mkdir -p bench
log() { echo "$@" | tee -a bench/summary.txt; }
median() { sort -n | awk '{a[NR]=$1} END{print a[int((NR+1)/2)]}'; }
mean() { awk '{s+=$1; n++} END{if (n) printf "%.3f", s/n; else print "NA"}'; }
ref_for() {
  local f=bench/ref_$(basename $1)_$2.txt
  [ -f $f ] || { echo "building CPU reference ($2 steps)..." >&2; ./bench/ref $1 $2 $f; }
  echo $f
}
run1() {  # run1 BIN args... ; stderr -> bench/last.txt (+ appended to bench/log.txt)
  local b=$1; shift
  $b "$@" 2> bench/last.txt >/dev/null || { cat bench/last.txt; return 1; }
  cat bench/last.txt >> bench/log.txt
}
devus() { grep -oE 'device_us_per_step=[0-9.]+' bench/last.txt | tail -1 | cut -d= -f2; }
reps() { grep -oE 'replays=[0-9]+' bench/last.txt | tail -1 | cut -d= -f2; }
binof() {
  case "${1%%:*}" in
    v8) echo bench/v8 ;; v8b) echo ./cuda196_v8b ;; v8bq) echo bench/v8bq ;; v8bj12) echo bench/v8bj12 ;;
    v8bt) echo bench/v8bt ;; v8btq) echo bench/v8btq ;; v8btqj12) echo bench/v8btqj12 ;;
    *) echo "unknown engine ${1%%:*}" >&2; exit 2 ;;
  esac
}
tileof() { echo "${1##*:}"; }
runcfg() { run1 $(binof $1) $2 $3 $4 $5 $K --tile=$(tileof $1); }   # runcfg CFG IN STEPS OUT IT
timed() {  # timed CFG IN STEPS OUT IT -> US, W, MHZ
  local cfg=$1 in=$2 steps=$3 out=$4 it=$5
  rm -f bench/pw.csv
  nvidia-smi --query-gpu=power.draw,clocks.sm --format=csv,noheader,nounits -lms 100 > bench/pw.csv 2>/dev/null &
  local smi=$!
  runcfg $cfg $in $steps $out $it || { kill $smi 2>/dev/null || true; return 1; }
  kill $smi 2>/dev/null || true; wait $smi 2>/dev/null || true
  US=$(devus)
  W=$(awk -F', *' '$2 > 1000 {s+=$1; n++} END{if (n) printf "%.2f", s/n; else print "NA"}' bench/pw.csv)
  MHZ=$(awk -F', *' '$2 > 1000 {s+=$2; n++} END{if (n) printf "%.0f", s/n; else print "NA"}' bench/pw.csv)
}
GPU_ALL="./cuda196_v8b bench/v8bq bench/v8bj12 bench/v8bt bench/v8btq bench/v8btqj12"
case "${1:-}" in
build)
  $NV cuda196_v8b.cu -o cuda196_v8b
  $NV -DTB_QUINARY=1 cuda196_v8b.cu -o bench/v8bq
  $NV -DTB_J=12 cuda196_v8b.cu -o bench/v8bj12
  $NV -DTB_THREADS=288 cuda196_v8b.cu -o bench/v8bt
  $NV -DTB_THREADS=288 -DTB_QUINARY=1 cuda196_v8b.cu -o bench/v8btq
  $NV -DTB_THREADS=288 -DTB_QUINARY=1 -DTB_J=12 cuda196_v8b.cu -o bench/v8btqj12
  (cd baseline_v8 && $NV cuda196_v8.cu -o ../bench/v8 && g++ -O3 -march=native -fopenmp -std=c++17 emu196_v8.cpp -o ../bench/emu_v8)
  E="g++ -O3 -march=native -fopenmp -std=c++17"
  $E emu196_v8b.cpp -o emu196_v8b
  $E -DTB_CHECK_HYBRID -DTB_CHECK_GROWTH emu196_v8b.cpp -o bench/emu_check
  $E -DTB_QUINARY=1 -DTB_CHECK_HYBRID -DTB_CHECK_GROWTH emu196_v8b.cpp -o bench/emu_check_q
  $E -DTB_THREADS=288 -DTB_QUINARY=1 -DTB_J=12 -DTB_CHECK_HYBRID -DTB_CHECK_GROWTH emu196_v8b.cpp -o bench/emu_check_all
  g++ -O2 -std=c++17 -I. tests/unit_quinary.cpp -o bench/unit_quinary
  gcc -O2 tools/ref.c -o bench/ref; gcc -O2 tools/gen_digits.c -o bench/gen_digits
  gcc -O2 tools/isf.c -o bench/isf; gcc -O2 tools/mod9.c -o bench/mod9
  ;;
resources)
  for b in $GPU_ALL bench/v8; do
    ru=$(cuobjdump --dump-resource-usage $b 2>/dev/null | grep -A1 'tb_kernel' | grep -oE 'REG:[0-9]+|STACK:[0-9]+' | tr '\n' ' ')
    sec=$(cuobjdump -sass $b | awk '/Function : .*tb_kernel/{f=1; next} /Function : /{f=0} f')
    [ -n "$sec" ] || { log "$b: tb_kernel section not found in SASS"; continue; }
    log "$b: $ru STL=$(grep -c STL <<< "$sec" || true) LDL=$(grep -c LDL <<< "$sec" || true) SASS_lines=$(wc -l <<< "$sec")"
  done
  log "  (288-thread builds: 2 blocks/SM need <= 112 registers; report if they spill - the A/B will show the cost)"
  ;;
gate)
  log "== base-5 arithmetic, exhaustive:"; ./bench/unit_quinary | tee -a bench/summary.txt
  log "== CPU emulator cross-checks (hybrid blocks recomputed through the v6r3 path, per step)"
  for b in bench/emu_check bench/emu_check_q bench/emu_check_all; do
    log "  $b"
    python3 tests/quiet_bits.py ./$b 4 | tail -1 | tee -a bench/summary.txt
    python3 tests/stress_hybrid.py ./$b 8 | tail -1 | tee -a bench/summary.txt
  done
  log "== GPU exactness"
  for f in "--mode=step" "--mode=tb" "--mode=tb --tile=4 --K=7" "--mode=tb --tile=4 --halo=4 --K=64 --window=128" \
           "--mode=tb --tile=8 --halo=4 --K=256 --window=512" "--mode=tb --tile=64 --K=1000" "--mode=tb --tile=1000" \
           "--mode=tb --hybrid=0"; do
    log "GPU exactness suite v8b: $f"
    ENGINE_FLAGS="$f" python3 tests/test_exact.py ./cuda196_v8b | tail -1 | tee -a bench/summary.txt
  done
  for b in bench/v8bq bench/v8bj12 bench/v8bt bench/v8btq bench/v8btqj12; do
    log "GPU exactness suite (default tb, forced failures, tile 1100) with $b"
    ENGINE_FLAGS="--mode=tb" python3 tests/test_exact.py ./$b | tail -1 | tee -a bench/summary.txt
    ENGINE_FLAGS="--mode=tb --tile=8 --halo=4 --K=256 --window=512" python3 tests/test_exact.py ./$b | tail -1 | tee -a bench/summary.txt
    ENGINE_FLAGS="--mode=tb --tile=1100" python3 tests/test_exact.py ./$b | tail -1 | tee -a bench/summary.txt
  done
  log "GPU differential v8 vs each v8b build (random inputs with planted carry chains, random K/tile):"
  for b in $GPU_ALL; do python3 tests/diff_engines.py ./bench/v8 ./$b 3 40 | tail -1 | tee -a bench/summary.txt; done
  log "GPU hybrid stress, palindromes inside windows, quiet regions, growth edge cases:"
  for b in ./cuda196_v8b bench/v8btqj12; do
    python3 tests/stress_hybrid.py $b 12 | tail -1 | tee -a bench/summary.txt
    python3 tests/pal_later.py $b 3 | tail -1 | tee -a bench/summary.txt
    python3 tests/quiet_bits.py $b 4 | tail -1 | tee -a bench/summary.txt
    python3 tests/test_growth_edge.py $b 40 | tail -1 | tee -a bench/summary.txt
  done
  R=$(ref_for $CK 2000)
  for cfg in v8b:1000 v8bq:1000 v8bj12:1000 v8bt:1100 v8btq:1100 v8btqj12:1100 v8:1000; do
    runcfg $cfg $CK 2000 bench/g2000.txt $START
    cmp -s bench/g2000.txt $R && log "$cfg +2000 == reference: PASS (replays=$(reps))" || log "$cfg +2000: MISMATCH"
  done
  log "mod-9 identity on the +2000 result:"; ./bench/mod9 $CK $START $R $((START + 2000)) | tee -a bench/summary.txt
  log "weekly cross-check tool (per-step kernel reproduces a later checkpoint):"
  tools/crosscheck.sh ./cuda196_v8b $CK $START $R $((START + 2000)) | tail -1 | tee -a bench/summary.txt
  ;;
big64)
  # 64-bit digit counts: start 48 digits below 2^31 and run 250 steps (crosses 2,147,483,648 digits
  # around step 116). Needs ~6 GB RAM for the reference and ~2.2 GB GPU memory; ~2.2 GB disk per file.
  BIG=${BIGDIR:-bench/big64}; mkdir -p $BIG; S=${STEPS:-250}
  [ -f $BIG/in.txt ] || ./bench/gen_digits 2147483600 196 $BIG/in.txt
  [ -f $BIG/ref_$S.txt ] || { echo "CPU reference, $S steps on 2.1e9 digits (tens of minutes)..."; ./bench/ref $BIG/in.txt $S $BIG/ref_$S.txt; }
  for cfg in v8b:1000 v8btqj12:1100; do
    runcfg $cfg $BIG/in.txt $S $BIG/out.txt 0 || { log "big64 $cfg: FAILED TO RUN"; continue; }
    d=$(grep -oE 'digits=[0-9]+' bench/last.txt | tail -1)
    cmp -s $BIG/out.txt $BIG/ref_$S.txt && log "big64 $cfg: 2,147,483,600 -> $d after $S steps == reference: PASS (replays=$(reps))" \
                                       || log "big64 $cfg: MISMATCH vs reference"
  done
  log "  (v8 would refuse this input: its limit is ~2.147e9 digits)"
  rm -f $BIG/out.txt
  ;;
ab)
  IN=${2:?checkpoint COPY}; IT=${3:?its iteration}; STEPS=${STEPS:-5000}; ROUNDS=${ROUNDS:-3}
  CFGS=${CFGS:-"v8:1000 v8b:1000 v8bq:1000 v8bj12:1000 v8bt:1000 v8bt:1100 v8btq:1100 v8btqj12:1100"}
  : > bench/ab.tsv
  runcfg v8:1000 $IN 500 bench/warm.txt $IT || true
  timed v8:1000 $IN $STEPS bench/ab_ref.txt $IT
  for r in $(seq 1 $ROUNDS); do
    for cfg in $CFGS; do
      timed $cfg $IN $STEPS bench/ab_out.txt $IT
      cmp -s bench/ab_out.txt bench/ab_ref.txt && ok=PASS || { ok=MISMATCH; log "$cfg round $r: OUTPUT MISMATCH vs v8:1000"; }
      J=$(awk -v w=$W -v u=$US 'BEGIN{ if (w == "NA") print "NA"; else printf "%.4f", w * u / 1000 }')
      printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" $cfg $r $US $W $MHZ $J $(reps) $ok | tee -a bench/ab.tsv
    done
  done
  log "A/B at $(basename $IN) iteration $IT, K=$K, $STEPS steps x $ROUNDS interleaved rounds (cfg: engine:tile)"
  log "  cfg              median_us/step  mean_us/step  vs v8:1000  mean_W  mean_MHz  mean_mJ/step  replays  outputs"
  base=$(awk -F'\t' '$1=="v8:1000"{print $3}' bench/ab.tsv | median)
  for cfg in $CFGS; do
    md=$(awk -F'\t' -v c=$cfg '$1==c{print $3}' bench/ab.tsv | median)
    mn=$(awk -F'\t' -v c=$cfg '$1==c{print $3}' bench/ab.tsv | mean)
    w=$(awk -F'\t' -v c=$cfg '$1==c && $4!="NA"{print $4}' bench/ab.tsv | mean)
    mz=$(awk -F'\t' -v c=$cfg '$1==c && $5!="NA"{print $5}' bench/ab.tsv | mean)
    mj=$(awk -F'\t' -v c=$cfg '$1==c && $6!="NA"{print $6}' bench/ab.tsv | mean)
    rp=$(awk -F'\t' -v c=$cfg '$1==c{s+=$7} END{print s}' bench/ab.tsv)
    ok=$(awk -F'\t' -v c=$cfg '$1==c && $8!="PASS"{bad++} END{print bad ? "MISMATCH" : "all PASS"}' bench/ab.tsv)
    rel=$(awk -v b=$base -v m=$md 'BEGIN{printf "%+.2f%%", (b / m - 1) * 100}')
    log "  $(printf '%-16s %14s %13s %11s %7s %9s %13s %8s  %s' $cfg $md $mn "$rel" $w $mz $mj $rp "$ok")"
  done
  log "  ('vs v8:1000' = speed change, positive = faster. Replays must be 0.)"
  ;;
sustained)
  IN=${2:?checkpoint COPY}; IT=${3:?its iteration}; CFG=${4:?config, e.g. v8btq:1100}; STEPS=${STEPS:-100000}
  for cfg in v8:1000 $CFG; do
    timed $cfg $IN $STEPS bench/sus_$cfg.txt $IT
    log "sustained $STEPS steps $cfg: device_us_per_step=$US mean_W=$W mean_MHz=$MHZ replays=$(reps)"
  done
  cmp -s bench/sus_v8:1000.txt bench/sus_$CFG.txt && log "  outputs identical: PASS" || log "  outputs DIFFER: MISMATCH"
  ;;
runmode)
  rm -rf bench/rm && mkdir -p bench/rm && cp $CK bench/rm/
  (cd bench/rm && ../../cuda196_v8b run $CK $START run --chunk=1000 --keep=2 --steps=3000 --tile=1000 2>> ../log.txt)
  R=$(ref_for $CK 3000)
  p=$(python3 -c "import json;print(json.load(open('bench/rm/run/latest.json'))['path'])")
  cmp -s bench/rm/$p $R && log "run mode +3000 == reference: PASS" || log "run mode: MISMATCH"
  python3 - <<'EOF' | tee -a bench/summary.txt
import hashlib, json, re
j = json.load(open('bench/rm/run/latest.json'))
d = re.sub(r'[^0-9]', '', open('bench/rm/' + j['path']).read())
print('latest.json digits-only sha256:', 'PASS' if hashlib.sha256(d.encode()).hexdigest() == j['sha256'] and len(d) == j['digits'] else 'MISMATCH',
      '| engine =', j.get('engine'))
EOF
  ./bench/mod9 $CK $START bench/rm/$p $((START + 3000)) | tee -a bench/summary.txt
  ./bench/isf bench/rm/$p $((START + 3000)) bench/rm/result.isf 2>&1 | tee -a bench/summary.txt
  ;;
*) echo "usage: $0 build|resources|gate|big64|ab FILE ITER|sustained FILE ITER CFG|runmode"; exit 1 ;;
esac
