#!/usr/bin/env python3
"""Crash-resumable, exact fixed-size chunks; no pretense of background execution by this assistant."""
import argparse, subprocess, pathlib, os, time, hashlib, json, sys
p=argparse.ArgumentParser()
p.add_argument('--input', required=True)
p.add_argument('--start',type=int,required=True)
p.add_argument('--chunk',type=int,default=20000)
p.add_argument('--batch',type=int,default=32)
p.add_argument('--output-dir',default='run')
p.add_argument('--max-chunks',type=int,default=0,help='0 means until stopped')
a=p.parse_args()
root=pathlib.Path(a.output_dir);root.mkdir(parents=True,exist_ok=True)
current=pathlib.Path(a.input).resolve()
it=a.start
if a.chunk<1:sys.exit('invalid chunk')
try:
    i=0
    while a.max_chunks==0 or i<a.max_chunks:
        nxt=it+a.chunk;final=root/f'checkpoint_{nxt}.txt'
        cmd=['./cuda196',str(current),str(a.chunk),str(final),str(it),str(a.batch)]
        t=time.perf_counter();subprocess.run(cmd,check=True)
        data=final.read_bytes().strip()
        if not data or any(x<48 or x>57 for x in data):raise RuntimeError('invalid checkpoint')
        record={'iteration':nxt,'digits':len(data),'elapsed_seconds':round(time.perf_counter()-t,4),'sha256':hashlib.sha256(data).hexdigest(),'path':str(final.resolve())}
        tmp=root/'latest.json.tmp';tmp.write_text(json.dumps(record,indent=2));os.replace(tmp,root/'latest.json')
        print(json.dumps(record),flush=True)
        current=final.resolve();it=nxt;i+=1
except KeyboardInterrupt:
    print('Stopped between chunks; resume with path+iteration in latest.json',file=sys.stderr)
