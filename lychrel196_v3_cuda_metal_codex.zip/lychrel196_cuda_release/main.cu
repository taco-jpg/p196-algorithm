#include <cuda_runtime.h>
#include <cstdio>
#include <cstdlib>
#include <cstdint>
#include <cstring>
#include <string>
#include <vector>
#include <fstream>
#include <iostream>
#include <chrono>
#include <algorithm>
#define CHECK(x) do { cudaError_t e=(x); if(e!=cudaSuccess){fprintf(stderr,"CUDA %s at %s:%d\n",cudaGetErrorString(e),__FILE__,__LINE__); exit(2);} }while(0)
static constexpr int THREADS=256;
__device__ __forceinline__ int hd(int n){return (n+1)/2;}
__device__ __forceinline__ int growth(const uint8_t *s,int n){for(int i=0;i<hd(n);i++){int v=s[i]; if(v!=9)return v>=10;} return 0;}
__device__ __forceinline__ int midcarry(const uint8_t *s,int n){for(int i=hd(n)-1;i>=0;i--){int v=s[i];if(v!=9)return v>=10;}return 0;}
__device__ __forceinline__ int lc(const uint8_t *s,int i){for(int j=i-1;j>=0;j--){int v=s[j];if(v!=9)return v>=10;}return 0;}
__device__ __forceinline__ int hc(const uint8_t *s,int n,int i,int mid){for(int j=i+1;j<n-hd(n);j++){int v=s[j];if(v!=9)return v>=10;}return mid;}
__device__ __forceinline__ int digit(int x){return x>=10?x-10:x;}
__device__ __forceinline__ int low(const uint8_t*s,int i){return digit(int(s[i])+lc(s,i));}
__device__ __forceinline__ int high(const uint8_t*s,int n,int i,int mid){return digit(int(s[i])+hc(s,n,i,mid));}
__global__ void step(const uint8_t *src,uint8_t *dst,const int *nIn,int *nOut,unsigned int *bad,int slot,int maxH){
  __shared__ int g,m,n;
  int tid=blockIdx.x*blockDim.x+threadIdx.x;
  if(threadIdx.x==0){n=*nIn;g=growth(src,n);m=midcarry(src,n);if(blockIdx.x==0)*nOut=n+g;}
  __syncthreads();
  int h=hd(n+g); if(tid>=h)return;
  int lo=0,hi=0, val=0, mismatch=0;
  if(g){
    if(tid==0){lo=low(src,0);val=lo+1;mismatch=lo!=1;}
    else if((n%2)==0 && tid==hd(n)){hi=high(src,n,hd(n)-1,m);val=2*hi;}
    else {lo=low(src,tid);hi=high(src,n,tid-1,m);val=lo+hi;mismatch=lo!=hi;}
  } else {
    if((n%2)!=0 && tid==hd(n)-1){lo=low(src,tid);val=2*lo;}
    else {lo=low(src,tid);hi=high(src,n,tid,m);val=lo+hi;mismatch=lo!=hi;}
  }
  dst[tid]=uint8_t(val);
  if(mismatch)atomicOr(bad+slot,1u);
}
static std::string readNumber(std::string f){if(f=="196")return "196";std::ifstream in(f);if(!in)throw std::runtime_error("cannot open input");std::string s;std::getline(in,s);if(!s.empty()&&s.back()=='\r')s.pop_back();if(s.empty()||s[0]=='0'||s.find_first_not_of("0123456789")!=std::string::npos)throw std::runtime_error("invalid positive decimal");return s;}
static std::vector<uint8_t> encode(const std::string &s){int n=s.size();std::vector<uint8_t> v((n+1)/2);for(int i=0;i<(int)v.size();i++)v[i]=s[n-1-i]+s[i]-'0'-'0';return v;}
static int carryGrow(const std::vector<uint8_t>&s){for(auto x:s)if(x!=9)return x>=10;return 0;}
static std::string materialize(const std::vector<uint8_t>&s,int n){int g=carryGrow(s), nn=n+g;std::string v(nn,'0');int c=0;for(int i=0;i<n;i++){int a=s[std::min(i,n-1-i)]+c;v[nn-1-i]=char('0'+a%10);c=a/10;}if(g)v[0]='1';if(c!=g)throw std::runtime_error("materialize carry mismatch");return v;}
static std::string cpuStep(const std::string &s){int n=s.size(),c=0;std::string v(n,'0');for(int i=0;i<n;i++){int z=s[i]+s[n-1-i]-'0'-'0'+c;v[n-1-i]=char('0'+z%10);c=z/10;}if(c)v.insert(v.begin(),'1');return v;}
static void writeFile(const std::string&f,const std::string&s){std::string tmp=f+".tmp";{std::ofstream out(tmp,std::ios::binary);if(!out)throw std::runtime_error("cannot write "+tmp);out<<s<<'\n';if(!out)throw std::runtime_error("write failed");}if(std::rename(tmp.c_str(),f.c_str()))throw std::runtime_error("rename failed");}
int main(int argc,char**argv){
 try{
  if(argc<4){fprintf(stderr,"usage: %s INPUT(196|decimal.txt) STEPS OUTPUT [START_ITER=0] [BATCH=32] [CHECKPOINT_INTERVAL=0]\n",argv[0]);return 1;}
  auto input=readNumber(argv[1]);int steps=std::stoi(argv[2]);std::string output=argv[3];long long start=argc>4?std::stoll(argv[4]):0;int batch=argc>5?std::stoi(argv[5]):32;int save=argc>6?std::stoi(argv[6]):0;
  if(steps<0||batch<1||batch>512||save<0||input.size()+size_t(steps)>UINT32_MAX-100)throw std::runtime_error("bad arguments");
  int device;CHECK(cudaGetDevice(&device));cudaDeviceProp prop;CHECK(cudaGetDeviceProperties(&prop,device));std::cerr<<"GPU "<<prop.name<<" input_digits="<<input.size()<<" steps="<<steps<<" batch="<<batch<<"\n";
  int maxH=(int(input.size())+steps+1)/2+2;size_t bytes=maxH;
  uint8_t *s[2];int *n[2];unsigned *dBad;CHECK(cudaMalloc(&s[0],bytes));CHECK(cudaMalloc(&s[1],bytes));CHECK(cudaMalloc(&n[0],sizeof(int)));CHECK(cudaMalloc(&n[1],sizeof(int)));CHECK(cudaMalloc(&dBad,sizeof(unsigned)*batch));
  auto packed=encode(input);int initN=input.size();CHECK(cudaMemcpy(s[0],packed.data(),packed.size(),cudaMemcpyHostToDevice));CHECK(cudaMemcpy(n[0],&initN,sizeof(int),cudaMemcpyHostToDevice));
  cudaStream_t stream;CHECK(cudaStreamCreate(&stream));
  std::vector<unsigned> bad(batch);int current=0,done=0;bool found=false;auto beginning=std::chrono::steady_clock::now();
  // Capture fixed-size batches so launch overhead is paid once per batch.
  // n[] is a DEVICE-side dynamic length; each step reads the previous step's length.
  cudaGraph_t graph=nullptr;cudaGraphExec_t exec=nullptr;
  if(steps>=batch){
    CHECK(cudaStreamBeginCapture(stream,cudaStreamCaptureModeGlobal));CHECK(cudaMemsetAsync(dBad,0,batch*sizeof(unsigned),stream));
    for(int i=0;i<batch;i++){
      step<<<(maxH+THREADS-1)/THREADS,THREADS,0,stream>>>(s[i%2],s[1-i%2],n[i%2],n[1-i%2],dBad,i,maxH);
    }
    CHECK(cudaStreamEndCapture(stream,&graph));CHECK(cudaGraphInstantiate(&exec,graph,0));
  }
  // Avoid an enormous overdispatch when computing a few initial digits. Restart graph per chunk for throughput.
  while(done<steps){
    int count=std::min(batch,steps-done);
    if(count==batch){
      // A batch starts at s[current]. Captured kernel 0 always starts from s[0].
      // For odd batch sizes, capture a matching alternate graph below by fallback.
      if(current==0){CHECK(cudaGraphLaunch(exec,stream));}
      else {
        CHECK(cudaMemsetAsync(dBad,0,count*sizeof(unsigned),stream));
        for(int i=0;i<count;i++){int from=(current+i)%2;step<<<(maxH+THREADS-1)/THREADS,THREADS,0,stream>>>(s[from],s[1-from],n[from],n[1-from],dBad,i,maxH);}
      }
    }else{
      CHECK(cudaMemsetAsync(dBad,0,count*sizeof(unsigned),stream));
      for(int i=0;i<count;i++){int from=(current+i)%2;step<<<(maxH+THREADS-1)/THREADS,THREADS,0,stream>>>(s[from],s[1-from],n[from],n[1-from],dBad,i,maxH);}
    }
    CHECK(cudaMemcpyAsync(bad.data(),dBad,count*sizeof(unsigned),cudaMemcpyDeviceToHost,stream));CHECK(cudaStreamSynchronize(stream));
    for(int i=0;i<count;i++)if(!bad[i]){fprintf(stderr,"PALINDROME FLAG at iteration %lld (batch step %d); verify checkpoint separately\n",start+done+i+1,i+1);found=true;}
    done+=count;current=(current+count)%2;
    if((save&&done%save==0)||done==steps||found){
      int previous=1-current;int digits=0;CHECK(cudaMemcpy(&digits,n[previous],sizeof(int),cudaMemcpyDeviceToHost));std::vector<uint8_t> state((digits+1)/2);CHECK(cudaMemcpy(state.data(),s[previous],state.size(),cudaMemcpyDeviceToHost));
      auto reconstructed=materialize(state,digits);
      // prev state S_(k-1) reconstructs exactly N_k; see materialize().
      std::string filename=done==steps?output:output+".next_"+std::to_string(start+done)+".txt";
      writeFile(filename,reconstructed);
      double elapsed=std::chrono::duration<double>(std::chrono::steady_clock::now()-beginning).count();
      std::cerr<<"processed="<<done<<" state_iteration="<<start+done<<" output_iteration="<<start+done<<" digits="<<reconstructed.size()<<" seconds="<<elapsed<<"\n";
    }
    if(found)break;
  }
  if(exec)cudaGraphExecDestroy(exec);if(graph)cudaGraphDestroy(graph);CHECK(cudaStreamDestroy(stream));CHECK(cudaFree(s[0]));CHECK(cudaFree(s[1]));CHECK(cudaFree(n[0]));CHECK(cudaFree(n[1]));CHECK(cudaFree(dBad));
  return found?3:0;
 }catch(const std::exception &ex){fprintf(stderr,"ERROR %s\n",ex.what());return 2;}
}
