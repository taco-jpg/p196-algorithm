# 196 GPU 长跑版：CUDA 优先 / Metal 对照

## 为什么先选 CUDA

按照用户在 RTX 4050 与 M1 Max 的**同检查点实测**：20,000 步压缩 CUDA **0.828 秒**，压缩 Metal **1.207 秒**，CUDA 的纯计算吞吐量约 **1.46 倍**；包含 I/O 则为 1.237 vs 1.445 秒。此性能是**用户上一轮实测**，并非本压缩包 `main.cu` 的实测，更不能称后者一定更快。

本包 CUDA 以精确的对称数位和 S 和进位计算为基础，增加可捕获 CUDA Graph 的批量提交、GPU 回文检测、可恢复的十进制检查点、自动连续分段运行。Graph 可能减少主机每步调度费用，但没有在本容器完成 CUDA 编译和性能基准。Metal 代码作为已有版本供对照，非这次重新验证的 GPU 成品。

## RTX 4050：编译

需要 Linux NVIDIA 驱动和 CUDA Toolkit（包含 nvcc），推荐先在 base-node 测试。运行：

```bash
nvcc -O3 -std=c++17 -arch=sm_89 main.cu -o cuda196
python3 verify_math.py
./cuda196 196 1000 check_1000.txt 0 32
python3 - <<'PY'
s='196'
for _ in range(1000): s=str(int(s)+int(s[::-1]))
a=open('check_1000.txt').read().strip()
assert a==s
print('CUDA 1000-step end-to-end PASS')
PY
```

CUDA Graph 每批默认 32 步。每个 GPU 线程组扫描输入前缀以取得动态增长/中点进位；在每个位置寻找最近一个 `S!=9` 的进位决定点，无截断近似。一次 batch 内每一步由同一 stream 的内核顺序保证精确依赖。回文标记来自 GPU 并在每个 batch 传回主机。回文标记如果出现，当前批可能执行到末尾，程序用非零退出码停止，不会把它隐瞒。

**重要**：任何正式长跑，必须先完成 GPU 端 1000 步参考比对。不能仅凭 `verify_math.py` 的 CPU 模拟成功就认定 CUDA 编译或运行正确。

## 从真实检查点继续

本包附带第 **4,942,464 步**、**2,046,548 位**的真实十进制检查点。下面只跑 20,000 步：

```bash
./cuda196 checkpoint_4942464.txt 20000 cuda_4962464.txt 4942464 32
```

预期输出所标记的迭代是 **4,962,464**，不是多加或少加一步。压缩状态 S_k 是 N_k 的对称和，必须用上一次状态 S_(k-1) 重构 N_k，因此本程序专门从 ping-pong 双缓冲中读取**前一状态**完成检查点。输入位数与输出步数会在 stderr 显示。

长跑建议分段执行，避免为很大的总迭代数预先申请过多显存，也便于中断后恢复：

```bash
python3 run_forever.py --input checkpoint_4942464.txt --start 4942464 --chunk 20000 --batch 32 --output-dir run
```

会持续生成 `run/checkpoint_<iteration>.txt` 和 `run/latest.json`。要恢复，查看 `latest.json`，以里面的 path/iteration 作为新的 --input/--start。不要尝试由当前这份聊天直接持续后台运行，真正长跑由本地终端或 Codex 部署执行。

## Metal 对照

在 M1 Max 上可使用附带的 Metal 源代码进行对照测试：

```bash
xcrun -sdk macosx metal -c pair_step_optimized.metal -o pair_step.air
xcrun -sdk macosx metallib pair_step.air -o pair_step.metallib
swiftc -O -framework Metal RunMetal.swift -o run_metal
./run_metal checkpoint_4942464.txt 20000 metal_4962464.txt one 4942464
cmp metal_4962464.txt cuda_4962464.txt  # 比较之前先把 CUDA 文件复制到 Mac
```

这份 Metal 代码沿用此前研究工程；它尚未在当前执行环境的 Apple GPU 上重新测试。跨平台比较应在相同检查点、相同步数、相同输出条件下完成。

## Codex 的建议任务

1. 先编译运行 CUDA 1000 步，从 196 与 Python 精确版本对照，再从检查点进行 20,000 步端点与 Metal 对照。
2. 测 `batch=16/32/64/128`，记录 GPU kernel-only、batch 同步、读取输出全部耗时；与用户现有 0.828 秒 CUDA 基线**在同一输入上复测**，新版落后就回退旧版。
3. 优先改造 kernel：避免每个线程组重复扫描增长和中点进位；尝试一次 block 统一进位预计算，再进行 step 更新。做严格 AB 验证再保留。
4. 只有通过跨平台验证后，才开启 `run_forever.py` 长跑。遇到回文立即停并 CPU 复核；定期哈希校验，保存原始数字及迭代号。
5. 不要宣称本包已实现 16 步时间分块，当前 GPU 代码仍是精确的一步一内核 + 多步 Graph 批处理。

## 已确认 / 未确认

- **已完成**：CUDA kernel 与 host 程序的源码、图提交路径、检查点逻辑设计；Python CPU 数学模拟通过 10,000 组随机两步试验、196 的前 1000 步和边界案例。
- **未完成**：当前环境无 `nvcc` 和 NVIDIA GPU，无法声称新的 CUDA 工程已经编译运行、更没有证明超越用户既有的 0.828 秒成绩。
- **长期目标**：大幅减少每步 GPU 全局内核同步，完整实现经认证的时间分块；目前仍属后续工程任务。
