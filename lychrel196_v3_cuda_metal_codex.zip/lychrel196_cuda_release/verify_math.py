import random

def enc(a):
    return [int(a[i])+int(a[-1-i]) for i in range((len(a)+1)//2)]
def ref(a):
    return str(int(a)+int(a[::-1]))
def calc(s,n):
    h=(n+1)//2
    def carrylow(i):
        for j in range(i-1,-1,-1):
            if s[j]!=9:return int(s[j]>=10)
        return 0
    def carryhi(i):
        for j in range(i+1,n-h):
            if s[j]!=9:return int(s[j]>=10)
        for j in range(h-1,-1,-1):
            if s[j]!=9:return int(s[j]>=10)
        return 0
    def lo(i):return (s[i]+carrylow(i))%10
    def hi(i):return (s[i]+carryhi(i))%10
    g=0
    for x in s:
        if x!=9:g=int(x>=10);break
    nn=n+g
    result=[];mismatch=0
    for i in range((nn+1)//2):
        if g:
            if i==0:
                v=lo(0)+1;mismatch|=(lo(0)!=1)
            elif n%2==0 and i==h:
                v=2*hi(h-1)
            else:
                v=lo(i)+hi(i-1);mismatch|=(lo(i)!=hi(i-1))
        else:
            if n%2==1 and i==h-1:v=2*lo(i)
            else:
                v=lo(i)+hi(i);mismatch|=(lo(i)!=hi(i))
        result.append(v)
    return result,nn,mismatch

def reconst(s,n):
    c=0;little=[]
    for i in range(n):
        z=s[min(i,n-1-i)]+c
        little.append(str(z%10));c=z//10
    if c:little.append('1')
    return ''.join(reversed(little))

def test(a,k):
    for _ in range(k):
        s=enc(a);v,n,bad=calc(s,len(a));r=ref(a)
        assert (v,n)==(enc(r),len(r)),(a,r,v)
        assert bool(bad)==(r!=r[::-1]),(a,r,bad)
        assert reconst(s,len(a))==r
        a=r
random.seed(196)
for i in range(10000):
    n=random.randint(1,80)
    a=str(random.randint(1,9))+''.join(str(random.randint(0,9)) for _ in range(n-1))
    test(a,2)
test('196',1000)
for a in ['9','99','1000','101','1991','209','99999','1000000001','909090900090909','5','19','110','999999999999']:
    test(a,12)
print('PASS: 10k random two-step trials, 196 1000 iterations, edge cases; outputs, lengths and palindrome flags exact')
