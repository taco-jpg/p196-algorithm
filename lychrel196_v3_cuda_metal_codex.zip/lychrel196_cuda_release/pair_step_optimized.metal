#include <metal_stdlib>
using namespace metal;

// Exact 196 reverse-and-add GPU kernel.  Each symmetric pair is independent
// once its inbound carry is found.  Carries are determined by the nearest
// paired-digit sum != 9; the scans have no approximate cutoff.
// Values are S[i] = digit[i] + digit[n-1-i], i=0..ceil(n/2)-1.

inline uint half(uint n){return (n+1u)/2u;}
inline bool getGrowth(const device uchar* s,uint n){
    for(uint i=0;i<half(n);++i){uchar v=s[i];if(v!=9u)return v>=10u;}
    return false;
}
inline uint getMiddleCarry(const device uchar* s,uint n){
    for(uint i=half(n);i>0u;){uchar v=s[--i];if(v!=9u)return v>=10u;}
    return 0u;
}
inline uint getLowCarry(const device uchar* s,uint i){
    while(i>0u){uchar v=s[--i];if(v!=9u)return v>=10u;}
    return 0u;
}
inline uint getHighCarry(const device uchar* s,uint n,uint i,uint mid){
    uint e=n-half(n);
    for(uint j=i+1u;j<e;++j){uchar v=s[j];if(v!=9u)return v>=10u;}
    return mid;
}
inline uchar mod10small(uint v){return uchar(v>=10u?v-10u:v);}
inline uchar lowDigit(const device uchar* s,uint i){
    return mod10small(uint(s[i])+getLowCarry(s,i));
}
inline uchar highDigit(const device uchar* s,uint n,uint i,uint mid){
    return mod10small(uint(s[i])+getHighCarry(s,n,i,mid));
}
inline uchar nextAt(const device uchar* s,uint n,bool grows,uint mid,uint i){
    uint h=half(n);
    if(grows){
        if(i==0u)return uchar(uint(lowDigit(s,0u))+1u);
        if((n&1u)==0u&&i==h)return uchar(2u*uint(highDigit(s,n,h-1u,mid)));
        return uchar(uint(lowDigit(s,i))+uint(highDigit(s,n,i-1u,mid)));
    }
    if((n&1u)!=0u&&i==h-1u)return uchar(2u*uint(lowDigit(s,i)));
    return uchar(uint(lowDigit(s,i))+uint(highDigit(s,n,i,mid)));
}
inline bool nextMismatch(const device uchar* s,uint n,bool grows,uint mid,uint i){
    uint h=half(n);
    if(grows){
        if(i==0u)return lowDigit(s,0u)!=1u;
        if((n&1u)==0u&&i==h)return false;
        return lowDigit(s,i)!=highDigit(s,n,i-1u,mid);
    }
    if((n&1u)!=0u&&i==h-1u)return false;
    return lowDigit(s,i)!=highDigit(s,n,i,mid);
}

// On-demand second-step S1 access. Neither S1 nor a full intermediate number
// is ever allocated. Slow on CPU; an experimental GPU launch-saving option.
inline uint secondGrowth(const device uchar*s,uint n,bool g,uint mid){
    uint n1=n+uint(g);
    for(uint i=0u;i<half(n1);++i){uint x=nextAt(s,n,g,mid,i);if(x!=9u)return x>=10u;}
    return 0u;
}
inline uint secondMiddle(const device uchar*s,uint n,bool g,uint mid){
    uint n1=n+uint(g);
    for(uint i=half(n1);i>0u;){uint x=nextAt(s,n,g,mid,--i);if(x!=9u)return x>=10u;}
    return 0u;
}
inline uint secondLowCarry(const device uchar*s,uint n,bool g,uint mid,uint i){
    while(i>0u){uint x=nextAt(s,n,g,mid,--i);if(x!=9u)return x>=10u;}
    return 0u;
}
inline uint secondHighCarry(const device uchar*s,uint n,bool g,uint mid,uint i,uint mid1){
    uint n1=n+uint(g),e=n1-half(n1);
    for(uint j=i+1u;j<e;++j){uint x=nextAt(s,n,g,mid,j);if(x!=9u)return x>=10u;}
    return mid1;
}
inline uchar low2(const device uchar*s,uint n,bool g,uint mid,uint i){
    return mod10small(uint(nextAt(s,n,g,mid,i))+secondLowCarry(s,n,g,mid,i));
}
inline uchar high2(const device uchar*s,uint n,bool g,uint mid,uint i,uint mid1){
    return mod10small(uint(nextAt(s,n,g,mid,i))+secondHighCarry(s,n,g,mid,i,mid1));
}
inline uchar secondAt(const device uchar*s,uint n,bool g,uint mid,bool g2,uint mid1,uint i){
    uint n1=n+uint(g),h1=half(n1);
    if(g2){
        if(i==0u)return uchar(uint(low2(s,n,g,mid,0u))+1u);
        if((n1&1u)==0u&&i==h1)return uchar(2u*uint(high2(s,n,g,mid,h1-1u,mid1)));
        return uchar(uint(low2(s,n,g,mid,i))+uint(high2(s,n,g,mid,i-1u,mid1)));
    }
    if((n1&1u)!=0u&&i==h1-1u)return uchar(2u*uint(low2(s,n,g,mid,i)));
    return uchar(uint(low2(s,n,g,mid,i))+uint(high2(s,n,g,mid,i,mid1)));
}
inline bool secondMismatch(const device uchar*s,uint n,bool g,uint mid,bool g2,uint mid1,uint i){
    uint n1=n+uint(g),h1=half(n1);
    if(g2){
        if(i==0u)return low2(s,n,g,mid,0u)!=1u;
        if((n1&1u)==0u&&i==h1)return false;
        return low2(s,n,g,mid,i)!=high2(s,n,g,mid,i-1u,mid1);
    }
    if((n1&1u)!=0u&&i==h1-1u)return false;
    return low2(s,n,g,mid,i)!=high2(s,n,g,mid,i,mid1);
}

// flags: per-threadgroup byte, 0 iff every pair in that group matches.
// This avoids atomic contention on a single global flag.
// Host MUST dispatch exactly 256 threads per threadgroup.
kernel void pair_one(
    const device uchar *src [[buffer(0)]],
    device uchar *dst [[buffer(1)]],
    const device uint *nIn [[buffer(2)]],
    device uint *nOut [[buffer(3)]],
    device uchar *flags [[buffer(4)]],
    constant uint &slot [[buffer(5)]],
    constant uint &groups [[buffer(6)]],
    uint tid [[thread_position_in_grid]],
    uint lid [[thread_index_in_threadgroup]],
    uint groupID [[threadgroup_position_in_grid]],
    uint simdLane [[thread_index_in_simdgroup]],
    uint simdID [[simdgroup_index_in_threadgroup]],
    uint simdWidth [[threads_per_simdgroup]])
{
    threadgroup uint sharedGrow;
    threadgroup uint sharedMid;
    threadgroup uchar simdMismatch[256];
    const uint n=nIn[0];
    if(lid==0u){
        sharedGrow=uint(getGrowth(src,n));
        sharedMid=getMiddleCarry(src,n);
        // Only ONE threadgroup writes the shared next-length scalar.
        if(groupID==0u)nOut[0]=n+sharedGrow;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    const bool g=sharedGrow!=0u;
    const uint m=sharedMid;
    const uint h=half(n),h2=half(n+uint(g));
    bool mismatch=false;
    if(tid<h2){
        // Compute each digit/carry only once: the original kernel independently
        // called nextAt and nextMismatch, recalculating both expensive probes.
        uchar out;
        if(g){
            if(tid==0u){
                const uchar lo=lowDigit(src,0u);
                out=uchar(uint(lo)+1u);
                mismatch=(lo!=1u);
            }else if((n&1u)==0u&&tid==h){
                out=uchar(2u*uint(highDigit(src,n,h-1u,m)));
            }else{
                const uchar lo=lowDigit(src,tid);
                const uchar hi=highDigit(src,n,tid-1u,m);
                out=uchar(uint(lo)+uint(hi));
                mismatch=(lo!=hi);
            }
        }else if((n&1u)!=0u&&tid==h-1u){
            out=uchar(2u*uint(lowDigit(src,tid)));
        }else{
            const uchar lo=lowDigit(src,tid);
            const uchar hi=highDigit(src,n,tid,m);
            out=uchar(uint(lo)+uint(hi));
            mismatch=(lo!=hi);
        }
        dst[tid]=out;
    }
    // Reduce each SIMD group in hardware, then just 8-16 tiny group flags,
    // instead of all 256 lanes writing scratch and one lane scanning 256 bytes.
    const bool anyMismatch=simd_any(mismatch);
    if(simdLane==0u)simdMismatch[simdID]=uchar(anyMismatch);
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if(lid==0u){
        uchar bad=0;
        const uint groupsHere=(256u+simdWidth-1u)/simdWidth;
        for(uint k=0;k<groupsHere;++k)bad|=simdMismatch[k];
        flags[slot*groups+groupID]=bad;
    }
}

// Outputs S_{k+2} directly from S_k, no intermediate S_{k+1} in device memory.
// Bit 0: step k+1 has mismatch; bit 1: step k+2 has mismatch.
kernel void pair_two(
    const device uchar *src [[buffer(0)]],
    device uchar *dst [[buffer(1)]],
    const device uint *nIn [[buffer(2)]],
    device uint *nOut [[buffer(3)]],
    device uchar *flags [[buffer(4)]],
    constant uint &slot [[buffer(5)]],
    constant uint &groups [[buffer(6)]],
    uint tid [[thread_position_in_grid]],
    uint lid [[thread_index_in_threadgroup]],
    uint groupID [[threadgroup_position_in_grid]])
{
    threadgroup uint g1mem, m1mem, g2mem, m2mem;
    threadgroup uchar scratch[256];
    uint n=nIn[0];
    if(lid==0u){
        g1mem=uint(getGrowth(src,n));
        m1mem=getMiddleCarry(src,n);
        g2mem=secondGrowth(src,n,g1mem!=0u,m1mem);
        m2mem=secondMiddle(src,n,g1mem!=0u,m1mem);
        if(groupID==0u)nOut[0]=n+g1mem+g2mem;
    }
    threadgroup_barrier(mem_flags::mem_threadgroup);
    bool g1=g1mem!=0u,g2=g2mem!=0u;
    uint mid1=m1mem,mid2=m2mem;
    uint n1=n+uint(g1),h1=half(n1),h2=half(n1+uint(g2));
    uchar m=0;
    if(tid<h1 && nextMismatch(src,n,g1,mid1,tid))m|=1u;
    if(tid<h2){
        dst[tid]=secondAt(src,n,g1,mid1,g2,mid2,tid);
        if(secondMismatch(src,n,g1,mid1,g2,mid2,tid))m|=2u;
    }
    scratch[lid]=m;
    threadgroup_barrier(mem_flags::mem_threadgroup);
    if(lid==0u){
        uchar bad=0;
        for(uint k=0;k<256u;++k)bad|=scratch[k];
        flags[slot*groups+groupID]=bad;
    }
}
