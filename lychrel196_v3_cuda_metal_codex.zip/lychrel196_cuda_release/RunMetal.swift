import Foundation
import Metal

// macOS 14+ Apple Silicon. Build pair_step.metal into pair_step.metallib first.
// Usage: ./run_metal 196 10000 out.txt [one|two] [starting_iteration]
//   or : ./run_metal existing_checkpoint.txt 10000 out.txt one 4926464
// Results checked on CPU at the final checkpoint; all intermediate palindrome
// flags are generated on the GPU and checked at each command-buffer boundary.

func die(_ text: String) -> Never {
    fputs("ERROR: \(text)\n", stderr)
    exit(1)
}
func h(_ n: Int) -> Int {(n+1)/2}
func growth(_ s: [UInt8], _ n: Int) -> Bool {
    for i in 0..<h(n) where s[i] != 9 { return s[i] >= 10 }
    return false
}
func stateFromDecimal(_ bytes: [UInt8]) -> [UInt8] {
    let n = bytes.count
    var result = [UInt8](repeating: 0, count: h(n))
    for i in 0..<h(n) {result[i] = bytes[i] + bytes[n-1-i] - 96}
    return result
}
func materializeNext(_ raw: [UInt8], _ n: Int) -> [UInt8] {
    let g = growth(raw, n)
    let newN = n + (g ? 1 : 0)
    var digits = [UInt8](repeating: 48, count: newN)
    var carry = 0
    for i in 0..<n {
        let total = Int(raw[min(i,n-1-i)]) + carry
        digits[newN-1-i] = UInt8(48 + total % 10)
        carry = total / 10
    }
    if g {digits[0] = 49}
    if carry != (g ? 1 : 0) {die("internal: invalid carry after reconstruction")}
    return digits
}
func addReverse(_ a: [UInt8]) -> [UInt8] {
    let n=a.count
    var out=[UInt8](repeating:48,count:n)
    var carry=0
    for i in 0..<n {
        let s=Int(a[i]) + Int(a[n-1-i]) - 96 + carry
        out[n-1-i] = UInt8(48+s%10)
        carry=s/10
    }
    if carry != 0 {out.insert(49,at:0)}
    return out
}
func isPalindrome(_ digits: [UInt8]) -> Bool {
    for i in 0..<digits.count/2 {
        if digits[i] != digits[digits.count-1-i] {return false}
    }
    return true
}

let args=CommandLine.arguments
if args.count < 4 || args.count > 6 {
    die("usage: run_metal (196|input_decimal.txt) steps output_decimal.txt [one|two] [start_iteration]")
}
let inputArg=args[1]
guard let requestedSteps=Int(args[2]), requestedSteps>0 else {die("steps must be positive")}
let outputFile=args[3]
let mode=args.count>=5 ? args[4] : "one"
if mode != "one" && mode != "two" {die("mode must be one or two")}
let initialIteration = args.count>=6 ? (Int(args[5]) ?? -1) : 0
if initialIteration<0 {die("invalid start_iteration")}
let rawInput: String
if inputArg == "196" {rawInput="196"}
else {
    guard let text=try? String(contentsOf: URL(fileURLWithPath:inputArg),encoding:.utf8) else {die("cannot open input file")}
    rawInput=text.trimmingCharacters(in:.whitespacesAndNewlines)
}
let inputDigits=[UInt8](rawInput.utf8)
if inputDigits.isEmpty || inputDigits[0]==48 || inputDigits.contains(where:{$0<48 || $0>57}) {die("expected a positive decimal input without leading zeroes")}
if inputDigits.count + requestedSteps >= Int(UInt32.max) {die("digit count exceeds 32-bit GPU kernel limit")}

guard let device=MTLCreateSystemDefaultDevice() else {die("no Metal GPU available")}
guard let queue=device.makeCommandQueue() else {die("cannot create Metal command queue")}
let libraryURL=URL(fileURLWithPath: "pair_step.metallib")
guard let lib=try? device.makeLibrary(URL:libraryURL) else {die("cannot load pair_step.metallib (run from compiled directory)")}
let shaderName = mode == "one" ? "pair_one" : "pair_two"
guard let function=lib.makeFunction(name:shaderName) else {die("missing GPU function \(shaderName)")}
let pipeline: MTLComputePipelineState
let pipelineOne: MTLComputePipelineState
 do {
    pipeline = try device.makeComputePipelineState(function:function)
    guard let fnOne=lib.makeFunction(name:"pair_one") else {die("missing pair_one GPU kernel")}
    pipelineOne=try device.makeComputePipelineState(function:fnOne)
 } catch {die("cannot compile GPU pipeline: \(error)")}
let threadgroupSize=256
if pipeline.maxTotalThreadsPerThreadgroup < threadgroupSize {die("GPU does not support 256 threads per group")}
let initialN=inputDigits.count
let initialS=stateFromDecimal(inputDigits)
let maxH = h(initialN + requestedSteps) + 4  // Worst case: +1 digit each step.
let capacityGroups = (maxH + threadgroupSize - 1) / threadgroupSize
let maxOpsBatch=32
let flagBytes=maxOpsBatch*capacityGroups
func makeBuffer(_ bytes: Int) -> MTLBuffer {
    guard let v=device.makeBuffer(length:bytes,options:.storageModeShared) else {die("cannot allocate GPU buffer of \(bytes) bytes")}
    return v
}
let states=[makeBuffer(maxH),makeBuffer(maxH)]
let lengths=[makeBuffer(MemoryLayout<UInt32>.size),makeBuffer(MemoryLayout<UInt32>.size)]
let flagBuffer=makeBuffer(flagBytes)
let state0=states[0].contents().bindMemory(to:UInt8.self,capacity:maxH)
for i in 0..<initialS.count {state0[i]=initialS[i]}
lengths[0].contents().bindMemory(to:UInt32.self,capacity:1).pointee=UInt32(initialN)
let initialTime=ProcessInfo.processInfo.systemUptime
print("GPU=\(device.name) original_digits=\(initialN) mode=\(mode) steps=\(requestedSteps) capacity_groups=\(capacityGroups)")
var processed=0
var current=0
var palindromeAt: Int?=nil
var finalPrev=0
var finalStride=1
while processed < requestedSteps {
    guard let cb=queue.makeCommandBuffer() else {die("cannot allocate command buffer")}
    let remain=requestedSteps-processed
    let operations=min(maxOpsBatch,(remain + (mode=="two" ? 1:0))/(mode=="two" ? 2:1))
    let operationBase=processed
    let batchInputN=Int(lengths[current].contents().bindMemory(to:UInt32.self,capacity:1).pointee)
    let batchMaxSteps=min(remain,operations*(mode == "two" ? 2:1))
    let batchGroups=(h(batchInputN+batchMaxSteps)+threadgroupSize-1)/threadgroupSize
    let batchPaddedThreads=batchGroups*threadgroupSize
    var operationsStrides=[Int]()
    for op in 0..<operations {
        let previousOffset=operationsStrides.reduce(0,+)
        let stepStride=(mode=="two" && previousOffset+2<=remain) ? 2:1
        operationsStrides.append(stepStride)
        guard let enc=cb.makeComputeCommandEncoder() else {die("cannot create Metal compute encoder")}
        enc.setComputePipelineState(stepStride==2 ? pipeline:pipelineOne)
        enc.setBuffer(states[current],offset:0,index:0)
        enc.setBuffer(states[1-current],offset:0,index:1)
        enc.setBuffer(lengths[current],offset:0,index:2)
        enc.setBuffer(lengths[1-current],offset:0,index:3)
        enc.setBuffer(flagBuffer,offset:0,index:4)
        var slot=UInt32(op),groupCount=UInt32(batchGroups)
        enc.setBytes(&slot,length:MemoryLayout<UInt32>.size,index:5)
        enc.setBytes(&groupCount,length:MemoryLayout<UInt32>.size,index:6)
        enc.dispatchThreads(MTLSize(width:batchPaddedThreads,height:1,depth:1),
                            threadsPerThreadgroup:MTLSize(width:threadgroupSize,height:1,depth:1))
        enc.endEncoding()
        finalPrev=current
        finalStride=stepStride
        current=1-current
    }
    cb.commit()
    cb.waitUntilCompleted()
    if cb.status != .completed {die("Metal GPU execution failed: \(String(describing:cb.error))")}
    let flags=flagBuffer.contents().bindMemory(to:UInt8.self,capacity:flagBytes)
    var localStep=operationBase
    for op in 0..<operations {
        let stride=operationsStrides[op]
        var mismatchBits:UInt8=0
        for k in 0..<batchGroups {mismatchBits |= flags[op*batchGroups+k]}
        if stride==2 {
            if (mismatchBits & 1) == 0 && palindromeAt==nil {palindromeAt=initialIteration+localStep+1}
            if (mismatchBits & 2) == 0 && palindromeAt==nil {palindromeAt=initialIteration+localStep+2}
        } else {
            if (mismatchBits & 1) == 0 && palindromeAt==nil {palindromeAt=initialIteration+localStep+1}
        }
        localStep += stride
    }
    processed=localStep
    let nextN=lengths[current].contents().bindMemory(to:UInt32.self,capacity:1).pointee
    let time=ProcessInfo.processInfo.systemUptime-initialTime
    print("progress iterations=\(initialIteration+processed) digits=\(nextN) seconds=\(String(format:"%.3f",time)) palindrome=\(palindromeAt.map(String.init) ?? "none")")
    if palindromeAt != nil {break}
}
// Reconstruction of exact final full decimal integer from the last input state.
// For mode two, this performs the second reverse-add only once on CPU.
let prevN=Int(lengths[finalPrev].contents().bindMemory(to:UInt32.self,capacity:1).pointee)
let prevH=h(prevN)
let prevPointer=states[finalPrev].contents().bindMemory(to:UInt8.self,capacity:maxH)
let prevS=Array(UnsafeBufferPointer(start:prevPointer,count:prevH))
var output=materializeNext(prevS,prevN)
if finalStride==2 {output=addReverse(output)}
let currentN=Int(lengths[current].contents().bindMemory(to:UInt32.self,capacity:1).pointee)
if currentN != output.count {die("GPU/CPU reconstructed length mismatch")}
let currentPointer=states[current].contents().bindMemory(to:UInt8.self,capacity:maxH)
let cpuState=stateFromDecimal(output)
for i in 0..<cpuState.count {
    if currentPointer[i] != cpuState[i] {die("GPU/CPU pair-state mismatch at index \(i)")}
}
let palindrome=isPalindrome(output)
if palindrome && palindromeAt==nil {die("missing GPU palindrome flag")}
var save=Data(output)
save.append(10)
do {try save.write(to: URL(fileURLWithPath:outputFile),options:.atomic)}
catch {die("cannot write checkpoint: \(error)")}
print("FINAL global_iteration=\(initialIteration+processed) digits=\(output.count) palindromic=\(palindrome) gpu_cpu_validation=PASS output=\(outputFile)")
if let first=palindromeAt {print("PALINDROME CANDIDATE reported by GPU at iteration \(first); rerun from previous checkpoint with a shorter batch to materialize that exact step")}
