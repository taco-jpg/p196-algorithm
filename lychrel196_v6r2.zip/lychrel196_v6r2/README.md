# 196 reverse-and-add v6r2

```bash
nvcc -O3 -std=c++17 -arch=sm_89 cuda196_v6r2.cu -o cuda196_v6r2
./cuda196_v6r2 checkpoint_4942464.txt 20000 out.txt 4942464 256                  # benchmark (same CLI)
./cuda196_v6r2 run <checkpoint> <iteration> run_v6r2 --chunk=1000000 --keep=3     # long search
```

v6r with the warp-0 imbalance from the v6r profile removed: one inlined copy of the fast path (v6r had
two, which warps holding both kinds of group executed back to back), and the growth bit taken from
registers. Same exact arithmetic, CLI, checkpoint format and `latest.json` fields. See AGENT_TASK.md.

| file | purpose |
|---|---|
| `cuda196_v6r2.cu` | CUDA backend: v4 per-step kernel (fallback), time-blocked kernel, GPU event timing |
| `emu196_v6r2.cpp` | CPU emulator, same kernel code (`EMU_CERTCHECK=1` soundness; `-DTB_CHECK_GROWTH` self-check) |
| `bits_core.h` | v4 per-step arithmetic (GPU-validated, unchanged) |
| `bits_tb6r2.h` | time-blocked arithmetic, thread roles, certification |
| `driver6r2.h` | bench mode, run mode, verification windows, replay, timing |
| `prof.h` | `-DTB_PROF` phase profiler, `-DTB_WORK_REPEAT=2` ablation |
| `bench_v6r2.sh` | `build`, `resources`, `gate`, `big`, `small`, `sweep`, `runmode` |
| `tests/` | exactness suite, engine differential |
| `baseline_v6r/` | the production engine, for A/B |
| `tools/ref.c` | independent schoolbook reference |
