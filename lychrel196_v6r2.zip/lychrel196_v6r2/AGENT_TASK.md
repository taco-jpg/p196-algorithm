# Task for the local agent (RTX 4050): v6r2

Production is running v6r. v6r2 is a small follow-up. Switch only if it passes the gate **and** is
measurably faster than v6r at 28M digits, and only with the user's go-ahead.

**The GPU is busy with production.** Timings taken while production runs are invalid, and the
exactness gate would slow production. Ask the user before pausing it. To pause: create
`search/STOP` (it finishes the current million-step chunk and saves), run this task, then resume
from `latest.json` exactly as you documented.

## Why v6r2 (from your v6r profile)
At 28M digits a v6r block-step took 3,498 cycles. Warp 0 took 3,024 of them, while the other workers
took about 2,115 and then waited at the barrier. The compiled code shows why:
1. **The fast path was inlined twice.** v6r called it from two places: groups whose palindrome
   mismatches count (owned pairs) and groups whose mismatches don't (prefix tile and halo). Warp 0 holds
   both kinds (prefix + left halo + owned), and so does the last worker warp (owned + right halo). Those
   warps therefore ran both copies one after the other.
2. **Thread 0 re-read words 0..3 from shared memory** after writing them, to find the growth bit.

## What v6r2 changes (certified results identical to v6r/v5)
- One call site for the fast path. "Mismatch counts" is now a plain value. In the SASS here there is
  one fast-path copy instead of two (`resources` shows it as roughly half the BREV count).
- Thread 0 gets the growth bit from the new words still in its registers. If word 0 went through the
  general path (tiny numbers), it falls back to the old shared-memory search. The growth bit is still
  validated by the prefix tracker at the next step, so even a wrong value would only fail the block and
  replay it, never give a wrong result.
- Everything else is v6r: thread roles, tile rule, CLI, checkpoint format, run mode.
- The SASS check here (clang+ptxas) found 0 local loads, and the only local stores are on the out-of-line
  rare-call paths. 0 spills in all builds. `resources` checks your nvcc binaries.

## Verified in the CPU emulator (same kernel code)
- Exactness suite ALL PASS in 4 configurations (tb, tiny tile, two forced-failure setups), run with a
  self-check build that compares every register-derived growth bit against the shared-memory search
  and aborts on any difference. The check build is included (`bench/emu196_v6r2_check`).
- Soundness checker: 0 violations (19,994 certified + 4 failed; 30 + 7,971; 63,986 + 3), outputs == reference.
- Differential: v5 vs v6r2 100/100 identical (check build), v6r vs v6r2 60/60 identical.
- 2.05M +2,000 == reference; run mode 3 chunks == reference, latest.json hash correct.
- Not covered by any test input: the new number's first 128 pairs all summing to 9. That case is handled
  by inspection, and the tracker check above makes it safe either way.
- **Not yet run on a GPU.**

## Expected speed (an estimate)
If warp 0 drops to the other workers' ~2,115 cycles, the block-step drops from ~3,500 to roughly
2,300–2,600 cycles. That's about 1.3–1.5× v6r at 28M. The v6r estimate ("up to 2×") came in at 1.48×,
so treat this as a target to measure, not a promise.

## Steps
1. `./bench_v6r2.sh build` then `./bench_v6r2.sh resources`
2. `./bench_v6r2.sh gate`: step + 4 tb configurations, mb1/t512/prof builds, v6r-vs-v6r2 differential,
   every binary vs reference at +2,000, emulator self-check build. All must PASS.
3. `./bench_v6r2.sh big <COPY of a recent production checkpoint> <its iteration>`: v6r vs v6r2 at the
   production setting (K=128, tile=736) by GPU events, 3 interleaved runs, plus phase profiles.
   **The deciding number.** `TILEN=` sets a different v6r2 tile.
4. `./bench_v6r2.sh sweep <COPY> <iteration>`: report the best `device_us_per_step` with PASS and replays=0.
5. `./bench_v6r2.sh small` and `./bench_v6r2.sh runmode`
6. Send back `bench/summary.txt` and `bench/log.txt`. Then resume production (on v6r2 only if it won and
   the user agreed), from `latest.json`, with the same supervisor setup.

## Rules
- Benchmarks only on a copy of a checkpoint, never the live file.
- Every step's palindrome status is checked; certification failures replay.
- Measured numbers only.
