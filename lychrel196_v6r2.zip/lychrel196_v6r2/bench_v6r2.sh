#!/usr/bin/env bash
# v6r2 build, gate, A/B against v6r (the production engine), sweep and phase profile on the RTX 4050.
#   ./bench_v6r2.sh build              build all binaries
#   ./bench_v6r2.sh resources          registers / stack / local-memory instructions (tb_kernel section)
#   ./bench_v6r2.sh gate               exactness gate (must pass first)
#   ./bench_v6r2.sh big FILE ITER      28M COPY: v6r vs v6r2, 3 interleaved runs + phase profiles
#   ./bench_v6r2.sh small              2.05M checkpoint, 20,000 steps: v6r vs v6r2 + profiles
#   ./bench_v6r2.sh sweep FILE ITER    28M COPY: v6r2 K x tile x build (STEPS=2000 default)
#   ./bench_v6r2.sh runmode            finite run-mode check (3 chunks) against the reference
# Never point FILE at the live production checkpoint: use a copy. Do not stop production to run this
# unless the user agrees; the GPU is shared, so timings taken while production runs are not valid.
set -euo pipefail
ARCH=${ARCH:-sm_89}
CK=checkpoint_4942464.txt; START=4942464
NV="nvcc -O3 -std=c++17 -arch=$ARCH"
mkdir -p bench
log() { echo "$@" | tee -a bench/summary.txt; }
median() { sort -n | awk '{a[NR]=$1} END{print a[int((NR+1)/2)]}'; }
ref_for() {
  local f=bench/ref_$(basename $1)_$2.txt
  [ -f $f ] || { echo "building CPU reference ($2 steps)..." >&2; ./bench/ref $1 $2 $f; }
  echo $f
}
run1() {  # run1 BIN args... ; stderr -> bench/last.txt (+ appended to bench/log.txt)
  local b=$1; shift
  $b "$@" 2> bench/last.txt >/dev/null || { cat bench/last.txt; return 1; }
  cat bench/last.txt >> bench/log.txt
}
devus() { grep -oE 'device_us_per_step=[0-9.]+' bench/last.txt | tail -1 | cut -d= -f2; }
hostus() { grep -oE ' us_per_step=[0-9.]+' bench/last.txt | tail -1 | cut -d= -f2; }
tilev() { grep -oE ' tile=[0-9]+' bench/last.txt | head -1 | cut -d= -f2; }
proflines() { { grep '^\[prof\]' bench/last.txt || true; } | sed 's/^/    /' | tee -a bench/summary.txt; }
BINS="./cuda196_v6r2 bench/v6r2_p bench/v6r2_p2 bench/v6r2_mb1 bench/v6r2_t512 bench/v6r bench/v6r_p"
case "${1:-}" in
build)
  $NV cuda196_v6r2.cu -o cuda196_v6r2
  $NV -DTB_PROF cuda196_v6r2.cu -o bench/v6r2_p
  $NV -DTB_PROF -DTB_WORK_REPEAT=2 cuda196_v6r2.cu -o bench/v6r2_p2
  $NV -DTB_MINBLOCKS=1 cuda196_v6r2.cu -o bench/v6r2_mb1
  $NV -DTB_THREADS=512 cuda196_v6r2.cu -o bench/v6r2_t512
  (cd baseline_v6r && $NV cuda196_v6r.cu -o ../bench/v6r && $NV -DTB_PROF cuda196_v6r.cu -o ../bench/v6r_p)
  g++ -O3 -march=native -fopenmp -std=c++17 emu196_v6r2.cpp -o emu196_v6r2
  g++ -O3 -march=native -fopenmp -std=c++17 -DTB_CHECK_GROWTH emu196_v6r2.cpp -o bench/emu196_v6r2_check
  gcc -O2 tools/ref.c -o bench/ref
  ;;
resources)
  for b in $BINS; do
    ru=$(cuobjdump --dump-resource-usage $b 2>/dev/null | grep -A1 'tb_kernel' | grep -oE 'REG:[0-9]+|STACK:[0-9]+' | tr '\n' ' ')
    sec=$(cuobjdump -sass $b | awk '/Function : .*tb_kernel/{f=1; next} /Function : /{f=0} f')
    [ -n "$sec" ] || { log "$b: tb_kernel section not found in SASS"; continue; }
    log "$b: $ru STL=$(grep -c STL <<< "$sec" || true) LDL=$(grep -c LDL <<< "$sec" || true) BREV=$(grep -c BREV <<< "$sec" || true) SASS_lines=$(wc -l <<< "$sec")"
  done
  log "  (BREV count: v6r2 should show about half of v6r's, because the fast path is now inlined once)"
  ;;
gate)
  for f in "--mode=step" "--mode=tb" "--mode=tb --tile=4 --K=7" "--mode=tb --tile=4 --halo=4 --K=64 --window=128" \
           "--mode=tb --tile=8 --halo=4 --K=256 --window=512"; do
    log "GPU exactness suite v6r2: $f"
    ENGINE_FLAGS="$f" python3 tests/test_exact.py ./cuda196_v6r2 | tail -1 | tee -a bench/summary.txt
  done
  for b in bench/v6r2_mb1 bench/v6r2_t512 bench/v6r2_p; do
    log "GPU exactness suite (default tb) with $b"
    ENGINE_FLAGS="--mode=tb" python3 tests/test_exact.py ./$b | tail -1 | tee -a bench/summary.txt
  done
  log "GPU differential v6r vs v6r2 (random large inputs, random K/tile):"
  python3 tests/diff_engines.py ./bench/v6r ./cuda196_v6r2 1 100 | tail -1 | tee -a bench/summary.txt
  R=$(ref_for $CK 2000)
  for b in $BINS; do
    run1 $b $CK 2000 bench/g2000.txt $START
    cmp -s bench/g2000.txt $R && log "$b +2000 == reference: PASS" || log "$b +2000: MISMATCH"
  done
  run1 bench/emu196_v6r2_check $CK 2000 bench/e2000.txt $START
  cmp -s bench/e2000.txt $R && log "CPU emulator (growth self-check build) +2000 == reference: PASS" || log "emulator +2000: MISMATCH"
  grep -E 'growth-check' bench/last.txt | tee -a bench/summary.txt || true
  ;;
big|small)
  if [ "$1" = big ]; then IN=${2:?28M checkpoint COPY}; IT=${3:?its iteration}; STEPS=${STEPS:-2000}; K=${K:-128}; TP=${TILEP:-736}
  else IN=$CK; IT=$START; STEPS=${STEPS:-20000}; K=${K:-256}; TP=${TILEP:-0}; fi
  TN=${TILEN:-$TP}   # v6r2 tile; default = the production tile, so only the code differs
  R=$(ref_for $IN $STEPS)
  : > bench/dp.txt; : > bench/dn.txt
  run1 ./cuda196_v6r2 $IN 200 bench/warm.txt $IT $K --tile=$TN || true
  for r in 1 2 3; do
    run1 bench/v6r $IN $STEPS bench/op.txt $IT $K --tile=$TP
    cmp -s bench/op.txt $R || { log "v6r MISMATCH vs reference"; exit 1; }
    devus >> bench/dp.txt
    run1 ./cuda196_v6r2 $IN $STEPS bench/on.txt $IT $K --tile=$TN
    cmp -s bench/on.txt $R || { log "v6r2 MISMATCH vs reference"; exit 1; }
    devus >> bench/dn.txt
  done
  log "$1 ($STEPS steps, K=$K): GPU-event us/step median v6r=$(median < bench/dp.txt) (tile $TP) | v6r2=$(median < bench/dn.txt) (tile $TN) | all PASS vs reference"
  log "  runs v6r: $(tr '\n' ' ' < bench/dp.txt)| v6r2: $(tr '\n' ' ' < bench/dn.txt)"
  for b in bench/v6r_p bench/v6r2_p bench/v6r2_p2; do
    t=$TN; [ $b = bench/v6r_p ] && t=$TP
    run1 $b $IN $STEPS bench/oq.txt $IT $K --tile=$t
    cmp -s bench/oq.txt $R && ok=PASS || ok=MISMATCH
    log "  $b ($ok) GPU-event us/step=$(devus)"; proflines
  done
  ;;
sweep)
  IN=${2:?28M checkpoint COPY}; IT=${3:?its iteration}; STEPS=${STEPS:-2000}; R=$(ref_for $IN $STEPS)
  for b in ./cuda196_v6r2 bench/v6r2_mb1 bench/v6r2_t512; do
    for K in 128 256 512; do
      for T in 0 608 672 736 800 1600; do
        run1 $b $IN $STEPS bench/o_sw.txt $IT $K --tile=$T || { log "$b K=$K tile=$T FAILED"; continue; }
        cmp -s bench/o_sw.txt $R && ok=PASS || ok=MISMATCH
        log "$b K=$K tile=$T(used $(tilev)) $ok device_us_per_step=$(devus) $(grep -oE 'replays=[0-9]+' bench/last.txt | tail -1)"
      done
    done
  done
  ;;
runmode)
  rm -rf bench/rm && mkdir -p bench/rm && cp $CK bench/rm/
  (cd bench/rm && ../../cuda196_v6r2 run $CK $START run --chunk=1000 --keep=2 --steps=3000 2>> ../log.txt)
  R=$(ref_for $CK 3000)
  p=$(python3 -c "import json;print(json.load(open('bench/rm/run/latest.json'))['path'])")
  cmp -s bench/rm/$p $R && log "run mode +3000 == reference: PASS" || log "run mode: MISMATCH"
  python3 - <<'EOF' | tee -a bench/summary.txt
import hashlib, json, re
j = json.load(open('bench/rm/run/latest.json'))
d = re.sub(r'[^0-9]', '', open('bench/rm/' + j['path']).read())
print('latest.json digits-only sha256:', 'PASS' if hashlib.sha256(d.encode()).hexdigest() == j['sha256'] and len(d) == j['digits'] else 'MISMATCH')
EOF
  ;;
*) echo "usage: $0 build|resources|gate|big FILE ITER|small|sweep FILE ITER|runmode"; exit 1 ;;
esac
