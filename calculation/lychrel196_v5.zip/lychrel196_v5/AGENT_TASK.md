# Task for the local agent (RTX 4050) — v5

Context from the v4 round (your own measurements, 2,046,548-digit checkpoint, 20,000 steps):
v4 GPU kernel time 0.0816 s (4.08 µs/step) vs old zip 0.770 s and production `pair` 0.813 s —
about 9.5–10× on the GPU work, outputs byte-identical. Process wall was only 1.6–1.9× better because
~0.58 s of the 0.745 s went to process start + CUDA context creation, and ~0.08 s to conversion/file I/O.
`run_forever.py` pays that startup every chunk. The live search is at iteration 68,226,464 with
28,239,389 digits, so the 28M-digit size is what matters most.

v5 adds, on top of v4 (v4's per-step kernel is kept unchanged and used as the exact fallback):
1. **Run mode**: one long-lived process, state stays on the GPU, checkpoints are materialised and
   written by a background thread while the GPU keeps going, `latest.json` like run_forever.py,
   old checkpoints pruned (`--keep`).
2. **Time-blocked kernel** (`--mode=tb`, default): each block runs K steps (default 256) per launch in
   shared memory with an exactly-certified interval; any certification loss or palindrome flag makes the
   host restore the window and replay it with the v4 kernel.

Verified here without a GPU (CPU emulator runs the identical kernel code):
- `tests/test_exact.py` ALL PASS for `--mode=step`, `--mode=tb`, `--mode=tb --tile=4 --K=7`, and with a
  deliberately too-small halo (`--halo=4`) that forces certification failures and exact replays.
- Soundness check (`EMU_CERTCHECK=1`): every block that claimed certification was recomputed with the
  per-step kernel — thousands of certified blocks mixed with failed ones, **0 violations**.
- 2.05M checkpoint +2,000 steps (tb defaults) == reference; run mode on 196 and on the 2.05M checkpoint ==
  reference; latest.json sha256 correct; Ctrl-C stops cleanly after a consistent checkpoint.
- `cuda196_v5.cu` compiles for sm_89: tb_kernel 128 registers (TB_MINBLOCKS=2, 40-byte spill),
  v4 step kernel 60 registers. **Not yet run on a GPU.**

## Steps

1. `./bench_v5.sh gate` — builds everything and runs the exactness suite **on the GPU** in four
   configurations (including forced certification failures) plus GPU-vs-emulator and GPU-vs-reference at
   +2,000. Everything must PASS before any timing is reported. If nvcc needs a fix, do not change the
   arithmetic in `bits_core.h` / `bits_tb.h`; report what you changed.
2. `./bench_v5.sh small` — 2.05M checkpoint, 20,000 steps, 5 interleaved trials: v4, v5 `--mode=step`,
   v5 `--mode=tb`. Report process-wall medians and the internal `compute_seconds` / `us_per_step`.
3. `./bench_v5.sh sweep` — K ∈ {64,128,256,512} × tile ∈ {auto,256,512,800,960} × register cap
   (default build = 2 blocks/SM, `bench/cuda196_v5_mb1` = uncapped). Report the best and whether any run
   had `replays>0` (expected 0 with default halo).
4. `./bench_v5.sh big <28M checkpoint file> 68226464` — v4 vs v5-tb at the real search size, 2,000 steps,
   both checked against the CPU reference (~3 min to build). This is the most important number.
5. `./bench_v5.sh longrun` — 200,000 steps: run_forever.py + v4 (process per 20k chunk) vs v5 run mode;
   outputs must be identical. Set `FULLREF=1` to also check against the CPU reference (slow).
6. Report: medians, µs/step at 2M and 28M, best K/tile, long-run speedup, replay counts, and the
   sha256 of iteration 4,962,464 (expected `f60f6efb…7d413b` digits-only / `030875ad…92764` file).

Only after 1–5 pass, and only if the user asks: resume the search with
`./cuda196_v5 run <latest 28M checkpoint> 68226464 run_v5 --chunk=20000 --keep=3`.

## Rules
- Every step's palindrome status is checked (tb: per-step quiet counters; any flag → exact replay).
- Never add a carry-scan cutoff. Certification failures must stay failures (replay), never be ignored.
- Report measured numbers only; label estimates as estimates; keep v4 (or production) if v5 is slower.
