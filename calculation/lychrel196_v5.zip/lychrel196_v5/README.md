# 196 reverse-and-add v5: bit-sliced, time-blocked, persistent

```bash
nvcc -O3 -std=c++17 -arch=sm_89 cuda196_v5.cu -o cuda196_v5
# benchmark (same positional arguments as v4 / old main.cu)
./cuda196_v5 checkpoint_4942464.txt 20000 out.txt 4942464 256
# long search: one process, background checkpoints, latest.json, keeps the newest 3
./cuda196_v5 run checkpoint_68226464.txt 68226464 run_v5 --chunk=20000 --keep=3
```

## Where v4 stood (measured by your agent on the RTX 4050)

| 2,046,548 digits, 20,000 steps | GPU time | process wall |
|---|---|---|
| old zip kernel | 0.770 s | 1.209 s |
| production `pair` mode | 0.813 s | 1.445 s |
| v4 bit-sliced | **0.082 s** (4.1 µs/step) | 0.745 s |

The GPU work got ~10× faster, but most of the wall time was process start-up, CUDA context
creation and file conversion, which `run_forever.py` pays again every chunk.

## What v5 changes

**1. Run mode (certain win for long runs).** One process keeps the state on the GPU indefinitely.
At each checkpoint it copies only the needed words to the host. A background thread rebuilds the
decimal number, writes it atomically, hashes it (SHA-256, digits only, same as run_forever.py),
updates `latest.json` and prunes old files, while the GPU keeps computing. Ctrl-C stops after the
current chunk with a consistent checkpoint. Resume with the latest file and its iteration.

**2. Time-blocked kernel (`--mode=tb`, default).** In the folded bit-plane form, pair j of the next
state depends only on pairs j−1..j+1 plus runs of pair-sum 9. So each block loads a tile of
bit-planes into shared memory and runs K (default 256) steps before writing back: one launch per
256 steps instead of 256 launches.

- **Exactness.** Each tile tracks the interval it can prove exact. Each step the interval shrinks by
  one pair per side, plus any edge run of 9s, and the middle-carry scan must stay inside it. If it no
  longer covers the block's own pairs, the block flags failure. The host restores the window's
  backup and replays it with the unchanged v4 per-step kernel. With the default halo
  (1.25·K + 64 pairs) failures are not expected, but correctness never depends on that.
- **Growth.** The growth bit for each step depends only on the outermost pairs. Every block also
  simulates a small certified prefix tile and derives the growth bits from it, so blocks never
  synchronise with each other.
- **Palindromes.** Each step every block counts whether its own pairs all matched. A small kernel
  flags a step where all blocks matched. That window is replayed exactly and the palindrome is
  written out and re-checked on the CPU.
- **Carry chains.** Four 32-pair words per thread, with carry chains flowing word to word inside the
  thread.

## Verification done before handing over (CPU emulator runs the same kernel code)

- Exactness suite (2,000 small numbers, 300 adversarial runs of 9s, delayed palindromes at 24/55/261,
  checkpoint naming with odd batches): ALL PASS in step mode, tb mode, tiny tiles, and with a too-small
  halo that forces failures and replays.
- `EMU_CERTCHECK=1` soundness test: every certified block is recomputed with the per-step kernel.
  Across mixed runs (e.g. 2,071 certified + 429 failed blocks) there were **0 violations**.
- 2.05M checkpoint +2,000 (defaults) and run mode == independent reference; latest.json hash correct.
- Compiles for sm_89. **Not yet run on a GPU.** Speed is unmeasured; see AGENT_TASK.md.

## Knobs

`--K=` steps per launch (≤1024) · `--tile=` words per block (auto: cost model + occupancy) ·
`--halo=` words (auto) · `--window=` steps per verification window (default 8192) · `--mode=step` (v4
path only) · `--batch=` v4 graph batch · run mode: `--chunk=`, `--keep=`, `--steps=` (0 = until the
100M-step buffer horizon, then restart from latest.json). Build flag `-DTB_MINBLOCKS=1` removes the
register cap (174 regs, 1 block/SM) for A/B testing.

## Files

| file | purpose |
|---|---|
| `cuda196_v5.cu` | CUDA backend: v4 step kernel, tb kernel, finalize kernel, graphs, backups |
| `emu196_v5.cpp` | CPU emulator with the kernels' block/thread structure; `EMU_CERTCHECK=1` soundness mode |
| `bits_core.h` | v4 arithmetic (unchanged, GPU-validated) |
| `bits_tb.h` | time-blocked arithmetic, certification tracking, prefix growth, phase functions |
| `driver5.h` | bench mode, run mode, verification windows, replay, palindrome reporting |
| `sha256.h` | checkpoint hashes |
| `bench_v5.sh` | `gate`, `small`, `sweep`, `big FILE ITER`, `longrun` |
| `tests/test_exact.py` | exactness suite (`ENGINE_FLAGS` passes options) |
| `baseline_v4/` | v4 engine for comparison; `run_forever.py` drives it per chunk |
| `tools/ref.c` | independent schoolbook reference |
| `math/` | identity test and pure-Python bit-sliced prototype |

## If tb is not faster

The likely limits are (a) the serial certification and prefix work done by threads 0 and 1 each step,
(b) register pressure, and (c) one block per SM at large tiles. Next ideas: give tracking its own warp,
use 2 words per thread at small sizes, and use warp shuffles for neighbour words. The v4 kernel stays
available with `--mode=step`, and run mode helps either way.
