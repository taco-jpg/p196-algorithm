// bits_tb.h - time-blocked (many steps per launch) exact bit-plane engine.
// Shared verbatim by the CUDA kernel (cuda196_v5.cu) and the CPU emulator (emu196_v5.cpp).
//
// Same math as bits_core.h (v4, GPU-validated), reorganised for a block that keeps a tile of
// bit-planes in shared memory and runs K steps before writing back:
//  * step_group(): 4 consecutive words per thread; low/high carry chains flow word-to-word
//    inside the thread, so only one neighbour scan per direction per 4 words.
//  * Locality: pair j of the next state depends on pairs j-1..j+1 plus runs of pair-sum 9.
//    Each tile tracks its exactly-certified interval [L,R) (track_step). If after K steps it
//    no longer covers the pairs the block owns, the block raises `fail` and the host redoes the
//    window with the per-step v4 kernel. No approximation anywhere.
//  * Growth g_t depends only on the outermost pairs: every block also simulates a small prefix
//    tile [0, PW words) and derives g_{t+1} from it, so blocks never wait for each other.
#pragma once
#include "bits_core.h"

#if defined(__CUDA_ARCH__)
#define TB_UNROLL _Pragma("unroll")
#else
#define TB_UNROLL
#endif

namespace tb {
using bits::u32;
using bits::u64;

static const int KMAX = 1024;
static const int THREADS = 256;  // threads per block (CUDA launch and emulator agree)

struct View { const u32* s; int stride; int base; int len; };  // word k at s[q*stride + k-base]

BHD void vld(const View& v, int k, u32 p[5]) {
  int x = k - v.base;
  if (k < 0 || x < 0 || x >= v.len) { p[0] = p[1] = p[2] = p[3] = p[4] = 0; return; }
  TB_UNROLL
  for (int q = 0; q < 5; ++q) p[q] = v.s[q * v.stride + x];
}
BHD int is9(const View& v, int j) { u32 p[5]; vld(v, j >> 5, p); return (int)((bits::Pof(p) >> (j & 31)) & 1u); }
BHD int ge10(const View& v, int j) { u32 p[5]; vld(v, j >> 5, p); return (int)((bits::Gof(p) >> (j & 31)) & 1u); }

BHD u32 vlow_cin(const View& v, int k, const u32 prev[5]) {  // a_{32k}
  int j = k - 1;
  if (j < 0) return 0;
  int r = bits::low_summary(prev);
  while (r == 2) {
    if (--j < 0) return 0;
    u32 p[5]; vld(v, j, p);
    r = bits::low_summary(p);
  }
  return (u32)r;
}
BHD u32 vlow_bit(const View& v, int j) {  // a_j
  int k = j >> 5;
  u32 p[5], q[5];
  vld(v, k, p); vld(v, k - 1, q);
  u32 c = vlow_cin(v, k, q);
  u32 G = bits::Gof(p), X = G | bits::Pof(p);
  u64 t = (u64)X + G + c;
  return (((u32)t ^ X ^ G) >> (j & 31)) & 1u;
}
BHD u32 vmid_cin(const View& v, int n) { int h = (n + 1) / 2; return vlow_bit(v, (n % 2 == 0) ? h : h - 1); }
BHD u32 vhigh_cin(const View& v, int n, int k, const u32 next[5]) {  // b_{32k+31}
  int h = (n + 1) / 2, j = k + 1;
  if (32LL * j >= h) return vmid_cin(v, n);
  int r = bits::high_summary(next, j, h);
  while (r == 2) {
    ++j;
    if (32LL * j >= h) return vmid_cin(v, n);
    u32 p[5]; vld(v, j, p);
    r = bits::high_summary(p, j, h);
  }
  return (u32)r;
}
BHD u32 rangemask(int w, int lo, int hi) { return hi <= lo ? 0u : (bits::hmask(w, hi) & ~bits::hmask(w, lo)); }

// Words w0..w0+3 of the next state (same layout as v). Returns 1 on a palindrome mismatch
// among pairs in [mlo, mhi).
BHD u32 step_group(const View& v, u32* __restrict__ d, int n, int g, int w0, int mlo, int mhi) {
  const int C = 4;
  const int h = (n + 1) / 2;
  u32 p[C + 2][5];
  TB_UNROLL
  for (int i = 0; i < C + 2; ++i) vld(v, w0 - 1 + i, p[i]);
  u32 A[C], aO[C], B[C], bO[C];
  u32 cl = vlow_cin(v, w0, p[0]);
  TB_UNROLL
  for (int i = 0; i < C; ++i) {
    u32 G = bits::Gof(p[i + 1]), X = G | bits::Pof(p[i + 1]);
    u64 t = (u64)X + G + cl;
    A[i] = (u32)t ^ X ^ G; aO[i] = (u32)(t >> 32); cl = aO[i];
  }
  u32 ch = vhigh_cin(v, n, w0 + C - 1, p[C + 1]);
  TB_UNROLL
  for (int i = C - 1; i >= 0; --i) {
    const int w = w0 + i;
    u32 m = bits::hmask(w, h);
    u32 G = bits::Gof(p[i + 1]), X = G | bits::Pof(p[i + 1]);
    u32 Xr = bits::brev32(X | ~m), Gr = bits::brev32(G & m);
    u64 t = (u64)Xr + Gr + ch;
    B[i] = bits::brev32((u32)t ^ Xr ^ Gr); bO[i] = (u32)(t >> 32); ch = bO[i];
  }
  u32 mism = 0;
  TB_UNROLL
  for (int i = 0; i < C; ++i) {
    const int w = w0 + i;
    const u32* cw = p[i + 1];
    const u32 m = bits::hmask(w, h);
    const u32 a = A[i] & m, b = B[i] & m;
    const u32 aup = ((A[i] >> 1) | (aO[i] << 31)) & m;  // a_{j+1}
    const u32 bdn = ((b << 1) | bO[i]) & m;             // b_{j-1}
    u32 out[5];
    if (!g) {
      u32 t0 = a ^ b, t1 = a & b;
      u32 v0 = t0;
      u32 v1 = cw[0] ^ t1, cc = cw[0] & t1;
      u32 v2 = cw[1] ^ cc; cc &= cw[1];
      u32 v3 = cw[2] ^ cc; cc &= cw[2];
      u32 v4 = cw[3] ^ cc;
      u32 k1 = aup ^ bdn, k2 = aup & bdn;
      u32 r1 = v1 ^ k1, bo = ~v1 & k1;
      u32 dd = v2 ^ k2; u32 r2 = dd ^ bo; bo = (~v2 & k2) | (~dd & bo);
      dd = v3 ^ k1;     u32 r3 = dd ^ bo; bo = (~v3 & k1) | (~dd & bo);
      dd = v4 ^ k2;     u32 r4 = dd ^ bo;
      out[0] = v0 & m; out[1] = r1 & m; out[2] = r2 & m; out[3] = r3 & m; out[4] = r4 & m;
      mism |= ((a ^ b) & rangemask(w, mlo, mhi < h ? mhi : h)) != 0;
    } else {
      const int h1 = (n + 2) / 2;
      const u32 m1 = bits::hmask(w, h1);
      u32 lo[4], hi[4], hp[4], hs[4];
      bits::digit4(cw, a, aup, lo);
      bits::digit4(cw, b, bdn, hi);
      if (w == 0) { hp[0] = 1; hp[1] = hp[2] = hp[3] = 0; }
      else {  // high digit of pair 32w-1: S + b_{32w-1} - 10 b_{32w-2}
        int s = 0;
        TB_UNROLL
        for (int q = 0; q < 5; ++q) s |= (int)((p[i][q] >> 31) & 1u) << q;
        int bj = (int)bO[i], bj1 = (s >= 10) | ((s == 9) & bj);
        int hv = s + bj - 10 * bj1;
        if (hv < 0) hv = 0;  // only for pairs >= h (masked)
        TB_UNROLL
        for (int q = 0; q < 4; ++q) hp[q] = (u32)(hv >> q) & 1u;
      }
      TB_UNROLL
      for (int q = 0; q < 4; ++q) hs[q] = (hi[q] << 1) | hp[q];
      if (!(n & 1)) {
        int hb = h - 32 * w;
        if (hb >= 0 && hb < 32) {
          u32 bm = 1u << hb;
          TB_UNROLL
          for (int q = 0; q < 4; ++q) lo[q] = (lo[q] & ~bm) | (hs[q] & bm);
        }
      }
      const u32 rm = rangemask(w, mlo, mhi < h1 ? mhi : h1);
      u32 diff = 0, cc = 0;
      TB_UNROLL
      for (int q = 0; q < 4; ++q) {
        diff |= (lo[q] ^ hs[q]) & rm;
        u32 x = lo[q], y = hs[q];
        out[q] = (x ^ y ^ cc) & m1;
        cc = (x & y) | (cc & (x ^ y));
      }
      out[4] = cc & m1;
      mism |= diff != 0;
    }
    const int x = w - v.base;
    if (x >= 0 && x < v.len)
      TB_UNROLL
      for (int q = 0; q < 5; ++q) d[q * v.stride + x] = out[q];
  }
  return mism;
}

// ---- certified interval tracking (pair indices) ----
struct Track { int L, R, rightReal; };

// Interval of exact values after one step from values certified on [L,R). 0 = certification lost.
BHD int track_step(const View& v, Track& tr, int n, int g) {
  const int h = (n + 1) / 2;
  if (tr.rightReal) {  // middle carry scan (from pair h-1 down) must end inside certified data
    int q = h - 1;
    while (q >= tr.L && is9(v, q)) --q;
    if (q < tr.L && tr.L > 0) return 0;
  }
  int nL, nR;
  if (tr.L == 0) nL = 0;
  else {
    int q = tr.L;
    while (q < tr.R && is9(v, q)) ++q;
    if (q >= tr.R) return 0;
    nL = q + 1;
  }
  if (tr.rightReal) nR = (n + g + 1) / 2;
  else {
    int r = tr.R - 1;
    while (r >= tr.L && is9(v, r)) --r;
    if (r < tr.L) return 0;
    nR = g ? r + 1 : r;
  }
  tr.L = nL; tr.R = nR;
  return nL < nR;
}
// Growth of the next step from a left-anchored certified tile (first non-9 pair is >= 10).
BHD int growth_cert(const View& v, const Track& tr, int n, int* g) {
  const int h = (n + 1) / 2;
  for (int w = 0; w < 4; ++w) {
    u32 p[5]; vld(v, w, p);
    u32 nn = ~bits::Pof(p) & bits::hmask(w, h);
    if (nn) {
      int b = 0;
      while (!((nn >> b) & 1u)) ++b;
      int q = 32 * w + b;
      *g = (int)((bits::Gof(p) >> b) & 1u);
      return q < tr.R;
    }
  }
  *g = 0;  // no non-9 pair among the first 128
  return (h <= 128 && tr.rightReal && tr.R >= h);
}

// ---- tile geometry ----
BHD int halo_words(int K) { return ((K + K / 4 + 64 + 31) / 32 + 3) & ~3; }
BHD int len_max(int TW, int HW, int K) { return (TW + 2 * HW + K / 64 + 16 + 3) & ~3; }
BHD int prefix_words(int HW) { return HW + 4; }
BHD int plen_max(int PW, int K) { return (PW + K / 64 + 16 + 3) & ~3; }

struct Conf { int K, TW, HW, PW, lenMax, plenMax, Wcap; };

struct State {  // per block, in shared memory
  int n0, h0, maxw;
  int o0w, o1w, bw, len, plen;
  int dead, okT, okP;
  Track tr, ptr;
  int gS[KMAX + 1];
};
BHD size_t smem_bytes(const Conf& c) {
  return sizeof(State) + sizeof(u32) * 5 * 2 * (size_t)(c.lenMax + c.plenMax);
}
BHD u32* tile_buf(u32* base, const Conf& c, int parity) { return base + (size_t)parity * 5 * c.lenMax; }
BHD u32* pre_buf(u32* base, const Conf& c, int parity) {
  return base + (size_t)10 * c.lenMax + (size_t)parity * 5 * c.plenMax;
}
BHD View tile_view(const State& S, u32* base, const Conf& c, int parity) {
  View v; v.s = tile_buf(base, c, parity); v.stride = c.lenMax; v.base = S.bw; v.len = S.len; return v;
}
BHD View pre_view(const State& S, u32* base, const Conf& c, int parity) {
  View v; v.s = pre_buf(base, c, parity); v.stride = c.plenMax; v.base = 0; v.len = S.plen; return v;
}

// Phase 1 (thread 0): geometry of block `blk`.
BHD void ph_setup(State& S, const Conf& c, int blk, int n0) {
  S.n0 = n0;
  S.h0 = (n0 + 1) / 2;
  S.maxw = (S.h0 + c.K / 2 + 2 + 31) / 32;  // words that can hold data after K steps
  S.o0w = blk * c.TW;
  S.o1w = S.o0w + c.TW < c.Wcap ? S.o0w + c.TW : c.Wcap;
  S.dead = S.o0w >= S.maxw;
  int bw = S.o0w - c.HW;
  S.bw = bw < 0 ? 0 : (bw & ~3);
  long long R0 = 32LL * (S.o1w + c.HW);
  if (R0 > S.h0) R0 = S.h0;
  int rightReal = (R0 == S.h0);
  int endw = S.o1w + c.HW;
  if (rightReal && S.maxw + 1 > endw) endw = S.maxw + 1;
  S.len = ((endw - S.bw + 3) & ~3) + 4;
  S.tr.L = 32 * S.bw; S.tr.R = (int)R0; S.tr.rightReal = rightReal;
  long long pR0 = 32LL * c.PW;
  if (pR0 > S.h0) pR0 = S.h0;
  int prr = (pR0 == S.h0);
  int pend = c.PW;
  if (prr && S.maxw + 1 > pend) pend = S.maxw + 1;
  S.plen = ((pend + 3) & ~3) + 4;
  S.ptr.L = 0; S.ptr.R = (int)pR0; S.ptr.rightReal = prr;
  S.okT = S.okP = 1;
}
// Phase 2 (all threads): global -> shared.
BHD void ph_load(const State& S, const Conf& c, u32* base, const u32* src, int tid, int nth) {
  u32* t0 = tile_buf(base, c, 0);
  for (int i = tid; i < 5 * S.len; i += nth) {
    int q = i / S.len, x = i - q * S.len, k = S.bw + x;
    t0[q * c.lenMax + x] = k < c.Wcap ? src[(size_t)q * c.Wcap + k] : 0u;
  }
  u32* p0 = pre_buf(base, c, 0);
  for (int i = tid; i < 5 * S.plen; i += nth) {
    int q = i / S.plen, x = i - q * S.plen;
    p0[q * c.plenMax + x] = x < c.Wcap ? src[(size_t)q * c.Wcap + x] : 0u;
  }
}
// Phase 3 (thread 0): growth of the first step.
BHD void ph_init(State& S, const Conf& c, u32* base) {
  int g;
  if (!growth_cert(pre_view(S, base, c, 0), S.ptr, S.n0, &g)) S.okP = 0;
  S.gS[0] = g;
}
// Step t, before the barrier-free work: thread 1 tracks the tile, thread 0 the prefix.
BHD void ph_track(State& S, const Conf& c, u32* base, int t, int n, int tid) {
  const int g = S.gS[t];
  if (tid == 1 && S.okT) S.okT = track_step(tile_view(S, base, c, t & 1), S.tr, n, g);
  if (tid == 0 && S.okP) S.okP = track_step(pre_view(S, base, c, t & 1), S.ptr, n, g);
}
// Step t work for one thread. Thread 0 also derives g_{t+1} from the prefix tile.
BHD u32 ph_work(State& S, const Conf& c, u32* base, int t, int n, int tid, int nth) {
  const int g = S.gS[t], par = t & 1;
  const int h1 = (n + g + 1) / 2;
  const int plo = 32 * S.o0w;
  long long phl = 32LL * S.o1w;
  const int phi = phl < h1 ? (int)phl : h1;
  u32 mism = 0;
  {
    View a = tile_view(S, base, c, par);
    u32* d = tile_buf(base, c, par ^ 1);
    const int ng = S.len / 4;
    for (int gi = nth - 1 - tid; gi < ng; gi += nth) mism |= step_group(a, d, n, g, S.bw + 4 * gi, plo, phi);
  }
  {
    View a = pre_view(S, base, c, par);
    u32* d = pre_buf(base, c, par ^ 1);
    const int ng = S.plen / 4;
    for (int pg = tid; pg < ng; pg += nth) step_group(a, d, n, g, 4 * pg, 0, 0);
    if (tid == 0) {  // prefix words 0..3 of the new state were written by this thread just now
      int gn;
      if (!growth_cert(pre_view(S, base, c, par ^ 1), S.ptr, n + g, &gn)) { S.okP = 0; gn = 0; }
      S.gS[t + 1] = gn;
    }
  }
  return mism;
}
// After K steps (thread 0): certification verdict for the owned pairs.
BHD int ph_verdict(const State& S, int nK) {
  const int hK = (nK + 1) / 2;
  long long phl = 32LL * S.o1w;
  const int phi = phl < hK ? (int)phl : hK;
  return S.okT && S.okP && S.tr.L <= 32 * S.o0w && S.tr.R >= phi;
}
// Owned words -> global (all threads).
BHD void ph_store(const State& S, const Conf& c, u32* base, u32* dst, int K, int tid, int nth) {
  const u32* f = tile_buf(base, c, K & 1);
  for (int x = S.o0w + tid; x < S.o1w; x += nth)
    for (int q = 0; q < 5; ++q) dst[(size_t)q * c.Wcap + x] = f[q * c.lenMax + (x - S.bw)];
}

}  // namespace tb
