# Test two claims about one reverse-and-add step in pair-sum form.
#  S_j = d_j + d_{n-1-j}.  a_j = carry into low digit j, b_j = carry into high digit n-1-j.
#  Claim 1 (no growth):  S'_j = 2 S_j + a_j + b_j - 10 (a_{j+1} + b_{j-1})
#          (growth):     S'_j = (S_j + a_j - 10 a_{j+1}) + (S_{j-1} + b_{j-1} - 10 b_{j-2}),  "pair -1" := digit 1
#  Claim 2: N_{t+1} is a palindrome  <=>  a_j == b_j for every pair j   (no-growth steps)
import random, sys
def pairs(s): n=len(s); return [int(s[n-1-i])+int(s[i]) for i in range((n+1)//2)]
def carries(S, n):
    h=len(S); G=[x>=10 for x in S]; P=[x==9 for x in S]
    a=[0]*(h+1)
    for j in range(h): a[j+1]=int(G[j] or (P[j] and a[j]))
    b=[0]*h
    b[h-1] = a[h] if n%2==0 else a[h-1]
    for j in range(h-1,0,-1): b[j-1]=int(G[j] or (P[j] and b[j]))
    g = int(G[0] or (P[0] and b[0]))   # carry out of the top digit
    return a,b,g
def step_identity(S,n):
    h=len(S); a,b,g=carries(S,n)
    lo=lambda j: S[j]+a[j]-10*a[j+1]
    def hi(j):   # high digit of pair j
        if j==-1: return 1
        bm1 = g if j==0 else (lambda k: int(S[k]>=10 or (S[k]==9 and b[k])))(j)  # b_{j-1}
        return S[j]+b[j]-10*bm1
    if not g:
        out=[2*S[j]+a[j]+b[j]-10*(a[j+1]+(g if j==0 else int(S[j]>=10 or (S[j]==9 and b[j])))) for j in range(h)]
        if n%2: out[h-1]=2*lo(h-1)
        pal = all(a[j]==b[j] for j in range(h))
        return out,n,pal
    n1=n+1; h1=(n1+1)//2; out=[]
    for j in range(h1):
        if n%2==0 and j==h: out.append(2*hi(h-1))
        else: out.append(lo(j)+hi(j-1))
    return out,n1,None
random.seed(1); tested=pal_hits=0
for trial in range(200000):
    L=random.randint(1,40)
    s=str(random.randint(1,9))+''.join(random.choice('0123456789') for _ in range(L-1))
    if random.random()<0.3:  # bias toward long runs of pair-sum 9
        s=''.join(random.choice('0909345') for _ in range(L)).lstrip('0') or '9'
    r=str(int(s)+int(s[::-1]))
    out,n1,pal=step_identity(pairs(s),len(s))
    assert out==pairs(r) and n1==len(r),(s,r,out)
    if pal is not None:
        tested+=1; isp=(r==r[::-1]); pal_hits+=isp
        assert pal==isp,(s,r)
s='196'
for k in range(3000):
    out,n1,pal=step_identity(pairs(s),len(s)); r=str(int(s)+int(s[::-1]))
    assert out==pairs(r) and n1==len(r); s=r
print(f"identity OK on 200k random + 3000 steps of 196; palindrome<=>a==b OK on {tested} no-growth steps ({pal_hits} palindromes)")
