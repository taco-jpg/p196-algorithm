# Bit-sliced reverse-and-add: the whole number is 5 big integers (bit-planes of the
# pair sums S_j in 0..18). One step = boolean ops + two big binary additions
# (one per carry direction). No per-digit loop anywhere.
import sys, time
sys.set_int_max_str_digits(0)
REV = bytes(int(f'{i:08b}'[::-1], 2) for i in range(256))
def brev(x, nbits):                      # reverse the low nbits bits
    nb = (nbits + 7) // 8
    y = int.from_bytes(x.to_bytes(nb, 'little').translate(REV)[::-1], 'little')
    return y >> (8 * nb - nbits)
def add(xs, ys):                         # ripple adder on bit-plane lists
    out, c = [], 0
    for i in range(max(len(xs), len(ys))):
        x = xs[i] if i < len(xs) else 0; y = ys[i] if i < len(ys) else 0
        out.append(x ^ y ^ c); c = (x & y) | (c & (x ^ y))
    return out + [c]
def sub(xs, ys, mask):                   # xs - ys, result known >= 0
    out, bo = [], 0
    for i in range(len(xs)):
        x = xs[i]; y = ys[i] if i < len(ys) else 0
        d = x ^ y; out.append(d ^ bo); bo = ((~x & y) | (~d & bo)) & mask
    return out
def encode(s):
    n = len(s); h = (n + 1) // 2; planes = [0] * 5
    for j in range(h):
        v = int(s[n - 1 - j]) + int(s[j])
        for k in range(5):
            if v >> k & 1: planes[k] |= 1 << j
    return planes, n
def step(planes, n):
    h = (n + 1) // 2; M = (1 << h) - 1
    s0, s1, s2, s3, s4 = planes
    G = s4 | (s3 & (s2 | s1))                          # S >= 10
    P = ~s4 & s3 & ~s2 & ~s1 & s0 & M                  # S == 9
    X = G | P
    A = (X + G) ^ X ^ G                                # bit j = a_j (low carries), bit h = a_h
    a = A & M
    cin = (A >> h) & 1 if n % 2 == 0 else (A >> (h - 1)) & 1
    Gr, Pr = brev(G, h), brev(P, h); Xr = Gr | Pr
    Br = (Xr + Gr + cin) ^ Xr ^ Gr                     # high carries, reversed order
    b = brev(Br & M, h); g = (Br >> h) & 1             # g = carry out of top digit
    Aup = a >> 1 | (((A >> h) & 1) << (h - 1))          # a_{j+1}
    Bdn = ((b << 1) | g) & M                            # b_{j-1}
    if not g:
        pal = (a ^ b) == 0
        V = add([0, s0, s1, s2, s3, s4], [a ^ b, a & b])          # 2S + a + b
        k1, k2 = Aup ^ Bdn, Aup & Bdn                              # subtract 10*(Aup+Bdn)
        return sub(V, [0, k1, k2, k1, k2], M)[:5], n, pal
    lo = sub(add(planes, [a]), [0, Aup, 0, Aup], M)[:4]            # low digits  0..9
    hi = sub(add(planes, [b]), [0, Bdn, 0, Bdn], M)[:4]            # high digits 0..9
    n1 = n + 1; h1 = (n1 + 1) // 2; M1 = (1 << h1) - 1
    his = [((p << 1) & M1) | (1 if k == 0 else 0) for k, p in enumerate(hi)]  # hi_{j-1}, hi_{-1}=1
    if n % 2 == 0:                                                  # new centre = 2*hi_{h-1}
        lo = [p | (((q >> (h - 1)) & 1) << h) for p, q in zip(lo, hi)]
    pal = all(((x ^ y) & M1) == 0 for x, y in zip(lo, his))
    return add(lo, his)[:5], n1, pal
def decode_next(planes, n):              # pairs of N_k -> decimal N_{k+1}
    h = (n + 1) // 2
    S = [sum(((planes[k] >> j) & 1) << k for k in range(5)) for j in range(h)]
    c = 0; out = []
    for i in range(n):
        z = S[min(i, n - 1 - i)] + c; out.append(z % 10); c = z // 10
    if c: out.append(1)
    return ''.join(map(str, reversed(out)))

if __name__ == '__main__':
    # 1) 196 from scratch vs Python big integers
    s = '196'; pl, n = encode(s)
    for k in range(5000):
        r = str(int(s) + int(s[::-1]))
        assert decode_next(pl, n) == r, k
        pl2, n2, pal = step(pl, n)
        assert pal == (r == r[::-1]) and n2 == len(r)
        pl, n, s = pl2, n2, r
    print('196: 5000 steps exact (values, lengths, palindrome flags)')
    # 2) delayed palindrome: 1186060307891929990 hits a palindrome at step 261
    s = '1186060307891929990'; pl, n = encode(s)
    for k in range(1, 300):
        pl, n, pal = step(pl, n)
        if pal: print('delayed palindrome detected at step', k); break
    # 3) user's 2,046,548-digit checkpoint: timing + exactness
    s = open(sys.argv[1]).read().strip()
    pl, n = encode(s)
    t = time.perf_counter(); K = int(sys.argv[2]) if len(sys.argv)>2 else 20
    for _ in range(K): pl, n, pal = step(pl, n); assert not pal
    dt = (time.perf_counter() - t) / K
    print(f'checkpoint: {dt*1e3:.2f} ms/step in pure Python bit-planes, digits now {n}')
    t = time.perf_counter(); x = s
    for _ in range(K + 1): x = str(int(x) + int(x[::-1]))
    tref = (time.perf_counter() - t) / (K + 1)
    assert decode_next(pl, n) == x
    print(f'checkpoint +{K+1} steps matches Python big-int reference exactly (reference: {tref*1e3:.0f} ms/step)')
