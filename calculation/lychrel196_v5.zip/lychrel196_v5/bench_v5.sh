#!/usr/bin/env bash
# v5 benchmark on the RTX 4050. Every timed output is checked against an independent CPU reference.
#   ./bench_v5.sh gate            build + GPU exactness gate (must pass first)
#   ./bench_v5.sh small           2.05M-digit checkpoint, 20,000 steps: v4 vs v5-step vs v5-tb (5 trials, interleaved)
#   ./bench_v5.sh sweep           v5-tb K x tile sweep on the 2.05M checkpoint
#   ./bench_v5.sh big FILE ITER   your 28.2M-digit checkpoint: v4 vs v5-tb, 2,000 steps
#   ./bench_v5.sh longrun         200,000 steps: run_forever.py + v4 (process per chunk) vs v5 run mode
set -euo pipefail
ARCH=${ARCH:-sm_89}
CK=checkpoint_4942464.txt; START=4942464
mkdir -p bench
log() { echo "$@" | tee -a bench/summary.txt; }
now() { date +%s.%N; }
build() {
  nvcc -O3 -std=c++17 -arch=$ARCH cuda196_v5.cu -o cuda196_v5
  nvcc -O3 -std=c++17 -arch=$ARCH -DTB_MINBLOCKS=1 cuda196_v5.cu -o bench/cuda196_v5_mb1
  nvcc -O3 -std=c++17 -arch=$ARCH baseline_v4/cuda196_bits.cu -o bench/cuda196_v4
  g++ -O3 -march=native -fopenmp -std=c++17 emu196_v5.cpp -o emu196_v5
  gcc -O2 tools/ref.c -o bench/ref
}
ref_for() {  # ref_for INPUT START STEPS -> path of reference output
  local f=bench/ref_$(basename $1)_$3.txt
  [ -f $f ] || { echo "building CPU reference ($3 steps)..." >&2; ./bench/ref $1 $3 $f; }
  echo $f
}
median() { sort -n | awk '{a[NR]=$1} END{print a[int((NR+1)/2)]}'; }
timed() {  # timed OUTFILE cmd... -> prints wall seconds; stderr appended to bench/log.txt
  local s e; s=$(now); "${@:2}" 2>>bench/log.txt >/dev/null; e=$(now); echo "$e - $s" | bc
}
case "${1:-}" in
gate)
  build
  for f in "--mode=step" "--mode=tb" "--mode=tb --tile=4 --K=7" "--mode=tb --tile=4 --halo=4 --K=64 --window=128"; do
    log "GPU exactness suite: $f"
    ENGINE_FLAGS="$f" python3 tests/test_exact.py ./cuda196_v5 | tail -1 | tee -a bench/summary.txt
  done
  ./cuda196_v5 $CK 2000 bench/g2000.txt $START 2>>bench/log.txt
  ./emu196_v5  $CK 2000 bench/e2000.txt $START 2>>bench/log.txt
  cmp bench/g2000.txt bench/e2000.txt && log "GPU tb == CPU emulator at +2000: PASS"
  R=$(ref_for $CK $START 2000); cmp bench/g2000.txt $R && log "GPU tb == reference at +2000: PASS"
  ;;
small)
  STEPS=20000; R=$(ref_for $CK $START $STEPS)
  for e in v4 v5step v5tb; do : > bench/t_$e.txt; done
  ./cuda196_v5 $CK 1000 bench/warm.txt $START >/dev/null 2>&1 || true  # warm-up
  for r in 1 2 3 4 5; do
    echo $(timed x ./bench/cuda196_v4 $CK $STEPS bench/o_v4.txt $START 64)               >> bench/t_v4.txt
    echo $(timed x ./cuda196_v5 $CK $STEPS bench/o_v5step.txt $START 64 --mode=step)     >> bench/t_v5step.txt
    echo $(timed x ./cuda196_v5 $CK $STEPS bench/o_v5tb.txt $START 256 --mode=tb)        >> bench/t_v5tb.txt
  done
  for e in v4 v5step v5tb; do
    cmp bench/o_$e.txt $R && ok=PASS || ok=MISMATCH
    log "$e: process wall median $(median < bench/t_$e.txt) s over 5 runs, output $ok"
  done
  log "internal compute timings (last run of each, from bench/log.txt):"
  grep -E "us_per_step" bench/log.txt | tail -3 | tee -a bench/summary.txt
  ;;
sweep)
  STEPS=20000; R=$(ref_for $CK $START $STEPS)
  for bin in ./cuda196_v5 ./bench/cuda196_v5_mb1; do
    for K in 64 128 256 512; do
      for T in 0 256 512 800 960; do
        line=$($bin $CK $STEPS bench/o_sw.txt $START $K --mode=tb --tile=$T 2>&1 | grep us_per_step || true)
        cmp -s bench/o_sw.txt $R && ok=PASS || ok=MISMATCH
        log "$bin K=$K tile=$T $ok $(echo "$line" | grep -oE 'us_per_step=[0-9.]+|replays=[0-9]+' | tr '\n' ' ')"
      done
    done
  done
  ;;
big)
  BIG=${2:?path to the 28M-digit checkpoint}; BIT=${3:?its iteration}; STEPS=${STEPS:-2000}
  R=$(ref_for $BIG $BIT $STEPS)
  t4=$(timed x ./bench/cuda196_v4 $BIG $STEPS bench/o_big_v4.txt $BIT 64)
  t5=$(timed x ./cuda196_v5 $BIG $STEPS bench/o_big_v5.txt $BIT 256 --mode=tb)
  cmp bench/o_big_v4.txt $R && a=PASS || a=MISMATCH
  cmp bench/o_big_v5.txt $R && b=PASS || b=MISMATCH
  log "28M-digit checkpoint, $STEPS steps: v4 wall $t4 s ($a), v5-tb wall $t5 s ($b)"
  grep -E "us_per_step" bench/log.txt | tail -2 | tee -a bench/summary.txt
  ;;
longrun)
  TOTAL=200000; CH=20000
  rm -rf bench/rf bench/v5run
  s=$(now); python3 run_forever.py --input $CK --start $START --chunk $CH --batch 64 --engine ./bench/cuda196_v4 \
      --output-dir bench/rf --max-chunks $((TOTAL / CH)) >/dev/null 2>>bench/log.txt; e=$(now)
  tA=$(echo "$e - $s" | bc)
  s=$(now); ./cuda196_v5 run $CK $START bench/v5run --chunk=$CH --steps=$TOTAL --keep=2 >/dev/null 2>>bench/log.txt; e=$(now)
  tB=$(echo "$e - $s" | bc)
  END=$((START + TOTAL))
  # v4 is already validated against the reference; byte-equality of the two engines checks v5.
  cmp bench/rf/checkpoint_$END.txt bench/v5run/checkpoint_$END.txt && ok=IDENTICAL || ok=DIFFERENT
  log "long run $TOTAL steps: run_forever+v4 $tA s | v5 run mode $tB s | outputs $ok | speedup $(echo "scale=2; $tA/$tB" | bc)x"
  [ -n "${FULLREF:-}" ] && { R=$(ref_for $CK $START $TOTAL); cmp bench/v5run/checkpoint_$END.txt $R && log "v5 run == reference: PASS"; }
  ;;
*) echo "usage: $0 gate|small|sweep|big FILE ITER|longrun"; exit 1 ;;
esac
