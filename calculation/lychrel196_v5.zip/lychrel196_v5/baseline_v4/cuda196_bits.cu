// cuda196_bits.cu - bit-sliced exact 196 reverse-and-add on CUDA.
// One thread per 32-pair word; arithmetic in bits_core.h (shared with the CPU emulator).
// Build: nvcc -O3 -std=c++17 -arch=sm_89 cuda196_bits.cu -o cuda196_bits
// Usage is identical to the old main.cu:
//   ./cuda196_bits INPUT(196|decimal.txt) STEPS OUTPUT [START_ITER=0] [BATCH=64] [CHECKPOINT_INTERVAL=0]
#include <cuda_runtime.h>
#include "driver.h"
using bits::u32;

#define CHECK(x)                                                                                   \
  do {                                                                                             \
    cudaError_t e_ = (x);                                                                          \
    if (e_ != cudaSuccess) {                                                                       \
      fprintf(stderr, "CUDA %s at %s:%d\n", cudaGetErrorString(e_), __FILE__, __LINE__);         \
      exit(2);                                                                                     \
    }                                                                                              \
  } while (0)

static constexpr int THREADS = 256;

__global__ void __launch_bounds__(THREADS)
bits_step(const u32* __restrict__ src, u32* __restrict__ dst, const int* __restrict__ nIn, int* __restrict__ nOut,
          unsigned* __restrict__ bad, int slot, int Wcap) {
  const int w = blockIdx.x * blockDim.x + threadIdx.x;
  const int n = *nIn;
  unsigned mism = 0;
  int g = 0;
  // Words far above the number are already zero in dst (buffers start zeroed, h only grows).
  if (w < Wcap && 32LL * w <= (n + 2) / 2 + 32) mism = bits::step_word(src, dst, Wcap, n, w, &g);
  if (w == 0) *nOut = n + g;  // nIn/nOut are different buffers (ping-pong)
  if (__syncthreads_or((int)mism) && threadIdx.x == 0) atomicOr(bad + slot, 1u);
}

struct CudaBackend {
  u32* s[2] = {nullptr, nullptr};
  u32* bk = nullptr;
  int* dn[2] = {nullptr, nullptr};
  int* dnbk = nullptr;
  unsigned* dBad = nullptr;
  int Wcap = 0, cur = 0, batch = 0, grid = 0;
  size_t bytes = 0;
  cudaStream_t st = nullptr;
  cudaGraphExec_t exec[2] = {nullptr, nullptr};
  char nameBuf[256];

  const char* name() { return nameBuf; }
  void enqueue(int count, int from) {
    CHECK(cudaMemsetAsync(dBad, 0, sizeof(unsigned) * count, st));
    for (int i = 0; i < count; ++i) {
      int a = (from + i) & 1;
      bits_step<<<grid, THREADS, 0, st>>>(s[a], s[1 - a], dn[a], dn[1 - a], dBad, i, Wcap);
    }
  }
  void init(const std::vector<u32>& pl, int n0, int W, int b) {
    int dev; cudaDeviceProp prop;
    CHECK(cudaGetDevice(&dev)); CHECK(cudaGetDeviceProperties(&prop, dev));
    snprintf(nameBuf, sizeof nameBuf, "cuda-bits(%s, %d SMs)", prop.name, prop.multiProcessorCount);
    Wcap = W; batch = b; bytes = sizeof(u32) * 5 * (size_t)W;
    grid = (Wcap + THREADS - 1) / THREADS;
    for (int i = 0; i < 2; ++i) {
      CHECK(cudaMalloc(&s[i], bytes)); CHECK(cudaMemset(s[i], 0, bytes));
      CHECK(cudaMalloc(&dn[i], sizeof(int)));
    }
    CHECK(cudaMalloc(&bk, bytes)); CHECK(cudaMalloc(&dnbk, sizeof(int)));
    CHECK(cudaMalloc(&dBad, sizeof(unsigned) * b));
    CHECK(cudaMemcpy(s[0], pl.data(), bytes, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(dn[0], &n0, sizeof(int), cudaMemcpyHostToDevice));
    CHECK(cudaStreamCreate(&st));
    // Two graphs so a batch can start from either ping-pong buffer (odd batches included).
    for (int from = 0; from < 2; ++from) {
      cudaGraph_t gph;
      CHECK(cudaStreamBeginCapture(st, cudaStreamCaptureModeGlobal));
      enqueue(batch, from);
      CHECK(cudaStreamEndCapture(st, &gph));
      CHECK(cudaGraphInstantiate(&exec[from], gph, 0));
      CHECK(cudaGraphDestroy(gph));
    }
    cur = 0;
  }
  void run(int count, std::vector<unsigned>& bad) {
    if (count == batch) CHECK(cudaGraphLaunch(exec[cur], st));
    else enqueue(count, cur);
    bad.assign(count, 0);
    CHECK(cudaMemcpyAsync(bad.data(), dBad, sizeof(unsigned) * count, cudaMemcpyDeviceToHost, st));
    CHECK(cudaStreamSynchronize(st));
    CHECK(cudaGetLastError());
    cur = (cur + count) & 1;
  }
  void backup() {
    CHECK(cudaMemcpyAsync(bk, s[cur], bytes, cudaMemcpyDeviceToDevice, st));
    CHECK(cudaMemcpyAsync(dnbk, dn[cur], sizeof(int), cudaMemcpyDeviceToDevice, st));
  }
  void restore() {
    CHECK(cudaMemcpyAsync(s[cur], bk, bytes, cudaMemcpyDeviceToDevice, st));
    CHECK(cudaMemcpyAsync(dn[cur], dnbk, sizeof(int), cudaMemcpyDeviceToDevice, st));
    CHECK(cudaStreamSynchronize(st));
  }
  void download(bool previous, std::vector<u32>& pl, int& n) {
    int k = previous ? 1 - cur : cur;
    pl.resize(5 * (size_t)Wcap);
    CHECK(cudaMemcpy(pl.data(), s[k], bytes, cudaMemcpyDeviceToHost));
    CHECK(cudaMemcpy(&n, dn[k], sizeof(int), cudaMemcpyDeviceToHost));
  }
  ~CudaBackend() {
    for (int i = 0; i < 2; ++i) { if (exec[i]) cudaGraphExecDestroy(exec[i]); cudaFree(s[i]); cudaFree(dn[i]); }
    cudaFree(bk); cudaFree(dnbk); cudaFree(dBad);
    if (st) cudaStreamDestroy(st);
  }
};

int main(int argc, char** argv) {
  try {
    CudaBackend be;
    return drv::run(be, argc, argv);
  } catch (const std::exception& e) {
    fprintf(stderr, "ERROR %s\n", e.what());
    return 2;
  }
}
