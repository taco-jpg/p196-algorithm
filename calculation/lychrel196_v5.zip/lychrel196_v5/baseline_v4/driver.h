// driver.h - host flow shared by cuda196_bits (GPU) and emu196_bits (CPU).
// usage: PROG INPUT(196|decimal.txt) STEPS OUTPUT [START_ITER=0] [BATCH=64] [CHECKPOINT_INTERVAL=0]
// Same arguments as the old main.cu. Every step's palindrome flag is checked.
#pragma once
#include <algorithm>
#include <chrono>
#include <climits>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <stdexcept>
#include <string>
#include <vector>
#include "bits_core.h"

namespace drv {
using bits::u32;

inline std::string readNumber(const std::string& f) {
  if (f == "196") return "196";
  std::ifstream in(f);
  if (!in) throw std::runtime_error("cannot open input " + f);
  std::string s;
  std::getline(in, s);
  while (!s.empty() && (s.back() == '\r' || s.back() == ' ')) s.pop_back();
  if (s.empty() || s[0] == '0' || s.find_first_not_of("0123456789") != std::string::npos)
    throw std::runtime_error("input must be a positive decimal without leading zeros");
  return s;
}
// decimal -> bit-planes of pair sums
inline std::vector<u32> encode(const std::string& s, int Wcap) {
  int n = (int)s.size(), h = (n + 1) / 2;
  std::vector<u32> pl(5 * (size_t)Wcap, 0);
  for (int j = 0; j < h; ++j) {
    int v = (s[n - 1 - j] - '0') + (s[j] - '0');
    for (int q = 0; q < 5; ++q)
      if ((v >> q) & 1) pl[(size_t)q * Wcap + (j >> 5)] |= 1u << (j & 31);
  }
  return pl;
}
inline std::vector<uint8_t> planesToPairs(const std::vector<u32>& pl, int Wcap, int n) {
  int h = (n + 1) / 2;
  std::vector<uint8_t> S(h);
  for (int j = 0; j < h; ++j) {
    int v = 0;
    for (int q = 0; q < 5; ++q) v |= (int)((pl[(size_t)q * Wcap + (j >> 5)] >> (j & 31)) & 1u) << q;
    S[j] = (uint8_t)v;
  }
  return S;
}
// pairs of N_k (n digits) -> decimal N_{k+1}; throws if the state is inconsistent
inline std::string materializeNext(const std::vector<uint8_t>& S, int n) {
  for (uint8_t v : S) if (v > 18) throw std::runtime_error("corrupt state: pair sum > 18");
  int c = 0;
  std::string v(n + 1, '0');
  for (int i = 0; i < n; ++i) {
    int a = S[i < n - 1 - i ? i : n - 1 - i] + c;
    v[n - i] = char('0' + a % 10);
    c = a / 10;
  }
  if (c) { v[0] = '1'; return v; }
  return v.substr(1);
}
inline bool isPalindrome(const std::string& s) {
  for (size_t i = 0, j = s.size() - 1; i < j; ++i, --j) if (s[i] != s[j]) return false;
  return true;
}
inline void writeFileAtomic(const std::string& f, const std::string& s) {
  std::string tmp = f + ".tmp";
  {
    std::ofstream out(tmp, std::ios::binary);
    if (!out) throw std::runtime_error("cannot write " + tmp);
    out << s << '\n';
    if (!out) throw std::runtime_error("write failed " + tmp);
  }
  if (std::rename(tmp.c_str(), f.c_str())) throw std::runtime_error("rename failed " + f);
}

// Backend concept:
//   const char* name();
//   void init(const std::vector<u32>& planes, int n, int Wcap, int batch);
//   void run(int count, std::vector<unsigned>& bad);   // count steps; bad[i]!=0 -> N after step i+1 not a palindrome
//   void backup(); void restore();                     // device copy of current state
//   void download(bool previous, std::vector<u32>& planes, int& n);  // previous = state before the last step
template <class Backend>
int run(Backend& be, int argc, char** argv) {
  if (argc < 4) {
    fprintf(stderr, "usage: %s INPUT(196|decimal.txt) STEPS OUTPUT [START_ITER=0] [BATCH=64] [CHECKPOINT_INTERVAL=0]\n", argv[0]);
    return 1;
  }
  std::string input = readNumber(argv[1]);
  long long steps = std::stoll(argv[2]);
  std::string output = argv[3];
  long long start = argc > 4 ? std::stoll(argv[4]) : 0;
  int batch = argc > 5 ? std::stoi(argv[5]) : 64;
  long long save = argc > 6 ? std::stoll(argv[6]) : 0;
  if (steps < 1 || batch < 1 || batch > 4096 || save < 0) throw std::runtime_error("bad arguments");
  if ((long long)input.size() + steps > INT_MAX / 2) throw std::runtime_error("too many digits");
  const int n0 = (int)input.size();
  const int Wcap = (int)(((n0 + steps + 1) / 2 + 2) / 32) + 4;
  be.init(encode(input, Wcap), n0, Wcap, batch);
  fprintf(stderr, "backend=%s input_digits=%d start=%lld steps=%lld batch=%d words=%d\n", be.name(), n0, start, steps,
          batch, Wcap);

  std::vector<unsigned> bad;
  long long done = 0;
  auto t0 = std::chrono::steady_clock::now();
  double gpuSeconds = 0;
  while (done < steps) {
    int count = (int)std::min<long long>(batch, steps - done);
    if (save) count = (int)std::min<long long>(count, save - done % save);  // never cross a checkpoint
    be.backup();
    auto tb = std::chrono::steady_clock::now();
    be.run(count, bad);
    gpuSeconds += std::chrono::duration<double>(std::chrono::steady_clock::now() - tb).count();
    int first = -1;
    for (int i = 0; i < count; ++i) if (!bad[i]) { first = i; break; }
    if (first >= 0) {
      // N_{start+done+first+1} is a palindrome: replay exactly to the state just before it.
      long long p = start + done + first + 1;
      be.restore();
      if (first > 0) be.run(first, bad);
      std::vector<u32> pl; int n;
      be.download(false, pl, n);
      std::string N = materializeNext(planesToPairs(pl, Wcap, n), n);
      std::string f = output + ".palindrome_" + std::to_string(p) + ".txt";
      writeFileAtomic(f, N);
      bool ok = isPalindrome(N);
      fprintf(stderr, "PALINDROME at iteration %lld digits=%zu cpu_check=%s file=%s\n", p, N.size(), ok ? "PASS" : "FAIL",
              f.c_str());
      return ok ? 3 : 2;
    }
    done += count;
    if ((save && done % save == 0) || done == steps) {
      std::vector<u32> pl; int n;
      be.download(true, pl, n);  // state of step done-1 reconstructs N_{start+done}
      std::string N = materializeNext(planesToPairs(pl, Wcap, n), n);
      std::string f = done == steps ? output : output + ".next_" + std::to_string(start + done) + ".txt";
      writeFileAtomic(f, N);
      double sec = std::chrono::duration<double>(std::chrono::steady_clock::now() - t0).count();
      fprintf(stderr, "iteration=%lld digits=%zu seconds=%.4f compute_seconds=%.4f us_per_step=%.3f file=%s\n",
              start + done, N.size(), sec, gpuSeconds, 1e6 * gpuSeconds / done, f.c_str());
      if (isPalindrome(N)) { fprintf(stderr, "PALINDROME at iteration %lld (checkpoint)\n", start + done); return 3; }
    }
  }
  return 0;
}
}  // namespace drv
