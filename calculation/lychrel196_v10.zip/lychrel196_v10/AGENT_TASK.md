# Task for the local agent (RTX 4050): v10 (decimal pair sums in the warp windows)

Production runs v9 (512 threads, J=32, tile 1900, K=128). v10 contains everything in v9 (64-bit digit
counts, ISF, mod-9 fingerprint, cross-check tools). Results must be byte-identical to v9.

Pause with `search/STOP` (finishes the current chunk) for anything that uses the GPU, resume from
`latest.json`, confirm the service runs again. One GPU job at a time. The CPU-only parts (the emulator
gate, the big64 CPU reference) can run while production runs, if the user agrees.

## What changes (README.md has the details)
- Inside each warp window every pair sum is held as S = D + 10G (BCD digit planes + carry-generate
  plane); a step then needs only the carries into each pair. About 2.2x fewer ALU-pipe instructions per
  step than v9 (static counts, BREV not counted - see README; not measured on a GPU).
- 64-step windows, tracker fast path, cheaper palindrome bookkeeping, the slow per-step tiles (tile 0 and
  the middle of the number) scheduled first in every launch.
- Build options are separate binaries, so the A/B measures each one.

## Steps
1. `./bench_v10.sh build`, then `./bench_v10.sh resources`. Report the lines. Every v10 binary must
   show `STL/LDL in loop=0` for the warp-window loop.
2. `./bench_v10.sh gate`. **Everything must PASS**: the CPU-emulator gate (it takes a while; it runs on
   the CPU), the 2 GPU fingerprint lines (an injected bit flip must be caught), the GPU exactness suites,
   the differential v9 vs v10 runs, the stress tests and every `+2000 == reference` line.
3. `./bench_v10.sh big64`: a 2,147,483,600-digit number, 250 steps. If an earlier package already built
   the reference, reuse it: `BIGDIR=<that package>/bench/big64 ./bench_v10.sh big64`.
4. `./bench_v10.sh ab <COPY of the newest checkpoint> <its iteration>`: v9t512:1900 (production) vs the
   v10 builds (512 threads at tile 1900, K=128 and K=256; without pipe balancing; J=32; 256 threads at
   tile 940/932, 2 blocks per SM). 5,000 steps, 3 interleaved rounds, power and energy. **Replays must
   be 0** for a configuration to count.
5. Best configuration (median, replays 0) vs production: `./bench_v10.sh sustained <COPY> <iter> <cfg>`.
6. `./bench_v10.sh runmode`. Resume production, confirm it runs. Send back `bench/summary.txt`,
   `bench/ab.tsv`, `bench/log.txt`, `bench/gate_emu.txt`.

## Deciding (the user's call)
- Switch to the fastest v10 configuration that is >= 5% faster sustained, with 0 replays and identical
  output, at a chunk boundary, resuming from `latest.json`, keeping the milestone/stop settings. Keep v9
  for rollback. The run command keeps its form; only the binary and possibly `--tile`/`--K` change.
- If no v10 configuration qualifies, stay on v9.

## In production on v10
- `fp_replays` should stay 0. Any fingerprint replay means a state bit changed without the code changing
  it: report it with the iteration and keep the run going (the replay fixed that window).
- If the run stops with "mod-9 fingerprint mismatch in the per-step kernel": do not restart blindly.
  Report it, restore from the last archive whose cross-check passed, and run `tools/crosscheck.sh`.
- Keep the routines: ISF dumps at milestones, `bench/mod9` on every archive, the weekly cross-check
  (`tools/crosscheck.sh ./cuda196_v10 ...`).

## Rules
- Benchmarks only on a copy of a checkpoint, never the live file.
- Every step's palindrome status is checked; certification failures replay.
- Measured numbers only.
