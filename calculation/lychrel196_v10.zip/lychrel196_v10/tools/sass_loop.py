#!/usr/bin/env python3
"""v9: find the warp-window step loop in a tb_kernel SASS listing (the smallest loop closed by a
backward branch whose body contains both SHFL.UP and SHFL.DOWN) and count its local-memory
instructions (STL/LDL), which must be 0.  usage: sass_loop.py SASS_TEXT_FILE"""
import re, sys
ins = [(int(a, 16), t) for a, t in re.findall(r'/\*([0-9a-f]{4,})\*/\s+([^;]*);', open(sys.argv[1]).read())]
ad = {a: i for i, (a, _) in enumerate(ins)}
best = None
for i, (a, t) in enumerate(ins):
    m = re.search(r'BRA[^;]*?0x([0-9a-f]+)', t)
    if m and int(m.group(1), 16) < a and int(m.group(1), 16) in ad:
        body = [x for _, x in ins[ad[int(m.group(1), 16)]:i + 1]]
        if any('SHFL.UP' in x for x in body) and any('SHFL.DOWN' in x for x in body) and (best is None or len(body) < len(best)):
            best = body
print('warp-window loop: none found' if best is None else
      f'warp-window loop: {len(best)} SASS lines, STL/LDL in loop={sum(("STL" in x or "LDL" in x) for x in best)}')
