// emu196_v10.cpp - CPU emulator of cuda196_v10: runs the same bits_core.h / bits_tb10.h / dg_arith.h code
// with the kernels' block/thread/barrier structure reproduced sequentially (blocks in parallel via OpenMP).
// Warp windows: the 32 lanes of a warp run the kernel's per-lane code as fibers (warp_ops.h), so shuffles
// and votes behave as on the GPU. Inline PTX (lop3, add.cc chains, mul.hi/mad.lo) has C++ twins here.
// Build: g++ -O3 -march=native -fopenmp -fcf-protection=none -std=c++17 emu196_v10.cpp -o emu196_v10
// EMU_FAULT=N : flip one state bit after the N-th time-blocked window (tests the mod-9 fingerprint).
// EMU_CERTCHECK=1 : after every time-blocked launch, recompute the same steps with the per-step
//                   kernel and verify every block that claimed certification (soundness test).
// Test builds: -DTB_CHECK_HYBRID (every certified hybrid block recomputed through the v6r3 path, per-step
// mismatch bits and owned words compared), -DTB_CHECK_TRACK (v9's tracker run alongside v10's, compared
// every step), -DTB_CHECK_GROWTH, -DTB_COUNT_PATHS (rare-path counters).
#include <atomic>
#include <climits>
#include <cstring>
#include <cstdio>
#include <cstdlib>
#define WY_EMULATOR
#include "driver10.h"
#include "warp_ops.h"
using bits::u32;

struct EmuBackend {
  std::vector<u32> s[2], bk;
  long long n[2] = {0, 0}, nbk = 0;
  int cur = 0, Wcap = 0, bkWords = 0;
  tb::Conf conf{};
  size_t smem = 0;
  std::vector<unsigned> quiet;
  std::atomic<unsigned> fail{0};
  long long pal = -1;
  bool certcheck = false;
  long long ccBlocksOk = 0, ccBlocksFail = 0, ccViolations = 0;
  std::atomic<long long> hyBlocks{0}, oldBlocks{0}, hyFail{0}, hyChecked{0}, hyQuietSteps{0};
  std::vector<unsigned> tape;  // v8 control tape of the current launch
  long long tbLaunches = 0, faultAt = -1, faultsInjected = 0;

  double devSec = 0;
  double deviceSeconds() const { return devSec; }  // host time of the emulated launches
  const char* name() { return certcheck ? "cpu-emulator(v10, certcheck)" : "cpu-emulator(v10)"; }
  int numSMs() { return 20; }  // behave like an RTX 4050 Laptop for tile auto-selection
  int tbBlocksPerSM(size_t bytes) {
    int bySmem = (int)((100 * 1024) / (bytes + 1024));
    return std::min(2, bySmem);  // the CUDA build caps tb_kernel at 2 blocks/SM (TB_MINBLOCKS=2)
  }
  void init(const std::vector<u32>& pl, long long n0, int W, const tb::Conf& c, int) {
    Wcap = W; conf = c; smem = tb::smem_bytes(c);
    s[0] = pl; s[1].assign(pl.size(), 0); bk.assign(pl.size(), 0);
    n[0] = n[1] = n0; cur = 0;
    quiet.assign(tb::KMAX, 0);
    const char* e = getenv("EMU_CERTCHECK");
    certcheck = e && *e == '1';
    const char* f = getenv("EMU_FAULT");
    faultAt = f ? atoll(f) : -1;
    if (smem > 99 * 1024) throw std::runtime_error("tile does not fit in shared memory; lower --tile or --K");
  }
  // one v4 step over all words, src -> dst
  static unsigned v4step(const u32* src, u32* dst, int W, long long nn, long long* nOut) {
    int g0 = 0;
    unsigned any = 0;
#pragma omp parallel for reduction(| : any) schedule(static)
    for (int w = 0; w < W; ++w) {
      int g = 0;
      if (32LL * w > (nn + 2) / 2 + 32) continue;
      any |= bits::step_word(src, dst, W, nn, w, &g);
      if (w == 0) g0 = g;
    }
    *nOut = nn + g0;
    return any;
  }
  void stepRun(int count, std::vector<unsigned>& bad, int) {
    auto t0 = d5::Clock::now();
    bad.assign(count, 0);
    for (int i = 0; i < count; ++i) {
      bad[i] = v4step(s[cur].data(), s[1 - cur].data(), Wcap, n[cur], &n[1 - cur]);
      cur ^= 1;
    }
    devSec += d5::secs(t0);
  }
  // v8: emulates tape_kernel (prefix tile alone, 64 threads) -> tape[0..KMAX/32] (last word = certified)
  void runTape(int K, const u32* src, long long nIn) {
    tb::Conf c = conf; c.K = K; c.lenMax = 0;
    std::vector<unsigned char> mem(tb::smem_bytes(c) + 16);
    tb::State& S = *reinterpret_cast<tb::State*>(mem.data());
    u32* base = reinterpret_cast<u32*>(mem.data() + tb::state_bytes());
    tb::ph_setup(S, c, 0, nIn); S.len = 0; S.okT = 0;
    for (int tid = 0; tid < 64; ++tid) tb::ph_load(S, c, base, src, tid, 64);
    tb::ph_init(S, c, base);
    long long nn = S.n0;
    int g = S.gS[0];
    std::vector<tb::WorkCtx> wc(64);
    for (int tid = 0; tid < 64; ++tid) wc[tid] = tb::work_ctx(S, tid, 64);
    for (int t = 0; t < K; ++t) {
      for (int tid = 0; tid < 64; ++tid) tb::ph_track(S, c, base, t, nn, g, tid);
      unsigned gn = 0;
      for (int tid = 0; tid < 64; ++tid) { const unsigned m = tb::ph_work(S, c, base, wc[tid], t, nn, g, tid); if (tid == 0) gn = (m >> 1) & 1u; }
      nn += g; g = (int)gn;
    }
    tape.assign(tb::KMAX / 32 + 1, 0u);
    for (int t = 0; t < K; ++t) tape[t >> 5] |= ((S.gbits[t >> 5] >> (t & 31)) & 1u) << (t & 31);
    tape[tb::KMAX / 32] = (unsigned)S.okP;
  }
  // v9: one warp window, run per lane by wyemu::runWarp (the kernel's own lane code)
  struct WinCtx { tb::State* S; const tb::Conf* c; u32* base; int warp, par, js; unsigned long long gb; unsigned long long m; };
  static void winLane(void* p, int lane) {
    WinCtx& x = *static_cast<WinCtx*>(p);
    const unsigned long long r = tb::wy_window<tb::EmuOps>(*x.S, *x.c, x.base, x.warp, lane, x.par, x.js, x.gb);
    if (lane == 0) x.m = r;
  }
  // Emulates one CUDA block of tb_kernel. Returns verdict (1 = certified).
  int tbBlock(int blk, int K, const u32* src, u32* dst, long long nIn, long long* nOut, std::vector<std::atomic<unsigned>>& q) {
    tb::Conf c = conf; c.K = K;
    std::vector<unsigned char> mem(tb::smem_bytes(c) + 16);
    tb::State& S = *reinterpret_cast<tb::State*>(mem.data());
    u32* base = reinterpret_cast<u32*>(mem.data() + tb::state_bytes());
    tb::ph_setup(S, c, blk, nIn);
    if (S.dead) { for (int t = 0; t < K; ++t) q[t]++; return 1; }
    if (S.hy) {  // v8 hybrid interior block (same code as the CUDA kernel, threads run in sequence)
      ++hyBlocks;
#ifdef TB_CHECK_HYBRID
      std::vector<unsigned char> snap(mem);  // state after setup + the v6r3 path's load/init, for the cross-check
      {
        tb::State& S2 = *reinterpret_cast<tb::State*>(snap.data());
        u32* base2 = reinterpret_cast<u32*>(snap.data() + tb::state_bytes());
        for (int tid = 0; tid < tb::THREADS; ++tid) tb::ph_load(S2, c, base2, src, tid, tb::THREADS);
        tb::ph_init(S2, c, base2);
      }
#endif
      if (!tape[tb::KMAX / 32]) { ++hyFail; return 0; }
      // v10: tile only, spans, mismatch bitmask (as the CUDA kernel)
      for (int tid = 0; tid < tb::THREADS; ++tid) tb::ph_load_tile(S, c, base, src, tid, tb::THREADS);
      for (int tid = 0; tid < tb::THREADS; ++tid) tb::hy_init_spans(S, c, base, tid, tb::THREADS);
      const int G = S.len / 4;
      int par = 0;
      for (int t0 = 0; t0 < K; t0 += TB_J) {
        const int js = K - t0 < TB_J ? K - t0 : TB_J;
        const unsigned long long gb = tb::tape_bits64(tape.data(), t0, js);
        unsigned long long m = 0;
        for (int warp = 0; warp < tb::THREADS / 32; ++warp) {
          if (tb::WY_CORE * warp >= G) break;  // warps without core groups only wait at the barrier
          WinCtx x{&S, &c, base, warp, par, js, gb, 0u};
          wyemu::runWarp(&winLane, &x);
          m |= x.m;
        }
        tb::qm_or(S.qm, t0, m);
        par ^= 1;
      }
      for (int t = 0; t < K; ++t)
        if (!((S.qm[t >> 5] >> (t & 31)) & 1u)) q[t]++;
      for (int tid = 0; tid < tb::THREADS; ++tid) tb::ph_store_par(S, c, base, dst, par, tid, tb::THREADS);
      if (!S.hyok) ++hyFail;
#ifdef TB_CHECK_HYBRID
      {  // test builds: the same block through the v6r3 path must give the same mismatch bits per step
        // and the same owned words whenever both are certified
        std::vector<unsigned char> m2(snap);
        tb::State& S2 = *reinterpret_cast<tb::State*>(m2.data());
        u32* base2 = reinterpret_cast<u32*>(m2.data() + tb::state_bytes());
        S2.hy = 0;
        std::vector<u32> d2(5 * (size_t)Wcap, 0u);
        unsigned qb[tb::KMAX / 32] = {0};
        long long n2 = 0;
        const int ok2 = oldPath(S2, c, base2, K, d2.data(), qb, &n2);
        if (ok2 && S.hyok) {
          for (int t = 0; t < K; ++t)
            if (((qb[t >> 5] ^ S.qm[t >> 5]) >> (t & 31)) & 1u) {
              fprintf(stderr, "v9 check: mismatch bit differs blk=%d t=%d (v6r3 %u, hybrid %u)\n", blk, t,
                      (qb[t >> 5] >> (t & 31)) & 1u, (S.qm[t >> 5] >> (t & 31)) & 1u);
              abort();
            }
          for (int x = S.o0w; x < S.o1w; ++x)
            for (int qq = 0; qq < 5; ++qq)
              if (d2[(size_t)qq * Wcap + x] != dst[(size_t)qq * Wcap + x]) {
                fprintf(stderr, "v9 check: owned word differs blk=%d word=%d\n", blk, x);
                abort();
              }
          ++hyChecked;
          for (int t = 0; t < K; ++t) if (!((qb[t >> 5] >> (t & 31)) & 1u)) ++hyQuietSteps;
        }
      }
#endif
      return S.hyok;
    }
    ++oldBlocks;
    for (int tid = 0; tid < tb::THREADS; ++tid) tb::ph_load(S, c, base, src, tid, tb::THREADS);
    tb::ph_init(S, c, base);
    unsigned qb[tb::KMAX / 32] = {0};
    long long nn = 0;
    const int ok = oldPath(S, c, base, K, dst, qb, &nn);
    for (int t = 0; t < K; ++t)
      if (!((qb[t >> 5] >> (t & 31)) & 1u)) q[t]++;
    if (blk == 0) *nOut = nn;
    return ok;
  }
  // The v6r3 per-step path for one block (state already set up and loaded). qb: bit t = mismatch.
  int oldPath(tb::State& S, const tb::Conf& c, u32* base, int K, u32* dst, unsigned* qb, long long* nOut) {
    long long nn = S.n0;
    int g = S.gS[0];
    std::vector<tb::WorkCtx> wc(tb::THREADS);
    for (int tid = 0; tid < tb::THREADS; ++tid) wc[tid] = tb::work_ctx(S, tid, tb::THREADS);
    for (int t = 0; t < K; ++t) {
      for (int tid = 0; tid < tb::THREADS; ++tid) tb::ph_track(S, c, base, t, nn, g, tid);  // threads 32/33 track
      unsigned any = 0, gn = 0;
      for (int tid = 0; tid < tb::THREADS; ++tid) {
        const unsigned m = tb::ph_work(S, c, base, wc[tid], t, nn, g, tid);
        any |= m & 1u;
        if (tid == 0) gn = (m >> 1) & 1u;  // what the barrier count delivers on the GPU
        else if (m & 2u) { fprintf(stderr, "v8: growth vote from thread %d\n", tid); abort(); }
      }
      if ((int)gn != S.gS[(t + 1) & 1] || (int)((S.gbits[(t + 1) >> 5] >> ((t + 1) & 31)) & 1u) != (int)gn) { fprintf(stderr, "v8: growth bit mismatch at t=%d\n", t); abort(); }
      if (any) qb[t >> 5] |= 1u << (t & 31);
      nn += g;
      g = (int)gn;
    }
    int ok = tb::ph_verdict(S, nn);
    for (int tid = 0; tid < tb::THREADS; ++tid) tb::ph_store(S, c, base, dst, K, tid, tb::THREADS);
    *nOut = nn;
    return ok;
  }
  void tbLaunch(int k, long long baseIter, int blocks) {
    auto t0 = d5::Clock::now();
    const u32* src = s[cur].data();
    u32* dst = s[1 - cur].data();
    std::vector<std::atomic<unsigned>> q(k);
    for (auto& x : q) x = 0;
    std::vector<int> ok(blocks, 1);
    long long nOut = n[cur];
    if (conf.hy) runTape(k, src, n[cur]);
#pragma omp parallel for schedule(dynamic, 1)
    for (int b = 0; b < blocks; ++b) ok[b] = tbBlock(b, k, src, dst, n[cur], &nOut, q);
    for (int b = 0; b < blocks; ++b) if (!ok[b]) fail = 1;
    for (int t = 0; t < k; ++t)
      if (q[t] == (unsigned)blocks && pal < 0) pal = baseIter + t + 1;
    if (certcheck) certCheck(k, blocks, ok, nOut);
    n[1 - cur] = nOut;
    cur ^= 1;
    if (++tbLaunches == faultAt) {  // test: a "hardware" bit flip in the new state (pair 3, plane 2)
      s[cur][(size_t)2 * Wcap + 0] ^= 1u << 3;
      ++faultsInjected;
      fprintf(stderr, "[emu] injected a bit flip after time-blocked launch %lld\n", tbLaunches);
    }
    devSec += d5::secs(t0);
  }
  // Soundness: every block that claimed certification must equal the per-step result.
  void certCheck(int k, int blocks, const std::vector<int>& ok, long long nTB) {
    std::vector<u32> a = s[cur], b(a.size(), 0);
    long long nn = n[cur];
    for (int t = 0; t < k; ++t) { long long n2; v4step(a.data(), b.data(), Wcap, nn, &n2); nn = n2; std::swap(a, b); }
    for (int bl = 0; bl < blocks; ++bl) {
      if (!ok[bl]) { ++ccBlocksFail; continue; }
      ++ccBlocksOk;
      int o0 = bl * conf.TW, o1 = std::min(o0 + conf.TW, Wcap);
      for (int x = o0; x < o1; ++x)
        for (int qq = 0; qq < 5; ++qq)
          if (a[(size_t)qq * Wcap + x] != s[1 - cur][(size_t)qq * Wcap + x]) { ++ccViolations; qq = 5; x = o1; }
    }
    bool allOk = true;
    for (int v : ok) allOk &= v != 0;
    if (allOk && nn != nTB) ++ccViolations;
  }
  d5::TBResult tbSync() {
    d5::TBResult r{(int)fail.load(), pal, n[cur]};
    fail = 0; pal = -1;
    return r;
  }
  long long currentN() { return n[cur]; }
  // v9: E = x_{t+1} mod 9 = 2*sum(S_j) - [n odd]*S_mid (mod 9), from the current planes
  int mod9() {
    const long long nn = n[cur];
    const int h = (int)((nn + 1) / 2), W = (h + 31) / 32;
    unsigned long long T = 0;
    const u32* p = s[cur].data();
#pragma omp parallel for reduction(+ : T) schedule(static)
    for (int w = 0; w < W; ++w) {
      const u32 m = bits::hmask(w, h);
      unsigned long long t = 0;
      for (int q = 0; q < 5; ++q) t += (unsigned long long)__builtin_popcount(p[(size_t)q * Wcap + w] & m) << q;
      T += t;
    }
    long long e = (long long)(2 * (T % 9));
    if (nn & 1) {
      const int j = h - 1;
      int v = 0;
      for (int q = 0; q < 5; ++q) v |= (int)((p[(size_t)q * Wcap + (j >> 5)] >> (j & 31)) & 1u) << q;
      e -= v;
    }
    return (int)(((e % 9) + 9) % 9);
  }
  void backup(int words) {
    bkWords = std::min(words, Wcap);
    for (int q = 0; q < 5; ++q)
      memcpy(&bk[(size_t)q * Wcap], &s[cur][(size_t)q * Wcap], sizeof(u32) * bkWords);
    nbk = n[cur];
  }
  void restore() {
    for (int q = 0; q < 5; ++q) {
      memcpy(&s[cur][(size_t)q * Wcap], &bk[(size_t)q * Wcap], sizeof(u32) * bkWords);
      memset(&s[cur][(size_t)q * Wcap + bkWords], 0, sizeof(u32) * (Wcap - bkWords));
    }
    std::fill(s[1 - cur].begin(), s[1 - cur].end(), 0u);
    n[cur] = nbk;
  }
  void download(bool previous, std::vector<u32>& pl, int& stride, long long& nn) {
    int k = previous ? 1 - cur : cur;
    nn = n[k];
    stride = (int)std::min<long long>(Wcap, (nn + 1) / 2 / 32 + 2);
    pl.assign(5 * (size_t)stride, 0);
    for (int q = 0; q < 5; ++q) memcpy(&pl[(size_t)q * stride], &s[k][(size_t)q * Wcap], sizeof(u32) * stride);
  }
  ~EmuBackend() {
#ifdef TB_CHECK_GROWTH
    fprintf(stderr, "[growth-check] register results verified=%lld\n", tb::g_growth_checks.load());
#endif
#ifdef TB_COUNT_PATHS
    fprintf(stderr, "[paths] fast groups=%lld slow groups=%lld | warp windows: exact carry scans=%lld, tracker word extensions=%lld, "
            "exact mismatch tests=%lld, tracker steps compared with v9's=%lld\n",
            tb::g_fast.load(), tb::g_slow.load(), tb::g_resolve.load(), tb::g_trackext.load(), tb::g_exactdiff.load(), tb::g_trackcmp.load());
#endif
    fprintf(stderr, "[hybrid] J=%d hybrid blocks=%lld (failed %lld) v6r3-path blocks=%lld\n", TB_J, hyBlocks.load(),
            hyFail.load(), oldBlocks.load());
    if (faultAt >= 0) fprintf(stderr, "[emu] faults injected=%lld\n", faultsInjected);
#ifdef TB_CHECK_HYBRID
    fprintf(stderr, "[hybrid-check] blocks cross-checked against the v6r3 path=%lld (block-steps with no mismatch: %lld)\n",
            hyChecked.load(), hyQuietSteps.load());
#endif
    if (certcheck)
      fprintf(stderr, "[certcheck] blocks certified=%lld failed=%lld violations=%lld %s\n", ccBlocksOk, ccBlocksFail,
              ccViolations, ccViolations ? "UNSOUND" : "SOUND");
  }
};

int main(int argc, char** argv) {
  int rc;
  {
    EmuBackend be;
    try {
      rc = d5::mainEntry(be, argc, argv);
    } catch (const std::exception& e) {
      fprintf(stderr, "ERROR %s\n", e.what());
      rc = 2;
    }
    if (be.ccViolations) rc = 4;
  }
  return rc;
}
