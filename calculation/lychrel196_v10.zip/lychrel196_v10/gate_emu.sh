#!/usr/bin/env bash
# gate_emu.sh [quick|full] - v10 CPU-emulator gate (the GPU's per-lane warp-window code run as fibers)
#
# Builds (all from emu196_v10.cpp; "check" builds cross-check every certified hybrid block against the
# per-step v6r3 path, run v9's tracker next to v10's and replay growth steps exactly):
#   emu196_v10           512 threads, J=64 (the default GPU build)
#   bench/emu_256        256 threads, J=64 (the 2-blocks-per-SM GPU build)
#   bench/emu_check      512 threads, J=64, checks          bench/emu_check_256  256 threads, J=64, checks
#   bench/emu_check_j32  512 threads, J=32, checks          bench/emu_check_288  288 threads, J=12, TB_PIPEBAL=0, checks
#   bench/emu_check_j1   512 threads, J=1, checks
set -uo pipefail
MODE=${1:-full}
EM="g++ -O3 -march=native -fopenmp -fcf-protection=none -std=c++17"
C="-DTB_CHECK_HYBRID -DTB_CHECK_GROWTH -DTB_COUNT_PATHS -DTB_CHECK_TRACK"
mkdir -p bench
L=bench/gate_emu.txt; : > $L
log() { echo "$@" | tee -a $L; }
$EM emu196_v10.cpp -o emu196_v10 || exit 1
$EM -DTB_THREADS=256 emu196_v10.cpp -o bench/emu_256 || exit 1
$EM $C emu196_v10.cpp -o bench/emu_check || exit 1
$EM $C -DTB_THREADS=256 emu196_v10.cpp -o bench/emu_check_256 || exit 1
if [ $MODE = full ]; then
  $EM $C -DTB_J=32 emu196_v10.cpp -o bench/emu_check_j32 || exit 1
  $EM $C -DTB_THREADS=288 -DTB_J=12 -DTB_PIPEBAL=0 emu196_v10.cpp -o bench/emu_check_288 || exit 1
  $EM $C -DTB_J=1 emu196_v10.cpp -o bench/emu_check_j1 || exit 1
fi
g++ -O2 -std=c++17 -I. tests/unit_dg.cpp -o bench/unit_dg || exit 1
gcc -O2 tools/ref.c -o bench/ref
log "gate_emu.sh $MODE, $(date)"
log "== decimal arithmetic, exhaustive: $(./bench/unit_dg)"
BUILDS="bench/emu_check bench/emu_check_256"
[ $MODE = full ] && BUILDS="$BUILDS bench/emu_check_j32 bench/emu_check_288 bench/emu_check_j1"
for b in $BUILDS; do
  log "== $b (hybrid blocks cross-checked against the v6r3 path, tracker against v9's, per step)"
  log "  $(python3 tests/quiet_bits.py ./$b 4 | tail -1)"
  log "  $(python3 tests/stress_hybrid.py ./$b 8 | tail -1)"
  log "  $(ENGINE_FLAGS=--halo=4 python3 tests/stress_hybrid.py ./$b 6 3 | tail -1)"
  log "  $(STRESS_LONG=1 python3 tests/stress_hybrid.py ./$b 6 4 | tail -1)"
done
FL=("--mode=tb" "--mode=tb --tile=4 --K=7" "--mode=tb --tile=8 --halo=4 --K=256 --window=512")
[ $MODE = full ] && FL=("--mode=step" "--mode=tb" "--mode=tb --tile=4 --K=7" "--mode=tb --tile=4 --halo=4 --K=64 --window=128" \
  "--mode=tb --tile=8 --halo=4 --K=256 --window=512" "--mode=tb --tile=64 --K=1000" "--mode=tb --tile=1900" "--mode=tb --hybrid=0" "--mode=tb --fp=0")
for f in "${FL[@]}"; do log "exactness suite (emu196_v10 $f): $(ENGINE_FLAGS="$f" python3 tests/test_exact.py ./emu196_v10 | tail -1)"; done
for f in "--mode=tb" "--mode=tb --tile=940" "--mode=tb --tile=4 --halo=4 --K=64 --window=128"; do
  log "exactness suite (emu_256 $f): $(ENGINE_FLAGS="$f" python3 tests/test_exact.py ./bench/emu_256 | tail -1)"; done
log "$(python3 tests/test_growth_edge.py ./emu196_v10 40 | tail -1)"
log "$(python3 tests/pal_later.py ./emu196_v10 3 | tail -1)"
V9=${V9EMU:-../v9_orig/lychrel196_v9/emu196_v9}
for s in 1 2 3; do log "$(python3 tests/diff_engines.py $V9 ./emu196_v10 $s $([ $MODE = full ] && echo 40 || echo 15) | tail -1) (seed $s)"; done
CK=checkpoint_4942464.txt; START=4942464
[ -f bench/ref_2000.txt ] || ./bench/ref $CK 2000 bench/ref_2000.txt
for f in 1 9; do
  EMU_FAULT=$f ./emu196_v10 $CK 2000 bench/f.txt $START 128 --tile=900 --window=512 2> bench/f.log >/dev/null
  fr=$(grep -oE 'fp_replays=[0-9]+' bench/f.log | tail -1 | cut -d= -f2)
  cmp -s bench/f.txt bench/ref_2000.txt && [ "${fr:-0}" -ge 1 ] && log "fingerprint: flip after launch $f caught (fp_replays=$fr), output == reference: PASS" || log "fingerprint: flip after launch $f: FAIL"
done
# the configurations of the GPU A/B (threads:tile:K), plus a check build on the real number
CFGS="512:1900:128 512:1892:256 256:940:128 256:932:256 256:900:128"
[ $MODE = full ] && CFGS="$CFGS c512:1900:128"
for cfg in $CFGS; do
  IFS=: read -r T W K <<< "$cfg"
  case $T in 512) B=./emu196_v10;; 256) B=bench/emu_256;; c512) B=bench/emu_check; T="512 (check build)";; esac
  $B $CK 2000 bench/g.txt $START $K --tile=$W 2> bench/g.log >/dev/null
  cmp -s bench/g.txt bench/ref_2000.txt && log "2M-digit checkpoint +2000, threads $T tile $W K=$K == reference: PASS ($(grep -oE 'hybrid blocks=[0-9]+ \(failed [0-9]+\)' bench/g.log))" || log "2M +2000 threads $T tile $W K=$K: MISMATCH"
done
log "gate done, $(date)"
