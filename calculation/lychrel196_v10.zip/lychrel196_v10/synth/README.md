# Gate search for the v10 decimal arithmetic

The circuits in `dg_arith.h` are networks of 3-input LOP3 gates (any truth table of 3 inputs, one SASS
instruction). They were found with these tools and are verified exhaustively by `tests/unit_dg.cpp`.

- `exact2.py`: SAT-based exact synthesis (python-sat / CaDiCaL). Finds the smallest network for small
  functions and proves that no smaller one exists (used for single outputs and the decimal corrections:
  e.g. the excess-6 correction of the growth add is 3 gates and 2 are impossible).
- `cgp.c`: Cartesian genetic programming over LOP3 networks, for the multi-output functions where the SAT
  search is too slow. Problem files: one row per input / output, the truth table over the care set.
  `./cgp PROBLEM NODES SECONDS SEED [SEED_CIRCUIT]`.
- `norm.py`: turns a found circuit with complemented outputs into one with true outputs (inversions are
  absorbed into the consumers' truth tables, which costs nothing) and re-verifies it.
- `mkprob.py`: writes the problem files.

Results used in v10 (per 32-pair word):

| function | inputs | gates | v9 equivalent |
|---|---|---:|---:|
| no-growth update D', G' (and the mismatch bits) | D (4 BCD planes), raw chain sums al, be, P | 10 (best of 7 CGP runs; 9 not found) | about 29 LOP3 + 2 shifts |
| high digit + 6 | D, be, P | 5 | (digit4: about 8) |
| growth BCD add with carry-in, excess-6 operand | D, a, hi+6, P | 12 (8 ripple + 3 correction, exact minimum for the correction + 1) | about 20 |

Searched without success (not proofs of impossibility unless stated): a 9-gate no-growth update (CGP,
many runs); the no-growth update emitting the next step's P and X as well (best found 14 gates, worse
than 10 + 2); a 12-gate growth add taking the raw chain sum instead of the carry (SAT at r=12 stopped
after 15 minutes without an answer).
