#!/usr/bin/env python3
"""SAT exact synthesis of LOP3 networks (3-input gates), v2.
 - inputs: list of (name, mask) over M care-set minterms
 - targets: list of (name, mask, polarity_free)
 - every gate must be used (fanout to a later gate or an output) - symmetry breaking
 - gates ordered: fanin triples of consecutive gates co-lexicographically non-decreasing when gate i
   does not use gate i-1 (standard 'colex' symmetry breaking, optional)
Prints progress to stderr. Returns (gates, outputs) with gates = [(j,k,l,imm)], outputs = [(sig, inverted)]."""
import itertools, sys, time
from pysat.solvers import Cadical153

def lop3_eval(imm, a, b, c, full):
    v = 0
    for p in range(8):
        if (imm >> p) & 1:
            v |= (a if (p >> 2) & 1 else ~a) & (b if (p >> 1) & 1 else ~b) & (c if p & 1 else ~c)
    return v & full

def try_r(inputs, targets, r, M, colex=True, time_limit=None):
    n = len(inputs)
    inv = [m for _, m in inputs]
    nv = [0]
    def new():
        nv[0] += 1
        return nv[0]
    S = n + r
    x = {(i, t): new() for i in range(n, S) for t in range(M)}
    o = {(i, p): new() for i in range(n, S) for p in range(8)}
    sel = {}
    cls = []
    def lit(j, t, val):
        if j < n:
            return ((inv[j] >> t) & 1) == val
        v = x[(j, t)]
        return v if val else -v
    for i in range(n, S):
        svars = []
        for (j, k, l) in itertools.combinations(range(i), 3):
            sv = new(); sel[(i, j, k, l)] = sv; svars.append(sv)
            for t in range(M):
                for a in (0, 1):
                    la = lit(j, t, a)
                    if la is False: continue
                    for b in (0, 1):
                        lb = lit(k, t, b)
                        if lb is False: continue
                        for c in (0, 1):
                            lc = lit(l, t, c)
                            if lc is False: continue
                            p = a * 4 + b * 2 + c
                            base = [-sv] + [-L for L in (la, lb, lc) if L is not True]
                            cls.append(base + [-x[(i, t)], o[(i, p)]])
                            cls.append(base + [x[(i, t)], -o[(i, p)]])
        cls.append(svars)
    # outputs: target h realised by gate i, polarity pol
    outv = {}
    for h, (name, tm, pfree) in enumerate(targets):
        cands = []
        for i in range(n, S):
            for pol in ((0, 1) if pfree else (0,)):
                gv = new(); cands.append(gv); outv[(h, i, pol)] = gv
                for t in range(M):
                    want = ((tm >> t) & 1) ^ pol
                    cls.append([-gv, x[(i, t)] if want else -x[(i, t)]])
        cls.append(cands)
    # every gate used
    for i in range(n, S):
        users = [v for (ii, j, k, l), v in sel.items() if i in (j, k, l)]
        users += [v for (h, ii, pol), v in outv.items() if ii == i]
        cls.append(users)
    # colex ordering of consecutive gates that are independent (i does not read i-1)
    if colex:
        trips = {i: [(j, k, l) for (ii, j, k, l) in sel if ii == i] for i in range(n, S)}
        for i in range(n + 1, S):
            for (j, k, l) in trips[i]:
                if i - 1 in (j, k, l): continue
                for (j2, k2, l2) in trips[i - 1]:
                    # forbid gate i's triple < gate i-1's triple (colex) when independent
                    if (l, k, j) < (l2, k2, j2):
                        cls.append([-sel[(i, j, k, l)], -sel[(i - 1, j2, k2, l2)]])
    solver = Cadical153(bootstrap_with=cls)
    ok = solver.solve()
    if not ok:
        return None
    m = set(v for v in solver.get_model() if v > 0)
    gates = []
    for i in range(n, S):
        j, k, l = next((j, k, l) for (ii, j, k, l), v in sel.items() if ii == i and v in m)
        imm = sum(1 << p for p in range(8) if o[(i, p)] in m)
        gates.append((j, k, l, imm))
    outs = []
    for h in range(len(targets)):
        outs.append(next((i, pol) for (hh, i, pol), v in outv.items() if hh == h and v in m))
    return gates, outs

def synth(inputs, targets, rmin, rmax, M, log=sys.stderr, **kw):
    for r in range(rmin, rmax + 1):
        t0 = time.time()
        res = try_r(inputs, targets, r, M, **kw)
        print(f'  r={r}: {"SAT" if res else "UNSAT"} ({time.time() - t0:.1f}s)', file=log, flush=True)
        if res:
            return res
    return None

def show(inputs, targets, res, M):
    gates, outs = res
    names = [nm for nm, _ in inputs]
    full = (1 << M) - 1
    sig = [m for _, m in inputs]
    for (j, k, l, imm) in gates:
        sig.append(lop3_eval(imm, sig[j], sig[k], sig[l], full))
    nm = lambda z: names[z] if z < len(names) else f'g{z - len(names)}'
    lines = []
    for gi, (j, k, l, imm) in enumerate(gates):
        lines.append(f'  const u32 g{gi} = lop3<0x{imm:02x}>({nm(j)}, {nm(k)}, {nm(l)});')
    for h, (name, tm, pf) in enumerate(targets):
        i, pol = outs[h]
        ok = (sig[i] ^ (full if pol else 0)) == tm
        lines.append(f'  // {name} = {"~" if pol else ""}{nm(i)}   check={"ok" if ok else "BAD"}')
    return '\n'.join(lines)
