import sys
def write(fn, ins, outs, mins):
    with open(fn, 'w') as f:
        f.write(f'{len(ins)} {len(outs)} {len(mins)}\n')
        for name, fn_ in ins: f.write(f'{name} 0 ' + ''.join('1' if fn_(*m) else '0' for m in mins) + '\n')
        for name, pf, fn_ in outs: f.write(f'{name} {pf} ' + ''.join('1' if fn_(*m) else '0' for m in mins) + '\n')
def Sp(D, a, b):
    c = a + b; P = D == 9
    return 2 * D + c - 10 * P * c
# 1. no growth, inputs a, b
mins = [(D, a, b) for D in range(10) for a in (0, 1) for b in (0, 1)]
ins = [(f'd{q}', lambda D, a, b, q=q: (D >> q) & 1) for q in range(4)] + [('a', lambda D, a, b: a), ('b', lambda D, a, b: b), ('P', lambda D, a, b: D == 9)]
outs = [('c0', 1, lambda D, a, b: Sp(D, a, b) % 10 & 1)] + [(f'd{q}n', 1, lambda D, a, b, q=q: (Sp(D, a, b) % 10) >> q & 1) for q in (1, 2, 3)] + [('Gn', 0, lambda D, a, b: Sp(D, a, b) >= 10)]
write('ng.prob', ins, outs, mins)
# 2. no growth with alpha = a ^ P, beta = b ^ P as the inputs (raw chain sums)
mins2 = [(D, al, be) for D in range(10) for al in (0, 1) for be in (0, 1)]
def A(D, al): return al ^ (D == 9)
ins2 = [(f'd{q}', lambda D, al, be, q=q: (D >> q) & 1) for q in range(4)] + [('al', lambda D, al, be: al), ('be', lambda D, al, be: be), ('P', lambda D, al, be: D == 9)]
outs2 = [('c0', 1, lambda D, al, be: Sp(D, A(D, al), A(D, be)) % 10 & 1)] + [(f'd{q}n', 1, lambda D, al, be, q=q: (Sp(D, A(D, al), A(D, be)) % 10) >> q & 1) for q in (1, 2, 3)] + [('Gn', 0, lambda D, al, be: Sp(D, A(D, al), A(D, be)) >= 10)]
write('ng_ab.prob', ins2, outs2, mins2)
# 3. inc10 (D + c) mod 10
mins3 = [(D, c) for D in range(10) for c in (0, 1)]
ins3 = [(f'd{q}', lambda D, c, q=q: (D >> q) & 1) for q in range(4)] + [('c', lambda D, c: c), ('P', lambda D, c: D == 9)]
outs3 = [(f'o{q}', 1, lambda D, c, q=q: ((D + c) % 10) >> q & 1) for q in range(4)]
write('inc10.prob', ins3, outs3, mins3)
# 3b. inc10 with beta = c ^ P
outs3b = [(f'o{q}', 1, lambda D, be, q=q: ((D + (be ^ (D == 9))) % 10) >> q & 1) for q in range(4)]
write('inc10_b.prob', ins3, outs3b, mins3)
# 4. growth add: D' = (D + a + y) mod 10, G' = (D + a + y >= 10) & !(P & a)   [lo = (D+a)%10; S' = lo + y]
mins4 = [(D, y, a) for D in range(10) for y in range(10) for a in (0, 1)]
ins4 = [(f'd{q}', lambda D, y, a, q=q: (D >> q) & 1) for q in range(4)] + [(f'y{q}', lambda D, y, a, q=q: (y >> q) & 1) for q in range(4)] + [('a', lambda D, y, a: a), ('P', lambda D, y, a: D == 9)]
def Sg(D, y, a): return (D + a) % 10 + y
outs4 = [(f'n{q}', 1, lambda D, y, a, q=q: (Sg(D, y, a) % 10) >> q & 1) for q in range(4)] + [('Gn', 0, lambda D, y, a: Sg(D, y, a) >= 10)]
write('gadd.prob', ins4, outs4, mins4)
print('ok')
