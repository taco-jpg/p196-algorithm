// cgp.c - Cartesian-genetic-programming search for small multi-output LOP3 circuits (3-input gates).
// Problem file (text): first line "NIN NOUT M"; then NIN input rows and NOUT output rows, each row:
//   name polfree(0/1) bitstring-of-length-M (minterm t = character t)
// Output: best circuit found (fewest active gates with zero errors), as LOP3 lines.
// usage: cgp PROBLEM NODES SECONDS SEED
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

#define W 4            // up to 256 minterms
typedef struct { uint64_t w[W]; } TT;
static int NIN, NOUT, M, NW;
static TT in[32], target[16], careMask;
static int polfree[16];
static char inname[32][32], outname[16][32];
static int NN;  // nodes

typedef struct { int a, b, c; uint8_t imm; } Node;
typedef struct { Node n[64]; int out[16]; int pol[16]; } Gen;

static uint64_t rs;
static inline uint64_t rnd(void) { rs ^= rs << 13; rs ^= rs >> 7; rs ^= rs << 17; return rs; }

static inline TT lop(uint8_t imm, const TT* x, const TT* y, const TT* z) {
  TT r;
  for (int i = 0; i < NW; ++i) {
    uint64_t a = x->w[i], b = y->w[i], c = z->w[i], v = 0;
    if (imm & 0x01) v |= ~a & ~b & ~c;
    if (imm & 0x02) v |= ~a & ~b & c;
    if (imm & 0x04) v |= ~a & b & ~c;
    if (imm & 0x08) v |= ~a & b & c;
    if (imm & 0x10) v |= a & ~b & ~c;
    if (imm & 0x20) v |= a & ~b & c;
    if (imm & 0x40) v |= a & b & ~c;
    if (imm & 0x80) v |= a & b & c;
    r.w[i] = v;
  }
  return r;
}
static int pc(const TT* t) { int s = 0; for (int i = 0; i < NW; ++i) s += __builtin_popcountll(t->w[i] & careMask.w[i]); return s; }

// evaluate: returns errors; *cost = active nodes
static int eval(const Gen* g, int* cost) {
  static TT sig[96];
  char active[96];
  memset(active, 0, sizeof active);
  for (int h = 0; h < NOUT; ++h) active[g->out[h]] = 1;
  for (int i = NIN + NN - 1; i >= NIN; --i)
    if (active[i]) { const Node* n = &g->n[i - NIN]; active[n->a] = active[n->b] = active[n->c] = 1; }
  for (int i = 0; i < NIN; ++i) sig[i] = in[i];
  int cst = 0;
  for (int i = NIN; i < NIN + NN; ++i)
    if (active[i]) { const Node* n = &g->n[i - NIN]; sig[i] = lop(n->imm, &sig[n->a], &sig[n->b], &sig[n->c]); ++cst; }
  int err = 0;
  for (int h = 0; h < NOUT; ++h) {
    TT d;
    for (int i = 0; i < NW; ++i) d.w[i] = sig[g->out[h]].w[i] ^ target[h].w[i] ^ (g->pol[h] ? ~0ull : 0ull);
    err += pc(&d);
  }
  *cost = cst;
  return err;
}
static void randnode(Gen* g, int k) {
  int lim = NIN + k;
  g->n[k].a = rnd() % lim; g->n[k].b = rnd() % lim; g->n[k].c = rnd() % lim; g->n[k].imm = rnd() & 255;
}
static void mutate(Gen* g) {
  int nm = 1 + rnd() % 3;
  for (int t = 0; t < nm; ++t) {
    int r = rnd() % (NN * 4 + NOUT * 2);
    if (r < NN * 4) {
      int k = r / 4, f = r % 4, lim = NIN + k;
      if (f == 0) g->n[k].a = rnd() % lim;
      else if (f == 1) g->n[k].b = rnd() % lim;
      else if (f == 2) g->n[k].c = rnd() % lim;
      else { if (rnd() & 1) g->n[k].imm ^= 1 << (rnd() & 7); else g->n[k].imm = rnd() & 255; }
    } else {
      int h = (r - NN * 4) / 2;
      if ((r & 1) == 0) g->out[h] = NIN + rnd() % NN;
      else if (polfree[h]) g->pol[h] ^= 1;
    }
  }
}
int main(int argc, char** argv) {
  FILE* f = fopen(argv[1], "r");
  NN = atoi(argv[2]);
  double secs = atof(argv[3]);
  rs = 0x9E3779B97F4A7C15ull ^ (uint64_t)atoll(argv[4]);
  if (fscanf(f, "%d %d %d", &NIN, &NOUT, &M) != 3) return 1;
  NW = (M + 63) / 64;
  static char buf[1024];
  for (int i = 0; i < NIN + NOUT; ++i) {
    int pf; if (fscanf(f, "%31s %d %1023s", i < NIN ? inname[i] : outname[i - NIN], &pf, buf) != 3) return 1;
    TT t; memset(&t, 0, sizeof t);
    for (int k = 0; k < M; ++k) if (buf[k] == '1') t.w[k / 64] |= 1ull << (k % 64);
    if (i < NIN) in[i] = t; else { target[i - NIN] = t; polfree[i - NIN] = pf; }
  }
  memset(&careMask, 0, sizeof careMask);
  for (int k = 0; k < M; ++k) careMask.w[k / 64] |= 1ull << (k % 64);
  Gen seed; int haveSeed = 0;
  if (argc > 5) {
    FILE* sf = fopen(argv[5], "r");
    char nmS[96][32]; int ns = 0;
    for (int i = 0; i < NIN; ++i) strcpy(nmS[i], inname[i]);
    for (int k = 0; k < NN; ++k) randnode(&seed, k);
    char l[256];
    int gk = 0;
    while (fgets(l, sizeof l, sf)) {
      char a[32], b[32], c[32], d[32]; unsigned imm; int pol;
      if (sscanf(l, "G %31s %x %31s %31s %31s", d, &imm, a, b, c) == 5) {
        int ia = -1, ib = -1, ic = -1;
        for (int i = 0; i < NIN + gk; ++i) { if (!strcmp(nmS[i], a)) ia = i; if (!strcmp(nmS[i], b)) ib = i; if (!strcmp(nmS[i], c)) ic = i; }
        if (ia < 0 || ib < 0 || ic < 0) { fprintf(stderr, "seed: unknown name in %s", l); return 1; }
        seed.n[gk].a = ia; seed.n[gk].b = ib; seed.n[gk].c = ic; seed.n[gk].imm = (uint8_t)imm;
        strcpy(nmS[NIN + gk], d); ++gk;
      } else if (sscanf(l, "O %d %31s %d", &pol, a, &ns) == 3) {
        int h = pol, ia = -1;
        for (int i = 0; i < NIN + gk; ++i) if (!strcmp(nmS[i], a)) ia = i;
        seed.out[h] = ia; seed.pol[h] = ns;
      }
    }
    haveSeed = 1;
    int sc, se = eval(&seed, &sc);
    fprintf(stderr, "seed: %d gates, %d errors\n", sc, se);
  }
  Gen best; int bestCost = 1 << 30, bestErr = 1 << 30;
  clock_t t0 = clock();
  long long evals = 0, restarts = 0;
  while ((double)(clock() - t0) / CLOCKS_PER_SEC < secs) {
    Gen p; for (int k = 0; k < NN; ++k) randnode(&p, k);
    for (int h = 0; h < NOUT; ++h) { p.out[h] = NIN + rnd() % NN; p.pol[h] = 0; }
    if (haveSeed) p = seed;
    int pc_, pe = eval(&p, &pc_);
    ++restarts;
    for (long it = 0; it < 400000; ++it) {
      Gen c = p; mutate(&c);
      int cc, ce = eval(&c, &cc); ++evals;
      if (ce < pe || (ce == pe && cc <= pc_)) { p = c; pe = ce; pc_ = cc; }
      if (pe == 0 && (pc_ < bestCost)) { best = p; bestCost = pc_; bestErr = 0;
        fprintf(stderr, "  found %d gates (restart %lld, %.1fs)\n", pc_, restarts, (double)(clock() - t0) / CLOCKS_PER_SEC); }
    }
  }
  if (bestErr) { printf("no exact circuit found\n"); return 2; }
  // print active nodes
  char active[96]; memset(active, 0, sizeof active);
  for (int h = 0; h < NOUT; ++h) active[best.out[h]] = 1;
  for (int i = NIN + NN - 1; i >= NIN; --i)
    if (active[i]) { Node* n = &best.n[i - NIN]; active[n->a] = active[n->b] = active[n->c] = 1; }
  char nm[96][32];
  for (int i = 0; i < NIN; ++i) strcpy(nm[i], inname[i]);
  int gi = 0;
  printf("// %d gates\n", bestCost);
  for (int i = NIN; i < NIN + NN; ++i)
    if (active[i]) { Node* n = &best.n[i - NIN]; sprintf(nm[i], "t%d", gi++);
      printf("  const u32 %s = lop3<0x%02x>(%s, %s, %s);\n", nm[i], n->imm, nm[n->a], nm[n->b], nm[n->c]); }
  for (int h = 0; h < NOUT; ++h) printf("  // %s = %s%s\n", outname[h], best.pol[h] ? "~" : "", nm[best.out[h]]);
  return 0;
}
