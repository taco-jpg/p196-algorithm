#!/usr/bin/env python3
"""Normalize a CGP circuit listing (from cgp) so that every output is in true polarity, absorbing
inversions into consumer gates' truth tables, then emit C code and verify against a problem file.
usage: norm.py PROBLEM CIRCUIT_TXT FUNCNAME OUTVAR1,OUTVAR2,..."""
import re, sys
prob, circ = sys.argv[1], sys.argv[2]
lines = open(prob).read().split('\n')
nin, nout, M = map(int, lines[0].split())
ins, outs = [], []
for i in range(nin):
    nm, pf, bits = lines[1 + i].split(); ins.append((nm, int(bits[::-1], 2)))
for h in range(nout):
    nm, pf, bits = lines[1 + nin + h].split(); outs.append((nm, int(bits[::-1], 2)))
full = (1 << M) - 1
gates = []  # (name, imm, [a, b, c])
outmap = {}
for l in open(circ):
    m = re.match(r'\s*const u32 (\w+) = lop3<0x([0-9a-f]+)>\((\w+), (\w+), (\w+)\);', l)
    if m: gates.append([m.group(1), int(m.group(2), 16), [m.group(3), m.group(4), m.group(5)]]); continue
    m = re.match(r'\s*// (\w+) = (~?)(\w+)', l)
    if m and not m.group(1).isdigit(): outmap[m.group(1)] = (m.group(3), m.group(2) == '~')
def flip_input(imm, k):  # operand k (0 = a, 1 = b, 2 = c) inverted
    bit = 4 >> k
    return sum(((imm >> (p ^ bit)) & 1) << p for p in range(8))
# signals to invert: outputs with polarity '~' (a gate used both ways would need an extra gate)
inv = set()
for o, (g, neg) in outmap.items():
    if neg: inv.add(g)
for o, (g, neg) in outmap.items():
    if not neg and g in inv: raise SystemExit(f'signal {g} needed in both polarities')
for gname in inv:
    for G in gates:
        if G[0] == gname: G[1] ^= 0xFF
        for k in range(3):
            if G[2][k] == gname: G[1] = flip_input(G[1], k)
# verify
sig = {nm: v for nm, v in ins}
def ev(imm, a, b, c):
    v = 0
    for p in range(8):
        if (imm >> p) & 1:
            v |= (a if p & 4 else ~a) & (b if p & 2 else ~b) & (c if p & 1 else ~c)
    return v & full
for name, imm, (a, b, c) in gates:
    sig[name] = ev(imm, sig[a], sig[b], sig[c])
ok = all(sig[outmap[o][0]] == tm for o, tm in outs)
print(f'// {len(gates)} gates, verified: {ok}')
for name, imm, (a, b, c) in gates:
    print(f'  const u32 {name} = lop3<0x{imm:02x}>({a}, {b}, {c});')
for o, tm in outs:
    print(f'  // {o} = {outmap[o][0]}')
