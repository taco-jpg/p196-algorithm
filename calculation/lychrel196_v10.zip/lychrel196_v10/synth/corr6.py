import os, sys; sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from exact2 import synth, show
mins = list(range(20))
inputs = [(f'r{q}', sum(1 << t for t, T in enumerate(mins) if (((T + 6) % 16) >> q) & 1)) for q in (1, 2, 3)] + [('k4', sum(1 << t for t, T in enumerate(mins) if T + 6 >= 16))]
targets = [(f'n{q}', sum(1 << t for t, T in enumerate(mins) if ((T % 10) >> q) & 1), False) for q in (1, 2, 3)]
M = len(mins)
res = synth(inputs, targets, 1, 6, M)
if res: print(show(inputs, targets, res, M))
