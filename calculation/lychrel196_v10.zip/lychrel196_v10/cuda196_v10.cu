// cuda196_v10.cu - exact 196 reverse-and-add, bit-sliced, time-blocked, persistent run mode.
// v10 = v9 + decimal pair-sum arithmetic inside the warp windows (bits_tb10.h, dg_arith.h) + the slow
// per-step tiles (block 0 and the middle of the number) scheduled first in every launch.
// Build: nvcc -O3 -std=c++17 -arch=sm_89 cuda196_v10.cu -o cuda196_v10
//   defaults: 512 threads, TB_J=64, TB_PIPEBAL=1. Options: -DTB_THREADS=256|288|512, -DTB_J=1..64,
//   -DTB_PIPEBAL=0|1; runtime --hybrid=0|1, --fp=0|1, --K=, --tile= (512 threads: up to 1900 at K=128).
// Command line, checkpoint format and latest.json are those of v9 (engine name "cuda196_v10").
#include <cuda_runtime.h>
#include <climits>
#include "driver10.h"
#include "warp_ops.h"
#include "prof.h"
using bits::u32;

#define CHECK(x)                                                                           \
  do {                                                                                     \
    cudaError_t e_ = (x);                                                                  \
    if (e_ != cudaSuccess) {                                                               \
      fprintf(stderr, "CUDA %s at %s:%d\n", cudaGetErrorString(e_), __FILE__, __LINE__); \
      exit(2);                                                                             \
    }                                                                                      \
  } while (0)

static constexpr int STEP_THREADS = 256;

// ---- v4 per-step kernel (unchanged logic; validated on RTX 4050) ----
__global__ void __launch_bounds__(STEP_THREADS)
step_kernel(const u32* __restrict__ src, u32* __restrict__ dst, const long long* __restrict__ nIn, long long* __restrict__ nOut,
            unsigned* __restrict__ bad, int slot, int Wcap) {
  const int w = blockIdx.x * blockDim.x + threadIdx.x;
  const long long n = *nIn;
  unsigned mism = 0;
  int g = 0;
  if (w < Wcap && 32LL * w <= (n + 2) / 2 + 32) mism = bits::step_word(src, dst, Wcap, n, w, &g);
  if (w == 0) *nOut = n + g;
  if (__syncthreads_or((int)mism) && threadIdx.x == 0) atomicOr(bad + slot, 1u);
}

// ---- time-blocked kernel: K steps per launch, tile in shared memory ----
#ifndef TB_MINBLOCKS
#if TB_THREADS >= 512
#define TB_MINBLOCKS 1
#else
#define TB_MINBLOCKS 2  // register cap: 65536/(256*2) = 128 regs/thread. A/B test 1 and 2 on the GPU.
#endif
#endif
__global__ void __launch_bounds__(tb::THREADS, TB_MINBLOCKS)
tb_kernel(const u32* __restrict__ src, u32* __restrict__ dst, const long long* __restrict__ nIn, long long* __restrict__ nOut,
          unsigned* __restrict__ quiet, unsigned* __restrict__ fail, const unsigned* __restrict__ tape,
          tb::Conf c, int K) {
  extern __shared__ __align__(16) unsigned char smem_raw[];
  tb::State& S = *reinterpret_cast<tb::State*>(smem_raw);
  u32* base = reinterpret_cast<u32*>(smem_raw + tb::state_bytes());  // 16-byte aligned rows
  const int tid = threadIdx.x;
  c.K = K;
  // v10: the last two tiles (the middle of the number, which runs the slower per-step v6r3 path) and
  // tile 0 (also v6r3) are scheduled first, so they overlap the other blocks instead of forming the
  // tail of the launch. Results do not depend on the order (blocks are independent within a launch).
  const int nb = (int)gridDim.x;
  const int blk = nb >= 3 ? ((int)blockIdx.x < 2 ? nb - 1 - (int)blockIdx.x : (int)blockIdx.x - 2) : (int)blockIdx.x;
  if (tid == 0) tb::ph_setup(S, c, blk, *nIn);
  __syncthreads();
  if (S.dead) {  // owns only words that cannot hold data: quiet in every step
    for (int t = tid; t < K; t += tb::THREADS) atomicAdd(quiet + t, 1u);
    return;
  }
  if (S.hy) {  // v8 hybrid interior block: TB_J steps per barrier, growth bits from the control tape
    if (!tape[tb::KMAX / 32]) {  // tape not certified: the window replays exactly
      if (tid == 0) atomicOr(fail, 1u);
      return;
    }
    // v10: tile only (no prefix tile, no ph_init), spans and mismatch bitmask in the same phase
    tb::ph_load_tile(S, c, base, src, tid, tb::THREADS);
    tb::hy_init_spans(S, c, base, tid, tb::THREADS);
    __syncthreads();
    const int G = S.len / 4;
    const int warp = tid >> 5, lane = tid & 31;
    const bool act = tb::WY_CORE * warp < G;  // v9: warps without core groups only wait at the barrier
    int par = 0;
    for (int t0 = 0; t0 < K; t0 += TB_J) {
      const int js = K - t0 < TB_J ? K - t0 : TB_J;
      const tb::u64 gb = tb::tape_bits64(tape, t0, js);
      tb::u64 m = 0;
      if (act) m = tb::wy_window<tb::DevOps>(S, c, base, warp, lane, par, js, gb);  // OR over the warp
      if (lane == 0 && m) tb::qm_or(S.qm, t0, m);
      __syncthreads();
      par ^= 1;
    }
    for (int t = tid; t < K; t += tb::THREADS)  // v10: one step per thread (v9: thread 0 looped over K)
      if (!((S.qm[t >> 5] >> (t & 31)) & 1u)) atomicAdd(quiet + t, 1u);
    if (tid == 0 && !S.hyok) atomicOr(fail, 1u);
    tb::ph_store_par(S, c, base, dst, par, tid, tb::THREADS);
    return;
  }
  tb::ph_load(S, c, base, src, tid, tb::THREADS);
  __syncthreads();
  if (tid == 0) tb::ph_init(S, c, base);
  __syncthreads();
  long long n = S.n0;
  int g = S.gS[0];
  const tb::WorkCtx w = tb::work_ctx(S, tid, tb::THREADS);  // v6r3: per-launch constants in registers
  unsigned qacc = 0;  // lane 0 of each warp: bit (t & 31) = some lane of this warp saw a mismatch
  PROF_DECL
  for (int t = 0; t < K; ++t) {
    PROF_A
    tb::ph_track(S, c, base, t, n, g, tid);
    PROF_B
#if TB_WORK_REPEAT > 1
    u32 m = 0;
#pragma unroll 1
    for (int r_ = 0; r_ < TB_WORK_REPEAT; ++r_) {  // diagnostic only: idempotent repeat, one code copy
      PROF_COMPILER_FENCE;
      m |= tb::ph_work(S, c, base, w, t, n, g, tid);
    }
#else
    u32 m = tb::ph_work(S, c, base, w, t, n, g, tid);
#endif
    PROF_C
    qacc |= (unsigned)__any_sync(0xffffffffu, (int)(m & 1u)) << (t & 31);
    const int gn = __syncthreads_count(tid == 0 && (m & 2u));  // g_{t+1} from thread 0, via the barrier
    PROF_D
    if ((t & 31) == 31 || t == K - 1) {
      if ((tid & 31) == 0 && qacc) atomicOr(&S.qm[t >> 5], qacc);
      qacc = 0;
    }
    n += g;
    g = gn;
  }
  PROF_END(K)
  __syncthreads();  // S.qm complete
  for (int t = tid; t < K; t += tb::THREADS)
    if (!((S.qm[t >> 5] >> (t & 31)) & 1u)) atomicAdd(quiet + t, 1u);
  if (tid == 0 && !tb::ph_verdict(S, n)) atomicOr(fail, 1u);
  tb::ph_store(S, c, base, dst, K, tid, tb::THREADS);
  if (blk == 0 && tid == 0) *nOut = n;
}

// v8 control tape: the prefix tile alone, K steps, same code as every block's prefix. Writes the
// growth bits g_0..g_{K-1} (bit t of word t/32) and, at index KMAX/32, whether the prefix tracker
// kept them certified. 64 threads: warp 0 works the prefix groups (thread 0 decodes growth),
// thread 33 tracks the prefix interval. c.lenMax = 0 (no tile buffers).
__global__ void __launch_bounds__(64)
tape_kernel(const u32* __restrict__ src, const long long* __restrict__ nIn, unsigned* __restrict__ tape, tb::Conf c, int K) {
  extern __shared__ __align__(16) unsigned char smem_raw[];
  tb::State& S = *reinterpret_cast<tb::State*>(smem_raw);
  u32* base = reinterpret_cast<u32*>(smem_raw + tb::state_bytes());
  const int tid = threadIdx.x;
  c.K = K;
  if (tid == 0) { tb::ph_setup(S, c, 0, *nIn); S.len = 0; S.okT = 0; }
  __syncthreads();
  tb::ph_load(S, c, base, src, tid, 64);
  __syncthreads();
  if (tid == 0) tb::ph_init(S, c, base);
  __syncthreads();
  long long n = S.n0;
  int g = S.gS[0];
  const tb::WorkCtx w = tb::work_ctx(S, tid, 64);
  for (int t = 0; t < K; ++t) {
    tb::ph_track(S, c, base, t, n, g, tid);
    const u32 m = tb::ph_work(S, c, base, w, t, n, g, tid);
    const int gn = __syncthreads_count(tid == 0 && (m & 2u));
    n += g;
    g = gn;
  }
  __syncthreads();
  if (tid == 0) {
    for (int i = 0; i < tb::KMAX / 32; ++i) {
      unsigned v = 0;
      const int nb = K - 32 * i;  // bits of this word that are steps < K
      if (nb > 0) v = nb >= 32 ? S.gbits[i] : (S.gbits[i] & ((1u << nb) - 1u));
      tape[i] = v;
    }
    tape[tb::KMAX / 32] = (unsigned)S.okP;
  }
}

// v9 fingerprint: acc[0] += sum of all pair sums S_j (j < h), acc[1] = S_mid (pair h-1) if n is odd.
__global__ void __launch_bounds__(256) fp_kernel(const u32* __restrict__ s, const long long* __restrict__ nIn,
                                                 unsigned long long* __restrict__ acc, int Wcap) {
  const long long n = *nIn;
  const int h = (int)((n + 1) / 2), W = (h + 31) / 32;
  unsigned long long t = 0;
  for (int w = blockIdx.x * blockDim.x + threadIdx.x; w < W; w += gridDim.x * blockDim.x) {
    const u32 m = bits::hmask(w, h);
    for (int q = 0; q < 5; ++q) t += (unsigned long long)__popc(s[(size_t)q * Wcap + w] & m) << q;
    if ((n & 1) && w == (h - 1) / 32) {
      const int b = (h - 1) & 31;
      unsigned v = 0;
      for (int q = 0; q < 5; ++q) v |= ((s[(size_t)q * Wcap + w] >> b) & 1u) << q;
      acc[1] = v;
    }
  }
  for (int o = 16; o; o >>= 1) t += __shfl_down_sync(0xffffffffu, t, o);
  if ((threadIdx.x & 31) == 0 && t) atomicAdd(acc, t);
}

// Gate test only (V10_FAULT=N): flip one state bit after the N-th time-blocked launch, as a hardware
// error would; the mod-9 fingerprint must catch it and the window must replay exactly.
__global__ void fault_kernel(u32* s, int Wcap) { s[(size_t)2 * Wcap] ^= 1u << 3; }

// Palindrome at step t of the launch iff every block saw no mismatch.
__global__ void tb_finalize(unsigned* quiet, int K, int blocks, long long base, unsigned long long* pal) {
  for (int t = threadIdx.x; t < K; t += blockDim.x) {
    if (quiet[t] == (unsigned)blocks) atomicMin(pal, (unsigned long long)(base + t + 1));
    quiet[t] = 0;
  }
}

struct CudaBackend {
  u32 *s[2] = {nullptr, nullptr}, *bk = nullptr;
  long long *dn[2] = {nullptr, nullptr}, *dnbk = nullptr;  // v8b: 64-bit digit counts
  unsigned *dBad = nullptr, *dQuiet = nullptr, *dFail = nullptr, *dTape = nullptr;
  size_t smemTape = 0;
  tb::Conf confTape{};
  unsigned long long* dPal = nullptr;
  unsigned long long* dFp = nullptr;  // v9 fingerprint accumulators
  int Wcap = 0, cur = 0, batch = 0, graphBlocks = 0, bkWords = 0, dev = -1, sms = 0;
  size_t smem = 0;
  tb::Conf conf{};
  cudaStream_t st = nullptr;
  cudaGraphExec_t exec[2] = {nullptr, nullptr};
  cudaEvent_t ev0 = nullptr, ev1 = nullptr;
  bool evOpen = false;
  double devSec = 0;
  char nameBuf[320];
  double deviceSeconds() const { return devSec; }
  void evBegin() { if (!evOpen) { CHECK(cudaEventRecord(ev0, st)); evOpen = true; } }
  void evEnd() {  // call before a stream synchronize
    if (!evOpen) return;
    CHECK(cudaEventRecord(ev1, st));
    CHECK(cudaEventSynchronize(ev1));
    float ms = 0;
    CHECK(cudaEventElapsedTime(&ms, ev0, ev1));
    devSec += ms / 1000.0;
    evOpen = false;
  }

  void ensureDevice() {
    if (dev >= 0) return;
    cudaDeviceProp prop;
    CHECK(cudaGetDevice(&dev));
    CHECK(cudaGetDeviceProperties(&prop, dev));
    sms = prop.multiProcessorCount;
    snprintf(nameBuf, sizeof nameBuf, "cuda-v10(%.200s, %d SMs)", prop.name, sms);
    CHECK(cudaFuncSetAttribute(tb_kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, (int)prop.sharedMemPerBlockOptin));
    CHECK(cudaFuncSetAttribute(tape_kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, (int)prop.sharedMemPerBlockOptin));
  }
  const char* name() { ensureDevice(); return nameBuf; }
  int numSMs() { ensureDevice(); return sms; }
  int tbBlocksPerSM(size_t bytes) {
    ensureDevice();
    int nb = 0;
    if (cudaOccupancyMaxActiveBlocksPerMultiprocessor(&nb, tb_kernel, tb::THREADS, bytes) != cudaSuccess) {
      cudaGetLastError();
      return 0;
    }
    return nb;
  }
  void enqueueSteps(int count, int from, int blocks) {
    CHECK(cudaMemsetAsync(dBad, 0, sizeof(unsigned) * count, st));
    for (int i = 0; i < count; ++i) {
      int a = (from + i) & 1;
      step_kernel<<<blocks, STEP_THREADS, 0, st>>>(s[a], s[1 - a], dn[a], dn[1 - a], dBad, i, Wcap);
    }
  }
  void captureGraphs(int blocks) {
    for (int from = 0; from < 2; ++from) {
      if (exec[from]) CHECK(cudaGraphExecDestroy(exec[from]));
      cudaGraph_t gph;
      CHECK(cudaStreamBeginCapture(st, cudaStreamCaptureModeGlobal));
      enqueueSteps(batch, from, blocks);
      CHECK(cudaStreamEndCapture(st, &gph));
      CHECK(cudaGraphInstantiate(&exec[from], gph, 0));
      CHECK(cudaGraphDestroy(gph));
    }
    graphBlocks = blocks;
  }
  void init(const std::vector<u32>& pl, long long n0, int W, const tb::Conf& c, int b) {
    ensureDevice();
    Wcap = W; conf = c; batch = b;
    smem = tb::smem_bytes(c);
    confTape = c; confTape.lenMax = 0;  // the tape kernel has no tile buffers
    smemTape = tb::smem_bytes(confTape);
    const size_t bytes = sizeof(u32) * 5 * (size_t)W;
    for (int i = 0; i < 2; ++i) {
      CHECK(cudaMalloc(&s[i], bytes)); CHECK(cudaMemset(s[i], 0, bytes));
      CHECK(cudaMalloc(&dn[i], sizeof(long long)));
    }
    CHECK(cudaMalloc(&bk, bytes)); CHECK(cudaMalloc(&dnbk, sizeof(long long)));
    CHECK(cudaMalloc(&dBad, sizeof(unsigned) * std::max(b, 1)));
    CHECK(cudaMalloc(&dQuiet, sizeof(unsigned) * tb::KMAX)); CHECK(cudaMemset(dQuiet, 0, sizeof(unsigned) * tb::KMAX));
    CHECK(cudaMalloc(&dFail, sizeof(unsigned))); CHECK(cudaMemset(dFail, 0, sizeof(unsigned)));
    CHECK(cudaMalloc(&dTape, sizeof(unsigned) * (tb::KMAX / 32 + 1))); CHECK(cudaMemset(dTape, 0, sizeof(unsigned) * (tb::KMAX / 32 + 1)));
    CHECK(cudaMalloc(&dPal, sizeof(unsigned long long))); CHECK(cudaMemset(dPal, 0xFF, sizeof(unsigned long long)));
    CHECK(cudaMalloc(&dFp, 2 * sizeof(unsigned long long)));
    CHECK(cudaMemcpy(s[0], pl.data(), bytes, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(dn[0], &n0, sizeof(long long), cudaMemcpyHostToDevice));
    CHECK(cudaStreamCreate(&st));
    CHECK(cudaEventCreate(&ev0));
    CHECK(cudaEventCreate(&ev1));
    cur = 0;
    if (tbBlocksPerSM(smem) < 1)
      throw std::runtime_error("tile does not fit in shared memory; lower --tile or --K");
  }
  void stepRun(int count, std::vector<unsigned>& bad, int gridWords) {
    int blocks = (gridWords + STEP_THREADS - 1) / STEP_THREADS;
    if (count == batch && blocks > graphBlocks) captureGraphs(blocks + 8);  // capture outside the timed region
    evBegin();
    if (count == batch) {
      CHECK(cudaGraphLaunch(exec[cur], st));
    } else {
      enqueueSteps(count, cur, blocks);
    }
    evEnd();
    bad.assign(count, 0);
    CHECK(cudaMemcpyAsync(bad.data(), dBad, sizeof(unsigned) * count, cudaMemcpyDeviceToHost, st));
    CHECK(cudaStreamSynchronize(st));
    CHECK(cudaGetLastError());
    cur = (cur + count) & 1;
  }
  long long launches = 0, faultAt = -2;
  void tbLaunch(int k, long long baseIter, int blocks) {
    evBegin();
    if (conf.hy) tape_kernel<<<1, 64, smemTape, st>>>(s[cur], dn[cur], dTape, confTape, k);
    tb_kernel<<<blocks, tb::THREADS, smem, st>>>(s[cur], s[1 - cur], dn[cur], dn[1 - cur], dQuiet, dFail, dTape, conf, k);
    tb_finalize<<<1, 256, 0, st>>>(dQuiet, k, blocks, baseIter, dPal);
    cur ^= 1;
    if (faultAt == -2) { const char* f = getenv("V10_FAULT"); faultAt = f ? atoll(f) : -1; }
    if (++launches == faultAt) {
      fault_kernel<<<1, 1, 0, st>>>(s[cur], Wcap);
      fprintf(stderr, "[gpu] V10_FAULT: flipped one state bit after time-blocked launch %lld\n", launches);
    }
  }
  d5::TBResult tbSync() {
    evEnd();
    unsigned f = 0; unsigned long long p = 0; long long n = 0;
    CHECK(cudaMemcpyAsync(&f, dFail, sizeof f, cudaMemcpyDeviceToHost, st));
    CHECK(cudaMemcpyAsync(&p, dPal, sizeof p, cudaMemcpyDeviceToHost, st));
    CHECK(cudaMemcpyAsync(&n, dn[cur], sizeof n, cudaMemcpyDeviceToHost, st));
    CHECK(cudaMemsetAsync(dFail, 0, sizeof(unsigned), st));
    CHECK(cudaMemsetAsync(dPal, 0xFF, sizeof(unsigned long long), st));
    CHECK(cudaStreamSynchronize(st));
    CHECK(cudaGetLastError());
    return d5::TBResult{(int)f, p == ULLONG_MAX ? -1LL : (long long)p, n};
  }
  int mod9() {  // v9: E = 2*sum(S) - [n odd]*S_mid (mod 9) of the current state
    long long n = 0;
    unsigned long long a[2] = {0, 0};
    CHECK(cudaMemsetAsync(dFp, 0, 2 * sizeof(unsigned long long), st));
    fp_kernel<<<4 * std::max(1, sms), 256, 0, st>>>(s[cur], dn[cur], dFp, Wcap);
    CHECK(cudaMemcpyAsync(a, dFp, sizeof a, cudaMemcpyDeviceToHost, st));
    CHECK(cudaMemcpyAsync(&n, dn[cur], sizeof n, cudaMemcpyDeviceToHost, st));
    CHECK(cudaStreamSynchronize(st));
    CHECK(cudaGetLastError());
    long long e = (long long)(2 * (a[0] % 9)) - ((n & 1) ? (long long)a[1] : 0);
    return (int)(((e % 9) + 9) % 9);
  }
  long long currentN() {
    long long n;
    CHECK(cudaMemcpyAsync(&n, dn[cur], sizeof n, cudaMemcpyDeviceToHost, st));
    CHECK(cudaStreamSynchronize(st));
    return n;
  }
  void backup(int words) {
    bkWords = std::min(words, Wcap);
    for (int q = 0; q < 5; ++q)
      CHECK(cudaMemcpyAsync(bk + (size_t)q * Wcap, s[cur] + (size_t)q * Wcap, sizeof(u32) * bkWords, cudaMemcpyDeviceToDevice, st));
    CHECK(cudaMemcpyAsync(dnbk, dn[cur], sizeof(long long), cudaMemcpyDeviceToDevice, st));
  }
  void restore() {  // rare path: also wipe everything above the restored number
    for (int q = 0; q < 5; ++q) {
      CHECK(cudaMemcpyAsync(s[cur] + (size_t)q * Wcap, bk + (size_t)q * Wcap, sizeof(u32) * bkWords, cudaMemcpyDeviceToDevice, st));
      CHECK(cudaMemsetAsync(s[cur] + (size_t)q * Wcap + bkWords, 0, sizeof(u32) * (Wcap - bkWords), st));
    }
    CHECK(cudaMemsetAsync(s[1 - cur], 0, sizeof(u32) * 5 * (size_t)Wcap, st));
    CHECK(cudaMemcpyAsync(dn[cur], dnbk, sizeof(long long), cudaMemcpyDeviceToDevice, st));
    CHECK(cudaStreamSynchronize(st));
  }
  void download(bool previous, std::vector<u32>& pl, int& stride, long long& n) {
    int k = previous ? 1 - cur : cur;
    CHECK(cudaMemcpy(&n, dn[k], sizeof(long long), cudaMemcpyDeviceToHost));
    stride = (int)std::min<long long>(Wcap, (n + 1) / 2 / 32 + 2);
    pl.assign(5 * (size_t)stride, 0);
    for (int q = 0; q < 5; ++q)
      CHECK(cudaMemcpy(pl.data() + (size_t)q * stride, s[k] + (size_t)q * Wcap, sizeof(u32) * stride, cudaMemcpyDeviceToHost));
  }
  ~CudaBackend() {
    if (dev >= 0) prof_report(tb::THREADS);
    for (int i = 0; i < 2; ++i) { if (exec[i]) cudaGraphExecDestroy(exec[i]); cudaFree(s[i]); cudaFree(dn[i]); }
    cudaFree(bk); cudaFree(dnbk); cudaFree(dBad); cudaFree(dQuiet); cudaFree(dFail); cudaFree(dPal); cudaFree(dFp);
    if (ev0) cudaEventDestroy(ev0);
    if (ev1) cudaEventDestroy(ev1);
    if (st) cudaStreamDestroy(st);
  }
};

int main(int argc, char** argv) {
  try {
    CudaBackend be;
    return d5::mainEntry(be, argc, argv);
  } catch (const std::exception& e) {
    fprintf(stderr, "ERROR %s\n", e.what());
    return 2;
  }
}
