// dg_arith.h - v10 decimal pair-sum arithmetic for the warp windows (bit-sliced, 32 pairs per word).
//
// Inside a warp window every pair sum S_j = d_j + d_{n-1-j} (0..18) is held as S = D + 10 G:
// D = S mod 10 in 4 BCD planes (d0..d3) and G = (S >= 10) as one plane. G and P = (S == 9) = (D == 9)
// are exactly the carry generate / propagate planes, and one step needs only the carry INTO each pair
// (a_j from below, b_j from above), never the carries out of it:
//   lo_j = (S_j + a_j) mod 10 = D_j + a_j - 10 P_j a_j         new low digit j
//   hi_j = (S_j + b_j) mod 10 = D_j + b_j - 10 P_j b_j         new high digit n-1-j
// No growth:  S'_j = lo_j + hi_j = 2 D_j + c - 10 P_j c  with c = a_j + b_j, so
//   D'_j = (2 D_j + c) mod 10:  bit 0 = a ^ b,  bits 1..3 = binary of (D_j + (a & b)) mod 5,
//   G'_j = (D_j + (a & b) >= 5) and not (P_j and (a | b)).
// Growth:     S'_j = lo_j + hi_{j-1}, so (D'_j, G'_j) is a BCD add with carry-in:
//   D'_j = (D_j + a_j + hi_{j-1}) mod 10,  G'_j = (D_j + a_j + hi_{j-1} >= 10) and not (P_j and a_j).
// Palindrome test of the new number: no growth, pair j mismatches iff a_j != b_j = bit 0 of D'_j;
// growth, iff lo_j != hi_{j-1}; an odd new pair sum (bit 0 of D'_j) is always a mismatch.
// v9 (binary S, 5 planes) needed the carries out of every pair (a_{j+1}, b_{j-1}) as shifted words and a
// 5-plane subtract of 10 (a_{j+1} + b_{j-1}); here the no-growth update is 13 three-input gates per word.
// All formulas are checked exhaustively by tests/unit_dg.cpp (CPU) and end to end by the emulator.
#pragma once
#include "bits_core.h"

namespace dg {
using bits::u32;
using bits::u64;

// LOP3 with an explicit truth table (PTX lop3 convention: bit (4a + 2b + c) of IMM = f(a, b, c)).
template <unsigned IMM>
BHD u32 lop3(u32 a, u32 b, u32 c) {
#ifdef __CUDA_ARCH__
  u32 r;
  asm("lop3.b32 %0, %1, %2, %3, %4;" : "=r"(r) : "r"(a), "r"(b), "r"(c), "n"(IMM));
  return r;
#else
  u32 r = 0;
  if (IMM & 0x01) r |= ~a & ~b & ~c;
  if (IMM & 0x02) r |= ~a & ~b & c;
  if (IMM & 0x04) r |= ~a & b & ~c;
  if (IMM & 0x08) r |= ~a & b & c;
  if (IMM & 0x10) r |= a & ~b & ~c;
  if (IMM & 0x20) r |= a & ~b & c;
  if (IMM & 0x40) r |= a & b & ~c;
  if (IMM & 0x80) r |= a & b & c;
  return r;
#endif
}
BHD u32 maj(u32 x, u32 y, u32 z) { return lop3<0xE8>(x, y, z); }
BHD u32 xor3(u32 x, u32 y, u32 z) { return lop3<0x96>(x, y, z); }

// binary pair-sum planes (S = s0 + 2 s1 + ... + 16 s4) <-> decimal (D, G)
BHD void from_bin(const u32 s[5], u32 d[4], u32& G) {
  G = s[4] | (s[3] & (s[2] | s[1]));
  const u32 b1 = ~s[1] & G;  // subtract 10 = 0b1010: borrow out of bit 1
  d[0] = s[0];
  d[1] = s[1] ^ G;
  d[2] = s[2] ^ b1;
  d[3] = s[3] ^ G ^ (~s[2] & b1);
}
BHD void to_bin(const u32 d[4], u32 G, u32 s[5]) {
  s[0] = d[0];
  s[1] = d[1] ^ G;
  u32 c = d[1] & G;
  s[2] = d[2] ^ c;
  c = d[2] & c;
  s[3] = xor3(d[3], G, c);
  s[4] = maj(d[3], G, c);
}
BHD u32 Pof(const u32 d[4]) { return d[3] & d[0]; }  // S == 9 (D == 9; G = 1 implies D <= 8)

// The carry chains below return RAW sums: al = (X + G + carries) and be = the same for the high chain,
// so the carries are a = al ^ P and b = be ^ P (P = X ^ G, the propagate plane). The circuits take al/be
// directly and absorb those XORs (gate lists found by a CGP search over 3-input gates, verified
// exhaustively by tests/unit_dg.cpp).

// No-growth step for one word, in place: 10 gates. Returns a ^ b (= the new d0, the mismatch bits).
BHD u32 step_ng(u32 d[4], u32& G, u32 al, u32 be, u32 P) {
  const u32 d0 = d[0], d1 = d[1], d2 = d[2], d3 = d[3];
  const u32 t0 = lop3<0xe7>(d2, d1, d0);
  const u32 t1 = lop3<0x93>(be, d0, al);
  const u32 t2 = lop3<0x46>(al, al, be);   // al ^ be = a ^ b
  const u32 t3 = lop3<0x42>(t0, P, t1);
  const u32 t4 = lop3<0x06>(t3, d2, d3);   // G'
  const u32 t5 = lop3<0x0a>(t2, d2, d3);
  const u32 t6 = lop3<0x09>(P, t4, t1);    // d'1
  const u32 t7 = lop3<0x06>(t6, t3, t5);   // d'3
  const u32 t8 = lop3<0x9f>(t1, d0, t4);
  const u32 t9 = lop3<0x99>(be, d1, t8);   // d'2
  d[0] = t2; d[1] = t6; d[2] = t9; d[3] = t7; G = t4;
  return t2;
}

// Growth step. The high digit of each pair is produced in excess-6 form, hi + 6 (6..15), so that in the
// BCD add D + a + (hi + 6) the binary carry out of bit 3 is exactly the decimal carry (D + a + hi >= 10);
// the low 4 bits are then D' itself when that carry is 1 and D' + 6 when it is 0 (3-gate correction).
// (D + c) mod 10 + 6 with c = be ^ P (be a raw chain sum): 5 gates.
BHD void inc10x6(const u32 d[4], u32 be, u32 P, u32 o[4]) {
  const u32 t0 = lop3<0x27>(d[3], be, d[0]);
  const u32 t1 = lop3<0xb6>(t0, d[1], d[3]);
  const u32 t2 = lop3<0x96>(d[0], P, be);
  const u32 t3 = lop3<0xf7>(d[2], t0, t1);
  const u32 t4 = lop3<0xc6>(d[1], d[2], t1);
  o[0] = t2; o[1] = t1; o[2] = t4; o[3] = t3;
}

// Growth step for one word, in place: (D, G) <- D + a + y with y = hi_{j-1} + 6 (excess 6), a = low
// carry-in; G' cleared where P & a (that pair's low digit wrapped to 0, so the sum is hi_{j-1} <= 9).
// 8 gates of ripple add + 3 of correction + 1 = 12. Bit 0 of the result (the parity of the new pair sum)
// is s0, which the caller uses as the fast palindrome-mismatch indicator.
BHD void step_g(u32 d[4], u32& G, const u32 y[4], u32 a, u32 P) {
  const u32 s0 = xor3(d[0], y[0], a), k1 = maj(d[0], y[0], a);
  const u32 s1 = xor3(d[1], y[1], k1), k2 = maj(d[1], y[1], k1);
  const u32 s2 = xor3(d[2], y[2], k2), k3 = maj(d[2], y[2], k2);
  const u32 s3 = xor3(d[3], y[3], k3), k4 = maj(d[3], y[3], k3);  // k4 = decimal carry
  const u32 g0 = lop3<0x9c>(s1, s2, k4);  // d'2
  const u32 g1 = lop3<0xc3>(s1, k4, g0);  // d'1 = s1 xnor k4
  const u32 g2 = lop3<0x10>(s3, g0, g1);  // d'3
  d[0] = s0; d[1] = g1; d[2] = g0; d[3] = g2;
  G = lop3<0x70>(k4, P, a);               // k4 & ~(P & a)
}

// Carry chains over a lane's 4 words. chain_lo: A[i] = word i of the 128-bit sum X + G + cin (cin at bit 0
// of word 0; one add-with-carry per word on the GPU). The carry into every bit is A ^ X ^ G = A ^ P.
BHD void chain_lo(const u32 X[4], const u32 G[4], u32 cin, u32 A[4]) {
  u32 s[4];
#ifdef __CUDA_ARCH__
  asm("{\n\t.reg .u32 t;\n\t"
      "add.cc.u32 t, %4, -1;\n\t"  // CC.CF = cin (cin + 0xffffffff carries iff cin == 1)
      "addc.cc.u32 %0, %5, %6;\n\t"
      "addc.cc.u32 %1, %7, %8;\n\t"
      "addc.cc.u32 %2, %9, %10;\n\t"
      "addc.u32 %3, %11, %12;\n\t}"
      : "=r"(s[0]), "=r"(s[1]), "=r"(s[2]), "=r"(s[3])
      : "r"(cin), "r"(X[0]), "r"(G[0]), "r"(X[1]), "r"(G[1]), "r"(X[2]), "r"(G[2]), "r"(X[3]), "r"(G[3]));
#else
  u64 t = (u64)X[0] + G[0] + cin; s[0] = (u32)t;
  t = (u64)X[1] + G[1] + (t >> 32); s[1] = (u32)t;
  t = (u64)X[2] + G[2] + (t >> 32); s[2] = (u32)t;
  t = (u64)X[3] + G[3] + (t >> 32); s[3] = (u32)t;
#endif
  for (int i = 0; i < 4; ++i) A[i] = s[i];  // raw sums: carries = A ^ P
}
// chain_hi: the same on bit-reversed words, from word 3 down to word 0 (carry-in cin at the top of word 3).
// Xr/Gr are brev(X)/brev(G); B[i] = brev(sum word i) in normal bit order, carries B ^ P.
BHD void chain_hi(const u32 Xr[4], const u32 Gr[4], u32 cin, u32 B[4]) {
  u32 s[4];
#ifdef __CUDA_ARCH__
  asm("{\n\t.reg .u32 t;\n\t"
      "add.cc.u32 t, %4, -1;\n\t"
      "addc.cc.u32 %3, %11, %12;\n\t"
      "addc.cc.u32 %2, %9, %10;\n\t"
      "addc.cc.u32 %1, %7, %8;\n\t"
      "addc.u32 %0, %5, %6;\n\t}"
      : "=r"(s[0]), "=r"(s[1]), "=r"(s[2]), "=r"(s[3])
      : "r"(cin), "r"(Xr[0]), "r"(Gr[0]), "r"(Xr[1]), "r"(Gr[1]), "r"(Xr[2]), "r"(Gr[2]), "r"(Xr[3]), "r"(Gr[3]));
#else
  u64 t = (u64)Xr[3] + Gr[3] + cin; s[3] = (u32)t;
  t = (u64)Xr[2] + Gr[2] + (t >> 32); s[2] = (u32)t;
  t = (u64)Xr[1] + Gr[1] + (t >> 32); s[1] = (u32)t;
  t = (u64)Xr[0] + Gr[0] + (t >> 32); s[0] = (u32)t;
#endif
  for (int i = 0; i < 4; ++i) B[i] = bits::brev32(s[i]);  // raw sums, normal bit order: carries = B ^ P
}
}  // namespace dg
