#!/usr/bin/env python3
"""v8 soundness stress for hybrid blocks: numbers with many planted runs of pair-sum 9 (long carry
chains that make hybrid windows lose certification), run through the CPU emulator with
EMU_CERTCHECK=1. Every certified block must equal the per-step result (violations = 0), some
hybrid blocks must fail (the test must exercise failures), and the output must equal big-int
arithmetic.  With a GPU build only the exactness against big integers is checked.
usage: python3 tests/stress_hybrid.py ENGINE [CASES] [SEED]   (extra engine options: ENGINE_FLAGS, e.g. "--halo=4")
v9: STRESS_LONG=1 plants runs of up to 400 pairs (longer than a warp window's 128-pair halo)."""
import os, random, re, subprocess, sys, tempfile
sys.set_int_max_str_digits(0)
emu = os.path.abspath(sys.argv[1]); FLAGS = os.environ.get('ENGINE_FLAGS', '').split(); LONG = os.environ.get('STRESS_LONG') == '1'; cases = int(sys.argv[2]) if len(sys.argv) > 2 else 40
random.seed(int(sys.argv[3]) if len(sys.argv) > 3 else 7); T = tempfile.mkdtemp()
bad = viol = hyb = hyf = 0
for c in range(cases):
    n = random.choice([20000, 40000, 80000])
    d = [random.randint(0, 9) for _ in range(n)]
    for _ in range(random.randint(5, 60)):            # planted 9-runs (lengths up to 120 pairs)
        a = random.randint(0, n // 2 - 1); L = random.choice([8, 16, 24, 33, 40, 64, 120] + ([160, 250, 400] if LONG else []))
        for j in range(a, min(a + L, n // 2)): d[n - 1 - j] = 9 - d[j]
    if d[0] == 0: d[0] = 1
    s = ''.join(map(str, d)); steps = random.randint(40, 400)
    K = random.choice([8, 16, 33, 64, 128]); tile = random.choice([4, 8, 32, 96])
    open(f'{T}/in.txt', 'w').write(s + '\n')
    env = dict(os.environ, EMU_CERTCHECK='1')
    r = subprocess.run([emu, f'{T}/in.txt', str(steps), f'{T}/out.txt', '0', str(K), f'--tile={tile}'] + FLAGS,
                       capture_output=True, text=True, env=env)
    x = int(s)
    for _ in range(steps): x = x + int(str(x)[::-1])
    got = re.sub(r'[^0-9]', '', open(f'{T}/out.txt').read()) if r.returncode == 0 else ''
    ok = got == str(x)
    emu_run = 'cpu-emulator' in r.stderr  # GPU builds print no certcheck/block statistics
    mv = re.search(r'violations=(\d+)', r.stderr); v = int(mv.group(1)) if mv else 0
    mh = re.search(r'hybrid blocks=(\d+) \(failed (\d+)\)', r.stderr)
    if mh: hyb += int(mh.group(1)); hyf += int(mh.group(2))
    viol += v
    if not ok or v != 0 or (emu_run and not mv):
        bad += 1; print(f'case {c}: n={n} steps={steps} K={K} tile={tile} exact={ok} violations={v}\n{r.stderr[-400:]}')
print(f'hybrid stress: {cases - bad}/{cases} exact and sound | hybrid blocks {hyb}, failed (replayed) {hyf}, '
      f'certcheck violations {viol}')
sys.exit(1 if bad or (hyb > 0 and hyf == 0) else 0)  # emulator runs must exercise hybrid failures
