#!/usr/bin/env python3
"""v8/v9 palindrome-vote placement test. Numbers whose pair sums are 0 except a few disturbances: far
from a disturbance a block sees no mismatch until the carries reach it, so its per-step mismatch
bits change inside hybrid windows. Run with a TB_CHECK_HYBRID emulator build, which recomputes
every certified hybrid block with the v6r3 path and aborts if any per-step bit or owned word
differs. Also checks the output against big-int arithmetic.
usage: python3 tests/quiet_bits.py CHECK_EMULATOR [CASES]"""
import os, random, re, subprocess, sys, tempfile
sys.set_int_max_str_digits(0)
emu = os.path.abspath(sys.argv[1]); cases = int(sys.argv[2]) if len(sys.argv) > 2 else 12
random.seed(17); T = tempfile.mkdtemp(); bad = 0; chk = quiet = 0
for c in range(cases):
    n = random.choice([30000, 50001]); h = (n + 1) // 2
    S = [0] * h
    for _ in range(random.randint(1, 8)): S[random.randint(0, h - 2)] = random.randint(1, 18)
    S[0] = max(S[0], 2)
    if n % 2: S[h - 1] = 2 * random.randint(0, 4)
    d = [0] * n
    for j, s in enumerate(S):
        a = random.randint(max(0, s - 9), min(9, s))
        if j == n - 1 - j: a = s // 2
        d[j] = a; d[n - 1 - j] = s - a
    if d[0] == 0: d[0], d[n - 1] = d[n - 1], d[0]
    s = ''.join(map(str, d)); steps = random.randint(100, 500)
    K = random.choice([16, 64, 128]); tile = random.choice([4, 8, 32])
    open(f'{T}/in.txt', 'w').write(s + '\n')
    r = subprocess.run([emu, f'{T}/in.txt', str(steps), f'{T}/out.txt', '0', str(K), f'--tile={tile}'], capture_output=True, text=True)
    x = int(s); pal = None
    for t in range(1, steps + 1):
        x = x + int(str(x)[::-1])
        if pal is None and str(x) == str(x)[::-1]: pal = t; break
    m = re.search(r'blocks cross-checked against the v6r3 path=(\d+) \(block-steps with no mismatch: (\d+)\)', r.stderr)
    if m: chk += int(m.group(1)); quiet += int(m.group(2))
    if pal is not None:
        mm = re.search(r'PALINDROME at iteration (\d+)', r.stderr)
        ok = mm is not None and int(mm.group(1)) == pal
    else:
        ok = r.returncode == 0 and re.sub(r'[^0-9]', '', open(f'{T}/out.txt').read()) == str(x)
    if not ok or 'v9 check' in r.stderr:
        bad += 1; print(f'case {c}: FAIL n={n} K={K} tile={tile} pal={pal}\n{r.stderr[-500:]}')
print(f'quiet-bit cases: {cases - bad}/{cases} exact | hybrid blocks cross-checked {chk}, block-steps without mismatch {quiet}')
sys.exit(1 if bad or (chk > 0 and quiet == 0) else 0)  # GPU builds: exactness only
