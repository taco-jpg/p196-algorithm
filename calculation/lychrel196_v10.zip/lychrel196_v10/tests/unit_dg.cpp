// unit_dg.cpp - exhaustive check of the v10 decimal pair-sum arithmetic (dg_arith.h) against plain integers.
// build: g++ -O2 -std=c++17 -I. tests/unit_dg.cpp -o bench/unit_dg
#include <algorithm>
#include <cstdio>
#include <cstdlib>
#include <random>
#include <vector>
#include "dg_arith.h"
using dg::u32;
static int fails = 0;
#define CHECK(c, ...) do { if (!(c)) { if (fails++ < 20) { printf("FAIL: " __VA_ARGS__); printf("\n"); } } } while (0)

// pack per-lane small integers into bit planes
static void pack(const int* v, int nb, u32* planes) {
  for (int q = 0; q < nb; ++q) {
    planes[q] = 0;
    for (int l = 0; l < 32; ++l) planes[q] |= (u32)((v[l] >> q) & 1) << l;
  }
}
static int lane(const u32* planes, int nb, int l) {
  int v = 0;
  for (int q = 0; q < nb; ++q) v |= (int)((planes[q] >> l) & 1u) << q;
  return v;
}

int main() {
  std::mt19937 rng(10);
  long long cases = 0;
  // conversions
  for (int rep = 0; rep < 2000; ++rep) {
    int S[32]; for (int l = 0; l < 32; ++l) S[l] = rng() % 19;
    u32 s[5], d[4], G, s2[5]; pack(S, 5, s);
    dg::from_bin(s, d, G);
    dg::to_bin(d, G, s2);
    for (int l = 0; l < 32; ++l) {
      const int D = lane(d, 4, l), g = (G >> l) & 1;
      CHECK(D == S[l] % 10 && g == (S[l] >= 10), "from_bin S=%d -> D=%d G=%d", S[l], D, g);
      CHECK(lane(s2, 5, l) == S[l], "to_bin S=%d", S[l]);
      ++cases;
    }
  }
  // all (D, a, b) and (D, y, a) combinations, 32 per word
  std::vector<int> combos;
  for (int D = 0; D < 10; ++D) for (int a = 0; a < 2; ++a) for (int b = 0; b < 2; ++b) for (int y = 0; y < 10; ++y)
    combos.push_back(D | a << 4 | b << 5 | y << 6);
  for (int rep = 0; rep < 50; ++rep) {
    std::shuffle(combos.begin(), combos.end(), rng);
    for (size_t base = 0; base < combos.size(); base += 32) {
      int D[32], A[32], B[32], Y[32];
      for (int l = 0; l < 32; ++l) {
        const int c = combos[(base + l) % combos.size()];
        D[l] = c & 15; A[l] = (c >> 4) & 1; B[l] = (c >> 5) & 1; Y[l] = c >> 6;
      }
      u32 d[4], a, b, y[4]; pack(D, 4, d); pack(A, 1, &a); pack(B, 1, &b); pack(Y, 4, y);
      const u32 Gin = rng();  // old G must not matter
      const u32 P = dg::Pof(d);
      // no growth (inputs are the raw chain sums al = a ^ P, be = b ^ P)
      {
        u32 e[4] = {d[0], d[1], d[2], d[3]}, G = Gin;
        const u32 m = dg::step_ng(e, G, a ^ P, b ^ P, P);
        for (int l = 0; l < 32; ++l) {
          const int c = A[l] + B[l], P = D[l] == 9, Sp = 2 * D[l] + c - 10 * P * c;
          CHECK(lane(e, 4, l) == Sp % 10 && (int)((G >> l) & 1) == (Sp >= 10), "step_ng D=%d a=%d b=%d", D[l], A[l], B[l]);
          CHECK((int)((m >> l) & 1) == (A[l] ^ B[l]), "step_ng mismatch bits");
          ++cases;
        }
      }
      // (D + c) mod 10 + 6
      {
        u32 o[4]; dg::inc10x6(d, a ^ P, P, o);
        for (int l = 0; l < 32; ++l) { CHECK(lane(o, 4, l) == (D[l] + A[l]) % 10 + 6, "inc10x6 D=%d c=%d", D[l], A[l]); ++cases; }
      }
      // growth: D' / G' of lo_j + y with lo_j = (D + a) mod 10, y given in excess 6
      {
        int Y6[32]; for (int l = 0; l < 32; ++l) Y6[l] = Y[l] + 6;
        u32 y6[4]; pack(Y6, 4, y6);
        u32 e[4] = {d[0], d[1], d[2], d[3]}, G = Gin;
        dg::step_g(e, G, y6, a, P);
        for (int l = 0; l < 32; ++l) {
          const int Sp = (D[l] + A[l]) % 10 + Y[l];
          CHECK(lane(e, 4, l) == Sp % 10 && (int)((G >> l) & 1) == (Sp >= 10), "step_g D=%d a=%d y=%d", D[l], A[l], Y[l]);
          ++cases;
        }
      }
    }
  }
  // carry chains vs sequential carries (random words with many 9s and random cin)
  for (int rep = 0; rep < 20000; ++rep) {
    u32 X[4], G[4], Xr[4], Gr[4], A[4], B[4];
    const int mode = rep % 4;
    for (int i = 0; i < 4; ++i) {
      u32 g = rng(), p = rng();
      if (mode == 1) p |= rng();               // more propagates
      if (mode == 2) { p = ~0u; g = 0; }       // all propagate
      if (mode == 3 && i == 2) { p = ~0u; g = 0; }
      G[i] = g & ~p; X[i] = G[i] | p;
      Xr[i] = bits::brev32(X[i]); Gr[i] = bits::brev32(G[i]);
    }
    const u32 cl = rng() & 1, ch = rng() & 1;
    dg::chain_lo(X, G, cl, A);
    dg::chain_hi(Xr, Gr, ch, B);
    for (int i = 0; i < 4; ++i) { A[i] ^= X[i] ^ G[i]; B[i] ^= X[i] ^ G[i]; }  // raw sums -> carries
    int c = cl;  // a_j: carry into pair j from below
    for (int j = 0; j < 128; ++j) {
      CHECK((int)((A[j >> 5] >> (j & 31)) & 1) == c, "chain_lo bit %d", j);
      const int gj = (G[j >> 5] >> (j & 31)) & 1, xj = (X[j >> 5] >> (j & 31)) & 1;
      c = gj | (xj & !gj & c);
    }
    c = ch;  // b_j: carry into pair j from above
    for (int j = 127; j >= 0; --j) {
      CHECK((int)((B[j >> 5] >> (j & 31)) & 1) == c, "chain_hi bit %d", j);
      const int gj = (G[j >> 5] >> (j & 31)) & 1, xj = (X[j >> 5] >> (j & 31)) & 1;
      c = gj | (xj & !gj & c);
    }
    cases += 256;
  }
  printf("unit_dg: %lld checks, %s\n", cases, fails ? "FAIL" : "ALL PASS");
  return fails ? 1 : 0;
}
