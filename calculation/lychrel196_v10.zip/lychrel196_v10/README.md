# 196 reverse-and-add v10: decimal pair sums inside the warp windows

```bash
nvcc -O3 -std=c++17 -arch=sm_89 cuda196_v10.cu -o cuda196_v10          # default: 512 threads, J=64, pipe balancing
./cuda196_v10 run <checkpoint> <iteration> search --chunk=1000000 --keep=3 --K=128 --tile=1900
nvcc ... -DTB_THREADS=256 ...   # 2 blocks per SM, --tile up to 940 (K=128)
```

Same arithmetic results, certification rule, replay, command line, checkpoint format and `latest.json`
fields as v9 (engine field `cuda196_v10`). Results are byte-identical. Everything in v9 (64-bit digit
counts, ISF, mod-9 fingerprint and tools, weekly cross-check) is unchanged and included.

## What changes

**1. Decimal pair sums in the window registers (the main change).** A step of v9 computed, for every
pair, `S' = 2S + a + b - 10(a_up + b_dn)` on 5 binary planes: it needed the carry *into* each pair (a, b)
and the carry *out* of it (two shifted words), then a 5-plane add and subtract. v10 keeps every pair sum
inside a window as `S = D + 10G` (D = S mod 10 as 4 BCD planes, G = S >= 10). G and P = (D == 9) are
then exactly the carry generate / propagate planes, and the new pair sum depends only on the carries
into the pair:

- no growth: `S'_j = lo_j + hi_j = 2D_j + c - 10 P_j c` with `c = a_j + b_j`, so
  `D' = (2D + c) mod 10` (bit 0 = a xor b, bits 1..3 = (D + (a and b)) mod 5) and
  `G' = (D + (a and b) >= 5) and not (P and (a or b))`;
- growth: `S'_j = lo_j + hi_{j-1}` is a BCD add `D_j + a_j + hi_{j-1}` with the carry-out cleared where
  `P_j and a_j`. The high digit is produced as `hi + 6` (excess 6), so the binary carry out of bit 3 *is*
  the decimal carry and the correction is 3 gates.

The gate lists were found by searching over 3-input LOP3 gates (an exact SAT search for single outputs,
a Cartesian-genetic-programming search for the multi-output functions) and are checked exhaustively
(`tests/unit_dg.cpp`, 5.2 million cases). Per 32-pair word: no-growth update 10 gates (v9 about 29),
growth 5 + 12 + 1. Conversion between the binary planes and (D, G) happens only at window load/store,
so tiles, checkpoints and all other kernels are untouched.

**2. Carry chains.** One add-with-carry per word (PTX `add.cc`/`addc.cc`), and the raw sums go straight
into the gates (the carries are `sum xor P`; the circuits absorb that xor).

**3. Tracking.** Same rule as v9 (track_step), with warp-uniform edges, but when neither edge pair is a 9
(about 80% of steps) the edges just move by one. v9's per-step emptiness checks are dropped: L never
decreases and R never increases, so an interval that empties stays empty and the verdict at the window
end is the same. (Test builds run v9's tracker alongside and abort on any difference: 0 differences.)

**4. Palindrome bits.** An odd new pair sum is always a mismatch, so owned lanes start with "mismatch" in
every step and only a lane whose word 0 has no odd new pair sum runs the exact test (practically never
on real data; the quiet-region tests exercise it).

**5. Lane-edge carries.** The carries entering lane 0 from below and lane 31 from above (and lane 0's
`hi` of the pair below) are no longer zeroed: they only reach pairs that leave the certified interval
after that step, as in v9's argument. The rare exact carry scan is unchanged.

**6. Windows of 64 steps** (`TB_J`, default 64): half the window loads/stores and barriers of v9. The
128-pair halo absorbs the ~71 pairs a window edge moves in 64 steps.

**7. Launch order.** The two tiles at the middle of the number and tile 0 run the per-step v6r3 path,
which is much slower than a warp-window block. They are now scheduled first, so they overlap the other
blocks instead of forming the tail of every launch.

**8. Pipe balancing** (`TB_PIPEBAL`, default 1 in v10): the growth step's 16 one-pair shifts per lane run as
`mul.hi` + `mad.lo` on the FMA pipe; the tracker's two adds and two shifts are on the FMA pipe always.

## Instruction counts (nvcc 13.4 for sm_89, static counts of the step loop, not measured)

Per lane-step (one lane, 4 words). Analysis builds with the rare paths compiled out; v9 measured the
same way. "fast/slow" = tracker fast path (both edge pairs non-9) or full search.

| | v9 (production build) | v10 (default, `TB_PIPEBAL=1`) | v10 `TB_PIPEBAL=0` |
|---|---:|---:|---:|
| no-growth step, ALU-pipe instructions | 191 | 81 fast / 92 slow | 81 / 92 |
| growth step, ALU-pipe instructions | 262 | 113 fast / 122 slow | 129 / 138 |
| no-growth step, all instructions | 238 | 107 / 115 | 107 / 115 |
| growth step, all instructions | 309 | 171 / 178 | 155 / 162 |
| FMA-pipe (IMAD) instructions, no growth / growth | 27 / 24 | 19 / 47 | 19 / 15 |

Weighted by the real mix (41% growth steps, ~81% tracker fast path): **v9 about 220 ALU-pipe
instructions per lane-step, v10 about 96 (plus 2-3 for the checks compiled out above): 2.2-2.3x fewer.**
All instructions (issue slots): v9 about 267, v10 about 135, 2.0x fewer.
Registers: 124 (512 and 256 threads), no stack, no local memory in the step loop.

Not in the ALU column: 12-13 `BREV` (bit reverse, for the carry chain that runs downwards) and 0-2 `FLO`
per lane-step, in **both** engines (v9: 13 + 2, v10: 12 + 0-2). NVIDIA does not document which pipe BREV
uses on sm_89 or its rate. If it is a quarter-rate instruction on the ALU pipe, the effective ALU work is
about 280 (v9) vs about 145 (v10), i.e. **about 1.9x instead of 2.2x**. The GPU A/B settles it.

## Checked here (CPU emulator running the GPU's lane code; nvcc 13.4 for sm_89)

- `tests/unit_dg.cpp`: all arithmetic exhaustively (conversions, no-growth update, excess-6 high digit,
  growth add, both carry chains with random and all-9 words): 5,246,400 checks, all pass.
- Emulator gate (`./gate_emu.sh full`), five check builds (512 threads J=64 = the default, 256 threads
  J=64, 512 threads J=32, 288 threads J=12 with `TB_PIPEBAL=0`, J=1; output in `bench/gate_emu.txt`):
  every certified hybrid block recomputed through the v6r3 path (per-step mismatch bits and owned words
  identical), v9's tracker run alongside v10's (identical in every compared step), quiet-region inputs
  (6,956 blocks, 118,766 quiet block-steps), stress with planted 9-runs, halo 4 and 400-pair runs:
  certcheck violations 0 and exactly the same certified / failed block counts as v9 (1, 808, 75);
  exactness suite in 12 configurations (9 at 512 threads, 3 at 256), growth edge cases 93/93, later palindromes, fault injection
  (mod-9 fingerprint catches the flip, output == reference), differential v9 vs v10 120/120 identical,
  the 2M-digit checkpoint +2000 steps in every A/B configuration (512 threads tile 1900 K=128 and 1892
  K=256, 256 threads tile 940 K=128, 932 K=256 and 900, and the 512-thread check build) == the
  schoolbook reference.
- All GPU builds compile with nvcc 13.4 (`bench_v10.sh build` set): 124 registers, no stack, no
  local-memory instructions in the warp-window loop.
- **Not run here**: nothing on a GPU. The inline PTX (lop3, the add.cc chains, mul.hi/mad.lo) ran only
  through its C++ twins in the emulator; the GPU gate runs the real thing, including the new launch order.

## Expected speed (honest)

v9 was ALU-bound (86% ALU-pipe busy). With 2.2-2.3x fewer ALU instructions per step (about 1.9x if
BREV turns out to be quarter-rate on the ALU pipe), the upper bound is about 1.9-2.2x. Other costs do
not shrink: global loads/stores of each tile (with one 512-thread block per SM they do not overlap
computation; roughly 5-10% of a v10 launch), the tape kernel before every launch, shuffle latency, and
the 35 W cap. My guess: **1.4-1.9x faster than v9 at the same tile**, most likely around 1.6x. Which of
512 threads x 1 block or 256 threads x 2 blocks (memory overlap) wins, and whether K=256 (half the
memory traffic per step) helps, is for the A/B to decide; `TB_PIPEBAL=0` is in the A/B too (v9's pipe
balancing did not pay off on the GPU).

## Files

| file | purpose |
|---|---|
| `cuda196_v10.cu`, `emu196_v10.cpp` | CUDA backend / CPU emulator (same kernel code) |
| `dg_arith.h` | v10 decimal arithmetic: conversions, gate lists, carry chains |
| `bits_tb10.h` | engine: v9 warp windows with the v10 step, tracker, 64-step windows |
| `warp_ops.h`, `bits_core.h`, `driver10.h`, `prof.h`, `sha256.h` | as in v9 |
| `bench_v10.sh` | `build`, `resources`, `gate`, `big64`, `ab`, `sustained`, `runmode` |
| `gate_emu.sh` | the CPU-emulator gate (called by `bench_v10.sh gate`) |
| `tools/` | schoolbook reference, ISF writer, mod-9 identity, weekly cross-check, SASS loop check |
| `tests/` | exactness, differential, hybrid stress, quiet regions, palindromes in windows, growth edges, `unit_dg.cpp` |
| `synth/` | the gate-search tools (SAT exact synthesis, CGP) and problem files, to reproduce the gate lists |
| `baseline_v9/` | the production engine (v9) for the A/B |
