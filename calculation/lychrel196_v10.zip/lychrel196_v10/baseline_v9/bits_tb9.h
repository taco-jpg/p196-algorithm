// bits_tb9.h - v9 = v8b with warp windows: the lanes of a warp share one register window and pass
// the carries that cross lane boundaries by warp shuffles, instead of every thread recomputing a
// halo word on each side (v8: 6 words computed per 4 kept; v9: 32 groups per 30 kept). Options:
// TB_J (default 32 now: the halo is 128 pairs), TB_QUINARY (base-5 window arithmetic, from v8b),
// TB_PIPEBAL (adds and shifts as multiply-adds on the FMA pipe). Results are identical to v8b.
//
// bits_tb8b.h - v8b = v8 + 64-bit digit counts + slimmer block state + any window length + optional
// base-5 window arithmetic. Results are identical to v8/v6r3.
//  * Digit counts n are 64-bit (bits::dlen) everywhere: host, device, the v4 kernel. Pair indices
//    stay 32-bit (h = ceil(n/2) < 2^31), so the limit moves from ~2.147e9 to ~4.29e9 digits.
//  * State.gS[KMAX+1] (4 KB) -> a 2-entry ring + a growth bitmask: room for wider tiles.
//  * TB_J may be any 1..32 (windows can straddle 32-bit words of the tape and the vote mask).
//  * TB_QUINARY=1: inside hybrid windows pair sums are kept as S = M + 5H + 10G (G = carry
//    generate is a plane, P = H & M2, the digit is M + 5H + c - 10Pc): fewer logic operations per
//    no-growth step. Converted at window load/store; tiles and checkpoints stay binary.
//
// bits_tb8.h - time-blocked exact bit-plane engine, v8 = v6r3 + "hybrid" interior blocks.
// v8 (idea from an outside review, implemented and verified here): interior blocks stop
// synchronising every step.
//  * Control tape: a tiny kernel runs the prefix tile alone for the K steps of the launch and
//    writes the growth bits g_0..g_{K-1} (certified by the prefix tracker, exactly as before).
//  * Hybrid blocks (not block 0, not near the middle): each thread owns one 4-word group, loads it
//    plus one halo word on each side (6 words) into registers, and runs TB_J steps alone using the
//    tape's growth bits. Every thread certifies its own window with the same interval rule as
//    track_step (window-local, so sound for any values outside the window). After TB_J steps it
//    writes its 4 words and its certified span; one barrier; next window. Barriers per launch:
//    K/TB_J instead of K. Cost: the halo words are recomputed (6 words computed per 4 kept).
//  * A hybrid block fails (window replays exactly, as before) if any owned group is not certified
//    at a window end, or the tape is not certified. Block 0 and the blocks near the middle run the
//    unchanged v6r3 path. Palindrome votes: per step, owned groups only, as before.
//
// bits_tb6r3.h - time-blocked exact bit-plane engine, v6r3.
// v6r3 vs v6r2 (same arithmetic and certification; results identical), from the Nsight Compute
// profile of v6r2 (barrier = #1 stall; warp 0 slowest; short-scoreboard stalls right after the
// barrier on shared-memory reads of the step's growth bit and tile geometry):
//  * per-launch WorkCtx in registers: tile geometry and the thread's item mapping are read from
//    shared memory once per launch instead of every step (they are constant during a launch);
//  * the growth bit g_{t+1} travels through the step barrier itself (__syncthreads_count with
//    only thread 0 voting), so no thread reads it back from shared memory after the barrier;
//  * the per-step palindrome vote leaves the barrier: each warp ORs its lanes (__any_sync) into a
//    register bitmask, flushed to shared memory every 32 steps; quiet[] is updated once per launch;
//  * thread 0 checks new word 0 first for the growth bit (words 1..3 only if word 0 is all 9s);
//  * ph_load copies plane by plane without an integer division per element.
//
// bits_tb6r2.h - time-blocked exact bit-plane engine, v6r2.
// v6r2 vs v6r (same arithmetic; certified results identical), from the v6r GPU profile (warp 0
// 3024 cycles/step vs 2115 for the other workers):
//  * the fast path is inlined once: v6r had two call sites (mismatch counted / not counted), so a
//    warp holding both kinds of group (warp 0: prefix + left halo + owned; the last warp: owned +
//    right halo) executed both copies one after the other;
//  * thread 0 takes g_{t+1} from the new words 0..3 still in its registers (returned packed with
//    the mismatch bit) instead of reloading them from shared memory; the shared-memory search
//    remains as the fallback when word 0 went through the general path.
//
// v6r: time-blocked exact bit-plane engine (v6 lean kernel, rebalanced warps).
// v6r vs v6s (same arithmetic; certified results identical), from the measured phase profile:
//  * word 0 now takes the fast path too (v6 sent prefix group 0 down the out-of-line general
//    path every step, so warp 0 executed both code paths one after the other);
//  * certification tracking runs in warp 1 (threads 32/33) instead of warp 0, which also does
//    the prefix tile and the growth bit;
//  * tile groups and prefix groups are one work list over the 'worker' threads (all except
//    warp 1), so each worker does one group per step through a single call site;
//  * the growth bit's certification check moves to the prefix tracker at the next step (same
//    condition, evaluated on the same interval), removing a cross-warp dependency.
// Shared verbatim by the CUDA kernel (cuda196_v6.cu) and the CPU emulator (emu196_v6.cpp).
// v6 vs v5 (same arithmetic, bit-identical results):
//  * every tile plane is surrounded by zeroed guard words, so the 6 words a thread-group reads
//    need no range checks (vldu); range-checked loads remain only in the rare carry scans;
//  * interior groups (not near the middle, not word 0, mismatch range all-or-nothing) take a
//    branch-free fast path with 128-bit shared-memory loads/stores and no masks;
//  * growth steps get the previous pair's high digit by a bitwise digit4 + funnel shift instead
//    of per-word scalar code.
//
// Same math as bits_core.h (v4, GPU-validated), reorganised for a block that keeps a tile of
// bit-planes in shared memory and runs K steps before writing back:
//  * step_group(): 4 consecutive words per thread; low/high carry chains flow word-to-word
//    inside the thread, so only one neighbour scan per direction per 4 words.
//  * Locality: pair j of the next state depends on pairs j-1..j+1 plus runs of pair-sum 9.
//    Each tile tracks its exactly-certified interval [L,R) (track_step). If after K steps it
//    no longer covers the pairs the block owns, the block raises `fail` and the host redoes the
//    window with the per-step v4 kernel. No approximation anywhere.
//  * Growth g_t depends only on the outermost pairs: every block also simulates a small prefix
//    tile [0, PW words) and derives g_{t+1} from it, so blocks never wait for each other.
#pragma once
#include "bits_core.h"
#if defined(TB_COUNT_PATHS) && !defined(__CUDA_ARCH__)
#include <atomic>
#endif

#if defined(__CUDA_ARCH__)
#define TB_UNROLL _Pragma("unroll")
#else
#define TB_UNROLL
#endif

namespace tb {
using bits::u32;
using bits::u64;
using bits::dlen;

static const int KMAX = 1024;
#ifndef TB_THREADS
#define TB_THREADS 256
#endif
static const int THREADS = TB_THREADS;  // threads per block (CUDA launch and emulator agree)
static_assert(TB_THREADS >= 96 && TB_THREADS % 32 == 0, "v6r needs warp 1 for tracking plus workers");
static const int GUARD = 4;             // zeroed guard words on each side of every plane
static const int WY_CORE = 30;          // v9: core lanes per warp (lanes 1..30; lanes 0 and 31 are halo)

struct View { const u32* s; int stride; int base; int len; };  // word k at s[q*stride + k-base]

BHD void vld(const View& v, int k, u32 p[5]) {
  int x = k - v.base;
  if (k < 0 || x < 0 || x >= v.len) { p[0] = p[1] = p[2] = p[3] = p[4] = 0; return; }
  TB_UNROLL
  for (int q = 0; q < 5; ++q) p[q] = v.s[q * v.stride + x];
}
// unchecked load: valid for word offsets in [-GUARD, len+GUARD) thanks to the zeroed guards
BHD void vldu(const View& v, int k, u32 p[5]) {
  const int x = k - v.base;
  TB_UNROLL
  for (int q = 0; q < 5; ++q) p[q] = v.s[q * v.stride + x];
}
BHD int is9(const View& v, int j) { u32 p[5]; vld(v, j >> 5, p); return (int)((bits::Pof(p) >> (j & 31)) & 1u); }
BHD int ge10(const View& v, int j) { u32 p[5]; vld(v, j >> 5, p); return (int)((bits::Gof(p) >> (j & 31)) & 1u); }

BHD u32 vlow_cin(const View& v, int k, const u32 prev[5]) {  // a_{32k}
  int j = k - 1;
  if (j < 0) return 0;
  int r = bits::low_summary(prev);
  while (r == 2) {
    if (--j < 0) return 0;
    u32 p[5]; vld(v, j, p);
    r = bits::low_summary(p);
  }
  return (u32)r;
}
BHD u32 vlow_bit(const View& v, int j) {  // a_j
  int k = j >> 5;
  u32 p[5], q[5];
  vld(v, k, p); vld(v, k - 1, q);
  u32 c = vlow_cin(v, k, q);
  u32 G = bits::Gof(p), X = G | bits::Pof(p);
  u64 t = (u64)X + G + c;
  return (((u32)t ^ X ^ G) >> (j & 31)) & 1u;
}
BHD u32 vmid_cin(const View& v, dlen n) { int h = (int)((n + 1) / 2); return vlow_bit(v, (n % 2 == 0) ? h : h - 1); }
BHD u32 vhigh_cin(const View& v, dlen n, int k, const u32 next[5]) {  // b_{32k+31}
  int h = (int)((n + 1) / 2), j = k + 1;
  if (32LL * j >= h) return vmid_cin(v, n);
  int r = bits::high_summary(next, j, h);
  while (r == 2) {
    ++j;
    if (32LL * j >= h) return vmid_cin(v, n);
    u32 p[5]; vld(v, j, p);
    r = bits::high_summary(p, j, h);
  }
  return (u32)r;
}

#ifdef __CUDA_ARCH__
#define TB_RARE __device__ __noinline__
#else
#define TB_RARE static inline
#endif
// rare continuations (a whole neighbour word of pair-sum 9s, or the middle): out of line on the GPU
// v6s: View by value and the neighbour word as five scalars, so no caller array or struct has its
// address taken (in v6 this forced a 144-168 byte local-memory stack frame into the hot path).
TB_RARE u32 rare_low_cin(View v, int k, u32 q0, u32 q1, u32 q2, u32 q3, u32 q4) {
  const u32 prev[5] = {q0, q1, q2, q3, q4};
  return vlow_cin(v, k, prev);
}
TB_RARE u32 rare_high_cin(View v, dlen n, int k, u32 q0, u32 q1, u32 q2, u32 q3, u32 q4) {
  const u32 next[5] = {q0, q1, q2, q3, q4};
  return vhigh_cin(v, n, k, next);
}
BHD int ctz32(u32 x) {
#ifdef __CUDA_ARCH__
  return __ffs(x) - 1;
#else
  return __builtin_ctz(x);
#endif
}
BHD u32 rangemask(int w, int lo, int hi) { return hi <= lo ? 0u : (bits::hmask(w, hi) & ~bits::hmask(w, lo)); }

// Words w0..w0+3 of the next state (same layout as v). Returns 1 on a palindrome mismatch
// among pairs in [mlo, mhi).
#ifdef __CUDA_ARCH__
// rare path: kept out of line so it does not raise register pressure in the fast path
__device__ __noinline__ u32 step_group_slow(View v, u32* __restrict__ d, dlen n, int g, int w0, int mlo, int mhi) 
#else
static inline u32 step_group_slow(View v, u32* __restrict__ d, dlen n, int g, int w0, int mlo, int mhi) 
#endif
{
  const int C = 4;
  const int h = (int)((n + 1) / 2);
  u32 p[C + 2][5];
  TB_UNROLL
  for (int i = 0; i < C + 2; ++i) vldu(v, w0 - 1 + i, p[i]);
  u32 A[C], aO[C], B[C], bO[C];
  u32 cl = vlow_cin(v, w0, p[0]);
  TB_UNROLL
  for (int i = 0; i < C; ++i) {
    u32 G = bits::Gof(p[i + 1]), X = G | bits::Pof(p[i + 1]);
    u64 t = (u64)X + G + cl;
    A[i] = (u32)t ^ X ^ G; aO[i] = (u32)(t >> 32); cl = aO[i];
  }
  u32 ch = vhigh_cin(v, n, w0 + C - 1, p[C + 1]);
  TB_UNROLL
  for (int i = C - 1; i >= 0; --i) {
    const int w = w0 + i;
    u32 m = bits::hmask(w, h);
    u32 G = bits::Gof(p[i + 1]), X = G | bits::Pof(p[i + 1]);
    u32 Xr = bits::brev32(X | ~m), Gr = bits::brev32(G & m);
    u64 t = (u64)Xr + Gr + ch;
    B[i] = bits::brev32((u32)t ^ Xr ^ Gr); bO[i] = (u32)(t >> 32); ch = bO[i];
  }
  u32 mism = 0;
  TB_UNROLL
  for (int i = 0; i < C; ++i) {
    const int w = w0 + i;
    const u32* cw = p[i + 1];
    const u32 m = bits::hmask(w, h);
    const u32 a = A[i] & m, b = B[i] & m;
    const u32 aup = ((A[i] >> 1) | (aO[i] << 31)) & m;  // a_{j+1}
    const u32 bdn = ((b << 1) | bO[i]) & m;             // b_{j-1}
    u32 out[5];
    if (!g) {
      u32 t0 = a ^ b, t1 = a & b;
      u32 v0 = t0;
      u32 v1 = cw[0] ^ t1, cc = cw[0] & t1;
      u32 v2 = cw[1] ^ cc; cc &= cw[1];
      u32 v3 = cw[2] ^ cc; cc &= cw[2];
      u32 v4 = cw[3] ^ cc;
      u32 k1 = aup ^ bdn, k2 = aup & bdn;
      u32 r1 = v1 ^ k1, bo = ~v1 & k1;
      u32 dd = v2 ^ k2; u32 r2 = dd ^ bo; bo = (~v2 & k2) | (~dd & bo);
      dd = v3 ^ k1;     u32 r3 = dd ^ bo; bo = (~v3 & k1) | (~dd & bo);
      dd = v4 ^ k2;     u32 r4 = dd ^ bo;
      out[0] = v0 & m; out[1] = r1 & m; out[2] = r2 & m; out[3] = r3 & m; out[4] = r4 & m;
      mism |= ((a ^ b) & rangemask(w, mlo, mhi < h ? mhi : h)) != 0;
    } else {
      const int h1 = (int)((n + 2) / 2);
      const u32 m1 = bits::hmask(w, h1);
      u32 lo[4], hi[4], hp[4], hs[4];
      bits::digit4(cw, a, aup, lo);
      bits::digit4(cw, b, bdn, hi);
      if (w == 0) { hp[0] = 1; hp[1] = hp[2] = hp[3] = 0; }
      else {  // high digit of pair 32w-1: S + b_{32w-1} - 10 b_{32w-2}
        int s = 0;
        TB_UNROLL
        for (int q = 0; q < 5; ++q) s |= (int)((p[i][q] >> 31) & 1u) << q;
        int bj = (int)bO[i], bj1 = (s >= 10) | ((s == 9) & bj);
        int hv = s + bj - 10 * bj1;
        if (hv < 0) hv = 0;  // only for pairs >= h (masked)
        TB_UNROLL
        for (int q = 0; q < 4; ++q) hp[q] = (u32)(hv >> q) & 1u;
      }
      TB_UNROLL
      for (int q = 0; q < 4; ++q) hs[q] = (hi[q] << 1) | hp[q];
      if (!(n & 1)) {
        int hb = h - 32 * w;
        if (hb >= 0 && hb < 32) {
          u32 bm = 1u << hb;
          TB_UNROLL
          for (int q = 0; q < 4; ++q) lo[q] = (lo[q] & ~bm) | (hs[q] & bm);
        }
      }
      const u32 rm = rangemask(w, mlo, mhi < h1 ? mhi : h1);
      u32 diff = 0, cc = 0;
      TB_UNROLL
      for (int q = 0; q < 4; ++q) {
        diff |= (lo[q] ^ hs[q]) & rm;
        u32 x = lo[q], y = hs[q];
        out[q] = (x ^ y ^ cc) & m1;
        cc = (x & y) | (cc & (x ^ y));
      }
      out[4] = cc & m1;
      mism |= diff != 0;
    }
    const int x = w - v.base;
    if (x >= 0 && x < v.len)
      TB_UNROLL
      for (int q = 0; q < 5; ++q) d[q * v.stride + x] = out[q];
  }
  return mism;
}

// Fast path. Preconditions (checked by the caller): w0 >= 0 (word -1 is a zeroed guard), the 4 words and the right
// neighbour word lie entirely below n-h (no masks, no middle, no centre/growMid pair), and the
// mismatch range covers all 128 pairs (countM) or none of them. Results are identical to
// step_group_slow under these conditions.
BHD u32 step_group_fast(const View& v, u32* __restrict__ d, dlen n, int g, int w0, bool countM) {
  const int C = 4;
  const int x0 = w0 - v.base;  // multiple of 4
  u32 p[C + 2][5];
  TB_UNROLL
  for (int q = 0; q < 5; ++q) {
    const u32* row = v.s + q * v.stride;
#ifdef __CUDA_ARCH__
    const uint4 c4 = *reinterpret_cast<const uint4*>(row + x0);
    p[1][q] = c4.x; p[2][q] = c4.y; p[3][q] = c4.z; p[4][q] = c4.w;
#else
    p[1][q] = row[x0]; p[2][q] = row[x0 + 1]; p[3][q] = row[x0 + 2]; p[4][q] = row[x0 + 3];
#endif
    p[0][q] = row[x0 - 1];
    p[5][q] = row[x0 + 4];
  }
  u32 A[C], aO[C], B[C], bO[C];
  u32 cl;
  {
    const int r = bits::low_summary(p[0]);
    cl = r == 2 ? rare_low_cin(v, w0, p[0][0], p[0][1], p[0][2], p[0][3], p[0][4]) : (u32)r;  // rare: word w0-1 is all pair-sum 9
  }
  TB_UNROLL
  for (int i = 0; i < C; ++i) {
    u32 G = bits::Gof(p[i + 1]), X = G | bits::Pof(p[i + 1]);
    u64 t = (u64)X + G + cl;
    A[i] = (u32)t ^ X ^ G; aO[i] = (u32)(t >> 32); cl = aO[i];
  }
  u32 ch;
  {
    u32 G = bits::Gof(p[C + 1]), X = G | bits::Pof(p[C + 1]);
    u64 t = (u64)bits::brev32(X) + bits::brev32(G);
    if (t >> 32) ch = 1u;
    else if ((u32)t != 0xFFFFFFFFu) ch = 0u;
    else ch = rare_high_cin(v, n, w0 + C - 1, p[C + 1][0], p[C + 1][1], p[C + 1][2], p[C + 1][3], p[C + 1][4]);  // rare: whole neighbour word is 9s
  }
  TB_UNROLL
  for (int i = C - 1; i >= 0; --i) {
    u32 G = bits::Gof(p[i + 1]), X = G | bits::Pof(p[i + 1]);
    u32 Xr = bits::brev32(X), Gr = bits::brev32(G);
    u64 t = (u64)Xr + Gr + ch;
    B[i] = bits::brev32((u32)t ^ Xr ^ Gr); bO[i] = (u32)(t >> 32); ch = bO[i];
  }
  u32 out[C][5];
  u32 diff = 0;
  if (!g) {
    TB_UNROLL
    for (int i = 0; i < C; ++i) {
      const u32* cw = p[i + 1];
      const u32 a = A[i], b = B[i];
      const u32 aup = (A[i] >> 1) | (aO[i] << 31), bdn = (b << 1) | bO[i];
      u32 t0 = a ^ b, t1 = a & b;
      u32 v1 = cw[0] ^ t1, cc = cw[0] & t1;
      u32 v2 = cw[1] ^ cc; cc &= cw[1];
      u32 v3 = cw[2] ^ cc; cc &= cw[2];
      u32 v4 = cw[3] ^ cc;
      u32 k1 = aup ^ bdn, k2 = aup & bdn;
      u32 r1 = v1 ^ k1, bo = ~v1 & k1;
      u32 dd = v2 ^ k2; u32 r2 = dd ^ bo; bo = (~v2 & k2) | (~dd & bo);
      dd = v3 ^ k1;     u32 r3 = dd ^ bo; bo = (~v3 & k1) | (~dd & bo);
      dd = v4 ^ k2;     u32 r4 = dd ^ bo;
      out[i][0] = t0; out[i][1] = r1; out[i][2] = r2; out[i][3] = r3; out[i][4] = r4;
      diff |= t0;
    }
  } else {
    // high digit of pair 32*w0-1 (bit 31 of the previous word): S + b_{32w0-1} - 10 b_{32w0-2}
    u32 hprev[4];
    if (w0 == 0) {  // hi_{-1} = 1: the new leading digit (as in the general path)
      hprev[0] = 1u << 31; hprev[1] = hprev[2] = hprev[3] = 0;
    } else {
      const u32 bv = bO[0] << 31;
      const u32 bd = bits::Gof(p[0]) | (bits::Pof(p[0]) & bv);
      bits::digit4(p[0], bv, bd, hprev);
    }
    TB_UNROLL
    for (int i = 0; i < C; ++i) {
      const u32* cw = p[i + 1];
      const u32 a = A[i], b = B[i];
      const u32 aup = (A[i] >> 1) | (aO[i] << 31), bdn = (b << 1) | bO[i];
      u32 lo[4], hi[4], hs[4];
      bits::digit4(cw, a, aup, lo);
      bits::digit4(cw, b, bdn, hi);
      TB_UNROLL
      for (int q = 0; q < 4; ++q) { hs[q] = (hi[q] << 1) | (hprev[q] >> 31); hprev[q] = hi[q]; }
      u32 cc = 0;
      TB_UNROLL
      for (int q = 0; q < 4; ++q) {
        diff |= lo[q] ^ hs[q];
        u32 x = lo[q], y = hs[q];
        out[i][q] = x ^ y ^ cc;
        cc = (x & y) | (cc & (x ^ y));
      }
      out[i][4] = cc;
    }
  }
  TB_UNROLL
  for (int q = 0; q < 5; ++q) {
    u32* row = d + q * v.stride;
#ifdef __CUDA_ARCH__
    *reinterpret_cast<uint4*>(row + x0) = make_uint4(out[0][q], out[1][q], out[2][q], out[3][q]);
#else
    row[x0] = out[0][q]; row[x0 + 1] = out[1][q]; row[x0 + 2] = out[2][q]; row[x0 + 3] = out[3][q];
#endif
  }
  // v6r2: for word 0, also report the first non-9 pair of the new state among words 0..3 and its
  // growth bit, from registers (same result as growth_find on the stored words: under the fast-path
  // precondition the new h exceeds 128, so no masking applies). Packed: bit 1 = present,
  // bit 2 = growth, bits 3..10 = pair index (255 = none among the first 128).
  u32 gres = 0;
  if (w0 == 0) {
    u32 q = 255, gb = 0;
    const u32 nn0 = ~bits::Pof(out[0]);
    if (nn0) {  // v6r3: word 0 decides unless all its 32 pairs sum to 9
      const int b = ctz32(nn0); q = (u32)b; gb = (bits::Gof(out[0]) >> b) & 1u;
    } else {  // rare: unrolled, constant indices (a dynamic index would move out[][] to local memory)
      TB_UNROLL
      for (int i = C - 1; i >= 1; --i) {
        const u32 nn = ~bits::Pof(out[i]);
        if (nn) { const int b = ctz32(nn); q = 32u * i + (u32)b; gb = (bits::Gof(out[i]) >> b) & 1u; }
      }
    }
    gres = 2u | (gb << 2) | (q << 3);
  }
  return (u32)(countM && diff != 0) | gres;
}

// Dispatch: fast path when its preconditions hold, otherwise the general (v5) path.
#if defined(TB_COUNT_PATHS) && !defined(__CUDA_ARCH__)
static std::atomic<long long> g_fast{0}, g_slow{0};  // test builds only: path coverage
#define TB_COUNT(x) (x)++
#else
#define TB_COUNT(x)
#endif
#if defined(TB_CHECK_GROWTH) && !defined(__CUDA_ARCH__)
#include <atomic>
#include <cstdio>
#include <cstdlib>
static std::atomic<long long> g_growth_checks{0};
#endif
BHD u32 step_group(const View& v, u32* __restrict__ d, dlen n, int g, int w0, int mlo, int mhi) {
  const int nh = (int)(n - (n + 1) / 2);
  const long long lo = 32LL * w0, hi = 32LL * (w0 + 4);
  if (w0 >= 0 && 32LL * (w0 + 5) <= nh) {
    // v6r2: one call site (the two cases are mutually exclusive)
    const bool full = mlo <= lo && hi <= mhi;
    const bool none = hi <= mlo || mhi <= lo || mhi <= mlo;
    if (full || none) { TB_COUNT(g_fast); return step_group_fast(v, d, n, g, w0, full); }
  }
  TB_COUNT(g_slow);
  return step_group_slow(v, d, n, g, w0, mlo, mhi);
}

// ---- certified interval tracking (pair indices) ----
struct Track { int L, R, rightReal; };

// Interval of exact values after one step from values certified on [L,R). 0 = certification lost.
BHD int track_step(const View& v, Track& tr, dlen n, int g) {
  const int h = (int)((n + 1) / 2);
  if (tr.rightReal) {  // middle carry scan (from pair h-1 down) must end inside certified data
    int q = h - 1;
    while (q >= tr.L && is9(v, q)) --q;
    if (q < tr.L && tr.L > 0) return 0;
  }
  int nL, nR;
  if (tr.L == 0) nL = 0;
  else {
    int q = tr.L;
    while (q < tr.R && is9(v, q)) ++q;
    if (q >= tr.R) return 0;
    nL = q + 1;
  }
  if (tr.rightReal) nR = (int)((n + g + 1) / 2);
  else {
    int r = tr.R - 1;
    while (r >= tr.L && is9(v, r)) --r;
    if (r < tr.L) return 0;
    nR = g ? r + 1 : r;
  }
  tr.L = nL; tr.R = nR;
  return nL < nR;
}
// Growth of the next step from a left-anchored certified tile (first non-9 pair is >= 10).
BHD int growth_cert(const View& v, const Track& tr, dlen n, int* g) {
  const int h = (int)((n + 1) / 2);
  for (int w = 0; w < 4; ++w) {
    u32 p[5]; vld(v, w, p);
    u32 nn = ~bits::Pof(p) & bits::hmask(w, h);
    if (nn) {
      int b = 0;
      while (!((nn >> b) & 1u)) ++b;
      int q = 32 * w + b;
      *g = (int)((bits::Gof(p) >> b) & 1u);
      return q < tr.R;
    }
  }
  *g = 0;  // no non-9 pair among the first 128
  return (h <= 128 && tr.rightReal && tr.R >= h);
}

// v6r: the two halves of growth_cert. growth_find (thread 0, right after it wrote prefix words
// 0..3) returns the first non-9 pair among the first 128 (-1 if none) and the growth bit;
// growth_ok (prefix tracker, next step) applies growth_cert's condition on the same interval.
BHD int growth_find(const View& v, dlen n, int* g) {
  const int h = (int)((n + 1) / 2);
  for (int w = 0; w < 4; ++w) {
    u32 p[5]; vld(v, w, p);
    u32 nn = ~bits::Pof(p) & bits::hmask(w, h);
    if (nn) {
      const int b = ctz32(nn);
      *g = (int)((bits::Gof(p) >> b) & 1u);
      return 32 * w + b;
    }
  }
  *g = 0;
  return -1;
}
BHD int growth_ok(int q, const Track& tr, dlen n) {
  const int h = (int)((n + 1) / 2);
  return q >= 0 ? q < tr.R : (h <= 128 && tr.rightReal && tr.R >= h);
}

// ---- tile geometry ----
BHD int halo_words(int K) { return ((K + K / 4 + 64 + 31) / 32 + 3) & ~3; }
BHD int len_max(int TW, int HW, int K) { return (TW + 2 * HW + K / 64 + 16 + 3) & ~3; }
BHD int prefix_words(int HW) { return HW + 4; }
BHD int plen_max(int PW, int K) { return (PW + K / 64 + 16 + 3) & ~3; }

struct Conf { int K, TW, HW, PW, lenMax, plenMax, Wcap, hy; bits::u32 one, two, t31; };  // v8: hy = hybrid blocks; v9: 1, 2, 2^31 for TB_PIPEBAL

struct State {  // per block, in shared memory
  dlen n0;
  int h0, maxw;
  int o0w, o1w, bw, len, plen;
  int dead, okT, okP;
  int gq[2];  // v6r: first non-9 pair found by growth_find, validated by the prefix tracker
  Track tr, ptr;
  int gS[2];                    // v8b: g_t ring (was KMAX+1 ints = 4 KB of shared memory per block)
  unsigned gbits[KMAX / 32 + 1];  // v8b: bit t = g_t, for the control tape
  unsigned qm[KMAX / 32];  // v6r3: bit t = some thread of the block saw a mismatch at step t
  int hy, hyok;            // v8: block runs the hybrid path; all owned groups certified so far
};
// plane stride = data capacity + guards on both sides (all multiples of 4 words: 16-byte rows)
BHD int tstride(const Conf& c) { return c.lenMax + 2 * GUARD; }
BHD int pstride(const Conf& c) { return c.plenMax + 2 * GUARD; }
BHD size_t state_bytes() { return (sizeof(State) + 15) & ~(size_t)15; }
// v8: certified spans of the hybrid groups, 2 parities x (lo, hi) bytes per group (+1 sentinel each side)
BHD int span_n(const Conf& c) { return c.lenMax / 4 + 2; }
BHD size_t span_bytes(const Conf& c) { return ((size_t)4 * span_n(c) + 15) & ~(size_t)15; }
BHD size_t smem_bytes(const Conf& c) {
  return state_bytes() + sizeof(u32) * 5 * 2 * (size_t)(tstride(c) + pstride(c)) + span_bytes(c);
}
// pointers to word 0 of plane 0 (guards precede it)
BHD u32* tile_buf(u32* base, const Conf& c, int parity) { return base + (size_t)parity * 5 * tstride(c) + GUARD; }
BHD unsigned char* span_lo(u32* base, const Conf& c, int parity) {
  return reinterpret_cast<unsigned char*>(base + (size_t)10 * tstride(c) + (size_t)10 * pstride(c)) + (size_t)parity * 2 * span_n(c);
}
BHD u32* pre_buf(u32* base, const Conf& c, int parity) {
  return base + (size_t)10 * tstride(c) + (size_t)parity * 5 * pstride(c) + GUARD;
}
BHD View tile_view(const State& S, u32* base, const Conf& c, int parity) {
  View v; v.s = tile_buf(base, c, parity); v.stride = tstride(c); v.base = S.bw; v.len = S.len; return v;
}
BHD View pre_view(const State& S, u32* base, const Conf& c, int parity) {
  View v; v.s = pre_buf(base, c, parity); v.stride = pstride(c); v.base = 0; v.len = S.plen; return v;
}

// Phase 1 (thread 0): geometry of block `blk`.
BHD void ph_setup(State& S, const Conf& c, int blk, dlen n0) {
  S.n0 = n0;
  S.h0 = (int)((n0 + 1) / 2);
  S.maxw = (S.h0 + c.K / 2 + 2 + 31) / 32;  // words that can hold data after K steps
  S.o0w = blk * c.TW;
  S.o1w = S.o0w + c.TW < c.Wcap ? S.o0w + c.TW : c.Wcap;
  S.dead = S.o0w >= S.maxw;
  int bw = S.o0w - c.HW;
  S.bw = bw < 0 ? 0 : (bw & ~3);
  long long R0 = 32LL * (S.o1w + c.HW);
  if (R0 > S.h0) R0 = S.h0;
  int rightReal = (R0 == S.h0);
  int endw = S.o1w + c.HW;
  if (rightReal && S.maxw + 1 > endw) endw = S.maxw + 1;
  S.len = ((endw - S.bw + 3) & ~3) + 4;
  S.tr.L = 32 * S.bw; S.tr.R = (int)R0; S.tr.rightReal = rightReal;
  long long pR0 = 32LL * c.PW;
  if (pR0 > S.h0) pR0 = S.h0;
  int prr = (pR0 == S.h0);
  int pend = c.PW;
  if (prr && S.maxw + 1 > pend) pend = S.maxw + 1;
  S.plen = ((pend + 3) & ~3) + 4;
  S.ptr.L = 0; S.ptr.R = (int)pR0; S.ptr.rightReal = prr;
  S.okT = S.okP = 1;
  // v8: hybrid only for interior blocks: not the outer edge (block 0), no real right edge, and every
  // window (up to word bw+len, the guard after the tile) stays below the middle for all K steps.
  const long long nh0 = n0 - (n0 + 1) / 2;
  // v9: and the tile's groups fit the warps (30 core groups per warp)
  S.hy = c.hy && S.o0w > 0 && !rightReal && 32LL * (S.bw + S.len + 2) <= nh0 && S.len / 4 <= WY_CORE * (THREADS / 32);
  S.hyok = 1;
}
// Phase 2 (all threads): global -> shared.
BHD void ph_load(const State& S, const Conf& c, u32* base, const u32* src, int tid, int nth) {
  const int ts = tstride(c), ps = pstride(c);
  u32* t0 = tile_buf(base, c, 0);
  const int len = S.len, plen = S.plen, bw = S.bw;
  for (int q = 0; q < 5; ++q)  // v6r3: plane by plane, no integer division per element
    for (int x = tid; x < len; x += nth) {
      const int k = bw + x;
      t0[q * ts + x] = k < c.Wcap ? src[(size_t)q * c.Wcap + k] : 0u;
    }
  u32* p0 = pre_buf(base, c, 0);
  for (int q = 0; q < 5; ++q)
    for (int x = tid; x < plen; x += nth) p0[q * ps + x] = x < c.Wcap ? src[(size_t)q * c.Wcap + x] : 0u;
  // zero the guards (before word 0 and right after the used length) of both parities
  for (int i = tid; i < 2 * 5 * 2 * GUARD; i += nth) {
    int par = i / (5 * 2 * GUARD), r = i % (5 * 2 * GUARD), q = r / (2 * GUARD), gi = r % (2 * GUARD);
    u32* tb = tile_buf(base, c, par) + q * ts;
    u32* pb = pre_buf(base, c, par) + q * ps;
    int off = gi < GUARD ? gi - GUARD : gi - GUARD;  // -GUARD..-1 then 0..GUARD-1 (after len)
    if (gi < GUARD) { tb[off] = 0u; pb[off] = 0u; }
    else { tb[S.len + off] = 0u; pb[S.plen + off] = 0u; }
  }
}
// Phase 3 (thread 0): growth of the first step.
BHD void ph_init(State& S, const Conf& c, u32* base) {
  for (int i = 0; i < KMAX / 32; ++i) S.qm[i] = 0u;
  int g;
  if (!growth_cert(pre_view(S, base, c, 0), S.ptr, S.n0, &g)) S.okP = 0;
  S.gS[0] = g;
  for (int i = 0; i < KMAX / 32 + 1; ++i) S.gbits[i] = 0u;
  S.gbits[0] = (unsigned)(g & 1);
}
// Step t, before the barrier-free work: thread 1 tracks the tile, thread 0 the prefix.
// Thread roles (v6r). Warp 1 tracks: thread 32 the tile, thread 33 the prefix tile, through one
// call site with register copies of View/Track. Every other thread is a worker.
static const int TRACK_TID = 32;
BHD bool is_worker(int tid) { return tid < TRACK_TID || tid >= TRACK_TID + 32; }
BHD int worker_index(int tid) { return tid < TRACK_TID ? tid : tid - 32; }
BHD int num_workers(int nth) { return nth - 32; }
// Step t, concurrently with the work.
BHD void ph_track(State& S, const Conf& c, u32* base, int t, dlen n, int g, int tid) {
  if (tid != TRACK_TID && tid != TRACK_TID + 1) return;
  const bool tile = tid == TRACK_TID;
  if (!(tile ? S.okT : S.okP)) return;
  if (!tile && t > 0 && !growth_ok(S.gq[t & 1], S.ptr, n)) { S.okP = 0; return; }  // check g_t
  View v;
  v.s = tile ? tile_buf(base, c, t & 1) : pre_buf(base, c, t & 1);
  v.stride = tile ? tstride(c) : pstride(c);
  v.base = tile ? S.bw : 0;
  v.len = tile ? S.len : S.plen;
  Track tr = tile ? S.tr : S.ptr;
  const int ok = track_step(v, tr, n, g);
  if (tile) { S.tr = tr; S.okT = ok; } else { S.ptr = tr; S.okP = ok; }
}
// v6r3: per-launch, per-thread constants (tile geometry is fixed for the whole launch).
struct WorkCtx { int wi, nw, np, items, bw, len, plen, o0w, o1w; };
BHD WorkCtx work_ctx(const State& S, int tid, int nth) {
  WorkCtx w;
  w.wi = is_worker(tid) ? worker_index(tid) : 1 << 30;  // non-workers get no items
  w.nw = num_workers(nth);
  w.np = S.plen / 4;
  w.items = w.np + S.len / 4;
  w.bw = S.bw; w.len = S.len; w.plen = S.plen; w.o0w = S.o0w; w.o1w = S.o1w;
  return w;
}
// Step t work for one thread: worker i takes items i, i+W, ... of the list [prefix groups][tile
// groups] (one call site, so a warp with both kinds stays converged). Item 0 is prefix words
// 0..3, done by thread 0, which then finds g_{t+1}. Returns bit 0 = mismatch seen, and for
// thread 0 bit 1 = g_{t+1}. g = growth of step t (from the previous barrier, in a register).
BHD u32 ph_work(State& S, const Conf& c, u32* base, const WorkCtx& w, int t, dlen n, int g, int tid) {
  if (w.wi >= w.items) return 0;
  const int par = t & 1;
  const int h1 = (int)((n + g + 1) / 2);
  const int plo = 32 * w.o0w;
  long long phl = 32LL * w.o1w;
  const int phi = phl < h1 ? (int)phl : h1;
  const u32* ps = pre_buf(base, c, par);
  const u32* ts = tile_buf(base, c, par);
  u32* pd = pre_buf(base, c, par ^ 1);
  u32* td = tile_buf(base, c, par ^ 1);
  u32 mism = 0, gr = 0;
  for (int i = w.wi; i < w.items; i += w.nw) {
    const bool pre = i < w.np;
    View a;
    a.s = pre ? ps : ts;
    a.stride = pre ? pstride(c) : tstride(c);
    a.base = pre ? 0 : w.bw;
    a.len = pre ? w.plen : w.len;
    const int w0 = pre ? 4 * i : w.bw + 4 * (i - w.np);
    const u32 r = step_group(a, pre ? pd : td, n, g, w0, pre ? 0 : plo, pre ? 0 : phi);
    mism |= r & 1u;
    if (i == 0) gr = r;  // item 0 = prefix words 0..3 (thread 0 only)
  }
  if (tid == 0) {
    int gn, q;
    if (gr & 2u) {  // from registers (fast path)
      gn = (int)((gr >> 2) & 1u);
      q = (int)((gr >> 3) & 255u);
      if (q == 255) q = -1;
    } else {        // general path: read back the words this thread just wrote
      q = growth_find(pre_view(S, base, c, par ^ 1), n + g, &gn);
    }
#if defined(TB_CHECK_GROWTH) && !defined(__CUDA_ARCH__)
    if (gr & 2u) {  // test builds: the register result must equal the shared-memory search
      int g2;
      const int q2 = growth_find(pre_view(S, base, c, par ^ 1), n + g, &g2);
      if (q2 != q || g2 != gn) { fprintf(stderr, "growth mismatch t=%d q=%d/%d g=%d/%d\n", t, q, q2, gn, g2); abort(); }
      ++g_growth_checks;
    }
#endif
    S.gq[(t + 1) & 1] = q;
    S.gS[(t + 1) & 1] = gn;
    if (gn) S.gbits[(t + 1) >> 5] |= 1u << ((t + 1) & 31);
    return mism | ((u32)gn << 1);
  }
  return mism;
}
// After K steps (thread 0): certification verdict for the owned pairs.
BHD int ph_verdict(const State& S, dlen nK) {
  const int hK = (int)((nK + 1) / 2);
  long long phl = 32LL * S.o1w;
  const int phi = phl < hK ? (int)phl : hK;
  return S.okT && S.okP && S.tr.L <= 32 * S.o0w && S.tr.R >= phi;
}
// Owned words -> global (all threads).
BHD void ph_store(const State& S, const Conf& c, u32* base, u32* dst, int K, int tid, int nth) {
  const u32* f = tile_buf(base, c, K & 1);
  const int ts = tstride(c);
  for (int x = S.o0w + tid; x < S.o1w; x += nth)
    for (int q = 0; q < 5; ++q) dst[(size_t)q * c.Wcap + x] = f[q * ts + (x - S.bw)];
}

// Owned words -> global from the buffer of the given parity (v8 hybrid blocks).
BHD void ph_store_par(const State& S, const Conf& c, u32* base, u32* dst, int parity, int tid, int nth) {
  const u32* f = tile_buf(base, c, parity);
  const int ts = tstride(c);
  for (int x = S.o0w + tid; x < S.o1w; x += nth)
    for (int q = 0; q < 5; ++q) dst[(size_t)q * c.Wcap + x] = f[q * ts + (x - S.bw)];
}

// ---------------- v9 warp windows ----------------
// A hybrid block's groups (4 words each) are dealt to warps: warp w, lane l holds group
// gi = 30w + l - 1. Lanes 1..30 are "core" (their 4 words are kept); lanes 0 and 31 hold the
// neighbouring warps' first/last core groups as a 128-pair halo on each side. The warp runs TB_J
// steps with no barrier and no shared memory; the only cross-lane data per step are the two carry
// bits that cross each lane boundary (low chain upward, high chain downward), passed by warp
// shuffles, plus 4 digit planes of the boundary pair in growth steps. A carry bit computed from the
// sending lane's edge word alone is exact unless that whole word is pair-sum 9 (X+G = all ones);
// then (rare: ~1e-32 per word, or planted test data) the warp resolves every lane's carry-in
// exactly with a sequential scan. Certification: one interval [L,R) per warp (warp pair
// coordinates 0..4096), tracked with the track_step rule exactly as v8 did per thread; the window
// edges' unknown carries are taken as 0 (outside the interval), so the rule stays sound. v8
// computed 6 words per 4 kept; v9 computes 32 groups per 30 kept, and the halo is 128 pairs instead
// of 32, so windows can be long (default TB_J = 32: 4 barriers per 128-step launch).
#ifndef TB_J
#define TB_J 32
#endif
static_assert(TB_J >= 1 && TB_J <= 32, "TB_J must be 1..32");
#ifndef TB_PIPEBAL
#define TB_PIPEBAL 0
#endif
#if defined(WY_ANALYZE) && !defined(WY_ANALYZE_G)
#define WY_ANALYZE_G 0
#endif
// v8b: windows may straddle 32-bit words of the tape / mismatch bitmask (TB_J need not divide 32)
BHD u32 tape_bits(const unsigned* tape, int t0) {
  const int w = t0 >> 5, sh = t0 & 31;
  return sh ? ((tape[w] >> sh) | (tape[w + 1] << (32 - sh))) : tape[w];
}
BHD int clz32(u32 x) {
#ifdef __CUDA_ARCH__
  return __clz(x);
#else
  return __builtin_clz(x);
#endif
}
BHD u32 mask_ge(int s) { return s <= 0 ? ~0u : (s >= 32 ? 0u : (~0u << s)); }        // bits >= s
BHD u32 mask_lt(int s) { return s <= 0 ? 0u : (s >= 32 ? ~0u : ((1u << s) - 1u)); }   // bits < s

// Spans of parity 0 from the tile's initial certified interval S.tr; empty sentinels (index 0 and
// G+1) in both parities. Group gi has index gi+1; offsets 0..128 within its 128 pairs.
BHD void hy_init_spans(const State& S, const Conf& c, u32* base, int tid, int nth) {
  const int G = S.len / 4, N = span_n(c);
  unsigned char* lo0 = span_lo(base, c, 0); unsigned char* hi0 = lo0 + N;
  unsigned char* lo1 = span_lo(base, c, 1); unsigned char* hi1 = lo1 + N;
  for (int i = tid; i < G + 2; i += nth) {
    int lo = 0, hi = 0;
    if (i >= 1 && i <= G) {
      const long long g0 = 32LL * (S.bw + 4 * (i - 1));
      long long a = S.tr.L > g0 ? S.tr.L : g0, b = S.tr.R < g0 + 128 ? S.tr.R : g0 + 128;
      if (a < b) { lo = (int)(a - g0); hi = (int)(b - g0); }
    }
    lo0[i] = (unsigned char)lo; hi0[i] = (unsigned char)hi;
    if (i == 0 || i == G + 1) { lo1[i] = 0; hi1[i] = 0; }
  }
}

// ---- v9 pipe balancing (TB_PIPEBAL=1): adds and shifts as multiply-adds, so they issue on the
// FMA pipe (5.6% busy in the v8 profile) instead of the ALU pipe (86%). The multipliers 1, 2 and
// 2^31 come from the launch configuration, so the compiler cannot turn them back into shifts.
// Exact identities: (a >> 1) | (t << 31) = t * 2^31 + mulhi(a, 2^31); (b << 1) | u = b * 2 + u;
// (x << 1) | (p >> 31) = x * 2 + mulhi(p, 2). The 64-bit carry-chain adds stay on the ALU (see pb_add3).
BHD u64 pb_add3(u32 x, u32 y, u32 cin, u32 one) {
  // Kept on the ALU: ptxas splits mad.wide with a 64-bit addend into IMAD.WIDE + IADD3 pairs
  // (checked in the SASS), which only adds instructions.
  (void)one;
  return (u64)x + y + cin;
}
BHD u32 pb_shr1_in(u32 a, u32 top, u32 t31) {  // (a >> 1) | (top << 31), top in {0,1}
#if TB_PIPEBAL && defined(__CUDA_ARCH__)
  u32 h, r;
  asm("mul.hi.u32 %0, %1, %2;" : "=r"(h) : "r"(a), "r"(t31));
  asm("mad.lo.u32 %0, %1, %2, %3;" : "=r"(r) : "r"(top), "r"(t31), "r"(h));
  return r;
#else
  (void)t31;
  return (a >> 1) | (top << 31);
#endif
}
BHD u32 pb_shl1_in(u32 b, u32 bot, u32 two) {  // (b << 1) | bot, bot in {0,1}
#if TB_PIPEBAL && defined(__CUDA_ARCH__)
  u32 r;
  asm("mad.lo.u32 %0, %1, %2, %3;" : "=r"(r) : "r"(b), "r"(two), "r"(bot));
  return r;
#else
  (void)two;
  return (b << 1) | bot;
#endif
}
BHD u32 pb_shl1_top(u32 x, u32 prev, u32 two) {  // (x << 1) | (prev >> 31)
#if TB_PIPEBAL && defined(__CUDA_ARCH__)
  u32 h, r;
  asm("mul.hi.u32 %0, %1, %2;" : "=r"(h) : "r"(prev), "r"(two));
  asm("mad.lo.u32 %0, %1, %2, %3;" : "=r"(r) : "r"(x), "r"(two), "r"(h));
  return r;
#else
  (void)two;
  return (x << 1) | (prev >> 31);
#endif
}

// ---- v8b base-5 ("quinary") pair-sum encoding, used inside hybrid windows when TB_QUINARY=1 ----
// S = M + 5H + 10G with M = S mod 5 (planes 0..2), H = floor(S/5) mod 2 (plane 3), G = S >= 10 (plane 4).
// Then G (carry generate) is a plane, P = (S == 9) = H & M2, and the digit for carry-in c is
// d(S, c) = M + 5H + c - 10 P c (G cancels). Only window registers use it; tiles, checkpoints and the
// v4 kernel stay binary (conversion at window load/store).
#ifndef TB_QUINARY
#define TB_QUINARY 0
#endif
// V (0..10, 4 planes v3..v0) -> M' = V mod 5 (3 planes), q0/q1 = bits of floor(V/5)
BHD void quin_reduce(u32 v0, u32 v1, u32 v2, u32 v3, u32& M0, u32& M1, u32& M2, u32& q0, u32& q1) {
  const u32 ge10 = v3 & v1, ge5 = v3 | (v2 & (v1 | v0));
  q0 = ge5 & ~ge10; q1 = ge10;
  M2 = (~v3 & v2 & ~v1 & ~v0) | (v3 & v0);
  M1 = (~v3 & v1 & (~v2 | v0)) | (v3 & ~v1 & ~v0);
  M0 = (~v3 & ~v2 & v0) | (~v3 & v2 & v1 & ~v0) | (v3 & ~v1 & ~v0);
}
// binary S (5 planes) -> quinary (m0, m1, m2, H, G), in place
BHD void bin2quin(u32 p[5]) {
  const u32 G = bits::Gof(p);
  // R = S - 10G = S + 22G mod 32 (22 = 10110b): only bits 0..3 matter (R <= 9)
  const u32 r0 = p[0];
  const u32 r1 = p[1] ^ G;               u32 c = p[1] & G;
  const u32 r2 = p[2] ^ G ^ c;           c = (p[2] & G) | (p[2] & c) | (G & c);
  const u32 r3 = p[3] ^ c;
  u32 M0, M1, M2, q0, q1;
  quin_reduce(r0, r1, r2, r3, M0, M1, M2, q0, q1);  // R <= 9: q0 = (R >= 5) = H
  p[0] = M0; p[1] = M1; p[2] = M2; p[3] = q0; p[4] = G;
}
// quinary -> binary S = M + 5H + 10G, in place
BHD void quin2bin(u32 p[5]) {
  const u32 m0 = p[0], m1 = p[1], m2 = p[2], H = p[3], G = p[4];
  // T = M + 5H  (5 = 101b)
  const u32 t0 = m0 ^ H;            u32 c = m0 & H;
  const u32 t1 = m1 ^ c;            c = m1 & c;
  const u32 t2 = m2 ^ H ^ c;        c = (m2 & H) | (m2 & c) | (H & c);
  const u32 t3 = c;
  // S = T + 10G  (10 = 1010b)
  const u32 s1 = t1 ^ G;            c = t1 & G;
  const u32 s2 = t2 ^ c;            c = t2 & c;
  const u32 s3 = t3 ^ G ^ c;        c = (t3 & G) | (t3 & c) | (G & c);
  p[0] = t0; p[1] = s1; p[2] = s2; p[3] = s3; p[4] = c;
}

// one quinary pair-sum update, no growth: S' = d(S,a) + d(S,b). Returns the mismatch bits (a ^ b).
BHD u32 quin_ng(u32 cw[5], u32 a, u32 b) {
  const u32 m0 = cw[0], m1 = cw[1], m2 = cw[2], H = cw[3], P = H & m2;
  const u32 s0 = a ^ b, c0 = a & b;
  const u32 v1 = m0 ^ c0, c1 = m0 & c0;
  const u32 v2 = m1 ^ c1, c2 = m1 & c1;
  const u32 v3 = m2 ^ c2;
  u32 M0, M1, M2, q0, q1;
  quin_reduce(s0, v1, v2, v3, M0, M1, M2, q0, q1);
  cw[0] = M0; cw[1] = M1; cw[2] = M2; cw[3] = q0; cw[4] = H ^ q1 ^ (P & s0);
  return s0;
}
// one quinary pair-sum update, growth: S'_j = d(S_j, a_j) + d(S_{j-1}, b_{j-1}), with pair j-1
// given as (my0..my2, Hy) and b_{j-1} as by. Returns the mismatch bits d(S_j,a_j) != d(S_{j-1},b_{j-1}).
BHD u32 quin_g(u32 cw[5], u32 a, u32 by, u32 my0, u32 my1, u32 my2, u32 Hy) {
  const u32 mx0 = cw[0], mx1 = cw[1], mx2 = cw[2], Hx = cw[3];
  const u32 Px = Hx & mx2, Py = Hy & my2;
  const u32 s0 = mx0 ^ my0 ^ a;  u32 k = (mx0 & my0) | (mx0 & a) | (my0 & a);
  const u32 s1 = mx1 ^ my1 ^ k;  k = (mx1 & my1) | (mx1 & k) | (my1 & k);
  const u32 s2 = mx2 ^ my2 ^ k;  const u32 u3 = (mx2 & my2) | (mx2 & k) | (my2 & k);
  const u32 v0 = s0 ^ by;        u32 e = s0 & by;
  const u32 v1 = s1 ^ e;         e = s1 & e;
  const u32 v2 = s2 ^ e;         e = s2 & e;
  const u32 v3 = u3 ^ e;
  u32 M0, M1, M2, q0, q1;
  quin_reduce(v0, v1, v2, v3, M0, M1, M2, q0, q1);
  const u32 maj = (Hx & Hy) | (Hx & q0) | (Hy & q0);
  cw[0] = M0; cw[1] = M1; cw[2] = M2; cw[3] = Hx ^ Hy ^ q0;
  cw[4] = maj ^ q1 ^ (Px & a) ^ (Py & by);
  // digit d = 5h + e' with e = M + c (0..5), e' = e mod 5, h = H ^ (e == 5)
  const u32 xe0 = mx0 ^ a, xt = mx0 & a, xe1 = mx1 ^ xt, xe2 = mx2 ^ (mx1 & xt);
  const u32 ye0 = my0 ^ by, yt = my0 & by, ye1 = my1 ^ yt, ye2 = my2 ^ (my1 & yt);
  const u32 x5 = xe2 & xe0, y5 = ye2 & ye0;
  return ((xe0 & ~xe2) ^ (ye0 & ~ye2)) | (xe1 ^ ye1) | ((xe2 & ~xe0) ^ (ye2 & ~ye0)) | ((Hx ^ x5) ^ (Hy ^ y5));
}


// ---- v9 warp-window step ----
// Ops = warp primitives (DevOps on the GPU, EmuOps in the CPU emulator); every Ops call is made by
// all 32 lanes (warp-uniform control flow), as __shfl_sync(0xffffffff, ...) requires.

#if defined(TB_COUNT_PATHS) && !defined(__CUDA_ARCH__)
static std::atomic<long long> g_resolve{0}, g_trackext{0};  // test builds: rare-path coverage
#define WY_COUNT(x) (x)++
#else
#define WY_COUNT(x)
#endif
// Warp interval [L,R) after one step: the track_step rule for an interior interval (L > true edge,
// no middle). P = pair-sum-9 planes of this lane's 4 words. L, R are warp-uniform.
// select word k & 3 of this lane's 4 (k warp-uniform): two predicates, three selects, no branches
BHD u32 sel4(const u32 v[4], int k) {
  const u32 lo = (k & 1) ? v[1] : v[0], hi = (k & 1) ? v[3] : v[2];
  return (k & 2) ? hi : lo;
}
template <class Ops>
BHD void wy_track(const u32 P[4], int& L, int& R, int g, bool lane0) {
  (void)lane0;
  // q = first pair >= L that is not 9: almost always inside the word holding L (one shuffle)
  int k = L >> 5;
  u32 m = ~Ops::shfl(sel4(P, k), k >> 2) & (~0u << (L & 31));
  while (!m) {  // rare: the rest of that word is all 9s
    if (32 * (k + 1) >= R) { L = R = 0; return; }
    ++k;
    m = ~Ops::shfl(sel4(P, k), k >> 2);
    if (lane0) WY_COUNT(g_trackext);
  }
  const int q = 32 * k + ctz32(m);
  if (q >= R) { L = R = 0; return; }
  // r = last pair < R that is not 9
  k = (R - 1) >> 5;
  m = ~Ops::shfl(sel4(P, k), k >> 2) & (0xFFFFFFFFu >> (31 - ((R - 1) & 31)));
  while (!m) {
    if (32 * k <= L) { L = R = 0; return; }
    --k;
    m = ~Ops::shfl(sel4(P, k), k >> 2);
    if (lane0) WY_COUNT(g_trackext);
  }
  const int r = 32 * k + 31 - clz32(m);
  if (r < L) { L = R = 0; return; }
  const int nL = q + 1, nR = g ? r + 1 : r;
  if (nL >= nR) { L = R = 0; return; }
  L = nL; R = nR;
}

// Rare path: some lane's edge word is entirely pair-sum 9, so its carry-out depends on its
// carry-in. Exact carry-ins for every lane by a sequential scan over the lanes (window edges: 0).
template <class Ops>
BHD void wy_resolve(const u32 Xw[4], const u32 Gw[4], int lane, u32& cinL, u32& cinH) {
  if (lane == 0) WY_COUNT(g_resolve);
  u32 c0 = 0, c1 = 1;
  TB_UNROLL
  for (int i = 0; i < 4; ++i) {
    c0 = (u32)(((u64)Xw[i] + Gw[i] + c0) >> 32);
    c1 = (u32)(((u64)Xw[i] + Gw[i] + c1) >> 32);
  }
  u32 c = 0;
  cinL = 0;
  for (int l = 0; l < 32; ++l) {  // c = carry into lane l
    if (lane == l) cinL = c;
    c = Ops::shfl(c ? c1 : c0, l);
  }
  u32 h0 = 0, h1 = 1;
  TB_UNROLL
  for (int i = 3; i >= 0; --i) {
    const u32 Xr = bits::brev32(Xw[i]), Gr = bits::brev32(Gw[i]);
    h0 = (u32)(((u64)Xr + Gr + h0) >> 32);
    h1 = (u32)(((u64)Xr + Gr + h1) >> 32);
  }
  c = 0;
  cinH = 0;
  for (int l = 31; l >= 0; --l) {  // c = high-chain carry into lane l's top word
    if (lane == l) cinH = c;
    c = Ops::shfl(c ? h1 : h0, l);
  }
}

// One window of js (<= TB_J) steps for this lane of warp `warp`, growth bits gb (bit s = g of step
// s). Reads parity par, writes the core lanes' words and spans to parity par^1. Returns the OR over
// the warp of the per-step mismatch bits of owned groups; clears S.hyok if an owned group is not
// certified at the end of the window.
template <class Ops>
BHD u32 wy_window(State& S, const Conf& c, u32* base, int warp, int lane, int par, int js, u32 gb) {
  const int ts = tstride(c), N = span_n(c), G = S.len / 4;
  const u32* src = tile_buf(base, c, par);
  u32* dst = tile_buf(base, c, par ^ 1);
  const int gi = WY_CORE * warp + lane - 1;
  const bool inb = gi >= -1 && gi <= G;  // gi = -1 / G read the zeroed guard words
  const bool core = lane >= 1 && lane <= WY_CORE && gi >= 0 && gi < G;
  const int x0 = 4 * gi;
  const int w0 = S.bw + x0;
  const bool owned = core && w0 >= S.o0w && w0 + 4 <= S.o1w;
  u32 p[4][5];
  TB_UNROLL
  for (int q = 0; q < 5; ++q) {
    if (inb) {
      const u32* row = src + q * ts + x0;
#ifdef __CUDA_ARCH__
      const uint4 c4 = *reinterpret_cast<const uint4*>(row);
      p[0][q] = c4.x; p[1][q] = c4.y; p[2][q] = c4.z; p[3][q] = c4.w;
#else
      p[0][q] = row[0]; p[1][q] = row[1]; p[2][q] = row[2]; p[3][q] = row[3];
#endif
    } else {
      p[0][q] = p[1][q] = p[2][q] = p[3][q] = 0u;
    }
  }
#if TB_QUINARY
  TB_UNROLL
  for (int k = 0; k < 4; ++k) bin2quin(p[k]);
#endif
  // initial warp interval from the published spans: the lanes' certified spans must form one run
  int L = 0, R = 0;
  {
    const unsigned char* slo = span_lo(base, c, par);
    const unsigned char* shi = slo + N;
    int lo = 0, hi = 0;
    if (gi + 1 >= 0 && gi + 1 <= G + 1) { lo = slo[gi + 1]; hi = shi[gi + 1]; }
    const u32 bm = Ops::ballot(lo < hi);
    if (bm) {
      const int f = ctz32(bm), e = 31 - clz32(bm);
      const int lof = (int)Ops::shfl((u32)lo, f), hif = (int)Ops::shfl((u32)hi, f);
      const int loe = (int)Ops::shfl((u32)lo, e), hie = (int)Ops::shfl((u32)hi, e);
      const bool hole = lane > f && lane < e && !(lo == 0 && hi == 128);
      const bool bad = Ops::any(hole) || (f < e && (hif != 128 || loe != 0));
      if (!bad) { L = 128 * f + lof; R = 128 * e + hie; }
    }
  }
  const u32 one = c.one, two = c.two, t31 = c.t31;
  u32 mism = 0;
  for (int s = 0; s < js; ++s) {
#ifdef WY_ANALYZE  // instruction-count analysis builds only: the common no-growth (or growth) step
    const int g = WY_ANALYZE_G; (void)gb;
#else
    const int g = (int)((gb >> s) & 1u);
#endif
    u32 Gw[4], Xw[4], Pw[4];
    TB_UNROLL
    for (int k = 0; k < 4; ++k) {
#if TB_QUINARY
      Gw[k] = p[k][4]; Pw[k] = p[k][3] & p[k][2];
#else
      Gw[k] = bits::Gof(p[k]); Pw[k] = bits::Pof(p[k]);
#endif
      Xw[k] = Gw[k] | Pw[k];
    }
    if (L < R) wy_track<Ops>(Pw, L, R, g, lane == 0);
    // carries crossing lane boundaries: from the sender's edge word alone (exact unless all 9s)
    const u64 tl = (u64)Xw[3] + Gw[3];
    const u32 Xr0 = bits::brev32(Xw[0]), Gr0 = bits::brev32(Gw[0]);
    const u64 th = (u64)Xr0 + Gr0;
    u32 cinL = Ops::shfl_up((u32)(tl >> 32), 1);
    u32 cinH = Ops::shfl_down((u32)(th >> 32), 1);
    if (lane == 0) cinL = 0;   // below the window: unknown, outside the certified interval
    if (lane == 31) cinH = 0;  // above the window: same
    const bool rare = (lane < 31 && (u32)tl == 0xFFFFFFFFu) || (lane > 0 && (u32)th == 0xFFFFFFFFu);
#ifdef WY_ANALYZE
    if (Ops::any(rare)) { cinL = cinH = 0; }
#else
    if (Ops::any(rare)) wy_resolve<Ops>(Xw, Gw, lane, cinL, cinH);
#endif
    u32 A[4], aO[4], B[4], bO[4];
    u32 cl = cinL;
    TB_UNROLL
    for (int i = 0; i < 4; ++i) {
      const u64 t = pb_add3(Xw[i], Gw[i], cl, one);
      A[i] = (u32)t ^ Xw[i] ^ Gw[i]; aO[i] = (u32)(t >> 32); cl = aO[i];
    }
    u32 ch = cinH;
    TB_UNROLL
    for (int i = 3; i >= 0; --i) {
      const u32 Xr = i ? bits::brev32(Xw[i]) : Xr0, Gr = i ? bits::brev32(Gw[i]) : Gr0;
      const u64 t = pb_add3(Xr, Gr, ch, one);
      B[i] = bits::brev32((u32)t ^ Xr ^ Gr); bO[i] = (u32)(t >> 32); ch = bO[i];
    }
    u32 diff = 0;
#if TB_QUINARY
    if (!g) {
      TB_UNROLL
      for (int i = 0; i < 4; ++i) diff |= quin_ng(p[i], A[i], B[i]);
    } else {
      // pair j-1 = previous bit: old planes of this word and of the word below (lane-1's word 3)
      u32 pm0 = Ops::shfl_up(p[3][0], 1), pm1 = Ops::shfl_up(p[3][1], 1);
      u32 pm2 = Ops::shfl_up(p[3][2], 1), pH = Ops::shfl_up(p[3][3], 1);
      if (lane == 0) pm0 = pm1 = pm2 = pH = 0u;  // below the window: unknown (uncertified)
      TB_UNROLL
      for (int i = 0; i < 4; ++i) {
        u32* cw = p[i];
        const u32 my0 = pb_shl1_top(cw[0], pm0, two), my1 = pb_shl1_top(cw[1], pm1, two);
        const u32 my2 = pb_shl1_top(cw[2], pm2, two), Hy = pb_shl1_top(cw[3], pH, two);
        pm0 = cw[0]; pm1 = cw[1]; pm2 = cw[2]; pH = cw[3];
        diff |= quin_g(cw, A[i], pb_shl1_in(B[i], bO[i], two), my0, my1, my2, Hy);
      }
    }
#else
    if (!g) {
      TB_UNROLL
      for (int i = 0; i < 4; ++i) {
        u32* cw = p[i];
        const u32 a = A[i], b = B[i];
        const u32 aup = pb_shr1_in(a, aO[i], t31), bdn = pb_shl1_in(b, bO[i], two);
        const u32 t0 = a ^ b, t1 = a & b;
        u32 v1 = cw[0] ^ t1, cc = cw[0] & t1;
        u32 v2 = cw[1] ^ cc; cc &= cw[1];
        u32 v3 = cw[2] ^ cc; cc &= cw[2];
        u32 v4 = cw[3] ^ cc;
        u32 k1 = aup ^ bdn, k2 = aup & bdn;
        u32 r1 = v1 ^ k1, bo = ~v1 & k1;
        u32 dd = v2 ^ k2; u32 r2 = dd ^ bo; bo = (~v2 & k2) | (~dd & bo);
        dd = v3 ^ k1;     u32 r3 = dd ^ bo; bo = (~v3 & k1) | (~dd & bo);
        dd = v4 ^ k2;     u32 r4 = dd ^ bo;
        cw[0] = t0; cw[1] = r1; cw[2] = r2; cw[3] = r3; cw[4] = r4;
        diff |= t0;
      }
    } else {
      u32 lo[4][4], hi[4][4];
      TB_UNROLL
      for (int i = 0; i < 4; ++i) {
        const u32 a = A[i], b = B[i];
        const u32 aup = pb_shr1_in(a, aO[i], t31), bdn = pb_shl1_in(b, bO[i], two);
        bits::digit4(p[i], a, aup, lo[i]);
        bits::digit4(p[i], b, bdn, hi[i]);
      }
      // high digit of the pair below this lane's word 0 = bit 31 of lane-1's word 3 high digits
      u32 hp[4];
      TB_UNROLL
      for (int q = 0; q < 4; ++q) { hp[q] = Ops::shfl_up(hi[3][q], 1); if (lane == 0) hp[q] = 0u; }
      TB_UNROLL
      for (int i = 0; i < 4; ++i) {
        u32 cc = 0;
        TB_UNROLL
        for (int q = 0; q < 4; ++q) {
          const u32 y = pb_shl1_top(hi[i][q], i ? hi[i - 1][q] : hp[q], two);
          const u32 x = lo[i][q];
          diff |= x ^ y;
          p[i][q] = x ^ y ^ cc;
          cc = (x & y) | (cc & (x ^ y));
        }
        p[i][4] = cc;
      }
    }
#endif
    if (owned && diff) mism |= 1u << s;
  }
  if (core) {
#if TB_QUINARY
    TB_UNROLL
    for (int k = 0; k < 4; ++k) quin2bin(p[k]);
#endif
    TB_UNROLL
    for (int q = 0; q < 5; ++q) {
      u32* row = dst + q * ts + x0;
#ifdef __CUDA_ARCH__
      *reinterpret_cast<uint4*>(row) = make_uint4(p[0][q], p[1][q], p[2][q], p[3][q]);
#else
      row[0] = p[0][q]; row[1] = p[1][q]; row[2] = p[2][q]; row[3] = p[3][q];
#endif
    }
    int lo = 0, hi = 0;
    if (L < R) {
      const int g0 = 128 * lane;
      lo = L - g0 < 0 ? 0 : (L - g0 > 128 ? 128 : L - g0);
      hi = R - g0 < 0 ? 0 : (R - g0 > 128 ? 128 : R - g0);
      if (lo >= hi) lo = hi = 0;
    }
    unsigned char* dlo = span_lo(base, c, par ^ 1);
    dlo[gi + 1] = (unsigned char)lo; dlo[N + gi + 1] = (unsigned char)hi;
    if (owned && !(L < R && L <= 128 * lane && R >= 128 * lane + 128)) S.hyok = 0;
  }
  return Ops::or_all(mism);
}

}  // namespace tb
