// warp_ops.h - the warp primitives used by the v9 warp windows (bits_tb9.h).
//  * DevOps: CUDA intrinsics (__shfl_*_sync, __ballot_sync, __reduce_or_sync), full-warp mask.
//  * EmuOps (CPU emulator only, define WY_EMULATOR before including): the 32 lanes of a warp run the
//    SAME per-lane code as cooperative fibers. Every primitive stores the lane's argument and switches
//    back to a scheduler; once all 32 lanes wait at the same primitive (checked: same kind and
//    parameter, else abort), the scheduler computes the CUDA result for every lane and resumes them.
//    So the emulator executes the GPU's per-lane window code itself, not a re-implementation.
#pragma once
#include "bits_core.h"

namespace tb {
using bits::u32;

struct DevOps {
#ifdef __CUDACC__
  static __host__ __device__ __forceinline__ u32 shfl(u32 v, int src) {
#ifdef __CUDA_ARCH__
    return __shfl_sync(0xffffffffu, v, src);
#else
    (void)src; return v;
#endif
  }
  static __host__ __device__ __forceinline__ u32 shfl_up(u32 v, int d) {
#ifdef __CUDA_ARCH__
    return __shfl_up_sync(0xffffffffu, v, d);
#else
    (void)d; return v;
#endif
  }
  static __host__ __device__ __forceinline__ u32 shfl_down(u32 v, int d) {
#ifdef __CUDA_ARCH__
    return __shfl_down_sync(0xffffffffu, v, d);
#else
    (void)d; return v;
#endif
  }
  static __host__ __device__ __forceinline__ u32 ballot(bool p) {
#ifdef __CUDA_ARCH__
    return __ballot_sync(0xffffffffu, p);
#else
    return p ? 1u : 0u;
#endif
  }
  static __host__ __device__ __forceinline__ bool any(bool p) {
#ifdef __CUDA_ARCH__
    return __any_sync(0xffffffffu, p) != 0;
#else
    return p;
#endif
  }
  static __host__ __device__ __forceinline__ u32 or_all(u32 v) {
#ifdef __CUDA_ARCH__
    return __reduce_or_sync(0xffffffffu, v);
#else
    return v;
#endif
  }
#endif
};
}  // namespace tb

#ifdef WY_EMULATOR
#include <cstdio>
#include <cstdlib>
#include <vector>

namespace wyemu {
using tb::u32;
enum Op { OP_NONE = 0, OP_SHFL, OP_UP, OP_DOWN, OP_BALLOT, OP_ANY, OP_OR, OP_DONE };

struct Sched;
struct Fiber {
  void* sp = nullptr;
  Sched* sch = nullptr;
  int lane = 0;
};
struct Sched {
  void* mainSp = nullptr;
  Fiber f[32];
  std::vector<char> stacks;
  int op[32], par[32];
  u32 arg[32], res[32];
  int curLane = -1;
  void (*fn)(void*, int) = nullptr;
  void* ctx = nullptr;
  long long rounds = 0;
};
static const size_t STACK = 256 * 1024;
inline Sched& sched() { static thread_local Sched s; return s; }
}  // namespace wyemu

#if defined(__x86_64__)
extern "C" void wy_swap(void** save, void* load);
extern "C" void wy_fiber_entry(wyemu::Fiber* f);
// minimal SysV x86-64 context switch: callee-saved registers on the stack, swap stack pointers.
// (build the emulator with -fcf-protection=none: the first switch into a fiber is a crafted return.)
asm(".text\n.globl wy_swap\n.type wy_swap,@function\nwy_swap:\n"
    "  pushq %rbp\n  pushq %rbx\n  pushq %r12\n  pushq %r13\n  pushq %r14\n  pushq %r15\n"
    "  movq %rsp, (%rdi)\n  movq %rsi, %rsp\n"
    "  popq %r15\n  popq %r14\n  popq %r13\n  popq %r12\n  popq %rbx\n  popq %rbp\n  ret\n"
    ".size wy_swap,.-wy_swap\n"
    ".globl wy_tramp\n.type wy_tramp,@function\nwy_tramp:\n"
    "  movq %rbx, %rdi\n  call wy_fiber_entry\n  ud2\n"
    ".size wy_tramp,.-wy_tramp\n");
extern "C" void wy_tramp();
extern "C" void wy_fiber_entry(wyemu::Fiber* f) {
  wyemu::Sched& s = *f->sch;
  s.fn(s.ctx, f->lane);
  s.op[f->lane] = wyemu::OP_DONE;
  wy_swap(&f->sp, s.mainSp);
  abort();  // never resumed
}
#else
#error "the v9 emulator's warp fibers need x86-64"
#endif

namespace wyemu {
// lane side: publish the argument, switch to the scheduler, return the result
inline u32 prim(int op, int par, u32 v) {
  Sched& s = sched();
  const int l = s.curLane;
  s.op[l] = op; s.par[l] = par; s.arg[l] = v;
  wy_swap(&s.f[l].sp, s.mainSp);
  return s.res[l];
}
// Run fn(ctx, lane) for lanes 0..31 as one warp.
inline void runWarp(void (*fn)(void*, int), void* ctx) {
  Sched& s = sched();
  if (s.stacks.empty()) s.stacks.resize(32 * STACK);
  s.fn = fn; s.ctx = ctx;
  for (int l = 0; l < 32; ++l) {
    Fiber& f = s.f[l];
    f.sch = &s; f.lane = l;
    char* top = s.stacks.data() + (size_t)(l + 1) * STACK;
    top = (char*)((uintptr_t)top & ~(uintptr_t)15);
    void** sp = (void**)(top - 72);  // r15 r14 r13 r12 rbx rbp ret (+2 pad): wy_tramp starts 16-aligned
    for (int i = 0; i < 9; ++i) sp[i] = nullptr;
    sp[4] = &f;                 // rbx -> fiber
    sp[6] = (void*)&wy_tramp;   // return address
    f.sp = sp;
    s.op[l] = OP_NONE;
  }
  for (;;) {
    for (int l = 0; l < 32; ++l) { s.curLane = l; wy_swap(&s.mainSp, s.f[l].sp); }
    s.curLane = -1;
    ++s.rounds;
    const int op = s.op[0];
    for (int l = 1; l < 32; ++l)
      if (s.op[l] != op || ((op == OP_UP || op == OP_DOWN) && s.par[l] != s.par[0])) {
        fprintf(stderr, "wyemu: warp divergence at a primitive (lane %d op %d/%d)\n", l, s.op[l], op);
        abort();
      }
    if (op == OP_DONE) return;
    u32 r[32];
    switch (op) {
      case OP_SHFL: for (int l = 0; l < 32; ++l) r[l] = s.arg[s.par[l] & 31]; break;
      case OP_UP: for (int l = 0; l < 32; ++l) r[l] = l >= s.par[l] ? s.arg[l - s.par[l]] : s.arg[l]; break;
      case OP_DOWN: for (int l = 0; l < 32; ++l) r[l] = l + s.par[l] < 32 ? s.arg[l + s.par[l]] : s.arg[l]; break;
      case OP_BALLOT: { u32 b = 0; for (int l = 0; l < 32; ++l) b |= (s.arg[l] ? 1u : 0u) << l; for (int l = 0; l < 32; ++l) r[l] = b; } break;
      case OP_ANY: { u32 b = 0; for (int l = 0; l < 32; ++l) b |= s.arg[l] ? 1u : 0u; for (int l = 0; l < 32; ++l) r[l] = b; } break;
      case OP_OR: { u32 b = 0; for (int l = 0; l < 32; ++l) b |= s.arg[l]; for (int l = 0; l < 32; ++l) r[l] = b; } break;
      default: fprintf(stderr, "wyemu: bad op %d\n", op); abort();
    }
    for (int l = 0; l < 32; ++l) { s.res[l] = r[l]; s.op[l] = OP_NONE; }
  }
}
}  // namespace wyemu

namespace tb {
struct EmuOps {
  static u32 shfl(u32 v, int src) { return wyemu::prim(wyemu::OP_SHFL, src, v); }
  static u32 shfl_up(u32 v, int d) { return wyemu::prim(wyemu::OP_UP, d, v); }
  static u32 shfl_down(u32 v, int d) { return wyemu::prim(wyemu::OP_DOWN, d, v); }
  static u32 ballot(bool p) { return wyemu::prim(wyemu::OP_BALLOT, 0, p ? 1u : 0u); }
  static bool any(bool p) { return wyemu::prim(wyemu::OP_ANY, 0, p ? 1u : 0u) != 0; }
  static u32 or_all(u32 v) { return wyemu::prim(wyemu::OP_OR, 0, v); }
};
}  // namespace tb
#endif
