#!/usr/bin/env bash
# v10 build, gate and A/B against v9 (production: 512 threads, J=32, tile 1900) on the RTX 4050 Laptop.
#   ./bench_v10.sh build              all binaries: v10 variants, baseline v9, emulators, tools
#   ./bench_v10.sh resources          registers / stack per binary (tb_kernel) and the warp-window
#                                     step loop's local-memory instructions (must be 0)
#   ./bench_v10.sh gate               exactness gate - must pass before any timing
#   ./bench_v10.sh big64              a 2,147,483,600-digit number crosses 2^31 digits (64-bit counts)
#   ./bench_v10.sh ab FILE ITER       COPY of a production checkpoint: interleaved A/B with power
#   ./bench_v10.sh sustained FILE ITER CFG   100,000 steps each: production (v9t512:1900) vs CFG
#   ./bench_v10.sh runmode            finite run-mode check (3 chunks) + ISF + mod-9 of the result
# Configurations are ENGINE:TILE[:K] (K defaults to 128). Engines:
#   v9t512 (production v9) | v10 (512 threads, J=64, pipe balancing; the default build) | v10nopb
#   v10j32 (J=32) | v10t256 (256 threads, 2 blocks/SM) | v10t256nopb
# Largest tile per thread count (K=128): 256 -> 940, 512 -> 1900 (K=256: 932 / 1892).
# Never point FILE at the live production checkpoint: use a copy. Timing needs the GPU to itself:
# pause production (search/STOP) first and resume from latest.json afterwards.
set -euo pipefail
ARCH=${ARCH:-sm_89}
CK=checkpoint_4942464.txt; START=4942464
NV="nvcc -O3 -std=c++17 -arch=$ARCH"
EM="g++ -O3 -march=native -fopenmp -fcf-protection=none -std=c++17"
mkdir -p bench
log() { echo "$@" | tee -a bench/summary.txt; }
median() { sort -n | awk '{a[NR]=$1} END{print a[int((NR+1)/2)]}'; }
mean() { awk '{s+=$1; n++} END{if (n) printf "%.3f", s/n; else print "NA"}'; }
ref_for() {
  local f=bench/ref_$(basename $1)_$2.txt
  [ -f $f ] || { echo "building CPU reference ($2 steps)..." >&2; ./bench/ref $1 $2 $f; }
  echo $f
}
run1() {  # run1 BIN args... ; stderr -> bench/last.txt (+ appended to bench/log.txt)
  local b=$1; shift
  $b "$@" 2> bench/last.txt >/dev/null || { cat bench/last.txt; return 1; }
  cat bench/last.txt >> bench/log.txt
}
devus() { grep -oE 'device_us_per_step=[0-9.]+' bench/last.txt | tail -1 | cut -d= -f2; }
reps() { grep -oE ' replays=[0-9]+' bench/last.txt | tail -1 | cut -d= -f2; }
fpreps() { grep -oE 'fp_replays=[0-9]+' bench/last.txt | tail -1 | cut -d= -f2; }
binof() {
  case "${1%%:*}" in
    v9t512) echo bench/v9t512 ;; v10) echo ./cuda196_v10 ;; v10nopb) echo bench/v10nopb ;;
    v10j32) echo bench/v10j32 ;; v10t256) echo bench/v10t256 ;; v10t256nopb) echo bench/v10t256nopb ;;
    *) echo "unknown engine ${1%%:*}" >&2; exit 2 ;;
  esac
}
tileof() { local r=${1#*:}; echo "${r%%:*}"; }
kof() { local r=${1#*:}; [ "$r" = "${r#*:}" ] && echo 128 || echo "${r#*:}"; }
runcfg() { run1 $(binof $1) $2 $3 $4 $5 $(kof $1) --tile=$(tileof $1); }   # runcfg CFG IN STEPS OUT IT
timed() {  # timed CFG IN STEPS OUT IT -> US, W, MHZ
  local cfg=$1 in=$2 steps=$3 out=$4 it=$5
  rm -f bench/pw.csv
  nvidia-smi --query-gpu=power.draw,clocks.sm --format=csv,noheader,nounits -lms 100 > bench/pw.csv 2>/dev/null &
  local smi=$!
  runcfg $cfg $in $steps $out $it || { kill $smi 2>/dev/null || true; return 1; }
  kill $smi 2>/dev/null || true; wait $smi 2>/dev/null || true
  US=$(devus)
  W=$(awk -F', *' '$2 > 1000 {s+=$1; n++} END{if (n) printf "%.2f", s/n; else print "NA"}' bench/pw.csv)
  MHZ=$(awk -F', *' '$2 > 1000 {s+=$2; n++} END{if (n) printf "%.0f", s/n; else print "NA"}' bench/pw.csv)
}
GPU_V10="./cuda196_v10 bench/v10nopb bench/v10j32 bench/v10t256 bench/v10t256nopb"
case "${1:-}" in
build)
  $NV cuda196_v10.cu -o cuda196_v10
  $NV -DTB_PIPEBAL=0 cuda196_v10.cu -o bench/v10nopb
  $NV -DTB_J=32 cuda196_v10.cu -o bench/v10j32
  $NV -DTB_THREADS=256 cuda196_v10.cu -o bench/v10t256
  $NV -DTB_THREADS=256 -DTB_PIPEBAL=0 cuda196_v10.cu -o bench/v10t256nopb
  (cd baseline_v9 && $NV -DTB_THREADS=512 cuda196_v9.cu -o ../bench/v9t512 && $EM emu196_v9.cpp -o ../bench/emu_v9)
  $EM emu196_v10.cpp -o emu196_v10
  g++ -O2 -std=c++17 -I. tests/unit_dg.cpp -o bench/unit_dg
  gcc -O2 tools/ref.c -o bench/ref; gcc -O2 tools/gen_digits.c -o bench/gen_digits
  gcc -O2 tools/isf.c -o bench/isf; gcc -O2 tools/mod9.c -o bench/mod9
  ;;
resources)
  for b in $GPU_V10 bench/v9t512; do
    ru=$(cuobjdump --dump-resource-usage $b 2>/dev/null | grep -A1 'tb_kernel' | grep -oE 'REG:[0-9]+|STACK:[0-9]+' | tr '\n' ' ')
    sec=$(cuobjdump -sass $b | awk '/Function : .*tb_kernel/{f=1; next} /Function : /{f=0} f')
    [ -n "$sec" ] || { log "$b: tb_kernel section not found in SASS"; continue; }
    printf '%s\n' "$sec" > bench/sass_tb.txt
    lp=$(python3 tools/sass_loop.py bench/sass_tb.txt)
    log "$b: $ru STL=$(grep -c STL <<< "$sec" || true) LDL=$(grep -c LDL <<< "$sec" || true) SASS_lines=$(wc -l <<< "$sec") | $lp"
  done
  log "  (any STL/LDL outside the warp-window loop are in the v6r3 path, used by block 0 and the middle blocks)"
  ;;
gate)
  log "== CPU emulator gate (the GPU's per-lane warp-window code run as 32 cooperating fibers per warp)"
  V9EMU=bench/emu_v9 ./gate_emu.sh full > bench/gate_emu.out 2>&1 || true
  cat bench/gate_emu.txt | tee -a bench/summary.txt
  R=$(ref_for $CK 2000)
  log "== mod-9 fingerprint on the GPU: an injected bit flip must be caught and the window replayed"
  for f in 1 9; do
    V10_FAULT=$f run1 ./cuda196_v10 $CK 2000 bench/f.txt $START 128 --tile=1900 --window=512 || true
    cmp -s bench/f.txt $R && [ "$(reps)" -ge 1 ] && log "  GPU, flip after launch $f: caught (replays=$(reps), fp_replays=$(fpreps)), output == reference: PASS" \
                                              || log "  GPU, flip after launch $f: FAIL"
  done
  log "== GPU exactness"
  for f in "--mode=step" "--mode=tb" "--mode=tb --tile=4 --K=7" "--mode=tb --tile=4 --halo=4 --K=64 --window=128" \
           "--mode=tb --tile=8 --halo=4 --K=256 --window=512" "--mode=tb --tile=64 --K=1000" "--mode=tb --tile=1900" \
           "--mode=tb --tile=1892 --K=256" "--mode=tb --hybrid=0" "--mode=tb --fp=0"; do
    log "GPU exactness suite v10: $f"
    ENGINE_FLAGS="$f" python3 tests/test_exact.py ./cuda196_v10 | tail -1 | tee -a bench/summary.txt
  done
  for b in bench/v10nopb bench/v10j32 bench/v10t256 bench/v10t256nopb; do
    case $b in *t256*) T=940 ;; *) T=1900 ;; esac
    log "GPU exactness suite (default tb, forced failures, tile $T) with $b"
    ENGINE_FLAGS="--mode=tb" python3 tests/test_exact.py ./$b | tail -1 | tee -a bench/summary.txt
    ENGINE_FLAGS="--mode=tb --tile=8 --halo=4 --K=256 --window=512" python3 tests/test_exact.py ./$b | tail -1 | tee -a bench/summary.txt
    ENGINE_FLAGS="--mode=tb --tile=$T" python3 tests/test_exact.py ./$b | tail -1 | tee -a bench/summary.txt
  done
  log "GPU differential v9 (production build) vs each v10 build (random inputs with planted carry chains, random K/tile):"
  for b in $GPU_V10; do python3 tests/diff_engines.py ./bench/v9t512 ./$b 3 40 | tail -1 | tee -a bench/summary.txt; done
  log "GPU hybrid stress (incl. halo 4 and 400-pair runs), palindromes inside windows, quiet regions, growth edges:"
  for b in ./cuda196_v10 bench/v10t256; do
    python3 tests/stress_hybrid.py $b 12 | tail -1 | tee -a bench/summary.txt
    ENGINE_FLAGS=--halo=4 python3 tests/stress_hybrid.py $b 8 3 | tail -1 | tee -a bench/summary.txt
    STRESS_LONG=1 python3 tests/stress_hybrid.py $b 8 4 | tail -1 | tee -a bench/summary.txt
    python3 tests/pal_later.py $b 3 | tail -1 | tee -a bench/summary.txt
    python3 tests/quiet_bits.py $b 4 | tail -1 | tee -a bench/summary.txt
    python3 tests/test_growth_edge.py $b 40 | tail -1 | tee -a bench/summary.txt
  done
  for cfg in v10:1900 v10:1892:256 v10nopb:1900 v10j32:1900 v10t256:940 v10t256:932:256 v10t256nopb:940 v9t512:1900; do
    runcfg $cfg $CK 2000 bench/g2000.txt $START
    cmp -s bench/g2000.txt $R && log "$cfg +2000 == reference: PASS (replays=$(reps) fp_replays=$(fpreps))" || log "$cfg +2000: MISMATCH"
  done
  log "mod-9 identity on the +2000 result:"; ./bench/mod9 $CK $START $R $((START + 2000)) | tee -a bench/summary.txt
  log "weekly cross-check tool (per-step kernel reproduces a later checkpoint):"
  tools/crosscheck.sh ./cuda196_v10 $CK $START $R $((START + 2000)) | tail -1 | tee -a bench/summary.txt
  ;;
big64)
  # 64-bit digit counts: start 48 digits below 2^31 and run 250 steps (crosses 2,147,483,648 digits
  # around step 116). Needs ~6 GB RAM for the reference and ~2.2 GB GPU memory; ~2.2 GB disk per file.
  BIG=${BIGDIR:-bench/big64}; mkdir -p $BIG; S=${STEPS:-250}
  [ -f $BIG/in.txt ] || ./bench/gen_digits 2147483600 196 $BIG/in.txt
  [ -f $BIG/ref_$S.txt ] || { echo "CPU reference, $S steps on 2.1e9 digits (tens of minutes)..."; ./bench/ref $BIG/in.txt $S $BIG/ref_$S.txt; }
  for cfg in v10:1900 v10t256:940; do
    runcfg $cfg $BIG/in.txt $S $BIG/out.txt 0 || { log "big64 $cfg: FAILED TO RUN"; continue; }
    d=$(grep -oE 'digits=[0-9]+' bench/last.txt | tail -1)
    cmp -s $BIG/out.txt $BIG/ref_$S.txt && log "big64 $cfg: 2,147,483,600 -> $d after $S steps == reference: PASS (replays=$(reps))" \
                                       || log "big64 $cfg: MISMATCH vs reference"
  done
  rm -f $BIG/out.txt
  ;;
ab)
  IN=${2:?checkpoint COPY}; IT=${3:?its iteration}; STEPS=${STEPS:-5000}; ROUNDS=${ROUNDS:-3}
  CFGS=${CFGS:-"v9t512:1900 v10:1900 v10:1892:256 v10nopb:1900 v10j32:1900 v10t256:940 v10t256:932:256 v10t256nopb:940"}
  : > bench/ab.tsv
  runcfg v9t512:1900 $IN 500 bench/warm.txt $IT || true
  timed v9t512:1900 $IN $STEPS bench/ab_ref.txt $IT
  for r in $(seq 1 $ROUNDS); do
    for cfg in $CFGS; do
      timed $cfg $IN $STEPS bench/ab_out.txt $IT
      cmp -s bench/ab_out.txt bench/ab_ref.txt && ok=PASS || { ok=MISMATCH; log "$cfg round $r: OUTPUT MISMATCH vs v9t512:1900"; }
      J=$(awk -v w=$W -v u=$US 'BEGIN{ if (w == "NA") print "NA"; else printf "%.4f", w * u / 1000 }')
      printf "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n" $cfg $r $US $W $MHZ $J $(reps) $ok | tee -a bench/ab.tsv
    done
  done
  log "A/B at $(basename $IN) iteration $IT, $STEPS steps x $ROUNDS interleaved rounds (cfg: engine:tile[:K])"
  log "  cfg                median_us/step  mean_us/step  vs v9t512:1900  mean_W  mean_MHz  mean_mJ/step  replays  outputs"
  base=$(awk -F'\t' '$1=="v9t512:1900"{print $3}' bench/ab.tsv | median)
  for cfg in $CFGS; do
    md=$(awk -F'\t' -v c=$cfg '$1==c{print $3}' bench/ab.tsv | median)
    mn=$(awk -F'\t' -v c=$cfg '$1==c{print $3}' bench/ab.tsv | mean)
    w=$(awk -F'\t' -v c=$cfg '$1==c && $4!="NA"{print $4}' bench/ab.tsv | mean)
    mz=$(awk -F'\t' -v c=$cfg '$1==c && $5!="NA"{print $5}' bench/ab.tsv | mean)
    mj=$(awk -F'\t' -v c=$cfg '$1==c && $6!="NA"{print $6}' bench/ab.tsv | mean)
    rp=$(awk -F'\t' -v c=$cfg '$1==c{s+=$7} END{print s}' bench/ab.tsv)
    ok=$(awk -F'\t' -v c=$cfg '$1==c && $8!="PASS"{bad++} END{print bad ? "MISMATCH" : "all PASS"}' bench/ab.tsv)
    rel=$(awk -v b=$base -v m=$md 'BEGIN{printf "%+.2f%%", (b / m - 1) * 100}')
    log "  $(printf '%-18s %14s %13s %14s %7s %9s %13s %8s  %s' $cfg $md $mn "$rel" $w $mz $mj $rp "$ok")"
  done
  log "  ('vs v9t512:1900' = speed change, positive = faster. Replays must be 0.)"
  ;;
sustained)
  IN=${2:?checkpoint COPY}; IT=${3:?its iteration}; CFG=${4:?config, e.g. v10:1900}; STEPS=${STEPS:-100000}
  for cfg in v9t512:1900 $CFG; do
    timed $cfg $IN $STEPS bench/sus_$cfg.txt $IT
    log "sustained $STEPS steps $cfg: device_us_per_step=$US mean_W=$W mean_MHz=$MHZ replays=$(reps)"
  done
  cmp -s bench/sus_v9t512:1900.txt bench/sus_$CFG.txt && log "  outputs identical: PASS" || log "  outputs DIFFER: MISMATCH"
  ;;
runmode)
  rm -rf bench/rm && mkdir -p bench/rm && cp $CK bench/rm/
  (cd bench/rm && ../../cuda196_v10 run $CK $START run --chunk=1000 --keep=2 --steps=3000 --tile=1900 2>> ../log.txt)
  R=$(ref_for $CK 3000)
  p=$(python3 -c "import json;print(json.load(open('bench/rm/run/latest.json'))['path'])")
  cmp -s bench/rm/$p $R && log "run mode +3000 == reference: PASS" || log "run mode: MISMATCH"
  python3 - <<'EOF' | tee -a bench/summary.txt
import hashlib, json, re
j = json.load(open('bench/rm/run/latest.json'))
d = re.sub(r'[^0-9]', '', open('bench/rm/' + j['path']).read())
print('latest.json digits-only sha256:', 'PASS' if hashlib.sha256(d.encode()).hexdigest() == j['sha256'] and len(d) == j['digits'] else 'MISMATCH',
      '| engine =', j.get('engine'))
EOF
  ./bench/mod9 $CK $START bench/rm/$p $((START + 3000)) | tee -a bench/summary.txt
  ./bench/isf bench/rm/$p $((START + 3000)) bench/rm/result.isf 2>&1 | tee -a bench/summary.txt
  ;;
*) echo "usage: $0 build|resources|gate|big64|ab FILE ITER|sustained FILE ITER CFG|runmode"; exit 1 ;;
esac
