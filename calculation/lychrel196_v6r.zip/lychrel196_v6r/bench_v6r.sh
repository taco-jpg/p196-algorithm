#!/usr/bin/env bash
# v6r build, gate, A/B against v5, sweep and phase profile on the RTX 4050.
#   ./bench_v6r.sh build              build all binaries
#   ./bench_v6r.sh resources          registers / stack / local-memory instructions (tb_kernel section)
#   ./bench_v6r.sh gate               exactness gate (must pass first)
#   ./bench_v6r.sh big FILE ITER      28M COPY: v5 vs v6r, 3 interleaved runs + phase profiles
#   ./bench_v6r.sh small              2.05M checkpoint, 20,000 steps: v5 vs v6r + profiles
#   ./bench_v6r.sh sweep FILE ITER    28M COPY: v6r K x tile x build (STEPS=2000 default)
#   ./bench_v6r.sh runmode            finite run-mode check (3 chunks) against the reference
# Never point FILE at the live production checkpoint: use a copy.
set -euo pipefail
ARCH=${ARCH:-sm_89}
CK=checkpoint_4942464.txt; START=4942464
NV="nvcc -O3 -std=c++17 -arch=$ARCH"
mkdir -p bench
log() { echo "$@" | tee -a bench/summary.txt; }
median() { sort -n | awk '{a[NR]=$1} END{print a[int((NR+1)/2)]}'; }
ref_for() {
  local f=bench/ref_$(basename $1)_$2.txt
  [ -f $f ] || { echo "building CPU reference ($2 steps)..." >&2; ./bench/ref $1 $2 $f; }
  echo $f
}
run1() {  # run1 BIN args... ; stderr -> bench/last.txt (+ appended to bench/log.txt)
  local b=$1; shift
  $b "$@" 2> bench/last.txt >/dev/null || { cat bench/last.txt; return 1; }
  cat bench/last.txt >> bench/log.txt
}
hostus() { grep -oE ' us_per_step=[0-9.]+' bench/last.txt | tail -1 | cut -d= -f2; }
devus() { grep -oE 'device_us_per_step=[0-9.]+' bench/last.txt | tail -1 | cut -d= -f2; }
tilev() { grep -oE ' tile=[0-9]+' bench/last.txt | head -1 | cut -d= -f2; }
proflines() { { grep '^\[prof\]' bench/last.txt || true; } | sed 's/^/    /' | tee -a bench/summary.txt; }
BINS="./cuda196_v6r bench/v6r_p bench/v6r_p2 bench/v6r_mb1 bench/v6r_t512 bench/v5 bench/v5_p"
case "${1:-}" in
build)
  $NV cuda196_v6r.cu -o cuda196_v6r
  $NV -DTB_PROF cuda196_v6r.cu -o bench/v6r_p
  $NV -DTB_PROF -DTB_WORK_REPEAT=2 cuda196_v6r.cu -o bench/v6r_p2
  $NV -DTB_MINBLOCKS=1 cuda196_v6r.cu -o bench/v6r_mb1
  $NV -DTB_THREADS=512 cuda196_v6r.cu -o bench/v6r_t512
  (cd baseline_v5 && $NV cuda196_v5.cu -o ../bench/v5 && $NV -DTB_PROF cuda196_v5.cu -o ../bench/v5_p)
  g++ -O3 -march=native -fopenmp -std=c++17 emu196_v6r.cpp -o emu196_v6r
  (cd baseline_v5 && g++ -O3 -march=native -fopenmp -std=c++17 emu196_v5.cpp -o ../bench/emu196_v5)
  gcc -O2 tools/ref.c -o bench/ref
  ;;
resources)
  for b in $BINS; do
    ru=$(cuobjdump --dump-resource-usage $b 2>/dev/null | grep -A1 'tb_kernel' | grep -oE 'REG:[0-9]+|STACK:[0-9]+' | tr '\n' ' ')
    sec=$(cuobjdump -sass $b | awk '/Function : .*tb_kernel/{f=1; next} /Function : /{f=0} f')
    [ -n "$sec" ] || { log "$b: tb_kernel section not found in SASS"; continue; }
    log "$b: $ru STL=$(grep -c STL <<< "$sec" || true) LDL=$(grep -c LDL <<< "$sec" || true) SASS_lines=$(wc -l <<< "$sec")"
  done
  ;;
gate)
  for f in "--mode=step" "--mode=tb" "--mode=tb --tile=4 --K=7" "--mode=tb --tile=4 --halo=4 --K=64 --window=128" \
           "--mode=tb --tile=8 --halo=4 --K=256 --window=512"; do
    log "GPU exactness suite v6r: $f"
    ENGINE_FLAGS="$f" python3 tests/test_exact.py ./cuda196_v6r | tail -1 | tee -a bench/summary.txt
  done
  for b in bench/v6r_mb1 bench/v6r_t512 bench/v6r_p; do
    log "GPU exactness suite (default tb) with $b"
    ENGINE_FLAGS="--mode=tb" python3 tests/test_exact.py ./$b | tail -1 | tee -a bench/summary.txt
  done
  log "GPU differential v5 vs v6r (random large inputs, random K/tile):"
  python3 tests/diff_engines.py ./bench/v5 ./cuda196_v6r 1 100 | tail -1 | tee -a bench/summary.txt
  R=$(ref_for $CK 2000)
  for b in $BINS; do
    run1 $b $CK 2000 bench/g2000.txt $START
    cmp -s bench/g2000.txt $R && log "$b +2000 == reference: PASS" || log "$b +2000: MISMATCH"
  done
  run1 ./emu196_v6r $CK 2000 bench/e2000.txt $START
  cmp -s bench/e2000.txt $R && log "CPU emulator v6r +2000 == reference: PASS" || log "emulator +2000: MISMATCH"
  ;;
big|small)
  if [ "$1" = big ]; then IN=${2:?28M checkpoint COPY}; IT=${3:?its iteration}; STEPS=${STEPS:-2000}; K=${K:-128}; T5=${TILE5:-800}
  else IN=$CK; IT=$START; STEPS=${STEPS:-20000}; K=${K:-256}; T5=${TILE5:-0}; fi
  T6=${TILE6:-0}   # 0 = auto (v6r picks the largest tile that fits one pass)
  R=$(ref_for $IN $STEPS)
  : > bench/t5.txt; : > bench/t6.txt; : > bench/d6.txt
  run1 ./cuda196_v6r $IN 200 bench/warm.txt $IT $K --tile=$T6 || true
  for r in 1 2 3; do
    run1 bench/v5 $IN $STEPS bench/o5.txt $IT $K --tile=$T5
    cmp -s bench/o5.txt $R || { log "v5 MISMATCH vs reference"; exit 1; }
    hostus >> bench/t5.txt
    run1 ./cuda196_v6r $IN $STEPS bench/o6.txt $IT $K --tile=$T6
    cmp -s bench/o6.txt $R || { log "v6r MISMATCH vs reference"; exit 1; }
    hostus >> bench/t6.txt; devus >> bench/d6.txt; tv=$(tilev)
  done
  log "$1 ($STEPS steps, K=$K): host us/step median v5=$(median < bench/t5.txt) (tile $T5) | v6r=$(median < bench/t6.txt) (tile $tv), v6r GPU-event median $(median < bench/d6.txt) | all PASS vs reference"
  log "  (for the same-scope GPU-event comparison, run your event-instrumented v5 copy with the same arguments)"
  for b in bench/v5_p bench/v6r_p bench/v6r_p2; do
    t=$T6; [ $b = bench/v5_p ] && t=$T5
    run1 $b $IN $STEPS bench/op.txt $IT $K --tile=$t
    cmp -s bench/op.txt $R && ok=PASS || ok=MISMATCH
    log "  $b ($ok) host us/step=$(hostus)"; proflines
  done
  ;;
sweep)
  IN=${2:?28M checkpoint COPY}; IT=${3:?its iteration}; STEPS=${STEPS:-2000}; R=$(ref_for $IN $STEPS)
  for b in ./cuda196_v6r bench/v6r_mb1 bench/v6r_t512; do
    for K in 128 256 512; do
      for T in 0 544 672 736 800 960 1600; do
        run1 $b $IN $STEPS bench/o_sw.txt $IT $K --tile=$T || { log "$b K=$K tile=$T FAILED"; continue; }
        cmp -s bench/o_sw.txt $R && ok=PASS || ok=MISMATCH
        log "$b K=$K tile=$T(used $(tilev)) $ok device_us_per_step=$(devus) $(grep -oE 'replays=[0-9]+' bench/last.txt | tail -1)"
      done
    done
  done
  ;;
runmode)
  rm -rf bench/rm && mkdir -p bench/rm && cp $CK bench/rm/
  (cd bench/rm && ../../cuda196_v6r run $CK $START run --chunk=1000 --keep=2 --steps=3000 2>> ../log.txt)
  R=$(ref_for $CK 3000)
  p=$(python3 -c "import json;print(json.load(open('bench/rm/run/latest.json'))['path'])")
  cmp -s bench/rm/$p $R && log "run mode +3000 == reference: PASS" || log "run mode: MISMATCH"
  python3 - <<'EOF' | tee -a bench/summary.txt
import hashlib, json, re
j = json.load(open('bench/rm/run/latest.json'))
d = re.sub(r'[^0-9]', '', open('bench/rm/' + j['path']).read())
print('latest.json digits-only sha256:', 'PASS' if hashlib.sha256(d.encode()).hexdigest() == j['sha256'] and len(d) == j['digits'] else 'MISMATCH')
EOF
  ;;
*) echo "usage: $0 build|resources|gate|big FILE ITER|small|sweep FILE ITER|runmode"; exit 1 ;;
esac
