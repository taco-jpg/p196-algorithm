# Task for the local agent (RTX 4050): v6r (rebalanced warps)

Production stays on v5. Test v6r next to it; switch only if it passes the gate **and** is measurably
faster at 28M digits, and only with the user's go-ahead.

## Why v6r exists (from your diagnostic run)
Your phase profile at 28M (cycles per block-step) showed:

| build | block-step | warp 0 track | warp 0 work | other warps' work | other warps waiting |
|---|---:|---:|---:|---:|---:|
| v5p | 5766 | 1898 | 3588 | 4577 | 931 |
| v6sp | 7563 | 1271 | 6065 | 2213 | 5153 |

v6s really did halve the per-group arithmetic time (4577 → 2213 cycles). But warp 0 became the critical
path and the other warps waited for it more than twice as long as they worked. The cause, found in the code:
1. Prefix group 0 (word 0) never qualified for v6's fast path. Warp 0 therefore ran the out-of-line general
   path for lane 0 **and** the fast path for its other prefix lanes, one after the other (divergence),
   every step.
2. The same warp also did the certification tracking (1271 cycles), the growth-bit search, and in v5/v6
   its tile groups were mapped separately from its prefix groups (two passes).

## What v6r changes (certified results identical to v5/v6/v6s)
- Word 0 takes the fast path (word −1 is a zeroed guard; the growth case sets hi₋₁ = 1 exactly as the
  general path does). General-path groups dropped from ~0.6% to 0.12% of all groups.
- Tracking moves to warp 1 (threads 32/33, one call site). Warp 1 does nothing else.
- All other threads are workers over one list [prefix groups][tile groups], one call site, so each
  worker does one group per step and a warp mixing both kinds stays converged.
- The growth bit is found by thread 0 right after it writes prefix words 0..3. Its certification check
  (the same condition v6 used, on the same interval) moves to the prefix tracker at the start of the next
  step, so the two warps don't wait on each other. A failed check still fails the block, which still replays.
- Auto tile picks the largest tile whose groups fit one pass (≈800 words at K=128 with 256 threads;
  the 512-thread build allows larger tiles).
- Same hot-path cleanliness as v6s: with clang+ptxas here, the main kernel body has 0 local loads and no
  local stores outside the rare-call argument setup. Registers: 128 (clang); nvcc may differ.
  `./bench_v6r.sh resources` checks the real binaries (the SASS section extraction is fixed).

## Verified in the CPU emulator (same kernel code)
- Exactness suite ALL PASS in 4 configurations: tb, tiny tile (K=7), forced failures (halo 4, K=64),
  heavy forced failures (halo 4, K=256).
- Soundness checker (`EMU_CERTCHECK=1`): 0 violations across mixed runs (e.g. 19,994 certified + 4 failed;
  30 certified + 7,971 failed; 63,986 certified + 3 failed).
- Differential: v5 vs v6r 100/100 identical, v6 vs v6r 60/60 identical.
- 2.05M +2,000 == reference; run mode 3 chunks == reference, latest.json digits-only hash correct.
- **Not yet run on a GPU.**

## Expected speed — an estimate, and my last one was wrong
If the profile model holds, the block-step falls from 7563 cycles (v6s) to about the larger of one worker
group (~2.2–2.6k) and the tracker (~1.3k), plus barrier overhead. v5 is 5766. That would be roughly up to
2× faster than v5 at 28M. This rests on the same kind of reasoning that failed for v6. Only the GPU numbers count.

## Steps
1. `./bench_v6r.sh build` then `./bench_v6r.sh resources` (report REG/STACK/STL/LDL per binary).
2. `./bench_v6r.sh gate`: step + 4 tb configurations, mb1/t512/prof builds, v5-vs-v6r differential,
   every binary and the emulator vs reference at +2,000. Your persistent test harness is fine for the suite.
3. `./bench_v6r.sh big <COPY of checkpoint_68226464.txt> 68226464`: v5 (tile 800) vs v6r (auto) +
   phase profiles. **The deciding number.** Also run your event-instrumented v5 copy with the same
   arguments for the same-scope GPU-event comparison, as last time.
4. `./bench_v6r.sh small`
5. `./bench_v6r.sh sweep <COPY> 68226464`: K × tile × {default, mb1, t512}. Report the best
   `device_us_per_step`, with PASS and replays=0.
6. `./bench_v6r.sh runmode`
7. Send back `bench/summary.txt` and `bench/log.txt`.

If v6r is faster, the production switch (after the user's go-ahead) is: stop v5 with Ctrl-C (it finishes
the chunk), then
`./cuda196_v6r run <path from latest.json> <iteration from latest.json> run_v6r --chunk=1000000 --keep=3`
plus the best K/tile from step 5.

## Rules
- Never benchmark against the live production checkpoint file; use a copy.
- Every step's palindrome status is checked; certification failures replay.
- Measured numbers only.
