# 196 reverse-and-add v6r: rebalanced time-blocked kernel

```bash
nvcc -O3 -std=c++17 -arch=sm_89 cuda196_v6r.cu -o cuda196_v6r
./cuda196_v6r checkpoint_4942464.txt 20000 out.txt 4942464 256                 # benchmark (same CLI as v5/v6)
./cuda196_v6r run <checkpoint> <iteration> run_v6r --chunk=1000000 --keep=3     # long search
```

Same exact arithmetic, command line, checkpoint format and `latest.json` fields as v5/v6. v6r fixes what
the measured phase profile showed: in v6, warp 0 (prefix tile + growth bit + tracking, plus a divergent
general path for word 0) was the critical path, and the other warps waited. See AGENT_TASK.md.

| file | purpose |
|---|---|
| `cuda196_v6r.cu` | CUDA backend: v4 per-step kernel (fallback), v6r time-blocked kernel, GPU event timing |
| `emu196_v6r.cpp` | CPU emulator running the same kernel code (`EMU_CERTCHECK=1` soundness mode) |
| `bits_core.h` | v4 per-step arithmetic (GPU-validated, unchanged) |
| `bits_tb6r.h` | time-blocked arithmetic, thread roles, certification |
| `driver6r.h` | bench mode, run mode, verification windows, replay, timing |
| `prof.h` | `-DTB_PROF` phase profiler (clock64 per step phase), `-DTB_WORK_REPEAT=2` ablation |
| `bench_v6r.sh` | `build`, `resources`, `gate`, `big`, `small`, `sweep`, `runmode` |
| `tests/test_exact.py` | exactness suite (`ENGINE_FLAGS` passes options) |
| `tests/diff_engines.py` | differential test between two engines |
| `baseline_v5/` | v5 sources for A/B (profiler hooks compiled only with `-DTB_PROF`) |
| `tools/ref.c` | independent schoolbook reference |
