# Task for the local agent (RTX 4050): v6 post-mortem and bottleneck measurement

v6 was exact but not faster (28M: 54.96 vs 52.32 µs/step; 2.05M: 5.54 vs 4.04 µs/step). Production
stays on v5. This package does two things: it tests a fix for a defect found in v6, and it measures
where the time-blocked kernel actually spends its cycles. That measurement decides what v7 should be.
Nothing here is a production change.

## Defect found in v6 (explains at least part of the slowdown)
v6 passed the hot path's 6x5 word array and the `View` struct to out-of-line rare-path functions by
pointer/reference. That forced the compiler to keep them in local memory: in the SASS, every fast-path
group did ~30 local stores (STL) and several local loads (LDL), executed every time, not only on the
rare path. Your `cuobjdump` showed this as "stack 168 bytes". The author's pre-delivery check
printed the 144-byte stack frame but read only the "0 bytes spill" field. Separately, the compiler had
merged the two certification-tracking calls and was reading `View` through a local-memory pointer on
every scan step of the serial bookkeeping.

**v6s** = v6 with both fixed (arguments passed as scalars/by value, one tracking call site with register
copies). Same arithmetic. With clang+ptxas here, the main kernel body has no local-memory instructions
outside the rare-call paths (remaining STL/LDL are in out-of-line rare functions). nvcc may differ:
`./diag.sh resources` checks the real binaries.
Emulator verification: exactness suite ALL PASS in tb / tiny-tile / forced-certification-failure modes,
v6-vs-v6s differential 60/60 identical, soundness check 0 violations, 2.05M +2,000 == reference.

## Phase profile (`-DTB_PROF` builds: v5p, v6p, v6sp)
Each warp reads the SM cycle counter around the three phases of every step:
- `track` — certification bookkeeping (threads 0/1 of warp 0, serial),
- `work` — the arithmetic (warp 0 also simulates the prefix tile and computes the growth bit),
- `barrier` — waiting at the end-of-step barrier for the slowest warp.

It prints average cycles per step for warp 0 and for the other warps, total cycles per block-step, and
the SM clock measured with a spin loop (works without NVML).
`-DTB_WORK_REPEAT=2` (v5p2, v6sp2) runs the arithmetic twice per step. The repeat writes identical
values, so the output must still match the reference.

## Steps
1. `./diag.sh build` then `./diag.sh resources` — report REG/STACK and STL/LDL counts per binary.
2. `./diag.sh gate` — v6s GPU exactness suite (3 configurations), GPU differential v6 vs v6s, every
   binary vs reference at +2,000. All must PASS. (Your persistent test harness from the v6 run is fine
   for the suite, as before.)
3. `./diag.sh big <COPY of checkpoint_68226464.txt> 68226464` — timing v5 / v6 / v6s (3
   interleaved runs, all checked vs reference) plus the phase profiles. Defaults: 2,000 steps, K=128,
   tile 800 (v5) / 960 (v6, v6s); override with `K=`, `TILE5=`, `TILE6=`.
4. `./diag.sh small` — same at 2.05M digits, 20,000 steps, default K/tile.
5. `./diag.sh tiles <COPY> <iteration>` — v5 profile at tile 128/256/512/800 (latency curve).
6. Send back `bench/summary.txt` (and `bench/log.txt`).

## What the numbers will decide (for the author, no action needed)
- warp-0 `track`+`work` ≈ cycles per block-step while other warps mostly wait at the barrier →
  the serial bookkeeping is the critical path → move it off the critical path (dedicated warp,
  bit-parallel scans).
- repeat=2 nearly doubles the step time → arithmetic throughput is the limit → instruction cuts (the
  transposed-layout v7) pay off.
- repeat=2 adds little → latency-bound → the fix is more independent work per SM (state held in
  registers instead of shared memory), not fewer instructions.

## Rules
- Benchmarks only on a copy of the checkpoint, never the live file.
- If v6s passes step 2 and is faster than v5 at 28M in step 3, report it; do not switch production
  without the user's go-ahead.
- Measured numbers only.
