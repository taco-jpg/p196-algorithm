// prof.h - diagnostic instrumentation for the time-blocked kernel (only active with -DTB_PROF).
// Each warp's lane 0 reads the SM cycle counter (clock64) around the three phases of every step:
//   track   = ph_track   (certification bookkeeping, threads 0/1 of warp 0 only)
//   work    = ph_work    (the arithmetic; warp 0 also does the prefix tile and the growth bit)
//   barrier = __syncthreads_or at the end of the step (time spent waiting for the slowest warp)
// Sums are accumulated per warp index over all blocks and printed by prof_report().
// -DTB_WORK_REPEAT=2 runs ph_work twice per step (idempotent: the output stays exact). If the
// step time barely grows, the kernel is limited by latency / the serial path, not by arithmetic.
#pragma once
#include <cstdio>
#ifndef TB_WORK_REPEAT
#define TB_WORK_REPEAT 1
#endif
#define PROF_COMPILER_FENCE asm volatile("" ::: "memory")

#ifdef TB_PROF
__device__ unsigned long long g_prof[33 * 4];
#define PROF_DECL unsigned long long pT_ = 0, pW_ = 0, pB_ = 0; long long L0_ = clock64(), c0_ = 0, c1_ = 0, c2_ = 0;
#define PROF_A c0_ = clock64();
#define PROF_B c1_ = clock64();
#define PROF_C c2_ = clock64();
#define PROF_D { long long c3_ = clock64(); pT_ += c1_ - c0_; pW_ += c2_ - c1_; pB_ += c3_ - c2_; }
#define PROF_END(K)                                                                        \
  {                                                                                        \
    long long L1_ = clock64();                                                             \
    if ((threadIdx.x & 31) == 0) {                                                         \
      int w_ = threadIdx.x >> 5;                                                           \
      atomicAdd(&g_prof[w_ * 4 + 0], pT_);                                                 \
      atomicAdd(&g_prof[w_ * 4 + 1], pW_);                                                 \
      atomicAdd(&g_prof[w_ * 4 + 2], pB_);                                                 \
      atomicAdd(&g_prof[w_ * 4 + 3], (unsigned long long)(K));                            \
    }                                                                                      \
    if (threadIdx.x == 0) {                                                                \
      atomicAdd(&g_prof[32 * 4 + 0], 1ull);                                                \
      atomicAdd(&g_prof[32 * 4 + 1], (unsigned long long)(L1_ - L0_));                     \
    }                                                                                      \
  }
__global__ void prof_spin(long long cyc, long long* out) {
  long long s = clock64();
  while (clock64() - s < cyc) {}
  if (threadIdx.x == 0) *out = clock64() - s;
}
// SM clock from a spin loop timed with CUDA events (works without NVML).
static double prof_clock_mhz() {
  long long* d = nullptr;
  cudaMalloc(&d, sizeof(long long));
  cudaEvent_t a, b;
  cudaEventCreate(&a); cudaEventCreate(&b);
  const long long cyc = 400000000LL;
  prof_spin<<<1, 32>>>(cyc / 20, d);  // warm-up
  cudaDeviceSynchronize();
  cudaEventRecord(a);
  prof_spin<<<1, 32>>>(cyc, d);
  cudaEventRecord(b);
  cudaEventSynchronize(b);
  float ms = 0;
  cudaEventElapsedTime(&ms, a, b);
  cudaFree(d); cudaEventDestroy(a); cudaEventDestroy(b);
  return ms > 0 ? cyc / (ms * 1000.0) : 0;
}
static void prof_report(int threads) {
  unsigned long long h[33 * 4];
  if (cudaMemcpyFromSymbol(h, g_prof, sizeof h) != cudaSuccess) { cudaGetLastError(); return; }
  const int warps = threads / 32;
  if (!h[3]) { fprintf(stderr, "[prof] no time-blocked launches\n"); return; }
  auto per = [&](int w, int k) { return h[w * 4 + 3] ? (double)h[w * 4 + k] / h[w * 4 + 3] : 0.0; };
  double ow = 0, ob = 0, mw = 0;
  for (int w = 1; w < warps; ++w) { ow += per(w, 1); ob += per(w, 2); if (per(w, 1) > mw) mw = per(w, 1); }
  if (warps > 1) { ow /= warps - 1; ob /= warps - 1; }
  const double steps = (double)h[3];
  fprintf(stderr, "[prof] work_repeat=%d blocks_launched=%llu block_steps=%.0f cycles_per_block_step=%.0f\n",
          TB_WORK_REPEAT, h[128], steps, (double)h[129] / steps);
  fprintf(stderr, "[prof] warp0: track=%.0f work=%.0f barrier=%.0f | warps1..%d avg: work=%.0f barrier=%.0f max_work=%.0f\n",
          per(0, 0), per(0, 1), per(0, 2), warps - 1, ow, ob, mw);
  fprintf(stderr, "[prof] sm_clock_mhz=%.0f\n", prof_clock_mhz());
}
#else
#define PROF_DECL
#define PROF_A
#define PROF_B
#define PROF_C
#define PROF_D
#define PROF_END(K)
static void prof_report(int) {}
#endif
