#!/usr/bin/env bash
# Diagnostic package: where does the time-blocked kernel spend its time, and does v6s fix v6?
#   ./diag.sh build                 build all variants (+ CPU reference)
#   ./diag.sh resources             registers / stack / local-memory instructions per binary
#   ./diag.sh gate                  exactness: v6s suite on the GPU + every binary vs reference at +2000
#   ./diag.sh big FILE ITER         28M-digit COPY: timing (3 interleaved runs) + phase profile
#   ./diag.sh small                 2.05M checkpoint, 20,000 steps: timing + phase profile
#   ./diag.sh tiles FILE ITER       28M COPY: v5 phase profile vs tile size (latency curve)
# Never point FILE at the live production checkpoint: use a copy.
set -euo pipefail
ARCH=${ARCH:-sm_89}
CK=checkpoint_4942464.txt; START=4942464
mkdir -p bench
log() { echo "$@" | tee -a bench/summary.txt; }
median() { sort -n | awk '{a[NR]=$1} END{print a[int((NR+1)/2)]}'; }
ref_for() {
  local f=bench/ref_$(basename $1)_$2.txt
  [ -f $f ] || { echo "building CPU reference ($2 steps)..." >&2; ./bench/ref $1 $2 $f; }
  echo $f
}
hostus() { grep -oE ' us_per_step=[0-9.]+' bench/last.txt | tail -1 | cut -d= -f2; }
proflines() { grep '^\[prof\]' bench/last.txt | sed 's/^/    /' | tee -a bench/summary.txt; }
NV="nvcc -O3 -std=c++17 -arch=$ARCH"
# name : source dir : flags
VARIANTS="v5:v5: v5p:v5:-DTB_PROF v5p2:v5:-DTB_PROF+-DTB_WORK_REPEAT=2 v6:v6: v6p:v6:-DTB_PROF v6s:v6s: v6sp:v6s:-DTB_PROF v6sp2:v6s:-DTB_PROF+-DTB_WORK_REPEAT=2"
src_of() { case $1 in v5*) echo cuda196_v5.cu ;; *) echo cuda196_v6.cu ;; esac; }
run1() {  # run1 BIN IN STEPS OUT ITER [args...] -> stderr in bench/last.txt
  local b=$1; shift
  ./bench/$b "$@" 2> bench/last.txt >/dev/null || { cat bench/last.txt; return 1; }
  cat bench/last.txt >> bench/log.txt
}
case "${1:-}" in
build)
  for v in $VARIANTS; do
    IFS=: read -r name dir flags <<< "$v"
    echo "building $name"
    (cd $dir && $NV ${flags//+/ } $(src_of $name) -o ../bench/$name)
  done
  # v6s CPU emulator (needed by the GPU gate comparison) and the independent reference
  g++ -O3 -march=native -fopenmp -std=c++17 v6s/emu196_v6.cpp -o bench/emu196_v6s
  gcc -O2 tools/ref.c -o bench/ref
  ;;
resources)
  for v in $VARIANTS; do
    IFS=: read -r name dir flags <<< "$v"
    ru=$(cuobjdump --dump-resource-usage bench/$name 2>/dev/null | grep -A1 tb_kernel | grep -oE 'REG:[0-9]+|STACK:[0-9]+|LOCAL:[0-9]+' | tr '\n' ' ')
    sass=$(cuobjdump -sass -fun tb_kernel bench/$name 2>/dev/null || cuobjdump -sass bench/$name)
    log "$name: $ru STL=$(echo "$sass" | grep -c 'STL' || true) LDL=$(echo "$sass" | grep -c 'LDL' || true)"
  done
  ;;
gate)
  for f in "--mode=tb" "--mode=tb --tile=4 --K=7" "--mode=tb --tile=4 --halo=4 --K=64 --window=128"; do
    log "GPU exactness suite v6s: $f"
    ENGINE_FLAGS="$f" python3 tests/test_exact.py ./bench/v6s | tail -1 | tee -a bench/summary.txt
  done
  log "GPU differential v6 vs v6s:"
  python3 tests/diff_v5_v6.py ./bench/v6 ./bench/v6s 1 100 | tail -1 | tee -a bench/summary.txt
  R=$(ref_for $CK 2000)
  for v in $VARIANTS; do
    IFS=: read -r name dir flags <<< "$v"
    run1 $name $CK 2000 bench/g_$name.txt $START
    cmp -s bench/g_$name.txt $R && log "$name +2000 == reference: PASS" || log "$name +2000: MISMATCH"
  done
  ;;
big|small)
  if [ "$1" = big ]; then IN=${2:?28M checkpoint COPY}; IT=${3:?its iteration}; STEPS=${STEPS:-2000}; K=${K:-128}
  else IN=$CK; IT=$START; STEPS=${STEPS:-20000}; K=${K:-256}; fi
  R=$(ref_for $IN $STEPS)
  tile_of() { case $1 in v5*) echo ${TILE5:-800} ;; *) echo ${TILE6:-960} ;; esac; }
  [ "$1" = small ] && tile_of() { echo 0; }
  : > bench/t_v5.txt; : > bench/t_v6.txt; : > bench/t_v6s.txt
  run1 v6s $IN 200 bench/warm.txt $IT $K --tile=$(tile_of v6s) || true
  for r in 1 2 3; do
    for b in v5 v6 v6s; do
      run1 $b $IN $STEPS bench/o_$b.txt $IT $K --tile=$(tile_of $b)
      cmp -s bench/o_$b.txt $R || { log "$b MISMATCH vs reference"; exit 1; }
      hostus >> bench/t_$b.txt
    done
  done
  log "$1 ($STEPS steps, K=$K): host us/step median  v5=$(median < bench/t_v5.txt)  v6=$(median < bench/t_v6.txt)  v6s=$(median < bench/t_v6s.txt)  (all PASS vs reference)"
  for b in v5p v5p2 v6p v6sp v6sp2; do
    run1 $b $IN $STEPS bench/o_$b.txt $IT $K --tile=$(tile_of $b)
    cmp -s bench/o_$b.txt $R && ok=PASS || ok=MISMATCH
    log "  $b ($ok) us/step=$(hostus)"; proflines
  done
  ;;
tiles)
  IN=${2:?28M checkpoint COPY}; IT=${3:?its iteration}; STEPS=${STEPS:-1000}; R=$(ref_for $IN $STEPS)
  for T in 128 256 512 800; do
    for b in v5p v5p2; do
      run1 $b $IN $STEPS bench/o_t.txt $IT 128 --tile=$T
      cmp -s bench/o_t.txt $R && ok=PASS || ok=MISMATCH
      log "  $b tile=$T ($ok) us/step=$(hostus)"; proflines
    done
  done
  ;;
*) echo "usage: $0 build|resources|gate|big FILE ITER|small|tiles FILE ITER"; exit 1 ;;
esac
