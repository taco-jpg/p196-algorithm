// bits_tb6.h - time-blocked exact bit-plane engine, v6 (lean kernel).
// Shared verbatim by the CUDA kernel (cuda196_v6.cu) and the CPU emulator (emu196_v6.cpp).
// v6 vs v5 (same arithmetic, bit-identical results):
//  * every tile plane is surrounded by zeroed guard words, so the 6 words a thread-group reads
//    need no range checks (vldu); range-checked loads remain only in the rare carry scans;
//  * interior groups (not near the middle, not word 0, mismatch range all-or-nothing) take a
//    branch-free fast path with 128-bit shared-memory loads/stores and no masks;
//  * growth steps get the previous pair's high digit by a bitwise digit4 + funnel shift instead
//    of per-word scalar code.
//
// Same math as bits_core.h (v4, GPU-validated), reorganised for a block that keeps a tile of
// bit-planes in shared memory and runs K steps before writing back:
//  * step_group(): 4 consecutive words per thread; low/high carry chains flow word-to-word
//    inside the thread, so only one neighbour scan per direction per 4 words.
//  * Locality: pair j of the next state depends on pairs j-1..j+1 plus runs of pair-sum 9.
//    Each tile tracks its exactly-certified interval [L,R) (track_step). If after K steps it
//    no longer covers the pairs the block owns, the block raises `fail` and the host redoes the
//    window with the per-step v4 kernel. No approximation anywhere.
//  * Growth g_t depends only on the outermost pairs: every block also simulates a small prefix
//    tile [0, PW words) and derives g_{t+1} from it, so blocks never wait for each other.
#pragma once
#include "bits_core.h"
#if defined(TB_COUNT_PATHS) && !defined(__CUDA_ARCH__)
#include <atomic>
#endif

#if defined(__CUDA_ARCH__)
#define TB_UNROLL _Pragma("unroll")
#else
#define TB_UNROLL
#endif

namespace tb {
using bits::u32;
using bits::u64;

static const int KMAX = 1024;
#ifndef TB_THREADS
#define TB_THREADS 256
#endif
static const int THREADS = TB_THREADS;  // threads per block (CUDA launch and emulator agree)
static const int GUARD = 4;             // zeroed guard words on each side of every plane

struct View { const u32* s; int stride; int base; int len; };  // word k at s[q*stride + k-base]

BHD void vld(const View& v, int k, u32 p[5]) {
  int x = k - v.base;
  if (k < 0 || x < 0 || x >= v.len) { p[0] = p[1] = p[2] = p[3] = p[4] = 0; return; }
  TB_UNROLL
  for (int q = 0; q < 5; ++q) p[q] = v.s[q * v.stride + x];
}
// unchecked load: valid for word offsets in [-GUARD, len+GUARD) thanks to the zeroed guards
BHD void vldu(const View& v, int k, u32 p[5]) {
  const int x = k - v.base;
  TB_UNROLL
  for (int q = 0; q < 5; ++q) p[q] = v.s[q * v.stride + x];
}
BHD int is9(const View& v, int j) { u32 p[5]; vld(v, j >> 5, p); return (int)((bits::Pof(p) >> (j & 31)) & 1u); }
BHD int ge10(const View& v, int j) { u32 p[5]; vld(v, j >> 5, p); return (int)((bits::Gof(p) >> (j & 31)) & 1u); }

BHD u32 vlow_cin(const View& v, int k, const u32 prev[5]) {  // a_{32k}
  int j = k - 1;
  if (j < 0) return 0;
  int r = bits::low_summary(prev);
  while (r == 2) {
    if (--j < 0) return 0;
    u32 p[5]; vld(v, j, p);
    r = bits::low_summary(p);
  }
  return (u32)r;
}
BHD u32 vlow_bit(const View& v, int j) {  // a_j
  int k = j >> 5;
  u32 p[5], q[5];
  vld(v, k, p); vld(v, k - 1, q);
  u32 c = vlow_cin(v, k, q);
  u32 G = bits::Gof(p), X = G | bits::Pof(p);
  u64 t = (u64)X + G + c;
  return (((u32)t ^ X ^ G) >> (j & 31)) & 1u;
}
BHD u32 vmid_cin(const View& v, int n) { int h = (n + 1) / 2; return vlow_bit(v, (n % 2 == 0) ? h : h - 1); }
BHD u32 vhigh_cin(const View& v, int n, int k, const u32 next[5]) {  // b_{32k+31}
  int h = (n + 1) / 2, j = k + 1;
  if (32LL * j >= h) return vmid_cin(v, n);
  int r = bits::high_summary(next, j, h);
  while (r == 2) {
    ++j;
    if (32LL * j >= h) return vmid_cin(v, n);
    u32 p[5]; vld(v, j, p);
    r = bits::high_summary(p, j, h);
  }
  return (u32)r;
}

#ifdef __CUDA_ARCH__
#define TB_RARE __device__ __noinline__
#else
#define TB_RARE static inline
#endif
// rare continuations (a whole neighbour word of pair-sum 9s, or the middle): out of line on the GPU
// v6s: View by value and the neighbour word as five scalars, so no caller array or struct has its
// address taken (in v6 this forced a 144-168 byte local-memory stack frame into the hot path).
TB_RARE u32 rare_low_cin(View v, int k, u32 q0, u32 q1, u32 q2, u32 q3, u32 q4) {
  const u32 prev[5] = {q0, q1, q2, q3, q4};
  return vlow_cin(v, k, prev);
}
TB_RARE u32 rare_high_cin(View v, int n, int k, u32 q0, u32 q1, u32 q2, u32 q3, u32 q4) {
  const u32 next[5] = {q0, q1, q2, q3, q4};
  return vhigh_cin(v, n, k, next);
}
BHD u32 rangemask(int w, int lo, int hi) { return hi <= lo ? 0u : (bits::hmask(w, hi) & ~bits::hmask(w, lo)); }

// Words w0..w0+3 of the next state (same layout as v). Returns 1 on a palindrome mismatch
// among pairs in [mlo, mhi).
#ifdef __CUDA_ARCH__
// rare path: kept out of line so it does not raise register pressure in the fast path
__device__ __noinline__ u32 step_group_slow(View v, u32* __restrict__ d, int n, int g, int w0, int mlo, int mhi) 
#else
static inline u32 step_group_slow(View v, u32* __restrict__ d, int n, int g, int w0, int mlo, int mhi) 
#endif
{
  const int C = 4;
  const int h = (n + 1) / 2;
  u32 p[C + 2][5];
  TB_UNROLL
  for (int i = 0; i < C + 2; ++i) vldu(v, w0 - 1 + i, p[i]);
  u32 A[C], aO[C], B[C], bO[C];
  u32 cl = vlow_cin(v, w0, p[0]);
  TB_UNROLL
  for (int i = 0; i < C; ++i) {
    u32 G = bits::Gof(p[i + 1]), X = G | bits::Pof(p[i + 1]);
    u64 t = (u64)X + G + cl;
    A[i] = (u32)t ^ X ^ G; aO[i] = (u32)(t >> 32); cl = aO[i];
  }
  u32 ch = vhigh_cin(v, n, w0 + C - 1, p[C + 1]);
  TB_UNROLL
  for (int i = C - 1; i >= 0; --i) {
    const int w = w0 + i;
    u32 m = bits::hmask(w, h);
    u32 G = bits::Gof(p[i + 1]), X = G | bits::Pof(p[i + 1]);
    u32 Xr = bits::brev32(X | ~m), Gr = bits::brev32(G & m);
    u64 t = (u64)Xr + Gr + ch;
    B[i] = bits::brev32((u32)t ^ Xr ^ Gr); bO[i] = (u32)(t >> 32); ch = bO[i];
  }
  u32 mism = 0;
  TB_UNROLL
  for (int i = 0; i < C; ++i) {
    const int w = w0 + i;
    const u32* cw = p[i + 1];
    const u32 m = bits::hmask(w, h);
    const u32 a = A[i] & m, b = B[i] & m;
    const u32 aup = ((A[i] >> 1) | (aO[i] << 31)) & m;  // a_{j+1}
    const u32 bdn = ((b << 1) | bO[i]) & m;             // b_{j-1}
    u32 out[5];
    if (!g) {
      u32 t0 = a ^ b, t1 = a & b;
      u32 v0 = t0;
      u32 v1 = cw[0] ^ t1, cc = cw[0] & t1;
      u32 v2 = cw[1] ^ cc; cc &= cw[1];
      u32 v3 = cw[2] ^ cc; cc &= cw[2];
      u32 v4 = cw[3] ^ cc;
      u32 k1 = aup ^ bdn, k2 = aup & bdn;
      u32 r1 = v1 ^ k1, bo = ~v1 & k1;
      u32 dd = v2 ^ k2; u32 r2 = dd ^ bo; bo = (~v2 & k2) | (~dd & bo);
      dd = v3 ^ k1;     u32 r3 = dd ^ bo; bo = (~v3 & k1) | (~dd & bo);
      dd = v4 ^ k2;     u32 r4 = dd ^ bo;
      out[0] = v0 & m; out[1] = r1 & m; out[2] = r2 & m; out[3] = r3 & m; out[4] = r4 & m;
      mism |= ((a ^ b) & rangemask(w, mlo, mhi < h ? mhi : h)) != 0;
    } else {
      const int h1 = (n + 2) / 2;
      const u32 m1 = bits::hmask(w, h1);
      u32 lo[4], hi[4], hp[4], hs[4];
      bits::digit4(cw, a, aup, lo);
      bits::digit4(cw, b, bdn, hi);
      if (w == 0) { hp[0] = 1; hp[1] = hp[2] = hp[3] = 0; }
      else {  // high digit of pair 32w-1: S + b_{32w-1} - 10 b_{32w-2}
        int s = 0;
        TB_UNROLL
        for (int q = 0; q < 5; ++q) s |= (int)((p[i][q] >> 31) & 1u) << q;
        int bj = (int)bO[i], bj1 = (s >= 10) | ((s == 9) & bj);
        int hv = s + bj - 10 * bj1;
        if (hv < 0) hv = 0;  // only for pairs >= h (masked)
        TB_UNROLL
        for (int q = 0; q < 4; ++q) hp[q] = (u32)(hv >> q) & 1u;
      }
      TB_UNROLL
      for (int q = 0; q < 4; ++q) hs[q] = (hi[q] << 1) | hp[q];
      if (!(n & 1)) {
        int hb = h - 32 * w;
        if (hb >= 0 && hb < 32) {
          u32 bm = 1u << hb;
          TB_UNROLL
          for (int q = 0; q < 4; ++q) lo[q] = (lo[q] & ~bm) | (hs[q] & bm);
        }
      }
      const u32 rm = rangemask(w, mlo, mhi < h1 ? mhi : h1);
      u32 diff = 0, cc = 0;
      TB_UNROLL
      for (int q = 0; q < 4; ++q) {
        diff |= (lo[q] ^ hs[q]) & rm;
        u32 x = lo[q], y = hs[q];
        out[q] = (x ^ y ^ cc) & m1;
        cc = (x & y) | (cc & (x ^ y));
      }
      out[4] = cc & m1;
      mism |= diff != 0;
    }
    const int x = w - v.base;
    if (x >= 0 && x < v.len)
      TB_UNROLL
      for (int q = 0; q < 5; ++q) d[q * v.stride + x] = out[q];
  }
  return mism;
}

// Fast path. Preconditions (checked by the caller): w0 >= 1, the 4 words and the right
// neighbour word lie entirely below n-h (no masks, no middle, no centre/growMid pair), and the
// mismatch range covers all 128 pairs (countM) or none of them. Results are identical to
// step_group_slow under these conditions.
BHD u32 step_group_fast(const View& v, u32* __restrict__ d, int n, int g, int w0, bool countM) {
  const int C = 4;
  const int x0 = w0 - v.base;  // multiple of 4
  u32 p[C + 2][5];
  TB_UNROLL
  for (int q = 0; q < 5; ++q) {
    const u32* row = v.s + q * v.stride;
#ifdef __CUDA_ARCH__
    const uint4 c4 = *reinterpret_cast<const uint4*>(row + x0);
    p[1][q] = c4.x; p[2][q] = c4.y; p[3][q] = c4.z; p[4][q] = c4.w;
#else
    p[1][q] = row[x0]; p[2][q] = row[x0 + 1]; p[3][q] = row[x0 + 2]; p[4][q] = row[x0 + 3];
#endif
    p[0][q] = row[x0 - 1];
    p[5][q] = row[x0 + 4];
  }
  u32 A[C], aO[C], B[C], bO[C];
  u32 cl;
  {
    const int r = bits::low_summary(p[0]);
    cl = r == 2 ? rare_low_cin(v, w0, p[0][0], p[0][1], p[0][2], p[0][3], p[0][4]) : (u32)r;  // rare: word w0-1 is all pair-sum 9
  }
  TB_UNROLL
  for (int i = 0; i < C; ++i) {
    u32 G = bits::Gof(p[i + 1]), X = G | bits::Pof(p[i + 1]);
    u64 t = (u64)X + G + cl;
    A[i] = (u32)t ^ X ^ G; aO[i] = (u32)(t >> 32); cl = aO[i];
  }
  u32 ch;
  {
    u32 G = bits::Gof(p[C + 1]), X = G | bits::Pof(p[C + 1]);
    u64 t = (u64)bits::brev32(X) + bits::brev32(G);
    if (t >> 32) ch = 1u;
    else if ((u32)t != 0xFFFFFFFFu) ch = 0u;
    else ch = rare_high_cin(v, n, w0 + C - 1, p[C + 1][0], p[C + 1][1], p[C + 1][2], p[C + 1][3], p[C + 1][4]);  // rare: whole neighbour word is 9s
  }
  TB_UNROLL
  for (int i = C - 1; i >= 0; --i) {
    u32 G = bits::Gof(p[i + 1]), X = G | bits::Pof(p[i + 1]);
    u32 Xr = bits::brev32(X), Gr = bits::brev32(G);
    u64 t = (u64)Xr + Gr + ch;
    B[i] = bits::brev32((u32)t ^ Xr ^ Gr); bO[i] = (u32)(t >> 32); ch = bO[i];
  }
  u32 out[C][5];
  u32 diff = 0;
  if (!g) {
    TB_UNROLL
    for (int i = 0; i < C; ++i) {
      const u32* cw = p[i + 1];
      const u32 a = A[i], b = B[i];
      const u32 aup = (A[i] >> 1) | (aO[i] << 31), bdn = (b << 1) | bO[i];
      u32 t0 = a ^ b, t1 = a & b;
      u32 v1 = cw[0] ^ t1, cc = cw[0] & t1;
      u32 v2 = cw[1] ^ cc; cc &= cw[1];
      u32 v3 = cw[2] ^ cc; cc &= cw[2];
      u32 v4 = cw[3] ^ cc;
      u32 k1 = aup ^ bdn, k2 = aup & bdn;
      u32 r1 = v1 ^ k1, bo = ~v1 & k1;
      u32 dd = v2 ^ k2; u32 r2 = dd ^ bo; bo = (~v2 & k2) | (~dd & bo);
      dd = v3 ^ k1;     u32 r3 = dd ^ bo; bo = (~v3 & k1) | (~dd & bo);
      dd = v4 ^ k2;     u32 r4 = dd ^ bo;
      out[i][0] = t0; out[i][1] = r1; out[i][2] = r2; out[i][3] = r3; out[i][4] = r4;
      diff |= t0;
    }
  } else {
    // high digit of pair 32*w0-1 (bit 31 of the previous word): S + b_{32w0-1} - 10 b_{32w0-2}
    u32 hprev[4];
    {
      const u32 bv = bO[0] << 31;
      const u32 bd = bits::Gof(p[0]) | (bits::Pof(p[0]) & bv);
      bits::digit4(p[0], bv, bd, hprev);
    }
    TB_UNROLL
    for (int i = 0; i < C; ++i) {
      const u32* cw = p[i + 1];
      const u32 a = A[i], b = B[i];
      const u32 aup = (A[i] >> 1) | (aO[i] << 31), bdn = (b << 1) | bO[i];
      u32 lo[4], hi[4], hs[4];
      bits::digit4(cw, a, aup, lo);
      bits::digit4(cw, b, bdn, hi);
      TB_UNROLL
      for (int q = 0; q < 4; ++q) { hs[q] = (hi[q] << 1) | (hprev[q] >> 31); hprev[q] = hi[q]; }
      u32 cc = 0;
      TB_UNROLL
      for (int q = 0; q < 4; ++q) {
        diff |= lo[q] ^ hs[q];
        u32 x = lo[q], y = hs[q];
        out[i][q] = x ^ y ^ cc;
        cc = (x & y) | (cc & (x ^ y));
      }
      out[i][4] = cc;
    }
  }
  TB_UNROLL
  for (int q = 0; q < 5; ++q) {
    u32* row = d + q * v.stride;
#ifdef __CUDA_ARCH__
    *reinterpret_cast<uint4*>(row + x0) = make_uint4(out[0][q], out[1][q], out[2][q], out[3][q]);
#else
    row[x0] = out[0][q]; row[x0 + 1] = out[1][q]; row[x0 + 2] = out[2][q]; row[x0 + 3] = out[3][q];
#endif
  }
  return countM && diff != 0;
}

// Dispatch: fast path when its preconditions hold, otherwise the general (v5) path.
#if defined(TB_COUNT_PATHS) && !defined(__CUDA_ARCH__)
static std::atomic<long long> g_fast{0}, g_slow{0};  // test builds only: path coverage
#define TB_COUNT(x) (x)++
#else
#define TB_COUNT(x)
#endif
BHD u32 step_group(const View& v, u32* __restrict__ d, int n, int g, int w0, int mlo, int mhi) {
  const int nh = n - (n + 1) / 2;
  const long long lo = 32LL * w0, hi = 32LL * (w0 + 4);
  if (w0 >= 1 && 32LL * (w0 + 5) <= nh) {
    if (mlo <= lo && hi <= mhi) { TB_COUNT(g_fast); return step_group_fast(v, d, n, g, w0, true); }
    if (hi <= mlo || mhi <= lo || mhi <= mlo) { TB_COUNT(g_fast); return step_group_fast(v, d, n, g, w0, false); }
  }
  TB_COUNT(g_slow);
  return step_group_slow(v, d, n, g, w0, mlo, mhi);
}

// ---- certified interval tracking (pair indices) ----
struct Track { int L, R, rightReal; };

// Interval of exact values after one step from values certified on [L,R). 0 = certification lost.
BHD int track_step(const View& v, Track& tr, int n, int g) {
  const int h = (n + 1) / 2;
  if (tr.rightReal) {  // middle carry scan (from pair h-1 down) must end inside certified data
    int q = h - 1;
    while (q >= tr.L && is9(v, q)) --q;
    if (q < tr.L && tr.L > 0) return 0;
  }
  int nL, nR;
  if (tr.L == 0) nL = 0;
  else {
    int q = tr.L;
    while (q < tr.R && is9(v, q)) ++q;
    if (q >= tr.R) return 0;
    nL = q + 1;
  }
  if (tr.rightReal) nR = (n + g + 1) / 2;
  else {
    int r = tr.R - 1;
    while (r >= tr.L && is9(v, r)) --r;
    if (r < tr.L) return 0;
    nR = g ? r + 1 : r;
  }
  tr.L = nL; tr.R = nR;
  return nL < nR;
}
// Growth of the next step from a left-anchored certified tile (first non-9 pair is >= 10).
BHD int growth_cert(const View& v, const Track& tr, int n, int* g) {
  const int h = (n + 1) / 2;
  for (int w = 0; w < 4; ++w) {
    u32 p[5]; vld(v, w, p);
    u32 nn = ~bits::Pof(p) & bits::hmask(w, h);
    if (nn) {
      int b = 0;
      while (!((nn >> b) & 1u)) ++b;
      int q = 32 * w + b;
      *g = (int)((bits::Gof(p) >> b) & 1u);
      return q < tr.R;
    }
  }
  *g = 0;  // no non-9 pair among the first 128
  return (h <= 128 && tr.rightReal && tr.R >= h);
}

// ---- tile geometry ----
BHD int halo_words(int K) { return ((K + K / 4 + 64 + 31) / 32 + 3) & ~3; }
BHD int len_max(int TW, int HW, int K) { return (TW + 2 * HW + K / 64 + 16 + 3) & ~3; }
BHD int prefix_words(int HW) { return HW + 4; }
BHD int plen_max(int PW, int K) { return (PW + K / 64 + 16 + 3) & ~3; }

struct Conf { int K, TW, HW, PW, lenMax, plenMax, Wcap; };

struct State {  // per block, in shared memory
  int n0, h0, maxw;
  int o0w, o1w, bw, len, plen;
  int dead, okT, okP;
  Track tr, ptr;
  int gS[KMAX + 1];
};
// plane stride = data capacity + guards on both sides (all multiples of 4 words: 16-byte rows)
BHD int tstride(const Conf& c) { return c.lenMax + 2 * GUARD; }
BHD int pstride(const Conf& c) { return c.plenMax + 2 * GUARD; }
BHD size_t state_bytes() { return (sizeof(State) + 15) & ~(size_t)15; }
BHD size_t smem_bytes(const Conf& c) {
  return state_bytes() + sizeof(u32) * 5 * 2 * (size_t)(tstride(c) + pstride(c));
}
// pointers to word 0 of plane 0 (guards precede it)
BHD u32* tile_buf(u32* base, const Conf& c, int parity) { return base + (size_t)parity * 5 * tstride(c) + GUARD; }
BHD u32* pre_buf(u32* base, const Conf& c, int parity) {
  return base + (size_t)10 * tstride(c) + (size_t)parity * 5 * pstride(c) + GUARD;
}
BHD View tile_view(const State& S, u32* base, const Conf& c, int parity) {
  View v; v.s = tile_buf(base, c, parity); v.stride = tstride(c); v.base = S.bw; v.len = S.len; return v;
}
BHD View pre_view(const State& S, u32* base, const Conf& c, int parity) {
  View v; v.s = pre_buf(base, c, parity); v.stride = pstride(c); v.base = 0; v.len = S.plen; return v;
}

// Phase 1 (thread 0): geometry of block `blk`.
BHD void ph_setup(State& S, const Conf& c, int blk, int n0) {
  S.n0 = n0;
  S.h0 = (n0 + 1) / 2;
  S.maxw = (S.h0 + c.K / 2 + 2 + 31) / 32;  // words that can hold data after K steps
  S.o0w = blk * c.TW;
  S.o1w = S.o0w + c.TW < c.Wcap ? S.o0w + c.TW : c.Wcap;
  S.dead = S.o0w >= S.maxw;
  int bw = S.o0w - c.HW;
  S.bw = bw < 0 ? 0 : (bw & ~3);
  long long R0 = 32LL * (S.o1w + c.HW);
  if (R0 > S.h0) R0 = S.h0;
  int rightReal = (R0 == S.h0);
  int endw = S.o1w + c.HW;
  if (rightReal && S.maxw + 1 > endw) endw = S.maxw + 1;
  S.len = ((endw - S.bw + 3) & ~3) + 4;
  S.tr.L = 32 * S.bw; S.tr.R = (int)R0; S.tr.rightReal = rightReal;
  long long pR0 = 32LL * c.PW;
  if (pR0 > S.h0) pR0 = S.h0;
  int prr = (pR0 == S.h0);
  int pend = c.PW;
  if (prr && S.maxw + 1 > pend) pend = S.maxw + 1;
  S.plen = ((pend + 3) & ~3) + 4;
  S.ptr.L = 0; S.ptr.R = (int)pR0; S.ptr.rightReal = prr;
  S.okT = S.okP = 1;
}
// Phase 2 (all threads): global -> shared.
BHD void ph_load(const State& S, const Conf& c, u32* base, const u32* src, int tid, int nth) {
  const int ts = tstride(c), ps = pstride(c);
  u32* t0 = tile_buf(base, c, 0);
  for (int i = tid; i < 5 * S.len; i += nth) {
    int q = i / S.len, x = i - q * S.len, k = S.bw + x;
    t0[q * ts + x] = k < c.Wcap ? src[(size_t)q * c.Wcap + k] : 0u;
  }
  u32* p0 = pre_buf(base, c, 0);
  for (int i = tid; i < 5 * S.plen; i += nth) {
    int q = i / S.plen, x = i - q * S.plen;
    p0[q * ps + x] = x < c.Wcap ? src[(size_t)q * c.Wcap + x] : 0u;
  }
  // zero the guards (before word 0 and right after the used length) of both parities
  for (int i = tid; i < 2 * 5 * 2 * GUARD; i += nth) {
    int par = i / (5 * 2 * GUARD), r = i % (5 * 2 * GUARD), q = r / (2 * GUARD), gi = r % (2 * GUARD);
    u32* tb = tile_buf(base, c, par) + q * ts;
    u32* pb = pre_buf(base, c, par) + q * ps;
    int off = gi < GUARD ? gi - GUARD : gi - GUARD;  // -GUARD..-1 then 0..GUARD-1 (after len)
    if (gi < GUARD) { tb[off] = 0u; pb[off] = 0u; }
    else { tb[S.len + off] = 0u; pb[S.plen + off] = 0u; }
  }
}
// Phase 3 (thread 0): growth of the first step.
BHD void ph_init(State& S, const Conf& c, u32* base) {
  int g;
  if (!growth_cert(pre_view(S, base, c, 0), S.ptr, S.n0, &g)) S.okP = 0;
  S.gS[0] = g;
}
// Step t, before the barrier-free work: thread 1 tracks the tile, thread 0 the prefix.
// v6s: one call site with register copies of View/Track. In v6 the compiler merged the two calls
// and reached View through a local-memory pointer, adding local loads to every scan step of the
// serial bookkeeping. Same logic and results.
BHD void ph_track(State& S, const Conf& c, u32* base, int t, int n, int tid) {
  if (tid > 1) return;
  const bool tile = tid == 1;
  if (!(tile ? S.okT : S.okP)) return;
  const int g = S.gS[t];
  View v;
  v.s = tile ? tile_buf(base, c, t & 1) : pre_buf(base, c, t & 1);
  v.stride = tile ? tstride(c) : pstride(c);
  v.base = tile ? S.bw : 0;
  v.len = tile ? S.len : S.plen;
  Track tr = tile ? S.tr : S.ptr;
  const int ok = track_step(v, tr, n, g);
  if (tile) { S.tr = tr; S.okT = ok; } else { S.ptr = tr; S.okP = ok; }
}
// Step t work for one thread. Thread 0 also derives g_{t+1} from the prefix tile.
BHD u32 ph_work(State& S, const Conf& c, u32* base, int t, int n, int tid, int nth) {
  const int g = S.gS[t], par = t & 1;
  const int h1 = (n + g + 1) / 2;
  const int plo = 32 * S.o0w;
  long long phl = 32LL * S.o1w;
  const int phi = phl < h1 ? (int)phl : h1;
  u32 mism = 0;
  {
    View a = tile_view(S, base, c, par);
    u32* d = tile_buf(base, c, par ^ 1);
    const int ng = S.len / 4;
    for (int gi = nth - 1 - tid; gi < ng; gi += nth) mism |= step_group(a, d, n, g, S.bw + 4 * gi, plo, phi);
  }
  {
    View a = pre_view(S, base, c, par);
    u32* d = pre_buf(base, c, par ^ 1);
    const int ng = S.plen / 4;
    for (int pg = tid; pg < ng; pg += nth) step_group(a, d, n, g, 4 * pg, 0, 0);
    if (tid == 0) {  // prefix words 0..3 of the new state were written by this thread just now
      int gn;
      if (!growth_cert(pre_view(S, base, c, par ^ 1), S.ptr, n + g, &gn)) { S.okP = 0; gn = 0; }
      S.gS[t + 1] = gn;
    }
  }
  return mism;
}
// After K steps (thread 0): certification verdict for the owned pairs.
BHD int ph_verdict(const State& S, int nK) {
  const int hK = (nK + 1) / 2;
  long long phl = 32LL * S.o1w;
  const int phi = phl < hK ? (int)phl : hK;
  return S.okT && S.okP && S.tr.L <= 32 * S.o0w && S.tr.R >= phi;
}
// Owned words -> global (all threads).
BHD void ph_store(const State& S, const Conf& c, u32* base, u32* dst, int K, int tid, int nth) {
  const u32* f = tile_buf(base, c, K & 1);
  const int ts = tstride(c);
  for (int x = S.o0w + tid; x < S.o1w; x += nth)
    for (int q = 0; q < 5; ++q) dst[(size_t)q * c.Wcap + x] = f[q * ts + (x - S.bw)];
}

}  // namespace tb
