# Task for the local agent (RTX 4050): v7r

Production runs v6r2. v7r is the redesigned transposed engine (README.md has the reasoning). Its
results must be bit-identical to v6r2's.

**Production and the power-profile test come first.** If you are testing the `performance` platform
profile, finish that first: both use the GPU, and timings from either are invalid while the other runs.
Benchmarks need production paused as before (`search/STOP`, resume from `latest.json`), and the
platform profile must be the **same** for both engines in the comparison.

## What v7r changes compared with v7 (which was exact but 1.45× slower)
- **4 words per thread** instead of 8, so as many warps as v6r2. v7's profile showed half the
  warps and IPC ~0.7.
- **Halo lanes.** In each worker warp, lanes 1..30 do the work and lanes 0/31 hold the neighbouring
  chunks, so there are no divergent edge scans in every warp.
- **Tracker state in registers**, with branch-free probes.
- **Growth bit by warp vote** over 32 pairs. Replays need 32 leading pair-sum-9 pairs (v7: 8).
- **Per-thread setup once per launch.**
- Common-path SASS per useful word (clang + ptxas): **36 / 59** (no-growth / growth) vs v6r2
  **76 / 100**, at the same 4 words per thread. 128 registers, 0 spills, 0 stack (clang; `resources`
  shows your nvcc numbers).

## Verified in the CPU emulator (same kernel code)
- Exactness suite ALL PASS in step, tb, tiny tile, two forced-failure configurations and tile=64/K=1000.
  It ran on a self-check build that aborts on any growth vote differing from the full shared-memory
  search, and on any non-uniform owned-pair mask on the fast path. 128, 192, 256 and 512 threads per
  block all pass.
- Soundness checker: 0 violations in 6 mixed configurations. The certified/failed block counts are
  identical to v6r2 and v7.
- Differential: v6r2 vs v7r 120/120 identical, v5 vs v7r 100/100. A 10M-digit random number with
  planted 9-runs at 4 K/tile settings == reference.
- Growth edge cases 138/138 exact (48 replays where 32+ leading pairs sum to 9, as designed). 78/78
  under the soundness checker.
- Unit tests: transpose and its shuffle simulation, fast division, masks, and 200,000 simulated
  growth votes vs the definition.
- **Not yet run on a GPU.** The GPU-only mechanics are the shuffles, the ballots and the halo-lane
  mapping; the GPU gate checks them end to end.

## Steps
1. `./bench_v7r.sh build` then `./bench_v7r.sh resources`.
2. `./bench_v7r.sh gate`: unit tests; 6 GPU suite configurations; 3 build variants × 2 configurations;
   v6r2-vs-v7r differential (100 random); growth edge cases; every binary + emulator vs reference at
   +2,000. **All must PASS.**
3. `./bench_v7r.sh big <COPY of the newest production checkpoint> <its iteration>`: v6r2 (K=128,
   tile 736) vs v7r at the auto tile and at 736, GPU events, 3 interleaved runs, plus phase profiles
   and the SM clock. **This is the deciding number.**
4. `./bench_v7r.sh sweep <COPY> <iteration>`: report the best `device_us_per_step` (PASS, replays=0).
5. `./bench_v7r.sh small`, `./bench_v7r.sh runmode`.
6. Send back `bench/summary.txt` and `bench/log.txt`, including the `[prof]` lines from step 3.

## Deciding
- Switch production to v7r only if the gate passes completely **and** v7r is faster than v6r2 at the
  production size (median of 3, GPU events, same input, same platform profile), and only with the
  user's go-ahead. Keep the v6r2 binary for rollback.
- If v7r is not faster: keep v6r2 and report the profile lines. They say which part limits the step:
  workers, warp 0, the tracker (warp 1) or the barrier.

## Rules
- Benchmarks only on a copy of a checkpoint, never the live file.
- Every step's palindrome status is checked; certification failures replay.
- Measured numbers only.
