// bits_tb7r.h - time-blocked exact bit-plane engine, v7r: transposed tiles at v6r2's parallelism.
// Shared verbatim by the CUDA kernel (cuda196_v7r.cu) and the CPU emulator (emu196_v7r.cpp).
//
// Same arithmetic as bits_core.h (v4, GPU-validated) and v5..v7; certified results identical.
//
// Why v7r (from the measured profiles): the step time of a block is set by how much independent
// work each SM has in flight. Shared memory limits an SM to ~1,500-2,400 words, so words per
// thread decides how many warps run. v6r2 (4 words/thread): ~12 worker warps/SM at ~2.7 IPC.
// v7 (8 words/thread): ~6 warps/SM at ~0.7 IPC, 1.45x slower despite 2x fewer instructions/word.
//
//  1. TRANSPOSED TILE (as v7): word u, lane k = pair P0 + k*Wt + u; carry chains are one 3-input
//     logic op per word for 32 lanes; neighbour values are neighbouring words.
//  2. C = 4 WORDS PER THREAD (v6r2's parallelism). One 128-bit shared-memory access per plane;
//     consecutive threads hold consecutive chunks, so accesses are conflict-free without swizzle.
//  3. HALO LANES. In every worker warp, lanes 1..30 hold 30 consecutive chunks; lane 0 holds the
//     chunk before them and lane 31 the chunk after them (computed, never stored). So every useful
//     lane gets its neighbour words by warp shuffle - no divergent edge path in every warp
//     (v7 paid ~2 serial shared-memory scans per warp per step for lanes 0 and 31).
//  4. TRACKER IN REGISTERS: the two trackers (warp 1) keep their interval in registers for the
//     whole launch, issue their three probes together, and touch shared memory only for g_t.
//  5. GROWTH BY WARP VOTE: the new number's pairs 0..31 lie in prefix chunks 0..7 (warp 0, lanes
//     1..8); four ballots per kind give lane 0 all 32 pairs. 'Undetermined' (replay) now needs 32
//     leading pair-sum-9 pairs (v7: 8).
//  6. PER-THREAD WORK SETUP ONCE PER LAUNCH (WorkCtx), not every step.
// Certification (interval tracking), prefix tile, middle tile, failure replay and the palindrome
// count are unchanged in meaning.
#pragma once
#include "bits_core.h"
#if (defined(TB_COUNT_PATHS) || defined(TB_CHECK_GROWTH)) && !defined(__CUDA_ARCH__)
#include <atomic>
#include <cstdio>
#include <cstdlib>
#endif

#if defined(__CUDA_ARCH__)
#define TB_UNROLL _Pragma("unroll")
#else
#define TB_UNROLL
#endif

namespace tb {
using bits::u32;
using bits::u64;

static const int KMAX = 1024;
#ifndef TB_THREADS
#define TB_THREADS 256  // v7r default: 7 worker warps (210 useful chunk lanes) + 1 tracking warp
#endif
static const int THREADS = TB_THREADS;
static_assert(TB_THREADS >= 96 && TB_THREADS % 32 == 0, "v7r needs warp 1 for tracking plus workers");
static const int C = 4;        // words per chunk (one 128-bit access per plane)
static const int USEFUL = 30;  // useful lanes per worker warp (lanes 1..30); lanes 0, 31 are halo

#if defined(TB_COUNT_PATHS) && !defined(__CUDA_ARCH__)
static std::atomic<long long> g_fast{0}, g_mid{0}, g_trk_fast{0}, g_trk_slow{0}, g_scan_extra{0}, g_edge{0};
#define TB_COUNT(x) (x)++
#else
#define TB_COUNT(x)
#endif
#if defined(TB_CHECK_GROWTH) && !defined(__CUDA_ARCH__)
static std::atomic<long long> g_growth_checks{0}, g_growth_unknown{0};
#endif

// ---------------------------------------------------------------- small helpers
BHD u32 umulhi32(u32 a, u32 b) {
#ifdef __CUDA_ARCH__
  return __umulhi(a, b);
#else
  return (u32)(((u64)a * b) >> 32);
#endif
}
BHD int ctz32(u32 x) {
#ifdef __CUDA_ARCH__
  return __ffs(x) - 1;
#else
  return __builtin_ctz(x);
#endif
}
// ceil(2^32 / d): floor(p / d) == umulhi(p, magic) for p * d < 2^32 (here p < 32*Wt, Wt < 11585)
BHD u32 magic_for(int d) { return (u32)(0xFFFFFFFFull / (u32)d) + 1u; }
BHD u32 below(int x) { return x <= 0 ? 0u : (x >= 32 ? 0xFFFFFFFFu : ((1u << x) - 1u)); }
BHD u32 shl(u32 x, int s) { return s >= 32 ? 0u : (x << s); }
BHD u32 shr(u32 x, int s) { return s >= 32 ? 0u : (x >> s); }


// transposed view: word u of plane q at s[q*stride + u]; pairs [P0, P0 + 32*Wt)
struct TV { const u32* s; int stride, Wt, P0; u32 magic; };
BHD void tld(const TV& v, int u, u32 p[5]) {
  TB_UNROLL
  for (int q = 0; q < 5; ++q) p[q] = v.s[q * v.stride + u];
}
// pair-level lookups (absolute pair index); outside the tile the state reads as 0
BHD int t_bit(const TV& v, int pabs, bool wantG) {
  const int rel = pabs - v.P0;
  if (rel < 0 || rel >= 32 * v.Wt) return 0;
  const int k = (int)umulhi32((u32)rel, v.magic), u = rel - k * v.Wt;
  u32 p[5]; tld(v, u, p);
  return (int)(((wantG ? bits::Gof(p) : bits::Pof(p)) >> k) & 1u);
}
BHD int t_is9(const TV& v, int p) { return t_bit(v, p, false); }
BHD int t_ge10(const TV& v, int p) { return t_bit(v, p, true); }
// branch-free is9 probe (out of range -> 0): the three tracker probes issue their loads together
BHD int t_is9_bf(const TV& v, int pabs) {
  const int rel = pabs - v.P0;
  const bool ok = rel >= 0 && rel < 32 * v.Wt;
  const int r = ok ? rel : 0;
  const int k = (int)umulhi32((u32)r, v.magic), u = r - k * v.Wt;
  u32 p[5]; tld(v, u, p);
  return ok ? (int)((bits::Pof(p) >> k) & 1u) : 0;
}

// ---------------------------------------------------------------- 32x32 bit transpose
// Lane i holds row i (bit j = M[i][j]); afterwards lane j holds column j (bit i = M[i][j]).
// Five butterfly stages. The emulator runs the identical stages on an array.
#ifdef __CUDACC__
__device__ __forceinline__ u32 transpose32_lane(u32 x, int lane) {
  const u32 mk[5] = {0x0000FFFFu, 0x00FF00FFu, 0x0F0F0F0Fu, 0x33333333u, 0x55555555u};
#pragma unroll
  for (int i = 0, s = 16; i < 5; ++i, s >>= 1) {
    const u32 y = __shfl_xor_sync(0xFFFFFFFFu, x, s);
    const u32 m = mk[i];
    x = (lane & s) ? ((x & ~m) | ((y & ~m) >> s)) : ((x & m) | ((y & m) << s));
  }
  return x;
}
#endif
static inline void transpose32_array(u32 x[32]) {
  const u32 mk[5] = {0x0000FFFFu, 0x00FF00FFu, 0x0F0F0F0Fu, 0x33333333u, 0x55555555u};
  for (int i = 0, s = 16; i < 5; ++i, s >>= 1) {
    const u32 m = mk[i];
    for (int l = 0; l < 32; ++l) {
      if (l & s) continue;
      const u32 a = x[l], b = x[l ^ s];
      x[l] = (a & m) | ((b & m) << s);
      x[l ^ s] = (b & ~m) | ((a & ~m) >> s);
    }
  }
}


// ---------------------------------------------------------------- the step for one chunk
// Owned-pair ranges for palindrome counting, relative to the tile: [lo, hi)
struct Own { int qlo, rlo, qhi, rhi; };
BHD Own own_of(const TV& v, int plo_rel, int phi_rel) {
  Own o;
  if (phi_rel <= plo_rel) { o.qlo = 32; o.rlo = 0; o.qhi = 0; o.rhi = 0; return o; }  // empty
  o.qlo = (int)umulhi32((u32)plo_rel, v.magic); o.rlo = plo_rel - o.qlo * v.Wt;
  o.qhi = (int)umulhi32((u32)phi_rel, v.magic); o.rhi = phi_rel - o.qhi * v.Wt;
  return o;
}
BHD u32 own_mask(const Own& o, int u) {
  return below(o.qhi + (u < o.rhi ? 1 : 0)) & ~below(o.qlo + (u < o.rlo ? 1 : 0));
}
// Lanes whose pair at word u is below x (x relative to the tile start): mask for the middle tile
BHD u32 lanes_below(int xr, int qx, int rx, int u) { return xr <= 0 ? 0u : below(qx + (u < rx ? 1 : 0)); }


// One step for words [u0, u0+4) of tile v, written to d (same layout).
// Returns bit 0 = owned mismatch; bits 1..4 = 'pair u0+i of the new state is not 9' and bits
// 5..8 = 'pair u0+i is >= 10' for lane 0 of a tile starting at pair 0 (the prefix: growth vote).
// SH (GPU fast path): the neighbouring chunks' G/P come from lanes l-1 / l+1 by warp shuffle;
// all 32 lanes of the warp must call this together. In the emulator SH reads the same words from
// shared memory (identical values: lane l-1 holds chunk u0-4 of the same tile, lane l+1 u0+4).
// `halo` lanes (0 and 31) only supply their G/P to the neighbours: no scans, no stores.
template <bool MID, bool SH>
BHD u32 chunk_step(const TV& v, u32* __restrict__ d, int n, int g, int u0, u32 ownU, const Own& own,
                   int lane, bool act, bool halo) {
  const int Wt = v.Wt;
  int hr = 0, qh = 0, rh = 0, h1r = 0, qh1 = 0, rh1 = 0;
  u32 midc = 0;
  if (MID) {
    const int h = (n + 1) / 2, h1 = (n + g + 1) / 2;
    hr = h - v.P0; h1r = h1 - v.P0;
    if (hr > 0) { qh = (int)umulhi32((u32)hr, v.magic); rh = hr - qh * Wt; }
    if (h1r > 0) { qh1 = (int)umulhi32((u32)h1r, v.magic); rh1 = h1r - qh1 * Wt; }
    int q = ((n % 2 == 0) ? h : h - 1) - 1;  // middle carry: low carry into pair h (n even) / h-1
    while (q >= v.P0 && t_is9(v, q)) --q;
    midc = (q >= v.P0 && t_ge10(v, q)) ? 0xFFFFFFFFu : 0u;
  }
  // ---- load the chunk: one 128-bit access per plane
  u32 S[C][5];
  TB_UNROLL
  for (int q = 0; q < 5; ++q) {
    const u32* row = v.s + q * v.stride + u0;
#ifdef __CUDA_ARCH__
    const uint4 w4 = *reinterpret_cast<const uint4*>(row);
    S[0][q] = w4.x; S[1][q] = w4.y; S[2][q] = w4.z; S[3][q] = w4.w;
#else
    for (int i = 0; i < C; ++i) S[i][q] = row[i];
#endif
  }
  u32 G[C], P[C];
  TB_UNROLL
  for (int i = 0; i < C; ++i) { G[i] = bits::Gof(S[i]); P[i] = bits::Pof(S[i]); }

  // ---- low carry into word u0
  u32 Sp[5] = {0, 0, 0, 0, 0}, Gp = 0, Pp = 0;  // the word just below (growth): u0-1, or Wt-1 shifted a lane
  u32 cl = 0, unres = 0;
  int j = 0, sh = 0;
  bool lowDone = false;
  if (SH) {
    const bool lowOK = !halo && u0 >= C;  // lane-1 holds chunk u0-4 of the same tile
#ifdef __CUDA_ARCH__
    u32 nG[C], nP[C], s3[5] = {0, 0, 0, 0, 0};
    TB_UNROLL
    for (int i = 0; i < C; ++i) { nG[i] = __shfl_up_sync(0xFFFFFFFFu, G[i], 1); nP[i] = __shfl_up_sync(0xFFFFFFFFu, P[i], 1); }
    if (g) {  // block-uniform
      TB_UNROLL
      for (int q = 0; q < 5; ++q) s3[q] = __shfl_up_sync(0xFFFFFFFFu, S[C - 1][q], 1);
    }
#else
    u32 nG[C] = {0, 0, 0, 0}, nP[C] = {0, 0, 0, 0}, s3[5] = {0, 0, 0, 0, 0};
    if (lowOK) {
      for (int i = 0; i < C; ++i) { u32 r[5]; tld(v, u0 - C + i, r); nG[i] = bits::Gof(r); nP[i] = bits::Pof(r); if (i == C - 1) for (int q = 0; q < 5; ++q) s3[q] = r[q]; }
    }
#endif
    if (lowOK) {
      TB_UNROLL
      for (int q = 0; q < 5; ++q) Sp[q] = s3[q];
      Gp = nG[3]; Pp = nP[3];
      cl = nG[3] | (nP[3] & (nG[2] | (nP[2] & (nG[1] | (nP[1] & nG[0])))));
      unres = nP[3] & nP[2] & nP[1] & nP[0];
      j = u0 - C; sh = 0;
      lowDone = true;
    } else if (halo) {
      lowDone = true;  // halo lanes: nothing to compute (cl = unres = 0)
    }
  }
  if (!lowDone) {
    if (!MID && u0 >= C) {  // interior chunk (emulator path / middle block): words u0-1..u0-4
      u32 r[5];
      tld(v, u0 - 1, Sp);
      Gp = bits::Gof(Sp); Pp = bits::Pof(Sp);
      cl = Gp; unres = Pp;
      TB_UNROLL
      for (int e = 2; e <= C; ++e) { tld(v, u0 - e, r); cl |= unres & bits::Gof(r); unres &= bits::Pof(r); }
      j = u0 - C; sh = 0;
    } else {  // first chunk of a tile (or the middle block): may wrap into the lane below
      TB_COUNT(g_edge);
      j = u0 - 1; sh = 0;
      if (j < 0) { j = Wt - 1; sh = 1; }
      u32 r0[5]; tld(v, j, r0);
      TB_UNROLL
      for (int q = 0; q < 5; ++q) Sp[q] = shl(r0[q], sh);
      Gp = bits::Gof(Sp); Pp = bits::Pof(Sp);
      cl = Gp; unres = Pp;
      TB_UNROLL
      for (int e = 0; e < 3; ++e) {
        if (--j < 0) { j = Wt - 1; ++sh; }
        u32 r[5]; tld(v, j, r);
        cl |= unres & shl(bits::Gof(r), sh); unres &= shl(bits::Pof(r), sh);
      }
    }
  }
  while (unres) {  // rare: some lane still inside a run of pair-sum 9
    TB_COUNT(g_scan_extra);
    if (--j < 0) { j = Wt - 1; ++sh; }
    u32 r[5]; tld(v, j, r);
    cl |= unres & shl(bits::Gof(r), sh); unres &= shl(bits::Pof(r), sh);
  }
  u32 at[C + 1];  // at[i] = low carry into word u0+i
  at[0] = cl;
  TB_UNROLL
  for (int i = 0; i < C; ++i) at[i + 1] = G[i] | (P[i] & at[i]);

  // ---- high chain (positions >= h generate the middle carry)
  u32 Gh[C], Ph[C];
  TB_UNROLL
  for (int i = 0; i < C; ++i) {
    if (MID) {
      const u32 m = lanes_below(hr, qh, rh, u0 + i);
      Gh[i] = (G[i] & m) | (midc & ~m); Ph[i] = P[i] & m;
    } else { Gh[i] = G[i]; Ph[i] = P[i]; }
  }
  u32 ch = 0;
  unres = 0;
  bool highDone = false;
  if (SH) {
    const bool highOK = !halo && u0 + C < Wt;  // lane+1 holds chunk u0+4 of the same tile
#ifdef __CUDA_ARCH__
    u32 xG[C], xP[C];
    TB_UNROLL
    for (int i = 0; i < C; ++i) { xG[i] = __shfl_down_sync(0xFFFFFFFFu, G[i], 1); xP[i] = __shfl_down_sync(0xFFFFFFFFu, P[i], 1); }
#else
    u32 xG[C] = {0, 0, 0, 0}, xP[C] = {0, 0, 0, 0};
    if (highOK) for (int i = 0; i < C; ++i) { u32 r[5]; tld(v, u0 + C + i, r); xG[i] = bits::Gof(r); xP[i] = bits::Pof(r); }
#endif
    if (highOK) {
      ch = xG[0] | (xP[0] & (xG[1] | (xP[1] & (xG[2] | (xP[2] & xG[3])))));
      unres = xP[0] & xP[1] & xP[2] & xP[3];
      j = u0 + 2 * C - 1; sh = 0;
      highDone = true;
    } else if (halo) {
      highDone = true;
    }
  }
  if (!highDone) {
    if (!MID && u0 + 2 * C <= Wt) {  // interior chunk: words u0+4..u0+7
      u32 r[5];
      unres = 0xFFFFFFFFu;
      TB_UNROLL
      for (int e = 0; e < C; ++e) { tld(v, u0 + C + e, r); ch |= unres & bits::Gof(r); unres &= bits::Pof(r); }
      j = u0 + 2 * C - 1; sh = 0;
    } else {  // last chunk of a tile (or the middle block): may wrap into the lane above
      TB_COUNT(g_edge);
      j = u0 + C; sh = 0;
      if (j >= Wt) { j = 0; sh = 1; }
      unres = 0xFFFFFFFFu;
      TB_UNROLL
      for (int e = 0; e < 4; ++e) {
        if (e > 0 && ++j >= Wt) { j = 0; ++sh; }
        u32 r[5]; tld(v, j, r);
        u32 Gj = bits::Gof(r), Pj = bits::Pof(r);
        if (MID) { const u32 m = lanes_below(hr, qh, rh, j); Gj = (Gj & m) | (midc & ~m); Pj &= m; }
        Gj = shr(Gj, sh); Pj = shr(Pj, sh);
        if (MID) Gj |= midc & ~shr(0xFFFFFFFFu, sh);  // lanes shifted in from beyond the top: >= h
        ch |= unres & Gj; unres &= Pj;
      }
    }
  }
  while (unres) {  // rare
    TB_COUNT(g_scan_extra);
    if (++j >= Wt) { j = 0; ++sh; }
    u32 r[5]; tld(v, j, r);
    u32 Gj = bits::Gof(r), Pj = bits::Pof(r);
    if (MID) { const u32 m = lanes_below(hr, qh, rh, j); Gj = (Gj & m) | (midc & ~m); Pj &= m; }
    Gj = shr(Gj, sh); Pj = shr(Pj, sh);
    if (MID) Gj |= midc & ~shr(0xFFFFFFFFu, sh);
    ch |= unres & Gj; unres &= Pj;
  }
  u32 bt[C + 1];  // bt[i] = high carry into word u0+i-1 (bt[C]: into the chunk's top word)
  bt[C] = ch;
  TB_UNROLL
  for (int i = C - 1; i >= 0; --i) bt[i] = Gh[i] | (Ph[i] & bt[i + 1]);

  // ---- update. Owned-pair mask: one per chunk outside the middle block (owned boundaries are
  // multiples of 32 pairs relative to the tile, hence chunk boundaries); per word in the middle.
  const bool ownUniform = !MID || !((u0 < own.rlo && own.rlo < u0 + C) || (u0 < own.rhi && own.rhi < u0 + C));
  if (MID) ownU = own_mask(own, u0);
#if defined(TB_CHECK_GROWTH) && !defined(__CUDA_ARCH__)
  if (!MID && act) {
    for (int i = 0; i < C; ++i)
      if (own_mask(own, u0 + i) != ownU) { fprintf(stderr, "owned mask not uniform at u0=%d\n", u0); abort(); }
  }
#endif
  u32 diff = 0;
  u32 out[C][5];
  if (!g) {
    TB_UNROLL
    for (int i = 0; i < C; ++i) {
      const u32* cw = S[i];
      u32 a = at[i], b = bt[i + 1], aup = at[i + 1], bdn = bt[i];
      u32 m = 0xFFFFFFFFu;
      if (MID) { m = lanes_below(hr, qh, rh, u0 + i); a &= m; b &= m; aup &= m; bdn &= m; }
      const u32 t0 = a ^ b, t1 = a & b;
      const u32 v1 = cw[0] ^ t1; u32 cc = cw[0] & t1;
      const u32 v2 = cw[1] ^ cc; cc &= cw[1];
      const u32 v3 = cw[2] ^ cc; cc &= cw[2];
      const u32 v4 = cw[3] ^ cc;
      const u32 k1 = aup ^ bdn, k2 = aup & bdn;
      const u32 r1 = v1 ^ k1; u32 bo = ~v1 & k1;
      u32 dd = v2 ^ k2; const u32 r2 = dd ^ bo; bo = (~v2 & k2) | (~dd & bo);
      dd = v3 ^ k1;     const u32 r3 = dd ^ bo; bo = (~v3 & k1) | (~dd & bo);
      dd = v4 ^ k2;     const u32 r4 = dd ^ bo;
      out[i][0] = t0 & m; out[i][1] = r1 & m; out[i][2] = r2 & m; out[i][3] = r3 & m; out[i][4] = r4 & m;
      diff |= t0 & (ownUniform ? ownU : own_mask(own, u0 + i));
    }
  } else {
    u32 hprev[4];  // previous pair's high digit for word u0 (word u0-1, or word Wt-1 of the lane below)
    {
      const u32 bp = bt[0];
      bits::digit4(Sp, bp, Gp | (Pp & bp), hprev);
      if (u0 == 0 && v.P0 == 0) {  // global pair -1: the new leading digit 1
        hprev[0] = (hprev[0] & ~1u) | 1u; hprev[1] &= ~1u; hprev[2] &= ~1u; hprev[3] &= ~1u;
      }
    }
    int kc = -1, uc = -1;  // even n: centre pair h takes 2*hi_{h-1}
    if (MID && (n % 2 == 0) && hr >= 0 && hr < 32 * Wt) { kc = qh; uc = rh; }
    TB_UNROLL
    for (int i = 0; i < C; ++i) {
      const u32* cw = S[i];
      u32 a = at[i], b = bt[i + 1], aup = at[i + 1], bdn = bt[i];
      if (MID) { const u32 m = lanes_below(hr, qh, rh, u0 + i); a &= m; b &= m; aup &= m; bdn &= m; }
      u32 lo[4], hi[4];
      bits::digit4(cw, a, aup, lo);
      bits::digit4(cw, b, bdn, hi);
      u32 hs[4];
      TB_UNROLL
      for (int q = 0; q < 4; ++q) { hs[q] = hprev[q]; hprev[q] = hi[q]; }
      u32 m1 = 0xFFFFFFFFu;
      if (MID) {
        if (u0 + i == uc) {
          const u32 bm = 1u << kc;
          TB_UNROLL
          for (int q = 0; q < 4; ++q) lo[q] = (lo[q] & ~bm) | (hs[q] & bm);
        }
        m1 = lanes_below(h1r, qh1, rh1, u0 + i);
      }
      u32 dq = 0, cc = 0;
      TB_UNROLL
      for (int q = 0; q < 4; ++q) {
        const u32 x = lo[q], y = hs[q];
        dq |= x ^ y;
        out[i][q] = (x ^ y ^ cc) & m1;
        cc = (x & y) | (cc & (x ^ y));
      }
      out[i][4] = cc & m1;
      diff |= dq & (ownUniform ? ownU : own_mask(own, u0 + i));
    }
  }
  if (act) {
    TB_UNROLL
    for (int q = 0; q < 5; ++q) {
      u32* row = d + q * v.stride + u0;
#ifdef __CUDA_ARCH__
      *reinterpret_cast<uint4*>(row) = make_uint4(out[0][q], out[1][q], out[2][q], out[3][q]);
#else
      for (int i = 0; i < C; ++i) row[i] = out[i][q];
#endif
    }
  }
  u32 res = (act && diff != 0) ? 1u : 0u;
  if (v.P0 == 0 && u0 < 32) {  // growth vote material: lane-0 pairs u0..u0+3 of the new state
    TB_UNROLL
    for (int i = 0; i < C; ++i) {
      res |= (~bits::Pof(out[i]) & 1u) << (1 + i);
      res |= (bits::Gof(out[i]) & 1u) << (5 + i);
    }
  }
  return res;
}

// ---------------------------------------------------------------- growth vote
// bn[i] / bg[i]: ballots over warp 0 of 'pair u0+i is not 9' / '>= 10'; prefix chunk c (pairs
// 4c..4c+3) is in lane c+1. Returns the first non-9 pair among the first min(hn, 32) (and its
// growth bit), -1 if hn <= 32 and there is none, Q_UNKNOWN otherwise (forces a replay).
static const int Q_UNKNOWN = 0x3FFFFFFF;  // never < R: forces certification failure
BHD int growth_from_votes(const u32 bn[4], const u32 bg[4], int hn, int* g) {
  const int lim = hn < 32 ? hn : 32;
  for (int p = 0; p < lim; ++p) {
    const int lane = (p >> 2) + 1, i = p & 3;
    if ((bn[i] >> lane) & 1u) { *g = (int)((bg[i] >> lane) & 1u); return p; }
  }
  *g = 0;
  return hn <= 32 ? -1 : Q_UNKNOWN;
}

// ---------------------------------------------------------------- certified interval tracking
struct Track { int L, R, rightReal; };
// exact v5 rule (pair by pair)
BHD int track_step_exact(const TV& v, Track& tr, int n, int g) {
  const int h = (n + 1) / 2;
  if (tr.rightReal) {
    int q = h - 1;
    while (q >= tr.L && t_is9(v, q)) --q;
    if (q < tr.L && tr.L > 0) return 0;
  }
  int nL, nR;
  if (tr.L == 0) nL = 0;
  else {
    int q = tr.L;
    while (q < tr.R && t_is9(v, q)) ++q;
    if (q >= tr.R) return 0;
    nL = q + 1;
  }
  if (tr.rightReal) nR = (n + g + 1) / 2;
  else {
    int r = tr.R - 1;
    while (r >= tr.L && t_is9(v, r)) --r;
    if (r < tr.L) return 0;
    nR = g ? r + 1 : r;
  }
  tr.L = nL; tr.R = nR;
  return nL < nR;
}

// v7r fast path: the three first probes are branch-free and independent (their loads issue
// together); if none hits a 9 or an edge case the result equals the exact rule's first iteration.
BHD int track_step(const TV& v, Track& tr, int n, int g) {
  const int h = (n + 1) / 2;
  const bool useM = tr.rightReal != 0, useL = tr.L > 0, useR = tr.rightReal == 0;
  const bool edge = (useM && h - 1 < tr.L) || (useL && tr.L >= tr.R) || (useR && tr.R - 1 < tr.L);
  const int a9 = t_is9_bf(v, useM ? h - 1 : -1) | t_is9_bf(v, useL ? tr.L : -1) | t_is9_bf(v, useR ? tr.R - 1 : -1);
  if (edge || a9) { TB_COUNT(g_trk_slow); return track_step_exact(v, tr, n, g); }
  TB_COUNT(g_trk_fast);
  const int nL = useL ? tr.L + 1 : 0;
  const int nR = tr.rightReal ? (n + g + 1) / 2 : (g ? tr.R : tr.R - 1);
  tr.L = nL; tr.R = nR;
  return nL < nR;
}
// growth from a left-anchored certified tile (first non-9 pair below h is >= 10)
BHD int growth_find(const TV& v, int n, int* g) {  // first non-9 pair among the first 128 (-1: none)
  const int h = (n + 1) / 2;
  const int lim = h < 128 ? h : 128;
  for (int q = 0; q < lim; ++q)
    if (!t_is9(v, q)) { *g = t_ge10(v, q); return q; }
  *g = 0;
  return -1;
}
BHD int growth_ok(int q, const Track& tr, int n) {
  const int h = (n + 1) / 2;
  return q >= 0 ? q < tr.R : (h <= 128 && tr.rightReal && tr.R >= h);
}


// ---------------------------------------------------------------- tile geometry
BHD int round32(int x) { return (x + 31) & ~31; }
BHD int halo_words(int K) { return ((K + K / 4 + 64 + 31) / 32 + 3) & ~3; }
BHD int len_max(int TW, int HW, int K) { return round32(TW + 2 * HW + K / 64 + 16); }
BHD int prefix_words(int HW) { return HW + 4; }
BHD int plen_max(int PW, int K) { return round32(PW + K / 64 + 16); }

struct Conf { int K, TW, HW, PW, lenMax, plenMax, Wcap; };
struct State {  // per block, in shared memory
  int n0, h0, maxw;
  int o0w, o1w, bw, len, plen;
  int ssT, ssP;  // staging strides (odd: conflict-free transposes)
  u32 magT, magP;
  int dead, okT, okP;
  int gq[2];
  Track tr, ptr;
  long long clk0;                // block 0: SM clock / GPU timer at kernel start (clock report)
  unsigned long long gt0;
  int gS[KMAX + 1];
};
// plane strides: capacity + 32 words (room for the padded staging layout)
BHD int tstride(const Conf& c) { return c.lenMax + 32; }
BHD int pstride(const Conf& c) { return c.plenMax + 32; }
BHD size_t state_bytes() { return (sizeof(State) + 15) & ~(size_t)15; }
BHD size_t smem_bytes(const Conf& c) { return state_bytes() + sizeof(u32) * 5 * 2 * (size_t)(tstride(c) + pstride(c)); }
BHD u32* tile_buf(u32* base, const Conf& c, int par) { return base + (size_t)par * 5 * tstride(c); }
BHD u32* pre_buf(u32* base, const Conf& c, int par) { return base + (size_t)10 * tstride(c) + (size_t)par * 5 * pstride(c); }
BHD TV tile_view(const State& S, u32* base, const Conf& c, int par) {
  TV v; v.s = tile_buf(base, c, par); v.stride = tstride(c); v.Wt = S.len; v.P0 = 32 * S.bw; v.magic = S.magT; return v;
}
BHD TV pre_view(const State& S, u32* base, const Conf& c, int par) {
  TV v; v.s = pre_buf(base, c, par); v.stride = pstride(c); v.Wt = S.plen; v.P0 = 0; v.magic = S.magP; return v;
}
BHD int odd_stride(int L32) { return L32 | 1; }


// thread roles: warp 1 tracks (thread 32 the tile, 33 the prefix); warps 0, 2, 3, ... work
static const int TRACK_TID = 32;
BHD bool is_worker(int tid) { return tid < TRACK_TID || tid >= TRACK_TID + 32; }
BHD int num_worker_warps(int nth) { return nth / 32 - 1; }
BHD int worker_warp(int tid) { const int w = tid >> 5; return w == 0 ? 0 : w - 1; }
BHD int chunk_capacity(int nth) { return USEFUL * num_worker_warps(nth); }  // chunks per pass

// ---------------------------------------------------------------- phases
// Phase 1 (thread 0): geometry of block `blk` (same certification geometry as v5/v6).
BHD void ph_setup(State& S, const Conf& c, int blk, int n0) {
  S.n0 = n0;
  S.h0 = (n0 + 1) / 2;
  S.maxw = (S.h0 + c.K / 2 + 2 + 31) / 32;
  S.o0w = blk * c.TW;
  S.o1w = S.o0w + c.TW < c.Wcap ? S.o0w + c.TW : c.Wcap;
  S.dead = S.o0w >= S.maxw;
  int bw = S.o0w - c.HW;
  S.bw = bw < 0 ? 0 : (bw & ~3);
  long long R0 = 32LL * (S.o1w + c.HW);
  if (R0 > S.h0) R0 = S.h0;
  int rightReal = (R0 == S.h0);
  int endw = S.o1w + c.HW;
  if (rightReal && S.maxw + 1 > endw) endw = S.maxw + 1;
  S.len = round32(endw - S.bw);
  if (S.len > c.lenMax) S.len = c.lenMax;  // cannot happen with len_max(); kept as a guard
  S.tr.L = 32 * S.bw; S.tr.R = (int)R0; S.tr.rightReal = rightReal;
  long long pR0 = 32LL * c.PW;
  if (pR0 > S.h0) pR0 = S.h0;
  int prr = (pR0 == S.h0);
  int pend = c.PW;
  if (prr && S.maxw + 1 > pend) pend = S.maxw + 1;
  S.plen = round32(pend);
  if (S.plen > c.plenMax) S.plen = c.plenMax;
  S.ptr.L = 0; S.ptr.R = (int)pR0; S.ptr.rightReal = prr;
  S.ssT = odd_stride(S.len / 32); S.ssP = odd_stride(S.plen / 32);
  S.magT = magic_for(S.len); S.magP = magic_for(S.plen);
  S.okT = S.okP = 1;
}
// Phase 2a (all threads): global natural words -> staging (parity-1 buffers), relative word
// w = k*L32 + m stored at k*ss + m.
BHD void ph_load_global(const State& S, const Conf& c, u32* base, const u32* src, int tid, int nth) {
  const int ts = tstride(c), ps = pstride(c);
  u32* st = tile_buf(base, c, 1);
  const int L32 = S.len / 32;
  for (int i = tid; i < 5 * S.len; i += nth) {
    const int q = i / S.len, w = i - q * S.len, k = w / L32, m = w - k * L32, gk = S.bw + w;
    st[q * ts + k * S.ssT + m] = gk < c.Wcap ? src[(size_t)q * c.Wcap + gk] : 0u;
  }
  u32* sp = pre_buf(base, c, 1);
  const int P32 = S.plen / 32;
  for (int i = tid; i < 5 * S.plen; i += nth) {
    const int q = i / S.plen, w = i - q * S.plen, k = w / P32, m = w - k * P32;
    sp[q * ps + k * S.ssP + m] = w < c.Wcap ? src[(size_t)q * c.Wcap + w] : 0u;
  }
}
// Transposition work items: (tile|prefix, plane q, block m). Item list: tile 5*L32, prefix 5*P32.
BHD int tr_items(const State& S) { return 5 * (S.len / 32) + 5 * (S.plen / 32); }
BHD void tr_item(const State& S, const Conf& c, u32* base, int it, int par_nat, int par_tr,
                 u32** nat, int* natStride, u32** trw, int* xr) {
  const int nt = 5 * (S.len / 32);
  if (it < nt) {
    const int L32 = S.len / 32, q = it / L32, m = it - q * L32;
    *nat = tile_buf(base, c, par_nat) + q * tstride(c) + m; *natStride = S.ssT;
    *trw = tile_buf(base, c, par_tr) + q * tstride(c) + 32 * m;
    *xr = 0;  // v7r: no swizzle (identity layout)
  } else {
    const int P32 = S.plen / 32, i2 = it - nt, q = i2 / P32, m = i2 - q * P32;
    *nat = pre_buf(base, c, par_nat) + q * pstride(c) + m; *natStride = S.ssP;
    *trw = pre_buf(base, c, par_tr) + q * pstride(c) + 32 * m;
    *xr = 0;
  }
}
// Phase 2b (warp-level): staging (natural, parity 1) -> transposed (parity 0), all items.
// Phase 5a (warp-level): transposed (parity f) -> staging (natural, parity f^1), tile only.
#ifdef __CUDACC__
__device__ __forceinline__ void ph_transpose_in(const State& S, const Conf& c, u32* base, int tid, int nth) {
  const int lane = tid & 31, warp = tid >> 5, nw = nth >> 5, items = tr_items(S);
  for (int it = warp; it < items; it += nw) {
    u32 *nat, *trw; int ns, xr;
    tr_item(S, c, base, it, 1, 0, &nat, &ns, &trw, &xr);
    const u32 x = nat[lane * ns];
    trw[lane ^ xr] = transpose32_lane(x, lane);
  }
}
__device__ __forceinline__ void ph_transpose_out(const State& S, const Conf& c, u32* base, int f, int tid, int nth) {
  const int lane = tid & 31, warp = tid >> 5, nw = nth >> 5, items = 5 * (S.len / 32);
  for (int it = warp; it < items; it += nw) {
    u32 *nat, *trw; int ns, xr;
    tr_item(S, c, base, it, f ^ 1, f, &nat, &ns, &trw, &xr);
    const u32 t = trw[lane ^ xr];
    nat[lane * ns] = transpose32_lane(t, lane);
  }
}
#endif
static inline void ph_transpose_in_host(const State& S, const Conf& c, u32* base) {
  const int items = tr_items(S);
  for (int it = 0; it < items; ++it) {
    u32 *nat, *trw; int ns, xr; u32 x[32];
    tr_item(S, c, base, it, 1, 0, &nat, &ns, &trw, &xr);
    for (int l = 0; l < 32; ++l) x[l] = nat[l * ns];
    transpose32_array(x);
    for (int l = 0; l < 32; ++l) trw[l ^ xr] = x[l];
  }
}
static inline void ph_transpose_out_host(const State& S, const Conf& c, u32* base, int f) {
  const int items = 5 * (S.len / 32);
  for (int it = 0; it < items; ++it) {
    u32 *nat, *trw; int ns, xr; u32 x[32];
    tr_item(S, c, base, it, f ^ 1, f, &nat, &ns, &trw, &xr);
    for (int l = 0; l < 32; ++l) x[l] = trw[l ^ xr];
    transpose32_array(x);
    for (int l = 0; l < 32; ++l) nat[l * ns] = x[l];
  }
}

// Phase 3 (thread 0): growth of the first step (prefix tile, transposed, parity 0).
BHD void ph_init(State& S, const Conf& c, u32* base) {
  int g;
  const int q = growth_find(pre_view(S, base, c, 0), S.n0, &g);
  if (!growth_ok(q, S.ptr, S.n0)) S.okP = 0;
  S.gS[0] = g;
}

// ---------------------------------------------------------------- per-thread contexts
// Tracker context: interval and status kept in registers for the whole launch.
struct TrkCtx { int on, ok; Track tr; TV v; const u32* s0; const u32* s1; };
BHD void trk_init(const State& S, const Conf& c, u32* base, int tid, TrkCtx& k) {
  k.on = (tid == TRACK_TID || tid == TRACK_TID + 1);
  const bool tile = tid == TRACK_TID;
  k.v = tile ? tile_view(S, base, c, 0) : pre_view(S, base, c, 0);
  k.s0 = tile ? tile_buf(base, c, 0) : pre_buf(base, c, 0);
  k.s1 = tile ? tile_buf(base, c, 1) : pre_buf(base, c, 1);
  k.tr = tile ? S.tr : S.ptr;
  k.ok = tile ? S.okT : S.okP;
}
// Step t, concurrently with the work.
BHD void ph_track(const State& S, TrkCtx& k, int t, int n, int tid) {
  if (!k.on || !k.ok) return;
  const int g = S.gS[t];
  if (tid == TRACK_TID + 1 && t > 0 && !growth_ok(S.gq[t & 1], k.tr, n)) { k.ok = 0; return; }  // check g_t
  k.v.s = (t & 1) ? k.s1 : k.s0;
  k.ok = track_step(k.v, k.tr, n, g);
}
// After the K steps: publish the trackers' results for the verdict.
BHD void trk_final(State& S, const TrkCtx& k, int tid) {
  if (tid == TRACK_TID) { S.tr = k.tr; S.okT = k.ok; }
  if (tid == TRACK_TID + 1) { S.ptr = k.tr; S.okP = k.ok; }
}

// Work context for pass 0 (normally the only pass), computed once per launch.
struct WorkCtx {
  int item, u0, lane;
  bool act, halo, pre;
  TV v;                 // geometry; v.s set per step from s0/s1
  const u32* s0; const u32* s1;
  u32 ownU;
  Own own;
  int plo_rel, phi32_rel;  // owned range relative to the tile (phi before the h1 cap)
};
BHD void map_item(const State& S, int tid, int nth, int pass, int& item, bool& act, bool& halo) {
  const int lane = tid & 31, items = S.plen / C + S.len / C;
  const int i = pass * chunk_capacity(nth) + USEFUL * worker_warp(tid) + (lane - 1);
  halo = lane == 0 || lane == 31;
  act = !halo && i >= 0 && i < items;
  item = i < 0 ? 0 : (i >= items ? items - 1 : i);  // halo / idle lanes past the end: a valid duplicate
}
BHD void work_ctx(const State& S, const Conf& c, u32* base, int tid, int nth, int pass, WorkCtx& w) {
  w.lane = tid & 31;
  map_item(S, tid, nth, pass, w.item, w.act, w.halo);
  const int np = S.plen / C;
  w.pre = w.item < np;
  w.u0 = C * (w.pre ? w.item : w.item - np);
  w.v = w.pre ? pre_view(S, base, c, 0) : tile_view(S, base, c, 0);
  w.s0 = w.pre ? pre_buf(base, c, 0) : tile_buf(base, c, 0);
  w.s1 = w.pre ? pre_buf(base, c, 1) : tile_buf(base, c, 1);
  w.plo_rel = w.pre ? 0 : 32 * (S.o0w - S.bw);
  w.phi32_rel = w.pre ? 0 : 32 * (S.o1w - S.bw);
  w.own = own_of(w.v, w.plo_rel, w.phi32_rel);
  w.ownU = own_mask(w.own, w.u0);
}

// Step t work for one thread. Lanes 1..30 of worker warp ww hold chunks USEFUL*ww .. +29 (pass 0);
// lane 0 / 31 hold the chunks next to them (halo). Returns the owned-mismatch bit.
// On the GPU, warp 0 then votes the growth bit of the next step (prefix chunks 0..7 = lanes 1..8);
// the emulator does the same from shared memory in ph_growth_host.
BHD u32 ph_work(State& S, const Conf& c, u32* base, int t, int n, int tid, int nth, const WorkCtx& w0) {
  if (!is_worker(tid)) return 0;
  const int g = S.gS[t], par = t & 1;
  const int h = (n + 1) / 2, h1 = (n + g + 1) / 2;
  const bool midT = 32LL * (S.bw + S.len) > h, midP = 32LL * S.plen > h;
  const int items = S.plen / C + S.len / C, npass = (items + chunk_capacity(nth) - 1) / chunk_capacity(nth);
  u32 mism = 0, vote = 0;
  for (int pass = 0; pass < npass; ++pass) {  // block-uniform trip count (normally 1)
    WorkCtx w;
    if (pass == 0) w = w0; else work_ctx(S, c, base, tid, nth, pass, w);
    TV v = w.v;
    v.s = par ? w.s1 : w.s0;
    u32* d = (u32*)(par ? w.s0 : w.s1);
    u32 r;
    if (!midT && !midP) {
      TB_COUNT(g_fast);
      r = chunk_step<false, true>(v, d, n, g, w.u0, w.ownU, w.own, w.lane, w.act, w.halo);
    } else {  // the block holding the middle: no shuffles, per-step owned range
      const int phi_rel = w.pre ? 0 : ((h1 - v.P0) < w.phi32_rel ? (h1 - v.P0) : w.phi32_rel);
      const Own o = own_of(v, w.plo_rel, phi_rel);
      const bool mid = w.pre ? midP : midT;
      if (w.halo) r = 0;  // no neighbours needed without shuffles
      else if (mid) { TB_COUNT(g_mid); r = chunk_step<true, false>(v, d, n, g, w.u0, 0u, o, w.lane, w.act, false); }
      else { TB_COUNT(g_fast); r = chunk_step<false, false>(v, d, n, g, w.u0, own_mask(o, w.u0), o, w.lane, w.act, false); }
    }
    mism |= r & 1u;
    if (pass == 0) vote = r;
  }
#ifdef __CUDA_ARCH__
  if ((tid >> 5) == 0) {  // warp 0: growth of the next step by vote (whole warp, converged here)
    const bool mine = w0.pre && w0.act && w0.u0 < 32;
    u32 bn[4], bg[4];
#pragma unroll
    for (int i = 0; i < 4; ++i) {
      bn[i] = __ballot_sync(0xFFFFFFFFu, mine && ((vote >> (1 + i)) & 1u));
      bg[i] = __ballot_sync(0xFFFFFFFFu, mine && ((vote >> (5 + i)) & 1u));
    }
    if (tid == 0) {
      int gn;
      const int q = growth_from_votes(bn, bg, h1, &gn);
      S.gq[(t + 1) & 1] = q;
      S.gS[t + 1] = gn;
    }
  }
#else
  (void)vote;
#endif
  return mism;
}
// Emulator: the same vote, built from the new prefix words in shared memory (the values lanes
// 1..8 hold in registers on the GPU).
static inline void ph_growth_host(State& S, const Conf& c, u32* base, int t, int n) {
  const int g = S.gS[t], hn = (n + g + 1) / 2;
  const TV v = pre_view(S, base, c, (t + 1) & 1);
  u32 bn[4] = {0, 0, 0, 0}, bg[4] = {0, 0, 0, 0};
  for (int ch = 0; ch < 8; ++ch)
    for (int i = 0; i < 4; ++i) {
      u32 p[5]; tld(v, 4 * ch + i, p);
      bn[i] |= (~bits::Pof(p) & 1u) << (ch + 1);
      bg[i] |= (bits::Gof(p) & 1u) << (ch + 1);
    }
  int gn;
  const int q = growth_from_votes(bn, bg, hn, &gn);
#if defined(TB_CHECK_GROWTH)
  if (q != Q_UNKNOWN) {
    int g2;
    const int q2 = growth_find(v, n + g, &g2);
    if (q2 != q || g2 != gn) { fprintf(stderr, "growth vote mismatch t=%d q=%d/%d g=%d/%d\n", t, q, q2, gn, g2); abort(); }
    ++g_growth_checks;
  } else ++g_growth_unknown;
#endif
  S.gq[(t + 1) & 1] = q;
  S.gS[t + 1] = gn;
}
// After K steps (thread 0): certification verdict for the owned pairs.
BHD int ph_verdict(const State& S, int nK) {
  const int hK = (nK + 1) / 2;
  long long phl = 32LL * S.o1w;
  const int phi = phl < hK ? (int)phl : hK;
  return S.okT && S.okP && S.tr.L <= 32 * S.o0w && S.tr.R >= phi;
}
// Phase 5b (all threads): owned natural words (staging, parity f^1) -> global.
BHD void ph_store_global(const State& S, const Conf& c, u32* base, u32* dst, int f, int tid, int nth) {
  const u32* st = tile_buf(base, c, f ^ 1);
  const int ts = tstride(c), L32 = S.len / 32;
  const int a = S.o0w - S.bw, nwd = S.o1w - S.o0w;
  for (int i = tid; i < 5 * nwd; i += nth) {
    const int q = i / nwd, w = a + (i - q * nwd), k = w / L32, m = w - k * L32;
    dst[(size_t)q * c.Wcap + S.bw + w] = st[q * ts + k * S.ssT + m];
  }
}

}  // namespace tb

