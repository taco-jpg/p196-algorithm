# 196 reverse-and-add v7r: transposed tiles at v6r2's parallelism

```bash
nvcc -O3 -std=c++17 -arch=sm_89 cuda196_v7r.cu -o cuda196_v7r
./cuda196_v7r checkpoint_4942464.txt 20000 out.txt 4942464 256                   # benchmark (same CLI)
./cuda196_v7r run <checkpoint> <iteration> run_v7r --chunk=1000000 --keep=3      # long search
```

Same exact arithmetic, command line, checkpoint format and `latest.json` fields as v5–v7, including
`sm_clock_mhz_last_chunk`.

## Why v7 lost, and what v7r changes

Measured at 111M digits, K=128, tile 736, per SM per step:

| | words / thread | worker warps / SM | instructions / warp / step | block step | IPC while working |
|---|---:|---:|---:|---:|---:|
| v6r2 | 4 | ~12 | ~400 | 3,005 cycles | ~2.7 |
| v7 | 8 | ~6 | ~480 | 4,383 cycles | ~0.7 |

Shared memory limits each SM to about 1,500–2,400 resident words, so words per thread decides how
many warps run. v7 halved the instructions per word but also halved the warps, and its IPC collapsed.
v7r keeps v7's transposed arithmetic at v6r2's 4 words per thread:

1. **4-word chunks.** One 128-bit shared-memory access per plane; consecutive threads hold consecutive
   chunks, so these accesses are conflict-free without v7's swizzle.
2. **Halo lanes.** Lanes 1..30 of each worker warp hold 30 consecutive chunks, while lanes 0 and 31
   hold the chunks just outside them. Halo lanes compute their chunk but never store it. Every useful
   lane therefore gets its neighbour chunk's carry inputs by warp shuffle. In v7, lanes 0 and 31 of
   every warp ran a divergent shared-memory scan instead; at 4 words per thread that would have cost
   ~35%. The halo costs 2 of 32 lanes (6.7%).
3. **Tracker in registers.** The two trackers keep their interval in registers for the whole launch,
   issue their three probes together (branch-free), and read shared memory only for g_t. With the
   arithmetic halved, the tracker (1,300–1,800 cycles per step in v6r2/v7) would otherwise become the
   slowest part.
4. **Growth by warp vote.** Prefix chunks 0..7 (pairs 0..31 of the new number) sit in warp 0 lanes
   1..8. Eight ballots give lane 0 all 32 pairs. The growth bit is "undetermined" (block fails, window
   replays exactly) only if the first 32 pairs all sum to 9; in v7 it was 8.
5. **Per-thread setup once per launch** (`WorkCtx`, `TrkCtx`), not every step.

## Measured before handing over (no NVIDIA GPU here: clang + ptxas for sm_89, CPU emulator)

| commonly executed path, SASS instructions per useful word | no-growth step | growth step |
|---|---:|---:|
| v6r2 (4-word group) | 76 | 100 |
| v7 (8-word chunk) | 33 | 48 |
| **v7r (4-word chunk, incl. the 2 halo lanes)** | **36** | **59** |

- tb_kernel: 128 registers (at the cap for 2 blocks of 256 threads), 0 spills, 0 stack.
  `-DTB_MINBLOCKS=1` → 167 registers.
- **Not yet run on a GPU.** My four previous speed estimates were all too high: v6 was slower,
  v6r 1.48× vs "up to 2×", v6r2 1.10× vs "1.3–1.5×", v7 0.69× vs "1.2–1.6×". v7r restores the one
  thing v7 lost (warps per SM) while keeping ~1.9× fewer instructions per word, so it *should* beat
  v6r2. I'd guess 1.2–1.5×, and the profile will show where it stops.

## Files

| file | purpose |
|---|---|
| `cuda196_v7r.cu` | CUDA backend: v4 per-step kernel (verification/replay), v7r time-blocked kernel, SM clock |
| `emu196_v7r.cpp` | CPU emulator, same kernel code (`EMU_CERTCHECK=1` soundness; `-DTB_CHECK_GROWTH` self-checks) |
| `bits_core.h` | v4 per-step arithmetic (GPU-validated, unchanged) |
| `bits_tb7r.h` | v7r engine: transposes, chunk step, halo mapping, tracker, growth vote, phases |
| `driver7r.h` | bench mode, run mode, verification windows, replay, timing, clock report |
| `prof.h` | `-DTB_PROF` phase profiler, `-DTB_WORK_REPEAT=2` ablation |
| `bench_v7r.sh` | `build`, `resources`, `gate`, `big`, `small`, `sweep`, `runmode` |
| `tests/test_exact.py` | exactness suite (`ENGINE_FLAGS` passes options) |
| `tests/diff_engines.py` | differential test between two engines |
| `tests/test_growth_edge.py` | numbers whose next iterate starts with many pair-sum-9 pairs |
| `tests/unit_v7r.cpp` | transpose (incl. shuffle simulation), fast division, masks, growth vote (simulated ballots) |
| `math/v7_proto.py` | Python model of the transposed chunk algorithm, exact vs big integers |
| `baseline_v6r2/` | the production engine, for A/B |
| `tools/ref.c` | independent schoolbook reference |
