// cuda196_v7r.cu - exact 196 reverse-and-add, bit-sliced, time-blocked with transposed tiles at
// v6r2 parallelism (v7r), persistent run mode. Build: nvcc -O3 -std=c++17 -arch=sm_89 cuda196_v7r.cu -o cuda196_v7r
//   options: -DTB_THREADS=512 (block size, default 256), -DTB_MINBLOCKS=1|2 (register cap),
//            -DTB_PROF (phase profile), -DTB_WORK_REPEAT=2 (diagnostic ablation)
// Command line: see driver7r.h. Arithmetic: bits_core.h (v4 per-step kernel, GPU-validated, used
// for verification replays) and bits_tb7r.h (time-blocked transposed engine).
#include <cuda_runtime.h>
#include <climits>
#include "driver7r.h"
#include "prof.h"
using bits::u32;

#define CHECK(x)                                                                           \
  do {                                                                                     \
    cudaError_t e_ = (x);                                                                  \
    if (e_ != cudaSuccess) {                                                               \
      fprintf(stderr, "CUDA %s at %s:%d\n", cudaGetErrorString(e_), __FILE__, __LINE__); \
      exit(2);                                                                             \
    }                                                                                      \
  } while (0)

static constexpr int STEP_THREADS = 256;

// ---- v4 per-step kernel (unchanged logic; validated on RTX 4050) ----
__global__ void __launch_bounds__(STEP_THREADS)
step_kernel(const u32* __restrict__ src, u32* __restrict__ dst, const int* __restrict__ nIn, int* __restrict__ nOut,
            unsigned* __restrict__ bad, int slot, int Wcap) {
  const int w = blockIdx.x * blockDim.x + threadIdx.x;
  const int n = *nIn;
  unsigned mism = 0;
  int g = 0;
  if (w < Wcap && 32LL * w <= (n + 2) / 2 + 32) mism = bits::step_word(src, dst, Wcap, n, w, &g);
  if (w == 0) *nOut = n + g;
  if (__syncthreads_or((int)mism) && threadIdx.x == 0) atomicOr(bad + slot, 1u);
}

// ---- time-blocked kernel: K steps per launch, tile in shared memory ----
#ifndef TB_MINBLOCKS
#if TB_THREADS >= 512
#define TB_MINBLOCKS 1
#else
#define TB_MINBLOCKS 2  // 2 blocks/SM (shared memory allows ~2 anyway): cap 65536/(2*THREADS) registers
#endif
#endif
__global__ void __launch_bounds__(tb::THREADS, TB_MINBLOCKS)
tb_kernel(const u32* __restrict__ src, u32* __restrict__ dst, const int* __restrict__ nIn, int* __restrict__ nOut,
          unsigned* __restrict__ quiet, unsigned* __restrict__ fail, unsigned long long* __restrict__ clk,
          tb::Conf c, int K) {
  extern __shared__ __align__(16) unsigned char smem_raw[];
  tb::State& S = *reinterpret_cast<tb::State*>(smem_raw);
  u32* base = reinterpret_cast<u32*>(smem_raw + tb::state_bytes());  // 16-byte aligned rows
  const int tid = threadIdx.x;
  c.K = K;
  if (tid == 0) {
    if (blockIdx.x == 0) {  // sustained SM clock: block 0's cycles vs the GPU's ns timer
      unsigned long long g0;
      asm volatile("mov.u64 %0, %%globaltimer;" : "=l"(g0));
      S.gt0 = g0;
      S.clk0 = clock64();
    }
    tb::ph_setup(S, c, blockIdx.x, *nIn);
  }
  __syncthreads();
  if (S.dead) {  // owns only words that cannot hold data: quiet in every step
    if (tid == 0) for (int t = 0; t < K; ++t) atomicAdd(quiet + t, 1u);
    return;
  }
  tb::ph_load_global(S, c, base, src, tid, tb::THREADS);  // natural layout -> staging
  __syncthreads();
  tb::ph_transpose_in(S, c, base, tid, tb::THREADS);      // 32x32 bit transposes (warp shuffles)
  __syncthreads();
  if (tid == 0) tb::ph_init(S, c, base);
  __syncthreads();
  tb::TrkCtx trk;
  tb::WorkCtx wctx;
  tb::trk_init(S, c, base, tid, trk);  // trackers keep their interval in registers
  tb::work_ctx(S, c, base, tid, tb::THREADS, 0, wctx);
  int n = S.n0;
  PROF_DECL
  for (int t = 0; t < K; ++t) {
    PROF_A
    tb::ph_track(S, trk, t, n, tid);
    PROF_B
#if TB_WORK_REPEAT > 1
    u32 m = 0;
#pragma unroll 1
    for (int r_ = 0; r_ < TB_WORK_REPEAT; ++r_) {  // diagnostic only: idempotent repeat, one code copy
      PROF_COMPILER_FENCE;
      m |= tb::ph_work(S, c, base, t, n, tid, tb::THREADS, wctx);
    }
#else
    u32 m = tb::ph_work(S, c, base, t, n, tid, tb::THREADS, wctx);
#endif
    PROF_C
    int any = __syncthreads_or((int)m);
    PROF_D
    if (tid == 0 && !any) atomicAdd(quiet + t, 1u);
    n += S.gS[t];
  }
  PROF_END(K)
  tb::trk_final(S, trk, tid);
  __syncthreads();
  if (tid == 0 && !tb::ph_verdict(S, n)) atomicOr(fail, 1u);
  tb::ph_transpose_out(S, c, base, K & 1, tid, tb::THREADS);  // back to natural layout (staging)
  __syncthreads();
  tb::ph_store_global(S, c, base, dst, K & 1, tid, tb::THREADS);
  if (blockIdx.x == 0 && tid == 0) {
    *nOut = n;
    unsigned long long gt1;
    asm volatile("mov.u64 %0, %%globaltimer;" : "=l"(gt1));
    atomicAdd(clk + 0, (unsigned long long)(clock64() - S.clk0));
    atomicAdd(clk + 1, gt1 - S.gt0);
  }
}

// Palindrome at step t of the launch iff every block saw no mismatch.
__global__ void tb_finalize(unsigned* quiet, int K, int blocks, long long base, unsigned long long* pal) {
  for (int t = threadIdx.x; t < K; t += blockDim.x) {
    if (quiet[t] == (unsigned)blocks) atomicMin(pal, (unsigned long long)(base + t + 1));
    quiet[t] = 0;
  }
}

struct CudaBackend {
  u32 *s[2] = {nullptr, nullptr}, *bk = nullptr;
  int *dn[2] = {nullptr, nullptr}, *dnbk = nullptr;
  unsigned *dBad = nullptr, *dQuiet = nullptr, *dFail = nullptr;
  unsigned long long* dClk = nullptr;  // [0] block-0 SM cycles, [1] GPU timer ns (cumulative)
  unsigned long long hClk[2] = {0, 0};
  unsigned long long* dPal = nullptr;
  int Wcap = 0, cur = 0, batch = 0, graphBlocks = 0, bkWords = 0, dev = -1, sms = 0;
  size_t smem = 0;
  tb::Conf conf{};
  cudaStream_t st = nullptr;
  cudaGraphExec_t exec[2] = {nullptr, nullptr};
  cudaEvent_t ev0 = nullptr, ev1 = nullptr;
  bool evOpen = false;
  double devSec = 0;
  char nameBuf[320];
  double deviceSeconds() const { return devSec; }
  void smClock(double& cyc, double& ns) const { cyc = (double)hClk[0]; ns = (double)hClk[1]; }
  void evBegin() { if (!evOpen) { CHECK(cudaEventRecord(ev0, st)); evOpen = true; } }
  void evEnd() {  // call before a stream synchronize
    if (!evOpen) return;
    CHECK(cudaEventRecord(ev1, st));
    CHECK(cudaEventSynchronize(ev1));
    float ms = 0;
    CHECK(cudaEventElapsedTime(&ms, ev0, ev1));
    devSec += ms / 1000.0;
    evOpen = false;
  }

  void ensureDevice() {
    if (dev >= 0) return;
    cudaDeviceProp prop;
    CHECK(cudaGetDevice(&dev));
    CHECK(cudaGetDeviceProperties(&prop, dev));
    sms = prop.multiProcessorCount;
    snprintf(nameBuf, sizeof nameBuf, "cuda-v7r(%.200s, %d SMs)", prop.name, sms);
    CHECK(cudaFuncSetAttribute(tb_kernel, cudaFuncAttributeMaxDynamicSharedMemorySize, (int)prop.sharedMemPerBlockOptin));
  }
  const char* name() { ensureDevice(); return nameBuf; }
  int numSMs() { ensureDevice(); return sms; }
  int tbBlocksPerSM(size_t bytes) {
    ensureDevice();
    int nb = 0;
    if (cudaOccupancyMaxActiveBlocksPerMultiprocessor(&nb, tb_kernel, tb::THREADS, bytes) != cudaSuccess) {
      cudaGetLastError();
      return 0;
    }
    return nb;
  }
  void enqueueSteps(int count, int from, int blocks) {
    CHECK(cudaMemsetAsync(dBad, 0, sizeof(unsigned) * count, st));
    for (int i = 0; i < count; ++i) {
      int a = (from + i) & 1;
      step_kernel<<<blocks, STEP_THREADS, 0, st>>>(s[a], s[1 - a], dn[a], dn[1 - a], dBad, i, Wcap);
    }
  }
  void captureGraphs(int blocks) {
    for (int from = 0; from < 2; ++from) {
      if (exec[from]) CHECK(cudaGraphExecDestroy(exec[from]));
      cudaGraph_t gph;
      CHECK(cudaStreamBeginCapture(st, cudaStreamCaptureModeGlobal));
      enqueueSteps(batch, from, blocks);
      CHECK(cudaStreamEndCapture(st, &gph));
      CHECK(cudaGraphInstantiate(&exec[from], gph, 0));
      CHECK(cudaGraphDestroy(gph));
    }
    graphBlocks = blocks;
  }
  void init(const std::vector<u32>& pl, int n0, int W, const tb::Conf& c, int b) {
    ensureDevice();
    Wcap = W; conf = c; batch = b;
    smem = tb::smem_bytes(c);
    const size_t bytes = sizeof(u32) * 5 * (size_t)W;
    for (int i = 0; i < 2; ++i) {
      CHECK(cudaMalloc(&s[i], bytes)); CHECK(cudaMemset(s[i], 0, bytes));
      CHECK(cudaMalloc(&dn[i], sizeof(int)));
    }
    CHECK(cudaMalloc(&bk, bytes)); CHECK(cudaMalloc(&dnbk, sizeof(int)));
    CHECK(cudaMalloc(&dBad, sizeof(unsigned) * std::max(b, 1)));
    CHECK(cudaMalloc(&dQuiet, sizeof(unsigned) * tb::KMAX)); CHECK(cudaMemset(dQuiet, 0, sizeof(unsigned) * tb::KMAX));
    CHECK(cudaMalloc(&dFail, sizeof(unsigned))); CHECK(cudaMemset(dFail, 0, sizeof(unsigned)));
    CHECK(cudaMalloc(&dClk, 2 * sizeof(unsigned long long))); CHECK(cudaMemset(dClk, 0, 2 * sizeof(unsigned long long)));
    CHECK(cudaMalloc(&dPal, sizeof(unsigned long long))); CHECK(cudaMemset(dPal, 0xFF, sizeof(unsigned long long)));
    CHECK(cudaMemcpy(s[0], pl.data(), bytes, cudaMemcpyHostToDevice));
    CHECK(cudaMemcpy(dn[0], &n0, sizeof(int), cudaMemcpyHostToDevice));
    CHECK(cudaStreamCreate(&st));
    CHECK(cudaEventCreate(&ev0));
    CHECK(cudaEventCreate(&ev1));
    cur = 0;
    if (tbBlocksPerSM(smem) < 1)
      throw std::runtime_error("tile does not fit in shared memory; lower --tile or --K");
  }
  void stepRun(int count, std::vector<unsigned>& bad, int gridWords) {
    int blocks = (gridWords + STEP_THREADS - 1) / STEP_THREADS;
    if (count == batch && blocks > graphBlocks) captureGraphs(blocks + 8);  // capture outside the timed region
    evBegin();
    if (count == batch) {
      CHECK(cudaGraphLaunch(exec[cur], st));
    } else {
      enqueueSteps(count, cur, blocks);
    }
    evEnd();
    bad.assign(count, 0);
    CHECK(cudaMemcpyAsync(bad.data(), dBad, sizeof(unsigned) * count, cudaMemcpyDeviceToHost, st));
    CHECK(cudaStreamSynchronize(st));
    CHECK(cudaGetLastError());
    cur = (cur + count) & 1;
  }
  void tbLaunch(int k, long long baseIter, int blocks) {
    evBegin();
    tb_kernel<<<blocks, tb::THREADS, smem, st>>>(s[cur], s[1 - cur], dn[cur], dn[1 - cur], dQuiet, dFail, dClk, conf, k);
    tb_finalize<<<1, 256, 0, st>>>(dQuiet, k, blocks, baseIter, dPal);
    cur ^= 1;
  }
  d5::TBResult tbSync() {
    evEnd();
    unsigned f = 0; unsigned long long p = 0; int n = 0;
    CHECK(cudaMemcpyAsync(&f, dFail, sizeof f, cudaMemcpyDeviceToHost, st));
    CHECK(cudaMemcpyAsync(&p, dPal, sizeof p, cudaMemcpyDeviceToHost, st));
    CHECK(cudaMemcpyAsync(&n, dn[cur], sizeof n, cudaMemcpyDeviceToHost, st));
    CHECK(cudaMemcpyAsync(hClk, dClk, sizeof hClk, cudaMemcpyDeviceToHost, st));
    CHECK(cudaMemsetAsync(dFail, 0, sizeof(unsigned), st));
    CHECK(cudaMemsetAsync(dPal, 0xFF, sizeof(unsigned long long), st));
    CHECK(cudaStreamSynchronize(st));
    CHECK(cudaGetLastError());
    return d5::TBResult{(int)f, p == ULLONG_MAX ? -1LL : (long long)p, n};
  }
  int currentN() {
    int n;
    CHECK(cudaMemcpyAsync(&n, dn[cur], sizeof n, cudaMemcpyDeviceToHost, st));
    CHECK(cudaStreamSynchronize(st));
    return n;
  }
  void backup(int words) {
    bkWords = std::min(words, Wcap);
    for (int q = 0; q < 5; ++q)
      CHECK(cudaMemcpyAsync(bk + (size_t)q * Wcap, s[cur] + (size_t)q * Wcap, sizeof(u32) * bkWords, cudaMemcpyDeviceToDevice, st));
    CHECK(cudaMemcpyAsync(dnbk, dn[cur], sizeof(int), cudaMemcpyDeviceToDevice, st));
  }
  void restore() {  // rare path: also wipe everything above the restored number
    for (int q = 0; q < 5; ++q) {
      CHECK(cudaMemcpyAsync(s[cur] + (size_t)q * Wcap, bk + (size_t)q * Wcap, sizeof(u32) * bkWords, cudaMemcpyDeviceToDevice, st));
      CHECK(cudaMemsetAsync(s[cur] + (size_t)q * Wcap + bkWords, 0, sizeof(u32) * (Wcap - bkWords), st));
    }
    CHECK(cudaMemsetAsync(s[1 - cur], 0, sizeof(u32) * 5 * (size_t)Wcap, st));
    CHECK(cudaMemcpyAsync(dn[cur], dnbk, sizeof(int), cudaMemcpyDeviceToDevice, st));
    CHECK(cudaStreamSynchronize(st));
  }
  void download(bool previous, std::vector<u32>& pl, int& stride, int& n) {
    int k = previous ? 1 - cur : cur;
    CHECK(cudaMemcpy(&n, dn[k], sizeof(int), cudaMemcpyDeviceToHost));
    stride = std::min(Wcap, (n + 1) / 2 / 32 + 2);
    pl.assign(5 * (size_t)stride, 0);
    for (int q = 0; q < 5; ++q)
      CHECK(cudaMemcpy(pl.data() + (size_t)q * stride, s[k] + (size_t)q * Wcap, sizeof(u32) * stride, cudaMemcpyDeviceToHost));
  }
  ~CudaBackend() {
    if (dev >= 0) prof_report(tb::THREADS);
    for (int i = 0; i < 2; ++i) { if (exec[i]) cudaGraphExecDestroy(exec[i]); cudaFree(s[i]); cudaFree(dn[i]); }
    cudaFree(bk); cudaFree(dnbk); cudaFree(dBad); cudaFree(dQuiet); cudaFree(dFail); cudaFree(dPal); cudaFree(dClk);
    if (ev0) cudaEventDestroy(ev0);
    if (ev1) cudaEventDestroy(ev1);
    if (st) cudaStreamDestroy(st);
  }
};

int main(int argc, char** argv) {
  try {
    CudaBackend be;
    return d5::mainEntry(be, argc, argv);
  } catch (const std::exception& e) {
    fprintf(stderr, "ERROR %s\n", e.what());
    return 2;
  }
}
