#!/usr/bin/env python3
"""Exactness tests for any engine with the cuda196 CLI (default: ./emu196_v7r).
Extra engine options via ENGINE_FLAGS.
usage: python3 tests/test_exact.py [ENGINE] [CHECKPOINT_FILE]
Compares against Python big integers: values, digit counts, checkpoint file
names/iterations, odd batches, palindrome detection, and adversarial runs of 9s
that cross 32-pair word boundaries and the middle."""
import os, random, subprocess, sys, tempfile
sys.set_int_max_str_digits(0)
ENGINE = os.path.abspath(sys.argv[1] if len(sys.argv) > 1 else './emu196_v7r')
FLAGS = os.environ.get('ENGINE_FLAGS', '').split()  # e.g. ENGINE_FLAGS="--mode=tb --tile=4 --K=7"
CKPT = sys.argv[2] if len(sys.argv) > 2 else None
tmp = tempfile.mkdtemp()

def ra(s): return str(int(s) + int(s[::-1]))
def run(num, steps, batch=64, save=0, start=0):
    inp = os.path.join(tmp, 'in.txt'); out = os.path.join(tmp, 'out.txt')
    open(inp, 'w').write(num + '\n')
    for f in os.listdir(tmp):
        if f.startswith('out.txt'): os.remove(os.path.join(tmp, f))
    args = [ENGINE, inp, str(steps), out, str(start)]
    if not any(f.startswith('--K=') for f in FLAGS): args.append(str(batch))
    else: args.append(str([f for f in FLAGS if f.startswith('--K=')][0][4:]))
    p = subprocess.run(args + [str(save)] + FLAGS, capture_output=True, text=True)
    return p.returncode, out, p.stderr
def first_pal(s, steps):
    for k in range(1, steps + 1):
        s = ra(s)
        if s == s[::-1]: return k, s
    return None, s
fails = 0
def check(cond, msg):
    global fails
    if not cond: fails += 1; print('FAIL', msg)

def case(num, steps, batch, label):
    k, ref = first_pal(num, steps)
    rc, out, err = run(num, steps, batch)
    if k is None:
        check(rc == 0 and open(out).read().strip() == ref, f'{label}: value after {steps} steps ({err[-300:]})')
    else:
        pf = f'{out}.palindrome_{k}.txt'
        ok = rc == 3 and os.path.exists(pf) and open(pf).read().strip() == first_pal(num, k)[1]
        check(ok, f'{label}: palindrome at step {k} rc={rc} ({err[-300:]})')
    return k

random.seed(196)
# 1) tiny numbers 1..2000, 40 steps, batches incl. odd and 1
pal = 0
for x in range(1, 2001):
    pal += case(str(x), 40, random.choice([1, 3, 7, 64]), f'n={x}') is not None
print(f'tiny numbers 1..2000 done ({pal} reach a palindrome within 40 steps)')
# 2) adversarial: long runs of pair-sum 9 (d_j + d_{n-1-j} = 9) crossing word boundaries / middle
for t in range(300):
    n = random.randint(2, 700)
    d = [random.randint(0, 9) for _ in range(n)]
    h = (n + 1) // 2
    a = random.randint(0, h - 1); b = random.randint(a, h)
    for j in range(a, min(b, n // 2)):
        d[n - 1 - j] = 9 - d[j]
    if d[0] == 0: d[0] = random.randint(1, 9)
    case(''.join(map(str, d)), random.randint(1, 120), random.choice([1, 5, 32, 64]), f'adv{t}')
print('adversarial 9-run cases done')
# 3) known delayed palindromes
for num, k in [('89', 24), ('1186060307891929990', 261), ('10911', 55)]:
    got = case(num, 400, 64, f'delayed {num}')
    check(got == k, f'{num}: expected first palindrome at {k}, got {got}')
print('delayed palindromes done')
# 4) checkpoints: interval 50 with batch 37 from 196 (off-by-one, odd batches)
rc, out, err = run('196', 500, batch=37, save=50, start=1000)
s = '196'; ok = rc == 0
for i in range(1, 501):
    s = ra(s)
    if i % 50 == 0:
        f = out if i == 500 else f'{out}.next_{1000 + i}.txt'
        ok &= os.path.exists(f) and open(f).read().strip() == s
check(ok, f'checkpoint files/iterations ({err[-300:]})')
print('checkpoint naming/iteration test done')
# 5) optional: real checkpoint, 3 steps against Python big ints
if CKPT:
    s = open(CKPT).read().strip()
    rc, out, err = run(s, 3, batch=64)
    for _ in range(3): s = ra(s)
    check(rc == 0 and open(out).read().strip() == s, 'checkpoint +3 vs big int')
    print('real checkpoint +3 done')
print('ALL PASS' if not fails else f'{fails} FAILURES')
sys.exit(1 if fails else 0)
