// unit_v7r.cpp - unit tests for v7r building blocks (CPU):
//  1. transpose32_array is a true 32x32 bit transpose, and a lane-by-lane simulation of the GPU
//     shuffle algorithm (transpose32_lane) gives the same result;
//  2. the multiply-high division (magic_for/umulhi32) equals integer division for every pair
//     index a tile can hold, for every tile width the engine can use;
//  3. own_mask / lanes_below agree with a direct definition;
//  4. the growth vote (ballots of warp 0, simulated) equals growth_find's definition.
// Build: g++ -O2 -std=c++17 -I.. unit_v7r.cpp -o unit_v7r && ./unit_v7r
#include <cstdio>
#include <cstdlib>
#include <random>
#include "../bits_tb7r.h"
using namespace tb;
static int fails = 0;
#define EXPECT(c, ...) do { if (!(c)) { if (fails++ < 10) { fprintf(stderr, "FAIL: " __VA_ARGS__); fprintf(stderr, "\n"); } } } while (0)
// simulate the warp: every lane runs transpose32_lane's stages with shfl_xor semantics
static void transpose_shfl_sim(u32 x[32]) {
  const u32 mk[5] = {0x0000FFFFu, 0x00FF00FFu, 0x0F0F0F0Fu, 0x33333333u, 0x55555555u};
  for (int i = 0, s = 16; i < 5; ++i, s >>= 1) {
    u32 y[32];
    for (int l = 0; l < 32; ++l) y[l] = x[l ^ s];  // __shfl_xor_sync(x, s)
    for (int l = 0; l < 32; ++l) {
      const u32 m = mk[i];
      x[l] = (l & s) ? ((x[l] & ~m) | ((y[l] & ~m) >> s)) : ((x[l] & m) | ((y[l] & m) << s));
    }
  }
}
int main() {
  std::mt19937 rng(7);
  for (int t = 0; t < 20000; ++t) {
    u32 a[32], b[32], c[32];
    for (int i = 0; i < 32; ++i) a[i] = b[i] = c[i] = (u32)rng();
    transpose32_array(b);
    transpose_shfl_sim(c);
    for (int i = 0; i < 32; ++i)
      for (int j = 0; j < 32; ++j) EXPECT(((b[j] >> i) & 1u) == ((a[i] >> j) & 1u), "transpose bit %d,%d", i, j);
    for (int i = 0; i < 32; ++i) EXPECT(b[i] == c[i], "shuffle simulation differs at lane %d", i);
    transpose32_array(b);
    for (int i = 0; i < 32; ++i) EXPECT(b[i] == a[i], "transpose is not an involution");
  }
  long long divs = 0;
  for (int Wt = 32; Wt <= 4096; Wt += 32) {
    const u32 mg = magic_for(Wt);
    for (int p = 0; p <= 32 * Wt; ++p, ++divs) {
      const int k = (int)umulhi32((u32)p, mg);
      EXPECT(k == p / Wt, "magic division Wt=%d p=%d", Wt, p);
    }
  }
  for (int t = 0; t < 200000; ++t) {
    const int Wt = 32 * (1 + (int)(rng() % 64));
    TV v; v.s = nullptr; v.stride = 0; v.Wt = Wt; v.P0 = 0; v.magic = magic_for(Wt);
    int lo = (int)(rng() % (32 * Wt + 1)), hi = (int)(rng() % (32 * Wt + 1));
    const Own o = own_of(v, lo, hi);
    const int u = (int)(rng() % Wt);
    u32 ref = 0;
    for (int k = 0; k < 32; ++k) { const int p = k * Wt + u; if (p >= lo && p < hi) ref |= 1u << k; }
    EXPECT(own_mask(o, u) == ref, "own_mask Wt=%d lo=%d hi=%d u=%d", Wt, lo, hi, u);
    const int xr = (int)(rng() % (32 * Wt + 40)) - 20;
    int qx = 0, rx = 0;
    if (xr > 0) { qx = (int)umulhi32((u32)xr, v.magic); rx = xr - qx * Wt; }
    u32 ref2 = 0;
    for (int k = 0; k < 32; ++k) if (k * Wt + u < xr) ref2 |= 1u << k;
    EXPECT(lanes_below(xr, qx, rx, u) == ref2, "lanes_below Wt=%d x=%d u=%d", Wt, xr, u);
  }
  // growth vote: random pair values for pairs 0..31 (biased towards 9), simulated ballots
  long long votes = 0;
  for (int t = 0; t < 200000; ++t, ++votes) {
    int val[32];
    const int nines = (int)(rng() % 34);  // leading run of pair-sum 9 of random length
    for (int p = 0; p < 32; ++p) val[p] = p < nines ? 9 : (int)(rng() % 19);
    const int hn = 1 + (int)(rng() % 60);
    u32 bn[4] = {0, 0, 0, 0}, bg[4] = {0, 0, 0, 0};
    for (int lane = 0; lane < 32; ++lane) {        // what each lane of warp 0 votes
      const bool mine = lane >= 1 && lane <= 8;      // prefix chunk lane-1 (pairs 4(lane-1)..+3)
      for (int i = 0; i < 4; ++i) {
        const int p = 4 * (lane - 1) + i;
        if (mine && val[p] != 9) bn[i] |= 1u << lane;
        if (mine && val[p] >= 10) bg[i] |= 1u << lane;
      }
    }
    int g; const int q = growth_from_votes(bn, bg, hn, &g);
    int qr = -2, gr = 0;                             // reference: growth_find restricted to 32 pairs
    const int lim = hn < 32 ? hn : 32;
    for (int p = 0; p < lim; ++p) if (val[p] != 9) { qr = p; gr = val[p] >= 10; break; }
    if (qr == -2) qr = hn <= 32 ? -1 : Q_UNKNOWN;
    EXPECT(q == qr && (q < 0 || q == Q_UNKNOWN || g == gr), "growth vote hn=%d q=%d/%d", hn, q, qr);
  }
  printf("unit_v7r: %lld growth votes; transpose (20000 random matrices, shuffle simulation), %lld magic divisions, masks: %s\n",
         votes, divs, fails ? "FAIL" : "ALL PASS");
  return fails ? 1 : 0;
}
