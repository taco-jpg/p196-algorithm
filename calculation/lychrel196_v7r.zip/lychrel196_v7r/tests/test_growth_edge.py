#!/usr/bin/env python3
"""Edge case for v7's growth bit: numbers whose NEXT iterate starts with many pairs summing to 9.
Pair sums (4,14,14,4) repeated m times at the start make N_1's first 4m pairs all sum to 9 (no
carries leave the pattern). v7r decides growth from the new number's first 32 pairs (warp vote;
v7: first 8), so m < 8 must be decided by the vote and m >= 8 must take the 'undetermined ->
certification failure -> exact replay' path. Checks exact output against big-int arithmetic for
several step counts and modes.
usage: python3 tests/test_growth_edge.py ENGINE [CASES]"""
import os, random, subprocess, sys, tempfile
sys.set_int_max_str_digits(0)
eng = os.path.abspath(sys.argv[1]); cases = int(sys.argv[2]) if len(sys.argv) > 2 else 60
random.seed(2026); T = tempfile.mkdtemp(); bad = 0; replays = 0; runs = 0
def digits_for(S, n):
    d = [0] * n
    for j, s in enumerate(S):
        lo = max(0, s - 9); hi = min(9, s)
        a = random.randint(lo, hi)
        if j == n - 1 - j: a = s // 2  # odd centre: only even sums are possible
        d[j] = a; d[n - 1 - j] = s - a
    if d[0] == 0:
        return None
    return ''.join(map(str, d))
def pairs(s): n = len(s); return [int(s[n-1-j]) + int(s[j]) for j in range((n + 1) // 2)]
for t in range(cases):
    m = random.choice([2, 3, 4, 8, 20, 33, 40])
    n = random.randint(8 * m + 4, 8 * m + 3000)
    h = (n + 1) // 2
    S = [4, 14, 14, 4] * m
    S += [random.randint(0, 8)] + [random.randint(0, 18) for _ in range(h - len(S) - 1)]
    if n % 2: S[h - 1] = 2 * random.randint(0, 9)
    s = digits_for(S[:h], n)
    if s is None or s != s.lstrip('0'): continue
    N1 = str(int(s) + int(s[::-1]))
    assert all(v == 9 for v in pairs(N1)[:4 * m]), "construction failed"
    steps = random.choice([1, 2, 3, 7, 20])
    ref = s
    for _ in range(steps): ref = str(int(ref) + int(ref[::-1]))
    open(os.path.join(T, 'in.txt'), 'w').write(s + '\n')
    for flags in (["--mode=tb"], ["--mode=tb", "--K=7", "--tile=4"], ["--mode=tb", "--K=64"]):
        out = os.path.join(T, 'out.txt')
        p = subprocess.run([eng, os.path.join(T, 'in.txt'), str(steps), out, '0'] + flags, capture_output=True, text=True)
        runs += 1
        got = open(out).read().strip() if p.returncode == 0 and os.path.exists(out) else None
        if p.returncode == 3:  # a palindrome inside the window is reported separately; recheck
            got = ref if any(f.startswith('out.txt.palindrome_') for f in os.listdir(T)) else None
            for f in os.listdir(T):
                if f.startswith('out.txt.palindrome_'): os.remove(os.path.join(T, f))
        if got != ref:
            bad += 1; print('FAIL', t, n, m, steps, flags, p.returncode, p.stderr[-300:])
        for tok in p.stderr.split():
            if tok.startswith('replays='): replays += int(tok.split('=')[1])
print(f'growth edge cases: {runs - bad}/{runs} exact, {replays} window replays triggered')
sys.exit(1 if bad else 0)
