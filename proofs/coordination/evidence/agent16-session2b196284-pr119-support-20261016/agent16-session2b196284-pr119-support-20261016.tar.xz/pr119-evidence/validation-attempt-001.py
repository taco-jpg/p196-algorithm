#!/usr/bin/env python3
"""Agent #16 independent retained-evidence validation; never invokes Lean or mutates Git."""
import collections, hashlib, importlib.util, json, lzma, pathlib, re, subprocess, tarfile, time, traceback, sys
R=pathlib.Path('/dev/shm/p196-agent16-session2b196284/pr119-evidence')
P=R/'publication'; E=R/'replay'; V=E/'verification-clean-001'; F=R/'firsthit'
H='b235d662ce481cf43f8db1335c18f5993953af9d'; MATH='b8dcd2392dd30e542348b6be160c5bae00abf017'; PREV='018a49231cd3226506699282f0f173745e6b9f8d'
PKG='proofs/contributions/agent-103/residual-five-fibers-20261016/'
GIT=['git','--git-dir=/workspace/scratch/046f9285a650/repo/.git']
import os
ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
A={'propext','Classical.choice','Quot.sound'}
out={'reviewer':'Agent #16 /root/pr119_evidence','source_head':H,'fresh_lean_execution':'NOT_RUN','status':'IN_PROGRESS','scope':'Independent validation of retained evidence bytes, complete logs, source closure, publication identity and documentary correction; no new Lean build or merge.'}
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def j(p): return json.loads(p.read_text())
def git(*args):
 p=subprocess.run(GIT+list(args),env=ENV,capture_output=True)
 assert p.returncode==0,(args,p.stderr.decode())
 return p.stdout.decode().strip()
def checkfile(p,rec):
 b=p.read_bytes();assert len(b)==rec['bytes'] and sha(b)==rec['sha256'],str(p);return b
def parse(log):
 inv=re.findall(r'^AUDIT_THEOREM (\S+) ([^\n]+)$',log,re.M)
 names=[n for m,n in inv];assert len(names)==len(set(names))
 entries=[(n,[]) for n in re.findall(r"^'([^\n]+)' does not depend on any axioms$",log,re.M)]
 entries += [(n,sorted(x.strip() for x in s.split(',') if x.strip())) for n,s in re.findall(r"^'([^\n]+)' depends on axioms:\s*\[([^\]]*)\]$",log,re.M)]
 assert collections.Counter(n for n,a in entries)==collections.Counter(names)
 assert re.findall(r'^AUDIT_COMPLETE (\d+)$',log,re.M)==[str(len(inv))]
 axioms=dict(entries);assert all(set(a)<=A for a in axioms.values())
 unsafe=re.findall(r'^UNSAFE_IMPL (\S+) ([^\n]+)$',log,re.M)
 assert not (set(n for m,n in unsafe)&set(x for a in axioms.values() for x in a))
 assert not re.search(r'(^|\n).*error:|CUSTOM_AXIOM|sorryAx|ofReduceBool|skipKernelTC',log)
 return {n:{'module':m,'axioms':axioms[n]} for m,n in inv},unsafe
try:
 inventory=j(R/'publication-git-inventory.json')
 assert len(inventory)==46
 for row in inventory:
  b=(P/row['path']).read_bytes();assert blob(b)==row['git_blob'];row.update(bytes=len(b),sha256=sha(b))
 out['publication_files']=inventory
 for x in [H,PREV,MATH]:
  out.setdefault('git_commits',{})[x]=git('cat-file','commit',x)
 delta=git('diff-tree','--no-commit-id','--name-status','-r',PREV,H).splitlines()
 assert set(delta)=={'A\t'+PKG+'AUDIT_SCOPE_CORRECTION.md','M\t'+PKG+'README.md','M\t'+PKG+'SOURCE_PINS.json'}
 out['final_head_delta']=delta
 assert out['git_commits'][H].splitlines()[1]=='parent '+PREV
 assert out['git_commits'][PREV].splitlines()[1]=='parent '+MATH
 arc=P/'evidence/complete-replay-evidence.tar.xz'; ab=arc.read_bytes(); ar=j(P/'evidence/ARCHIVE.json')
 assert sha(ab)==ar['sha256'] and len(ab)==ar['bytes'] and blob(ab)==ar['git_blob']
 tb=lzma.decompress(ab);assert len(tb)==ar['uncompressed_tar_bytes'] and sha(tb)==ar['uncompressed_tar_sha256']
 with tarfile.open(arc) as t:
  ms=t.getmembers(); assert len(ms)==143 and len(set(m.name for m in ms))==143
  assert [m.name for m in ms]==sorted(m.name for m in ms)
  assert all(m.isfile() and m.mode==0o644 and m.uid==m.gid==m.mtime==0 and m.uname==m.gname=='' and not m.pax_headers and '..' not in pathlib.PurePosixPath(m.name).parts and not pathlib.PurePosixPath(m.name).is_absolute() for m in ms)
  assert set(m.name for m in ms)==set(j(E/'FILES.json'))|{'FILES.json'}
  assert sum(m.size for m in ms)==ar['uncompressed_file_payload_bytes']
 for n,rec in j(E/'FILES.json').items(): checkfile(E/n,rec)
 assert (P/'FILES.json').read_bytes()==(E/'FILES.json').read_bytes()
 for name in ['BUILD_REGISTRY.json','SOURCES.json','UNSAFE_IMPLEMENTATIONS.json','check.py','REPRODUCE.md','non-author-final-review.json','non-author-final-review.md']:
  assert (P/name).read_bytes()==(E/name).read_bytes()
 out['archive']={k:ar[k] for k in ['bytes','sha256','git_blob','member_count','indexed_files','uncompressed_file_payload_bytes','uncompressed_tar_bytes','uncompressed_tar_sha256']}
 # The inspected driver is imported only for pure source parsing and deterministic audit text; main is not called.
 sys.dont_write_bytecode=True
 spec=importlib.util.spec_from_file_location('reviewed_driver',P/'check.py');driver=importlib.util.module_from_spec(spec);spec.loader.exec_module(driver)
 manifest=j(P/'SOURCES.json'); verify=j(V/'verification.json'); registry=j(P/'BUILD_REGISTRY.json'); mods=registry['projects']['agent103-residual-five-fibers']['modules']; pins=j(P/'SOURCE_PINS.json')
 assert verify['driver_sha256']==sha((P/'check.py').read_bytes()) and verify['manifest_sha256']==sha((P/'SOURCES.json').read_bytes())
 assert driver.COMPILE_ARGS==['--trust=0','-j1','-DElab.async=false']
 assert manifest['toolchain']['arguments']==driver.COMPILE_ARGS
 assert verify['status']=='PASS' and verify['module_count']==22 and not verify['unused_manifest_dependencies']
 assert registry['projects']['agent103-residual-five-fibers']['roots']==['ResidualFiveFilteredConclusion']
 records=manifest['dependencies']|manifest['new_modules'];assert set(records)==set(mods)==set(verify['sources']) and len(records)==22
 sources=[]
 for m,rec in records.items():
  orig=(V/'originals'/(m+'.lean')).read_bytes(); comp=(V/'snapshot'/(m+'.lean')).read_bytes();vr=verify['sources'][m]
  assert sha(orig)==rec['sha256']==vr['original_sha256']
  assert sha(comp)==vr['compiled_sha256'] and driver.imports_of(comp)==rec['imports']==vr['imports']
  if m in manifest['new_modules']:
   assert orig==(P/rec['path']).read_bytes()==(E/rec['path']).read_bytes()
   assert sha(orig)==pins['new_modules'][m]['sha256']
   assert git('rev-parse',H+':'+PKG+rec['path'])==git('rev-parse',MATH+':'+PKG+rec['path'])==blob(orig)
  else:
   assert blob(orig)==rec['git_blob']==vr['git_blob']
   assert git('rev-parse',rec['commit']+':'+rec['path'])==rec['git_blob']
  reg=mods[m];assert git('rev-parse',H+':'+reg['path'])==reg['git_blob']
  assert reg['sha256']==sha(orig) and reg['git_blob']==blob(orig)
  if rec.get('adapter'):
   a=rec['adapter']; header=a['excluded_exact_prefix_utf8'].encode();container=(V/'originals'/(a['container_module']+'.lean')).read_bytes()
   assert orig.startswith(header) and container.startswith(header)
   body=orig[len(header):];off=container.find(body);assert off>=0 and container.find(body,off+1)<0
   assert len(body.splitlines(keepends=True))==4444 and container[:off].count(b'\n')+1==11
   assert comp==b'import LychrelDigitSums\n'==a['exact_compiled_source_utf8'].encode()
  else: assert orig==comp
  sources.append({'module':m,'source_sha256':sha(orig),'compiled_sha256':sha(comp),'git_blob':blob(orig),'publication_path':reg['path'],'imports':driver.imports_of(comp),'new':m in manifest['new_modules']})
 order=[];visiting=set();done=set()
 def visit(m):
  if m not in records: assert m.split('.')[0] in {'Lean','Std','Init'};return
  if m in done:return
  assert m not in visiting;visiting.add(m)
  for d in records[m]['imports']:visit(d)
  visiting.remove(m);done.add(m);order.append(m)
 visit('ResidualFiveFilteredConclusion');assert done==set(records)
 assert set(verify['build_order'])==done
 for i,m in enumerate(verify['build_order']):
  assert all(d not in records or verify['build_order'].index(d)<i for d in records[m]['imports'])
 out['source_closure']=sources
 assert (V/'snapshot/AuditAllContributionModules.lean').read_text()==driver.audit_source(verify['build_order'])
 assert sha((V/'snapshot/AuditAllContributionModules.lean').read_bytes())==verify['audit_source_sha256']
 commands=verify['commands'];assert [c['label'] for c in commands]==['version','prefix']+verify['build_order']+['AuditAllContributionModules']
 for c in commands:
  assert c['exit_code']==0 and sha((V/c['log']).read_bytes())==c['log_sha256']
  assert c['environment']=={'PATH':'/usr/local/bin:/usr/bin:/bin','LANG':'C.UTF-8','TZ':'UTC','LEAN_PATH':c['cwd']}
  if c['label'] not in ['version','prefix']: assert c['argv'][1:4]==driver.COMPILE_ARGS
  log=(V/c['log']).read_text();assert not re.search(r'(^|\n).*error:|sorryAx|CUSTOM_AXIOM',log)
 assert (V/'logs/version.log').read_text().strip()==verify['lean']['version']
 assert 'version 4.19.0, x86_64-unknown-linux-gnu, commit 6caaee842e94, Release' in verify['lean']['version']
 assert (V/'logs/prefix.log').read_text().strip()==verify['lean']['runtime_prefix']
 out['commands']=commands;out['retained_runtime']=verify['lean'];out['retained_run_times']=[verify['started_utc'],verify['finished_utc']]
 th,unsafe=parse((V/'logs/AuditAllContributionModules.log').read_text())
 assert th==verify['theorems'] and len(th)==1812 and unsafe==[tuple(x) for x in verify['unsafe_implementation_constants']]
 counts=collections.Counter(x['module'] for x in th.values())
 assert {m:counts[m] for m in records}==verify['module_theorem_counts']
 assert sum(counts[m] for m in manifest['new_modules'])==111
 dep,dunsafe=parse((E/'dependency-audit-001/audit.log').read_text())
 assert len(dep)==1701 and all(th[n]==v for n,v in dep.items()) and len(dunsafe)==30
 ledger=j(P/'UNSAFE_IMPLEMENTATIONS.json');assert [(e['module'],e['constant']) for e in ledger['entries']]==unsafe and len(unsafe)==33
 assert sum(m in manifest['new_modules'] for m,n in unsafe)==3
 out['axiom_audit']={'theorem_count':len(th),'inherited':len(dep),'new':len(th)-len(dep),'counts_by_module':dict(counts),'axiom_union':sorted({a for v in th.values() for a in v['axioms']}),'unsafe_axiomInfo':len(unsafe),'unsafe_inherited':len(dunsafe),'unsafe_new':3,'unsafe_in_theorem_dependencies':0,'raw_audit_log_sha256':sha((V/'logs/AuditAllContributionModules.log').read_bytes()),'all_parsed_rows_equal_recorded_rows':True,'all_inherited_rows_equal_preflight':True}
 for n,rec in j(V/'FILES.json').items():checkfile(V/n,rec)
 for sub in ['dependency-audit-001','registry-check-only-001']:
  for n,rec in j(E/sub/'FILES.json').items():checkfile(E/sub/n,rec)
 structural=j(E/'registry-check-only-001/verification.json');cmd=j(E/'registry-check-only-invocation.json')
 assert cmd['exit_code']==0 and '--check-only' in cmd['argv']
 assert cmd['registry_sha256']==sha((P/'BUILD_REGISTRY.json').read_bytes())
 out['structural_check']={'invocation':cmd,'verification':structural}
 # Restore and inventory failed historical research without executing it.
 dev=j(P/'evidence/development-evidence.manifest.json');da=P/'evidence/development-evidence.tar.xz'
 assert sha(da.read_bytes())==dev['archive_sha256'] and da.stat().st_size==dev['archive_bytes']
 logs=[]
 with tarfile.open(da) as t:
  ms=t.getmembers();assert len(ms)==dev['file_count']==66 and set(x.name for x in ms)==set(dev['files'])
  for m in ms:
   assert m.isfile() and not pathlib.PurePosixPath(m.name).is_absolute() and '..' not in pathlib.PurePosixPath(m.name).parts
   d=t.extractfile(m).read();rec=dev['files'][m.name];assert len(d)==rec['bytes'] and sha(d)==rec['sha256']
   dest=R/'development'/m.name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(d)
   if m.name.endswith('.log'):
    text=d.decode();logs.append({'path':m.name,'bytes':len(d),'sha256':sha(d),'errors':[l for l in text.splitlines() if 'error:' in l]})
 out['development_archive']={'bytes':da.stat().st_size,'sha256':sha(da.read_bytes()),'files':len(ms),'logs':logs}
 # Later audit is used only to fact-check the documentation correction, not as PR119 proof replacement.
 later=j(F/'verification-clean-001/verification.json');ll=(F/'verification-clean-001/logs/AuditAllContributionModules.log').read_text()
 lt,lu=parse(ll);assert len(lt)==1881 and lt==later['theorems'] and all(lt[n]==v for n,v in th.items())
 defs=re.findall(r'^AUDIT_DEFINITION (\S+) (\S+) (safe|unsafe|partial) (definition|opaque)$',ll,re.M)
 assert len(defs)==1157 and len({n for m,n,s,k in defs})==1157
 assert collections.Counter(s for m,n,s,k in defs)=={'safe':216,'unsafe':917,'partial':24}
 assert collections.Counter(k for m,n,s,k in defs)=={'definition':1157}
 assert all(m not in later['selected_new_modules'] for m,n,s,k in defs)
 assert re.findall(r'^AUDIT_DEFINITIONS_COMPLETE (\d+) (\d+)$',ll,re.M)==[('1157','0')]
 assert set(lu)==set(unsafe)
 assert len(later['commands'])==30 and all(c['exit_code']==0 for c in later['commands'])
 assert all(c['argv'][1:4]==driver.COMPILE_ARGS for c in later['commands'] if c['label'] not in ['version','prefix'])
 di=j(F/'DEFINITION_INVENTORY.json')
 assert di['source_sha256']==sha((F/'verification-clean-001/verification.json').read_bytes()) and di['audit_log_sha256']==sha(ll.encode())
 out['later_documentary_check']={'publication_head':'43219b02c191325d0263b4ad2fa1f4ebb1470a5c','archive_git_blob':blob((F/'complete-replay-evidence.tar.xz').read_bytes()),'archive_sha256':sha((F/'complete-replay-evidence.tar.xz').read_bytes()),'module_count':later['module_count'],'theorem_count':len(lt),'all_earlier_theorem_rows_equal':True,'definition_count':len(defs),'safety_counts':dict(collections.Counter(s for m,n,s,k in defs)),'kind_counts':dict(collections.Counter(k for m,n,s,k in defs)),'new_module_definitions':0,'unsafe_axiomInfo_count':len(lu),'all_exits_zero':True,'finished_utc':later['finished_utc']}
 reviews={}
 for f in sorted((E/'reviews').glob('*.review.json')):
  reviews[f.name]=j(f)
 out['review_records']=reviews
 pack=j(P/'evidence/PACKAGING_FILES.json');missing=[]
 for n,rec in pack.items():
  p=P/'evidence'/n
  if p.exists():checkfile(p,rec)
  else:missing.append(n)
 assert missing==['PR_REVIEW.md','final-publication-tree.json','publication-placeholders.json']
 out['packaging_auxiliary_absences']={'files':missing,'interpretation':'Published packaging inventory also lists three local auxiliary publication receipts absent from the published tree and complete replay archive. They are not Lean evidence. This review independently verifies all 46 published blobs and commit/tree identities; no proof obligation relies on these missing auxiliary receipts. If desired for full historical packaging recovery, add exact files matching retained hashes or an additive scope clarification.'}
 out['status']='PASS_RETAINED_EVIDENCE_WITH_PACKAGING_SCOPE_NOTE'
except Exception:
 out['status']='VALIDATOR_FAILURE';out['failure']=traceback.format_exc();print(out['failure'])
finally:
 out['validation_finished_utc']=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime())
 (R/'validation-results.json').write_text(json.dumps(out,indent=2)+'\n')
 print(json.dumps({k:v for k,v in out.items() if k in ['status','failure','axiom_audit','later_documentary_check','archive','packaging_auxiliary_absences']},indent=2))
 if out['status']=='VALIDATOR_FAILURE':sys.exit(1)
