import Std

theorem agent12_runtime_smoke (n : Nat) : n + 0 = n := Nat.add_zero n

#print axioms agent12_runtime_smoke
