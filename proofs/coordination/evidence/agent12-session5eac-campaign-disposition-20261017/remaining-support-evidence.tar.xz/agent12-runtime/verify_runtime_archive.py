"""Compare an installed Lean runtime against a freshly downloaded official archive."""
from pathlib import Path, PurePosixPath
import hashlib
import json
import subprocess
import tarfile

root = Path('/workspace/scratch/5eac7b9c26af/agent12-runtime')
archive = root / 'lean-4.19.0-linux.tar.zst'
installed = Path('/tmp/p196-agent5-lean')

def digest_file(path):
    with path.open('rb') as stream:
        return hashlib.file_digest(stream, 'sha256').hexdigest()

rows = []
failures = []
process = subprocess.Popen(['zstd', '-dc', str(archive)], stdout=subprocess.PIPE)
with tarfile.open(fileobj=process.stdout, mode='r|') as bundle:
    for member in bundle:
        parts = PurePosixPath(member.name).parts
        if not parts or parts[0] != 'lean-4.19.0-linux' or '..' in parts:
            raise RuntimeError('Unsafe or unexpected archive path: ' + member.name)
        target = installed.joinpath(*parts)
        row = {'path': member.name, 'size': member.size}
        if member.isfile():
            with bundle.extractfile(member) as content:
                expected = hashlib.file_digest(content, 'sha256').hexdigest()
            actual = digest_file(target)
            row.update(type='file', expected_sha256=expected, actual_sha256=actual,
                       matched=actual == expected)
        elif member.isdir():
            row.update(type='directory', matched=target.is_dir())
        elif member.issym():
            row.update(type='symlink', target=member.linkname,
                       matched=target.is_symlink() and str(target.readlink()) == member.linkname)
        elif member.islnk():
            reference = installed.joinpath(*PurePosixPath(member.linkname).parts)
            row.update(type='hardlink', target=member.linkname,
                       matched=digest_file(target) == digest_file(reference))
        else:
            row.update(type='unexpected', matched=False)
        rows.append(row)
        if not row['matched']:
            failures.append(row)
process.stdout.close()
exit_code = process.wait()
if exit_code:
    raise RuntimeError('zstd exited ' + str(exit_code))
result = {
    'source': 'https://github.com/leanprover/lean4/releases/download/v4.19.0/lean-4.19.0-linux.tar.zst',
    'archive': str(archive),
    'archive_bytes': archive.stat().st_size,
    'archive_sha256': digest_file(archive),
    'digest_scope': 'Locally computed SHA-256 of an HTTPS download from the official fixed-version release; upstream release API digest is null.',
    'runtime': str(installed / 'lean-4.19.0-linux'),
    'member_count': len(rows),
    'regular_file_count': sum(row['type'] == 'file' for row in rows),
    'all_archive_members_match': not failures,
    'failures': failures,
}
(root / 'runtime-member-checks.json').write_text(json.dumps(rows, indent=2) + '\n')
(root / 'runtime-archive-check.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
if failures:
    raise SystemExit(1)
