#!/usr/bin/env python3
"""Validate retained successful audit output without executing Lean or modifying sources."""
import hashlib
import json
import re
import sys
import traceback
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path("/dev/shm/p196-agent13-session6124-20261016/review127")
OUT = ROOT / "analysis-004"
ORIGINAL = Path("/workspace/scratch/6124a6476634/evidence/pr127-incoming")
HEAD = "c68b0aaa5344f2cc646c035e2efca187852cb57d"
BASE = "1ee9123344dbe17e9bda224ff8af5b1cbb2b64e4"
PROJECT = "agent7-allbase-overflow-births"
FLAGS = ["--trust=0", "-j1", "-DElab.async=false"]
PIN = "92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023"
ALLOWED = {"propext", "Classical.choice", "Quot.sound"}

def now():
    return datetime.now(timezone.utc).isoformat()

def sha(path):
    h = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def write_new(path, text):
    with path.open("x", encoding="utf-8") as stream:
        stream.write(text)

def dump(path, value):
    write_new(path, json.dumps(value, indent=2, ensure_ascii=False) + "\n")

def require(condition, message):
    if not condition:
        raise ValueError(message)

def load(relative):
    return json.loads((ROOT / relative).read_text())

def digest_files(paths):
    return {str(p): {"sha256": sha(p), "bytes": p.stat().st_size} for p in paths}

def main():
    OUT.mkdir()
    report = {
        "schema_version": 1,
        "reviewer": "Agent #13 /root/review127",
        "status": "RUNNING",
        "started_at": now(),
        "head": HEAD,
        "checked_base": BASE,
        "project": PROJECT,
        "action": "Independent validation of retained successful Lean audit output",
        "lean_executions_in_this_stage": 0,
        "fresh_project_compilations_in_this_stage": 0,
        "project_source_edits": False,
        "remote_mutations": False,
        "repository_wide_pass": False,
        "independent_nonauthor": True,
        "formal_github_approve_established": False,
        "parent_handles_combined_tree_and_all_incoming_publication_checks": True,
        "invocation": [sys.executable, *sys.argv],
        "allowed_axioms": sorted(ALLOWED),
        "prior_theorem_count_comparison_only": 338,
    }
    dump(OUT / "state-0000.json", report)
    try:
        fresh = load("fresh-001/FINAL_RECEIPT.json")
        audit = load("audit-003/FINAL_RECEIPT.json")
        identity = load("SOURCE_IDENTITY_READONLY.json")
        registry = load("inputs/project/PROJECT_REGISTRY.json")
        modules = registry["projects"][PROJECT]["modules"]
        endpoints = [e for c in registry["claims"] if c["project"] == PROJECT for e in c["endpoints"]]
        require(len(endpoints) == len(set(endpoints)), "Duplicate registry public endpoint")
        require(set(registry["toolchain"]["allowed_axioms"]) == ALLOWED, "Registry changed axiom allowance")
        require(fresh["head"] == audit["head"] == identity["head"] == HEAD, "Head binding differs")
        require(fresh["checked_base"] == audit["checked_base"] == identity["checked_base"] == BASE, "Base binding differs")
        require(fresh["status"] == "FAIL" and fresh["project_fresh_compilation_complete"], "Fresh build history not retained truthfully")
        require(fresh["fresh_object_count_at_start"] == 0, "Fresh build started with project objects")
        require(fresh["fresh_project_objects"] and not fresh["historical_project_objects_imported"], "Historical objects represented as fresh")
        require(audit["status"] == "FAIL", "Retained postprocessing failure changed")
        require(audit["failure"] == "Unexpected newly originated unsafe implementation constant", "Unexpected prior failure")
        require(audit["fresh_project_compilation_this_execution"] is False, "Audit continuation mislabels fresh compilation")
        require(audit["source_records"] == fresh["source_records"], "Audit objects lost the fresh build source binding")
        require(set(modules) == set(fresh["source_records"]) == set(fresh["build_order"]), "Module closure mismatch")
        require(endpoints == fresh["endpoints"] == audit["endpoints"], "Endpoint list mismatch")
        require(len(modules) == 13, "Review assignment is not the thirteen-module closure")
        selected_identity = {r["module"]: r for r in identity["selected_modules"]}
        require(set(selected_identity) == set(modules), "Independent Git source binding coverage mismatch")
        dependencies = {m for m, r in fresh["source_records"].items() if r["inherited_dependency"]}
        require(len(dependencies) == 8, "Original dependency closure mismatch")
        original_bindings = {r["module"]: r for r in identity["original_dependency_bindings"]}
        require(set(original_bindings) == dependencies, "Original dependency pin coverage mismatch")
        files = [Path(__file__), ROOT / "fresh-001/FINAL_RECEIPT.json",
                 ROOT / "audit-003/FINAL_RECEIPT.json", ROOT / "SOURCE_IDENTITY_READONLY.json",
                 ROOT / "inputs/project/PROJECT_REGISTRY.json",
                 ROOT / "inputs/project/dependencies/SOURCE_PINS.json",
                 ROOT / "inputs/canonical_verifier.py", ROOT / "run_review.py",
                 ROOT / "continue_audit_003.py", ROOT / audit["audit_source_path"]]
        for m, spec in modules.items():
            rec = fresh["source_records"][m]
            independent = selected_identity[m]
            require(spec["sha256"] == rec["sha256"] == independent["sha256"], "Source hash identity mismatch: " + m)
            require(spec["git_blob"] == rec["git_blob"] == independent["git_blob"], "Git blob identity mismatch: " + m)
            require(spec["path"] == rec["repository_path"] == independent["path"], "Repository source path mismatch: " + m)
            require(spec["imports"] == rec["imports"] == independent["imports_observed"], "Import closure mismatch: " + m)
            require(independent["registry_identity_equal"] and independent["head_tree_binding_equal"]
                    and independent["git_object_bytes_equal"], "Prior independent exact Git binding failed: " + m)
            paths = [ROOT / rec["compile_path"], ROOT / rec["snapshot_path"], ORIGINAL / rec["repository_path"]]
            require(all(sha(p) == rec["sha256"] for p in paths), "Current source differs from exact H: " + m)
            obj = ROOT / "fresh-001/source" / (m + ".olean")
            require(sha(obj) == rec["object_sha256"] and obj.stat().st_size == rec["object_bytes"],
                    "Fresh compiler object changed: " + m)
            files.extend([*paths, obj])
            if m in dependencies:
                old = original_bindings[m]
                require(old["original_tree_binding_equal"] and old["original_git_blob"] == rec["git_blob"],
                        "Original dependency binding mismatch: " + m)
                require(old["original_commit"] == "98d59927ad89c42f438ea857ec5750a0df3b91db",
                        "Original dependency commit changed")
        require(sha(ROOT / "inputs/project/PROJECT_REGISTRY.json") == fresh["registry_sha256"] == identity["registry_sha256"],
                "Registry hash changed")
        require(sha(ROOT / "inputs/project/dependencies/SOURCE_PINS.json") == fresh["dependency_source_pins_sha256"] == identity["source_pins_sha256"],
                "Dependency pin hash changed")
        require(sha(ROOT / "inputs/canonical_verifier.py") == fresh["canonical_verifier_source_sha256"],
                "Canonical verifier source hash changed")
        require(sha(ROOT / "run_review.py") == fresh["runner_sha256_before"], "Original build runner changed")
        require(sha(ROOT / "continue_audit_003.py") == audit["runner_sha256_before"], "Successful audit runner changed")
        require(sha(ROOT / audit["audit_source_path"]) == audit["audit_source_sha256"], "Successful audit source changed")
        project_commands = [c for c in fresh["commands"] if c["label"] in modules]
        require([c["label"] for c in project_commands] == fresh["build_order"], "Fresh build order mismatch")
        require(len(project_commands) == 13, "Fresh project compilation count mismatch")
        for c in project_commands:
            require(c["exit_code"] == 0 and c["status"] == "PASSED", "Fresh module did not succeed")
            require(c["argv"][1:4] == FLAGS, "Fresh module lost required trust/resource flags")
            require(c["argv"][4:] == ["-o", c["label"] + ".olean", c["label"] + ".lean"], "Unexpected build command")
        require(len(audit["commands"]) == 1, "Unexpected audit-only command count")
        successful = audit["commands"][0]
        require(successful["exit_code"] == 0 and successful["status"] == "PASSED",
                "Lean audit execution itself did not succeed")
        require(successful["argv"][1:4] == FLAGS, "Audit lost required trust/resource flags")
        require(successful["argv"][-1] == str(ROOT / audit["audit_source_path"]), "Audit executed different source")
        commands = []
        for stage in ["fresh-001", "audit-002", "audit-003"]:
            receipt = load(stage + "/FINAL_RECEIPT.json")
            for command in receipt["commands"]:
                for stream in ["stdout", "stderr"]:
                    p = ROOT / command[stream]
                    require(sha(p) == command[stream + "_sha256"] and p.stat().st_size == command[stream + "_bytes"],
                            "Raw execution log changed: " + str(p))
                    files.append(p)
                commands.append({"stage": stage, **command})
        require("4.19.0" in fresh["lean_version"] and "6caaee842e94" in fresh["lean_version"],
                "Pinned version/commit not observed")
        runtime_before = {p: sha(Path(p)) for p in fresh["runtime_files_before"]}
        require(runtime_before == fresh["runtime_files_before"] == audit["runtime_files_before"],
                "Runtime identity changed since fresh compilation or successful audit")
        require(sha(Path(successful["argv"][0])) == PIN, "Lean executable pin mismatch")
        files.extend(Path(p) for p in runtime_before)
        report["inputs_before"] = digest_files(files)
        audit_text = (ROOT / successful["stdout"]).read_text()
        def rows(prefix):
            return [json.loads(line[len(prefix):]) for line in audit_text.splitlines() if line.startswith(prefix)]
        declaration_rows = rows("DECL_JSON ")
        graph_rows = rows("GRAPH_JSON ")
        summaries = rows("AUDIT_SUMMARY_JSON ")
        require(len(summaries) == 1 and declaration_rows and graph_rows, "Incomplete audit output")
        summary = summaries[0]
        declarations = {r["name"]: r for r in declaration_rows}
        graph = {r["name"]: r for r in graph_rows}
        require(len(declarations) == len(declaration_rows) and len(graph) == len(graph_rows), "Duplicate audited name")
        require(set(r["module"] for r in declaration_rows) == set(modules), "Missing module-origin audit")
        require(summary["module_origin_constants"] == len(declarations), "Declaration count mismatch")
        require(summary["reachable_dependency_constants"] == len(graph), "Graph count mismatch")
        require(summary["module_origin_theorems"] == sum(r["kind"] == "theorem" for r in declaration_rows), "Theorem count mismatch")
        require(summary["module_origin_safe_definitions"] ==
                sum(r["kind"] == "definition" and not r["unsafe"] and not r["partial"] for r in declaration_rows),
                "Safe definition count mismatch")
        require(summary["module_origin_unsafe_constants"] == sum(r["unsafe"] for r in declaration_rows), "Unsafe count mismatch")
        require(summary["module_origin_partial_implementation_definitions"] == sum(r["partial"] for r in declaration_rows), "Partial count mismatch")
        require(set(r["name"] for r in declaration_rows if r["public_endpoint"]) == set(endpoints),
                "Public endpoint full-type coverage mismatch")
        for row in declaration_rows:
            safe = not (row["unsafe"] or row["partial"])
            require(row["safe"] == safe, "Incorrect safety classification: " + row["name"])
            require(all(marker not in row["type"] for marker in ["\u22ef", "\u2026", "<...>"]),
                    "Type pretty-printer omitted content: " + row["name"])
            if safe:
                require(row["kind"] in {"theorem", "definition"}, "Unexpected selected safe declaration kind")
                require(row["present_in_checked_environment"], "Safe declaration absent from kernel checked environment")
                require(row["axiom_audit_status"] == "CHECKED", "Safe declaration was not audited")
                require(set(row["axioms"]) <= ALLOWED, "Forbidden axiom in safe declaration")
            else:
                require(row["axiom_audit_status"] == "NOT_APPLICABLE_IMPLEMENTATION_HELPER",
                        "Implementation helper incorrectly represented as axiom-checked")
        literal = re.findall(r"^'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", audit_text, re.M)
        literal_dict = {name: [ax.strip() for ax in body.split(",") if ax.strip()] for name, body in literal}
        require(len(literal) == len(endpoints) and set(literal_dict) == set(endpoints),
                "Literal public axiom output incomplete or duplicated")
        for name, axs in literal_dict.items():
            require(declarations[name]["kind"] == "theorem" and declarations[name]["safe"], "Public endpoint is not a safe theorem")
            require(set(axs) == set(declarations[name]["axioms"]) and set(axs) <= ALLOWED,
                    "Literal/programmatic axiom mismatch: " + name)
        for name, row in graph.items():
            require(not row["unsafe"] and not row["partial"], "Unsafe or partial proof dependency: " + name)
            require(all(dep in graph for dep in row["dependencies"]), "Missing transitive graph edge: " + name)
        safe_roots = {r["name"] for r in declaration_rows if r["safe"]}
        require(summary["safe_roots"] == len(safe_roots), "Safe-root count mismatch")
        reached = set()
        todo = list(safe_roots)
        while todo:
            name = todo.pop()
            if name in reached:
                continue
            require(name in graph, "Safe root or reachable node missing")
            reached.add(name)
            todo.extend(graph[name]["dependencies"])
        require(reached == set(graph), "Graph is not exactly the full accepted safe-root closure")
        implementation = [r for r in declaration_rows if not r["safe"]]
        new_expected = {
            "P196.Agent7.AllBaseOverflow.adjacentPair._cstage1": {
                "type": "Int \u2192 Int \u2192 Int \u2192 Int \u2192 Int \u2192 Int",
                "dependencies": {"Int.emod", "Int", "Int.add", "Int.ediv"}},
            "P196.Agent7.AllBaseOverflow.adjacentPair._cstage2": {
                "type": "_obj \u2192 _obj \u2192 _obj \u2192 _obj \u2192 _obj \u2192 _obj",
                "dependencies": {"_obj", "Int.emod", "Int.add", "Int.ediv"}},
        }
        new_implementation = [r for r in implementation if r["module"] not in dependencies]
        require({r["name"] for r in new_implementation} == set(new_expected),
                "Uninspected new implementation helper")
        for row in new_implementation:
            expected = new_expected[row["name"]]
            require(row["module"] == "AdjacentBirths" and row["kind"] == "definition"
                    and row["unsafe"] and not row["partial"], "New helper classification differs from inspected compiler stages")
            require(row["type"] == expected["type"] and set(row["dependencies"]) == expected["dependencies"],
                    "New compiler-stage helper type or dependency changed")
        require(all(r["name"] not in reached for r in implementation), "Implementation helper feeds accepted proofs")
        for row in implementation:
            row["implementation_origin"] = (
                "Inherited original dependency compiler helper" if row["module"] in dependencies
                else "Compiler stage of the new safe adjacentPair definition")
            row["reachable_from_accepted_safe_roots"] = False
            row["classification_evidence"] = (
                "Lean ConstantInfo.isUnsafe / isPartial classification in the retained successful audit; "
                "complete type-and-value dependency closure rejects both kinds")
        union = sorted(set().union(*(set(r["axioms"]) for r in declaration_rows if r["safe"])))
        graph_axioms = sorted(r["name"] for r in graph_rows if r["kind"] == "axiom")
        require(set(union) == set(summary["axiom_union"]) and set(union) <= ALLOWED, "Axiom union differs")
        require(set(graph_axioms) == set(union), "Kernel graph axioms disagree with collection")
        require(summary["public_endpoints"] == len(endpoints) and summary["unsafe_reachable"] is False,
                "Audit summary public/unsafe mismatch")
        require(not any(name in reached for name in ["sorryAx", "Lean.ofReduceBool", "Lean.trustCompiler"]), "Forbidden accepted dependency")
        outputs = {
            "DECLARATIONS.json": declaration_rows,
            "DEPENDENCY_GRAPH.json": graph_rows,
            "PUBLIC_ENDPOINTS.json": [{**declarations[e], "literal_axioms": literal_dict[e]} for e in endpoints],
            "IMPLEMENTATION_INVENTORY.json": implementation,
            "COMMANDS.json": commands,
            "SOURCE_IDENTITIES.json": {
                "head": HEAD, "checked_base": BASE,
                "selected_sources": fresh["source_records"],
                "original_dependency_bindings": identity["original_dependency_bindings"],
                "git_identity_record": "SOURCE_IDENTITY_READONLY.json",
                "git_identity_record_sha256": sha(ROOT / "SOURCE_IDENTITY_READONLY.json"),
                "registry_sha256": fresh["registry_sha256"],
                "dependency_source_pins_sha256": fresh["dependency_source_pins_sha256"],
            },
        }
        for name, value in outputs.items():
            dump(OUT / name, value)
        report["inputs_after"] = digest_files(files)
        require(report["inputs_after"] == report["inputs_before"], "Inputs changed during postprocessing")
        report.update(
            status="PASS",
            semantic_disposition="No mathematical blocker found for the exact finite one-step scope",
            total_fresh_project_builds_by_this_reviewer=1,
            project_module_compilations_successful=13,
            compiler_flags=FLAGS,
            lean_version=fresh["lean_version"],
            lean_binary_sha256=PIN,
            registry_sha256=fresh["registry_sha256"],
            dependency_source_pins_sha256=fresh["dependency_source_pins_sha256"],
            canonical_verifier_sha256=fresh["canonical_verifier_source_sha256"],
            fresh_project_build_stage="fresh-001",
            successful_lean_audit_stage="audit-003",
            successful_lean_audit_command=successful,
            overall_failed_stage_receipts_preserved=["fresh-001/FINAL_RECEIPT.json", "audit-002/FINAL_RECEIPT.json", "audit-003/FINAL_RECEIPT.json"],
            recovery={
                "first_audit_error": "Unresolved RecursorRule lambda parameter type; no evaluation bypass used",
                "second_audit_error": "Reviewer mistook a partial compiler implementation helper for a safe definition",
                "third_postprocessor_error": "Reviewer wrongly assumed every compiler implementation helper originated in an inherited module",
                "final_correction": "Validate the two independently inspected new adjacentPair compiler-stage helpers separately and require all unsafe/partial helpers to be absent from every accepted dependency closure",
                "mathematical_sources_changed": False,
                "axiom_allowance_changed": False,
                "successful_audit_rerun_for_this_correction": False,
            },
            audit_summary=summary,
            observed_axiom_union=union,
            graph_axioms=graph_axioms,
            public_endpoint_count=len(endpoints),
            total_implementation_helpers=len(implementation),
            inherited_implementation_helpers=sum(r["module"] in dependencies for r in implementation),
            new_compiler_stage_helpers=len(new_implementation),
            unsafe_helpers_reachable_from_safe_roots=[],
            partial_helpers_reachable_from_safe_roots=[],
            module_origin_counts={m: {
                "all_constants": sum(r["module"] == m for r in declaration_rows),
                "theorems": sum(r["module"] == m and r["kind"] == "theorem" for r in declaration_rows),
                "safe_definitions": sum(r["module"] == m and r["kind"] == "definition" and r["safe"] for r in declaration_rows),
                "unsafe_constants": sum(r["module"] == m and r["unsafe"] for r in declaration_rows),
                "partial_implementation_definitions": sum(r["module"] == m and r["partial"] for r in declaration_rows),
                "public_endpoints": sum(r["module"] == m and r["public_endpoint"] for r in declaration_rows),
            } for m in fresh["build_order"]},
            prior_theorem_count_comparison={"prior": 338, "observed": summary["module_origin_theorems"],
                                            "equal": summary["module_origin_theorems"] == 338,
                                            "not_used_as_a_pass_assumption": True},
            source_runtime_object_and_log_hashes_unchanged=True,
            data_artifacts={name: {"sha256": sha(OUT / name), "bytes": (OUT / name).stat().st_size}
                            for name in outputs},
        )
    except Exception as exc:
        report.update(status="FAIL", failure=str(exc))
        write_new(OUT / "failure.txt", traceback.format_exc())
    finally:
        report["finished_at"] = now()
        dump(OUT / "FINAL_RECEIPT.json", report)
        print(json.dumps({k: report[k] for k in ["status", "head", "checked_base", "started_at", "finished_at"]}))
        if report["status"] == "FAIL":
            print(report["failure"], file=sys.stderr)
    return 0 if report["status"] == "PASS" else 1

if __name__ == "__main__":
    raise SystemExit(main())
