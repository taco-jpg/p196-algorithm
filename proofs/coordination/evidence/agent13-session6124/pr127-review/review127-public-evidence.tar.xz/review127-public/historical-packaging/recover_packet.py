#!/usr/bin/env python3
"""Verify this evidence archive losslessly; optionally extract without executing content."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import tarfile

def digest(data):
    return hashlib.sha256(data).hexdigest()

def verify(archive, expected_sha256=None):
    archive = Path(archive)
    raw = archive.read_bytes()
    if expected_sha256 and digest(raw) != expected_sha256:
        raise ValueError("Archive SHA-256 mismatch")
    payload = {}
    with tarfile.open(archive, "r:xz") as tar:
        for member in tar:
            path = PurePosixPath(member.name)
            if not member.isfile() or path.is_absolute() or ".." in path.parts:
                raise ValueError("Unsupported or unsafe archive entry: " + member.name)
            if len(path.parts) < 2 or path.parts[0] != "review127":
                raise ValueError("Unexpected archive prefix")
            name = str(PurePosixPath(*path.parts[1:]))
            if name in payload:
                raise ValueError("Duplicate archive entry")
            stream = tar.extractfile(member)
            data = stream.read()
            if len(data) != member.size:
                raise ValueError("Truncated archive member")
            payload[name] = data
    manifest_raw = payload.pop("ARCHIVE_MANIFEST.json")
    manifest = json.loads(manifest_raw)
    expected = {row["path"]: row for row in manifest["files"]}
    if len(expected) != len(manifest["files"]) or set(expected) != set(payload):
        raise ValueError("Archive member coverage differs from manifest")
    for name, data in payload.items():
        rec = expected[name]
        if len(data) != rec["bytes"] or digest(data) != rec["sha256"]:
            raise ValueError("Payload hash mismatch: " + name)
    return payload, manifest_raw, {
        "status": "PASS",
        "archive_sha256": digest(raw),
        "archive_bytes": len(raw),
        "manifest_sha256": digest(manifest_raw),
        "substantive_files_verified": len(payload),
        "substantive_bytes_verified": sum(map(len, payload.values())),
        "archive_members_verified": len(payload) + 1,
        "extracted": False,
        "executed_archive_content": False,
    }

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("archive")
    parser.add_argument("--expected-sha256")
    parser.add_argument("--extract-to")
    args = parser.parse_args()
    payload, manifest_raw, receipt = verify(args.archive, args.expected_sha256)
    if args.extract_to:
        root = Path(args.extract_to)
        if root.exists():
            raise ValueError("Extraction destination must not exist")
        root.mkdir(parents=True)
        payload["ARCHIVE_MANIFEST.json"] = manifest_raw
        for name, data in payload.items():
            destination = root / name
            destination.parent.mkdir(parents=True, exist_ok=True)
            with destination.open("xb") as stream:
                stream.write(data)
        receipt["extracted"] = True
        receipt["extraction_directory"] = str(root)
    print(json.dumps(receipt, indent=2))

if __name__ == "__main__":
    main()
