#!/usr/bin/env python3
"""Seal all substantive reviewer evidence, retaining original objects outside transport."""
import base64
import hashlib
import json
import lzma
import sys
import tarfile
import traceback
from datetime import datetime, timezone
from pathlib import Path

ROOT = Path("/dev/shm/p196-agent13-session6124-20261016/review127")
DELIVERY = ROOT / "delivery"
HEAD = "c68b0aaa5344f2cc646c035e2efca187852cb57d"
BASE = "1ee9123344dbe17e9bda224ff8af5b1cbb2b64e4"

def now():
    return datetime.now(timezone.utc).isoformat()

def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest()

def dump(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")

def record(path):
    return {"path": str(path.relative_to(ROOT)), "sha256": sha(path), "bytes": path.stat().st_size}

def main():
    DELIVERY.mkdir()
    result = {"schema_version": 1, "status": "RUNNING", "started_at": now(),
              "reviewer": "Agent #13 /root/review127", "head": HEAD, "checked_base": BASE,
              "lean_execution_in_packaging": False, "remote_mutations": False,
              "original_files_deleted": False, "invocation": [sys.executable, *sys.argv]}
    dump(DELIVERY / "state-0000.json", result)
    try:
        analysis = json.loads((ROOT / "analysis-004/FINAL_RECEIPT.json").read_text())
        fresh = json.loads((ROOT / "fresh-001/FINAL_RECEIPT.json").read_text())
        if analysis["status"] != "PASS" or analysis["head"] != HEAD or analysis["checked_base"] != BASE:
            raise ValueError("Missing valid final review analysis")
        for relative in ["SEMANTIC_REVIEW.md", "COMMENT_REVIEW_DRAFT.md", "README_REVIEW_PACKET.md",
                         "recover_packet.py", "RECOVERY.md"]:
            if not (ROOT / relative).is_file():
                raise ValueError("Missing substantive deliverable")
        exclusions = []
        project_commands = {c["label"]: c for c in fresh["commands"] if c["label"] in fresh["source_records"]}
        for module in fresh["build_order"]:
            rec = fresh["source_records"][module]
            path = ROOT / "fresh-001/source" / (module + ".olean")
            if sha(path) != rec["object_sha256"] or path.stat().st_size != rec["object_bytes"]:
                raise ValueError("Fresh compiler object changed before archive")
            exclusions.append({
                **record(path), "module": module,
                "original_absolute_path": str(path),
                "preserved_in_original_workspace": True,
                "excluded_from_transport_only": True,
                "reason": "Reproducible compiler output; exact source and original commands/logs are included",
                "source_path": rec["compile_path"], "source_sha256": rec["sha256"],
                "lean_binary_sha256": analysis["lean_binary_sha256"],
                "original_compilation": project_commands[module],
                "future_reproduction_is_a_new_execution": True,
            })
        excluded_paths = {rec["path"] for rec in exclusions}
        all_objects = {str(p.relative_to(ROOT)) for p in ROOT.rglob("*.olean")}
        if all_objects != excluded_paths:
            raise ValueError("Unexpected compiler object requires explicit classification")
        dump(ROOT / "EXCLUDED_COMPILER_OBJECTS.json", {
            "schema_version": 1, "objects": exclusions,
            "count": len(exclusions), "total_bytes": sum(r["bytes"] for r in exclusions),
            "source_or_log_exclusions": [], "objects_deleted": False})
        review_receipt = {
            "schema_version": 1, "status": "PASS", "head": HEAD, "checked_base": BASE,
            "project": analysis["project"], "reviewer": analysis["reviewer"],
            "independent_nonauthor": True,
            "review_disposition": "COMMENT; no mathematical blocker in exact selected closure",
            "formal_github_approve_established": False,
            "remote_mutations": False, "project_source_edits": False,
            "parent_supplied_combined_tree": "8e5190dcb621fc976cd2afbd13dccfa122a25bed",
            "combined_tree_independently_constructed_or_rebuilt_by_reviewer": False,
            "parent_owns_all_incoming_file_and_current_target_publication_checks": True,
            "repository_wide_pass": False,
            "total_fresh_project_builds_by_reviewer": 1,
            "module_compilation_successes": 13,
            "compiler_flags": analysis["compiler_flags"],
            "lean_version": analysis["lean_version"],
            "lean_binary_sha256": analysis["lean_binary_sha256"],
            "audit_summary": analysis["audit_summary"],
            "observed_axiom_union": analysis["observed_axiom_union"],
            "implementation_helpers": {
                "unsafe": 80, "partial": 8,
                "inherited": analysis["inherited_implementation_helpers"],
                "new_adjacentPair_compiler_stages": analysis["new_compiler_stage_helpers"],
                "unsafe_reachable": [], "partial_reachable": [],
                "complete_inventory": "analysis-004/IMPLEMENTATION_INVENTORY.json"},
            "full_types_and_literal_axioms": "analysis-004/PUBLIC_ENDPOINTS.json",
            "all_declarations": "analysis-004/DECLARATIONS.json",
            "complete_proof_dependency_graph": "analysis-004/DEPENDENCY_GRAPH.json",
            "commands_and_raw_logs": "analysis-004/COMMANDS.json",
            "selected_source_identities": "analysis-004/SOURCE_IDENTITIES.json",
            "source_runtime_object_and_log_hashes_unchanged": True,
            "actual_execution_stage_interpretation": {
                "fresh-001": "Overall FAIL retained; all thirteen project compiler commands passed; first reviewer audit failed",
                "audit-002": "FAIL retained; reviewer partial-helper classification error",
                "audit-003": "Overall FAIL retained; Lean audit command exited zero and produced complete output; overly strict postprocessor origin assumption failed",
                "analysis-004": "PASS; existing successful audit output fully validated without executing Lean again"},
            "substantive_artifact_hashes": {
                relative: record(ROOT / relative)
                for relative in ["SEMANTIC_REVIEW.md", "COMMENT_REVIEW_DRAFT.md",
                                 "analysis-004/FINAL_RECEIPT.json",
                                 "analysis-004/PUBLIC_ENDPOINTS.json",
                                 "analysis-004/DECLARATIONS.json",
                                 "analysis-004/DEPENDENCY_GRAPH.json",
                                 "analysis-004/IMPLEMENTATION_INVENTORY.json",
                                 "analysis-004/COMMANDS.json",
                                 "analysis-004/SOURCE_IDENTITIES.json",
                                 "EXCLUDED_COMPILER_OBJECTS.json"]},
            "scope": fresh["scope"],
            "sealed_at": now(),
            "transport_receipt": "delivery/FINAL_PACKET_RECEIPT.json",
            "transport_receipt_is_outside_archive_to_avoid_circular_hash": True,
        }
        dump(ROOT / "REVIEW_RECEIPT.json", review_receipt)
        files = []
        for path in sorted(ROOT.rglob("*")):
            if DELIVERY == path or DELIVERY in path.parents:
                continue
            if path.is_symlink():
                raise ValueError("Symlink not silently archived: " + str(path))
            if not path.is_file():
                continue
            relative = str(path.relative_to(ROOT))
            if relative in excluded_paths:
                continue
            files.append(record(path))
        manifest = {
            "schema_version": 1, "head": HEAD, "checked_base": BASE,
            "created_at": now(), "root_prefix": "review127",
            "content_preservation": "Every listed original byte is stored losslessly",
            "files": files, "file_count": len(files),
            "substantive_bytes": sum(r["bytes"] for r in files),
            "exclusions": {
                "compiler_objects": "EXCLUDED_COMPILER_OBJECTS.json",
                "delivery_wrapper": "Transport derivatives, outer receipt and packaging execution metadata",
                "manifest_self_hash": "This manifest is included as an additional member; its hash is bound by the outer receipt"},
            "source_or_log_exclusions": [],
        }
        dump(ROOT / "ARCHIVE_MANIFEST.json", manifest)
        archive = DELIVERY / "review127-evidence.tar.xz"
        with archive.open("xb") as raw:
            with lzma.LZMAFile(raw, "w", preset=6) as compressed:
                with tarfile.open(fileobj=compressed, mode="w|", format=tarfile.PAX_FORMAT) as tar:
                    for row in [record(ROOT / "ARCHIVE_MANIFEST.json"), *files]:
                        path = ROOT / row["path"]
                        if sha(path) != row["sha256"] or path.stat().st_size != row["bytes"]:
                            raise ValueError("Evidence changed during packing: " + row["path"])
                        tar.add(path, arcname="review127/" + row["path"], recursive=False)
        namespace = {"__name__": "packet_verifier_without_cli"}
        recovery_source = (ROOT / "recover_packet.py").read_text()
        exec(compile(recovery_source, str(ROOT / "recover_packet.py"), "exec"), namespace)
        payload, manifest_raw, verification = namespace["verify"](archive, sha(archive))
        for row in files:
            path = ROOT / row["path"]
            if sha(path) != row["sha256"]:
                raise ValueError("Substantive file changed after packing: " + row["path"])
        encoded = DELIVERY / "review127-evidence.tar.xz.base64"
        data = archive.read_bytes()
        with encoded.open("xb") as stream:
            stream.write(base64.encodebytes(data))
        if base64.b64decode(encoded.read_bytes(), validate=False) != data:
            raise ValueError("Base64 round trip changed archive")
        for name in ["recover_packet.py", "RECOVERY.md"]:
            with (DELIVERY / name).open("xb") as stream:
                stream.write((ROOT / name).read_bytes())
        result.update(
            status="PASS",
            archive=record(archive),
            base64=record(encoded),
            recovery_script=record(DELIVERY / "recover_packet.py"),
            recovery_instructions=record(DELIVERY / "RECOVERY.md"),
            inner_manifest=record(ROOT / "ARCHIVE_MANIFEST.json"),
            review_receipt=record(ROOT / "REVIEW_RECEIPT.json"),
            semantic_report=record(ROOT / "SEMANTIC_REVIEW.md"),
            comment_review_draft=record(ROOT / "COMMENT_REVIEW_DRAFT.md"),
            excluded_compiler_objects=record(ROOT / "EXCLUDED_COMPILER_OBJECTS.json"),
            excluded_compiler_object_count=len(exclusions),
            excluded_compiler_object_bytes=sum(r["bytes"] for r in exclusions),
            all_substantive_files_round_trip_verified=True,
            base64_round_trip_verified=True,
            archive_verification=verification,
            all_preserved_original_evidence_hashes_unchanged_after_packing=True,
            archive_root="review127/",
            total_reviewer_regular_file_bytes=sum(p.stat().st_size for p in ROOT.rglob("*") if p.is_file()),
            selected_mathematical_result="PASS",
            publication_and_integration_performed_by_reviewer=False,
        )
    except Exception as exc:
        result.update(status="FAIL", failure=str(exc))
        with (DELIVERY / "failure.txt").open("x") as stream:
            stream.write(traceback.format_exc())
    finally:
        result["finished_at"] = now()
        dump(DELIVERY / "FINAL_PACKET_RECEIPT.json", result)
        print(json.dumps(result, indent=2))
    return 0 if result["status"] == "PASS" else 1

if __name__ == "__main__":
    raise SystemExit(main())
