#!/usr/bin/env python3
"""One fresh thirteen-module PR #127 build and exhaustive checked-declaration audit.

Operational reviewer code only. No accepted source is edited, no old object is
copied, and no remote action is performed. Every command and failure is retained.
The unchanged inspected canonical verifier supplies its comment/string masker.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / "inputs"
PACKAGE = INPUTS / "project"
ORIGINAL_PACKAGE = Path("/workspace/scratch/6124a6476634/evidence/pr127-incoming/proofs/contributions/agent-7/allbase-overflow-births-20261016")
LEAN = Path("/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean")
PIN = "92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023"
VERIFIER_PIN = "c047ff1ff1fe12b2c2094ca5f36af871b1c6faf89db593a102f9c2f7d48cc98a"
HEAD = "c68b0aaa5344f2cc646c035e2efca187852cb57d"
BASE = "1ee9123344dbe17e9bda224ff8af5b1cbb2b64e4"
ALLOWED = {"propext", "Classical.choice", "Quot.sound"}
FLAGS = ["--trust=0", "-j1", "-DElab.async=false"]
PROJECT = "agent7-allbase-overflow-births"
ATTEMPT = ROOT / "audit-002"

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def stamp():
    return datetime.now(timezone.utc).isoformat()

def write_new(path, text):
    with Path(path).open("x", encoding="utf-8") as out:
        out.write(text)

def main():
    ATTEMPT.mkdir(exist_ok=False)
    source = ROOT / "fresh-001/source"
    logs = ATTEMPT / "logs"; logs.mkdir()
    (ATTEMPT / "tmp").mkdir()
    report = {
        "schema_version": 1, "reviewer": "Agent #13 /root/review127",
        "status": "RUNNING", "started_at": stamp(),
        "head": HEAD, "checked_base": BASE, "project": PROJECT,
        "independent_nonauthor": True,
        "source_edits": False, "remote_mutations": False,
        "repository_wide_pass": False,
        "fresh_project_objects": False, "historical_project_objects_imported": False,
        "fresh_project_compilation_this_execution": False,
        "audit_only_continuation": True,
        "project_fresh_compilation_complete": False,
        "parent_handles_combined_tree_and_incoming_publication_checks": True,
        "prior_theorem_count_comparison_only": 338,
        "compiler_flags": FLAGS, "commands": [], "source_records": {},
        "invocation": [sys.executable, *sys.argv],
        "resource_policy": {
            "storage": "Authorized exclusive reviewer directory in parent-approved tmpfs",
            "parent_total_artifact_budget_bytes": 536870912,
            "reviewer_soft_artifact_budget_bytes": 134217728,
            "per_process_timeout_seconds": 1800,
            "compiler_jobs": 1,
        },
    }
    events = ATTEMPT / "events.jsonl"
    def event(kind, **fields):
        row = {"time": stamp(), "kind": kind, **fields}
        with events.open("a", encoding="utf-8") as out:
            out.write(json.dumps(row) + "\n")
        print(json.dumps(row), flush=True)
    def save():
        number = len(list(ATTEMPT.glob("state-*.json")))
        write_new(ATTEMPT / ("state-%04d.json" % number), json.dumps(report, indent=2) + "\n")
    env = {
        "PATH": str(LEAN.parent) + ":/usr/bin:/bin",
        "LANG": "C.UTF-8",
        "LEAN_PATH": str(source),
        "TMPDIR": str(ATTEMPT / "tmp"),
    }
    report["compiler_environment"] = env
    def run(label, argv, cwd=source, timeout=1800):
        ordinal = len(report["commands"])
        outpath = logs / ("%02d-%s.stdout" % (ordinal, label))
        errpath = logs / ("%02d-%s.stderr" % (ordinal, label))
        command = {
            "label": label, "argv": list(map(str, argv)), "cwd": str(cwd),
            "started_at": stamp(), "timeout_seconds": timeout,
            "stdout": str(outpath.relative_to(ROOT)),
            "stderr": str(errpath.relative_to(ROOT)),
            "status": "RUNNING",
        }
        report["commands"].append(command)
        save(); event("command_started", label=label, argv=command["argv"])
        start = time.monotonic()
        with outpath.open("xb") as out, errpath.open("xb") as err:
            try:
                proc = subprocess.run(command["argv"], cwd=cwd, env=env,
                                      stdout=out, stderr=err, timeout=timeout)
                code = proc.returncode
            except subprocess.TimeoutExpired:
                code = 124
                command["timed_out"] = True
        command.update(
            exit_code=code, status="PASSED" if code == 0 else "FAILED",
            finished_at=stamp(), elapsed_seconds=time.monotonic() - start,
            stdout_sha256=sha(outpath), stderr_sha256=sha(errpath),
            stdout_bytes=outpath.stat().st_size, stderr_bytes=errpath.stat().st_size,
        )
        save(); event("command_finished", label=label, exit_code=code)
        if code:
            raise RuntimeError("Command failed: %s, exit=%s; raw logs retained" % (label, code))
        return outpath.read_text(encoding="utf-8")
    try:
        previous_path = ROOT / "fresh-001/FINAL_RECEIPT.json"
        previous = json.loads(previous_path.read_text())
        if previous["status"] != "FAIL" or not previous["project_fresh_compilation_complete"]:
            raise ValueError("Continuation requires a retained complete fresh project build and audit-only failure")
        if previous["head"] != HEAD or previous["checked_base"] != BASE:
            raise ValueError("Prior source identity changed")
        if previous["commands"][-1]["label"] != "IndependentAudit" or previous["commands"][-1]["exit_code"] == 0:
            raise ValueError("Prior failure is not confined to the reviewer audit")
        report["inherited_project_compilation"] = {
            "execution": str(previous_path.relative_to(ROOT)),
            "receipt_sha256": sha(previous_path),
            "source": "The single fresh thirteen-module build performed by this reviewer in fresh-001",
            "prior_overall_status": previous["status"],
            "fresh_build_success_is_separate_from_failed_audit": True,
            "project_objects_copied_in_this_continuation": False,
            "failed_audit_object_imported": False,
            "commands": [c for c in previous["commands"] if c["label"] in previous["build_order"]],
        }
        report["source_records"] = previous["source_records"]
        report["scope"] = previous["scope"]
        report["registry_sha256"] = previous["registry_sha256"]
        report["dependency_source_pins_sha256"] = previous["dependency_source_pins_sha256"]
        report["build_order"] = previous["build_order"]
        report["roots"] = previous["roots"]
        endpoints = previous["endpoints"]
        order = previous["build_order"]
        dependencies = {m for m,r in previous["source_records"].items() if r["inherited_dependency"]}
        report["endpoints"] = endpoints
        report["lean_version"] = previous["lean_version"]
        report["runtime_prefix"] = previous["runtime_prefix"]
        report["project_fresh_compilation_complete"] = True
        project_commands = report["inherited_project_compilation"]["commands"]
        if len(project_commands) != 13 or any(c["exit_code"] != 0 for c in project_commands):
            raise ValueError("Incomplete prior fresh project compilation")
        for c in project_commands:
            if any(flag not in c["argv"] for flag in FLAGS):
                raise ValueError("Prior command lost required trust/resource flags")
            if sha(ROOT / c["stdout"]) != c["stdout_sha256"] or sha(ROOT / c["stderr"]) != c["stderr_sha256"]:
                raise ValueError("Prior raw command log changed")
        for module,rec in report["source_records"].items():
            if sha(source / (module + ".lean")) != rec["sha256"]:
                raise ValueError("Prior project source changed")
            if sha(source / (module + ".olean")) != rec["object_sha256"]:
                raise ValueError("Prior fresh project object changed")
        runtime_files = [Path(p) for p in previous["runtime_files_before"]]
        report["runtime_files_before"] = {str(p): sha(p) for p in runtime_files}
        if report["runtime_files_before"] != previous["runtime_files_before"] or sha(LEAN) != PIN:
            raise ValueError("Runtime changed since fresh compilation")
        old_audit = source / "IndependentAudit.lean"
        if sha(old_audit) != previous["audit_source_sha256"]:
            raise ValueError("Failed audit source was not preserved")
        wrong = "(fun acc rule => acc ++ rule.rhs.getUsedConstantsAsSet) initial"
        fixed = "(fun (acc : NameSet) (rule : RecursorRule) => acc ++ rule.rhs.getUsedConstantsAsSet) initial"
        text = old_audit.read_text()
        if text.count(wrong) != 1:
            raise ValueError("Expected unique audit-only type annotation repair")
        audit_source = ATTEMPT / "IndependentAudit002.lean"
        write_new(audit_source, text.replace(wrong, fixed))
        report["audit_source_sha256"] = sha(audit_source)
        report["audit_source_path"] = str(audit_source.relative_to(ROOT))
        report["runner_sha256_before"] = sha(Path(__file__))
        report["audit_only_repair"] = {
            "before_source": str(old_audit.relative_to(ROOT)),
            "before_sha256": sha(old_audit),
            "after_source": str(audit_source.relative_to(ROOT)),
            "after_sha256": sha(audit_source),
            "change": "Explicit NameSet accumulator and RecursorRule parameter types in dependency extraction; no accepted source or proof changed",
            "first_error": "invalid field notation: rule has unresolved type ?m.302",
            "rejected_evaluation_note": "Lean aborted operational audit evaluation after elaboration recovery; no #eval! bypass was attempted",
        }
        save()
        audit_text = run("IndependentAudit002", [LEAN, *FLAGS, str(audit_source)])
        declaration_rows = [json.loads(line[len("DECL_JSON "):])
                            for line in audit_text.splitlines() if line.startswith("DECL_JSON ")]
        graph_rows = [json.loads(line[len("GRAPH_JSON "):])
                      for line in audit_text.splitlines() if line.startswith("GRAPH_JSON ")]
        summaries = [json.loads(line[len("AUDIT_SUMMARY_JSON "):])
                     for line in audit_text.splitlines() if line.startswith("AUDIT_SUMMARY_JSON ")]
        if len(summaries) != 1 or not declaration_rows or not graph_rows:
            raise ValueError("Missing exhaustive audit output")
        summary = summaries[0]
        declarations = {r["name"]: r for r in declaration_rows}
        graph = {r["name"]: r for r in graph_rows}
        if len(declarations) != len(declaration_rows) or len(graph) != len(graph_rows):
            raise ValueError("Duplicate declaration or graph record")
        if summary["module_origin_constants"] != len(declarations):
            raise ValueError("Module-origin count differs from records")
        if summary["reachable_dependency_constants"] != len(graph):
            raise ValueError("Dependency count differs from records")
        if set(r["module"] for r in declaration_rows) != set(order):
            raise ValueError("Missing module-origin coverage")
        if summary["module_origin_theorems"] != sum(r["kind"] == "theorem" for r in declaration_rows):
            raise ValueError("Theorem count mismatch")
        if summary["module_origin_safe_definitions"] != sum(r["kind"] == "definition" and not r["unsafe"] for r in declaration_rows):
            raise ValueError("Safe definition count mismatch")
        if set(r["name"] for r in declaration_rows if r["public_endpoint"]) != set(endpoints):
            raise ValueError("Public endpoint type audit incomplete")
        for row in declaration_rows:
            if "\u22ef" in row["type"]:
                raise ValueError("Pretty-printer omitted part of full type: " + row["name"])
            if not row["unsafe"] and not set(row["axioms"]) <= ALLOWED:
                raise ValueError("Forbidden axiom in audited safe declaration")
        literal = re.findall(r"^'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", audit_text, re.M)
        literal_dict = {name: [a.strip() for a in text.split(",") if a.strip()] for name, text in literal}
        if len(literal) != len(endpoints) or set(literal_dict) != set(endpoints):
            raise ValueError("Literal public #print axioms coverage is incomplete or duplicated")
        for name, axioms in literal_dict.items():
            if set(axioms) != set(declarations[name]["axioms"]) or not set(axioms) <= ALLOWED:
                raise ValueError("Literal and programmatic axiom reports disagree: " + name)
        for name, row in graph.items():
            if row["unsafe"] or row["partial"]:
                raise ValueError("Unsafe or partial reachable declaration: " + name)
            if any(dep not in graph for dep in row["dependencies"]):
                raise ValueError("Incomplete transitive dependency graph: " + name)
        safe_roots = {r["name"] for r in declaration_rows if not r["unsafe"]}
        reached = set(); todo = list(safe_roots)
        while todo:
            name = todo.pop()
            if name in reached: continue
            reached.add(name); todo.extend(graph[name]["dependencies"])
        if reached != set(graph):
            raise ValueError("Exported graph is not exactly the safe-root dependency closure")
        unsafe = [r for r in declaration_rows if r["unsafe"]]
        if any(r["module"] not in dependencies for r in unsafe):
            raise ValueError("Unexpected newly originated unsafe implementation constant")
        if any(r["name"] in reached for r in unsafe):
            raise ValueError("Unsafe implementation helper feeds accepted safe roots")
        union = sorted(set().union(*(set(r["axioms"]) for r in declaration_rows if not r["unsafe"])))
        if set(summary["axiom_union"]) != set(union):
            raise ValueError("Axiom union mismatch")
        write_new(ATTEMPT / "DECLARATIONS.json", json.dumps(declaration_rows, indent=2) + "\n")
        write_new(ATTEMPT / "DEPENDENCY_GRAPH.json", json.dumps(graph_rows, indent=2) + "\n")
        write_new(ATTEMPT / "PUBLIC_ENDPOINTS.json", json.dumps([
            {**declarations[e], "literal_axioms": literal_dict[e]} for e in endpoints], indent=2) + "\n")
        write_new(ATTEMPT / "UNSAFE_IMPLEMENTATION_INVENTORY.json", json.dumps(unsafe, indent=2) + "\n")
        for module, rec in report["source_records"].items():
            relative = rec["repository_path"].split("/allbase-overflow-births-20261016/", 1)[1]
            if sha(PACKAGE / relative) != rec["sha256"] or sha(ORIGINAL_PACKAGE / relative) != rec["sha256"]:
                raise ValueError("Source changed during verification: " + module)
            if sha(source / (module + ".lean")) != rec["sha256"]:
                raise ValueError("Compile source changed during verification: " + module)
            if sha(source / (module + ".olean")) != rec["object_sha256"]:
                raise ValueError("Project object changed during audit: " + module)
        report["runtime_files_after"] = {str(p): sha(p) for p in runtime_files}
        if report["runtime_files_after"] != report["runtime_files_before"]:
            raise ValueError("Runtime changed during verification")
        if sha(Path(__file__)) != report["runner_sha256_before"]:
            raise ValueError("Runner changed during verification")
        if sha(audit_source) != report["audit_source_sha256"]:
            raise ValueError("Audit source changed during verification")
        report.update(
            status="PASS", audit_summary=summary, observed_axiom_union=union,
            public_endpoint_count=len(endpoints),
            module_origin_counts={module: {
                "all_constants": sum(r["module"] == module for r in declaration_rows),
                "theorems": sum(r["module"] == module and r["kind"] == "theorem" for r in declaration_rows),
                "safe_definitions": sum(r["module"] == module and r["kind"] == "definition" and not r["unsafe"] for r in declaration_rows),
                "unsafe_constants": sum(r["module"] == module and r["unsafe"] for r in declaration_rows),
            } for module in order},
            unsafe_implementation_constants=[r["name"] for r in unsafe],
            unsafe_helpers_reachable_from_safe_roots=[],
            prior_theorem_count_equal=(summary["module_origin_theorems"] == 338),
            source_before_after_unchanged=True, runtime_before_after_unchanged=True,
        )
    except Exception as exc:
        report.update(status="FAIL", failure=str(exc))
        write_new(ATTEMPT / "failure.txt", traceback.format_exc())
        event("failure", message=str(exc))
    finally:
        report["finished_at"] = stamp()
        save()
        write_new(ATTEMPT / "FINAL_RECEIPT.json", json.dumps(report, indent=2) + "\n")
        event("completed", status=report["status"],
              project_fresh_compilation_complete=report["project_fresh_compilation_complete"])
    return 0 if report["status"] == "PASS" else 1

if __name__ == "__main__":
    raise SystemExit(main())
