#!/usr/bin/env python3
"""One fresh thirteen-module PR #127 build and exhaustive checked-declaration audit.

Operational reviewer code only. No accepted source is edited, no old object is
copied, and no remote action is performed. Every command and failure is retained.
The unchanged inspected canonical verifier supplies its comment/string masker.
"""
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import runpy
import subprocess
import sys
import time
import traceback

ROOT = Path(__file__).resolve().parent
INPUTS = ROOT / "inputs"
PACKAGE = INPUTS / "project"
ORIGINAL_PACKAGE = Path("/workspace/scratch/6124a6476634/evidence/pr127-incoming/proofs/contributions/agent-7/allbase-overflow-births-20261016")
LEAN = Path("/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean")
PIN = "92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023"
VERIFIER_PIN = "c047ff1ff1fe12b2c2094ca5f36af871b1c6faf89db593a102f9c2f7d48cc98a"
HEAD = "c68b0aaa5344f2cc646c035e2efca187852cb57d"
BASE = "1ee9123344dbe17e9bda224ff8af5b1cbb2b64e4"
ALLOWED = {"propext", "Classical.choice", "Quot.sound"}
FLAGS = ["--trust=0", "-j1", "-DElab.async=false"]
PROJECT = "agent7-allbase-overflow-births"
ATTEMPT = ROOT / "fresh-001"

def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def stamp():
    return datetime.now(timezone.utc).isoformat()

def write_new(path, text):
    with Path(path).open("x", encoding="utf-8") as out:
        out.write(text)

def main():
    ATTEMPT.mkdir(exist_ok=False)
    source = ATTEMPT / "source"; source.mkdir()
    logs = ATTEMPT / "logs"; logs.mkdir()
    (ATTEMPT / "tmp").mkdir()
    report = {
        "schema_version": 1, "reviewer": "Agent #13 /root/review127",
        "status": "RUNNING", "started_at": stamp(),
        "head": HEAD, "checked_base": BASE, "project": PROJECT,
        "independent_nonauthor": True,
        "source_edits": False, "remote_mutations": False,
        "repository_wide_pass": False,
        "fresh_project_objects": True, "historical_project_objects_imported": False,
        "project_fresh_compilation_complete": False,
        "parent_handles_combined_tree_and_incoming_publication_checks": True,
        "prior_theorem_count_comparison_only": 338,
        "compiler_flags": FLAGS, "commands": [], "source_records": {},
        "invocation": [sys.executable, *sys.argv],
        "resource_policy": {
            "storage": "Authorized exclusive reviewer directory in parent-approved tmpfs",
            "parent_total_artifact_budget_bytes": 536870912,
            "reviewer_soft_artifact_budget_bytes": 134217728,
            "per_process_timeout_seconds": 1800,
            "compiler_jobs": 1,
        },
    }
    events = ATTEMPT / "events.jsonl"
    def event(kind, **fields):
        row = {"time": stamp(), "kind": kind, **fields}
        with events.open("a", encoding="utf-8") as out:
            out.write(json.dumps(row) + "\n")
        print(json.dumps(row), flush=True)
    def save():
        number = len(list(ATTEMPT.glob("state-*.json")))
        write_new(ATTEMPT / ("state-%04d.json" % number), json.dumps(report, indent=2) + "\n")
    env = {
        "PATH": str(LEAN.parent) + ":/usr/bin:/bin",
        "LANG": "C.UTF-8",
        "LEAN_PATH": str(source),
        "TMPDIR": str(ATTEMPT / "tmp"),
    }
    report["compiler_environment"] = env
    def run(label, argv, cwd=source, timeout=1800):
        ordinal = len(report["commands"])
        outpath = logs / ("%02d-%s.stdout" % (ordinal, label))
        errpath = logs / ("%02d-%s.stderr" % (ordinal, label))
        command = {
            "label": label, "argv": list(map(str, argv)), "cwd": str(cwd),
            "started_at": stamp(), "timeout_seconds": timeout,
            "stdout": str(outpath.relative_to(ROOT)),
            "stderr": str(errpath.relative_to(ROOT)),
            "status": "RUNNING",
        }
        report["commands"].append(command)
        save(); event("command_started", label=label, argv=command["argv"])
        start = time.monotonic()
        with outpath.open("xb") as out, errpath.open("xb") as err:
            try:
                proc = subprocess.run(command["argv"], cwd=cwd, env=env,
                                      stdout=out, stderr=err, timeout=timeout)
                code = proc.returncode
            except subprocess.TimeoutExpired:
                code = 124
                command["timed_out"] = True
        command.update(
            exit_code=code, status="PASSED" if code == 0 else "FAILED",
            finished_at=stamp(), elapsed_seconds=time.monotonic() - start,
            stdout_sha256=sha(outpath), stderr_sha256=sha(errpath),
            stdout_bytes=outpath.stat().st_size, stderr_bytes=errpath.stat().st_size,
        )
        save(); event("command_finished", label=label, exit_code=code)
        if code:
            raise RuntimeError("Command failed: %s, exit=%s; raw logs retained" % (label, code))
        return outpath.read_text(encoding="utf-8")
    try:
        if sha(LEAN) != PIN:
            raise ValueError("Pinned Lean executable changed")
        verifier = INPUTS / "canonical_verifier.py"
        if sha(verifier) != VERIFIER_PIN:
            raise ValueError("Inspected canonical verifier identity changed")
        reference = runpy.run_path(str(verifier), run_name="review127_inspected_reference")
        code_only = reference["code_only"]
        registry_path = PACKAGE / "PROJECT_REGISTRY.json"
        registry = json.loads(registry_path.read_text())
        report["registry_sha256"] = sha(registry_path)
        if sha(registry_path) != "138fc4ac68beb8188812db092aae722476475dbb9644eb2e03d586fa5d6e733e":
            raise ValueError("Frozen registry changed")
        spec = registry["projects"][PROJECT]
        if registry["toolchain"]["allowed_axioms"] != ["propext", "Classical.choice", "Quot.sound"]:
            raise ValueError("Unexpected axiom policy")
        report["scope"] = spec["scope"]
        pins_path = PACKAGE / "dependencies/SOURCE_PINS.json"
        pins = json.loads(pins_path.read_text())
        report["dependency_source_pins_sha256"] = sha(pins_path)
        dependencies = {r["module"]: r for r in pins["dependencies"]}
        endpoints = [e for c in registry["claims"] if c["project"] == PROJECT for e in c["endpoints"]]
        if len(endpoints) != len(set(endpoints)):
            raise ValueError("Duplicate registered endpoint")
        records = spec["modules"]
        if len(records) != 13:
            raise ValueError("Unexpected selected project module count")
        imports = {}; actual_new_public = []
        for module, rec in records.items():
            relative = rec["path"].split("/allbase-overflow-births-20261016/", 1)[1]
            retained = PACKAGE / relative
            original = ORIGINAL_PACKAGE / relative
            data = retained.read_bytes()
            if original.read_bytes() != data:
                raise ValueError("Original source changed after read-only identity check: " + module)
            digest = hashlib.sha256(data).hexdigest()
            blob = hashlib.sha1(("blob %d\0" % len(data)).encode() + data).hexdigest()
            if digest != rec["sha256"] or blob != rec["git_blob"]:
                raise ValueError("Registry source identity mismatch: " + module)
            if module in dependencies:
                pin = dependencies[module]
                if digest != pin["sha256"] or blob != pin["original_git_blob"] or len(data) != pin["bytes"]:
                    raise ValueError("Original dependency pin mismatch: " + module)
            code = code_only(data.decode("utf-8"))
            forbidden = re.search(r"(?<![\w'])\b(?:sorry|admit|axiom|sorryAx|native_decide|ofReduceBool|skipKernelTC|unsafe|partial)\b(?![\w'])", code)
            if forbidden:
                raise ValueError("Forbidden source token in %s: %s" % (module, forbidden.group()))
            observed = [d for line in re.findall(r"^\s*import\s+([^\n]+)", code, re.M) for d in line.split()]
            if observed != rec["imports"]:
                raise ValueError("Registry import mismatch: " + module)
            if any(d not in records and d != "Std" for d in observed):
                raise ValueError("Unexpected external proof import: " + module)
            imports[module] = observed
            spaces = re.findall(r"^namespace\s+(\S+)", code, re.M)
            if len(spaces) != 1:
                raise ValueError("Unexpected namespace structure: " + module)
            names = re.findall(r"^(?:theorem|lemma)\s+([A-Za-z_][\w.]*)", code, re.M)
            public_names = [spaces[0] + "." + n for n in names]
            if module not in dependencies:
                actual_new_public.extend(public_names)
            (source / (module + ".lean")).write_bytes(data)
            report["source_records"][module] = {
                "repository_path": rec["path"], "snapshot_path": str(retained.relative_to(ROOT)),
                "compile_path": str((source / (module + ".lean")).relative_to(ROOT)),
                "bytes": len(data), "sha256": digest, "git_blob": blob,
                "imports": observed, "public_theorems": public_names,
                "inherited_dependency": module in dependencies,
            }
        if set(actual_new_public) != set(endpoints) or len(actual_new_public) != len(endpoints):
            raise ValueError("Registry does not enumerate exactly the new public theorems")
        order = []; active = set(); seen = set()
        def visit(module):
            if module not in records: return
            if module in active: raise ValueError("Import cycle: " + module)
            if module in seen: return
            active.add(module)
            for dependency in imports[module]: visit(dependency)
            active.remove(module); seen.add(module); order.append(module)
        for module in spec["roots"]: visit(module)
        if seen != set(records):
            raise ValueError("Selected root closure is not exactly the registry")
        if list(source.glob("*.olean")):
            raise ValueError("Fresh source directory already contains project objects")
        report.update(build_order=order, roots=spec["roots"], endpoints=endpoints,
                      fresh_object_count_at_start=0,
                      canonical_verifier_source_sha256=VERIFIER_PIN,
                      masker_reuse="Only inspected code_only; canonical build main is not called")
        audit_template = (ROOT / "AuditTemplate.lean").read_text()
        audit = audit_template.replace("SELECTED_MODULES", json.dumps(order))
        audit = audit.replace("ENDPOINT_NAMES", json.dumps(endpoints))
        audit = audit.replace("PUBLIC_CHECKS", "\n".join(
            "#check " + e + "\n#print axioms " + e for e in endpoints))
        (source / "IndependentAudit.lean").write_text(audit)
        report["audit_source_sha256"] = sha(source / "IndependentAudit.lean")
        runtime = LEAN.parent.parent
        runtime_files = [LEAN, *sorted((runtime / "lib/lean").glob("*.so")),
                         runtime / "lib/lean/Std.olean", runtime / "lib/lean/Lean.olean"]
        report["runtime_files_before"] = {str(p): sha(p) for p in runtime_files}
        report["runner_sha256_before"] = sha(Path(__file__))
        save()
        version = run("lean-version", [LEAN, "--version"], timeout=60).strip()
        if "version 4.19.0," not in version or "commit 6caaee842e94, Release" not in version:
            raise ValueError("Unexpected Lean version")
        report["lean_version"] = version
        prefix = run("lean-prefix", [LEAN, "--print-prefix"], timeout=60).strip()
        if Path(prefix).resolve() != runtime.resolve():
            raise ValueError("Runtime prefix differs from pinned installation")
        report["runtime_prefix"] = prefix
        for module in order:
            run(module, [LEAN, *FLAGS, "-o", module + ".olean", module + ".lean"])
            obj = source / (module + ".olean")
            report["source_records"][module]["object_sha256"] = sha(obj)
            report["source_records"][module]["object_bytes"] = obj.stat().st_size
            report["source_records"][module]["object_origin"] = "Freshly compiled in fresh-001 by this reviewer"
        report["project_fresh_compilation_complete"] = True
        save()
        audit_text = run("IndependentAudit", [LEAN, *FLAGS, "IndependentAudit.lean"])
        declaration_rows = [json.loads(line[len("DECL_JSON "):])
                            for line in audit_text.splitlines() if line.startswith("DECL_JSON ")]
        graph_rows = [json.loads(line[len("GRAPH_JSON "):])
                      for line in audit_text.splitlines() if line.startswith("GRAPH_JSON ")]
        summaries = [json.loads(line[len("AUDIT_SUMMARY_JSON "):])
                     for line in audit_text.splitlines() if line.startswith("AUDIT_SUMMARY_JSON ")]
        if len(summaries) != 1 or not declaration_rows or not graph_rows:
            raise ValueError("Missing exhaustive audit output")
        summary = summaries[0]
        declarations = {r["name"]: r for r in declaration_rows}
        graph = {r["name"]: r for r in graph_rows}
        if len(declarations) != len(declaration_rows) or len(graph) != len(graph_rows):
            raise ValueError("Duplicate declaration or graph record")
        if summary["module_origin_constants"] != len(declarations):
            raise ValueError("Module-origin count differs from records")
        if summary["reachable_dependency_constants"] != len(graph):
            raise ValueError("Dependency count differs from records")
        if set(r["module"] for r in declaration_rows) != set(order):
            raise ValueError("Missing module-origin coverage")
        if summary["module_origin_theorems"] != sum(r["kind"] == "theorem" for r in declaration_rows):
            raise ValueError("Theorem count mismatch")
        if summary["module_origin_safe_definitions"] != sum(r["kind"] == "definition" and not r["unsafe"] for r in declaration_rows):
            raise ValueError("Safe definition count mismatch")
        if set(r["name"] for r in declaration_rows if r["public_endpoint"]) != set(endpoints):
            raise ValueError("Public endpoint type audit incomplete")
        for row in declaration_rows:
            if "\u22ef" in row["type"]:
                raise ValueError("Pretty-printer omitted part of full type: " + row["name"])
            if not row["unsafe"] and not set(row["axioms"]) <= ALLOWED:
                raise ValueError("Forbidden axiom in audited safe declaration")
        literal = re.findall(r"^'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|does not depend on any axioms)", audit_text, re.M)
        literal_dict = {name: [a.strip() for a in text.split(",") if a.strip()] for name, text in literal}
        if len(literal) != len(endpoints) or set(literal_dict) != set(endpoints):
            raise ValueError("Literal public #print axioms coverage is incomplete or duplicated")
        for name, axioms in literal_dict.items():
            if set(axioms) != set(declarations[name]["axioms"]) or not set(axioms) <= ALLOWED:
                raise ValueError("Literal and programmatic axiom reports disagree: " + name)
        for name, row in graph.items():
            if row["unsafe"] or row["partial"]:
                raise ValueError("Unsafe or partial reachable declaration: " + name)
            if any(dep not in graph for dep in row["dependencies"]):
                raise ValueError("Incomplete transitive dependency graph: " + name)
        safe_roots = {r["name"] for r in declaration_rows if not r["unsafe"]}
        reached = set(); todo = list(safe_roots)
        while todo:
            name = todo.pop()
            if name in reached: continue
            reached.add(name); todo.extend(graph[name]["dependencies"])
        if reached != set(graph):
            raise ValueError("Exported graph is not exactly the safe-root dependency closure")
        unsafe = [r for r in declaration_rows if r["unsafe"]]
        if any(r["module"] not in dependencies for r in unsafe):
            raise ValueError("Unexpected newly originated unsafe implementation constant")
        if any(r["name"] in reached for r in unsafe):
            raise ValueError("Unsafe implementation helper feeds accepted safe roots")
        union = sorted(set().union(*(set(r["axioms"]) for r in declaration_rows if not r["unsafe"])))
        if set(summary["axiom_union"]) != set(union):
            raise ValueError("Axiom union mismatch")
        write_new(ATTEMPT / "DECLARATIONS.json", json.dumps(declaration_rows, indent=2) + "\n")
        write_new(ATTEMPT / "DEPENDENCY_GRAPH.json", json.dumps(graph_rows, indent=2) + "\n")
        write_new(ATTEMPT / "PUBLIC_ENDPOINTS.json", json.dumps([
            {**declarations[e], "literal_axioms": literal_dict[e]} for e in endpoints], indent=2) + "\n")
        write_new(ATTEMPT / "UNSAFE_IMPLEMENTATION_INVENTORY.json", json.dumps(unsafe, indent=2) + "\n")
        for module, rec in report["source_records"].items():
            relative = rec["repository_path"].split("/allbase-overflow-births-20261016/", 1)[1]
            if sha(PACKAGE / relative) != rec["sha256"] or sha(ORIGINAL_PACKAGE / relative) != rec["sha256"]:
                raise ValueError("Source changed during verification: " + module)
            if sha(source / (module + ".lean")) != rec["sha256"]:
                raise ValueError("Compile source changed during verification: " + module)
            if sha(source / (module + ".olean")) != rec["object_sha256"]:
                raise ValueError("Project object changed during audit: " + module)
        report["runtime_files_after"] = {str(p): sha(p) for p in runtime_files}
        if report["runtime_files_after"] != report["runtime_files_before"]:
            raise ValueError("Runtime changed during verification")
        if sha(Path(__file__)) != report["runner_sha256_before"]:
            raise ValueError("Runner changed during verification")
        if sha(source / "IndependentAudit.lean") != report["audit_source_sha256"]:
            raise ValueError("Audit source changed during verification")
        report.update(
            status="PASS", audit_summary=summary, observed_axiom_union=union,
            public_endpoint_count=len(endpoints),
            module_origin_counts={module: {
                "all_constants": sum(r["module"] == module for r in declaration_rows),
                "theorems": sum(r["module"] == module and r["kind"] == "theorem" for r in declaration_rows),
                "safe_definitions": sum(r["module"] == module and r["kind"] == "definition" and not r["unsafe"] for r in declaration_rows),
                "unsafe_constants": sum(r["module"] == module and r["unsafe"] for r in declaration_rows),
            } for module in order},
            unsafe_implementation_constants=[r["name"] for r in unsafe],
            unsafe_helpers_reachable_from_safe_roots=[],
            prior_theorem_count_equal=(summary["module_origin_theorems"] == 338),
            source_before_after_unchanged=True, runtime_before_after_unchanged=True,
        )
    except Exception as exc:
        report.update(status="FAIL", failure=str(exc))
        write_new(ATTEMPT / "failure.txt", traceback.format_exc())
        event("failure", message=str(exc))
    finally:
        report["finished_at"] = stamp()
        save()
        write_new(ATTEMPT / "FINAL_RECEIPT.json", json.dumps(report, indent=2) + "\n")
        event("completed", status=report["status"],
              project_fresh_compilation_complete=report["project_fresh_compilation_complete"])
    return 0 if report["status"] == "PASS" else 1

if __name__ == "__main__":
    raise SystemExit(main())
