import CanonicalOverflowBirths
import Lean

/-!
Independent operational audit for the exact thirteen-module PR #127 closure.
This file does not change or replace any accepted mathematical declaration.
It enumerates module origins, uses the checked kernel environment, audits
safe declarations and literal public endpoints, and exports a dependency graph.
-/

open Lean Elab Command

set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
set_option pp.all true
set_option pp.maxSteps 1000000

namespace Review127Audit

def kind (ci : ConstantInfo) : String :=
  match ci with
  | .axiomInfo _ => "axiom"
  | .defnInfo _ => "definition"
  | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "constructor"
  | .recInfo _ => "recursor"

def dependencies (ci : ConstantInfo) : List Name :=
  let initial := ci.getUsedConstantsAsSet
  let complete :=
    match ci with
    | .recInfo val => val.rules.foldl
        (fun (acc : NameSet) (rule : RecursorRule) => acc ++ rule.rhs.getUsedConstantsAsSet) initial
    | _ => initial
  complete.toList

end Review127Audit

run_cmd do
  let env ← getEnv
  let selected : List String := ["BaseBirths", "SignedDigitUniqueness", "BaseReflection", "ResetNormalization", "AdjacentBirths", "PhysicalWidth", "SeamSafety", "ReverseAdd", "ActualBaseBirths", "OverflowDigits", "ActualOverflowBirths", "OverflowEndpoints", "CanonicalOverflowBirths"]
  let endpointNames : List String := ["P196.Agent7.AllBaseOverflow.residue_zero_iff", "P196.Agent7.AllBaseOverflow.residue_max_iff", "P196.Agent7.AllBaseOverflow.adjacent_residues_zero_iff", "P196.Agent7.AllBaseOverflow.adjacent_residues_max_iff", "P196.Agent7.AllBaseOverflow.adjacentPair_zero_iff", "P196.Agent7.AllBaseOverflow.adjacentPair_max_iff", "P196.Agent7.AllBaseOverflow.adjacent_new_extreme_neutral", "P196.Agent7.AllBaseOverflow.adjacent_without_neutral", "P196.Agent7.AllBaseOverflow.ordinary_terminal_take_succ", "P196.Agent7.AllBaseOverflow.incoming_succ", "P196.Agent7.AllBaseOverflow.incoming_predecessor", "P196.Agent7.AllBaseOverflow.incoming_mirror_predecessor", "P196.Agent7.AllBaseOverflow.actual_overflow_body", "P196.Agent7.AllBaseOverflow.actual_overflow_length", "P196.Agent7.AllBaseOverflow.overflow_length_pos", "P196.Agent7.AllBaseOverflow.actual_overflow_at", "P196.Agent7.AllBaseOverflow.actual_overflow_last", "P196.Agent7.AllBaseOverflow.actual_overflow_pair_at", "P196.Agent7.AllBaseOverflow.actual_overflow_pair_getD", "P196.Agent7.AllBaseOverflow.actual_overflow_endpoints", "P196.Agent7.AllBaseOverflow.actual_overflow_zero_iff", "P196.Agent7.AllBaseOverflow.actual_overflow_max_iff", "P196.Agent7.AllBaseOverflow.actual_overflow_new_extreme_neutral", "P196.Agent7.AllBaseOverflow.actual_overflow_without_neutral", "P196.Agent7.AllBaseOverflow.endpoint_residue_positive", "P196.Agent7.AllBaseOverflow.endpoint_residue_below_max", "P196.Agent7.AllBaseOverflow.endpoint_residue_max_iff", "P196.Agent7.AllBaseOverflow.overflow_head_coefficient_bound", "P196.Agent7.AllBaseOverflow.actual_overflow_endpoints_pos", "P196.Agent7.AllBaseOverflow.actual_overflow_endpoints_nonzero", "P196.Agent7.AllBaseOverflow.actual_overflow_endpoints_max_iff", "P196.Agent7.AllBaseOverflow.actual_overflow_endpoints_nonextreme", "P196.Agent7.AllBaseOverflow.canonical_reverse_add_overflow_theorem"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut allCount := 0
  let mut theoremCount := 0
  let mut safeDefinitionCount := 0
  let mut unsafeCount := 0
  let mut endpointCount := 0
  let mut safeRoots : List Name := []
  let mut union : List Name := []
  for (name, elaboratorInfo) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        let checkedInfo := env.checked.get.find? name
        let ci := checkedInfo.getD elaboratorInfo
        if !ci.isUnsafe && checkedInfo.isNone then
          throwError m!"Safe declaration is absent from checked environment: {name}"
        if ci.type.hasMVar then
          throwError m!"Metavariable in selected declaration type: {name}"
        allCount := allCount + 1
        if ci.isTheorem then theoremCount := theoremCount + 1
        if ci.isDefinition && !ci.isUnsafe then
          safeDefinitionCount := safeDefinitionCount + 1
        if ci.isPartial then
          throwError m!"Partial declaration in accepted selected source: {name}"
        let isEndpoint := endpointNames.contains name.toString
        if isEndpoint then
          endpointCount := endpointCount + 1
          if !ci.isTheorem then throwError m!"Public endpoint is not a theorem: {name}"
        let mut axs : List Name := []
        if ci.isUnsafe then
          unsafeCount := unsafeCount + 1
        else
          if ci.isAxiom then throwError m!"Custom safe axiom in selected module: {name}"
          axs := (← liftCoreM (Lean.collectAxioms name)).toList
          if axs.any (fun ax => !(allowed.contains ax)) then
            throwError m!"Forbidden transitive axiom: {name}: {axs}"
          for ax in axs do
            if !(union.contains ax) then union := ax :: union
          safeRoots := name :: safeRoots
        let typeFormat ← liftTermElabM (Lean.Meta.ppExpr ci.type)
        let record := Json.mkObj [
          ("module", toJson mod.toString),
          ("name", toJson name.toString),
          ("kind", toJson (Review127Audit.kind ci)),
          ("unsafe", toJson ci.isUnsafe),
          ("partial", toJson ci.isPartial),
          ("present_in_checked_environment", toJson checkedInfo.isSome),
          ("public_endpoint", toJson isEndpoint),
          ("type", toJson (typeFormat.pretty 120)),
          ("level_parameters", toJson (ci.levelParams.map Name.toString)),
          ("axioms", toJson (axs.map Name.toString)),
          ("dependencies", toJson ((Review127Audit.dependencies ci).map Name.toString))]
        logInfo m!"DECL_JSON {record.compress}"
  if endpointCount != endpointNames.length then
    throwError m!"Missing endpoint: found {endpointCount}, required {endpointNames.length}"
  let mut todo := safeRoots
  let mut visited : NameSet := {}
  let mut graphCount := 0
  while !todo.isEmpty do
    let name := todo.head!
    todo := todo.tail!
    if !visited.contains name then
      visited := visited.insert name
      let some ci := env.checked.get.find? name
        | throwError m!"Dependency absent from checked environment: {name}"
      if ci.isUnsafe then
        throwError m!"Unsafe declaration reaches accepted theorem or safe definition: {name}"
      if ci.isPartial then
        throwError m!"Partial declaration reaches accepted theorem or safe definition: {name}"
      let deps := Review127Audit.dependencies ci
      let mod := match env.getModuleIdxFor? name with
        | some idx => env.allImportedModuleNames[idx.toNat]!.toString
        | none => "<kernel>"
      let record := Json.mkObj [
        ("module", toJson mod),
        ("name", toJson name.toString),
        ("kind", toJson (Review127Audit.kind ci)),
        ("unsafe", toJson ci.isUnsafe),
        ("partial", toJson ci.isPartial),
        ("dependencies", toJson (deps.map Name.toString))]
      logInfo m!"GRAPH_JSON {record.compress}"
      todo := deps ++ todo
      graphCount := graphCount + 1
  let summary := Json.mkObj [
    ("module_origin_constants", toJson allCount),
    ("module_origin_theorems", toJson theoremCount),
    ("module_origin_safe_definitions", toJson safeDefinitionCount),
    ("module_origin_unsafe_constants", toJson unsafeCount),
    ("public_endpoints", toJson endpointCount),
    ("safe_roots", toJson safeRoots.length),
    ("reachable_dependency_constants", toJson graphCount),
    ("axiom_union", toJson (union.map Name.toString)),
    ("unsafe_reachable", toJson false)]
  logInfo m!"AUDIT_SUMMARY_JSON {summary.compress}"

#check P196.Agent7.AllBaseOverflow.residue_zero_iff
#print axioms P196.Agent7.AllBaseOverflow.residue_zero_iff
#check P196.Agent7.AllBaseOverflow.residue_max_iff
#print axioms P196.Agent7.AllBaseOverflow.residue_max_iff
#check P196.Agent7.AllBaseOverflow.adjacent_residues_zero_iff
#print axioms P196.Agent7.AllBaseOverflow.adjacent_residues_zero_iff
#check P196.Agent7.AllBaseOverflow.adjacent_residues_max_iff
#print axioms P196.Agent7.AllBaseOverflow.adjacent_residues_max_iff
#check P196.Agent7.AllBaseOverflow.adjacentPair_zero_iff
#print axioms P196.Agent7.AllBaseOverflow.adjacentPair_zero_iff
#check P196.Agent7.AllBaseOverflow.adjacentPair_max_iff
#print axioms P196.Agent7.AllBaseOverflow.adjacentPair_max_iff
#check P196.Agent7.AllBaseOverflow.adjacent_new_extreme_neutral
#print axioms P196.Agent7.AllBaseOverflow.adjacent_new_extreme_neutral
#check P196.Agent7.AllBaseOverflow.adjacent_without_neutral
#print axioms P196.Agent7.AllBaseOverflow.adjacent_without_neutral
#check P196.Agent7.AllBaseOverflow.ordinary_terminal_take_succ
#print axioms P196.Agent7.AllBaseOverflow.ordinary_terminal_take_succ
#check P196.Agent7.AllBaseOverflow.incoming_succ
#print axioms P196.Agent7.AllBaseOverflow.incoming_succ
#check P196.Agent7.AllBaseOverflow.incoming_predecessor
#print axioms P196.Agent7.AllBaseOverflow.incoming_predecessor
#check P196.Agent7.AllBaseOverflow.incoming_mirror_predecessor
#print axioms P196.Agent7.AllBaseOverflow.incoming_mirror_predecessor
#check P196.Agent7.AllBaseOverflow.actual_overflow_body
#print axioms P196.Agent7.AllBaseOverflow.actual_overflow_body
#check P196.Agent7.AllBaseOverflow.actual_overflow_length
#print axioms P196.Agent7.AllBaseOverflow.actual_overflow_length
#check P196.Agent7.AllBaseOverflow.overflow_length_pos
#print axioms P196.Agent7.AllBaseOverflow.overflow_length_pos
#check P196.Agent7.AllBaseOverflow.actual_overflow_at
#print axioms P196.Agent7.AllBaseOverflow.actual_overflow_at
#check P196.Agent7.AllBaseOverflow.actual_overflow_last
#print axioms P196.Agent7.AllBaseOverflow.actual_overflow_last
#check P196.Agent7.AllBaseOverflow.actual_overflow_pair_at
#print axioms P196.Agent7.AllBaseOverflow.actual_overflow_pair_at
#check P196.Agent7.AllBaseOverflow.actual_overflow_pair_getD
#print axioms P196.Agent7.AllBaseOverflow.actual_overflow_pair_getD
#check P196.Agent7.AllBaseOverflow.actual_overflow_endpoints
#print axioms P196.Agent7.AllBaseOverflow.actual_overflow_endpoints
#check P196.Agent7.AllBaseOverflow.actual_overflow_zero_iff
#print axioms P196.Agent7.AllBaseOverflow.actual_overflow_zero_iff
#check P196.Agent7.AllBaseOverflow.actual_overflow_max_iff
#print axioms P196.Agent7.AllBaseOverflow.actual_overflow_max_iff
#check P196.Agent7.AllBaseOverflow.actual_overflow_new_extreme_neutral
#print axioms P196.Agent7.AllBaseOverflow.actual_overflow_new_extreme_neutral
#check P196.Agent7.AllBaseOverflow.actual_overflow_without_neutral
#print axioms P196.Agent7.AllBaseOverflow.actual_overflow_without_neutral
#check P196.Agent7.AllBaseOverflow.endpoint_residue_positive
#print axioms P196.Agent7.AllBaseOverflow.endpoint_residue_positive
#check P196.Agent7.AllBaseOverflow.endpoint_residue_below_max
#print axioms P196.Agent7.AllBaseOverflow.endpoint_residue_below_max
#check P196.Agent7.AllBaseOverflow.endpoint_residue_max_iff
#print axioms P196.Agent7.AllBaseOverflow.endpoint_residue_max_iff
#check P196.Agent7.AllBaseOverflow.overflow_head_coefficient_bound
#print axioms P196.Agent7.AllBaseOverflow.overflow_head_coefficient_bound
#check P196.Agent7.AllBaseOverflow.actual_overflow_endpoints_pos
#print axioms P196.Agent7.AllBaseOverflow.actual_overflow_endpoints_pos
#check P196.Agent7.AllBaseOverflow.actual_overflow_endpoints_nonzero
#print axioms P196.Agent7.AllBaseOverflow.actual_overflow_endpoints_nonzero
#check P196.Agent7.AllBaseOverflow.actual_overflow_endpoints_max_iff
#print axioms P196.Agent7.AllBaseOverflow.actual_overflow_endpoints_max_iff
#check P196.Agent7.AllBaseOverflow.actual_overflow_endpoints_nonextreme
#print axioms P196.Agent7.AllBaseOverflow.actual_overflow_endpoints_nonextreme
#check P196.Agent7.AllBaseOverflow.canonical_reverse_add_overflow_theorem
#print axioms P196.Agent7.AllBaseOverflow.canonical_reverse_add_overflow_theorem
