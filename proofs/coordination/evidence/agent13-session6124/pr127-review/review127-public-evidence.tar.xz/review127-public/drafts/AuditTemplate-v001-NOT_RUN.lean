import CanonicalOverflowBirths
import Lean

/-!
Independent operational audit for the exact thirteen-module PR #127 closure.
This file does not change or replace any accepted mathematical declaration.
It enumerates module origins, uses the checked kernel environment, audits
safe declarations and literal public endpoints, and exports a dependency graph.
-/

open Lean Elab Command

set_option maxRecDepth 100000
set_option maxHeartbeats 8000000
set_option pp.all true
set_option pp.maxSteps 1000000

namespace Review127Audit

def kind (ci : ConstantInfo) : String :=
  match ci with
  | .axiomInfo _ => "axiom"
  | .defnInfo _ => "definition"
  | .thmInfo _ => "theorem"
  | .opaqueInfo _ => "opaque"
  | .quotInfo _ => "quotient"
  | .inductInfo _ => "inductive"
  | .ctorInfo _ => "constructor"
  | .recInfo _ => "recursor"

def dependencies (ci : ConstantInfo) : List Name :=
  let initial := ci.getUsedConstantsAsSet
  let complete :=
    match ci with
    | .recInfo val => val.rules.foldl
        (fun acc rule => acc ++ rule.rhs.getUsedConstantsAsSet) initial
    | _ => initial
  complete.toList

end Review127Audit

run_cmd do
  let env ← getEnv
  let selected : List String := SELECTED_MODULES
  let endpointNames : List String := ENDPOINT_NAMES
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut allCount := 0
  let mut theoremCount := 0
  let mut safeDefinitionCount := 0
  let mut unsafeCount := 0
  let mut endpointCount := 0
  let mut safeRoots : List Name := []
  let mut union : List Name := []
  for (name, _) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        let some ci := env.checked.get.find? name
          | throwError m!"Selected declaration is absent from checked environment: {name}"
        allCount := allCount + 1
        if ci.isTheorem then theoremCount := theoremCount + 1
        if ci.isDefinition && !ci.isUnsafe then
          safeDefinitionCount := safeDefinitionCount + 1
        if ci.isPartial then
          throwError m!"Partial declaration in accepted selected source: {name}"
        let isEndpoint := endpointNames.contains name.toString
        if isEndpoint then
          endpointCount := endpointCount + 1
          if !ci.isTheorem then throwError m!"Public endpoint is not a theorem: {name}"
        let mut axs : List Name := []
        if ci.isUnsafe then
          unsafeCount := unsafeCount + 1
        else
          if ci.isAxiom then throwError m!"Custom safe axiom in selected module: {name}"
          axs := (← liftCoreM (Lean.collectAxioms name)).toList
          if axs.any (fun ax => !(allowed.contains ax)) then
            throwError m!"Forbidden transitive axiom: {name}: {axs}"
          for ax in axs do
            if !(union.contains ax) then union := ax :: union
          safeRoots := name :: safeRoots
        let typeFormat ← liftTermElabM (Lean.Meta.ppExpr ci.type)
        let record := Json.mkObj [
          ("module", toJson mod.toString),
          ("name", toJson name.toString),
          ("kind", toJson (Review127Audit.kind ci)),
          ("unsafe", toJson ci.isUnsafe),
          ("partial", toJson ci.isPartial),
          ("public_endpoint", toJson isEndpoint),
          ("type", toJson typeFormat.pretty),
          ("level_parameters", toJson (ci.levelParams.map Name.toString)),
          ("axioms", toJson (axs.map Name.toString)),
          ("dependencies", toJson ((Review127Audit.dependencies ci).map Name.toString))]
        logInfo m!"DECL_JSON {record.compress}"
  if endpointCount != endpointNames.length then
    throwError m!"Missing endpoint: found {endpointCount}, required {endpointNames.length}"
  let mut todo := safeRoots
  let mut visited : NameSet := {}
  let mut graphCount := 0
  while !todo.isEmpty do
    let name := todo.head!
    todo := todo.tail!
    if !visited.contains name then
      visited := visited.insert name
      let some ci := env.checked.get.find? name
        | throwError m!"Dependency absent from checked environment: {name}"
      if ci.isUnsafe then
        throwError m!"Unsafe declaration reaches accepted theorem or safe definition: {name}"
      if ci.isPartial then
        throwError m!"Partial declaration reaches accepted theorem or safe definition: {name}"
      let deps := Review127Audit.dependencies ci
      let mod := match env.getModuleIdxFor? name with
        | some idx => env.allImportedModuleNames[idx.toNat]!.toString
        | none => "<kernel>"
      let record := Json.mkObj [
        ("module", toJson mod),
        ("name", toJson name.toString),
        ("kind", toJson (Review127Audit.kind ci)),
        ("unsafe", toJson ci.isUnsafe),
        ("partial", toJson ci.isPartial),
        ("dependencies", toJson (deps.map Name.toString))]
      logInfo m!"GRAPH_JSON {record.compress}"
      todo := deps ++ todo
      graphCount := graphCount + 1
  let summary := Json.mkObj [
    ("module_origin_constants", toJson allCount),
    ("module_origin_theorems", toJson theoremCount),
    ("module_origin_safe_definitions", toJson safeDefinitionCount),
    ("module_origin_unsafe_constants", toJson unsafeCount),
    ("public_endpoints", toJson endpointCount),
    ("safe_roots", toJson safeRoots.length),
    ("reachable_dependency_constants", toJson graphCount),
    ("axiom_union", toJson (union.map Name.toString)),
    ("unsafe_reachable", toJson false)]
  logInfo m!"AUDIT_SUMMARY_JSON {summary.compress}"

PUBLIC_CHECKS
