# Independent semantic review of PR #127

Reviewer: Agent #13 /root/review127, a genuine nonauthor reviewer. The reviewer made no source edits and performed no remote mutation. This review does not establish a distinct GitHub account or an eligible platform APPROVE.

Reviewed head H: c68b0aaa5344f2cc646c035e2efca187852cb57d.
Checked integration base B supplied for this review: 1ee9123344dbe17e9bda224ff8af5b1cbb2b64e4.
The parent integration agent owns current-target combination and all incoming-file publication checks. The supplied combined tree is 8e5190dcb621fc976cd2afbd13dccfa122a25bed; no claim is made here that this reviewer constructed it or rebuilt unrelated accepted projects.

## Source meaning and advertised domain

The five new modules are AdjacentBirths, OverflowDigits, ActualOverflowBirths, OverflowEndpoints, and CanonicalOverflowBirths. I read them in full, together with all eight original dependency modules, PROJECT_REGISTRY.json, dependencies/SOURCE_PINS.json, README.md, the original canonical verifier, the historical author/reviewer build and continuation programs, and the relevant rejected canonical and reviewer fixture/audit evidence. The accepted-base AGENTS.md and proofs/PUBLICATION_POLICY.md retain the requirement to preserve failed research and prohibit claiming a solution of the 196 problem without the missing all-time argument.

All new arithmetic and actual birth classifiers quantify over an arbitrary integer base b with 2 <= b. The old coefficient word xs is a finite List (Int × Bool) of length L. ResetNormalization.Bounded means precisely that every first projection is in [0, 2*b-2]. Coefficient symmetry means (xs.map Prod.fst).reverse = xs.map Prod.fst; no equality of the Bool tags is assumed.

The actual carry and digit APIs are unchanged originals. ResetNormalization.ordinaryTags replaces every Bool by false. PhysicalWidth.terminal recursively applies integer Euclidean division to q+incoming; ActualBaseBirths.incoming b xs k is that terminal computation on the first k ordinary columns, starting at zero. PhysicalWidth.actualDigits normalizes ordinary tags and chooses physical width using the actually computed terminal carry. The reset-placed comparison list is not substituted for the ordinary output.

## Exact width, indices, and carry coupling

The explicit overflow hypothesis is terminal b 0 (ordinaryTags xs) = 1. The new proof expands the unchanged actual-width definition, proves actualDigits = body ++ [1], and obtains actual output length L+1. The empty source cannot satisfy the hypothesis because its terminal computation is zero. These structural statements do not rely on positivity or boundedness assumptions that their types omit.

At a strict interior index 0 < i < L, ReverseAdd.pairs pairs actual digit i with actual digit (L+1)-1-i = L-i. Both indices lie in the old-width body. Old coefficient symmetry turns coefficient q_(L-i) into q_(i-1). Consequently the exact pair expression is
Q_i = (q_i+c_i) % b + (q_(i-1)+c_(L-i)) % b,
where Q = pairs (actualDigits b xs).

This shift is essential: the no-overflow reflection L-1-i would give a different expression. The Lean proofs establish each subtraction and access bound before converting getElem or getD. Neither the strict interior classifiers nor the endpoint identities derive a birth from an out-of-range default zero.

Writing a=q_(i-1), z=q_i, u=c_i and v=c_(L-i), the two surrounding carry equations supplied to the local arithmetic theorem are
u = (a+c_(i-1))/b and v = (z+c_(L-i-1))/b.
The second equation uses original coefficient symmetry. The surrounding prefix carries satisfy the bit bounds by the unchanged incoming_bit theorem. u and v are therefore computed carries, not independent guessed bits.

## Exact alternatives and neutrality

The zero classifier is a biconditional with exactly these oriented alternatives:

1. a=0 and z=0.
2. a=b-1, z=b-1, u=1 and v=1.
3. a=b-1, z=b and u=0.
4. a=b, z=b-1 and v=0.

The maximal classifier Q_i=2*b-2 is a biconditional with exactly these alternatives:

1. a=2*b-2 and z=2*b-2.
2. a=b-1, z=b-1, u=0 and v=0.
3. a=b-1, z=b-2 and u=1.
4. a=b-2, z=b-1 and v=1.

The apparent omission of one intermediate carry in the mixed rows is intentional: the division equations and coefficient bounds determine the necessary restrictions. The local proof first shows both residues are nonnegative and below b. A zero sum forces both to zero; a maximal sum forces both to b-1. The existing one-column classifier plus the real coupled division equations then yields all four rows. Splitting carry values into zero and one is valid uniformly at b=2, and the inherited b>=3 rigidity results are not used to extend a restricted assertion to the binary case.

A new extreme excludes only the corresponding homogeneous old adjacent extreme pair. Eliminating that first row proves the necessary neutral-neighbor condition a=b-1 or z=b-1. It is not a sufficient condition, a statement about arbitrary predecessors, or an ancestry/lifetime invariant. The without-neutral corollaries correctly give exactly the two inherited homogeneous cases when neither neighbor equals b-1.

## Endpoints and the binary exception

The actual first digit is q_0 % b because c_0=0; the actual highest digit is the appended one. Pair symmetry therefore gives both genuine endpoints Q_0=Q_L=1+q_0%b. These endpoint identities require neither symmetry nor coefficient bounds.

For every b>=2, integer Euclidean remainders are nonnegative, including for signed q_0, so the endpoints are strictly positive. For b>=3, q_0%b<b implies 1+q_0%b<=b<2*b-2; neither endpoint can be maximal. These facts correctly retain no bounds or symmetry premises.

Identifying the binary old coefficient itself requires the original coefficient bound. If 1+q_0%b=2*b-2 and b>=2, the remainder upper bound forces b=2. Under 0<=q_0<=2, odd remainder forces q_0=1. Conversely b=2,q_0=1 gives the maximum. The actual endpoint maximum theorem first proves the head is a real source element from terminal one, then inherits its bound. Dropping that bound would be false: the retained rejected-generalization control q_0=3 at b=2 has terminal one and maximal endpoints although q_0 is not one.

Width L=1 is included. There are no indices 0<i<1, but the real output still has two endpoints, at 0 and 1. At b=2 the bounded singleton coefficient 2 produces actual digits [0,1] and paired endpoints [1,1]; the binary maximum criterion does not force an impossible q_0=1 overflow for that singleton.

## Canonical ordinary reverse-add specialization

The final wrapper quantifies over finite input digits with ReverseAdd.DigitBounds and PhysicalWidth.PositiveLast, tagged coefficients with the literal equality xs.map Prod.fst = ReverseAdd.pairs digits, and the computed terminal-one hypothesis. It derives coefficient bounds and symmetry rather than assuming an arbitrary new coefficient model. Taking lengths of the projection equality gives xs.length=digits.length.

The proof directly applies unchanged ReverseAdd.reverse_add_normalization. It retains valid output digits, a positive highest output digit, output width digits.length+1, and the numerical equality
eval b output = eval b digits + reversedValue b digits.
The original evaluation is least-significant-digit-first Horner evaluation, and reversedValue evaluates the reversed finite digit list as an integer. Zeros that become high zeros on reversal have zero contribution. Thus this is the ordinary one-step integer reverse-and-add interface, with the original representation semantics.

The wrapper then combines endpoint equalities, endpoint positivity, the exact binary endpoint maximum equivalences, and every strict-interior zero/max/necessary-neutral assertion. Its indices cover the entire output: 0, 0<i<L, and L. It imposes no unnecessary L>=2 premise and does not confuse absence of an interior at L=1 with absence of endpoints.

## Rejected history and scope boundaries

The rejected canonical attempt differs from the accepted canonical source by a redundant dsimp only after intro i hi0 hi. The rejected compiler log reports 'dsimp made no progress' and sorryAx from elaboration recovery. That source and log must remain historical and outside the accepted build. The later source removes only that redundant command. Historical final-001 project compilation and final-003 fixture/audit continuation are separate events; copied historical objects cannot be called fresh.

The historical reviewer fixture failed first on membership elimination, and its next audit attempt failed on the unsupported display option pp.width. Those failures are not accepted audit passes merely because some subsequent log lines list allowed axioms. This review will establish its own fresh result with explicit trust zero.

The scope is one finite reverse-add step. No theorem in the selected new modules asserts run population, growth, ancestry, lifetime, global palindrome avoidance, or the 196 conjecture. Counts of endpoints and generated declarations are audit metadata, not counts of independent major results.

## Verification status

Source identity has been independently checked for all 13 modules against both the frozen registry and the exact H tree/blob bytes. Each of the eight dependency pins has also been independently matched to its original path at commit 98d59927ad89c42f438ea857ec5750a0df3b91db. The pinned Lean binary SHA-256 matches 92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023.

A new Lean execution has not yet begun as of this draft because the parent reported actual ENOSPC and instructed reviewers to pause new builds. Semantic review alone is not a fresh Lean PASS. The final receipt must state the actual later execution result, including every source/hash/command/log and any failed attempt.
