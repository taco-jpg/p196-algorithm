#!/usr/bin/env python3
"""Create a research-only public packet from explicit path provenance, without reading excluded files."""
import base64
import hashlib
import json
import lzma
import sys
import tarfile
import traceback
from datetime import datetime, timezone
from pathlib import Path, PurePosixPath

ROOT = Path("/dev/shm/p196-agent13-session6124-20261016/review127")
OUT = ROOT / "delivery-public"
INPUTS = OUT / "publication-source"
HEAD = "c68b0aaa5344f2cc646c035e2efca187852cb57d"
BASE = "1ee9123344dbe17e9bda224ff8af5b1cbb2b64e4"

def now():
    return datetime.now(timezone.utc).isoformat()

def digest(data):
    return hashlib.sha256(data).hexdigest()

def identity(data):
    return {"sha256": digest(data), "bytes": len(data),
            "git_blob_sha1": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}

def write(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")

TOP_LEVEL_RESEARCH = {
    "AuditTemplate.lean", "COMMENT_REVIEW_DRAFT.md", "EXCLUDED_COMPILER_OBJECTS.json",
    "RESOURCE_HISTORY.json", "REVIEW_RECEIPT.json", "SEMANTIC_REVIEW.md",
    "SOURCE_IDENTITY_READONLY.json", "audit_only_002.py", "continue_audit.py",
    "continue_audit_003.py", "finalize_audit_004.py", "run_review.py",
    "fresh-001-launcher.stdout", "fresh-001-launcher.stderr",
    "audit-002-launcher.stdout", "audit-002-launcher.stderr",
    "audit-003-launcher.stdout", "audit-003-launcher.stderr",
    "finalizer-004-launcher.stdout", "finalizer-004-launcher.stderr",
}
RESEARCH_PREFIXES = (
    "analysis-004/", "audit-002/", "audit-003/", "fresh-001/", "drafts/",
    "inputs/project/", "inputs/accepted-base/", "inputs/runtime-inspected/",
)
RETAINED_METADATA = {
    "inputs/canonical_verifier.py", "failed-setup-001/FAILURE.json",
    "failed-setup-001/RECOVERY.json", "failed-finalizer-write-001/RECOVERY.json",
    "operations/finalizer004-write-failed.json",
}
HISTORICAL_PACKAGING_CODE = {"pack_review.py", "recover_packet.py"}
PRIVATE_MARKERS = {"role_prompt.txt", ".aws", ".ssh", ".env", "credentials", "secrets"}
ATTACHMENT_SUFFIXES = {".pdf", ".docx", ".pptx", ".xlsx", ".png", ".jpg", ".jpeg", ".gif", ".zip", ".tar", ".xz", ".base64"}

def safe_path(relative):
    path = PurePosixPath(relative)
    return not path.is_absolute() and ".." not in path.parts and "\\" not in relative

def selected(relative):
    return (relative in TOP_LEVEL_RESEARCH or relative in RETAINED_METADATA
            or relative in HISTORICAL_PACKAGING_CODE
            or relative.startswith(RESEARCH_PREFIXES))

def main():
    report = {"schema_version": 1, "status": "RUNNING", "started_at": now(),
              "head": HEAD, "checked_base": BASE, "reviewer": "Agent #13 /root/review127",
              "action": "Publication-scope correction only",
              "mathematical_review_result_unchanged": "PASS",
              "lean_invocations": 0, "mathematical_source_edits": False,
              "remote_mutations": False, "excluded_bodies_opened": False,
              "original_archive_or_receipt_modified": False,
              "original_private_archive_published": False,
              "original_publication_status_source": "Parent integration agent",
              "only_new_public_archive_eligible_for_publication": True,
              "invocation": [sys.executable, *sys.argv]}
    write(OUT / "public-state-0000.json", report)
    try:
        old_manifest = json.loads((ROOT / "ARCHIVE_MANIFEST.json").read_text())
        old_receipt = json.loads((ROOT / "delivery/FINAL_PACKET_RECEIPT.json").read_text())
        if old_receipt["archive"]["sha256"] != "46d378cdb2efcd991e6c1a88e6c30f628a6448aa0b4bc49308808388a3475f89":
            raise ValueError("Original archive identity metadata differs")
        original_rows = old_manifest["files"]
        if len({row["path"] for row in original_rows}) != len(original_rows):
            raise ValueError("Duplicate original-manifest path")
        included = []
        excluded = []
        eligible_paths = set()
        for row in original_rows:
            rel = row["path"]
            if not safe_path(rel):
                raise ValueError("Unsafe original path metadata")
            keep = selected(rel)
            parts = {part.lower() for part in PurePosixPath(rel).parts}
            obvious_private = bool(parts.intersection(PRIVATE_MARKERS)) or "pasted text" in rel.lower() or "/upload/" in rel.lower()
            obvious_attachment = PurePosixPath(rel).suffix.lower() in ATTACHMENT_SUFFIXES
            if keep and (obvious_private or obvious_attachment):
                raise ValueError("Allowlisted research path requires privacy classification: " + rel)
            if keep:
                eligible_paths.add(rel)
                target = "historical-packaging/" + rel if rel in HISTORICAL_PACKAGING_CODE else rel
                included.append({**row, "path": target, "source_path": rel,
                                 "source_kind": "Original byte-exact research evidence"})
            else:
                if rel == "inputs/ROLE_PROMPT.txt":
                    reason = "User task attachment copy; excluded by path without opening its body"
                elif rel.startswith("operations/"):
                    reason = "General inspection/tool-response or transport metadata may mix administrative inputs; direct research sources and complete execution logs are separately retained"
                elif rel.startswith("failed-setup-001/") or rel.startswith("failed-finalizer-write-001/"):
                    reason = "Long administrative/transport command payload or fragment; original remains local and direct failure metadata is retained"
                elif rel.startswith("bootstrap-") or rel in {"ASSIGNMENT.json", "inputs/PARENT_TMPFS_SCOPE.json"}:
                    reason = "Nonresearch initialization or private task/scope material"
                else:
                    reason = "Superseded private-archive transport instructions or administrative metadata"
                excluded.append({**row, "reason": reason, "retained_locally_unchanged": True,
                                 "body_opened_during_public_scope_correction": False})
        essential_prefixes = ("inputs/project/", "fresh-001/", "audit-002/", "audit-003/", "analysis-004/")
        for row in original_rows:
            if row["path"].startswith(essential_prefixes) and row["path"] not in eligible_paths:
                raise ValueError("Research source/result omitted")
        for rel in ["run_review.py", "continue_audit.py", "continue_audit_003.py", "finalize_audit_004.py"]:
            if rel not in eligible_paths:
                raise ValueError("Research runner omitted")
        exclusion_data = {
            "schema_version": 1, "publication_scope_only": True,
            "excluded_original_manifest_members": excluded,
            "excluded_count": len(excluded),
            "excluded_bytes_from_prior_manifest": sum(row["bytes"] for row in excluded),
            "excluded_bodies_read": False,
            "classification": "Explicit path/provenance allowlist; no broad content scan",
            "original_archive_withheld": {
                "archive": old_receipt["archive"], "base64": old_receipt["base64"],
                "uploaded_or_published": False, "status_source": "Parent integration agent",
                "retained_locally_unchanged": True, "publication_eligible": False},
            "old_delivery_and_new_delivery_containers": {
                "archived": False, "reason": "Explicit manifest inputs avoid recursive container inclusion"},
            "compiler_object_exclusion_manifest": "EXCLUDED_COMPILER_OBJECTS.json",
            "compiler_objects_preserved_locally": True,
            "mathematical_or_direct_execution_log_exclusions": [],
            "automatic_approval_rejection": {
                "occurred": True, "process_started": False,
                "action": "Proposed broad byte-marker scan of other manifest members",
                "reason": "Potential attachment copies could be read contrary to the parent instruction",
                "response": "No retry or bypass; a narrower path-only allowlist was used"},
        }
        write(OUT / "PUBLIC_EXCLUSIONS.json", exclusion_data)
        correction_files = {
            "PUBLICATION_SCOPE_CORRECTION.md": INPUTS / "PUBLICATION_SCOPE_CORRECTION.md",
            "RECOVERY_PUBLIC.md": INPUTS / "RECOVERY_PUBLIC.md",
            "recover_public_packet.py": INPUTS / "recover_public_packet.py",
            "pack_public_review.py": INPUTS / "pack_public_review.py",
            "PUBLIC_EXCLUSIONS.json": OUT / "PUBLIC_EXCLUSIONS.json",
            "PUBLIC_PACKAGING_INVOCATION.json": INPUTS / "PUBLIC_PACKAGING_INVOCATION.json",
        }
        payload = {}
        for row in included:
            path = ROOT / row["source_path"]
            if path.is_symlink() or not path.is_file():
                raise ValueError("Unexpected research input file kind")
            data = path.read_bytes()
            if len(data) != row["bytes"] or digest(data) != row["sha256"]:
                raise ValueError("Research input identity changed: " + row["source_path"])
            payload[row["path"]] = data
        for name, path in correction_files.items():
            data = path.read_bytes()
            payload[name] = data
            included.append({"path": name, "source_path": str(path.relative_to(ROOT)),
                             "bytes": len(data), "sha256": digest(data),
                             "source_kind": "New publication-only correction evidence"})
        if any(path.startswith(("delivery/", "delivery-public/")) for path in payload):
            raise ValueError("Nested transport container")
        forbidden = [row["path"] for row in excluded]
        if set(forbidden).intersection(payload):
            raise ValueError("Excluded administrative member included")
        manifest = {
            "schema_version": 1, "head": HEAD, "checked_base": BASE,
            "created_at": now(), "root_prefix": "review127-public",
            "publication_scope": "Research evidence only; user task attachment and mixed administrative transport payloads excluded",
            "mathematical_result_unchanged": "PASS", "lean_invocations_for_repack": 0,
            "files": sorted(included, key=lambda row: row["path"]),
            "file_count": len(included),
            "substantive_bytes": sum(len(data) for data in payload.values()),
            "forbidden_archive_members": forbidden,
            "exclusions": "PUBLIC_EXCLUSIONS.json",
            "all_direct_mathematical_sources_logs_receipts_and_audit_data_retained": True,
            "old_delivery_containers_included": False,
            "manifest_self_hash": "Bound by the outer receipt and complete archive hash"},
        write(OUT / "PUBLIC_ARCHIVE_MANIFEST.json", manifest)
        archive = OUT / "review127-public-evidence.tar.xz"
        import io
        manifest_bytes = (OUT / "PUBLIC_ARCHIVE_MANIFEST.json").read_bytes()
        with archive.open("xb") as raw:
            with lzma.LZMAFile(raw, "w", preset=6) as compressed:
                with tarfile.open(fileobj=compressed, mode="w|", format=tarfile.PAX_FORMAT) as tar:
                    entries = {"PUBLIC_ARCHIVE_MANIFEST.json": manifest_bytes, **payload}
                    for name in sorted(entries):
                        data = entries[name]
                        info = tarfile.TarInfo("review127-public/" + name)
                        info.size = len(data)
                        info.mode = 0o644
                        info.mtime = 0
                        tar.addfile(info, io.BytesIO(data))
        namespace = {"__name__": "public_recovery_without_cli"}
        recovery_path = INPUTS / "recover_public_packet.py"
        exec(compile(recovery_path.read_text(), str(recovery_path), "exec"), namespace)
        archive_data = archive.read_bytes()
        _, verified_manifest, verified = namespace["verify"](archive, digest(archive_data))
        if verified_manifest != manifest_bytes:
            raise ValueError("Verified manifest differs")
        for row in included:
            if row["source_kind"] == "Original byte-exact research evidence":
                if digest((ROOT / row["source_path"]).read_bytes()) != row["sha256"]:
                    raise ValueError("Research evidence changed after packing")
        encoded = OUT / "review127-public-evidence.tar.xz.base64"
        encoded_data = base64.encodebytes(archive_data)
        with encoded.open("xb") as stream:
            stream.write(encoded_data)
        if base64.b64decode(encoded_data) != archive_data:
            raise ValueError("Base64 round trip changed archive")
        for name in ["recover_public_packet.py", "RECOVERY_PUBLIC.md", "PUBLICATION_SCOPE_CORRECTION.md"]:
            with (OUT / name).open("xb") as stream:
                stream.write((INPUTS / name).read_bytes())
        report.update(
            status="PASS",
            archive={"path": str(archive.relative_to(ROOT)), **identity(archive_data)},
            base64={"path": str(encoded.relative_to(ROOT)), **identity(encoded_data)},
            public_manifest={"path": "delivery-public/PUBLIC_ARCHIVE_MANIFEST.json", **identity(manifest_bytes)},
            exclusions={"path": "delivery-public/PUBLIC_EXCLUSIONS.json",
                        **identity((OUT / "PUBLIC_EXCLUSIONS.json").read_bytes())},
            recovery_script={"path": "delivery-public/recover_public_packet.py",
                             **identity((OUT / "recover_public_packet.py").read_bytes())},
            recovery_instructions={"path": "delivery-public/RECOVERY_PUBLIC.md",
                                   **identity((OUT / "RECOVERY_PUBLIC.md").read_bytes())},
            member_verification=verified,
            base64_round_trip_verified=True,
            original_research_members_retained=len(eligible_paths),
            original_manifest_members_excluded=len(excluded),
            all_original_research_bytes_unchanged=True,
            all_direct_lean_and_audit_failure_success_logs_retained=True,
            all_research_runner_sources_retained=True,
            private_path_screen="Metadata-only explicit allowlist and forbidden path/suffix checks",
            content_scan_of_excluded_material_performed=False,
            original_private_archive_metadata=old_receipt["archive"],
            old_archives_nested=False,
            original_private_archive_receipt_sha256="819545057c7b08066159bd1b55c76d96bd2cd0e2741ee93d2978bf712e7185f1",
        )
    except Exception as exc:
        report.update(status="FAIL", failure=str(exc))
        with (OUT / "public-failure.txt").open("x") as stream:
            stream.write(traceback.format_exc())
    finally:
        report["finished_at"] = now()
        write(OUT / "PUBLIC_ARCHIVE_RECEIPT.json", report)
        print(json.dumps(report, indent=2))
    return 0 if report["status"] == "PASS" else 1

if __name__ == "__main__":
    raise SystemExit(main())
