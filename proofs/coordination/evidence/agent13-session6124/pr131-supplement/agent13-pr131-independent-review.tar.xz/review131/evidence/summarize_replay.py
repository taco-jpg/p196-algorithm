#!/usr/bin/env python3
"""Derive review counts and literal endpoint evidence from the completed run."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re

ROOT = Path('/workspace/scratch/6124a6476634/review131')
RUN = ROOT / 'replay'
H = '0bfe5347de0e5085307a3432975a18b83a3a2bba'
B = '5ff4f607535587d572fbc9e95ba9501d1fbe5fc5'
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}
NEW_MODULE = 'Agent9OneStepDigitSumCollapse'
PREFIX = 'P196.Agent9.OneStepDigitSumCollapse.'


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


report_bytes = (RUN / 'verification.json').read_bytes()
report = json.loads(report_bytes)
assert report['status'] == 'PASS_SELECTED_SOURCE_CLOSURE'
assert report['auditor'] == 'Agent #13/review131'
assert report['repository_head_before'] == report['repository_head_after'] == H
assert report['repository_status_before'] == report['repository_status_after'] == ''
assert report['precompile_object_count'] == 0
assert report['all_selected_sources_unchanged']
assert report['compiler_snapshot_unchanged']
for command in report['commands']:
    assert command['exit_code'] == 0
    assert digest((RUN / command['log']).read_bytes()) == command['log_sha256']
for relative, identity in json.loads((RUN / 'FILES.json').read_text()).items():
    data = (RUN / relative).read_bytes()
    assert len(data) == identity['bytes'] and digest(data) == identity['sha256']

audit_bytes = (RUN / 'logs/CollapseIndependentAudit.log').read_bytes()
audit = audit_bytes.decode()
records = re.findall(r'^(AUDIT_THEOREM|AUDIT_DEFINITION) (\S+) (\S+) : \[([^\]]*)\]', audit, re.M)
parsed = [{'kind': kind, 'module': module, 'name': name,
           'axioms': [part.strip() for part in axioms.split(',') if part.strip()]}
          for kind, module, name, axioms in records]
assert len({row['name'] for row in parsed}) == len(parsed)
assert all(set(row['axioms']) <= ALLOWED for row in parsed)
theorems = [row for row in parsed if row['kind'] == 'AUDIT_THEOREM']
definitions = [row for row in parsed if row['kind'] == 'AUDIT_DEFINITION']
assert len(theorems) == report['audited_theorem_count'] == 1320
assert len(definitions) == report['audited_safe_definition_count'] == 183
assert dict(Counter(row['module'] for row in theorems)) == report['theorems_by_module']
assert dict(Counter(row['module'] for row in definitions)) == report['safe_definitions_by_module']
assert set(row['module'] for row in parsed) == set(report['build_order'])
union = sorted({axiom for row in parsed for axiom in row['axioms']})
assert set(union) == ALLOWED

source = (RUN / 'source/Agent9OneStepDigitSumCollapse.lean').read_text()
public = [PREFIX + name for name in re.findall(r'^theorem ([A-Za-z_]\w*)', source, re.M)]
assert public == report['endpoints'] and len(public) == 10
literal_rows = re.findall(r"^'(P196\.Agent9\.OneStepDigitSumCollapse\.[^']+)' depends on axioms: \[([^\]]*)\]", audit, re.M)
literal = {name: [part.strip() for part in axioms.split(',') if part.strip()] for name, axioms in literal_rows}
assert len(literal_rows) == len(literal) == 10
assert set(literal) == set(public)
assert all(set(axioms) == ALLOWED for axioms in literal.values())
assert all(len(re.findall(r'^' + re.escape(name) + r'\b', audit, re.M)) == 1 for name in public)
new_rows = [row for row in theorems if row['module'] == NEW_MODULE]
assert len(new_rows) == 21
assert not [row for row in definitions if row['module'] == NEW_MODULE]
assert not [row for row in report['unsafe_implementation_constants'] if row[0] == NEW_MODULE]
assert not [row for row in report['unsafe_implementation_definitions'] if row[0] == NEW_MODULE]
assert not re.search(r'^(CUSTOM_AXIOM|DISALLOWED_AXIOM|DISALLOWED_DEFINITION_AXIOM|MISSING_MODULE_ORIGIN)\b', audit, re.M)

first_audit = min(audit.index(prefix) for prefix in ('AUDIT_THEOREM ', 'AUDIT_DEFINITION ', 'UNSAFE_IMPLEMENTATION_') if prefix in audit)
(ROOT / 'PUBLIC_EXPORTS.log').write_text(audit[:first_audit])
write_json('AUDITED_DECLARATIONS.json', parsed)
write_json('NEW_MODULE_DECLARATIONS.json', new_rows)
summary = {
    'auditor': report['auditor'],
    'status': 'PASS_COMPLETE_LITERAL_AND_MODULE_ORIGIN_AUDIT',
    'head': H,
    'module_count': len(report['build_order']),
    'theorem_constant_count': len(theorems),
    'safe_definition_count': len(definitions),
    'theorems_by_module': report['theorems_by_module'],
    'safe_definitions_by_module': {name: report['safe_definitions_by_module'].get(name, 0) for name in report['build_order']},
    'new_public_theorem_count': len(public),
    'new_generated_theorem_count': len(new_rows) - len(public),
    'new_safe_definition_count': 0,
    'allowed_axiom_union': union,
    'endpoint_literal_axioms': literal,
    'unsafe_implementation_axiom_info_count': len(report['unsafe_implementation_constants']),
    'unsafe_implementation_definition_count': len(report['unsafe_implementation_definitions']),
    'unsafe_implementation_items_are_logical_dependencies': False,
    'new_module_unsafe_implementation_count': 0,
    'recorded_command_count': len(report['commands']),
    'all_recorded_commands_succeeded': True,
    'raw_report_sha256': digest(report_bytes),
    'raw_audit_log_sha256': digest(audit_bytes),
    'literal_export_log_sha256': digest((ROOT / 'PUBLIC_EXPORTS.log').read_bytes()),
    'elapsed_seconds': round(report['finished_epoch'] - report['started_epoch'], 6),
    'all_replay_file_manifest_entries_verified': True,
}
write_json('AUDIT_SUMMARY.json', summary)

final = {
    'schema_version': 1,
    'reviewer': report['auditor'],
    'author': 'Agent #9/horizon-safety',
    'reviewer_is_separate_nonauthor_agent': True,
    'source_changed_by_reviewer': False,
    'repository': 'taco-jpg/p196-algorithm',
    'pull_request': 131,
    'reviewed_head': H,
    'accepted_policy_base': B,
    'decision': 'PASS_INDEPENDENT_SEMANTICS_AND_FRESH_SELECTED_CLOSURE',
    'semantic_review': 'PASS',
    'kernel_replay': report['status'],
    'independent_full_run_count': 1,
    'run_started_utc': datetime.fromtimestamp(report['started_epoch'], timezone.utc).isoformat(),
    'run_finished_utc': datetime.fromtimestamp(report['finished_epoch'], timezone.utc).isoformat(),
    'lean_version': report['compiler']['version'],
    'lean_executable_sha256': report['compiler']['files']['/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean'],
    'trust_level': 0,
    'compiler_flags': ['--trust=0', '-j1', '-DElab.async=false'],
    'module_count': 6,
    'theorem_constant_count': 1320,
    'safe_definition_count': 183,
    'new_public_theorem_count': 10,
    'new_generated_theorem_count': 11,
    'new_safe_definition_count': 0,
    'axiom_union': union,
    'all_public_export_types_and_literal_axiom_reports_present': True,
    'all_registered_module_origins_present': True,
    'source_sha256': report['sources'][NEW_MODULE]['sha256'],
    'source_git_blob': report['sources'][NEW_MODULE]['git_blob'],
    'registry_sha256': report['manifest_sha256'],
    'verifier_sha256': report['workflow_sha256'],
    'raw_report_sha256': summary['raw_report_sha256'],
    'raw_audit_log_sha256': summary['raw_audit_log_sha256'],
    'all_selected_sources_unchanged': True,
    'identified_runtime_snapshot_unchanged': True,
    'repository_head_before_and_after': H,
    'repository_status_before_and_after': '',
    'fresh_output_precompile_objects': 0,
    'recorded_command_count': len(report['commands']),
    'all_recorded_commands_exit_zero': True,
    'compiler_failure_count_this_run': 0,
    'mathematical_findings_requiring_repair': [],
    'nonblocking_editorial_findings': ['The incoming historical semantic review mixes a Chinese conjunction into English prose; original evidence was preserved, and this new review is entirely English.'],
    'archive_identity_check': json.loads((ROOT / 'evidence/archive-check.json').read_text())['status'],
    'archive_original_file_count': 146,
    'archive_original_payload_bytes': 1926244,
    'remote_mutations_by_this_reviewer': [],
    'formal_review_submitted_by_this_reviewer': False,
    'repository_wide_pass': False,
    'runtime_built_from_source': False,
    'combined_target_tree_verified_by_this_reviewer': False,
    'remaining_integration_gates_owned_by_parent': ['Current-target combination, full PR metadata/diff, platform requirements, coordination, publication, and any actual Ready/review/merge actions.'],
    'limitations': [
        'The exact selected six-module project closure was rebuilt, not unrelated repository sources.',
        'The supplied Lean runtime was identified and selected runtime files were hashed; its entire source closure was not independently rebuilt.',
        'The result is a one-step family whose witness varies with the threshold; it does not prove a fixed infinite-orbit or 196 claim.',
        'An independent technical review does not establish a separate eligible GitHub account or satisfy an unknown platform approval requirement.'
    ],
}
write_json('FINAL_REVIEW.json', final)
write_json('REPLAY_COMMANDS.json', {'invocation': report['invocation'], 'commands': report['commands']})
print(json.dumps({key: value for key, value in summary.items() if key != 'endpoint_literal_axioms'}, indent=2))
