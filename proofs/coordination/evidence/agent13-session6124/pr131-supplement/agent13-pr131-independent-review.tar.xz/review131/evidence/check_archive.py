#!/usr/bin/env python3
"""Check the PR #131 research archive without extracting or executing it."""
import hashlib
import io
import json
import lzma
from pathlib import Path, PurePosixPath
import tarfile

ROOT = Path('/workspace/scratch/6124a6476634/repo/proofs/contributions/agent-9/one-step-digit-sum-collapse-20261016')
OUTPUT = Path('/workspace/scratch/6124a6476634/review131/evidence/archive-check.json')


def sha256(data):
    return hashlib.sha256(data).hexdigest()


manifest_bytes = (ROOT / 'evidence/MANIFEST.json').read_bytes()
manifest = json.loads(manifest_bytes)
compressed = (ROOT / manifest['stored_path']).read_bytes()
payload = lzma.decompress(compressed)
assert len(compressed) == manifest['stored_bytes']
assert sha256(compressed) == manifest['stored_sha256']
assert len(payload) == manifest['uncompressed_tar_bytes']
assert sha256(payload) == manifest['uncompressed_tar_sha256']
expected = {record['original_path']: record for record in manifest['files']}
assert len(expected) == len(manifest['files']) == manifest['original_files']
seen = set()
rows = []
with tarfile.open(fileobj=io.BytesIO(payload), mode='r:') as archive:
    for member in archive.getmembers():
        path = PurePosixPath(member.name)
        assert not path.is_absolute() and '..' not in path.parts
        if member.isdir():
            continue
        assert member.isfile() and not member.issym() and not member.islnk()
        name = path.as_posix()
        assert name not in seen
        seen.add(name)
        record = expected[name]
        data = archive.extractfile(member).read()
        assert len(data) == record['bytes']
        assert sha256(data) == record['sha256']
        direct = ROOT / name
        direct_matches = direct.read_bytes() == data if direct.is_file() else None
        assert direct_matches is not False
        rows.append({**record, 'direct_file_matches_if_present': direct_matches})
assert seen == set(expected)
assert sum(row['bytes'] for row in rows) == manifest['original_payload_bytes']
result = {
    'auditor': 'Agent #13/review131',
    'status': 'PASS_EXACT_ARCHIVE_IDENTITIES',
    'head': '0bfe5347de0e5085307a3432975a18b83a3a2bba',
    'archive_sha256': sha256(compressed),
    'manifest_sha256': sha256(manifest_bytes),
    'uncompressed_tar_sha256': sha256(payload),
    'file_count': len(rows),
    'original_payload_bytes': sum(row['bytes'] for row in rows),
    'direct_file_count': sum(row['direct_file_matches_if_present'] is True for row in rows),
    'files': rows,
    'execution_of_archived_code': False,
}
OUTPUT.write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key != 'files'}, indent=2))
