#!/usr/bin/env python3
"""Losslessly retain this completed review without reproducible build objects."""
from datetime import datetime, timezone
import hashlib
import io
import json
import lzma
from pathlib import Path
import tarfile

ROOT = Path('/workspace/scratch/6124a6476634/review131')
ARCHIVE_NAME = 'agent13-pr131-independent-review.tar.xz'


def identity(path):
    data = path.read_bytes()
    return {'path': path.relative_to(ROOT).as_posix(), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2) + '\n')


objects = [identity(path) for path in sorted((ROOT / 'replay/build').rglob('*')) if path.is_file()]
assert len(objects) == 6 and all(item['path'].endswith('.olean') for item in objects)
save('RETENTION.json', {
    'reviewer': 'Agent #13/review131',
    'included': 'All substantive source snapshots, verifier scripts, compiler/proof-audit logs, original provenance outputs, policies, manuscript, and review records.',
    'excluded_from_archive_only': objects,
    'excluded_reason': 'These six freshly generated .olean objects are reproducible compiler output, not research findings. The exact source and build command evidence is retained. The files remain locally present and were not deleted.',
    'original_replay_inventory_preserved': 'replay/FILES.json',
    'source_deletion_count': 0,
    'substantive_failure_logs_this_run': 'None: all 23 recorded replay commands exited zero.',
})
exclude = {'MANIFEST.json', 'ARCHIVE.json', ARCHIVE_NAME}
files = []
for path in sorted(ROOT.rglob('*')):
    if not path.is_file():
        continue
    relative = path.relative_to(ROOT).as_posix()
    if relative in exclude or relative.startswith('replay/build/'):
        continue
    assert not path.is_symlink()
    files.append(identity(path))
save('MANIFEST.json', {
    'schema_version': 1,
    'reviewer': 'Agent #13/review131',
    'head': '0bfe5347de0e5085307a3432975a18b83a3a2bba',
    'file_count': len(files),
    'payload_bytes': sum(item['bytes'] for item in files),
    'files': files,
    'self_hash_recorded_in': 'ARCHIVE.json',
    'infrastructure_exclusions': 'RETENTION.json',
})
payload_files = files + [identity(ROOT / 'MANIFEST.json')]
archive_path = ROOT / ARCHIVE_NAME
assert not archive_path.exists()
with tarfile.open(archive_path, mode='w:xz', format=tarfile.PAX_FORMAT) as archive:
    for record in sorted(payload_files, key=lambda item: item['path']):
        path = ROOT / record['path']
        data = path.read_bytes()
        assert len(data) == record['bytes'] and hashlib.sha256(data).hexdigest() == record['sha256']
        info = archive.gettarinfo(str(path), arcname='review131/' + record['path'])
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        info.mtime = 0
        archive.addfile(info, io.BytesIO(data))
compressed = archive_path.read_bytes()
uncompressed = lzma.decompress(compressed)
expected = {'review131/' + record['path']: record for record in payload_files}
seen = set()
with tarfile.open(fileobj=io.BytesIO(uncompressed), mode='r:') as archive:
    for member in archive.getmembers():
        assert member.isfile() and member.name not in seen
        seen.add(member.name)
        original = expected[member.name]
        data = archive.extractfile(member).read()
        assert len(data) == original['bytes'] and hashlib.sha256(data).hexdigest() == original['sha256']
assert seen == set(expected)
descriptor = {
    'schema_version': 1,
    'reviewer': 'Agent #13/review131',
    'created_utc': datetime.now(timezone.utc).isoformat(),
    'head': '0bfe5347de0e5085307a3432975a18b83a3a2bba',
    'format': 'xz-compressed POSIX tar, exact retained file bytes',
    'archive': identity(archive_path),
    'original_file_count': len(payload_files),
    'original_payload_bytes': sum(item['bytes'] for item in payload_files),
    'uncompressed_tar_bytes': len(uncompressed),
    'uncompressed_tar_sha256': hashlib.sha256(uncompressed).hexdigest(),
    'round_trip_all_file_identities': 'PASS',
    'manifest': identity(ROOT / 'MANIFEST.json'),
    'recovery_command': 'tar -xJf agent13-pr131-independent-review.tar.xz -C <new empty directory>',
    'recovered_directory': 'review131/',
    'companion_descriptor_outside_archive': 'ARCHIVE.json',
    'exclusion_record': 'RETENTION.json',
}
save('ARCHIVE.json', descriptor)
print(json.dumps(descriptor, indent=2))
