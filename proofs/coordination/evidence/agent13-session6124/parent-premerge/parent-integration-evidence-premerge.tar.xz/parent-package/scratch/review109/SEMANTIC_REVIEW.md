# Interrupted independent semantic review — PR #109

## Status and decision

**Status: STOPPED_DUPLICATE_COORDINATION. No acceptance recommendation is issued.**

Reviewer: Agent #13/review109, an actual nonauthor subagent in session `6124a6476634`.

Repository: `taco-jpg/p196-algorithm`  
Exact assigned head H: `18a82d9b5a2bd326751621e3e7a5458117561da7`  
Assigned integration base B: `5ff4f607535587d572fbc9e95ba9501d1fbe5fc5`  
Observed merge base: `ae8bbdfd2a18e8910eebc25fd2a81661c01abc16`

The parent stopped this assignment after the current coordination record assigned PRs #131, #109, and #123 to Agent #12. The parent identified coordination commit `2045b6ac` and issue #61 comment `6226177871`. Those coordination facts are an attributed parent handoff, not an independent remote read by this reviewer.

**No Lean compiler process was started.** The complete fresh selected-closure build, endpoint audit, and module-origin axiom audit are **NOT_RUN**. No inherited author or reviewer build is presented as this reviewer's execution. No remote mutation, source repair, substantive proof authorship, or shared-cache write was performed.

## Completed work

The entire supplied integration-role file, accepted `AGENTS.md`, and accepted `proofs/PUBLICATION_POLICY.md` were read. A private repository was created with `git clone --shared --no-checkout`. The parent repository and its alternate object stores were read only. The private clone was not checked out to H; all recovered contribution files were individually requested from H through the GitHub connector.

The two new mathematical modules were read completely:

- `Agent9FactorialRecurrence.lean`
- `Agent9DecimalFactorialEscape.lean`

The authored audit module and both replay scripts were read. None was executed. The registry identifies eleven mathematical modules: nine retained dependencies and the two new proof modules. This reviewer did not retrieve or inspect the complete nine-module dependency closure before cancellation.

Nineteen contribution text files already received through the exact-head connector calls were saved. Every saved file matches both the connector's exact UTF-8 content and its reported Git blob SHA-1; local SHA-256 values and sizes are recorded in `source-recovery/SOURCE_IDENTITIES.json`. The archive was not retrieved. Some large metadata outputs were truncated in the conversational tool display; the complete received responses are preserved in `source-recovery/connector-responses.json`. Preservation of a received file does not imply that its entire contents were reviewed.

## Preliminary source observations

These are source-reading observations, not completed formal verification or an acceptance gate.

### Generic recurrence

The formal recurrence is

```lean
∀ i, E (i + 2) =
  κ * ((i + 2) + (i + 1) * (2 * E (i + 1) + 1))
```

The final bound quantifies over natural `κ`, assumes `0 < κ`, natural-valued `E`, `E 1 = 1`, and this exact recurrence, and requires `1 ≤ M`. Its conclusion is

```lean
E M ≤ (4 * κ) ^ (M - 1) * factorial M
```

The source defines ordinary natural factorial with zero value one and successor value `(m + 1) * factorial m`. The proof uses induction on the positive index `i + 1`. Its base case only reads `E 1`; its recurrence only reads indices at least one. It imposes and uses no value for `E 0`.

The step substitutes the induction upper bound `C` monotonically into the recurrence. Positivity of `κ` and factorial gives `1 ≤ C`. The auxiliary inequality
`(i+2) + (i+1)*(2*C+1) ≤ 4*(i+2)*C`
is obtained from `i+2 ≤ (i+2)*C` and `2*C+1 ≤ 3*C`. The final multiplication and power/factorial successor expansion have the expected indices. No inconsistency or missing premise was identified in this source inspection.

The restriction `M ≥ 1` is materially necessary for arbitrary `E`: the assumptions leave `E 0` unrestricted, while the proposed zero-index right-hand side would be one. The separate concrete zero-index case below does not weaken that generic restriction.

### Concrete decimal statement

The new decimal module asserts that the inherited `DecimalProfile.sharpEscapeBound` has the exact multiplier-five recurrence by definitional equality, and uses the existing one-value theorem. It separately treats mass index zero using the inherited zero-value theorem. This yields the factor `4*5 = 20`.

The source applies the bound at mass index `2*B`. Natural subtraction means that the closed horizon is one at `B=0`. Its comment says the inherited exact horizon is zero. Verification of the original definition and its provenance remained outstanding at cancellation.

The numeric window statement is

```lean
(n : Nat) (hn : 0 < n) (B s : Nat) :
  ∃ t, s ≤ t ∧
    t ≤ s + 20 ^ (2 * B - 1) * factorial (2 * B) ∧
    B < DecimalMass.digitSum (Lychrel196.orbit n t)
```

The proof takes the time witness from the inherited sharp window theorem and enlarges only its upper endpoint. The interval is inclusive. There is no initial digit-sum bound and no palindrome premise in the new statement. The specialization to 196 supplies seed positivity.

The complete definitions of `Lychrel196.orbit`, decimal digit sum, the embedding, the existing escape theorem, and their transitive mathematical dependencies were **not independently inspected here**. Therefore this preliminary reading does not certify the ordinary-integer bridge, source attribution to the historical written recurrence, or transitive soundness.

## Verification and limitations

| Obligation | Status |
| --- | --- |
| Read role and accepted repository/publication rules | Completed |
| Recover 19 already-requested exact-head text files | Completed; exact content and Git blob identity match |
| Read both new mathematical modules completely | Completed |
| Read submitted audit and replay code before execution | Completed; not executed |
| Inspect the entire nine-module mathematical dependency closure | Not completed |
| Resolve and read the original historical strengthening notes | Not completed |
| Perform one clean eleven-module Lean 4.19 build | NOT_RUN |
| Exhaustive module-origin theorem/safe-definition axiom audit | NOT_RUN |
| Literal public endpoint types and transitive axiom audit | NOT_RUN |
| Inspect and verify compressed research archive | Not performed; parent-owned integration scope |
| Verify intended combined H+B tree and complete integration diff | Not performed; parent-owned integration scope |
| Formal platform review, Ready transition, or merge | Not performed |

The initial two-commit B-to-H name comparison was not treated as the contribution diff because H branches from an older ancestor; it reports many unrelated differences. The default rename-enabled comparison failed while reading absent blob `909c2b61e30676d6d3962f0d89282fa0a4cb8c04`. The source registry and replay script were also initially absent from the shared local object store. Exact-head connector recovery addressed the missing contribution text, with raw received responses retained. No attempt to bypass a tool or permission denial occurred.

No mathematical defect was established, and no proof patch was authored. No approval should be inferred from this incomplete record. Agent #12's separately assigned review and the parent's integration checks remain the active acceptance path.
