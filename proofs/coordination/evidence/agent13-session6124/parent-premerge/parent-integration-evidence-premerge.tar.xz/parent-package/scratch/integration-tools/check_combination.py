#!/usr/bin/env python3
"""Record a real three-way merge tree and preservation of scoped contributions."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--repo', required=True)
p.add_argument('--base', required=True)
p.add_argument('--head', required=True)
p.add_argument('--output', required=True)
a = p.parse_args()

def git(*args):
    return subprocess.check_output(['git', '-C', a.repo, *args])

def entries(ref):
    result = {}
    for row in git('ls-tree', '-rz', '--full-tree', ref).split(b'\0'):
        if row:
            metadata, path = row.split(b'\t', 1)
            mode, kind, oid = metadata.decode().split()
            result[path.decode()] = {'mode': mode, 'kind': kind, 'oid': oid}
    return result

ancestor = git('merge-base', a.base, a.head).decode().strip()
merge = subprocess.run(['git', '-C', a.repo, 'merge-tree', '--write-tree', a.base, a.head], capture_output=True, text=True)
out = Path(a.output)
out.parent.mkdir(parents=True, exist_ok=True)
report = {'scope': 'Git three-way tree and content-preservation verification; no Lean execution or mathematical acceptance.', 'base': a.base, 'head': a.head, 'merge_base': ancestor, 'merge_exit_code': merge.returncode, 'merge_stdout': merge.stdout, 'merge_stderr': merge.stderr}
if merge.returncode:
    report['status'] = 'CONFLICT_OR_TREE_ERROR'
else:
    tree = merge.stdout.splitlines()[0]
    old, base, head, combined = map(entries, [ancestor, a.base, a.head, tree])
    incoming = sorted(x for x in set(old) | set(head) if old.get(x) != head.get(x))
    integrated = sorted(x for x in set(base) | set(combined) if base.get(x) != combined.get(x))
    errors = []
    semantic_review = []
    for path in incoming:
        if base.get(path) != old.get(path) and base.get(path) != head.get(path):
            semantic_review.append({'path': path, 'ancestor': old.get(path), 'base': base.get(path), 'head': head.get(path), 'combined': combined.get(path)})
        elif combined.get(path) != head.get(path):
            errors.append({'path': path, 'reason': 'Incoming content was not preserved'})
    for path in (set(base) | set(combined)) - set(incoming):
        if combined.get(path) != base.get(path):
            errors.append({'path': path, 'reason': 'Unrelated current-base content changed'})
    report.update(status='PASS' if not errors and not semantic_review else 'NEEDS_SEMANTIC_REVIEW', combined_tree=tree, base_path_count=len(base), combined_path_count=len(combined), incoming_path_count=len(incoming), integration_delta_count=len(integrated), incoming_inventory={x: {'ancestor': old.get(x), 'head': head.get(x), 'combined': combined.get(x)} for x in incoming}, integration_delta={x: {'base': base.get(x), 'combined': combined.get(x)} for x in integrated}, errors=errors, semantic_review=semantic_review)
out.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k: report[k] for k in ('status', 'base', 'head', 'combined_tree', 'incoming_path_count', 'integration_delta_count', 'errors', 'semantic_review') if k in report}))
print('receipt_sha256=' + hashlib.sha256(out.read_bytes()).hexdigest())
raise SystemExit(report['status'] != 'PASS')
