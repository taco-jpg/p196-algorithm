# Agent #13 runtime and source retrieval report

## Scope and independence

This report covers read-only discovery and identity checks. No proof build, PR verification script, source repair, remote mutation, or review claim was executed by this specialist. Shared repositories, compiler trees, caches, and archives were not modified. Local evidence files were written only below `/workspace/scratch/6124a6476634/runtime-scout`.

## Runtime available

Primary Lean installation: `/tmp/p196-agent5-lean/lean-4.19.0-linux`.

Alternative preserved installation: `/workspace/scratch/cb81a8236405/toolchain/lean-4.19.0-linux`.

Both installations' executable bytes match:

| Executable | SHA-256 |
| --- | --- |
| `bin/lean` | `92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023` |
| `bin/lake` | `5111aee5c9434ab05d4265606475ef22e8bda69aaf3a0657b61a7eec6e550bed` |

Actual read-only checks in this session:

- `lean --version` under the ordinary sandbox failed with `error: failed to locate application`.
- `lake --version` under the ordinary sandbox succeeded: `Lake version 5.0.0-6caaee8 (Lean version 4.19.0)`.
- `lean --version` through the platform's approved `require_escalated` execution succeeded, exit code 0: `Lean (version 4.19.0, x86_64-unknown-linux-gnu, commit 6caaee842e94, Release)`.

This is compiler identification, not mathematical verification. Use an ordinary approved escalation for inspected, scoped verification when the ordinary sandbox cannot locate Lean; do not infer a build pass from the version check.

## Runtime provenance

The primary retained record is `/tmp/p196-agent5-lean/install-record.json`. It names the official release URL `https://github.com/leanprover/lean4/releases/download/v4.19.0/lean-4.19.0-linux.tar.zst`, records 343,842,845 bytes, and records local archive SHA-256 `6fe3ce97a58f44e2b3567d455b994eacec5bfe9ae7774f2a573444480ba813fe`. The original archive is not presently present at its recorded `/tmp/p196-agent5-lean/lean-4.19.0-linux.tar.zst` path.

The official GitHub release API was read in this session at `https://api.github.com/repos/leanprover/lean4/releases/tags/v4.19.0`. Asset 250981932 has the same filename and byte size; release publication is `2025-05-01T09:13:00Z`. Its `digest` is null. Therefore no independent upstream checksum verification is claimed.

The alternative installation's retained provenance record is `/tmp/agent2-toolchain/runtime_evidence.json`: repository `taco-jpg/p196-algorithm`, workflow run 38682760398, artifact 11948069575, preserved ZIP `/workspace/scratch/cb81a8236405/toolchain/lean419_checker.zip`, recorded ZIP SHA-256 `205d817f95c9425a6338743da10dc37960f5a64181d3127edbef1ccf5a91ed2d`. The executable hash in that record matches both binaries checked here. `/workspace/scratch/cb81a8236405/toolchain/official-archive.sha256` repeats the primary archive hash. These retained artifact claims have not been revalidated against the original workflow run in this session.

`/tmp/agent4-runtime` is a small Std-only Lake smoke project, not a Lean installation or Mathlib cache. Its manifest lists no packages.

## Exact source objects available

The useful recent local object database is `/workspace/scratch/aa9210d02a75/p196-agent12/.git/objects`. The read-only origin URL is the intended public repository `https://github.com/taco-jpg/p196-algorithm.git`. A second cache, `/workspace/scratch/046f9285a650/repo`, exposes the same relevant remote refs, but was not subjected to the same closure check.

Actual `git cat-file -p` checks found:

| Source | Commit | Root tree |
| --- | --- | --- |
| Main base | `5ff4f607535587d572fbc9e95ba9501d1fbe5fc5` | `c0a8ef6be298352e06ba6a9d68385bc63c6361fa` |
| PR 131 | `0bfe5347de0e5085307a3432975a18b83a3a2bba` | `a3a124b68b2e0e7bf14a7edfc0ed41a961b79a54` |
| PR 109 | `18a82d9b5a2bd326751621e3e7a5458117561da7` | `0009f72c3f77057c9f69c82c7e52401b6c636c17` |
| PR 123 | `0d1eea6c69078111366d9d7235bd47c3e16aadf8` | `22d0e7bedb4a17da349b9ca7afe394f3a73ea069` |
| Historical source | `2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5` | `9b7ce2e46a2f89c1cd3baf2cb4afc2d7032546ba` |

At the frozen main base, `proofs/archive/source-trees/2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5` is tree `42f5c00a445adb400b465fa55b565c224e76905e`.

The recent database is a partial cache: `remote.origin.promisor=true`. Read-only `git rev-list --objects --missing=print` over the five source commits returned 24,462 entries, including 9,796 missing objects. Commit presence must not be confused with complete source closure. `GIT_NO_LAZY_FETCH=1`, `GIT_TERMINAL_PROMPT=0`, and `GIT_OPTIONAL_LOCKS=0` were set for this audit, and no lazy fetch was attempted.

A useful retained historical object database is `/tmp/agent2-toolchain/bundle_objects.git/objects`: its bare repository contains 26,854 packed objects and no refs. Its recorded source is `/workspace/scratch/cb81a8236405/toolchain/source_snapshot/public-repository.bundle`. Retained provenance lists workflow run 38806420219, artifact 12064172562, recorded bundle SHA-256 `1b083971b3e13f233f8dc09b35f4f5aadb338a9e5cf498deead001b3f5b1188b`, and snapshot main `28358aef8fdfa145c5da3232cee891d08dbe51a6`. This snapshot is historical, not the current base. The bundle and metadata remain present. Its checksum and complete closure were not rerun here. `capture.json` describes a paginated, non-atomic snapshot and explicitly forbids treating transport retention as branch-deletion authorization.

## Reproducible preparation for isolated verification

The parent can initialize a new repository in its own workspace and point its object alternates at the two read-only databases:

```sh
p196_verify_repo=/workspace/scratch/6124a6476634/pr131-isolated
mkdir -p "$p196_verify_repo"
git init "$p196_verify_repo"
cat > "$p196_verify_repo/.git/objects/info/alternates" <<'EOF'
/workspace/scratch/aa9210d02a75/p196-agent12/.git/objects
/tmp/agent2-toolchain/bundle_objects.git/objects
EOF
git -C "$p196_verify_repo" update-ref refs/heads/pr131 0bfe5347de0e5085307a3432975a18b83a3a2bba
git -C "$p196_verify_repo" update-ref refs/heads/frozen-base 5ff4f607535587d572fbc9e95ba9501d1fbe5fc5
git -C "$p196_verify_repo" remote add origin https://github.com/taco-jpg/p196-algorithm.git
```

These are preparation commands, not commands executed by this specialist. Borrowed alternates can change or disappear; preserve the needed objects in the private repository before publishing durable evidence. Retrieve missing source objects only into the private repository, using the already authorized ordinary network path, or recover exact files through the GitHub connector and verify their Git blob identity. The existing parent-fetched source tree can supply already verified target bytes. Never manufacture a commit identity around substituted files. Populate the intended head or combined tree, audit each required module's source origin and closure, and ensure local `.olean` files cannot shadow the intended source before running the parent-inspected verifier. The retained historical directory provides provenance data, not automatic inclusion in the accepted build.

For scoped Std-only checks, use the identified Lean 4.19.0 runtime. No actual Mathlib source/cache was located in the bounded search of existing scratch and temporary runtime areas. The parent confirmed PRs 131, 109, and 123 do not need Mathlib, so no further Mathlib search or download was performed.

## Evidence files and limitations

`source-object-check.json` retains exact commit headers, the historical tree lookup, partial-clone facts, and the full missing-object list. `source-object-summary.json` is the concise version. No mathematical theorem, transitive axiom output, PR build, combined-tree verification, or post-merge result is certified by these records.
