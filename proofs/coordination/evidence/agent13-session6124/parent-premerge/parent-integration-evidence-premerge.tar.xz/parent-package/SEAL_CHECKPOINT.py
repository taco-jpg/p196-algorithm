"""Seal authorized parent evidence without executing project code."""
from pathlib import Path
from collections import defaultdict
import datetime, hashlib, json, lzma, os, tarfile

DISK = Path('/workspace/scratch/6124a6476634')
MEMORY = Path('/dev/shm/p196-agent13-session6124-20261016')
PACKAGE = MEMORY / 'parent-package'
ARCHIVE = MEMORY / 'parent-integration-evidence-premerge.tar.xz'
RECEIPT = MEMORY / 'parent-integration-evidence-premerge.ARCHIVE_RECEIPT.json'
BUDGET = 512 * 1024 * 1024
INPUTS = [(DISK/name, Path('scratch')/name) for name in
          ['evidence','integration-tools','ownership-scout','runtime-scout','review109','review123']]
INPUTS += [(MEMORY/name, Path('memory')/name) for name in
           ['publication','integration','parent-evidence','check_selected_closure.py',
            'integration-git-setup.json','SCOPE.json']]
ATTACHMENT_COPY = DISK/'review123/evidence/ROLE_PROMPT.txt'
EXCLUSIONS = []

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def write_json(relative, value):
    path=PACKAGE/relative
    assert not path.exists(), f'Refuse to overwrite {path}'
    path.parent.mkdir(parents=True,exist_ok=True)
    path.write_text(json.dumps(value,indent=2)+'\n')
    return path

def inventory_inputs(record_exclusions):
    found=[]
    for source, destination in INPUTS:
        assert source.exists(), f'Missing authorized input {source}'
        if source.is_file():
            assert not source.is_symlink()
            found.append((source,destination))
            continue
        for directory,dirs,files in os.walk(source,followlinks=False):
            keep=[]
            for name in sorted(dirs):
                child=Path(directory,name)
                if name.startswith('.') or name=='__pycache__' or child.is_symlink():
                    if record_exclusions:
                        EXCLUSIONS.append({'original_path':str(child),'bytes':None,
                          'reason':'Not traversed: hidden metadata/configuration, reproducible bytecode cache, or symlink lies outside the authorized evidence scope.'})
                else:
                    keep.append(name)
            dirs[:]=keep
            for name in sorted(files):
                child=Path(directory,name)
                reason=None
                if child==ATTACHMENT_COPY:
                    reason='User-attachment copy expressly excluded; its contents were not read or hashed for this sealing task.'
                elif name.startswith('.') or child.is_symlink():
                    reason='Hidden configuration/metadata or symlink excluded without reading its contents.'
                elif child.suffix in {'.olean','.ilean','.pyc','.o'}:
                    reason='Reproducible compiled infrastructure excluded; substantive source and execution logs retained.'
                if reason:
                    if record_exclusions:
                        EXCLUSIONS.append({'original_path':str(child),'bytes':child.lstat().st_size,'reason':reason})
                    continue
                found.append((child,destination/child.relative_to(source)))
    return sorted(found,key=lambda item:str(item[0]))

def memory_file_bytes():
    result=0
    for directory,dirs,files in os.walk(MEMORY,followlinks=False):
        dirs[:]=[name for name in dirs if not Path(directory,name).is_symlink()]
        for name in files:
            path=Path(directory,name)
            if not path.is_symlink():
                result+=path.stat().st_size
    return result

assert not ARCHIVE.exists() and not RECEIPT.exists()
started=now()
selected=inventory_inputs(True)
selected_total=sum(source.stat().st_size for source,_ in selected)
initial_memory_bytes=memory_file_bytes()
assert selected_total < 64*1024*1024
assert initial_memory_bytes + selected_total*3 + 16*1024*1024 < BUDGET
records=[]
for source,relative in selected:
    before=source.stat();data=source.read_bytes();after=source.stat()
    assert before.st_size==after.st_size==len(data)
    assert before.st_mtime_ns==after.st_mtime_ns, f'Source changed during read: {source}'
    target=PACKAGE/relative
    target.parent.mkdir(parents=True,exist_ok=True)
    assert not target.exists()
    target.write_bytes(data)
    assert target.read_bytes()==data
    records.append({'original_path':str(source),'stored_path':str(target),
      'package_path':relative.as_posix(),'archive_path':'parent-package/'+relative.as_posix(),
      'bytes':len(data),'sha256':sha(data),'original_mtime_ns':before.st_mtime_ns,
      'read_completed_at_utc':now(),'kind':'Unchanged original evidence'})
snapshot_completed=now()
record_by_origin={record['original_path']:record for record in records}
post_enumeration=inventory_inputs(False)
new_paths=[str(path) for path,_ in post_enumeration if str(path) not in record_by_origin]
missing_paths=[origin for origin in record_by_origin if not Path(origin).exists()]
changed_paths=[origin for origin,record in record_by_origin.items()
               if Path(origin).exists() and sha(Path(origin).read_bytes())!=record['sha256']]
write_json('SNAPSHOT_BOUNDARY.json',{
  'snapshot_started_at_utc':started,'snapshot_completed_at_utc':snapshot_completed,
  'new_paths_observed_after_initial_enumeration':new_paths,
  'missing_paths_observed_after_copy':missing_paths,'changed_paths_observed_after_copy':changed_paths,
  'scope':'Inventory frozen at initial enumeration; every retained file had stable metadata during its read. Later remote state and later-created evidence lie outside this checkpoint.',
  'atomic_remote_state_snapshot':False})
assert not missing_paths and not changed_paths, 'An input changed while taking the checkpoint; inspect the preserved boundary record.'
write_json('INPUT_SNAPSHOT_MANIFEST.json',{
  'schema_version':1,'checkpoint':'PREMERGE_EVIDENCE_ONLY','file_count':len(records),
  'original_bytes':sum(record['bytes'] for record in records),
  'snapshot_started_at_utc':started,'snapshot_completed_at_utc':snapshot_completed,
  'hash_algorithm':'SHA-256','files':records})
write_json('EXCLUSIONS.json',{
  'policy':'Retain substantive sources, scripts, failed attempts and full logs from the authorized inputs. Do not read user attachments, hidden configuration or Git internals.',
  'excluded_paths':EXCLUSIONS,
  'separately_published_pr131':{
     'commit':'1a8c4b93df46a8b6172cc1323004e0c2a17ad1db',
     'reason':'The parent reports that the complete PR #131 supplement is already published at this commit. Its separate archive is not duplicated; parent session references remain intact.',
     'remote_commit_rechecked_in_this_task':False}})

compressed=PACKAGE/'memory/publication/pr127-v1.json.xz'
with lzma.open(compressed,'rb') as source:
    v1=source.read(32*1024*1024+1)
assert len(v1)<=32*1024*1024
v1_json=json.loads(v1)
restored=PACKAGE/'restored/publication/pr127-v1.json'
restored.parent.mkdir(parents=True,exist_ok=True)
restored.write_bytes(v1)
assert restored.read_bytes()==v1
historical=json.loads((PACKAGE/'memory/publication/PR110_HISTORICAL_CHECKPOINT_RECOVERY.json').read_text())
assert len(historical)==3
historical_checks=[]
for record in historical:
    path=PACKAGE/'memory/publication/historical'/record['commit']/record['path']
    data=path.read_bytes()
    git_blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
    assert len(data)==record['bytes'] and sha(data)==record['sha256'] and git_blob==record['git_blob']
    historical_checks.append({**record,'stored_path':str(path),'archive_path':'parent-package/'+path.relative_to(PACKAGE).as_posix(),'byte_and_git_blob_identity':'PASS'})
write_json('PRESERVATION_CHECKS.json',{
   'scope':'Local archival identity checks only; no project source or verifier execution.',
   'complete_original_v1_report':{
     'compressed_original_path':str(compressed),'compressed_bytes':compressed.stat().st_size,
     'compressed_sha256':sha(compressed.read_bytes()),'restored_path':str(restored),
     'restored_bytes':len(v1),'restored_sha256':sha(v1),'complete_json_parse':True,
     'unchanged_report_status':v1_json.get('status'),
     'derivation':'Lossless XZ decompression; no report fields altered.'},
   'pr110_historical_files':historical_checks,
   'publication_programs_retained':['memory/publication/check_publication_v1.py','memory/publication/check_publication_v2.py'],
   'initial_pr110_report_retained':'memory/publication/pr110-initial.json',
   'project_code_executed':False,'lean_invocations':0,'remote_calls':0})
status_records=[]
for name in ['pr110-initial.json','pr110-final.json','pr127-final.json','pr128-final.json']:
    obj=json.loads((PACKAGE/'memory/publication'/name).read_text())
    status_records.append({'file':name,**{key:obj.get(key) for key in ['pr','head','status','file_count','manifest_check_count']}})
summary=defaultdict(lambda:[0,0])
for record in records:
    key='/'.join(Path(record['package_path']).parts[:2])
    summary[key][0]+=1;summary[key][1]+=record['bytes']
summary_table='\n'.join('| `'+key+'` | '+str(value[0])+' | '+str(value[1])+' |' for key,value in sorted(summary.items()))
publication_table='\n'.join('| `'+item['file']+'` | '+str(item['pr'])+' | `'+str(item['status'])+'` |' for item in status_records)
report=f'''# Parent integration evidence: premerge checkpoint

## Result and boundary

**The specified parent evidence has been sealed as a premerge checkpoint.** This is an evidence preservation result, not a merge receipt or a new mathematical acceptance decision. No Lean process, project verifier, remote API call, source edit or external mutation was performed in this sealing task. Existing parent reports were copied without modification.

The snapshot began at `{started}` and finished copying at `{snapshot_completed}`. It retains **{len(records)} original files totaling {sum(record['bytes'] for record in records):,} bytes**, together with preservation metadata and the complete losslessly restored initial PR #127 publication report. Every original copy was checked against its source bytes; a second hash pass found no changed or missing retained inputs. The frozen inventory and any later-created paths are recorded in `SNAPSHOT_BOUNDARY.json`. This local file snapshot does not assert an atomic remote GitHub state.

The parent remains responsible for actual reviews, final current-base checks, required platform gates, publication and merge. This package must not be cited as evidence that any merge occurred.

## Complete retained input scope

| Stored input group | Original files | Original bytes |
| --- | ---: | ---: |
{summary_table}

`INPUT_SNAPSHOT_MANIFEST.json` provides every full original absolute path, full stored absolute path, archive member path, byte count and SHA-256. It also records each read completion time and original modification timestamp. `MANIFEST.json` covers every delivered package file other than itself; the outer archive receipt separately pins the manifest.

Original source snapshots, discovery/replay scripts, solver data, failed attempts, exact logs and intermediate reports remain intact. Ownership and runtime reconnaissance, received source identities, integration programs and combination/closure results are included. Inclusion of an author's historical report does not convert it into this agent's execution.

## Initial publication failures and corrections

The original `memory/publication/pr127-v1.json.xz` is retained byte-for-byte. Its complete decompressed report is also retained as `restored/publication/pr127-v1.json`: **{len(v1):,} bytes**, SHA-256 `{sha(v1)}`. The complete JSON parses and retains the original status `{v1_json.get('status')}`. Neither failures nor fields were rewritten. Both publication program versions are preserved.

The existing reports retain these labels:

| Original report | PR | Preserved status |
| --- | ---: | --- |
{publication_table}

These labels describe retained parent reports; this task does not rerun their underlying checks. The PR #110 historical recovery receipt and all three recovered Git files are included. Every recovered file matches its recorded byte count, SHA-256 and Git blob identity. `PRESERVATION_CHECKS.json` gives the exact commits, paths and results. Both initial and corrected PR #110 reports remain available.

## Stopped review records and exclusions

PR #109 retains `STOPPED_DUPLICATE_COORDINATION`, zero Lean processes and `NOT_RUN` for required builds and audits. PR #123 retains `STOPPED_ON_PARENT_SCOPE_REASSIGNMENT`, zero compile attempts and the corresponding `NOT_RUN` results. Their acquired source material and acquisition evidence are included. Neither interrupted review is represented as accepted.

No user attachment, hidden configuration, Git metadata directory or alternate object store was read into this package. The recognized user-attachment copy `review123/evidence/ROLE_PROMPT.txt` was excluded without reading or hashing its contents. The two private Git directories were not traversed. `EXCLUSIONS.json` identifies every observed exclusion. All other substantive files in the specified inputs were retained.

The parent identifies the complete PR #131 supplement as already published at commit `1a8c4b93df46a8b6172cc1323004e0c2a17ad1db`; its separate archive is not duplicated. Existing references remain in the session records. This task did not query or republish that commit.

## Resource, preparation failure and recovery

The stored package is `{PACKAGE}`; its archive is `{ARCHIVE}`. The initial session memory directory held {initial_memory_bytes:,} logical file bytes; the added original snapshot was {selected_total:,} bytes. The archive receipt records the final session total against the authorized 512 MiB output budget.

The original ENOSPC incident and recovery records remain included. A first attempt to prepare this packaging program failed to parse before executing because of nested quoting and a reused heredoc delimiter. Its actual diagnostic and execution boundary are retained in `PACKAGING_PREPARATION_FAILURE.json`; the failed request's complete text remains in its original tool transcript. No program source file existed from that failed preparation. The replacement executed program is retained as `SEAL_CHECKPOINT.py`.

No original source, failed record, log or research artifact was deleted. `RECOVER.md` explains extraction into a fresh directory and hash verification. Every archive member was separately decompressed and compared byte-for-byte with its staged original.
'''
(PACKAGE/'CHECKPOINT_REPORT.md').write_text(report)
recovery='''# Recover the parent premerge evidence checkpoint

The adjacent `parent-integration-evidence-premerge.ARCHIVE_RECEIPT.json` identifies the compressed byte count and SHA-256, pins the full manifest, and records byte-for-byte verification of every archive member. Check that identity before extraction.

Create a new output directory:

```sh
mkdir recovered-parent-premerge
tar -xJf parent-integration-evidence-premerge.tar.xz -C recovered-parent-premerge
```

The extracted root is `recovered-parent-premerge/parent-package`. The `scratch/` and `memory/` groups preserve the input structure; original absolute paths appear in `INPUT_SNAPSHOT_MANIFEST.json`. Historical execution paths inside original logs remain untouched.

Run this standard-library check from the recovered package root to verify its file identities:

```sh
python3 - <<'PY'
from pathlib import Path
import hashlib, json
root = Path.cwd()
manifest = json.loads((root / 'MANIFEST.json').read_text())
for record in manifest['files']:
    data = (root / record['package_path']).read_bytes()
    assert len(data) == record['bytes'], record['package_path']
    assert hashlib.sha256(data).hexdigest() == record['sha256'], record['package_path']
print('Every manifest-listed file matches its recorded bytes and SHA-256.')
PY
```

The manifest omits itself to avoid a circular hash; the outer receipt pins its own identity. `PRESERVATION_CHECKS.json` identifies the lossless restoration of the complete initial report. Earlier failures remain failures in the original records. This checkpoint makes no claim that a merge or additional Lean audit occurred.
'''
(PACKAGE/'RECOVER.md').write_text(recovery)

all_files=sorted(path for path in PACKAGE.rglob('*') if path.is_file())
assert all(not path.is_symlink() for path in all_files)
origin_by_stored={record['stored_path']:record['original_path'] for record in records}
manifest_records=[]
for path in all_files:
    data=path.read_bytes();relative=path.relative_to(PACKAGE).as_posix()
    manifest_records.append({'package_path':relative,'archive_path':'parent-package/'+relative,
      'stored_path':str(path),'original_path':origin_by_stored.get(str(path)),
      'kind':'Unchanged original evidence' if str(path) in origin_by_stored else 'New preservation metadata or explicit lossless restoration',
      'bytes':len(data),'sha256':sha(data)})
manifest_path=write_json('MANIFEST.json',{'schema_version':1,'checkpoint':'PREMERGE_EVIDENCE_ONLY',
  'hash_algorithm':'SHA-256','file_count':len(manifest_records),'original_file_count':len(records),
  'all_listed_file_bytes':sum(record['bytes'] for record in manifest_records),
  'self_exclusion':'This manifest is excluded from its own list; the outer archive receipt pins it.',
  'files':manifest_records})
manifest_data=manifest_path.read_bytes()
manifest_records.append({'package_path':'MANIFEST.json','archive_path':'parent-package/MANIFEST.json',
  'bytes':len(manifest_data),'sha256':sha(manifest_data)})
with tarfile.open(ARCHIVE,'w:xz',preset=6,format=tarfile.PAX_FORMAT) as tar:
    for record in sorted(manifest_records,key=lambda item:item['package_path']):
        tar.add(PACKAGE/record['package_path'],arcname=record['archive_path'],recursive=False)
expected={record['archive_path']:record for record in manifest_records}
with tarfile.open(ARCHIVE,'r:xz') as tar:
    members=tar.getmembers()
    assert len(members)==len(expected)
    assert len({member.name for member in members})==len(members)
    for member in members:
        assert member.isfile() and member.name in expected
        assert not member.name.startswith('/') and '..' not in Path(member.name).parts
        data=tar.extractfile(member).read();record=expected[member.name]
        assert len(data)==record['bytes'] and sha(data)==record['sha256']
        assert data==(PACKAGE/record['package_path']).read_bytes()
archive_data=ARCHIVE.read_bytes()
final_memory_bytes=memory_file_bytes()
assert final_memory_bytes < BUDGET
receipt={'schema_version':1,'status':'PASS_LOSSLESS_PREMERGE_CHECKPOINT_EVERY_MEMBER_BYTE_VERIFIED',
  'checkpoint':'PREMERGE_EVIDENCE_ONLY','merge_claim':False,
  'snapshot_started_at_utc':started,'snapshot_completed_at_utc':snapshot_completed,
  'archive':{'path':str(ARCHIVE),'bytes':len(archive_data),'sha256':sha(archive_data),
    'format':'POSIX pax tar with lossless XZ compression'},
  'archive_member_count':len(expected),'all_member_original_bytes':sum(record['bytes'] for record in manifest_records),
  'input_original_file_count':len(records),'input_original_bytes':sum(record['bytes'] for record in records),
  'every_member_extracted_and_byte_compared':True,'symlinks_or_unsafe_member_paths':False,
  'manifest':{'path':str(manifest_path),'bytes':len(manifest_data),'sha256':sha(manifest_data)},
  'report':{'path':str(PACKAGE/'CHECKPOINT_REPORT.md'),'sha256':sha((PACKAGE/'CHECKPOINT_REPORT.md').read_bytes())},
  'full_path_input_manifest':str(PACKAGE/'INPUT_SNAPSHOT_MANIFEST.json'),
  'preservation_checks':str(PACKAGE/'PRESERVATION_CHECKS.json'),
  'exclusions':str(PACKAGE/'EXCLUSIONS.json'),'recovery_instructions':str(PACKAGE/'RECOVER.md'),
  'memory_file_bytes_after_archive_before_receipt':final_memory_bytes,'memory_budget_bytes':BUDGET,
  'separately_published_pr131_commit':'1a8c4b93df46a8b6172cc1323004e0c2a17ad1db',
  'lean_invocations':0,'remote_calls':0,'original_parent_report_modifications':0,
  'generated_at_utc':now()}
RECEIPT.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({**receipt,'receipt_path':str(RECEIPT),'receipt_sha256':sha(RECEIPT.read_bytes())},indent=2))
