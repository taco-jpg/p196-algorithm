#!/usr/bin/env python3
"""Check retained publication inventories against exact incoming Git contents.

This checks byte identities and explicit omission records. It does not execute
historical research scripts or promote their reported mathematical outcomes.
"""

import hashlib
import json
import os
from pathlib import Path
import posixpath
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]
REPO = ROOT / "repo"
TARGETS = {
    110: ("624cc122e39e4d1f30b5c17890e7aac17c40a1e9", "agent-1/groupIII-handoff-20261016"),
    127: ("c68b0aaa5344f2cc646c035e2efca187852cb57d", "agent-7/allbase-overflow-births-20261016"),
    128: ("0a5cdbb1d265a659d34b3444f3daf41ebd077e43", "agent-104/620-depth12-witness-20261016"),
}


def digest(data):
    return hashlib.sha256(data).hexdigest()


class Audit:
    def __init__(self, pr, head, package):
        self.pr, self.head = pr, head
        self.root = ROOT / "evidence" / f"pr{pr}-incoming"
        self.package = "proofs/contributions/" + package
        self.records = []
        self.omitted = {}
        self.cache = {}

    def read(self, path):
        if path in self.cache:
            return self.cache[path]
        local = self.root / path
        if local.is_file():
            data = local.read_bytes()
        else:
            env = dict(os.environ, GIT_NO_LAZY_FETCH="1")
            r = subprocess.run(["git", "-C", str(REPO), "cat-file", "blob", self.head + ":" + path], capture_output=True, env=env)
            data = r.stdout if r.returncode == 0 else None
        self.cache[path] = data
        return data

    def path(self, manifest, target, package_relative=False):
        if target.startswith("proofs/"):
            result = target
        else:
            parent = self.package if package_relative else posixpath.dirname(manifest)
            result = posixpath.normpath(posixpath.join(parent, target))
        if result.startswith("/") or result == ".." or result.startswith("../"):
            raise ValueError("Path escapes repository: " + result)
        return result

    def check(self, manifest, target, metadata=None, package_relative=False, historical=False):
        metadata = metadata or {}
        path = self.path(manifest, target, package_relative)
        data = self.read(path)
        rec = {"manifest": manifest, "recorded_path": target, "resolved_path": path, "historical_checkpoint": historical}
        if data is None:
            omission = self.omitted.get(path)
            if omission and omission["valid"]:
                rec.update(status="EXPLICIT_OMISSION", omission=omission)
                if metadata.get("sha256") and omission.get("sha256") and metadata["sha256"] != omission["sha256"]:
                    rec["status"] = "OMISSION_HASH_CONFLICT"
                if metadata.get("bytes") is not None and omission.get("bytes") is not None and metadata["bytes"] != omission["bytes"]:
                    rec["status"] = "OMISSION_SIZE_CONFLICT"
            else:
                rec["status"] = "MISSING"
        else:
            rec.update(actual_bytes=len(data), actual_sha256=digest(data))
            mismatch = {key: metadata[key] for key in ("bytes", "sha256") if key in metadata and metadata[key] != rec["actual_" + key]}
            rec["status"] = "MISMATCH" if mismatch else "MATCH"
            if mismatch:
                rec["expected"] = mismatch
        self.records.append(rec)

    def collect_omissions(self):
        for p in sorted((self.root / self.package).rglob("*.json")):
            manifest = p.relative_to(self.root).as_posix()
            obj = json.loads(p.read_text())
            if not isinstance(obj, dict):
                continue
            for field in ("omitted_files", "omitted_reproducible", "excluded_generated_objects"):
                for item in obj.get(field, []):
                    path = self.path(manifest, item["path"], field == "omitted_reproducible")
                    rec = dict(item, manifest=manifest, valid=False)
                    retained = item.get("retained_source") or item.get("source")
                    if path.endswith(".olean") and item.get("reason"):
                        rec.update(valid=True, classification="reproducible_compiler_object")
                    elif retained:
                        source_path = self.path(manifest, retained, field == "omitted_reproducible")
                        data = self.read(source_path)
                        rec["retained_source_resolved"] = source_path
                        rec["valid"] = data is not None and digest(data) == item["sha256"] and len(data) == item["bytes"]
                        if item.get("retained_source_sha256"):
                            rec["valid"] = rec["valid"] and item["retained_source_sha256"] == item["sha256"]
                        rec["classification"] = "exact_duplicate_source"
                    self.omitted[path] = rec

    def run(self):
        self.collect_omissions()
        for p in sorted((self.root / self.package).rglob("*.json")):
            manifest = p.relative_to(self.root).as_posix()
            obj = json.loads(p.read_text())
            if isinstance(obj, dict):
                if p.name == "FILES.json":
                    for path, meta in obj.items():
                        self.check(manifest, path, meta)
                if isinstance(obj.get("files"), dict):
                    for path, meta in obj["files"].items():
                        if isinstance(meta, dict) and "sha256" in meta:
                            self.check(manifest, path, meta, historical=p.name.startswith("CHECKPOINT"))
                if p.name == "PUBLICATION.json":
                    for field in ("retained", "retained_files"):
                        for meta in obj.get(field, []):
                            self.check(manifest, meta["path"], meta, package_relative=field == "retained")
            elif isinstance(obj, list) and p.name.endswith("FILES.json"):
                for path in obj:
                    self.check(manifest, path)
        for p in sorted((self.root / self.package).rglob("*.sha256")):
            manifest = p.relative_to(self.root).as_posix()
            for line in p.read_text().splitlines():
                match = re.fullmatch(r"([0-9a-f]{64})\s+\*?(.+)", line)
                if not match:
                    self.records.append({"manifest": manifest, "status": "BAD_HASH_LINE", "line": line})
                    continue
                self.check(manifest, match[2], {"sha256": match[1]})
        for p in sorted((self.root / self.package).rglob("PUBLISH_REVIEW_FILES.txt")):
            for path in p.read_text().splitlines():
                if path:
                    self.check(p.relative_to(self.root).as_posix(), path)
        problems = [r for r in self.records if r["status"] not in ("MATCH", "EXPLICIT_OMISSION")]
        omissions_invalid = {p: r for p, r in self.omitted.items() if not r["valid"]}
        inventory = [{"path": p.relative_to(self.root).as_posix(), "bytes": p.stat().st_size, "sha256": digest(p.read_bytes())} for p in sorted(self.root.rglob("*")) if p.is_file()]
        return {"reviewer": "Agent #13/session6124", "pr": self.pr, "head": self.head, "scope": "Retained manifest byte identities, explicit omission sources, and incoming file inventory; no historical code executed.", "status": "PASS" if not problems and not omissions_invalid else "NEEDS_CLASSIFICATION_OR_REPAIR", "file_count": len(inventory), "file_bytes": sum(x["bytes"] for x in inventory), "manifest_check_count": len(self.records), "omission_count": len(self.omitted), "problems": problems, "invalid_omissions": omissions_invalid, "checks": self.records, "omissions": self.omitted, "inventory": inventory}


if __name__ == "__main__":
    out = ROOT / "evidence" / "publication-audit-001"
    out.mkdir(exist_ok=False)
    for pr, (head, package) in TARGETS.items():
        report = Audit(pr, head, package).run()
        destination = out / f"pr{pr}.json"
        destination.write_text(json.dumps(report, indent=2) + "\n")
        print(json.dumps({"pr": pr, "status": report["status"], "checks": report["manifest_check_count"], "omissions": report["omission_count"], "problems": report["problems"], "invalid_omissions": report["invalid_omissions"], "report_sha256": digest(destination.read_bytes())}))
