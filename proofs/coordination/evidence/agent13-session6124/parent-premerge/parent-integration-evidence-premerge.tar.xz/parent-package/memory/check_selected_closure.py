#!/usr/bin/env python3
"""Bind a reviewed source registry to a real current-target merge tree."""
import argparse, hashlib, json, subprocess
from pathlib import Path
p=argparse.ArgumentParser()
p.add_argument('--repo',required=True);p.add_argument('--head',required=True);p.add_argument('--base',required=True);p.add_argument('--tree',required=True);p.add_argument('--registry',required=True);p.add_argument('--output',required=True)
a=p.parse_args()
def get(ref,path): return subprocess.check_output(['git','-C',a.repo,'cat-file','blob',ref+':'+path])
def oid(data): return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def sha(data): return hashlib.sha256(data).hexdigest()
reg=get(a.head,a.registry);projects=json.loads(reg)['projects'];projects=projects if isinstance(projects,list) else projects.values()
records=[];errors=[]
for project in projects:
 for name,spec in project['modules'].items():
  old=get(a.head,spec['path']);new=get(a.tree,spec['path'])
  valid=(old==new and sha(new)==spec['sha256'] and oid(new)==spec['git_blob'])
  records.append({'module':name,'path':spec['path'],'bytes':len(new),'sha256':sha(new),'git_blob':oid(new),'matches_reviewed_head_and_registry':valid})
  if not valid:errors.append(name)
aux=[]
for path in [a.registry,'proofs/verify_project__214bf7673efe116b.py']:
 old=get(a.head,path);new=get(a.tree,path);same=old==new
 aux.append({'path':path,'sha256':sha(new),'git_blob':oid(new),'matches_reviewed_head':same})
 if not same:errors.append(path)
policies=[]
for path in ['AGENTS.md','proofs/PUBLICATION_POLICY.md']:
 old=get(a.base,path);new=get(a.tree,path);same=old==new
 policies.append({'path':path,'sha256':sha(new),'git_blob':oid(new),'matches_current_base':same})
 if not same:errors.append(path)
report={'reviewer':'Agent #13/session6124','status':'PASS_UNCHANGED_SELECTED_CLOSURE_ON_COMBINED_TARGET' if not errors else 'FAIL','head':a.head,'base':a.base,'combined_tree':a.tree,'scope':'Byte identity binds the executed selected-source build to this actual merge tree. No unrelated main build is asserted.','registry_path':a.registry,'modules':records,'auxiliary_inputs':aux,'current_base_policies':policies,'errors':errors}
out=Path(a.output);out.parent.mkdir(parents=True,exist_ok=True);out.write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'module_count':len(records),'errors':errors,'report_sha256':sha(out.read_bytes())}))
raise SystemExit(bool(errors))
