# Evidence recovery and independent replay

## Recovery

The adjacent `ARCHIVE_RECEIPT.json` identifies the compressed archive, its byte count and SHA-256, and records a complete byte-for-byte extraction check. Extract the archive into a newly created directory:

```sh
mkdir recovered-pr128-review
tar -xzf review128-exact-head-0a5cdbb-evidence.tar.gz -C recovered-pr128-review
```

The recovered package root is `recovered-pr128-review/review128`. Its `MANIFEST.json` lists every retained file other than the manifest itself, with its archive path, original byte count and SHA-256. The outer archive receipt pins the manifest's own hash. Sources, programs, logs and original failed receipts are preserved without textual normalization. The original execution paths recorded in historical logs are evidence and are not rewritten to extraction paths.

Only the reproducible infrastructure listed in `EXCLUDED_INFRASTRUCTURE.json` was excluded: private Git metadata/object stores, compiled project objects and Python caches. The eleven complete source snapshots and the pinned original registry are included. The successful audit's preflight records the exact self-built object identities. This independent review package supplements the incoming PR contribution package; the integration owner publishes and verifies that complete incoming package separately.

## Fresh replay recipe

Use the Lean 4.19.0 Linux release at commit `6caaee842e94`. The actual compiler used here has SHA-256 `92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023`. The pinned registry `build-001/original.registry.json` supplies the exact eleven source SHA-256 values and their Git blob/path identities at reviewed head `0a5cdbb1d265a659d34b3444f3daf41ebd077e43`. Check those identities and the package manifest before replay. The following commands are a recipe for a new independent execution; they were not run again during final packaging.

Set these three task-specific paths to the recovered package, the verified compiler and a new output directory. Keep the compiler's original standard-library distribution intact.

```sh
review_archive_root=/absolute/path/recovered-pr128-review/review128
review_lean=/absolute/path/lean-4.19.0-linux/bin/lean
review_replay_root=/absolute/path/new-pr128-replay
mkdir "$review_replay_root"
mkdir "$review_replay_root/source" "$review_replay_root/logs"
cp "$review_archive_root"/build-001/source/*.lean "$review_replay_root/source/"
cp "$review_archive_root/audit-003/ReviewAuditFinal.lean" "$review_replay_root/source/ReviewAuditFinal.lean"
cd "$review_replay_root/source"
for review_module in LychrelDigitSums PrefixInverse ActualPrefix PrefixCertificate LongRowsBase FastInverse FastRowsBase PalindromeBridge ShortBoundary Agent124PrefixK Agent104620Witness
do
  env -i PATH="${review_lean%/*}:/usr/bin:/bin" LANG=C.UTF-8 LEAN_PATH="$review_replay_root/source"     "$review_lean" --trust=0 -j1 -DElab.async=false "$review_module.lean" -o "$review_module.olean"     > "$review_replay_root/logs/$review_module.log" 2>&1 || exit 1
done
env -i PATH="${review_lean%/*}:/usr/bin:/bin" LANG=C.UTF-8 LEAN_PATH="$review_replay_root/source"   "$review_lean" --trust=0 -j1 -DElab.async=false ReviewAuditFinal.lean   > "$review_replay_root/logs/ReviewAuditFinal.log" 2>&1
```

The final audit must exit 0. It checks seven literal contracts, prints the actual seven theorem types and their transitive axioms, prints the actual mathematical definitions, and enumerates every declaration originating in the eleven selected modules. The expected successful census is 1,364 theorem declarations, 251 safe definitions, no safe opaques and 46 other logical declarations; the axiom union is the three standard permitted axioms. The raw audit also explicitly inventories 1,004 unsafe implementation definitions and 52 unsafe specialization placeholders. These are separate from the 1,661 audited logical declarations. Their inspected categories and the original implementation-name census are retained in the evidence.

`integer_replay.py` is the full independently written ordinary-integer replay, with its actual output under `evidence/integer-replay.json`. The historical build and postprocessing programs contain original absolute session paths. They are preserved as executed. For a relocated replay, choose new output paths explicitly; do not overwrite the retained original receipts. `postprocess-004/verification.json` is the final successful result, while `build-001/verification.json`, `audit-002/verification.json` and `audit-003/verification.json` intentionally retain their actual earlier failure statuses.
