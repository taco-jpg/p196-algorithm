#!/usr/bin/env python3
"""Independent ordinary-integer check of the exact PR #128 witness only."""
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import sys


ROOT = Path(__file__).resolve().parent
EXPECTED = [
    19014942070, 26039883161, 42178776223, 74446563347,
    148783127794, 646504515635, 1183019921281, 3004319025092,
    5909528159095, 11819046418190, 21000510510001,
    31002012010013, 62003033030026,
]


def digits(n):
    assert type(n) is int and n > 0
    result = []
    while n:
        n, digit = divmod(n, 10)
        result.append(digit)
    return result


def reverse_decimal(n):
    assert type(n) is int and n >= 0
    result = 0
    while n:
        n, digit = divmod(n, 10)
        result = 10 * result + digit
    return result


def main():
    source = ROOT / "repo/proofs/Agent104620Witness.lean"
    source_bytes = source.read_bytes()
    assert hashlib.sha256(source_bytes).hexdigest() == "fb65cab70bf90214691a06904cd93a621d2e0c0edeba13dffc4df9a2b7d645a6"
    literal = re.search(r"theorem exact_trajectory\s*:\s*.*?=\s*\[([^\]]*)\]", source_bytes.decode(), re.S)
    assert literal is not None
    advertised = [int(x.strip()) for x in literal.group(1).split(",")]
    assert advertised == EXPECTED
    actual = [EXPECTED[0]]
    for _ in range(12):
        actual.append(actual[-1] + reverse_decimal(actual[-1]))
    assert actual == EXPECTED
    rows = []
    for t, n in enumerate(actual):
        ds, rev = digits(n), reverse_decimal(n)
        assert all(0 <= d <= 9 for d in ds) and ds[-1] > 0
        assert sum(d * 10 ** i for i, d in enumerate(ds)) == n
        row = {"time": t, "integer": str(n), "decimal_width": len(ds),
               "reverse_integer": str(rev), "palindrome": rev == n,
               "digits_units_first": ds}
        if t < 12:
            successor = actual[t + 1]
            assert n + rev == successor
            row["next_integer"] = str(successor)
            row["actual_width_increases"] = len(digits(successor)) > len(ds)
            row["trailing_zero"] = ds[0] == 0
        rows.append(row)
    palindromic_times = [r["time"] for r in rows if r["palindrome"]]
    assert palindromic_times == [12]
    target_digits = digits(actual[-1])
    assert len(target_digits) == 14
    assert [target_digits[13], target_digits[12], target_digits[11]] == [6, 2, 0]
    assert actual[0] > 0
    controls = [{"n": n, "reverse": reverse_decimal(n), "expected": expected}
                for n, expected in [(0, 0), (1200, 21), (10700, 701), (56, 65)]]
    assert all(c["reverse"] == c["expected"] for c in controls)
    result = {
        "status": "PASS_INDEPENDENT_DIVMOD_EXACT_TRAJECTORY_FIRST_HIT_AND_CANONICAL_PREFIX",
        "reviewer": "Agent #13 genuine nonauthor subagent /root/review128",
        "reviewed_head": "0a5cdbb1d265a659d34b3444f3daf41ebd077e43",
        "source_sha256": hashlib.sha256(source_bytes).hexdigest(),
        "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
        "executed_at_utc": datetime.now(timezone.utc).isoformat(),
        "argv": sys.argv,
        "seed": str(actual[0]), "target": str(actual[-1]), "step_count": 12,
        "positive_seed": True, "palindromic_times_in_closed_interval_0_12": palindromic_times,
        "all_earlier_times_nonpalindromic": True,
        "canonical_target_width": 14, "leading_three_digits": [6, 2, 0],
        "actual_predicate": "Agent124.PrefixK.PalStarts3 6 2 0",
        "arithmetic": "Python arbitrary precision natural integers and divmod only",
        "author_discovery_or_replay_code_imported": False,
        "solver_used": False, "seed_search_run": False,
        "widths": [r["decimal_width"] for r in rows], "trajectory": rows,
        "reverse_controls": controls,
        "scope": "One fixed seed and times 0 through 12. No minimal seed, minimal width, upper bound, all-time avoidance, or 196 conjecture claim.",
    }
    out = ROOT / "evidence/integer-replay.json"
    with out.open("x") as stream:
        stream.write(json.dumps(result, indent=2) + "\n")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
