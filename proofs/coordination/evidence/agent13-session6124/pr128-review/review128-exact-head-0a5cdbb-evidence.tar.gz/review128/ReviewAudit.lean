import Agent104620Witness
import Lean

open Lean Elab Command
open Lychrel196 DecimalDigits Agent124.PrefixK
open Agent104.Prefix620Witness

set_option maxRecDepth 100000
set_option maxHeartbeats 0
set_option pp.width 1000000

-- Literal contracts independently pin all seven public theorem statements.
example : (List.range 13).map (orbit 19014942070) =
    [19014942070, 26039883161, 42178776223, 74446563347,
     148783127794, 646504515635, 1183019921281, 3004319025092,
     5909528159095, 11819046418190, 21000510510001,
     31002012010013, 62003033030026] := exact_trajectory
example : orbit 19014942070 12 = 62003033030026 := twelve_steps
example : Canonical 62003033030026 (fun i => (62003033030026 / 10 ^ i) % 10) 14 :=
  target_canonical
example : PalStarts3 6 2 0 62003033030026 := target_mem_family
example : Palindrome (orbit 19014942070 12) ∧
    ∀ t, t < 12 → ¬ Palindrome (orbit 19014942070 t) := first_hit_twelve
example : ∃ A, 0 < A ∧ PalStarts3 6 2 0 (orbit A 12) := realized_depth12
example (B : Nat)
    (hB : ∀ A P t, 0 < A → PalStarts3 6 2 0 P → orbit A t = P → t ≤ B) :
    12 ≤ B := any_uniform_bound_ge12 B hB

#check @Agent104.Prefix620Witness.exact_trajectory
#check @Agent104.Prefix620Witness.twelve_steps
#check @Agent104.Prefix620Witness.target_canonical
#check @Agent104.Prefix620Witness.target_mem_family
#check @Agent104.Prefix620Witness.first_hit_twelve
#check @Agent104.Prefix620Witness.realized_depth12
#check @Agent104.Prefix620Witness.any_uniform_bound_ge12
#print axioms Agent104.Prefix620Witness.exact_trajectory
#print axioms Agent104.Prefix620Witness.twelve_steps
#print axioms Agent104.Prefix620Witness.target_canonical
#print axioms Agent104.Prefix620Witness.target_mem_family
#print axioms Agent104.Prefix620Witness.first_hit_twelve
#print axioms Agent104.Prefix620Witness.realized_depth12
#print axioms Agent104.Prefix620Witness.any_uniform_bound_ge12
#print Lychrel196.reverseFuel
#print Lychrel196.reverse10
#print Lychrel196.Palindrome
#print Lychrel196.step
#print Lychrel196.orbit
#print DecimalDigits.value
#print DecimalDigits.Canonical
#print Agent124.PrefixK.Starts3
#print Agent124.PrefixK.PalStarts3

-- Select declarations by their actual defining module, including generated names.
run_cmd do
  let env ← getEnv
  let selected : List String := ["LychrelDigitSums", "PrefixInverse", "ActualPrefix",
    "PrefixCertificate", "LongRowsBase", "FastInverse", "FastRowsBase",
    "PalindromeBridge", "ShortBoundary", "Agent124PrefixK", "Agent104620Witness"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut theoremCount := 0
  let mut safeDefinitionCount := 0
  let mut safeOpaqueCount := 0
  let mut otherCount := 0
  let mut axiomUnion : List Name := []
  for mod in selected do
    unless env.allImportedModuleNames.any (fun name => name.toString == mod) do
      throwError m!"MISSING_MODULE {mod}"
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        let mut kind := "other_declaration"
        match info with
          | .axiomInfo _ => throwError m!"CUSTOM_AXIOM {mod} {name}"
          | .thmInfo _ =>
            theoremCount := theoremCount + 1
            kind := "theorem"
          | .defnInfo v =>
            if v.safety == .safe then
              safeDefinitionCount := safeDefinitionCount + 1
              kind := "safe_definition"
            else
              throwError m!"NONSAFE_PROJECT_DEFINITION {mod} {name}"
          | .opaqueInfo v =>
            if v.isUnsafe then
              throwError m!"UNSAFE_PROJECT_OPAQUE {mod} {name}"
            else
              safeOpaqueCount := safeOpaqueCount + 1
              kind := "safe_opaque"
          | _ =>
            otherCount := otherCount + 1
            pure ()
        let axioms ← liftCoreM (Lean.collectAxioms name)
        for ax in axioms do
          unless allowed.contains ax do
            throwError m!"DISALLOWED_AXIOM {mod} {name} {ax}"
          unless axiomUnion.contains ax do
            axiomUnion := ax :: axiomUnion
        let record := Json.mkObj [
          ("kind", toJson kind), ("module", toJson mod.toString),
          ("name", toJson name.toString),
          ("axioms", toJson (axioms.toList.map Name.toString))]
        logInfo m!"REVIEW_DECL {record.compress}"
  unless theoremCount == 1364 do
    throwError m!"THEOREM_CENSUS_MISMATCH expected=1364 actual={theoremCount}"
  let summary := Json.mkObj [
    ("theorems", toJson theoremCount),
    ("safe_definitions", toJson safeDefinitionCount),
    ("safe_opaques", toJson safeOpaqueCount),
    ("other_declarations", toJson otherCount),
    ("axiom_union", toJson (axiomUnion.map Name.toString)),
    ("literal_contracts", toJson (7 : Nat))]
  logInfo m!"REVIEW_SUMMARY {summary.compress}"
