#!/usr/bin/env python3
"""Validate the completed independent build and successful full audit without rerunning Lean."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import traceback

sys.path.insert(0, "/workspace/scratch/6124a6476634/review128")
from review_rebuild import ALLOWED, HEAD, TREE, ROOT, code_only, require, sha

OUTPUT_ROOT = Path("/dev/shm/p196-agent13-session6124-20261016/review128")


def main():
    out = OUTPUT_ROOT / "postprocess-004"
    out.mkdir(exist_ok=False)
    build = ROOT / "build-001"
    audit = OUTPUT_ROOT / "audit-003"
    build_bytes = (build / "verification.json").read_bytes()
    audit_bytes = (audit / "verification.json").read_bytes()
    build_report = json.loads(build_bytes)
    audit_report = json.loads(audit_bytes)
    record = {
        "schema_version": 1, "status": "RUNNING",
        "reviewer": "Agent #13 genuine nonauthor subagent /root/review128",
        "reviewed_head": HEAD, "reviewed_tree": TREE,
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "additional_lean_commands": 0,
        "original_build_receipt_sha256": sha(build_bytes),
        "original_successful_audit_receipt_sha256": sha(audit_bytes),
        "original_receipt_statuses_preserved": {
            "build-001": build_report["status"], "audit-003": audit_report["status"]},
        "postprocessor_sha256": sha(Path(__file__).read_bytes()),
    }
    def save():
        (out / "verification.json").write_text(json.dumps(record, indent=2) + "\n")
    try:
        save()
        require(build_report["reviewed_head"] == audit_report["reviewed_head"] == HEAD, "Source head mismatch")
        require(build_report["reviewed_tree"] == audit_report["reviewed_tree"] == TREE, "Source tree mismatch")
        modules = build_report["source_records"]
        require(len(modules) == 11 and build_report["source_checkout_tracked_clean"], "Source closure or initial checkout mismatch")
        commands = [c for c in build_report["commands"] if c["label"] in modules]
        require(len(commands) == 11 and [c["label"] for c in commands] == build_report["build_order"], "Incomplete build order")
        require(all(c["exit_code"] == 0 for c in commands), "Project module build failed")
        for c in commands:
            require(all(f in c["argv"] for f in ["--trust=0", "-j1", "-DElab.async=false"]), "Build flags changed")
            require(sha((build / c["log"]).read_bytes()) == c["log_sha256"], "Build log changed")
        command = audit_report["command"]
        require(command["exit_code"] == 0, "The complete Lean audit did not pass")
        require(all(f in command["argv"] for f in ["--trust=0", "-j1", "-DElab.async=false"]), "Audit flags changed")
        log = audit / command["log"]
        require(sha(log.read_bytes()) == command["log_sha256"], "Successful raw audit log changed")
        text = log.read_text()
        require("error:" not in text, "Unexpected error in successful audit log")
        declarations = [json.loads(s[len("REVIEW_DECL "):]) for s in text.splitlines() if s.startswith("REVIEW_DECL ")]
        summaries = [json.loads(s[len("REVIEW_SUMMARY "):]) for s in text.splitlines() if s.startswith("REVIEW_SUMMARY ")]
        require(len(summaries) == 1, "Missing or repeated summary")
        summary = summaries[0]
        require(len(declarations) == len({d["name"] for d in declarations}), "Duplicate declaration record")
        require({d["module"] for d in declarations} == set(modules), "Incomplete module origin census")
        count = Counter(d["kind"] for d in declarations)
        fields = {"theorem": "theorems", "safe_definition": "safe_definitions", "safe_opaque": "safe_opaques", "other_declaration": "other_declarations", "unsafe_compiler_definition": "unsafe_compiler_definitions", "unsafe_compiler_axiom": "unsafe_compiler_axioms"}
        for kind, field in fields.items():
            require(count[kind] == summary[field], "Count mismatch: " + kind)
        require(summary["theorems"] == 1364 and summary["safe_definitions"] == 251 and summary["other_declarations"] == 46 and summary["literal_contracts"] == 7, "Incomplete logical audit")
        logical = [d for d in declarations if d["kind"] in {"theorem", "safe_definition", "safe_opaque", "other_declaration"}]
        require(all(d["axiom_audit_performed"] and set(d["axioms"]) <= ALLOWED for d in logical), "Unsupported axiom or unexecuted logical audit")
        require(set(summary["axiom_union"]) == ALLOWED, "Unexpected axiom union")
        unsafe_defs = [d for d in declarations if d["kind"] == "unsafe_compiler_definition"]
        suffix_counts = Counter(d["name"].split(".")[-1] for d in unsafe_defs)
        require(suffix_counts == {"_cstage2": 822, "_cstage1": 153, "_unsafe_rec": 29}, "Unexpected generated unsafe implementation name")
        require(all(not d["axiom_audit_performed"] for d in unsafe_defs), "Incorrect implementation audit label")
        unsafe_axioms = [d for d in declarations if d["kind"] == "unsafe_compiler_axiom"]
        expected_unsafe = {tuple(x) for x in json.loads((ROOT / "evidence/original-unsafe-implementation-axioms.json").read_text())}
        require({(d["module"], d["name"]) for d in unsafe_axioms} == expected_unsafe and len(unsafe_axioms) == 52, "Unsafe compiler specialization census changed")
        require(all(not d["axiom_audit_performed"] for d in unsafe_axioms), "Incorrect specialization audit label")
        registry = json.loads((build / "original.registry.json").read_text())
        endpoints = registry["claims"][0]["endpoints"]
        endpoint_records = [d for d in logical if d["name"] in endpoints]
        require(len(endpoint_records) == len(endpoints) == 7, "Incomplete endpoint audit")
        for d in endpoint_records:
            require(d["kind"] == "theorem" and d["module"] == "Agent104620Witness", "Wrong endpoint module origin")
            expected = set() if d["name"].split(".")[-1] in {"exact_trajectory", "twelve_steps"} else {"propext", "Quot.sound"}
            require(set(d["axioms"]) == expected, "Endpoint axiom mismatch")
        source_links = {}
        for name, item in modules.items():
            data = (build / "source" / (name + ".lean")).read_bytes()
            require(sha(data) == item["sha256"] == item["build_source_sha256"], "Source snapshot changed")
            require(data == (ROOT / "repo" / item["path"]).read_bytes(), "Reviewed original source changed")
            git_blob = subprocess.check_output(["git", "-C", str(ROOT / "repo"), "rev-parse", HEAD + ":" + item["path"]], text=True).strip()
            require(git_blob == item["git_blob"], "Reviewed tree blob changed")
            require(hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == git_blob, "Source Git blob identity mismatch")
            compiled = audit_report["fresh_project_objects"][name]
            require(sha(Path(compiled["path"]).read_bytes()) == compiled["sha256"], "Fresh compiled object changed")
            source_links[name] = {"path": item["path"], "git_blob": git_blob, "sha256": sha(data), "bytes": len(data)}
        require(not subprocess.check_output(["git", "--no-optional-locks", "-C", str(ROOT / "repo"), "status", "--porcelain", "--untracked-files=no"]), "Tracked source is not clean")
        require(subprocess.check_output(["git", "-C", str(ROOT / "repo"), "rev-parse", "HEAD"], text=True).strip() == HEAD, "Review checkout head changed")
        for p, expected in build_report["compiler"]["files"].items():
            require(sha(Path(p).read_bytes()) == expected, "Compiler component changed")
        harness = audit / "ReviewAuditFinal.lean"
        require(sha(harness.read_bytes()) == audit_report["audit_harness_sha256"], "Executed audit source changed")
        integer_path = ROOT / "evidence/integer-replay.json"
        integer = json.loads(integer_path.read_text())
        require(integer["status"] == "PASS_INDEPENDENT_DIVMOD_EXACT_TRAJECTORY_FIRST_HIT_AND_CANONICAL_PREFIX" and integer["reviewed_head"] == HEAD, "Independent integer result mismatch")
        require(integer["palindromic_times_in_closed_interval_0_12"] == [12] and integer["seed"] == "19014942070" and integer["target"] == "62003033030026", "Independent first-hit result mismatch")
        require((build / "verification.json").read_bytes() == build_bytes and (audit / "verification.json").read_bytes() == audit_bytes, "A previous receipt was overwritten")
        record.update({
            "status": "PASS_EXACT_HEAD_INDEPENDENT_SEMANTIC_KERNEL_AND_AXIOM_REVIEW",
            "fresh_full_module_builds": 1, "compiled_project_modules": 11,
            "author_project_objects_reused": False, "mathematical_source_edits": False,
            "all_11_module_compilations_passed": True, "successful_full_lean_audit_exit_code": 0,
            "successful_audit_log_sha256": sha(log.read_bytes()), "audit_summary": summary,
            "logical_declarations_transitively_audited": len(logical),
            "theorems_by_module": dict(Counter(d["module"] for d in logical if d["kind"] == "theorem")),
            "safe_definitions_by_module": dict(Counter(d["module"] for d in logical if d["kind"] == "safe_definition")),
            "endpoint_records": endpoint_records, "source_links": source_links,
            "unsafe_implementation_suffix_counts": dict(suffix_counts),
            "unsafe_specialization_placeholders": 52,
            "unsafe_implementation_scope": "Compiler-generated unsafe implementation declarations are separately inventoried. Every theorem, safe definition and other logical declaration has an executed transitive axiom audit; no nonstandard axiom occurs in these logical closures. All source files contain no explicit unsafe, partial, implemented_by or extern declarations, as checked by the successful audit launch preflight.",
            "postprocessor_correction": "The successful Lean audit was unchanged. This reader recognizes all three observed compiler-generated implementation suffixes (_cstage1, _cstage2, _unsafe_rec); the previous reader allowed only _cstage2. Both original failed readers and original logs remain retained.",
            "integer_replay_sha256": sha(integer_path.read_bytes()),
            "repository_wide_build_claim": False, "combined_current_base_checked_by_this_reviewer": False,
            "external_mutations_by_this_reviewer": [],
        })
        (out / "declarations.json").write_text(json.dumps(declarations, indent=2) + "\n")
        print(json.dumps({k: record[k] for k in ["status", "audit_summary", "theorems_by_module", "safe_definitions_by_module", "logical_declarations_transitively_audited"]}, indent=2))
    except Exception:
        record["status"] = "FAILED"
        (out / "failure.txt").write_text(traceback.format_exc())
        raise
    finally:
        record["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
        save()
        inventory = {str(p.relative_to(out)): {"bytes": p.stat().st_size, "sha256": sha(p.read_bytes())} for p in sorted(out.rglob("*")) if p.is_file() and p.name != "FILES.json"}
        (out / "FILES.json").write_text(json.dumps(inventory, indent=2) + "\n")


if __name__ == "__main__":
    main()
