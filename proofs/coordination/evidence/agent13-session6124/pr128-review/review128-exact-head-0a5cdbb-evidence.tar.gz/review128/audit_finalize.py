#!/usr/bin/env python3
"""Finish the independent audit using the already rebuilt project modules.

The first complete build and its failed review-harness receipt are immutable.
This command changes only the review harness and does not rebuild any project
module. Every imported project object is from that recorded fresh trust0 run.
"""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess
import time
import traceback

from review_rebuild import ALLOWED, HEAD, LEAN_SHA, ROOT, code_only, require, sha


def main():
    build = ROOT / "build-001"
    source = build / "source"
    repo = ROOT / "repo"
    out = ROOT / "audit-002"
    out.mkdir(exist_ok=False)
    lean = Path("/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean")
    build_report_path = build / "verification.json"
    build_report_bytes = build_report_path.read_bytes()
    prior = json.loads(build_report_bytes)
    modules = prior["source_records"]
    frozen_build_manifest = (build / "FILES.json").read_bytes()
    audited_source = (ROOT / "ReviewAuditFixed.lean").read_bytes()
    harness = out / "ReviewAuditFixed.lean"
    harness.write_bytes(audited_source)
    record = {
        "status": "RUNNING", "reviewer": "Agent #13 genuine nonauthor subagent /root/review128",
        "reviewed_head": HEAD, "reviewed_tree": prior["reviewed_tree"],
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "fresh_module_build_receipt": "../build-001/verification.json",
        "fresh_module_build_receipt_sha256": sha(build_report_bytes),
        "initial_runner_status_preserved": prior["status"],
        "initial_failure_scope": "Review-only harness: unknown pp.width option and overbroad rejection of generated unsafe compiler definitions. All eleven project compilations had passed.",
        "additional_project_module_builds": 0, "author_project_object_reuse": False,
        "runner_sha256": sha(Path(__file__).read_bytes()), "audit_harness_sha256": sha(audited_source),
    }

    def save():
        (out / "verification.json").write_text(json.dumps(record, indent=2) + "\n")

    try:
        save()
        require(sha(lean.read_bytes()) == LEAN_SHA, "Compiler binary changed")
        require(len(modules) == 11, "Wrong module closure")
        commands = prior["commands"]
        actual_builds = [c for c in commands if c["label"] in modules]
        require([c["label"] for c in actual_builds] == prior["build_order"], "Incomplete module compilation order")
        require(len(actual_builds) == 11 and all(c["exit_code"] == 0 for c in actual_builds), "Missing passing module build")
        for command in actual_builds:
            require(all(flag in command["argv"] for flag in ["--trust=0", "-j1", "-DElab.async=false"]), "Build flags changed")
            require(sha((build / command["log"]).read_bytes()) == command["log_sha256"], "Original build log changed")
        objects = {}
        for module, item in modules.items():
            data = (source / (module + ".lean")).read_bytes()
            require(sha(data) == item["sha256"] == item["build_source_sha256"], "Source snapshot mismatch")
            require(data == (repo / item["path"]).read_bytes(), "Reviewed source changed")
            require(not re.search(r"\b(?:unsafe|partial|implemented_by|extern)\b", code_only(data.decode())),
                    "Unexpected explicit unsafe or external declaration requires source review")
            obj = source / (module + ".olean")
            objects[module] = {"path": str(obj), "bytes": obj.stat().st_size, "sha256": sha(obj.read_bytes())}
        record["fresh_project_objects"] = objects
        record["explicit_unsafe_or_external_project_declarations"] = []
        argv = [str(lean), "--trust=0", "-j1", "-DElab.async=false", harness.name]
        env = {"PATH": str(lean.parent) + ":/usr/bin:/bin", "LANG": "C.UTF-8", "LEAN_PATH": str(source)}
        record["command"] = {"argv": argv, "cwd": str(out), "environment": env}
        save()
        started = time.monotonic()
        log = out / "ReviewAuditFixed.log"
        with log.open("wb") as stream:
            try:
                rc = subprocess.run(argv, cwd=out, env=env, stdout=stream,
                                    stderr=subprocess.STDOUT, timeout=1800).returncode
            except subprocess.TimeoutExpired:
                rc = 124
        record["command"].update({"exit_code": rc, "elapsed_seconds": time.monotonic() - started,
                                  "log": log.name, "log_sha256": sha(log.read_bytes()), "log_bytes": log.stat().st_size})
        save()
        require(rc == 0, "Corrected review audit failed; see the retained original log")
        text = log.read_text()
        declarations = [json.loads(line[len("REVIEW_DECL "):]) for line in text.splitlines() if line.startswith("REVIEW_DECL ")]
        summaries = [json.loads(line[len("REVIEW_SUMMARY "):]) for line in text.splitlines() if line.startswith("REVIEW_SUMMARY ")]
        require(len(summaries) == 1, "Missing or repeated final audit summary")
        require(len(declarations) == len({x["name"] for x in declarations}), "Duplicated declaration audit")
        require(set(x["module"] for x in declarations) == set(modules), "Missing module in declaration audit")
        summary = summaries[0]
        counts = Counter(x["kind"] for x in declarations)
        expected_counts = {
            "theorem": "theorems", "safe_definition": "safe_definitions", "safe_opaque": "safe_opaques",
            "other_declaration": "other_declarations", "unsafe_compiler_definition": "unsafe_compiler_definitions",
        }
        for kind, field in expected_counts.items():
            require(counts[kind] == summary[field], "Incomplete declaration census: " + kind)
        require(summary["theorems"] == 1364 and summary["literal_contracts"] == 7, "Theorem or endpoint count changed")
        skipped = [x for x in declarations if not x["axiom_audit_performed"]]
        require(all(x["kind"] == "unsafe_compiler_definition" and x["name"].endswith("._cstage2") for x in skipped),
                "Unexpected skipped implementation declaration requires inspection")
        checked = [x for x in declarations if x["axiom_audit_performed"]]
        require(all(set(x["axioms"]) <= ALLOWED for x in checked), "Unsupported transitive axiom")
        require(set(summary["axiom_union"]) == ALLOWED, "Unexpected full axiom union")
        registry = json.loads((build / "original.registry.json").read_text())
        endpoints = registry["claims"][0]["endpoints"]
        endpoint_records = [x for x in declarations if x["name"] in endpoints]
        require(len(endpoint_records) == 7, "Incomplete public endpoint audit")
        for item in endpoint_records:
            require(item["kind"] == "theorem" and item["module"] == "Agent104620Witness", "Wrong endpoint origin")
            expected = set() if item["name"].split(".")[-1] in {"exact_trajectory", "twelve_steps"} else {"propext", "Quot.sound"}
            require(set(item["axioms"]) == expected, "Changed endpoint axiom set")
        for module, obj in objects.items():
            require(sha(Path(obj["path"]).read_bytes()) == obj["sha256"], "Rebuilt project object changed")
            require(sha((source / (module + ".lean")).read_bytes()) == modules[module]["sha256"], "Source snapshot changed")
        require(build_report_path.read_bytes() == build_report_bytes, "Original failed-run receipt was changed")
        require((build / "FILES.json").read_bytes() == frozen_build_manifest, "Original build manifest was changed")
        require(harness.read_bytes() == audited_source and (ROOT / "ReviewAuditFixed.lean").read_bytes() == audited_source, "Audit source changed")
        for path, digest in prior["compiler"]["files"].items():
            require(sha(Path(path).read_bytes()) == digest, "Pinned compiler component changed")
        require(not subprocess.check_output(["git", "-C", str(repo), "status", "--porcelain", "--untracked-files=no"]), "Tracked source changed")
        record["module_build_status"] = "PASS_ALL_11_FRESH_TRUST0_MODULES"
        record["audit_summary"] = summary
        record["module_theorem_counts"] = dict(Counter(x["module"] for x in declarations if x["kind"] == "theorem"))
        record["module_safe_definition_counts"] = dict(Counter(x["module"] for x in declarations if x["kind"] == "safe_definition"))
        record["endpoint_records"] = endpoint_records
        record["skipped_compiler_definitions"] = skipped
        record["generated_unsafe_scope"] = "Only compiler-generated _cstage2 definitions, separately inventoried and excluded from the logical declaration count. Every theorem, safe definition, safe opaque and other logical declaration was transitively axiom-audited. No source contains explicit unsafe, partial, implemented_by or extern declarations."
        (out / "declarations.json").write_text(json.dumps(declarations, indent=2) + "\n")
        record["status"] = "PASS_EXACT_HEAD_INDEPENDENT_SEMANTIC_KERNEL_AND_AXIOM_REVIEW"
        print(json.dumps({"status": record["status"], "audit_summary": summary, "module_theorems": record["module_theorem_counts"]}, indent=2))
    except Exception:
        record["status"] = "FAILED"
        (out / "failure.txt").write_text(traceback.format_exc())
        raise
    finally:
        record["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
        save()
        inventory = {str(p.relative_to(out)): {"bytes": p.stat().st_size, "sha256": sha(p.read_bytes())}
                     for p in sorted(out.rglob("*")) if p.is_file() and p.name != "FILES.json"}
        (out / "FILES.json").write_text(json.dumps(inventory, indent=2) + "\n")


if __name__ == "__main__":
    main()
