#!/usr/bin/env python3
"""Independently rebuild the exact PR #128 source and audit its full closure.

The original sources, verifier, registry, and historical reports are untouched.
This review harness adds trust=0 and audits every project-origin declaration.
It must run once into a new output directory. It never fetches or publishes.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time
import traceback


ROOT = Path(__file__).resolve().parent
HEAD = "0a5cdbb1d265a659d34b3444f3daf41ebd077e43"
TREE = "bdd2176a7691094e7eca9b8f4373284db139229d"
REGISTRY = "proofs/contributions/agent-104/620-depth12-witness-20261016/independent/Agent104620Witness.registry.json"
LEAN_SHA = "92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023"
ALLOWED = {"propext", "Classical.choice", "Quot.sound"}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(condition, message):
    if not condition:
        raise AssertionError(message)


def code_only(text):
    """Mask nested comments and string contents for the supplemental token scan."""
    out, i, depth, string = [], 0, 0, False
    while i < len(text):
        pair = text[i:i + 2]
        if depth:
            if pair == "/-":
                depth += 1
                out.extend("  ")
                i += 2
            elif pair == "-/":
                depth -= 1
                out.extend("  ")
                i += 2
            else:
                out.append("\n" if text[i] == "\n" else " ")
                i += 1
        elif string:
            if text[i] == "\\":
                out.extend("  ")
                i += 2
            else:
                string = text[i] != '"'
                out.append("\n" if text[i] == "\n" else " ")
                i += 1
        elif pair == "/-":
            depth = 1
            out.extend("  ")
            i += 2
        elif pair == "--":
            end = text.find("\n", i)
            end = len(text) if end < 0 else end
            out.extend(" " * (end - i))
            i = end
        elif text[i] == '"':
            string = True
            out.append(" ")
            i += 1
        else:
            out.append(text[i])
            i += 1
    require(not depth and not string, "Unterminated comment or string")
    return "".join(out)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    repo, lean, out = ROOT / "repo", args.lean.resolve(), args.output.resolve()
    require(out.is_relative_to(ROOT), "Output must remain inside the review ownership scope")
    out.mkdir(parents=True, exist_ok=False)
    source, logs = out / "source", out / "logs"
    source.mkdir()
    logs.mkdir()
    record = {
        "schema_version": 1,
        "reviewer": "Agent #13 genuine nonauthor subagent /root/review128",
        "reviewed_head": HEAD,
        "reviewed_tree": TREE,
        "status": "RUNNING",
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "author_project_objects_reused": False,
        "project_build_directory_initially_empty": True,
        "repository_wide_build_claim": False,
        "source_edits": False,
        "commands": [],
        "source_records": {},
        "runner_sha256": sha(Path(__file__).read_bytes()),
        "audit_harness_sha256": sha((ROOT / "ReviewAudit.lean").read_bytes()),
    }

    def save():
        (out / "verification.json").write_text(json.dumps(record, indent=2) + "\n")

    def git(*args):
        return subprocess.check_output(["git", "-C", str(repo), *args])

    def run(label, argv, cwd, env=None, timeout=1800):
        start = time.monotonic()
        path = logs / (label + ".log")
        with path.open("wb") as stream:
            try:
                code = subprocess.run(argv, cwd=cwd, env=env, stdout=stream,
                                      stderr=subprocess.STDOUT, timeout=timeout).returncode
            except subprocess.TimeoutExpired:
                code = 124
        record["commands"].append({
            "label": label, "argv": argv, "cwd": str(cwd), "environment": env,
            "exit_code": code, "elapsed_seconds": round(time.monotonic() - start, 6),
            "log": str(path.relative_to(out)), "log_bytes": path.stat().st_size,
            "log_sha256": sha(path.read_bytes()),
        })
        save()
        print(label + " exit=" + str(code), flush=True)
        require(code == 0, "Command failed: " + label)
        return path.read_text()

    try:
        save()
        require(git("rev-parse", "HEAD").decode().strip() == HEAD, "Wrong checkout HEAD")
        require(git("rev-parse", "HEAD^{tree}").decode().strip() == TREE, "Wrong checkout tree")
        require(not git("status", "--porcelain", "--untracked-files=no"), "Dirty tracked source")
        record["source_checkout_tracked_clean"] = True
        require(sha(lean.read_bytes()) == LEAN_SHA, "Pinned compiler binary hash mismatch")
        version = run("lean-version", [str(lean), "--version"], ROOT, timeout=30).strip()
        require(re.search(r"version 4\.19\.0,.*commit 6caaee842e94, Release", version), "Wrong Lean release")
        runtime = Path(run("lean-prefix", [str(lean), "--print-prefix"], ROOT, timeout=30).strip())
        runtime_files = [lean, *sorted((runtime / "lib/lean").glob("*.so"))]
        record["compiler"] = {"version": version, "files": {str(p): sha(p.read_bytes()) for p in runtime_files}}
        registry_bytes = git("show", HEAD + ":" + REGISTRY)
        require((repo / REGISTRY).read_bytes() == registry_bytes, "Registry differs from the reviewed Git blob")
        (out / "original.registry.json").write_bytes(registry_bytes)
        registry = json.loads(registry_bytes)
        record["registry_sha256"] = sha(registry_bytes)
        modules = registry["projects"]["agent104_620_witness"]["modules"]
        require(len(modules) == 11, "Expected exactly eleven project modules")
        require(set(registry["toolchain"]["allowed_axioms"]) == ALLOWED, "Changed axiom policy")
        originals, imports = {}, {}
        for module, item in modules.items():
            require(not item.get("adapter"), "No adapter is authorized for this closure")
            blob = git("rev-parse", HEAD + ":" + item["path"]).decode().strip()
            data = git("cat-file", "blob", blob)
            require(blob == item["git_blob"] and sha(data) == item["sha256"], "Source identity mismatch: " + module)
            require((repo / item["path"]).read_bytes() == data, "Checkout differs from reviewed source: " + module)
            code = code_only(data.decode())
            forbidden = re.findall(r"(?<![\w'])\b(?:sorry|admit|axiom|sorryAx|native_decide|ofReduceBool|skipKernelTC)\b(?![\w'])", code)
            require(not forbidden, "Forbidden source token: " + module)
            deps = [dep for line in re.findall(r"^\s*import\s+([^\n]+)", code, re.M) for dep in line.split()]
            require(deps == item["imports"], "Import registry mismatch: " + module)
            for dep in deps:
                require(dep in modules or (dep.split(".")[0] in {"Std", "Init", "Lean"}
                        and (runtime / "lib/lean" / (dep.replace(".", "/") + ".olean")).is_file()),
                        "Unregistered dependency: " + dep)
            originals[module], imports[module] = data, deps
            (source / (module + ".lean")).write_bytes(data)
            record["source_records"][module] = {**item, "head_source_git_blob": blob,
                "source_bytes": len(data), "build_source_sha256": sha(data), "forbidden_tokens": []}
        order, active, visited = [], set(), set()

        def visit(module):
            if module not in modules or module in visited:
                return
            require(module not in active, "Import cycle")
            active.add(module)
            for dep in imports[module]:
                visit(dep)
            active.remove(module)
            visited.add(module)
            order.append(module)

        visit("Agent104620Witness")
        require(visited == set(modules), "Registry is not the exact root import closure")
        record["build_order"] = order
        record["module_count"] = len(order)
        env = {"PATH": str(lean.parent) + ":/usr/bin:/bin", "LANG": "C.UTF-8", "LEAN_PATH": str(source)}
        flags = ["--trust=0", "-j1", "-DElab.async=false"]
        record["lean_flags"] = flags
        save()
        for module in order:
            run(module, [str(lean), *flags, "-o", module + ".olean", module + ".lean"], source, env)
        (source / "ReviewAudit.lean").write_bytes((ROOT / "ReviewAudit.lean").read_bytes())
        audit_log = run("ReviewAudit", [str(lean), *flags, "ReviewAudit.lean"], source, env)
        declarations = [json.loads(line.removeprefix("REVIEW_DECL ")) for line in audit_log.splitlines()
                        if line.startswith("REVIEW_DECL ")]
        summaries = [json.loads(line.removeprefix("REVIEW_SUMMARY ")) for line in audit_log.splitlines()
                     if line.startswith("REVIEW_SUMMARY ")]
        require(len(summaries) == 1, "Missing or repeated audit summary")
        require(len({d["name"] for d in declarations}) == len(declarations), "Repeated declaration audit")
        counts = Counter(d["kind"] for d in declarations)
        summary = summaries[0]
        require(counts["theorem"] == summary["theorems"] == 1364, "Incomplete theorem census")
        require(counts["safe_definition"] == summary["safe_definitions"], "Incomplete safe-definition census")
        require(counts["safe_opaque"] == summary["safe_opaques"], "Incomplete safe-opaque census")
        require(counts["other_declaration"] == summary["other_declarations"], "Incomplete other-declaration census")
        require(set(d["module"] for d in declarations) == set(modules), "Missing module in audit census")
        require(all(set(d["axioms"]) <= ALLOWED for d in declarations), "Disallowed transitive axiom")
        endpoints = registry["claims"][0]["endpoints"]
        endpoint_records = [d for d in declarations if d["name"] in endpoints]
        require(len(endpoint_records) == len(endpoints) == 7, "Incomplete public endpoint audit")
        for endpoint in endpoint_records:
            expected = set() if endpoint["name"].split(".")[-1] in {"exact_trajectory", "twelve_steps"} else {"propext", "Quot.sound"}
            require(set(endpoint["axioms"]) == expected, "Endpoint axiom set changed: " + endpoint["name"])
        (out / "declarations.json").write_text(json.dumps(declarations, indent=2) + "\n")
        record["audit_summary"] = summary
        record["module_declaration_counts"] = dict(Counter(d["module"] for d in declarations))
        record["endpoint_records"] = endpoint_records
        for module, data in originals.items():
            require((source / (module + ".lean")).read_bytes() == data, "Build source changed")
            require((repo / modules[module]["path"]).read_bytes() == data, "Original source changed")
        for path, digest in record["compiler"]["files"].items():
            require(sha(Path(path).read_bytes()) == digest, "Compiler changed during verification")
        require(not git("status", "--porcelain", "--untracked-files=no"), "Tracked checkout changed")
        record["status"] = "PASS_EXACT_HEAD_TRUST0_FRESH_CLOSURE_AND_EXHAUSTIVE_AUDIT"
        print(record["status"], flush=True)
    except Exception:
        record["status"] = "FAILED"
        (out / "failure.txt").write_text(traceback.format_exc())
        raise
    finally:
        record["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
        save()
        manifest = {str(p.relative_to(out)): {"bytes": p.stat().st_size, "sha256": sha(p.read_bytes())}
                    for p in sorted(out.rglob("*")) if p.is_file() and p.suffix != ".olean" and p.name != "FILES.json"}
        (out / "FILES.json").write_text(json.dumps(manifest, indent=2) + "\n")


if __name__ == "__main__":
    main()
