from pathlib import Path
import datetime
import hashlib
import json
import tarfile

ROOT = Path('/dev/shm/p196-agent13-session6124-20261016/review128')
PACKAGE = ROOT / 'package'
ARCHIVE = ROOT / 'review128-exact-head-0a5cdbb-evidence.tar.gz'

def sha256(data):
    return hashlib.sha256(data).hexdigest()

def inventory(path):
    data = path.read_bytes()
    return {
        'path': path.relative_to(PACKAGE).as_posix(),
        'archive_path': 'review128/' + path.relative_to(PACKAGE).as_posix(),
        'bytes': len(data),
        'sha256': sha256(data),
    }

assert PACKAGE.is_dir()
assert not ARCHIVE.exists(), 'Do not overwrite an existing archive.'
files = sorted(p for p in PACKAGE.rglob('*') if p.is_file())
assert all(not p.is_symlink() for p in files)
assert not (PACKAGE / 'MANIFEST.json').exists()
records = [inventory(p) for p in files]
manifest = {
    'schema_version': 1,
    'reviewed_head': '0a5cdbb1d265a659d34b3444f3daf41ebd077e43',
    'reviewed_tree': 'bdd2176a7691094e7eca9b8f4373284db139229d',
    'storage_root': str(PACKAGE),
    'archive_root': 'review128',
    'hash_algorithm': 'SHA-256',
    'scope': 'All retained files except this manifest itself; its identity is pinned by the outer archive receipt.',
    'file_count': len(records),
    'original_bytes': sum(r['bytes'] for r in records),
    'files': records,
}
manifest_path = PACKAGE / 'MANIFEST.json'
manifest_path.write_text(json.dumps(manifest, indent=2) + '\n')
all_records = records + [inventory(manifest_path)]
with tarfile.open(ARCHIVE, 'w:gz', compresslevel=9, format=tarfile.PAX_FORMAT) as tf:
    for record in sorted(all_records, key=lambda r: r['path']):
        tf.add(PACKAGE / record['path'], arcname=record['archive_path'], recursive=False)
expected = {r['archive_path']: r for r in all_records}
verified = []
with tarfile.open(ARCHIVE, 'r:gz') as tf:
    members = tf.getmembers()
    assert len(members) == len(expected)
    assert len({m.name for m in members}) == len(members)
    for member in members:
        assert member.isfile() and member.name in expected
        assert not member.name.startswith('/') and '..' not in Path(member.name).parts
        data = tf.extractfile(member).read()
        record = expected[member.name]
        assert len(data) == record['bytes'] and sha256(data) == record['sha256']
        assert data == (PACKAGE / record['path']).read_bytes()
        verified.append(member.name)
archive_bytes = ARCHIVE.read_bytes()
critical = ['SEMANTIC_REVIEW.md', 'FORMAL_COMMENT_DRAFT.md', 'REVIEW_RECEIPT.json',
            'postprocess-004/verification.json', 'audit-003/ReviewAuditFinal.log', 'MANIFEST.json']
receipt = {
    'schema_version': 1,
    'status': 'PASS_LOSSLESS_ARCHIVE_EVERY_MEMBER_BYTE_VERIFIED',
    'reviewed_head': manifest['reviewed_head'],
    'reviewed_tree': manifest['reviewed_tree'],
    'archive': {
        'path': str(ARCHIVE),
        'filename': ARCHIVE.name,
        'format': 'POSIX pax tar with lossless gzip compression',
        'bytes': len(archive_bytes),
        'sha256': sha256(archive_bytes),
    },
    'members': len(verified),
    'uncompressed_original_file_bytes': sum(r['bytes'] for r in all_records),
    'manifest': inventory(manifest_path),
    'all_members_byte_identical_to_packaged_originals': True,
    'symlinks_or_unsafe_member_paths': False,
    'excluded_infrastructure_inventory': 'review128/EXCLUDED_INFRASTRUCTURE.json',
    'critical_files': [inventory(PACKAGE / name) for name in critical],
    'recover_into_new_directory': 'mkdir recovered-pr128-review && tar -xzf ' + ARCHIVE.name + ' -C recovered-pr128-review',
    'review_verdict': 'PASS_EXACT_HEAD_INDEPENDENT_SEMANTIC_KERNEL_AND_AXIOM_REVIEW',
    'external_mutations_by_this_reviewer': [],
    'generated_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
receipt_path = ROOT / 'ARCHIVE_RECEIPT.json'
assert not receipt_path.exists()
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'archive': receipt['archive'], 'members': receipt['members'],
                  'original_bytes': receipt['uncompressed_original_file_bytes'],
                  'manifest': receipt['manifest'], 'receipt_path': str(receipt_path),
                  'receipt_sha256': sha256(receipt_path.read_bytes()),
                  'critical_files': receipt['critical_files']}, indent=2))
