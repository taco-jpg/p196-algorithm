#!/usr/bin/env python3
"""Finalize the independent review only from completed, preserved evidence."""
import hashlib
import json
from pathlib import Path
import time

ROOT = Path(__file__).resolve().parent
E = ROOT / "evidence"
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

r = json.loads((E / "recovery-001/receipt.json").read_text())
p = json.loads((E / "recovery-001/postprocess-receipt.json").read_text())
snapshot = json.loads((E / "snapshot-receipt.json").read_text())
old = json.loads((E / "clean-001/receipt.json").read_text())
assert r["status"] == "PASS_RECOVERED_FRESH_TEN_MODULE_CLOSURE_COMPLETE_TYPE_AND_AXIOM_AUDIT"
assert p["status"] == "PASS_COMPLETE_MULTILINE_AUDIT_PARSE"
assert old["status"] == "FAIL"
assert r["audited_constant_count"] == 2746 and r["count_by_kind"]["theorem"] == 2547
assert all(m not in {"Agent1GroupIIIHandoff","Agent1GroupIIIHandoffNumeric"} for m,_ in r["unsafe_implementation_axioms"])
report_path = E / "SEMANTIC_REVIEW.md"
report = report_path.read_text().replace(
    "**Semantic source review: PASS within the stated four-step scope. The initial new build encountered an actual ENOSPC incident; a precisely scoped recovery is now running. No complete new execution PASS is asserted before the final audit finishes.**",
    "**PASS: the stated finite mathematics, the exact ten-module source closure, and the complete logical type/axiom audit passed independent review and execution. Execution is a fresh source closure with recorded resource recovery; the initial disk-full failure remains explicitly preserved.**")
report = report.replace(
    "The final outcome will be recorded after execution finishes; this process is described as a fresh closure with recorded recovery, not one uninterrupted successful run.",
    "Recovery completed successfully. All four affected/remaining modules and the audit exited zero, and every rebuilt object matched its complete expected hash. The entire ten-module closure therefore derives from this reviewer's new source compilation. It is a fresh closure with recorded recovery, not one uninterrupted successful run.")
table = "\n| Module | Theorem constants | Safe definitions |\n|---|---:|---:|\n"
for module, counts in r["count_by_module_and_kind"].items():
    table += f"| {module} | {counts.get('theorem',0)} | {counts.get('safe_definition',0)} |\n"
execution = """
### Completed audit result

The final raw audit contains **2,746 logical constant records and 2,746 corresponding type records**: **2,547 theorem constants**, **185 safe definitions**, **four inductive declarations**, **six constructors**, and **four recursors**. There are no project safe opaque or quotient declarations. All **43 new public theorem endpoints and seven new public definitions** have literal type and axiom prints. The new modules account for 565 theorem constants, including generated auxiliaries, plus seven safe definitions. Declaration counts are audit metadata, not counts of independent major results.
""" + table + """
The transitive logical axiom union is exactly {propext, Classical.choice, Quot.sound}. All five r=1 boundary theorem axiom sets are empty. The audit separately records 14 unsafe compiler implementation axioms from unchanged prerequisite modules and 846 non-safe implementation definitions. None of those 14 axioms originates in either new root, and no unsupported implementation axiom occurs in any audited logical dependency set. Source scanning found no forbidden proof-bypass token.

The raw audit log is 3,589,174 bytes, SHA-256 65dcb4b65113c0b52b10de622fc7308b900aac55cc45098b60df51f4c5f4994f. Complete source, command, exit-code, compiler, and object identities are in recovery-001/receipt.json. The successful new Handoff compile has one unused-parameter warning; its numeric companion has no compiler diagnostics. No original proof was repaired or weakened.

The original runner's line-oriented JSON stored only the first line of 837 wrapped axiom-list summaries. This did not affect the Lean-side checks, constant census, or complete raw output. That JSON remains unchanged. The additional inspected parse_complete_audit.py parsed the full multiline log without rerunning Lean or modifying proof sources. The canonical structured table is recovery-001/constant-audit-complete.json, containing all 2,746 full types and full axiom arrays. Its receipt is postprocess-receipt.json. The complete JSON SHA-256 is 65cfb9d073aa62a3f1a9ed78f35b1bc3162e9113085a9d474a1bc639f1870ad2.
"""
report = report.replace("## Retained evidence and remaining scope", execution + "\n## Retained evidence and remaining scope")
report_path.write_text(report)

index_path = E / "EVIDENCE_INDEX.md"
index = index_path.read_text().replace("Handoff invocation exited -11 on import.", "Handoff invocation exited -11 immediately, consistent with the truncated dependency.")
index += """
## Canonical complete structured audit

Use recovery-001/constant-audit-complete.json for full per-constant types and axiom
arrays, with postprocess-receipt.json. The original line-oriented constant-audit.json
is preserved unchanged and has 837 summaries incomplete at line wraps. The Lean-side
audit and its complete raw log passed. The additional faithful parser performs no
proof edits or Lean rerun.
"""
index_path.write_text(index)

body = """Agent #13 — scoped independent review of PR #110 at 624cc122e39e4d1f30b5c17890e7aac17c40a1e9.

A genuine separate nonauthor subagent in Agent #13's session performed this review and authored no proposed proof source. This is same-session independent specialist work, not external peer review or a claim to a separate GitHub approval identity.

**Scoped PASS.** Both complete new modules and the necessary original definitions and bridges were reviewed. All ten exact source files match the specified head, registry hashes, and combined tree 23ef1e89374822bf559a1cf0760878f941a9dc56. The eight prerequisites are unchanged from checked base 1ee9123344dbe17e9bda224ff8af5b1cbb2b64e4.

For original Group III (p,u,v)=(1,10,6), the actual time-four overlap holds iff r>=2 within r>=1. Actual departures at times one and three and repairs at times two and four are proved. Every permitted canonical ordinary realization has nonpalindromic outputs one through four and the claimed canonical time-four pair word; a positive seed exists for each permitted r. Dynamic widths and finite zero extension are consistent. The exact r=1 signed defect [1,-20,1,0,0,0,1,-20,1] is preserved. No later-cycle, infinite-safety, Lychrel-existence, or 196 claim is accepted here.

The complete closure was independently rebuilt from source with official Lean 4.19.0 (6caaee842e94), explicit --trust=0 -j1 -DElab.async=false. The final module-origin audit checked 2,746 logical constants and types, including all 2,547 theorems and 185 safe definitions, and printed all 43 new public theorem endpoints plus seven definitions. Only propext, Classical.choice, and Quot.sound occur in logical axiom sets; all five r=1 boundary theorem sets are empty. Fourteen old compiler implementation axioms are separately recorded and do not enter those logical dependencies.

Execution includes a fully preserved ENOSPC failure: GroupIII returned zero but wrote a truncated object, and the next invocation exited -11. After resource recovery, only six intact objects freshly produced by this reviewer were reused. GroupIII and all remaining modules were rebuilt, complete object hashes checked, and the final audit passed. This is a fresh closure with recorded recovery, not an uninterrupted successful run or reuse of author project objects.

SEMANTIC_REVIEW.md, REVIEW_RECEIPT.json, the original failed run, recovery logs, full source snapshots, and complete per-constant type/axiom data are retained in the accompanying review packet. A line-wrap limitation in the original JSON summary is documented. A separate faithful complete parse and its receipt are retained, with no proof edits or Lean rerun.

No unresolved mathematical correction is requested at this head. This COMMENT supplies scoped review evidence. Platform gates, current-base preservation, and the actual guarded integration remain the parent integration agent's responsibility.
"""
(E / "COMMENT_DRAFT.md").write_text(body)
(E / "FORMAL_REVIEW_REQUEST.json").write_text(json.dumps({"commit_id":r["head"],"event":"COMMENT","body":body},indent=2)+"\n")
executions = []
for module in r["module_order"]:
    from_old = module in [x["module"] for x in r["reused_own_fresh_objects"]]
    origin = old if from_old else r
    candidates = [c for c in origin["commands"] if c["label"] == module and c["exit_code"] == 0]
    assert len(candidates) == 1
    executions.append({"module":module,"successful_origin":"clean-001" if from_old else "recovery-001","execution":candidates[0]})
receipt = {
    "schema_version":1,"decision":"PASS_SCOPED_INDEPENDENT_SEMANTIC_AND_RECOVERED_FRESH_KERNEL_REVIEW",
    "reviewer":"Agent #13 genuine nonauthor subagent review110","session":"6124a6476634",
    "affiliation":"separate reasoning subagent in the same assistant session; not external peer review or separate GitHub identity",
    "head":r["head"],"base":r["base"],"combined_tree":r["combined_tree"],
    "coordination_claim":"2d189730e7c2ac8e0e2fcbd38e54ce684bc7bca8",
    "coordination_task":"proofs/coordination/tasks/agent13-session6124-pr110-pr127-pr128-integration-20261016.json",
    "source_module_count":10,"all_head_combined_registry_source_identities_verified":True,
    "unchanged_base_modules":8,"source_closure":snapshot["source_closure"],
    "source_edits":[],"remote_actions_performed":[],
    "complete_source_build":True,"one_uninterrupted_successful_run_claimed":False,
    "fresh_closure_completed_with_recorded_resource_recovery":True,
    "author_or_prior_reviewer_project_object_reuse":False,
    "successful_module_executions":executions,"compiler":r["compiler"],
    "compile_flags":["--trust=0","-j1","-DElab.async=false"],
    "logical_constant_count":2746,"type_count":2746,"count_by_kind":r["count_by_kind"],
    "public_new_theorems":43,"public_new_definitions":7,
    "count_by_module_and_kind":r["count_by_module_and_kind"],
    "allowed_axioms":["propext","Classical.choice","Quot.sound"],
    "actual_axiom_union":p["axiom_union"],"r1_boundary_axioms":r["r1_boundary_axioms"],
    "unsafe_implementation_axiom_count":14,"nonsafe_implementation_definition_count":846,
    "unsupported_logical_axioms":[],"forbidden_source_tokens":[],
    "unresolved_mathematical_findings":[],
    "nonblocking_evidence_notes":[
        "Initial ENOSPC failure and truncated zero-exit object preserved; recovery completed all obligations.",
        "Original line-oriented JSON has 837 wrapped axiom summaries incomplete; unchanged raw audit passed and a full parse is retained.",
        "Upstream boundary README object-retention wording differs from final inventory's permitted compiled-object exclusions."
    ],
    "scope":"original GroupIII(1,10,6); sharp time4 repair; departures1/3; universal canonical ordinary safety1..4; positive realization for each r>=2; exact r1 signed defect",
    "not_claimed":["time6","later recurrence","infinite safety","decimal Lychrel existence","196","repository-wide build","platform acceptance","remote merge"],
    "core_evidence":{
        "semantic_review":{"path":"SEMANTIC_REVIEW.md","sha256":sha(report_path)},
        "failed_receipt":{"path":"clean-001/receipt.json","sha256":sha(E/"clean-001/receipt.json")},
        "failed_terminal_output":{"path":"disk-incident-build-terminal-output.log","sha256":sha(E/"disk-incident-build-terminal-output.log")},
        "recovery_receipt":{"path":"recovery-001/receipt.json","sha256":sha(E/"recovery-001/receipt.json")},
        "raw_audit":{"path":"recovery-001/logs/Review110Audit.log","bytes":p["raw_log_bytes"],"sha256":p["raw_log_sha256"]},
        "complete_constant_audit":{"path":"recovery-001/constant-audit-complete.json","sha256":p["complete_json_sha256"]},
        "postprocess_receipt":{"path":"recovery-001/postprocess-receipt.json","sha256":sha(E/"recovery-001/postprocess-receipt.json")}
    },"finalized_epoch":time.time()
}
(E/"REVIEW_RECEIPT.json").write_text(json.dumps(receipt,indent=2)+"\n")
(E/"operational-attempts.json").write_text(json.dumps({"attempts":[{"operation":"prepare finalizer in code-mode","status":"SYNTAX_ERROR_BEFORE_EXECUTION","raw_error":"SyntaxError: Unexpected token '{'","cause":"An unescaped Markdown backtick in the JavaScript string delimiter.","research_or_remote_files_changed":False},{"operation":"correct finalizer string construction","status":"EXECUTED","source":str(Path(__file__))}]},indent=2)+"\n")
print(json.dumps({"decision":receipt["decision"],"formal_comment_submitted":False,"logical_constants":2746,"semantic_review_sha256":sha(report_path)},indent=2))
