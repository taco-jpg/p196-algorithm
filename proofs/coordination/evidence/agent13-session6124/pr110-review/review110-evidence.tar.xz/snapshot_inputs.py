#!/usr/bin/env python3
"""Retain exact PR #110 inputs for an independent Agent #13 review."""
import hashlib
import json
import pathlib
import subprocess

ROOT = pathlib.Path(__file__).resolve().parent
EVIDENCE = ROOT / "evidence"
HEAD = "624cc122e39e4d1f30b5c17890e7aac17c40a1e9"
BASE = "1ee9123344dbe17e9bda224ff8af5b1cbb2b64e4"
TREE = "23ef1e89374822bf559a1cf0760878f941a9dc56"
PACKAGE = "proofs/contributions/agent-1/groupIII-handoff-20261016"
REGISTRY = "proofs/Agent1GroupIIIHandoff.registry.json"

def git(*args):
    return subprocess.run(["git", "-C", str(ROOT), *args], capture_output=True, check=True).stdout

def retain(path, data):
    target = EVIDENCE / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)

def sha256(data):
    return hashlib.sha256(data).hexdigest()

EVIDENCE.mkdir(exist_ok=True)
registry_bytes = git("show", f"{HEAD}:{REGISTRY}")
registry = json.loads(registry_bytes)
retain("input/" + REGISTRY, registry_bytes)
for policy in ["AGENTS.md", "proofs/PUBLICATION_POLICY.md"]:
    retain("accepted-base/" + policy, git("show", f"{BASE}:{policy}"))
role_path = pathlib.Path("/workspace/scratch/6124a6476634/upload/Pasted text(20261016-224241).txt")
retain("role.txt", role_path.read_bytes())

rows = []
for module, declaration in registry["projects"]["agent1-groupIII-handoff"]["modules"].items():
    path = declaration["path"]
    data = git("show", f"{TREE}:{path}")
    from_head = git("show", f"{HEAD}:{path}")
    blob = git("rev-parse", f"{TREE}:{path}").decode().strip()
    base_result = subprocess.run(["git", "-C", str(ROOT), "show", f"{BASE}:{path}"], capture_output=True)
    assert data == from_head, path
    assert sha256(data) == declaration["sha256"], path
    assert blob == declaration["git_blob"], path
    retain("source/" + module + ".lean", data)
    retain("input/" + path, data)
    rows.append({"module": module, "path": path, "bytes": len(data), "sha256": sha256(data),
                 "git_blob": blob, "imports_declared": declaration["imports"], "head_equals_combined": True,
                 "base_present": base_result.returncode == 0,
                 "base_equals_combined": data == base_result.stdout if base_result.returncode == 0 else None})

failures = []
retained = []
for path in git("ls-tree", "-r", "--name-only", HEAD, PACKAGE).decode().splitlines():
    result = subprocess.run(["git", "-C", str(ROOT), "show", f"{HEAD}:{path}"], capture_output=True)
    if result.returncode:
        failures.append({"path": path, "returncode": result.returncode, "stderr": result.stderr.decode()})
        continue
    retain("input/" + path, result.stdout)
    retained.append({"path": path, "bytes": len(result.stdout), "sha256": sha256(result.stdout)})

receipt = {"head": HEAD, "base": BASE, "combined_tree": TREE, "registry": REGISTRY,
           "registry_sha256": sha256(registry_bytes), "source_closure": rows,
           "package_files_retained": retained, "retention_failures": failures,
           "author_build_objects_reused": False}
retain("snapshot-receipt.json", (json.dumps(receipt, indent=2) + "\n").encode())
print(json.dumps({"source_modules": len(rows), "retained_package_files": len(retained), "failures": failures}, indent=2))
