# PR #110 independent evidence index

This package records Agent #13's genuine nonauthor subagent review110 for head
`624cc122e39e4d1f30b5c17890e7aac17c40a1e9`, checked base
`1ee9123344dbe17e9bda224ff8af5b1cbb2b64e4`, and combined tree
`23ef1e89374822bf559a1cf0760878f941a9dc56`.

## Current decision and machine records

The delivered `SEMANTIC_REVIEW.md` and `REVIEW_RECEIPT.json` are the final review
conclusion. `FORMAL_REVIEW_REQUEST.json` is an exact-head COMMENT draft for the
parent integration agent; no remote review or other external mutation was
performed by this subagent.

- `snapshot-receipt.json` pins all ten source modules to the head, combined tree,
  registry hashes, Git blob identities, and eight byte-identical base modules.
- `source/` contains the complete exact ten-module source closure.
- `input/` contains exact published roots, registry, and all 99 files of the
  retained author/prior-review/parent evidence package.
- `accepted-base/` contains the accepted AGENTS.md and PUBLICATION_POLICY.md.
- `reference/` contains the inspected original verifier and exact written-source
  blob. The original verifier was not altered or executed by this reviewer.
- `SEMANTIC_REVIEW_SOURCE_DRAFT.md` is the preserved source-review draft, which
  did not claim the later execution result.

## Failed run and resource recovery

`clean-001/receipt.json` is permanently FAIL. Its source and full per-command logs
are retained. The original clean directory had no project objects. Its first six
module builds succeeded and produced complete objects; GroupIII returned zero
but wrote a truncated object during a real disk-full incident. The following
Handoff invocation exited -11 immediately, consistent with the truncated dependency. This is not a complete successful build.

`disk-incident-build-terminal-output.log` preserves the exact returned terminal
traceback. `disk-incident-object-removal.json` records the size and hash of the
single unusable reproducible object removed. `disk-incident-followup.json`
records readback and identifies the canonical complete traceback. The original
attempts to write `failure.txt`, `FILES.json`, and `disk-incident-tool-output.log`
were affected by ENOSPC; any empty files are retained as empty failure artifacts,
not treated as valid reports or substitutes for the complete terminal output.

`recovery-001/` is a separate recovery record. Only the six complete objects
freshly built by this reviewer in clean-001 are copied into that isolated build.
Their hashes and successful originating commands are checked and recorded. The
four remaining/affected modules are rebuilt, and the complete module-origin type
and axiom audit covers all ten modules. No author-generated project object is
used. Each new object is checked against retained identity metadata to guard
against a zero compiler exit with a truncated output file.

`recovery-001/source/Review110Audit.lean` contains the exact audit harness.
`recovery-001/logs/Review110Audit.log` is its full raw output, including all
selected logical constant types and transitive axiom sets, as well as the public
endpoint type and literal axiom prints. `constant-audit.json` gives the parsed
per-constant census, and `receipt.json` records successful completion or an
honest failure. Neither a filename nor a partial log is evidence of PASS.

## Scope of the verification

The source family is original Group III `(p,u,v)=(1,10,6)`. The review concerns
actual departures at times 1 and 3, restoration at times 2 and 4 for `r>=2`, the
sharp time-four iff for `r>=1`, the exact r=1 signed defect, canonical ordinary
safety at every positive time 1 through 4, and a positive realization for every
permitted spacer. No later-cycle, infinite-safety, decimal Lychrel-existence,
196, or repository-wide verification conclusion is made.

The audit uses the official Lean 4.19.0 compiler, commit `6caaee842e94`, executable
SHA-256 `92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023`.
Every project compilation and the audit use `--trust=0 -j1 -DElab.async=false`.
Only `propext`, `Classical.choice`, and `Quot.sound` are permitted in logical
axiom dependencies. Compiler-generated unsafe implementation declarations are
listed separately; they are not admitted as extra logical axioms.

## Reproduction and exclusions

The retained runner `run_clean_review.py` can perform a new complete replay from
the retained exact `evidence/source/` inputs and the retained registry. It uses
the pinned compiler at `/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean` and a new
previously nonexistent run label, for example:

```sh
python3 -B run_clean_review.py replay-001
```

The actual first run used label `clean-001`. The separate
`resume_clean_review.py` records the resource-recovery operation and the original
six object locations; it is retained as the exact executed recovery driver, not
as a claim that other machines already have those local objects. A portable
fresh replay needs only the retained source package and the pinned official
Lean distribution, placed at the recorded compiler path.

The final lossless packet retains source, scripts, registry, accepted policy,
written analysis, failed and successful compiler/audit logs, commands, hashes,
and machine receipts. Reproducible `.olean` objects, the runtime installation,
and local Git object caches are excluded from publication. These exclusions are
permitted infrastructure exclusions under the accepted publication policy;
they do not discard substantive research or failure logs. The manifest records
any locally present excluded object identities and the reason.

## Canonical complete structured audit

Use recovery-001/constant-audit-complete.json for full per-constant types and axiom
arrays, with postprocess-receipt.json. The original line-oriented constant-audit.json
is preserved unchanged and has 837 summaries incomplete at line wraps. The Lean-side
audit and its complete raw log passed. The additional faithful parser performs no
proof edits or Lean rerun.
