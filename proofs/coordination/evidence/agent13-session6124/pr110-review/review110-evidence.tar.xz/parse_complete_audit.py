#!/usr/bin/env python3
"""Retain complete multiline types and axiom sets from the successful raw audit.

The original runner's line-oriented JSON is preserved unchanged. Its Lean-side
axiom checks and complete raw log succeeded; only wrapped JSON summary values
need this additional faithful parser. This script executes no Lean or proof code.
"""
import collections
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "evidence/recovery-001"
raw = (OUT / "logs/Review110Audit.log").read_bytes()
log = raw.decode()
receipt = json.loads((OUT / "receipt.json").read_text())
assert receipt["status"] == "PASS_RECOVERED_FRESH_TEN_MODULE_CLOSURE_COMPLETE_TYPE_AND_AXIOM_AUDIT"
allowed = {"propext", "Classical.choice", "Quot.sound"}
rows = []
for match in re.finditer(r"^AUDIT_CONSTANT (\S+) (\S+) (\S+) : \[([^\]]*)\]\nAUDIT_TYPE ", log, re.M):
    kind, module, name, body = match.groups()
    axioms = [part.strip() for part in body.split(",") if part.strip()]
    assert set(axioms) <= allowed
    rows.append({"kind":kind, "module":module, "name":name, "axioms":axioms})
type_rows = {}
pattern = r"^AUDIT_TYPE (\S+) (\S+) : (.*?)(?=^(?:AUDIT_CONSTANT|UNSAFE_IMPLEMENTATION_AXIOM|NONSAFE_DEFINITION|UNSAFE_OPAQUE|COMPLETE_MODULE_AUDIT)\b|\Z)"
for match in re.finditer(pattern, log, re.M | re.S):
    module, name, body = match.groups()
    assert (module,name) not in type_rows
    type_rows[(module,name)] = body.rstrip()
assert len(rows) == 2746 and len(type_rows) == 2746
assert {(r["module"],r["name"]) for r in rows} == set(type_rows)
assert len({r["name"] for r in rows}) == len(rows)
for row in rows:
    row["type"] = type_rows[(row["module"],row["name"])]
    assert row["type"]
count_by_kind = dict(collections.Counter(r["kind"] for r in rows))
assert count_by_kind == receipt["count_by_kind"]
assert len([r for r in rows if r["kind"] == "theorem"]) == 2547
assert len([r for r in rows if r["kind"] == "safe_definition"]) == 185
public = set(receipt["public_new_theorem_endpoints"] + receipt["public_new_definitions"])
assert public <= {r["name"] for r in rows} and len(public) == 50
for row in rows:
    if row["name"] in receipt["r1_boundary_axioms"]:
        assert row["axioms"] == []
target = OUT / "constant-audit-complete.json"
target.write_text(json.dumps(rows, indent=2) + "\n")
original = (OUT / "constant-audit.json").read_bytes()
parsed_original = json.loads(original)
summary = {"status":"PASS_COMPLETE_MULTILINE_AUDIT_PARSE",
           "scope":"faithful parsing only; no proof source edits or Lean rerun",
           "raw_log_sha256":hashlib.sha256(raw).hexdigest(),
           "raw_log_bytes":len(raw),
           "original_runner_json_sha256":hashlib.sha256(original).hexdigest(),
           "original_runner_json_preserved":True,
           "original_line_oriented_summary_values_incomplete":sum(not r["axioms"].endswith("]") for r in parsed_original),
           "complete_json_sha256":hashlib.sha256(target.read_bytes()).hexdigest(),
           "complete_json_bytes":target.stat().st_size,
           "logical_constant_count":len(rows), "type_count":len(type_rows),
           "count_by_kind":count_by_kind, "public_endpoints":50,
           "axiom_union":sorted({a for r in rows for a in r["axioms"]}),
           "parser_sha256":hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
(OUT / "postprocess-receipt.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps(summary, indent=2))
