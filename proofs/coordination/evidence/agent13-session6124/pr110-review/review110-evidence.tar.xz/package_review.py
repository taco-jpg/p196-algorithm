#!/usr/bin/env python3
"""Package this independent review without changing any proof source."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parent
E = ROOT / "evidence"
HEAD = "624cc122e39e4d1f30b5c17890e7aac17c40a1e9"
BASE = "1ee9123344dbe17e9bda224ff8af5b1cbb2b64e4"
TREE = "23ef1e89374822bf559a1cf0760878f941a9dc56"
ARCHIVE = ROOT / "review110-evidence.tar.gz"
MANIFEST = ROOT / "EVIDENCE_MANIFEST.json"
PACKET_RECEIPT = ROOT / "PACKET_RECEIPT.json"

def digest(data):
    return hashlib.sha256(data).hexdigest()

def read_json(path):
    return json.loads(path.read_text())

def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n")

def verify(path, expected):
    data = path.read_bytes()
    assert digest(data) == expected["sha256"], str(path)
    if "bytes" in expected:
        assert len(data) == expected["bytes"], str(path)
    return data

assert ROOT == Path("/dev/shm/p196-agent13-session6124-20261016/review110")
assert not ARCHIVE.exists()
assert not MANIFEST.exists()
assert not PACKET_RECEIPT.exists()
receipt = read_json(E / "REVIEW_RECEIPT.json")
snapshot = read_json(E / "snapshot-receipt.json")
assert receipt["decision"] == "PASS_SCOPED_INDEPENDENT_SEMANTIC_AND_RECOVERED_FRESH_KERNEL_REVIEW"
for obj in [receipt, snapshot]:
    assert obj["head"] == HEAD
    assert obj["base"] == BASE
    assert obj["combined_tree"] == TREE
assert len(snapshot["package_files_retained"]) == 99
assert len(snapshot["source_closure"]) == 10
assert not snapshot["retention_failures"]
for row in snapshot["package_files_retained"]:
    verify(E / "input" / row["path"], row)
for row in snapshot["source_closure"]:
    for directory in [E / "source", E / "recovery-001" / "source"]:
        verify(directory / (row["module"] + ".lean"), row)
for row in receipt["core_evidence"].values():
    verify(E / row["path"], row)
for row in receipt["successful_module_executions"]:
    execution = row["execution"]
    assert execution["exit_code"] == 0
    verify(E / row["successful_origin"] / execution["log"], {
        "bytes": execution["log_bytes"], "sha256": execution["log_sha256"]})
draft = (E / "COMMENT_DRAFT.md").read_text()
request = read_json(E / "FORMAL_REVIEW_REQUEST.json")
assert request == {"commit_id": HEAD, "event": "COMMENT", "body": draft}
review_text = (E / "SEMANTIC_REVIEW.md").read_text()
for stale in [
    "a precisely scoped recovery is now running",
    "No complete new execution PASS is asserted",
    "Final execution results will replace this sentence",
    "The final outcome will be recorded after execution finishes",
]:
    assert stale not in review_text, stale

attempts = read_json(E / "operational-attempts.json")
attempts["attempts"].append({
    "operation": "prepare packet writer in code-mode",
    "status": "SYNTAX_ERROR_BEFORE_EXECUTION",
    "raw_error": "SyntaxError: Unexpected identifier 'RUST_BACKTRACE'",
    "cause": "An unescaped backtick in a raw terminal-output string closed the JavaScript string delimiter.",
    "research_or_remote_files_changed": False,
})
attempts["attempts"].append({
    "operation": "correct packet writer string construction",
    "status": "EXECUTED",
    "source": str(Path(__file__).resolve()),
})
write_json(E / "operational-attempts.json", attempts)

other_raw = (
    "Tool result from the failed ordinary exec (chunk 1a392a):\n\n"
    "thread 'main' (195655) panicked at linux-sandbox/src/linux_run_main.rs:970:21:\n"
    "failed to create synthetic bubblewrap mount marker directory /tmp/codex-bwrap-synthetic-mount-targets-0/9dddf21f25fb79fe: No space left on device (os error 28)\n"
    "note: run with " + chr(96) + "RUST_BACKTRACE=1" + chr(96) +
    " environment variable to display a backtrace\n\n"
    "Tool result from the read-only filesystem diagnosis (chunk 1e274c):\n\n"
    "Filesystem      Size  Used Avail Use% Mounted on\n"
    "overlay          32G   32G     0 100% /\n"
    "overlay          32G   32G     0 100% /\n\n"
    "Tool result from the failed attempt to preserve the tool transcript:\n\n"
    "Script error:\n"
    "Exit code: 1\n"
    "Wall time: 2 seconds\n"
    "Output:\n"
    "Failed to write file /workspace/scratch/6124a6476634/review110/evidence/disk-incident-tool-output.log\n"
)
extra_log = E / "disk-incident-other-raw-output.log"
assert not extra_log.exists()
extra_log.write_text(other_raw)

files = []
excluded = []
excluded_names = {ARCHIVE.name, MANIFEST.name, PACKET_RECEIPT.name}
for path in sorted(ROOT.rglob("*")):
    assert not path.is_symlink(), str(path)
    if not path.is_file():
        continue
    rel = path.relative_to(ROOT).as_posix()
    if rel in excluded_names:
        continue
    data = path.read_bytes()
    row = {"path": rel, "bytes": len(data), "sha256": digest(data)}
    if path.suffix == ".olean":
        row["reason"] = "Reproducible compiler object; exact source, compiler identity, command, origin, full logs and object hash are retained."
        excluded.append(row)
    else:
        files.append(row)
assert len(excluded) == 10, len(excluded)
manifest = {
    "schema_version": 1,
    "head": HEAD,
    "base": BASE,
    "combined_tree": TREE,
    "review_decision": receipt["decision"],
    "package_format": "Deterministic gzip-compressed tar containing every listed regular file byte-for-byte and this manifest.",
    "scope": "Independent nonauthor review evidence only; no remote mutation.",
    "verified_original_package_files": 99,
    "verified_exact_source_modules": 10,
    "files": files,
    "excluded_reproducible_objects": excluded,
    "other_infrastructure_exclusions": [
        "Official Lean distribution: pinned version, executable and shared library identities retained.",
        "Local Git object caches: exact research-source blobs and file bytes retained.",
    ],
    "manifest_self_hash": "Omitted from its own file list; recorded in PACKET_RECEIPT.json.",
}
write_json(MANIFEST, manifest)
manifest_data = MANIFEST.read_bytes()
archive_rows = files + [{
    "path": MANIFEST.name, "bytes": len(manifest_data),
    "sha256": digest(manifest_data)}]
expected = {row["path"]: row for row in archive_rows}
assert len(expected) == len(archive_rows)
with ARCHIVE.open("xb") as target:
    with gzip.GzipFile(filename="", mode="wb", compresslevel=6, mtime=0, fileobj=target) as compressed:
        with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as packet:
            for row in sorted(archive_rows, key=lambda r: r["path"]):
                name = row["path"]
                pure = PurePosixPath(name)
                assert not pure.is_absolute() and ".." not in pure.parts
                data = verify(ROOT / name, row)
                entry = tarfile.TarInfo(name=name)
                entry.size = len(data)
                entry.mtime = 0
                entry.mode = 0o644
                entry.uid = entry.gid = 0
                entry.uname = entry.gname = ""
                packet.addfile(entry, io.BytesIO(data))
seen = set()
with tarfile.open(ARCHIVE, mode="r:gz") as packet:
    for entry in packet:
        name = entry.name
        assert name not in seen and name in expected
        assert entry.isfile()
        pure = PurePosixPath(name)
        assert not pure.is_absolute() and ".." not in pure.parts
        data = packet.extractfile(entry).read()
        assert entry.size == len(data) == expected[name]["bytes"]
        assert digest(data) == expected[name]["sha256"]
        seen.add(name)
assert seen == set(expected)
tar_hash = hashlib.sha256()
tar_bytes = 0
with gzip.open(ARCHIVE, "rb") as source:
    while True:
        block = source.read(1048576)
        if not block:
            break
        tar_bytes += len(block)
        tar_hash.update(block)
archive_data = ARCHIVE.read_bytes()
packet_receipt = {
    "schema_version": 1,
    "status": "PASS_LOSSLESS_PACKET_ROUNDTRIP",
    "head": HEAD, "base": BASE, "combined_tree": TREE,
    "review_decision": receipt["decision"],
    "archive_path": str(ARCHIVE),
    "compressed_bytes": len(archive_data),
    "compressed_sha256": digest(archive_data),
    "uncompressed_tar_bytes": tar_bytes,
    "uncompressed_tar_sha256": tar_hash.hexdigest(),
    "archive_member_count": len(archive_rows),
    "preserved_file_payload_bytes": sum(row["bytes"] for row in archive_rows),
    "excluded_reproducible_object_count": len(excluded),
    "excluded_reproducible_object_bytes": sum(row["bytes"] for row in excluded),
    "manifest_path": str(MANIFEST),
    "manifest_sha256": digest(manifest_data),
    "all_archive_member_paths_unique_relative_regular": True,
    "all_archive_member_sizes_and_sha256_verified_after_roundtrip": True,
    "verified_original_package_files": 99,
    "verified_exact_source_modules": 10,
    "no_remote_publication_performed": True,
    "recovery_command": "mkdir -p pr110-review && tar -xzf review110-evidence.tar.gz -C pr110-review",
}
write_json(PACKET_RECEIPT, packet_receipt)
print(json.dumps(packet_receipt, indent=2))
