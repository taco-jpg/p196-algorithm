#!/usr/bin/env python3
"""Complete PR #110 verification after the recorded ENOSPC failure.

The six intact prerequisite objects come only from this reviewer's new clean-001
compilation. The truncated GroupIII object is never used. All remaining modules
are rebuilt, and every selected module is covered by the final complete audit.
The original failed run and its runner remain unchanged.
"""
import ast
import collections
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time
import traceback

from run_clean_review import code_only

ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "evidence"
OLD = Path("/workspace/scratch/6124a6476634/review110/evidence/clean-001")
LEAN = Path("/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean")
PREVIOUS_RUNNER_SHA = "106569da0b1a44e7372e52c2c531ac4d9befe0de81dde8eade90dd41285794aa"

def sha(data):
    return hashlib.sha256(data).hexdigest()

def main():
    free = shutil.disk_usage(ROOT).free
    if free < 160 * 1024 * 1024:
        raise RuntimeError(f"Recovery not started: only {free} free bytes; need at least 160 MiB.")
    runner_bytes = (ROOT / "run_clean_review.py").read_bytes()
    assert sha(runner_bytes) == PREVIOUS_RUNNER_SHA
    prior_bytes = (OLD / "receipt.json").read_bytes()
    prior = json.loads(prior_bytes)
    assert prior["status"] == "FAIL"
    order = prior["module_order"]
    reused = order[:6]
    remaining = order[6:]
    assert remaining == ["Agent1GroupIII", "Agent1GroupIIIHandoff", "Agent1GroupIIINumeric", "Agent1GroupIIIHandoffNumeric"]
    out = EVIDENCE / "recovery-001"
    out.mkdir(exist_ok=False)
    source, logs = out / "source", out / "logs"
    source.mkdir(); logs.mkdir()
    env = {"PATH": str(LEAN.parent) + ":/usr/bin:/bin", "LANG": "C.UTF-8", "LEAN_PATH": str(source)}
    report = {"agent": "Agent #13 genuine nonauthor review110 subagent", "status": "RUNNING",
              "started_epoch": time.time(), "initial_free_bytes": free,
              "head": prior["head"], "base": prior["base"], "combined_tree": prior["combined_tree"],
              "prior_failed_receipt": str(OLD / "receipt.json"), "prior_failed_receipt_sha256": sha(prior_bytes),
              "prior_failed_run_retained": True, "one_uninterrupted_successful_build_claimed": False,
              "all_project_objects_derive_from_this_reviewers_fresh_source_build": True,
              "author_or_previous_reviewer_project_objects_reused": False,
              "repository_wide_pass": False, "environment": env, "commands": [],
              "runner_sha256": sha(Path(__file__).read_bytes()), "original_runner_sha256": sha(runner_bytes),
              "module_order": order, "source_scan": prior["source_scan"],
              "public_new_theorem_endpoints": prior["public_new_theorem_endpoints"],
              "public_new_definitions": prior["public_new_definitions"], "reused_own_fresh_objects": []}

    def save():
        tmp = out / "receipt.json.tmp"
        with tmp.open("w") as stream:
            stream.write(json.dumps(report, indent=2) + "\n")
            stream.flush()
            os.fsync(stream.fileno())
        tmp.replace(out / "receipt.json")

    def command(label, argv, timeout=1800):
        started = time.monotonic()
        log = logs / (label + ".log")
        with log.open("wb") as stream:
            try:
                rc = subprocess.run(argv, cwd=source, env=env, stdout=stream,
                                    stderr=subprocess.STDOUT, timeout=timeout).returncode
            except subprocess.TimeoutExpired:
                rc = 124
        raw = log.read_bytes()
        report["commands"].append({"label": label, "argv": argv, "cwd": str(source),
                                  "exit_code": rc, "elapsed_seconds": round(time.monotonic()-started, 6),
                                  "log": str(log.relative_to(out)), "log_bytes": len(raw), "log_sha256": sha(raw),
                                  "free_bytes_after_command": shutil.disk_usage(ROOT).free})
        save()
        print(label + " exit=" + str(rc), flush=True)
        if rc:
            raise RuntimeError("Failed " + label + "; full log retained")
        return raw.decode()

    try:
        for path, expected in prior["compiler"]["files"].items():
            assert sha(Path(path).read_bytes()) == expected, path
        report["compiler"] = prior["compiler"]
        assert command("lean-version", [str(LEAN), "--version"], 30).strip() == prior["compiler"]["version"]
        registry_bytes = (EVIDENCE / "input/proofs/Agent1GroupIIIHandoff.registry.json").read_bytes()
        assert sha(registry_bytes) == prior["registry_sha256"]
        registry = json.loads(registry_bytes)
        modules = registry["projects"]["agent1-groupIII-handoff"]["modules"]
        report["registry_sha256"] = sha(registry_bytes)
        for module, rec in modules.items():
            raw = (EVIDENCE / "source" / (module + ".lean")).read_bytes()
            assert sha(raw) == rec["sha256"]
            assert hashlib.sha1(f"blob {len(raw)}\0".encode() + raw).hexdigest() == rec["git_blob"]
            code = code_only(raw.decode())
            deps = [d for line in re.findall(r"^\s*import\s+([^\n]+)", code, re.M) for d in line.split()]
            assert deps == rec["imports"]
            assert not re.search(r"(?<![\w'])\b(?:sorry|admit|axiom|sorryAx|native_decide|ofReduceBool|skipKernelTC)\b(?![\w'])", code)
            (source / (module + ".lean")).write_bytes(raw)
        package = EVIDENCE / "input/proofs/contributions/agent-1/groupIII-handoff-20261016"
        boundary = json.loads((package / "author/boundary-specialist/manifest.json").read_text())
        author_audit = json.loads((package / "author/audit-001/run.json").read_text())
        expected_objects = {m: boundary["dependencies"][m + ".olean"] for m in order if m + ".olean" in boundary["dependencies"]}
        expected_objects.update({m: data["object_sha256"] for m, data in author_audit["source_objects"].items()})
        assert set(expected_objects) == set(order)
        for module in reused:
            old_object = OLD / "source" / (module + ".olean")
            own_raw = old_object.read_bytes()
            assert sha(own_raw) == expected_objects[module], module
            own_commands = [c for c in prior["commands"] if c["label"] == module]
            assert len(own_commands) == 1 and own_commands[0]["exit_code"] == 0
            assert sha((OLD / own_commands[0]["log"]).read_bytes()) == own_commands[0]["log_sha256"]
            assert (OLD / "source" / (module + ".lean")).read_bytes() == (source / (module + ".lean")).read_bytes()
            shutil.copyfile(old_object, source / (module + ".olean"))
            assert sha((source / (module + ".olean")).read_bytes()) == expected_objects[module]
            report["reused_own_fresh_objects"].append({"module": module, "source_run": "clean-001",
                                                       "bytes": len(own_raw), "sha256": sha(own_raw),
                                                       "own_compile_command": own_commands[0],
                                                       "retained_reference_metadata_compared": True,
                                                       "author_object_read_or_copied": False})
        save()
        flags = ["--trust=0", "-j1", "-DElab.async=false"]
        for module in remaining:
            command(module, [str(LEAN), *flags, "-o", module + ".olean", module + ".lean"])
            obj = source / (module + ".olean")
            actual = sha(obj.read_bytes())
            assert actual == expected_objects[module], module + " incomplete or unexpected object"
            report.setdefault("rebuilt_objects", []).append({"module": module, "bytes": obj.stat().st_size, "sha256": actual})
            save()
        endpoints = prior["public_new_theorem_endpoints"]
        definitions = prior["public_new_definitions"]
        literals = [n.value for n in ast.walk(ast.parse(runner_bytes.decode())) if isinstance(n, ast.Constant)
                    and isinstance(n.value, str) and "COMPLETE_MODULE_AUDIT constants={audited}" in n.value]
        assert len(literals) == 1
        audit = "import Agent1GroupIIIHandoffNumeric\nimport Lean\nopen Lean Elab Command\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\nset_option pp.universes true\n"
        audit += "\n".join("#check " + n + "\n#print axioms " + n for n in endpoints + definitions)
        audit += "\nrun_cmd do\n  let env ← getEnv\n  let selected : List String := " + json.dumps(order) + literals[0]
        (source / "Review110Audit.lean").write_text(audit)
        audit_log = command("Review110Audit", [str(LEAN), *flags, "Review110Audit.lean"])
        rows = re.findall(r"^AUDIT_CONSTANT (\S+) (\S+) (\S+) : (.*)$", audit_log, re.M)
        types = re.findall(r"^AUDIT_TYPE (\S+) (\S+) :", audit_log, re.M)
        totals = re.findall(r"^COMPLETE_MODULE_AUDIT constants=(\d+) union=([^\n]*)$", audit_log, re.M)
        assert len(totals) == 1 and int(totals[0][0]) == len(rows)
        assert len({r[2] for r in rows}) == len(rows)
        assert {(r[1],r[2]) for r in rows} == set(types)
        assert set(endpoints + definitions) <= {r[2] for r in rows}
        printed = re.findall(r"'([^']+)' (?:depends on axioms|does not depend on any axioms)", audit_log)
        assert set(printed) == set(endpoints + definitions) and len(printed) == 50
        counts = collections.Counter(r[0] for r in rows)
        assert counts["theorem"] == 2547
        boundaries = [n for n in endpoints if n.startswith("P196.Agent1.GroupIIIHandoff.r1_")]
        assert len(boundaries) == 5
        assert all(r[3] == "[]" for r in rows if r[2] in boundaries)
        report.update({"audited_constant_count": len(rows), "type_records": len(types),
                       "count_by_kind": dict(counts), "literal_public_print_count": len(printed),
                       "count_by_module_and_kind": {m: dict(collections.Counter(r[0] for r in rows if r[1] == m)) for m in order},
                       "axiom_union": totals[0][1], "r1_boundary_axioms": {n: [] for n in boundaries},
                       "unsafe_implementation_axioms": re.findall(r"^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$", audit_log, re.M),
                       "nonsafe_definitions": re.findall(r"^NONSAFE_DEFINITION (\S+) (\S+)$", audit_log, re.M),
                       "unsafe_opaques": re.findall(r"^UNSAFE_OPAQUE (\S+) (\S+)$", audit_log, re.M)})
        (out / "constant-audit.json").write_text(json.dumps([{"kind": k, "module": m, "name": n, "axioms": a} for k,m,n,a in rows], indent=2) + "\n")
        for m, rec in modules.items():
            assert sha((source / (m + ".lean")).read_bytes()) == rec["sha256"]
            assert sha((EVIDENCE / "source" / (m + ".lean")).read_bytes()) == rec["sha256"]
        for path, expected in prior["compiler"]["files"].items():
            assert sha(Path(path).read_bytes()) == expected
        report["status"] = "PASS_RECOVERED_FRESH_TEN_MODULE_CLOSURE_COMPLETE_TYPE_AND_AXIOM_AUDIT"
        return 0
    except Exception as error:
        report["status"] = "FAIL"
        report["error"] = str(error)
        (out / "failure.txt").write_text(traceback.format_exc())
        print("FAIL " + str(error), flush=True)
        return 1
    finally:
        report["finished_epoch"] = time.time()
        save()
        files = {str(p.relative_to(out)): {"bytes": p.stat().st_size, "sha256": sha(p.read_bytes())}
                 for p in sorted(out.rglob("*")) if p.is_file() and p.suffix != ".olean" and p.name != "FILES.json"}
        (out / "FILES.json").write_text(json.dumps(files, indent=2) + "\n")

if __name__ == "__main__":
    raise SystemExit(main())
