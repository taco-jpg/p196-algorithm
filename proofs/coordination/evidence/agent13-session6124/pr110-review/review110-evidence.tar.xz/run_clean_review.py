#!/usr/bin/env python3
"""Independent exact-source PR #110 rebuild and complete module-origin audit.

The comment/string masker and origin-selection pattern are adapted from the
inspected, retained verify_project__214bf7673efe116b.py and independent_build.py.
This runner is separate from those unmodified originals. It strengthens the
explicit compiler flags and audits safe definitions and types in addition to
all theorem constants. It never loads author-generated project objects.
"""
from __future__ import annotations

import collections
import hashlib
import json
import pathlib
import re
import subprocess
import sys
import time
import traceback

ROOT = pathlib.Path(__file__).resolve().parent
EVIDENCE = ROOT / "evidence"
LEAN = pathlib.Path("/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean")
LEAN_SHA256 = "92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023"
REGISTRY = EVIDENCE / "input/proofs/Agent1GroupIIIHandoff.registry.json"
FORBIDDEN = re.compile(r"(?<![\w'])\b(?:sorry|admit|axiom|sorryAx|native_decide|ofReduceBool|skipKernelTC)\b(?![\w'])")

def sha(data):
    return hashlib.sha256(data).hexdigest()

def code_only(text):
    """Mask nested Lean comments and strings without changing line positions."""
    out, i, depth, string = [], 0, 0, False
    while i < len(text):
        pair = text[i:i+2]
        if depth:
            if pair == "/-":
                depth += 1; out.extend("  "); i += 2
            elif pair == "-/":
                depth -= 1; out.extend("  "); i += 2
            else:
                out.append("\n" if text[i] == "\n" else " "); i += 1
        elif string:
            if text[i] == "\\":
                out.extend("  "); i += 2
            else:
                string = text[i] != '"'; out.append("\n" if text[i] == "\n" else " "); i += 1
        elif pair == "/-":
            depth = 1; out.extend("  "); i += 2
        elif pair == "--":
            end = text.find("\n", i); end = len(text) if end < 0 else end
            out.extend(" " * (end-i)); i = end
        elif text[i] == '"':
            string = True; out.append(" "); i += 1
        else:
            out.append(text[i]); i += 1
    if depth or string:
        raise ValueError("Unterminated comment or string")
    return "".join(out)

def main():
    label = sys.argv[1]
    if not re.fullmatch(r"[A-Za-z0-9_-]+", label):
        raise ValueError("Invalid run label")
    out = EVIDENCE / label
    out.mkdir(exist_ok=False)
    source = out / "source"
    logs = out / "logs"
    source.mkdir(); logs.mkdir()
    env = {"PATH": str(LEAN.parent) + ":/usr/bin:/bin", "LANG": "C.UTF-8", "LEAN_PATH": str(source)}
    report = {"agent": "Agent #13 independent nonauthor subagent review110", "status": "RUNNING",
              "started_epoch": time.time(), "commands": [], "environment": env,
              "head": "624cc122e39e4d1f30b5c17890e7aac17c40a1e9",
              "base": "1ee9123344dbe17e9bda224ff8af5b1cbb2b64e4",
              "combined_tree": "23ef1e89374822bf559a1cf0760878f941a9dc56",
              "author_project_objects_reused": False, "repository_wide_pass": False,
              "runner_sha256": sha(pathlib.Path(__file__).read_bytes())}

    def save():
        (out / "receipt.json").write_text(json.dumps(report, indent=2) + "\n")

    def command(label, argv, timeout=1800):
        log = logs / (label + ".log")
        started = time.monotonic()
        with log.open("wb") as stream:
            try:
                rc = subprocess.run(argv, cwd=source, env=env, stdout=stream,
                                    stderr=subprocess.STDOUT, timeout=timeout).returncode
            except subprocess.TimeoutExpired:
                rc = 124
        raw = log.read_bytes()
        report["commands"].append({"label": label, "argv": argv, "cwd": str(source),
                                   "exit_code": rc, "elapsed_seconds": round(time.monotonic()-started, 6),
                                   "log": str(log.relative_to(out)), "log_bytes": len(raw), "log_sha256": sha(raw)})
        save()
        print(label + " exit=" + str(rc), flush=True)
        if rc:
            raise RuntimeError("Failed " + label + "; full failure log retained")
        return raw.decode()

    try:
        assert sha(LEAN.read_bytes()) == LEAN_SHA256, "Compiler executable hash mismatch"
        version = command("lean-version", [str(LEAN), "--version"], 30).strip()
        assert re.search(r"version 4\.19\.0,.*commit 6caaee842e94, Release", version), version
        runtime = pathlib.Path(command("lean-prefix", [str(LEAN), "--print-prefix"], 30).strip())
        compiler_files = [LEAN, *sorted((runtime / "lib/lean").glob("*.so"))]
        report["compiler"] = {"version": version, "files": {str(p): sha(p.read_bytes()) for p in compiler_files}}
        registry_bytes = REGISTRY.read_bytes()
        registry = json.loads(registry_bytes)
        report["registry_sha256"] = sha(registry_bytes)
        assert registry["toolchain"]["allowed_axioms"] == ["propext", "Classical.choice", "Quot.sound"]
        spec = registry["projects"]["agent1-groupIII-handoff"]
        modules = spec["modules"]
        assert len(modules) == 10
        imports, originals, endpoints, new_definitions, scan = {}, {}, [], [], {}
        for module, rec in modules.items():
            original = EVIDENCE / "source" / (module + ".lean")
            raw = original.read_bytes()
            assert sha(raw) == rec["sha256"], module
            assert hashlib.sha1(f"blob {len(raw)}\0".encode() + raw).hexdigest() == rec["git_blob"], module
            code = code_only(raw.decode())
            assert not FORBIDDEN.search(code), module + " has a forbidden source token"
            deps = [d for line in re.findall(r"^\s*import\s+([^\n]+)", code, re.M) for d in line.split()]
            assert deps == rec["imports"], module
            for dep in deps:
                if dep not in modules:
                    assert dep.split(".")[0] in {"Init", "Std", "Lean"}, dep
                    assert (runtime / "lib/lean" / (dep.replace(".", "/") + ".olean")).is_file(), dep
            imports[module] = deps
            originals[module] = (original, raw)
            (source / (module + ".lean")).write_bytes(raw)
            scan[module] = {"forbidden_tokens": [], "sha256": sha(raw), "git_blob": rec["git_blob"],
                            "imports": deps, "special_commands": re.findall(r"^.*(?:unsafe|partial|implemented_by|extern|run_cmd|run_tac|#eval|set_option).*$", code, re.M)}
            if module in {"Agent1GroupIIIHandoff", "Agent1GroupIIIHandoffNumeric"}:
                assert re.findall(r"^namespace\s+(\S+)", code, re.M) == ["P196.Agent1.GroupIIIHandoff"]
                endpoints.extend("P196.Agent1.GroupIIIHandoff." + name for name in re.findall(r"^theorem\s+([\w']+)", code, re.M))
                new_definitions.extend("P196.Agent1.GroupIIIHandoff." + name for name in re.findall(r"^def\s+([\w']+)", code, re.M))
        assert len(endpoints) == 43
        assert len(new_definitions) == 7
        order, active, visited = [], set(), set()
        def visit(module):
            if module not in modules:
                return
            assert module not in active, "Import cycle"
            if module in visited:
                return
            active.add(module)
            for dep in imports[module]:
                visit(dep)
            active.remove(module); visited.add(module); order.append(module)
        for root in spec["roots"]:
            visit(root)
        assert visited == set(modules), "Not exactly the root import closure"
        assert not list(source.glob("*.olean")), "Build directory was not clean"
        report.update({"module_order": order, "source_scan": scan,
                       "public_new_theorem_endpoints": endpoints, "public_new_definitions": new_definitions,
                       "project_objects_before_build": [], "import_closure_exact": True})
        save()
        flags = ["--trust=0", "-j1", "-DElab.async=false"]
        for module in order:
            command(module, [str(LEAN), *flags, "-o", module + ".olean", module + ".lean"])
        audit = "import Agent1GroupIIIHandoffNumeric\nimport Lean\nopen Lean Elab Command\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\nset_option pp.universes true\n"
        audit += "\n".join("#check " + name + "\n#print axioms " + name for name in endpoints + new_definitions)
        audit += "\nrun_cmd do\n  let env ← getEnv\n  let selected : List String := " + json.dumps(order) + '''
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut audited : Nat := 0
  let mut union : List Name := []
  for mod in selected do
    if !(env.allImportedModuleNames.toList.any (fun name => name.toString == mod)) then
      throwError m!"MISSING_PROJECT_MODULE {mod}"
    logInfo m!"PROJECT_MODULE {mod}"
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        let kind : String ← match info with
          | .axiomInfo v =>
            if v.isUnsafe then
              logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {mod} {name}"
              pure ""
            else throwError m!"CUSTOM_AXIOM {mod} {name}"
          | .thmInfo _ => pure "theorem"
          | .defnInfo v =>
            if v.safety == .safe then pure "safe_definition"
            else
              logInfo m!"NONSAFE_DEFINITION {mod} {name}"
              pure ""
          | .opaqueInfo v =>
            if v.isUnsafe then
              logInfo m!"UNSAFE_OPAQUE {mod} {name}"
              pure ""
            else pure "safe_opaque"
          | .inductInfo _ => pure "inductive"
          | .ctorInfo _ => pure "constructor"
          | .recInfo _ => pure "recursor"
          | .quotInfo _ => pure "quotient"
        if kind != "" then
          audited := audited + 1
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          for ax in axl do
            if !(union.contains ax) then union := ax :: union
          if axl.any (fun ax => !(allowed.contains ax)) then
            throwError m!"DISALLOWED_AXIOMS {mod} {name} : {axl}"
          logInfo m!"AUDIT_CONSTANT {kind} {mod} {name} : {axl}"
          logInfo m!"AUDIT_TYPE {mod} {name} : {info.type}"
  logInfo m!"COMPLETE_MODULE_AUDIT constants={audited} union={union}"
'''
        (source / "Review110Audit.lean").write_text(audit)
        audit_log = command("Review110Audit", [str(LEAN), *flags, "Review110Audit.lean"])
        rows = re.findall(r"^AUDIT_CONSTANT (\S+) (\S+) (\S+) : (.*)$", audit_log, re.M)
        types = re.findall(r"^AUDIT_TYPE (\S+) (\S+) :", audit_log, re.M)
        totals = re.findall(r"^COMPLETE_MODULE_AUDIT constants=(\d+) union=([^\n]*)$", audit_log, re.M)
        assert len(totals) == 1 and int(totals[0][0]) == len(rows)
        assert len({row[2] for row in rows}) == len(rows)
        assert {(row[1], row[2]) for row in rows} == set(types)
        assert set(endpoints + new_definitions) <= {row[2] for row in rows}
        counts = collections.Counter(row[0] for row in rows)
        assert counts["theorem"] == 2547, counts
        report.update({"audited_constant_count": len(rows), "type_records": len(types),
                       "count_by_kind": dict(counts),
                       "count_by_module_and_kind": {module: dict(collections.Counter(row[0] for row in rows if row[1] == module)) for module in order},
                       "axiom_union": totals[0][1],
                       "unsafe_implementation_axioms": re.findall(r"^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$", audit_log, re.M),
                       "nonsafe_definitions": re.findall(r"^NONSAFE_DEFINITION (\S+) (\S+)$", audit_log, re.M),
                       "unsafe_opaques": re.findall(r"^UNSAFE_OPAQUE (\S+) (\S+)$", audit_log, re.M)})
        (out / "constant-audit.json").write_text(json.dumps([{"kind": k, "module": m, "name": n, "axioms": a} for k,m,n,a in rows], indent=2) + "\n")
        for module, (original, raw) in originals.items():
            assert original.read_bytes() == raw and (source / (module + ".lean")).read_bytes() == raw, module
        for path, digest in report["compiler"]["files"].items():
            assert sha(pathlib.Path(path).read_bytes()) == digest, path
        report["status"] = "PASS_FRESH_EXACT_TEN_MODULE_BUILD_COMPLETE_TYPE_AND_AXIOM_AUDIT"
        return 0
    except Exception as error:
        report["status"] = "FAIL"
        report["error"] = str(error)
        (out / "failure.txt").write_text(traceback.format_exc())
        print("FAIL " + str(error), flush=True)
        return 1
    finally:
        report["finished_epoch"] = time.time()
        save()
        files = {str(p.relative_to(out)): {"bytes": p.stat().st_size, "sha256": sha(p.read_bytes())}
                 for p in sorted(out.rglob("*")) if p.is_file() and p.suffix != ".olean" and p.name != "FILES.json"}
        (out / "FILES.json").write_text(json.dumps(files, indent=2) + "\n")

if __name__ == "__main__":
    raise SystemExit(main())
