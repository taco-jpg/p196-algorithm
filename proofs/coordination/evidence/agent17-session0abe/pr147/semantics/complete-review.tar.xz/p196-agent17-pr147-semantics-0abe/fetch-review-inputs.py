import concurrent.futures, hashlib, json, pathlib, urllib.request
ROOT=pathlib.Path('/dev/shm/p196-agent17-pr147-semantics-0abe')
HEAD='e77289c5f58a3238f53c0f3c6951a73515c5d7d2'
REPO='taco-jpg/p196-algorithm'
BASE='https://raw.githubusercontent.com/'+REPO+'/'+HEAD+'/'
def fetch(url):
    return urllib.request.urlopen(urllib.request.Request(url,headers={'User-Agent':'Agent17-pinned-source-review'}),timeout=60).read()
def save(path,data):
    dest=ROOT/path
    dest.parent.mkdir(parents=True,exist_ok=True)
    dest.write_bytes(data)
regpath='proofs/Agent1PeriodicWidthLift.registry.json'
regdata=fetch(BASE+regpath)
save('inputs/'+regpath,regdata)
reg=json.loads(regdata)
modules=reg['projects']['agent1-periodic-width-projection']['modules']
allfiles=[]
for page in range(1,5):
    data=fetch('https://api.github.com/repos/'+REPO+'/pulls/147/files?per_page=100&page='+str(page))
    save('api/files-page-'+str(page)+'.json',data)
    allfiles.extend(json.loads(data))
assert len(allfiles)==327 and len({f['filename'] for f in allfiles})==327
save('api/review-5554812356.json',fetch('https://api.github.com/repos/'+REPO+'/pulls/147/reviews/5554812356'))
save('api/pr147.json',fetch('https://api.github.com/repos/'+REPO+'/pulls/147'))
paths=sorted(set(m['path'] for m in modules.values())|{f['filename'] for f in allfiles if f['filename'].endswith('.md')})
def task(path):
    data=fetch(BASE+path)
    save('inputs/'+path,data)
    return path, {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\x00'+data).hexdigest()}
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:
    records=dict(pool.map(task,paths))
for module,record in modules.items():
    actual=records[record['path']]
    assert actual['sha256']==record['sha256'],module
    assert actual['git_blob']==record['git_blob'],module
records[regpath]={'bytes':len(regdata),'sha256':hashlib.sha256(regdata).hexdigest()}
save('INPUT-FILES.json',(json.dumps({'head':HEAD,'files':records},indent=2)+'\n').encode())
groups={}
for f in allfiles:
    p=f['filename']
    g='mathematical-source-and-registry' if not p.startswith('proofs/contributions/') else '/'.join(p.split('/')[5:6])
    groups[g]=groups.get(g,0)+1
summary={'head':HEAD,'pages':[100,100,100,27],'all_unique_paths':len(allfiles),'statuses':sorted({f['status'] for f in allfiles}),'groups':groups,'source_modules':len(modules),'input_files':len(records),'all_module_hashes_and_git_blobs_match_registry':True,'lean_executed':False}
save('input-summary.json',(json.dumps(summary,indent=2)+'\n').encode())
print(json.dumps(summary,indent=2))
