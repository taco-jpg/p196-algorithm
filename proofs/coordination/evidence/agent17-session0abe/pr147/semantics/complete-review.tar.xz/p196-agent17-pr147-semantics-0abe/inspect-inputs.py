from pathlib import Path
from collections import Counter
import hashlib,json,re
root=Path('/dev/shm/p196-agent17-pr147-semantics-0abe')
allfiles=[f for p in range(1,5) for f in json.loads((root/'api'/('files-page-'+str(p)+'.json')).read_text())]
registry=json.loads((root/'inputs/proofs/Agent1PeriodicWidthLift.registry.json').read_text())
project=registry['projects']['agent1-periodic-width-projection']
modules=project['modules']
imports={}
for name,record in modules.items():
    content=(root/'inputs'/record['path']).read_text()
    imports[name]=re.findall(r'^import\s+(\S+)',content,re.M)
    assert imports[name]==record['imports'],name
seen=set()
def visit(name):
    if name in seen or name=='Std': return
    assert name in modules,name
    seen.add(name)
    for dependency in imports[name]: visit(dependency)
for name in project['roots']: visit(name)
assert seen==set(modules)
groups=Counter()
extensions=Counter()
inventory=[]
for record in allfiles:
    path=record['filename']
    group='mathematical-source-and-registry' if not path.startswith('proofs/contributions/') else path.split('/')[4]
    groups[group]+=1
    extensions[Path(path).suffix]+=1
    inventory.append({k:record[k] for k in ['filename','status','sha','additions','deletions','changes']})
review=json.loads((root/'api/review-5554812356.json').read_text())
pr=json.loads((root/'api/pr147.json').read_text())
assert review['commit_id']==pr['head']['sha']=='e77289c5f58a3238f53c0f3c6951a73515c5d7d2'
assert review['state']=='COMMENTED'
summary={'verdict':'SOURCE_AND_SCOPE_PASS','head':pr['head']['sha'],'base':pr['base']['sha'],'draft':pr['draft'],'pages':[100,100,100,27],'unique_paths':len(set(f['filename'] for f in allfiles)),'all_added':all(f['status']=='added' for f in allfiles),'groups':dict(groups),'extensions':dict(extensions),'local_module_imports_match_registry':True,'all_three_roots_import_closure_exact':True,'closure_count':len(seen),'new_public_endpoints':sum(len(c['endpoints']) for c in registry['claims']),'review_id':review['id'],'review_state':review['state'],'new_Lean_execution':False,'new_formal_build_claim':False}
(root/'SCOPE-SUMMARY.json').write_text(json.dumps(summary,indent=2)+'\n')
(root/'CHANGED-PATHS.json').write_text(json.dumps(inventory,indent=2)+'\n')
(root/'IMPORTS.json').write_text(json.dumps(imports,indent=2)+'\n')
print(json.dumps(summary,indent=2))
