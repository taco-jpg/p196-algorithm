import pathlib,json,urllib.request,hashlib,concurrent.futures,datetime,traceback
ROOT=pathlib.Path('/dev/shm/p196-agent17-pr147-evidence-0abe')
identity=json.loads((ROOT/'retained/review/final-source-identity.json').read_text())
H='e77289c5f58a3238f53c0f3c6951a73515c5d7d2'
M=identity['source_commit']
extra=[identity['registry_path'],'proofs/verify_project__214bf7673efe116b.py']
jobs=[(ref,e['path'],e['sha256'],e['git_blob']) for ref in [H,M] for e in identity['sources']]+[(ref,p,None,None) for ref in [H,M] for p in extra]
def run(job):
 ref,path,sha,blob=job; url='https://raw.githubusercontent.com/taco-jpg/p196-algorithm/'+ref+'/'+path
 row={'commit':ref,'path':path,'url':url,'expected_sha256':sha,'expected_git_blob_sha':blob}
 try:
  data=urllib.request.urlopen(url,timeout=45).read()
  dest=ROOT/'source-pins'/ref/path; dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(data)
  row.update(bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),git_blob_sha=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest())
  row['status']='PASS' if (sha is None or sha==row['sha256']) and (blob is None or blob==row['git_blob_sha']) else 'FAIL'
 except Exception:row.update(status='ERROR',traceback=traceback.format_exc())
 return row
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool: rows=list(pool.map(run,jobs))
(ROOT/'source-download-receipt.json').write_text(json.dumps({'head':H,'math_pin':M,'records':rows},indent=2)+'\n')
print(json.dumps({'files':len(rows),'bytes':sum(x.get('bytes',0) for x in rows),'failures':[x for x in rows if x['status']!='PASS']},indent=2))

