#!/usr/bin/env python3
"""Qualify existing PR147 evidence; never invokes Lean or writes retained inputs."""
from pathlib import Path
import ast, collections, datetime, difflib, hashlib, json, re
ROOT=Path(__file__).resolve().parent
R=ROOT/'retained/review'
C=R/'clean-001'
V=ROOT/'retained/verification/parent-clean-001'
H='e77289c5f58a3238f53c0f3c6951a73515c5d7d2'
M='8f9249c855418eaadf9bb68bd645948d15777b5b'
sha=lambda b:hashlib.sha256(b).hexdigest()
readj=lambda p:json.loads(p.read_text())
checks=[]
def check(name, condition, detail=None):
    row={'check':name,'status':'PASS' if condition else 'FAIL'}
    if detail is not None:row['detail']=detail
    checks.append(row)
    if not condition:raise AssertionError(row)
def manifest(base,name,count,complete=False):
    entries=readj(base/name)
    check(name+' entry count',len(entries)==count,len(entries))
    for p,e in entries.items():
        data=(base/p).read_bytes()
        check(name+' identity '+p,len(data)==e['bytes'] and sha(data)==e['sha256'])
    if complete:
        actual={str(p.relative_to(base)) for p in base.rglob('*') if p.is_file()}
        check(name+' complete coverage',actual==set(entries)|{name},sorted(actual-(set(entries)|{name})))
    return entries

identity=readj(R/'final-source-identity.json')
sources=identity['sources']; modules=[e['module'] for e in sources]
summary=readj(R/'audit-summary.json')
final=readj(R/'final-review-receipt.json')
check('head source pin',identity['source_commit']==M)
check('exact 30 unique source modules',len(sources)==len(set(modules))==30)
manifest(R,'FILES.json',108,True)
manifest(V,'FILES.json',63)
manifest(V,'PACKAGE-FILES.json',66,True)
for group,expected in [('download-receipt.json',176),('source-download-receipt.json',64)]:
    rec=readj(ROOT/group)['records']
    check(group+' verified downloads',len(rec)==expected and all(x['status']=='PASS' for x in rec))
check('source snapshot identity manifests',readj(C/'sources.json')==sources and (C/'final-source-identity.json').read_bytes()==(R/'final-source-identity.json').read_bytes())

original=(C/'replay.py').read_text(); portable=(R/'replay.py').read_text()
check('original build driver exact hash',sha(original.encode())==final['original_full_build_driver_sha256'])
check('portable driver exact hash',sha(portable.encode())==final['corrected_portable_driver_sha256'])
check('recovery exact hash',sha((R/'recover-postcheck.py').read_bytes())==final['executed_recovery_driver_sha256'])
check('portable copy preserved',(C/'postcheck-recovery-001/replay.py').read_text()==portable)
check('recovery copy preserved',(C/'postcheck-recovery-001/recover-postcheck.py').read_bytes()==(R/'recover-postcheck.py').read_bytes())
check('original and portable Lean execution prefixes identical',original.split('\nexports = []\n')[0].rstrip()==portable.split('\n# BEGIN POSTCHECK\n')[0].rstrip())
(ROOT/'driver-original-to-portable.diff').write_text(''.join(difflib.unified_diff(original.splitlines(True),portable.splitlines(True),fromfile='original-executed-driver',tofile='corrected-portable-driver')))
check('fresh build dir and isolated LEAN_PATH in executed driver',"build.mkdir(parents=True, exist_ok=False)" in original and "env = dict(os.environ, LEAN_PATH=str(build))" in original)
scanner=next(n for n in ast.parse(portable).body if isinstance(n,ast.FunctionDef) and n.name=='lean_code_tokens')
scope={}
exec(compile(ast.Module(body=[scanner],type_ignores=[]),'retained-reviewed-pure-scanner','exec'),scope)
scan=scope['lean_code_tokens']
pattern=r'\b(?:sorry|admit|native_decide|sorryAx|axiom)\b|Lean\.ofReduceBool'
recovery=(R/'recover-postcheck.py').read_text()
controls=next(ast.literal_eval(n.value) for n in ast.parse(recovery).body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='controls' for t in n.targets))
control_records=[]
for src,expected in controls:
    actual=re.findall(pattern,scan(src));check('retained scanner control '+sha(src.encode()),actual==expected)
    control_records.append({'input_sha256':sha(src.encode()),'expected':expected,'actual':actual})
for bad in ['/- unterminated','def x := "unterminated']:
    try:scan(bad)
    except AssertionError:control_records.append({'input_sha256':sha(bad.encode()),'unterminated_input_rejected':True})
    else:raise AssertionError('invalid input accepted')
check('eight exact scanner controls reproduced without Lean',control_records==readj(C/'postcheck-recovery-001/tokenizer-controls.json'))

registry_path=identity['registry_path']
registry=readj(ROOT/'source-pins'/H/registry_path)
project=registry['projects']['agent1-periodic-width-projection']
check('registry pin',sha((ROOT/'source-pins'/H/registry_path).read_bytes())==identity['registry_sha256'])
check('registry frozen H versus math pin',(ROOT/'source-pins'/H/registry_path).read_bytes()==(ROOT/'source-pins'/M/registry_path).read_bytes())
source_records=[]; graph={}; raw_failures=[];exports=[]
for e in sources:
    mod=e['module']; data=(ROOT/'source-pins'/H/e['path']).read_bytes()
    copies=[ROOT/'source-pins'/M/e['path'],C/'compiled-sources'/(mod+'.lean'),V/'agent1-periodic-width-projection/source'/(mod+'.lean')]
    check('source pin identity '+mod,sha(data)==e['sha256'] and hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()==e['git_blob'] and all(p.read_bytes()==data for p in copies))
    check('registry source mapping '+mod,project['modules'][mod]=={k:v for k,v in e.items() if k!='module'})
    text=data.decode();code=scan(text)
    imports=[x for line in re.findall(r'^\s*import\s+([^\n]+)',code,re.M) for x in line.split()]
    check('actual source imports '+mod,imports==e['imports'],imports)
    check('topological build order '+mod,all(x=='Std' or (x in modules and modules.index(x)<modules.index(mod)) for x in imports))
    graph[mod]=[x for x in imports if x!='Std']
    if mod.startswith('Agent1'):
        check('comment-aware forbidden-token scan '+mod,not re.findall(pattern,code))
        raw=re.findall(pattern,text)
        if raw:raw_failures.append({'module':mod,'tokens':raw})
        ns='Agent1.Periodic' if mod.startswith('Agent1Periodic') else 'Agent1.RepeatedBlock'
        for name in re.findall(r'^theorem\s+(\w+)',text,re.M):exports.append((mod,ns+'.'+name))
    source_records.append({'module':mod,'path':e['path'],'bytes':len(data),'sha256':sha(data),'git_blob':e['git_blob'],'actual_imports':imports,'math_head_independent_canonical_identical':True})
closure=set()
def visit(mod):
    if mod in closure:return
    closure.add(mod)
    for dep in graph[mod]:visit(dep)
for root in identity['roots']:visit(root)
check('exact transitive source closure',closure==set(modules),sorted(closure))
check('original wrapper first failure reproduced as comment-only admit',raw_failures and raw_failures[0]=={'module':'Agent1PeriodicWidthLift','tokens':['admit']},raw_failures)
failure=readj(C/'postcheck-recovery-001/original-wrapper-failure.json')
check('wrapper failure points to original bytes',failure['original_executed_driver_sha256']==sha(original.encode()) and failure['source_sha256']==sha((C/'compiled-sources/Agent1PeriodicWidthLift.lean').read_bytes()) and failure['source_line'] in (C/'compiled-sources/Agent1PeriodicWidthLift.lean').read_text())
commands=readj(C/'results.json');compiler=readj(C/'compiler.json')
check('compiler identity exact retained official pin',compiler['sha256']=='92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023' and '4.19.0' in compiler['version'])
check('31 command order', [x['module'] for x in commands]==modules+['ReviewAudit'])
for result in commands:
    mod=result['module'];expected=[compiler['path'],'--trust=0','-j1','-DElab.async=false']+([] if mod=='ReviewAudit' else ['-o',mod+'.olean'])+[mod+'.lean']
    check('strict command '+mod,result['command']==expected and result['exit_code']==0 and result['timed_out'] is False,result)
    check('raw log identity '+mod,sha((C/(mod+'.log')).read_bytes())==result['log_sha256'])
    check('no Lean error diagnostics '+mod,not re.search(r'(?m)^.*(?:error:|declaration uses .sorry.|REVIEW_COMMAND_TIMEOUT|sorryAx|Lean\.ofReduceBool)',(C/(mod+'.log')).read_text()))
    check('resource caps '+mod,result['resource_limits']=={'address_space_mib_per_child':8192,'timeout_seconds_per_command':600,'lean_stack_kib':'compiler default'})
audit=(C/'ReviewAudit.lean').read_text();alog=(C/'ReviewAudit.log').read_text()
selected=json.loads(re.search(r'let selected : List String := (\[[^\n]+\])',audit).group(1))
check('audit origins cover exact modules',selected==modules)
check('public check commands exact source theorem inventory',re.findall(r'^#check (\S+)',audit,re.M)==[n for _,n in exports])
def axset(s):return set(x.strip() for x in s.split(',') if x.strip())
allowed={'propext','Classical.choice','Quot.sound'}
theorems=re.findall(r'^AUDIT_THEOREM (\S+) (\S+) : \[([^\]]*)\]',alog,re.M)
defs=re.findall(r'^AUDIT_SAFE_(?:DEFINITION|OPAQUE) (\S+) (\S+) : \[([^\]]*)\]',alog,re.M)
check('actual-origin theorem and safe-definition record counts',len(theorems)==1695 and len(defs)==430,{'theorems':len(theorems),'safe_definitions':len(defs)})
check('unique theorem records',len({(m,n) for m,n,a in theorems})==1695)
check('unique safe-definition records',len({(m,n) for m,n,a in defs})==430)
check('record origins selected',all(m in modules for m,n,a in theorems+defs))
check('each logical dependency uses only allowed axioms',all(axset(a)<=allowed for m,n,a in theorems+defs))
tu=set().union(*(axset(a) for m,n,a in theorems));du=set().union(*(axset(a) for m,n,a in defs))
check('raw theorem and definition axiom unions',tu==allowed and du=={'propext'},{'theorem_union':sorted(tu),'safe_definition_union':sorted(du)})
for mod in modules:
    t=sum(m==mod for m,n,a in theorems);d=sum(m==mod for m,n,a in defs)
    check('per-module full inventory '+mod,summary['per_module'][mod]=={'theorems':t,'safe_definitions':d} and t>0,{'theorems':t,'safe_definitions':d})
check('no rejected audit marker',not re.search(r'CUSTOM_AXIOM|DISALLOWED_AXIOMS|DISALLOWED_DEFINITION_AXIOMS|DISALLOWED_OPAQUE_AXIOMS|MODULE_NOT_AUDITED',alog))
check('raw audit summary markers',re.search(r'FULL_MODULE_AUDIT theorems=1695 union=\[([^\]]*)\]',alog) is not None and re.search(r'FULL_DEFINITION_AUDIT definitions=430 union=\[propext\]',alog) is not None)
for mod,name in exports:
    log=(C/(mod+'.log')).read_text()
    ax=re.search("'"+re.escape(name)+r"' depends on axioms:\s*\[([^\]]*)\]",log)
    no="'"+name+"' does not depend on any axioms" in log
    check('public theorem printed axioms '+name,(ax is not None and axset(ax.group(1))<=allowed) or no)
    check('public theorem printed type '+name,re.search(r'^'+re.escape(name)+r'(?:\s|\()',alog,re.M) is not None)
check('139 public exports and 16 new endpoints',len(exports)==139 and len(set(n for m,n in exports))==139 and len(summary['new_public_exports'])==16 and set(summary['new_public_exports'])<=set(n for m,n in exports))
nonsafe=re.findall(r'^NONSAFE_DEFINITION (\S+) (\S+)',alog,re.M)
unsafe_axioms=re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)',alog,re.M)
unsafe_opaque=re.findall(r'^UNSAFE_OPAQUE (\S+) (\S+)',alog,re.M)
cstages=[(m,n) for m,n in nonsafe if re.search(r'\._cstage[12](?:\.|$)',n)]
urec=[(m,n) for m,n in nonsafe if n.endswith('._unsafe_rec')]
unknown=set(nonsafe)-set(cstages)-set(urec)
safe_names={(m,n) for m,n,a in defs}
check('separate unsafe implementation counts',len(nonsafe)==6895 and len(cstages)==6864 and len(urec)==31 and len(unsafe_axioms)==35 and not unsafe_opaque and not unknown)
check('all unsafe-rec helpers have separately audited safe bases',all((m,n[:-len('._unsafe_rec')]) in safe_names for m,n in urec))
check('unsafe implementation axioms not logical dependencies',not {n for m,n in unsafe_axioms}&(tu|du))
inv=readj(C/'implementation-inventory.json');ver=readj(C/'verification.json')
check('preserved inventory matches raw logs',inv['unsafe_axioms']==[list(x) for x in unsafe_axioms] and ver['nonsafe_definitions_inventoried']==[list(x) for x in nonsafe] and inv['nonsafe_count']==len(nonsafe) and inv['cstage_helpers']==len(cstages) and inv['unsafe_rec_helpers']==len(urec) and not inv['unclassified_nonsafe'])
check('preserved verification matches full raw inventories',ver['audited_named_exports']==[n for m,n in exports] and ver['theorems_audited']==1695 and ver['safe_definitions_audited']==430 and set(ver['axiom_union'])==tu and set(ver['safe_definition_axiom_union'])==du)
check('final receipt hashes',final['verification_sha256']==sha((C/'verification.json').read_bytes()) and final['semantic_review_sha256']==sha((R/'semantic-review.md').read_bytes()) and final['parent_packaging_receipt_sha256']==sha((V/'source-identity-receipt.json').read_bytes()) and final['parent_package_manifest_sha256']==sha((V/'PACKAGE-FILES.json').read_bytes()))
recrec=readj(C/'postcheck-recovery-001/receipt.json')
check('retained recovery identity chain',recrec['status']=='PASS' and recrec['no_lean_process_executed_in_recovery'] is True and recrec['original_driver_sha256']==sha(original.encode()) and recrec['corrected_portable_driver_sha256']==sha(portable.encode()) and recrec['executed_recovery_driver_sha256']==sha(recovery.encode()) and recrec['verification_sha256']==sha((C/'verification.json').read_bytes()) and recrec['implementation_inventory_sha256']==sha((C/'implementation-inventory.json').read_bytes()))
parent=readj(V/'verification.json');pp=parent['projects']['agent1-periodic-width-projection']
check('canonical run preserved and source-clean recorded',parent['status']=='PASS' and parent['source_tree_clean'] is True and parent['source_commit']==M and parent['registry_sha256']==identity['registry_sha256'] and parent['repository_wide_pass'] is False)
check('canonical 31 command order',[x['label'] for x in pp['commands']]==modules+['ProjectAudit'])
for row in pp['commands']:
    check('canonical retained command/log '+row['label'],row['exit_code']==0 and sha((V/row['log']).read_bytes())==row['log_sha256'] and '--trust=0' not in row['argv'],row)
check('canonical checker source pin',(V/'canonical-checker.py').read_bytes()==(ROOT/'source-pins'/H/'proofs/verify_project__214bf7673efe116b.py').read_bytes()==(ROOT/'source-pins'/M/'proofs/verify_project__214bf7673efe116b.py').read_bytes())
check('no compiled project objects packaged',not [p for p in (ROOT/'retained').rglob('*') if p.suffix in {'.olean','.ilean','.so'}])
result={'status':'PASS','head':H,'mathematical_source_pin':M,'reviewer':'Agent17 evidence specialist /root/pr147_evidence, nonauthor; actual retained-evidence qualification only','lean_processes_executed':0,'remote_mutations':0,'blocking_evidence_gaps':[],'independent_lean_commands':31,'independent_fresh_sources':30,'theorems':1695,'safe_definitions':430,'public_exports':139,'new_public_exports':16,'theorem_axiom_union':sorted(tu),'safe_definition_axiom_union':sorted(du),'nonsafe_compiler_definitions':6895,'unsafe_compiler_implementation_axioms':35,'retained_original_wrapper_failures':1,'preserved_manifest_entries':{'independent':108,'parent_original':63,'parent_package':66},'source_records':source_records,'checks':checks,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(ROOT/'qualification-results.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))

