#!/usr/bin/env python3
"""Reconstruct exact Git trees and verify a preservation-only PR105 combination."""
import argparse, hashlib, json, urllib.request
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
API='https://api.github.com/repos/taco-jpg/p196-algorithm/'
def get(url):
    req=urllib.request.Request(url,headers={'User-Agent':'P196-Agent24-exact-integration','Accept':'application/vnd.github+json'})
    with urllib.request.urlopen(req,timeout=60) as r: return r.read()
def objhash(kind,data): return hashlib.sha1(kind.encode()+b' '+str(len(data)).encode()+b'\0'+data).hexdigest()
def leaves(tree):
    assert tree.get('truncated') is False
    return {e['path']:{'mode':e['mode'],'type':e['type'],'sha':e['sha']} for e in tree['tree'] if e['type']!='tree'}
def treehash(entries):
    root={}
    for path,e in entries.items():
        parts=path.split('/'); node=root
        for part in parts[:-1]: node=node.setdefault(part,{})
        assert parts[-1] not in node
        node[parts[-1]]=(e['mode'].lstrip('0'),e['sha'])
    def rec(node):
        items=[]
        for name,value in node.items():
            if isinstance(value,dict): mode,sha,key='40000',rec(value),name.encode()+b'/'
            else: mode,sha=value; key=name.encode()
            items.append((key,mode.encode()+b' '+name.encode()+b'\0'+bytes.fromhex(sha)))
        return objhash('tree',b''.join(x[1] for x in sorted(items,key=lambda x:x[0])))
    return rec(root)
def run(base):
    inputs=json.loads((ROOT/'input.json').read_text()); head=inputs['head']; mergebase=inputs['merge_base']
    maps={}; metadata={}
    for label,commit,existing in [('head',head,'head-tree.json'),('mergebase',mergebase,'mergebase-tree.json'),('base',base,('base-tree.json' if base==inputs['base'] else 'integration/base-'+base+'.tree.json'))]:
        cp=ROOT/'integration'/('commit-'+commit+'.json')
        if not cp.exists(): cp.write_bytes(get(API+'git/commits/'+commit))
        meta=json.loads(cp.read_text()); assert meta['sha']==commit
        tp=ROOT/existing
        if not tp.exists(): tp.write_bytes(get(API+'git/trees/'+meta['tree']['sha']+'?recursive=1'))
        parsed=json.loads(tp.read_text()); mp=leaves(parsed); actual=treehash(mp)
        assert actual==meta['tree']['sha'],(label,actual,meta['tree']['sha'])
        maps[label]=mp; metadata[label]={'commit':commit,'tree':actual,'leaf_count':len(mp),'parents':[p['sha'] for p in meta['parents']]}
    h,m,b=maps['head'],maps['mergebase'],maps['base']
    removed=sorted(set(m)-set(h)); modified=sorted(p for p in set(m)&set(h) if m[p]!=h[p]); added=sorted(set(h)-set(m))
    assert not removed and not modified,{'removed':removed,'modified':modified}
    advertised={x['path']:x['sha'] for x in inputs['files']}
    assert set(added)==set(advertised) and all(h[p]['sha']==advertised[p] for p in added)
    conflicts=[p for p in added if p in b and b[p]!=h[p]]; assert not conflicts,conflicts
    identical=[p for p in added if p in b]; new=[p for p in added if p not in b]
    combined=dict(b)
    for p in added: combined[p]=h[p]
    assert all(combined[p]==e for p,e in b.items())
    closure=[]
    for name,spec in inputs['modules'].items():
        path=spec['path']; data=(ROOT/'source'/path).read_bytes()
        assert hashlib.sha256(data).hexdigest()==spec['sha256']
        assert objhash('blob',data)==spec['git_blob']==h[path]['sha']==combined[path]['sha']
        closure.append({'module':name,'path':path,'git_blob':spec['git_blob'],'sha256':spec['sha256'],'unchanged_in_combination':True})
    preserved=[]
    for path in ['AGENTS.md','proofs/PUBLICATION_POLICY.md','proofs/ACCEPTED_BUILD.json','proofs/verify_project__214bf7673efe116b.py']:
        assert path in h and path in b and h[path]==b[path]==combined[path],path
        preserved.append({'path':path,**h[path]})
    for path in ['proofs/Agent105AffineDynamics.registry.json','proofs/Agent105UniformReturn.registry.json','proofs/Agent105UniformIntegerReturn.registry.json']:
        assert h[path]==combined[path],path
        preserved.append({'path':path,**h[path]})
    result={'schema':'p196-agent24-integration-source-check/v1','agent':'Agent #24','session':'cdc2341d6c4f','pr':105,'status':'PASSED','trees':metadata,'expected_combined_tree':treehash(combined),'combined_leaf_count':len(combined),'pr_delta':{'added':len(added),'modified':modified,'removed':removed,'exact_match_with_421_paginated_files':True},'new_paths_on_base':len(new),'identical_paths_on_base':identical,'conflicts':conflicts,'every_base_leaf_mode_type_blob_preserved':True,'registry_source_closure':closure,'preserved_policy_verifier_and_registry':preserved,'verification_reuse':'Existing independently reviewed fresh20 plus six extension compilations plus exhaustive26 theorem audit; exact unchanged source closure and canonical verifier. No new Lean compilation and no repository-wide build claimed.','new_tree_elements':[{'path':p,**h[p]} for p in new]}
    out=ROOT/'integration'/('combination-'+base+'.json'); out.write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'base':base,'expected_combined_tree':result['expected_combined_tree'],'trees':metadata,'added':len(added),'new':len(new),'identical':len(identical),'closure_modules':len(closure),'receipt':str(out)},indent=2))
if __name__=='__main__':
    parser=argparse.ArgumentParser(); parser.add_argument('--base',required=True); run(parser.parse_args().base)
