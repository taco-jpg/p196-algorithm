#!/usr/bin/env python3
"""Check bounded preservation and source identity; never execute Lean or source code."""
import hashlib
import json
import re
from intake import run, OUT, REPO

def write(name, obj):
    (OUT/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')

def imports(text):
    # Mask nested block comments, line comments, and string literals.
    out=[]; i=0; depth=0; quoted=False
    while i<len(text):
        pair=text[i:i+2]
        if depth:
            if pair=='/-': depth+=1; out.extend('  '); i+=2
            elif pair=='-/': depth-=1; out.extend('  '); i+=2
            else: out.append('\n' if text[i]=='\n' else ' '); i+=1
        elif quoted:
            if text[i]=='\\': out.extend('  '); i+=2
            else: quoted=text[i]!='"'; out.append('\n' if text[i]=='\n' else ' '); i+=1
        elif pair=='/-': depth=1; out.extend('  '); i+=2
        elif pair=='--':
            j=text.find('\n',i); j=len(text) if j<0 else j
            out.extend(' '*(j-i)); i=j
        elif text[i]=='"': quoted=True; out.append(' '); i+=1
        else: out.append(text[i]); i+=1
    assert depth==0 and not quoted
    masked=''.join(out)
    return [m for line in re.findall(r'^\s*import\s+([^\n]+)',masked,re.M) for m in line.split()]

if __name__=='__main__':
    tree=json.loads((OUT/'tree_entries.json').read_text())
    intake=json.loads((OUT/'combination_intake.json').read_text())
    assertions=[]
    def check(name,condition,detail=None):
        assertions.append({'name':name,'pass':bool(condition),'detail':detail})
    def changed(a,b):
        return {p:{'before':tree[a].get(p),'after':tree[b].get(p)} for p in sorted(set(tree[a])|set(tree[b])) if tree[a].get(p)!=tree[b].get(p)}
    cache={}
    def body(oid):
        if oid not in cache: cache[oid]=run(['git','cat-file','blob',oid],label='scoped_public_blob_bytes_'+oid).stdout
        return cache[oid]
    def entry(p,k): return tree[k].get(p)
    for base in ['B','T97','H97','H121']:
        lost=[p for p,v in tree[base].items() if tree['Tfinal'].get(p)!=v]
        check('preserve_every_'+base+'_entry',not lost,{'checked':len(tree[base]),'mismatches':lost})
    delta=changed('MB','H121')
    actual=changed('T97','Tfinal')
    check('PR121_delta_exactly_92_additions',len(delta)==92 and all(v['before'] is None and v['after'] for v in delta.values()))
    check('T97_to_Tfinal_exactly_PR121_delta',actual==delta,{'expected_paths':len(delta),'actual_paths':len(actual)})
    check('no_PR121_source_additions_already_in_T97',all(p not in tree['T97'] for p in delta))
    delta_rows=[]
    for p,d in delta.items():
        data=body(d['after']['oid'])
        delta_rows.append({'path':p,**d['after'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'same_in_Tfinal':entry(p,'Tfinal')==d['after']})
    write('pr121_delta_identity.json',delta_rows)
    restoration=changed('MB','H97')
    check('PR97_restoration_exactly_17_additions',len(restoration)==17 and all(v['before'] is None and v['after'] for v in restoration.values()))
    restoration_rows=[]
    for p,d in restoration.items():
        data=body(d['after']['oid'])
        row={'path':p,**d['after'],'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
             'same_in_T97':entry(p,'T97')==d['after'],'same_in_Tfinal':entry(p,'Tfinal')==d['after']}
        restoration_rows.append(row)
    check('all_17_restoration_bytes_preserved',all(r['same_in_T97'] and r['same_in_Tfinal'] for r in restoration_rows))
    write('pr97_restoration_identity.json',restoration_rows)
    registry_path='proofs/Agent5OrdinaryStreamPrefix.registry.json'
    registry_bytes=body(entry(registry_path,'H121')['oid'])
    registry=json.loads(registry_bytes)
    modules=registry['projects']['agent5-ordinary-stream-prefix']['modules']
    check('exactly_15_registered_modules',len(modules)==15)
    check('registry_unchanged_C121_H121_Tfinal',entry(registry_path,'C121')==entry(registry_path,'H121')==entry(registry_path,'Tfinal'))
    rows=[]
    for module,spec in modules.items():
        p=spec['path']; oid=entry(p,'H121')['oid']; data=body(oid)
        actual_imports=imports(data.decode())
        row={'module':module,'path':p,'registry_blob':spec['git_blob'],'actual_blob':oid,'registry_sha256':spec['sha256'],
             'actual_sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data),'registry_imports':spec['imports'],'actual_imports':actual_imports,
             'entries':{key:entry(p,key) for key in ['B','MB','H97','T97','C121','H121','Tfinal']},
             'present_unchanged_in_B':entry(p,'B')==entry(p,'H121'),'present_unchanged_in_T97':entry(p,'T97')==entry(p,'H121')}
        good=(oid==spec['git_blob'] and row['actual_sha256']==spec['sha256'] and actual_imports==spec['imports']
              and entry(p,'C121')==entry(p,'H121')==entry(p,'Tfinal'))
        check('registered_module_identity_'+module,good)
        check('registered_module_import_closure_'+module,all(x in modules or x=='Std' for x in actual_imports))
        rows.append(row)
    write('registered_source_identity.json',{'registry_path':registry_path,'registry_sha256':hashlib.sha256(registry_bytes).hexdigest(),'toolchain':registry['toolchain'],'modules':rows})
    shared=['proofs/verify_project__214bf7673efe116b.py','proofs/verify_project.py','proofs/replay_original_layout.py','.github/workflows/agent5-lean.yml']
    config=[]
    for p in shared:
        entries={k:entry(p,k) for k in ['B','T97','C121','H121','Tfinal']}
        unchanged=all(e==entries['H121'] and e is not None for e in entries.values())
        data=body(entries['H121']['oid'])
        config.append({'path':p,'entries':entries,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'unchanged':unchanged})
        check('shared_verifier_configuration_unchanged_'+p,unchanged)
    write('shared_verifier_identity.json',config)
    original_base=run(['git','merge-base','--all',intake['objects']['B'],intake['objects']['H97']],label='current_B_PR97_original_merge_base').stdout.decode().strip()
    from prepare_combination import tree as readtree
    tree['PR97_original_base']=readtree(original_base)
    pr97_delta=changed('PR97_original_base','H97')
    overlaps=[{'path':p,'same_entry':entry(p,'B')==d['after'],'B_entry':entry(p,'B'),'H97_entry':d['after']} for p,d in pr97_delta.items() if entry(p,'B') is not None and d['before'] is None]
    check('current_B_PR97_same_overlap',len(overlaps)==1 and all(o['same_entry'] for o in overlaps),overlaps)
    check('current_B_to_Tfinal_258_additions',len(changed('B','Tfinal'))==258 and all(d['before'] is None and d['after'] for d in changed('B','Tfinal').values()))
    movement=changed('C121','H121')
    write('source_base_movement.json',{'C121_to_H121':movement,'PR97_original_base':original_base,'PR97_additions_relative_original_base':len(pr97_delta),
          'PR97_same_overlap_already_in_B':overlaps,'PR121_added_paths_already_in_T97':[],
          'registered_modules_already_in_B':[r['module'] for r in rows if r['present_unchanged_in_B']],
          'registered_modules_already_in_T97':[r['module'] for r in rows if r['present_unchanged_in_T97']],
          'registered_modules_added_by_PR97':[r['module'] for r in rows if r['present_unchanged_in_T97'] and not r['present_unchanged_in_B']],
          'registered_modules_added_by_PR121':[r['module'] for r in rows if not r['present_unchanged_in_T97']]})
    before=json.loads((OUT/'shared_state_before.json').read_text())
    index=REPO/'.git/index'
    after={'shared_index_exists':index.exists(),'shared_index_sha256':hashlib.sha256(index.read_bytes()).hexdigest() if index.exists() else None}
    check('shared_index_unchanged',before==after,{'before':before,'after':after})
    records=[json.loads(line) for line in (OUT/'commands.jsonl').read_text().splitlines()]
    for label,argv in [('shared_checkout_before',['git','rev-parse','HEAD']),('shared_refs_before',['git','for-each-ref','--format=%(refname) %(objectname)'])]:
        prior=next(r['stdout'] for r in records if r.get('label')==label)
        current=run(argv,label=label.replace('before','after')).stdout.decode()
        check(label.replace('before','unchanged'),prior==current)
    write('preservation_checks.json',assertions)
    result={'status':'PASS' if all(r['pass'] for r in assertions) else 'FAIL','checks':len(assertions),'failed_checks':[r for r in assertions if not r['pass']],
            'source_head':intake['objects']['H121'],'prospective_tree':intake['objects']['Tfinal'],'base':intake['objects']['B'],
            'actual_post_PR97_main_verification':False,'Lean_execution':'NOT_RUN','mathematical_review':'NOT_RERUN',
            'source_or_task_mutation':False,'shared_index_or_checkout_or_ref_mutation':False,
            'PR121_delivery_owner':'Agent50/session4dce66859b6c','source_owner':'original Agent5','PR97_delivery_owner':'original Agent11/session UNKNOWN',
            'main_writer':'Agent31/session02893e4f368d, ACTIVE on PR104, no expiry or acknowledged transfer observed by parent',
            'scoped_counts':{'B_entries':len(tree['B']),'T97_entries':len(tree['T97']),'Tfinal_entries':len(tree['Tfinal']),'PR121_additions':len(delta),
                             'PR97_restoration_additions':len(restoration),'registered_modules':len(modules),'registered_modules_already_in_B':sum(r['present_unchanged_in_B'] for r in rows),
                             'registered_modules_already_in_T97':sum(r['present_unchanged_in_T97'] for r in rows)}}
    write('RESULT.json',result)
    print(json.dumps(result,indent=2))
    raise SystemExit(0 if result['status']=='PASS' else 1)
