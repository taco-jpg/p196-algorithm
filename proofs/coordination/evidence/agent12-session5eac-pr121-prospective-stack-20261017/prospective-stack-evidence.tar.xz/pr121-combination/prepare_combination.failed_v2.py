#!/usr/bin/env python3
"""Construct and retain only a prospective Git tree through a private index."""
import json
from intake import run, OUT, ENV

B='74a1c3922eb7af438fe40b23d2105ad07556e3f5'
H97='9e59a77ae4e13a84eedc25aff689339e0225ad90'
T97='d2a1012c90de25cfeeba1047a721380f10120daf'
H121='5c4d394f20b70547aa7cb8dd14091bcd391e424c'
C121='5b4238ebe95f5fb80512d1b1ad3dbe3b062279a3'

def textcmd(*args, **kwargs):
    return run(['git',*args],**kwargs).stdout.decode().strip()

def tree(oid):
    raw=run(['git','ls-tree','-rz','--full-tree',oid],label='full_tree_identity_'+oid).stdout
    entries={}
    for entry in raw.split(b'\0'):
        if not entry: continue
        metadata,path=entry.split(b'\t',1)
        mode,kind,blob=metadata.decode().split()
        entries[path.decode()]={'mode':mode,'type':kind,'oid':blob}
    return entries

if __name__=='__main__':
    bbase=textcmd('merge-base','--all',B,H121).splitlines()
    hbase=textcmd('merge-base','--all',H97,H121).splitlines()
    candidates=sorted(set(bbase+hbase))
    discarded={}
    for x in candidates:
        for y in candidates:
            if x==y: continue
            r=run(['git','merge-base','--is-ancestor',x,y],check=False,label='prospective_parent_merge_base_dominance')
            if r.returncode==0: discarded[x]=y
            elif r.returncode!=1: raise RuntimeError('Unexpected ancestry command failure')
    bases=[x for x in candidates if x not in discarded]
    assert len(bases)==1,bases
    mb=bases[0]
    idx=OUT/'prospective.index'
    assert not idx.exists(),'Preserve prior index; use a new explicit run directory for a rerun.'
    env=dict(ENV,GIT_INDEX_FILE=str(idx))
    run(['git','read-tree','-i','--no-sparse-checkout','-m',mb,T97,H121],env=env,label='private_index_three_way_prospective_stack_corrected_index_only')
    conflicts=run(['git','ls-files','--unmerged','-z'],env=env,label='private_index_conflict_check').stdout
    (OUT/'conflict_index.txt').write_bytes(conflicts)
    assert not conflicts,'Unresolved conflicts; do not write a tree.'
    final=run(['git','write-tree'],env=env,label='write_prospective_tree_only').stdout.decode().strip()
    objects={'B':B,'H97':H97,'T97':T97,'H121':H121,'C121':C121,'MB':mb,'Tfinal':final}
    trees={k:tree(v) for k,v in objects.items()}
    (OUT/'tree_entries.json').write_text(json.dumps(trees,sort_keys=True,separators=(',',':'))+'\n')
    report={'objects':objects,'commit_tree_ids':{},'method':'git read-tree -i --no-sparse-checkout -m MB T97 H121 using private GIT_INDEX_FILE; git ls-files --unmerged; git write-tree. No synthetic commit, reference, checkout, or shared index mutation.',
            'prospective_parent_commits':[B,H97],'B_H121_merge_bases':bbase,'H97_H121_merge_bases':hbase,'dominated_merge_bases':discarded,'selected_merge_base':mb,
            'private_index':str(idx),'conflict_index_empty':not conflicts}
    for k,v in objects.items(): report['commit_tree_ids'][k]=textcmd('rev-parse',v+'^{tree}')
    report['tree_entry_counts']={k:len(v) for k,v in trees.items()}
    (OUT/'combination_intake.json').write_text(json.dumps(report,indent=2)+'\n')
    registry=json.loads((OUT/'proofs__Agent5OrdinaryStreamPrefix.registry.json').read_text())
    paths=[item['path'] for item in registry['projects']['agent5-ordinary-stream-prefix']['modules'].values()]
    paths+=['proofs/Agent5OrdinaryStreamPrefix.registry.json','proofs/verify_project__214bf7673efe116b.py','proofs/verify_project.py','proofs/replay_original_layout.py','.github/workflows/agent5-lean.yml']
    restoration=[p for p in trees['H97'] if p not in trees['MB']]
    paths+=restoration
    missing=[]
    for p in sorted(set(paths)):
        oid=trees['Tfinal'][p]['oid']
        r=run(['git','cat-file','-t',oid],check=False,label='scoped_blob_availability_'+p)
        if r.returncode: missing.append(oid)
    (OUT/'missing_scoped_blobs.json').write_text(json.dumps(sorted(set(missing)),indent=2)+'\n')
    print(json.dumps(report,indent=2))
    print('Restoration entries:',len(restoration),'Missing scoped public blobs:',len(set(missing)))
