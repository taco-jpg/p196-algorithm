# PR121 prospective current-base stack preservation

## Conclusion and exact scope

**PASS: 50 data-only preservation and identity checks; zero findings.** The exact PR121 contribution can be combined with the already validated prospective PR97 tree at frozen main base `74a1c3922eb7af438fe40b23d2105ad07556e3f5` without changing any pre-existing entry. The resulting prospective tree is **`87705ac5efd322296c7daa6e7ed0965b05fb36db`**.

This is a prospective current-base combination and source/dependency identity check, **not actual post-PR97 main verification**, a new mathematical review, a Lean execution, a Ready transition, an ownership transfer, a retarget, or a merge. No source, existing task, shared checkout, shared index, or Git reference was modified. Only immutable public Git objects and the resulting unattached tree were added to the local object store. The initial and final shared checkout/ref snapshots and shared-index SHA256 agree.

PR121 delivery remains with **Agent50/session4dce66859b6c**. Original source ownership remains Agent5. PR97 restoration delivery remains original Agent11/session UNKNOWN. The parent's last ownership observation remains Agent31/session02893e4f368d, ACTIVE on PR104, without expiry or acknowledged transfer; this report does not refresh or claim that slot.

## Frozen objects and exact tree method

| Role | Git object | Tree |
|---|---|---|
| Current frozen main B | `74a1c3922eb7af438fe40b23d2105ad07556e3f5` | `ba552a911841c2f2654cb4481c92e559e42d2a9b` |
| Repaired PR97 H97 | `9e59a77ae4e13a84eedc25aff689339e0225ad90` | `8a85e50e466ff2f97d406871b6d355460dd11a82` |
| Already validated prospective PR97 T97 | Tree only; no commit invented | `d2a1012c90de25cfeeba1047a721380f10120daf` |
| PR121 H121 | `5c4d394f20b70547aa7cb8dd14091bcd391e424c` | `46c08acd3898bc1914539b7afb5ac2d07ecd8f27` |
| Original mathematical source C121 | `5b4238ebe95f5fb80512d1b1ad3dbe3b062279a3` | `07e60b3bb92b31474ccd5acfe278eb3706e5b0ff` |
| Relevant merge base MB | `5bbd70c486b3c274cfc9bf244cc92e551419d5d8` | `7af88e9442347f09f603eb13e21ff37e2a225bc5` |
| Prospective combined Tfinal | Tree only; no commit or parent metadata | `87705ac5efd322296c7daa6e7ed0965b05fb36db` |

T97 is supplied by the parent's validated PR97 combination. Its conceptual integration parents are B and H97; it is not misrepresented as a commit. The merge base between B and H121 is `4b4edf976b2c7a9ba1dad80636c0e21c66350325`; the merge base between H97 and H121 is `5bbd70c486b3c274cfc9bf244cc92e551419d5d8`. Git ancestry checks prove the former is an ancestor of the latter. Therefore the latter is the unique maximal common ancestor of H121 and the prospective B/H97 integration. This is the relevant base; the earlier three-argument probe in the intake log is not used as the prospective stack base.

The successful native Git construction was:

```sh
GIT_NO_LAZY_FETCH=1 git merge-tree --write-tree \
  --merge-base=5bbd70c486b3c274cfc9bf244cc92e551419d5d8 \
  d2a1012c90de25cfeeba1047a721380f10120daf \
  5c4d394f20b70547aa7cb8dd14091bcd391e424c
```

Git accepted the first input as a tree. It exited **0**, emitted exactly `87705ac5efd322296c7daa6e7ed0965b05fb36db` and a newline, and emitted no stderr, conflict entries, or conflict messages. No synthetic author identity or commit was required. Both the successful probe and the scripted reproduction returned the same tree.

## Preservation results

| Obligation | Result |
|---|---|
| Every B entry survives with identical path, mode, object type and Git object ID | 22,212 / 22,212 |
| Every T97 entry survives unchanged | 22,378 / 22,378 |
| Every H97 entry survives unchanged | 13,878 / 13,878 |
| Every H121 entry survives unchanged | 13,953 / 13,953 |
| H121 relative to MB | Exactly 92 additions; zero modifications or deletions |
| Tfinal relative to T97 | Exactly the same 92 additions; no extras or deletions |
| H97 relative to MB | Exactly 17 restoration additions |
| Restoration additions retained in T97 and Tfinal | 17 / 17, with byte length, Git blob and SHA256 recorded |
| Tfinal relative to B | Exactly 258 additions; zero modifications or deletions |
| Final entry count | 22,470 |

The complete 92-file PR121 delta was read as public immutable blob content and SHA256-hashed. `pr121_delta_identity.json` records every path, mode, type, Git blob, byte length, SHA256 and equality with Tfinal. `pr97_restoration_identity.json` records the corresponding identities for all 17 restoration additions. Whole-tree preservation is checked through Git's content-addressed entry identities, without retrieving or recompiling unrelated historical content.

PR97 has 167 additions relative to its original merge base. Exactly one is already present on B: `proofs/contributions/agent-6/exterior-coordinate-dynamics-20261016/CoordinateThreshold.lean`, Git blob `34ddc74962d8bbef954f1626a80593de60906215`. Its mode/type/blob are identical. Thus PR97 adds 166 paths to B, and PR121 adds another 92. No PR121 addition already exists in T97. This explains why the current combined increment is 258, rather than mechanically applying the earlier historical 150 + 92 count or losing the later 17 restorations.

## Active registry and dependency identity

The path was obtained from H121's actual tree and public documentation: `proofs/Agent5OrdinaryStreamPrefix.registry.json`. Its SHA256 is `e866196ef123c8c79232fa2d0aba72d5662bcd06faaadd2295c55d17ae9e3061`. The registry entry itself is identical in C121, H121 and Tfinal.

All **15 registered module bodies** were read and checked against both the registry's Git blob and SHA256. Imports were parsed after masking nested Lean comments, line comments and strings, and compared with the registry. Every local import is within the registered closure; the only external import is `Std`. The path/mode/type/blob identity of every registered module is unchanged across C121, H121 and Tfinal. The full module-by-module mapping, SHA256 values, imports and tree entries are in `registered_source_identity.json`.

| Dependency location | Exact modules |
|---|---|
| Eight already unchanged in B | OuterFinite; TARGET; ExteriorFactorizationProof; CoordinateThreshold; ExteriorCore; ExteriorBridge; ExteriorProjection; ExteriorArithmetic |
| Five added by PR97 and already unchanged in T97 | DigitDefinitions; AdicDigits; FractionDigits; CoordinateStreams; CoordinateOnlyStreams |
| Two added by PR121 | RawPrefixStreams; OrdinaryStreamStep |

All 13 inherited dependencies are already present unchanged in T97. The 15-module closure therefore has exactly the reviewed source identity on the prospective result, including the ordinary-arithmetic branch of the closure.

## Verifier and source movement

The actual documented canonical command selects `proofs/verify_project__214bf7673efe116b.py` with the scoped registry and project `agent5-ordinary-stream-prefix`. The canonical verifier, the `proofs/verify_project.py` wrapper, `proofs/replay_original_layout.py`, and the existing `.github/workflows/agent5-lean.yml` all have identical mode/type/blob entries in **B, T97, C121, H121 and Tfinal**. Their bytes, SHA256 values and entries are retained in `shared_verifier_identity.json`. The workflow identity comparison is not a claim that this legacy workflow executes PR121's registry-selected build.

The registry still pins Lean version `4.19.0`, commit `6caaee842e94`, and allowed theorem axioms `propext`, `Classical.choice`, and `Quot.sound`. This check establishes unchanged verifier/configuration inputs; it does not assert that a fresh runtime was executed.

C121 to H121 contains 19 evidence additions and three modified metadata/documentation entries: the package Markdown, its top-level verification receipt, and PUBLICATION.json. None of the 15 active source modules or the active registry changes. All 22 movement entries are retained in `source_base_movement.json`. No new gap in the already reviewed source/manifest binding was found within this combination scope, so the 601-condition Agent50 review and historical Lean builds were not repeated.

Existing mathematical/evidence reviews are references for the parent's applicability decision, not new proof executions by this subtask:

- [Separate nonauthor source review5554315948](https://github.com/taco-jpg/p196-algorithm/pull/121#pullrequestreview-5554315948).
- [Agent50 source/evidence review5554926947](https://github.com/taco-jpg/p196-algorithm/pull/121#pullrequestreview-5554926947).
- [Agent50 retained review packet](https://github.com/taco-jpg/p196-algorithm/tree/1235be0b48b0c59ab1f3b3fe915f3a184303185a/proofs/coordination/reviews/agent50-session4dce/pr121).
- [Parent PR97 result](https://github.com/taco-jpg/p196-algorithm/pull/97#issuecomment-6230250563) and [writer packet](https://github.com/taco-jpg/p196-algorithm/issues/61#issuecomment-6230250701), as supplied in this assignment.

## Preserved failures and corrections

All commands, exact arguments, stdout, stderr and captured exit codes are retained in `commands.jsonl`. No failure was silently replaced with a successful result.

1. The initial H121 `cat-file` probe encountered a failed automatic promisor fetch because the ordinary network proxy was unavailable. Its nested exit was not separately captured; that limitation is recorded explicitly. Subsequent reads used `GIT_NO_LAZY_FETCH=1`.
2. An explicit ordinary-network immutable H121 fetch exited 128. The approved escalated fetch of that exact public commit exited 0. It used `--no-write-fetch-head --no-tags --no-recurse-submodules` and did not change refs.
3. Five missing public registry/provenance blobs were fetched by exact ID after the corresponding failed reads; the fetch exited 0.
4. Initial private-index `read-tree -m` exited 128 on a missing promisor README blob. Adding `-i --no-sparse-checkout` was insufficient and also failed. The original scripts, failed command records and initial mistaken sparse-checkout hypothesis are retained; no private index was created.
5. A bounded fetch of the PR121 delta/registered closure retrieved most requested blobs but exited 1 with six objects still absent. A second fetch of only those six IDs using `--refetch --no-filter` and negotiation disabled exited 0. Every correction remained limited to known public immutable objects.
6. `read-tree` then demanded another unrelated inherited blob, `calculation/196-Engine-Fixed.html`. That body was not fetched for this task. The construction was changed to the native explicit-base `merge-tree` command above, which needed no unrelated blob and returned the conflict-free prospective result.
7. The final data-only `verify_combination.py` execution exited 0, with 50 passed checks and empty stderr. No source conflict or source repair was required.

These are local Git transport/index-construction failures, not Lean failures or defects in the PR121 source. No blocked Agent26 archive was accessed, uploaded, repackaged or relied upon.

## Delivery boundary and next action

The missing prospective preservation obligation is now satisfied for the exact frozen inputs above. The parent handles full public evidence applicability, platform conditions, publication and the Agent50 handoff. Actual PR97 integration still has to occur. Agent50 or an acknowledged delegate must then read back the real resulting main commit/tree, compare it with T97 or revalidate affected changes, inspect the complete actual PR121 retargeted diff, perform the warranted retarget through the established ownership protocol, and refresh required platform checks and the authorized main writer before any guarded merge.

A prospective tree and a sent handoff are not actual integration or accepted ownership. This packet changes no task status and performs no remote mutation.

## Retained evidence and publication selection

`RESULT.json` is the compact machine result. `preservation_checks.json` contains all 50 assertions. `combination_intake.json` binds the objects, conceptual parents, ancestry and exact tree method. The identity inventories give exact paths and hashes. The three executable scripts and two failed construction versions preserve the procedure.

`PUBLISH_MANIFEST.json` names the suggested compact publication set and hashes every local evidence file. Large raw full-tree maps and command transcripts remain retained locally with exact SHA256 references; `command_summary.json` preserves each command, exit and complete non-tree output while replacing only large full-tree listings with their exact output length and digest. This avoids requiring a repository-wide historical content copy in a scoped support packet. The parent may publish the selected evidence through Agent12's established scoped path, retaining Agent50's delivery ownership.
