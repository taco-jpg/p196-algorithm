#!/usr/bin/env python3
"""Record bounded, read-only PR121 prospective combination intake."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

OUT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/5eac7b9c26af/agent12-integration')
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1')
LOG = OUT / 'commands.jsonl'

def run(args, *, cwd=REPO, env=ENV, label=None, check=True):
    result = subprocess.run(args, cwd=cwd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    record = {'time_utc': time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime()),
              'label': label, 'cwd': str(cwd), 'argv': args,
              'environment_overrides': {key: env[key] for key in ['GIT_NO_LAZY_FETCH','GIT_INDEX_FILE'] if key in env},
              'exit_code': result.returncode,
              'stdout': result.stdout.decode(errors='replace'),
              'stderr': result.stderr.decode(errors='replace')}
    with LOG.open('a') as file:
        file.write(json.dumps(record, ensure_ascii=False) + '\n')
    if check and result.returncode:
        raise RuntimeError(f'{args}: exit {result.returncode}; see {LOG}')
    return result

if __name__ == '__main__':
    if not LOG.exists():
        LOG.write_text(json.dumps({'label':'initial_probe_before_logging', 'cwd':str(REPO),
          'argv':['bash','-lc',"pwd; git rev-parse --git-dir; git cat-file -t 5c4d394f20b70547aa7cb8dd14091bcd391e424c; rg --files -g '*121*' -g '*97*' /workspace/scratch/5eac7b9c26af/agent12-evidence | head -100"],
          'shell_exit_code':0, 'cat_file_exit_code':'not separately captured',
          'stdout':str(REPO)+'\n.git\n',
          'stderr':"fatal: unable to access 'https://github.com/taco-jpg/p196-algorithm.git/': Failed to connect to browser-proxy port 8889 after 0 ms: Couldn't connect to server\nfatal: git cat-file: could not get object info\n",
          'finding':'H121 absent locally; promisor lazy fetch attempted and network failed. Further read-only Git commands disable lazy fetch.'})+'\n')
    run(['git','rev-parse','HEAD'],label='shared_checkout_before')
    run(['git','for-each-ref','--format=%(refname) %(objectname)'],label='shared_refs_before')
    index = REPO / '.git/index'
    state = {'shared_index_exists':index.exists(), 'shared_index_sha256':hashlib.sha256(index.read_bytes()).hexdigest() if index.exists() else None}
    (OUT/'shared_state_before.json').write_text(json.dumps(state,indent=2)+'\n')
    run(['git','config','--get','remote.origin.url'])
    run(['git','config','--get','remote.origin.partialclonefilter'],check=False)
    for oid in ['74a1c3922eb7af438fe40b23d2105ad07556e3f5','9e59a77ae4e13a84eedc25aff689339e0225ad90','d2a1012c90de25cfeeba1047a721380f10120daf','5c4d394f20b70547aa7cb8dd14091bcd391e424c']:
        result=run(['git','cat-file','-t',oid],check=False)
        print(oid,result.returncode,result.stdout.decode().strip(),result.stderr.decode().strip())
