#!/usr/bin/env python3
"""Package exact public inputs and parent assessment; never execute project code."""
import base64
import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent.parent / 'agent12-publication' / 'pr121'
OUT.mkdir(parents=True, exist_ok=True)
members = []
archive = OUT / 'parent-support-evidence.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6, format=tarfile.PAX_FORMAT) as tf:
    for path in sorted(ROOT.rglob('*')):
        if not path.is_file() or '__pycache__' in path.parts:
            continue
        data = path.read_bytes()
        name = path.relative_to(ROOT).as_posix()
        item = tarfile.TarInfo('parent-support/' + name)
        item.size = len(data)
        item.mode = 0o644
        item.mtime = 0
        item.uid = item.gid = 0
        item.uname = item.gname = ''
        tf.addfile(item, io.BytesIO(data))
        members.append({'path': name, 'archive_member': item.name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
with tarfile.open(archive, 'r:xz') as tf:
    actual = tf.getmembers()
    assert [m.name for m in actual] == [m['archive_member'] for m in members]
    for member, expected in zip(actual, members):
        assert member.isfile()
        data = tf.extractfile(member).read()
        assert len(data) == expected['bytes']
        assert hashlib.sha256(data).hexdigest() == expected['sha256']
manifest = {'scope': 'Complete parent PR121 public inputs and assessment', 'source': 'Public GitHub reads and own integration support only', 'files': members,
            'original_files': len(members), 'original_bytes': sum(m['bytes'] for m in members), 'excluded': ['__pycache__ if present; reproducible Python cache only'],
            'archive': {'path': archive.name, 'bytes': archive.stat().st_size, 'sha256': hashlib.sha256(archive.read_bytes()).hexdigest()},
            'verification': 'All archive members read, size and SHA256 compared once; PASS',
            'recovery': 'python -m tarfile -e parent-support-evidence.tar.xz recovered-parent-support',
            'copy_correction': 'Four initial local formatting copies were replaced with the exact UTF-8 connector-returned public source/report strings before final packaging. No project source changed.'}
(OUT / 'parent-support-evidence.files.json').write_text(json.dumps(manifest, indent=2) + '\n')
text_paths = {
    'INTEGRATION_PACKET.md': ROOT / 'INTEGRATION_PACKET.md',
    'REVIEW_REUSE.md': ROOT / 'REVIEW_REUSE.md',
    'PACKAGING_RECEIPT.md': OUT / 'PACKAGING_RECEIPT.md',
    'prospective-stack-evidence.files.json': OUT / 'prospective-stack-evidence.files.json',
    'prospective-stack-evidence.verification.json': OUT / 'prospective-stack-evidence.verification.json',
    'parent-support-evidence.files.json': OUT / 'parent-support-evidence.files.json',
    'package_complete_evidence.py': OUT / 'package_complete_evidence.py',
}
payload = {'text_files': {name: path.read_text() for name, path in text_paths.items()}, 'binary_files': {}}
published = []
for name, path in text_paths.items():
    data = path.read_bytes()
    published.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'kind': 'utf-8 text'})
for name in ['prospective-stack-evidence.tar.xz', 'parent-support-evidence.tar.xz']:
    path = OUT / name
    data = path.read_bytes()
    payload['binary_files'][name] = base64.b64encode(data).decode('ascii')
    published.append({'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(), 'kind': 'lossless xz-compressed tar'})
publication = {'schema_version': 1, 'agent': 'Agent12/session5eac7b9c26af', 'scope': 'PR121 prospective support',
               'prefix': 'proofs/coordination/evidence/agent12-session5eac-pr121-prospective-stack-20261017/',
               'files': published, 'verification': 'Local archive round-trip PASS; remote readback and own-path commit delta to be verified after publication.',
               'separate_blocked_Agent26_archive_accessed': False}
publication_text = json.dumps(publication, indent=2) + '\n'
(OUT / 'PUBLICATION_MANIFEST.json').write_text(publication_text)
payload['text_files']['PUBLICATION_MANIFEST.json'] = publication_text
transport = json.dumps(payload, ensure_ascii=True, separators=(',', ':'))
(OUT / 'publication_transport.json').write_text(transport)
metadata = {'transport_characters': len(transport), 'text_files': len(payload['text_files']), 'binary_files': len(payload['binary_files']), 'parent_manifest': manifest, 'publication_files': published}
(OUT / 'transport_metadata.json').write_text(json.dumps(metadata, indent=2) + '\n')
print(json.dumps({'transport_characters': len(transport), 'text_files': len(payload['text_files']), 'binary_files': len(payload['binary_files']), 'parent_archive': manifest['archive'], 'parent_original_files': len(members)}))
