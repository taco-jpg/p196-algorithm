#!/usr/bin/env python3
"""Revalidate retained PR145 bytes/log coverage; never executes Lean or retained code."""
import hashlib, io, json, pathlib, re, tarfile
ROOT = pathlib.Path(__file__).resolve().parent
SRC = ROOT / 'source-e8d706dc'
HEAD = 'e8d706dc8a67248e1531b0b828fbe05ff50052ed'
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}
MODULES = ['SpectralWeights', 'BinaryCode', 'ChargeSymmetry', 'SourceFormula', 'ChargeControls']
FLAGS = ['--trust=0', '-j1', '-DElab.async=false']

def sha(b):
    return hashlib.sha256(b).hexdigest()

def json_bytes(b):
    return json.loads(b.decode())

def axioms(b):
    rows = []
    pattern = r"'([^']+)' (does not depend on any axioms|depends on axioms:\s*\[([^\]]*)\])"
    for match in re.finditer(pattern, b.decode(), re.S):
        vals = [] if match[2].startswith('does not') else [v.strip() for v in match[3].split(',') if v.strip()]
        assert set(vals) <= ALLOWED, (match[1], vals)
        rows.append({'name': match[1], 'axioms': vals})
    assert len({x['name'] for x in rows}) == len(rows)
    return rows

manifest = json.loads((SRC / 'evidence/development-evidence-manifest.json').read_text())
blob = (SRC / 'evidence/development-evidence.tar.gz').read_bytes()
assert len(blob) == manifest['archive']['bytes'] == 1476920
assert sha(blob) == manifest['archive']['sha256'] == '9c041aff895f9fda757d1c9a9894f91eb25cbad743401b1bf8c6ede26c0e6859'
assert hashlib.sha1(b'blob ' + str(len(blob)).encode() + bytes([0]) + blob).hexdigest() == 'df4e4050cfdb17d2bc9409c00aa4ff3b065b9f9a'
expected = {x['path']: x for x in manifest['files']}
assert len(expected) == len(manifest['files']) == 342
contents = {}
with tarfile.open(fileobj=io.BytesIO(blob), mode='r:gz') as archive:
    for member in archive:
        p = pathlib.PurePosixPath(member.name)
        assert not p.is_absolute() and '..' not in p.parts
        assert not member.issym() and not member.islnk()
        if member.isdir():
            continue
        assert member.isfile() and member.name not in contents and member.name in expected
        b = archive.extractfile(member).read()
        pin = expected[member.name]
        assert len(b) == pin['bytes'] and sha(b) == pin['sha256'], member.name
        contents[member.name] = b
assert set(contents) == set(expected)
assert all(x['path'].endswith(('.olean', '.ilean', '.olean.tmp')) for x in manifest['omitted_regenerable_objects'])

build = json.loads((SRC / 'BUILD.json').read_text())
source_pins = json.loads((SRC / 'evidence/author-source-pins.json').read_text())
receipt = json.loads((SRC / 'evidence/author-verification.json').read_text())
assert build['modules'] == receipt['modules'] == MODULES
assert build['source_pins'] == receipt['source_pins'] == source_pins
imports = {}
exports = []
for module in MODULES:
    b = (SRC / (module + '.lean')).read_bytes()
    assert {'sha256': sha(b), 'bytes': len(b)} == source_pins[module]
    assert contents['author-attempts/memory/attempt-006/source/' + module + '.lean'] == b
    imports[module] = re.findall(r'^import\s+(\S+)', b.decode(), re.M)
    assert set(imports[module]) <= set(MODULES) | {'Std'}
    for kind, name in re.findall(r"^(?:@\[[^\n]*\]\s*)?(def|theorem)\s+([A-Za-z0-9_']+)", b.decode(), re.M):
        exports.append({'kind': kind, 'name': 'P196.Agent15.SpectralCarry.' + name})
assert len(exports) == 69
assert exports == receipt['public_exports'] == json.loads((SRC / 'evidence/author-exports.json').read_text())
prefix = 'author-attempts/memory/attempt-006/'
for local, remote in [('author-verification.json', 'verification.json'), ('author-source-pins.json', 'source-pins.json'), ('author-exports.json', 'exports.json'), ('author-public-axioms.json', 'public-axioms.json')]:
    assert (SRC / 'evidence' / local).read_bytes() == contents[prefix + remote]
rows = axioms(contents[prefix + 'logs/PublicAudit.log'])
assert rows == json.loads((SRC / 'evidence/author-public-axioms.json').read_text())
assert {r['name'] for r in rows} == {r['name'] for r in exports}
audit_source = contents[prefix + 'source/PublicAudit.lean'].decode()
assert len(re.findall(r'^#print axioms ', audit_source, re.M)) == 69
assert len(re.findall(r'^#print (?!axioms )', audit_source, re.M)) == 69
assert receipt['status'] == 'PASS' and receipt['source_unchanged']
assert [x['name'] for x in receipt['commands']] == ['lean-version'] + MODULES + ['PublicAudit']
assert all(x['exit_code'] == 0 for x in receipt['commands'])

attempts = []
for path in sorted(contents):
    if not re.fullmatch(r'author-attempts/(memory|overlay)/attempt-\d+/verification.json', path):
        continue
    d = json_bytes(contents[path]); base = path.rsplit('/', 1)[0] + '/'
    for module, pin in d['source_pins'].items():
        b = contents[base + 'source/' + module + '.lean']
        assert {'sha256': sha(b), 'bytes': len(b)} == pin
    records = []
    for cmd in d['commands']:
        log = contents[base + 'logs/' + cmd['name'] + '.log']
        if cmd['name'] != 'lean-version':
            assert all(f in cmd['argv'] for f in FLAGS)
        else:
            assert b'version 4.19.0' in log and b'6caaee842e94' in log
        assert cmd['cwd'] == cmd['LEAN_PATH']
        if cmd['exit_code']:
            assert b'error:' in log
        records.append({'name': cmd['name'], 'exit_code': cmd['exit_code'], 'log_bytes': len(log), 'log_sha256': sha(log)})
    if d['status'] == 'PASS':
        assert all(c['exit_code'] == 0 for c in d['commands'])
        parsed = axioms(contents[base + 'logs/PublicAudit.log'])
        assert parsed == json_bytes(contents[base + 'public-axioms.json'])
        assert {r['name'] for r in parsed} == {r['name'] for r in d['public_exports']}
    else:
        assert any(c['exit_code'] != 0 for c in d['commands'])
    attempts.append({'path': path, 'status': d['status'], 'modules': d['modules'], 'commands': records})
assert len(attempts) == 6

weights = SRC / 'development/weights'
wmanifest = json.loads((weights / 'MANIFEST.json').read_text())
assert wmanifest['source_sha256'] == source_pins['SpectralWeights']['sha256']
for attempt in ['attempt-001', 'attempt-002']:
    p = weights / attempt
    d = json.loads((p / 'attempt.json').read_text())
    assert (p / 'build.log').exists()
waudit = json.loads((weights / 'audit-001/audit.json').read_text())
assert all(x['exit_code'] == 0 and all(f in x['command'] for f in FLAGS) for x in waudit['runs'])
assert len(axioms((weights / 'audit-001/WeightsExports.log').read_bytes())) == 29
assert (weights / 'audit-001/SpectralWeights.lean').read_bytes() == (SRC / 'SpectralWeights.lean').read_bytes()

result = {'status': 'PASS_RETAINED_AUTHOR_EVIDENCE', 'source_head': HEAD, 'archive_files': len(contents), 'uncompressed_file_bytes': sum(map(len, contents.values())), 'archive_sha256': sha(blob), 'manifest_sha256': sha((SRC / 'evidence/development-evidence-manifest.json').read_bytes()), 'omitted_regenerable_objects': len(manifest['omitted_regenerable_objects']), 'source_pins': source_pins, 'imports': imports, 'public_exports': len(exports), 'public_axiom_results': len(rows), 'axioms_seen': sorted({a for r in rows for a in r['axioms']}), 'compiler': receipt['compiler'], 'attempts': attempts, 'weights_public_axiom_results': 29, 'new_lean_execution': False, 'independent_origin_audit': 'PENDING separate published evidence at this pinned checkpoint'}
(ROOT / 'author-evidence-validation.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
