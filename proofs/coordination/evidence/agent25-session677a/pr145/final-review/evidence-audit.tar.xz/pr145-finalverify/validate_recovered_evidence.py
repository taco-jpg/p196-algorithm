#!/usr/bin/env python3
"""Independently validate preserved PR145 evidence without executing retained code.

Only Python standard-library data parsing and hashing are used. No compiler,
subprocess, network request, imported retained script, or archive extraction occurs.
The only output is this directory's validation-result.json.
"""
from pathlib import Path, PurePosixPath
import argparse
import ast
import collections
import csv
import hashlib
import io
import json
import re
import tarfile
import traceback

ROOT = Path(__file__).resolve().parent
R = ROOT / 'originals/runtime-review'
S = ROOT / 'originals/semantic-review'
A = R / 'frozen-e8d706dc-attempt-001'
H = 'e8d706dc8a67248e1531b0b828fbe05ff50052ed'
TREE = '2d447634e0ff42b4275d34bfb169101bba0ed130'
MODULES = ['SpectralWeights', 'BinaryCode', 'ChargeSymmetry', 'SourceFormula', 'ChargeControls']
PINS = {
    'SpectralWeights': (4445, '07b3831f17a0d2e43a7e27cfd8a63d364a98ccbbcef87362a20cfbf24fb49db1', '40afa93196976972e5c0f6772a18e50c1e635a3f'),
    'BinaryCode': (2655, '8db88d52e00dddbd32610dc09b7f8833f1ec1dc623b82236060b67bd2c9171f9', '35ba9bee5afb9bb47f39738e44860a02ea9b2469'),
    'ChargeSymmetry': (3240, '28d11217cf147750ec2d07e64dbc6dabeee7deec7e543987817da611201b60a3', 'f69efd4bc0642759dddf99834d5d093c929761a5'),
    'SourceFormula': (5059, 'be165a538963922f6096e63934e5f3c1010d760cabc9e08baa96a0bb43c105d8', '1db4a109629abddf355d12e8a14f2cfb0e26a39b'),
    'ChargeControls': (1104, 'bb23522ad6792dcf6b30ef010837eb1703f7eba59f4448e355282f8eb27f668c', 'b7a1c9f7d0d175fb3f2abea93fcd23bd5eb082f8'),
}
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}
PREFIX = 'P196.Agent15.SpectralCarry.'
ORIGINAL_RUN = '/dev/shm/p196-agent15-43cf6e114472/runtime-review/frozen-e8d706dc-attempt-001'
LEAN = '/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean'
FLAGS = ['-j1', '-DElab.async=false', '--trust=0']
RESULT = {'source_head': H, 'validator': 'Agent #25 / pr145_finalverify',
          'mode': 'retained evidence validation; no new Lean execution', 'checks': []}


def require(value, message):
    if not value:
        raise AssertionError(message)


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(('blob %d\0' % len(data)).encode() + data).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def safe_relative(name):
    p = PurePosixPath(name)
    require(not p.is_absolute() and '..' not in p.parts and str(p) == name and bool(p.parts), 'Unsafe or noncanonical path: ' + name)
    return p


def check_bytes(data, record, label):
    require(len(data) == record['bytes'], label + ': byte length')
    require(sha(data) == record['sha256'], label + ': SHA256')
    if 'git_blob' in record:
        require(blob(data) == record['git_blob'], label + ': Git blob')


def check_file(path, record):
    require(path.is_file() and not path.is_symlink(), 'Missing or linked file: ' + str(path))
    check_bytes(path.read_bytes(), record, str(path))


def check_map(base, mapping, exact=False, excluded=()):
    for name, record in mapping.items():
        safe_relative(name)
        check_file(base / name, record)
    if exact:
        actual = {str(p.relative_to(base)) for p in base.rglob('*') if p.is_file() and not any(str(p.relative_to(base)) == e or str(p.relative_to(base)).startswith(e + '/') for e in excluded)}
        require(actual == set(mapping), 'Manifest file set: ' + str(base))


def passed(name, **data):
    RESULT['checks'].append({'check': name, 'status': 'PASS', **data})


def mask_lean(source):
    """Remove nested comments and strings while retaining line structure."""
    out = list(source)
    i = depth = 0
    quoted = False
    while i < len(source):
        pair = source[i:i+2]
        if depth:
            if pair == '/-':
                depth += 1; out[i:i+2] = '  '; i += 2; continue
            if pair == '-/':
                depth -= 1; out[i:i+2] = '  '; i += 2; continue
            if source[i] != '\n': out[i] = ' '
        elif quoted:
            if source[i] == '\\' and i + 1 < len(source):
                out[i:i+2] = '  '; i += 2; continue
            if source[i] == '"': quoted = False
            if source[i] != '\n': out[i] = ' '
        elif pair == '/-':
            depth = 1; out[i:i+2] = '  '; i += 2; continue
        elif pair == '--':
            j = source.find('\n', i)
            if j < 0: j = len(source)
            out[i:j] = ' ' * (j - i); i = j; continue
        elif source[i] == '"':
            quoted = True; out[i] = ' '
        i += 1
    require(not depth and not quoted, 'Unterminated Lean comment/string')
    return ''.join(out)


def parse_axiom_line(line):
    m = re.fullmatch(r"'([^']+)' (does not depend on any axioms|depends on axioms: \[([^\]]*)\])", line)
    require(m is not None, 'Malformed printed axiom line: ' + line[:160])
    axioms = [] if m[2] == 'does not depend on any axioms' else [x.strip() for x in m[3].split(',') if x.strip()]
    require(len(axioms) == len(set(axioms)), 'Duplicate axiom')
    require(set(axioms) <= ALLOWED, 'Disallowed printed axiom: ' + line)
    return m[1], axioms


def parse_origin_log(path):
    """Consume the complete log, not a summary or a selection of names."""
    lines = path.read_text().splitlines()
    records, signatures, printed = [], {}, {}
    i = 0
    while i < len(lines) and lines[i].startswith('AUDIT_DECL_JSON '):
        record = json.loads(lines[i][len('AUDIT_DECL_JSON '):]); i += 1
        name = record['name']
        require(name not in signatures, 'Duplicate origin declaration ' + name)
        require(lines[i] == 'SIGNATURE_BEGIN ' + name, 'Missing signature start ' + name); i += 1
        start = i
        while i < len(lines) and lines[i] != 'SIGNATURE_END ' + name:
            i += 1
        require(i < len(lines), 'Missing signature end ' + name)
        signature = '\n'.join(lines[start:i]); i += 1
        require(signature.startswith(name + ' : '), 'Signature name mismatch ' + name)
        axiom_text = lines[i]; i += 1
        if 'depends on axioms: [' in axiom_text:
            while not axiom_text.endswith(']'):
                require(i < len(lines) and lines[i].startswith(' '), 'Invalid wrapped axiom continuation')
                axiom_text += ' ' + lines[i].strip(); i += 1
        printed_name, axioms = parse_axiom_line(axiom_text)
        require(printed_name == name and axioms == record['axioms'], 'Axiom record mismatch ' + name)
        signatures[name] = signature
        printed[name] = axioms
        records.append(record)
    require(i == len(lines) - 1 and lines[i].startswith('AUDIT_SUMMARY_JSON '), 'Unparsed origin-log content')
    summary = json.loads(lines[i][len('AUDIT_SUMMARY_JSON '):])
    require(summary['count'] == len(records), 'Origin summary count')
    return records, signatures, printed, summary


def main(check_originals):
    snapshot = read_json(ROOT / 'snapshot-manifest.json')
    for item in snapshot['files']:
        safe_relative(item['copy'])
        check_file(ROOT / item['copy'], item)
        if check_originals:
            require((ROOT / item['copy']).read_bytes() == Path(item['source']).read_bytes(), 'Original changed since snapshot: ' + item['source'])
    require(len(snapshot['files']) == 183 and sum(i['bytes'] for i in snapshot['files']) == 3270741, 'Snapshot corpus totals')
    passed('preinspection_snapshot', files=183, bytes=3270741, originals_rechecked=check_originals, snapshot_manifest_sha256=sha((ROOT/'snapshot-manifest.json').read_bytes()))

    manifest = read_json(R / 'review-manifest.json')
    envelope = read_json(R / 'delivery/package-manifest.json')
    require(manifest['source_commit'] == envelope['source_commit'] == H and manifest['source_tree'] == envelope['source_tree'] == TREE, 'Archive source identity')
    check_map(R, manifest['files'], exact=True, excluded=('review-manifest.json', 'delivery'))
    require(manifest['file_count'] == len(manifest['files']) == 135, 'Runtime manifest count')
    require(manifest['total_file_bytes'] == sum(v['bytes'] for v in manifest['files'].values()) == 2408082, 'Runtime manifest total')
    require(sha((R/'review-manifest.json').read_bytes()) == envelope['review_manifest_sha256'] == '31c1859d570ef3f86ac92e29405404304aa73f030e6165f4dce8fa8f70413e1b', 'Original manifest identity')
    for name, field in [('FROZEN_REVIEW.md','review_report_sha256'),('review-summary.json','review_summary_sha256')]:
        require(sha((R/name).read_bytes()) == envelope[field], 'Envelope ' + field)
    archive = R / 'delivery' / envelope['archive']
    require(archive.stat().st_size == envelope['archive_bytes'] == 629387, 'Archive bytes')
    require(sha(archive.read_bytes()) == envelope['archive_sha256'] == 'b5d335c483e4b94ac573f4d00f047cc2cfa4303864469620cd1c20c8ead2b261', 'Archive hash')
    archived, all_names, total = set(), set(), 0
    with tarfile.open(archive, 'r:gz') as tf:
        for member in tf:
            safe_relative(member.name)
            require(member.name not in all_names, 'Duplicate tar member'); all_names.add(member.name)
            require(member.name == 'runtime-review' or member.name.startswith('runtime-review/'), 'Unexpected archive root')
            require(member.isdir() or member.isfile(), 'Link or special tar member')
            if member.isdir(): continue
            rel = member.name[len('runtime-review/'):]
            require(rel in manifest['files'] or rel == 'review-manifest.json', 'Unmanifested archive file ' + rel)
            data = tf.extractfile(member).read()
            require(len(data) == member.size and data == (R/rel).read_bytes(), 'Archive/original byte mismatch ' + rel)
            archived.add(rel); total += len(data)
    require(archived == set(manifest['files']) | {'review-manifest.json'}, 'Missing archived file')
    require(len(archived) == envelope['archive_file_count'] == 136 and total == envelope['archive_uncompressed_file_bytes'] == 2431703, 'Archive totals')
    passed('original_archive_and_complete_runtime_manifest', archive_bytes=629387, archive_sha256=envelope['archive_sha256'], regular_files=136, uncompressed_bytes=total, manifest_files=135)

    semantic_manifest = read_json(S/'FINAL_ARTIFACTS.json')
    require(semantic_manifest['source_commit'] == H, 'Semantic manifest head')
    semantic_map = {e['path']:e for e in semantic_manifest['artifacts']}
    require(len(semantic_map) == len(semantic_manifest['artifacts']) == 44, 'Semantic duplicate/count')
    check_map(S, semantic_map, exact=True, excluded=('FINAL_ARTIFACTS.json',))
    environment = read_json(R/'environment-history/copy-manifest.json')
    environment_map = {e['relative_path']: e for e in environment['copied']}
    check_map(R/'environment-history', environment_map, exact=True, excluded=('copy-manifest.json',))
    require(len(environment_map) == 50 and len(environment['omitted_generated_artifacts']) == 6, 'Environment preservation counts')
    for e in environment['omitted_generated_artifacts']:
        require(not (R/'environment-history'/e['relative_path']).exists(), 'Unexpected historical omitted artifact')
    freeze = read_json(R/'freeze-inputs-001/manifest.json')
    require(freeze['source_commit'] == H and freeze['source_tree'] == TREE, 'Preflight freeze identity')
    check_map(R/'freeze-inputs-001', freeze['snapshots'], exact=True, excluded=('manifest.json',))
    passed('semantic_and_environment_manifests', semantic_files=44, environment_files=50, explicitly_omitted_historical_objects=6, frozen_metadata_files=len(freeze['snapshots']))

    remote = read_json(S/'remote-freeze-e8d/MANIFEST.json')
    require(remote['commit'] == H and remote['tree'] == TREE and len(remote['files']) == remote['file_count'] == 11, 'Remote identity manifest')
    responses = {}
    for path in sorted((S/'remote-freeze-e8d').glob('fetch-batch-*.json')):
        batch = read_json(path)
        require(batch['commit'] == H and batch['tree'] == TREE, 'Remote batch head')
        for item in batch['entries']:
            require(item['name'] not in responses, 'Duplicate remote response')
            responses[item['name']] = item['response']['structuredContent']
    comparisons = [e for p in sorted((S/'remote-freeze-e8d').glob('comparison-batch-*.json')) for e in read_json(p)]
    require(sorted(comparisons,key=lambda e:e['name']) == sorted(remote['files'],key=lambda e:e['name']), 'Remote comparisons differ')
    require(set(responses) == {e['name'] for e in remote['files']}, 'Remote file set')
    git_receipt = read_json(S/'remote-freeze-e8d/git-object-inspection.json')
    require(git_receipt['exit_code'] == 0 and git_receipt['output'].startswith(H+'\n'+TREE+'\n'), 'Retained Git identity receipt')
    for entry in remote['files']:
        name = entry['name']; data = (S/'remote-freeze-e8d/files'/name).read_bytes(); response = responses[name]
        check_bytes(data, entry, name)
        require(response['encoding'] == 'utf-8' and response['content'].encode('utf-8') == data, 'Raw remote response bytes ' + name)
        require(response['sha'] == entry['api_sha'] == blob(data), 'API Git blob ' + name)
        require('/blob/'+H+'/' in response['display_url'], 'Remote response ref ' + name)
        require((S/'source-snapshot-004'/name).read_bytes() == data, 'Semantic reviewed snapshot ' + name)
        require(('blob '+blob(data)+'\t'+name+'\n') in git_receipt['output'], 'Retained Git tree blob ' + name)
    passed('eleven_remote_source_responses', files=11, raw_content_verified=True, prior_semantic_snapshot_verified=True, retained_git_tree_verified=True, fresh_network_access=False)

    verification = read_json(A/'verification.json')
    require(verification['source_commit'] == H and verification['status'] == 'PASS_CLEAN_BUILD_AND_ALL_DECLARATIONS', 'Gate status/head')
    require(verification['build_order'] == MODULES and verification['roots'] == ['ChargeControls'], 'Complete dependency closure')
    require(verification['project_objects_reused'] is False and verification['standard_toolchain_objects_reused'] is True, 'Freshness boundary')
    require(verification['semantic_acceptance'] == 'SEPARATE_REVIEW_REQUIRED', 'Mechanical semantic boundary')
    require(sha((R/'clean_review.py').read_bytes()) == verification['runner_sha256'] == '3c5beaea129575dd335bebf6f31994613c3f706cee13711a3aaf60bacaa768ef', 'Executed runner identity')
    check_map(A, verification['artifacts'], exact=True, excluded=('verification.json',))
    build_meta = read_json(R/'freeze-inputs-001/BUILD.json')
    author_pins = read_json(R/'freeze-inputs-001/evidence/author-source-pins.json')
    exports, private_explicit, by_module, kinds = [], [], {}, collections.Counter()
    source_results = []
    for i, module in enumerate(MODULES):
        data = (A/'source'/ (module+'.lean')).read_bytes(); n,digest,git = PINS[module]
        expected = {'bytes':n,'sha256':digest,'git_blob':git}
        check_bytes(data, expected, module)
        for path in [S/'remote-freeze-e8d/files'/(module+'.lean'), S/'source-snapshot-004'/(module+'.lean'), R/'preliminary-source-reading'/(module+'.lean')]:
            require(path.read_bytes() == data, 'Source snapshot mismatch ' + str(path))
        for record in [verification['source_records'][module], freeze['sources'][module], build_meta['source_pins'][module], author_pins[module]]:
            check_bytes(data, record, module)
        require(('blob '+git+'\t'+verification['source_records'][module]['repository_path']+'\n') in (A/'logs/source-tree.log').read_text(), 'Recorded committed source blob ' + module)
        code = mask_lean(data.decode())
        require(not re.search(r'\b(?:sorry|admit|sorryAx|axiom|native_decide|ofReduceBool|skipKernelTC|unsafe|partial)\b',code), 'Forbidden live source token ' + module)
        imports = re.findall(r'^import\s+(\w+)\s*$', code, re.M)
        require(imports == verification['source_records'][module]['imports'] == ['Std' if i == 0 else MODULES[i-1]], 'Import closure ' + module)
        require(re.findall(r'^namespace\s+([^\s]+)', code,re.M) == [PREFIX[:-1]], 'Unexpected source namespace')
        module_exports = []
        for private,kind,name in re.findall(r'^(?:@\[[^\]]+\]\s*)?(?:(private)\s+)?(def|theorem)\s+([A-Za-z_][A-Za-z_0-9]*)',code,re.M):
            if private:
                private_explicit.append((module,PREFIX+name)); continue
            exports.append(PREFIX+name); module_exports.append(PREFIX+name); kinds[kind] += 1
        by_module[module] = module_exports
        source_results.append({'module':module,**expected,'imports':imports})
    require(kinds == {'def':13,'theorem':56} and len(exports) == len(set(exports)) == 69 and len(private_explicit) == 2, 'Source declaration census')
    require(by_module == read_json(R/'expected-public-exports-by-module.json'), 'Per-module public exports')
    require(exports == (R/'expected-public-exports.txt').read_text().splitlines() == read_json(A/'expected-public-exports.json') == verification['expected_public_exports'], 'Expected public-export lists')
    require(exports == [e['name'] for e in read_json(R/'freeze-inputs-001/evidence/author-exports.json')], 'Author export identity')
    require(sha((R/'expected-public-exports.txt').read_bytes()) == verification['public_exports_source_sha256'], 'Export input hash')
    passed('exact_source_pins_and_dependency_closure', modules=source_results, public_definitions=13, public_theorems=56, private_source_theorems=2)

    invocation = read_json(R/'gate-invocation-001.json')
    require(invocation['exit_code'] == 0 and invocation['source_commit'] == H, 'Outer gate execution')
    require(invocation['started_at_epoch'] <= verification['started_at_epoch'] < verification['finished_at_epoch'] <= invocation['finished_at_epoch'], 'Execution time nesting')
    args = invocation['argv']
    require(args[1] == '/dev/shm/p196-agent15-43cf6e114472/runtime-review/clean_review.py', 'Outer runner')
    for flag,value in [('--source-commit',H),('--evidence',ORIGINAL_RUN),('--module','ChargeControls'),('--expected-public-export-count','69')]:
        require(args[args.index(flag)+1] == value, 'Invocation flag '+flag)
    require([args[i+1] for i,v in enumerate(args) if v=='--exact-module'] == MODULES, 'Invocation exact closure')
    labels = ['version','compiler-prefix','source-commit','source-tree'] + ['build-'+m for m in MODULES] + ['all-declarations','public-exports']
    require([c['label'] for c in verification['commands']] == labels, 'Command coverage/order')
    minimal_env = {'PATH':str(PurePosixPath(LEAN).parent)+':/usr/bin:/bin','LANG':'C.UTF-8','LEAN_PATH':ORIGINAL_RUN+'/source'}
    outer_lines = []
    for command in verification['commands']:
        label = command['label']; log = A/command['log']
        require(command['exit_code'] == 0 and command['elapsed_seconds'] >= 0, 'Command result '+label)
        require(sha(log.read_bytes()) == command['log_sha256'], 'Command log hash '+label)
        require(command['cwd'] == ORIGINAL_RUN+'/source', 'Command working directory '+label)
        if command['argv'][0] == LEAN:
            require(command['environment'] == minimal_env, 'Compiler environment '+label)
        if label.startswith('build-') or label in ['all-declarations','public-exports']:
            stem = label[6:] if label.startswith('build-') else {'all-declarations':'IndependentDeclarationAudit','public-exports':'IndependentPublicExports'}[label]
            require(command['argv'] == [LEAN,*FLAGS,'-o',stem+'.olean',stem+'.lean'], 'Exact compiler command '+label)
            require((A/'source'/(stem+'.olean')).stat().st_size > 0, 'Missing built object '+stem)
        if label.startswith('build-'):
            require(log.read_bytes() == b'', 'Unexpected target diagnostics')
        outer_lines.append(label+': exit 0; '+ORIGINAL_RUN+'/'+command['log'])
    require((R/'gate-invocation-001.log').read_text().splitlines() == outer_lines, 'Outer progress log')
    require((A/'logs/version.log').read_text().strip() == verification['compiler']['version'] == 'Lean (version 4.19.0, x86_64-unknown-linux-gnu, commit 6caaee842e94, Release)', 'Compiler version')
    require(verification['compiler']['files'][LEAN] == '92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023', 'Compiler pin')
    require((A/'logs/source-commit.log').read_text() == H+'\n', 'Source commit output')
    require(set(verification['standard_direct_imports']) == {'Std'} and verification['standard_direct_imports']['Std']['sha256'] == '7d3771da25b893da62564bf8198487ff28f01af5cbd410be88d493a4921b2bb1', 'Std identity')
    passed('retained_fresh_execution', outer_exit=0, commands=11, project_compilations=5, audit_compilations=2, all_command_exits_zero=True, flags=FLAGS, project_cache_reused=False, official_toolchain_objects_reused=True, artifact_files=len(verification['artifacts']))

    # Inspect the retained runner as syntax/data, never import or execute it.
    tree = ast.parse((R/'clean_review.py').read_text())
    templates = [n.value for n in ast.walk(tree) if isinstance(n,ast.Constant) and isinstance(n.value,str) and 'for (name, info) in env.constants.toList do' in n.value]
    require(len(templates)==1, 'Audit template ambiguity')
    required = list(dict.fromkeys(verification['required_declarations']+exports))
    expected_audit = 'import ChargeControls\nimport Lean\n\n'+templates[0].replace('__SELECTED_MODULES__',json.dumps(MODULES)).replace('__REQUIRED_DECLARATIONS__',json.dumps(required))
    require((A/'source/IndependentDeclarationAudit.lean').read_text()==expected_audit, 'Generated origin harness bytes')
    expected_public = 'import ChargeControls\n\nset_option pp.universes true\nset_option pp.fullNames true\n\n'+'\n'.join('#print '+name+'\n#print axioms '+name for name in exports)+'\n'
    require((A/'source/IndependentPublicExports.lean').read_text()==expected_public, 'Generated public audit bytes')
    records,signatures,printed,summary = parse_origin_log(A/'logs/all-declarations.log')
    require(records == read_json(A/'declarations.json') and len(records)==174, 'Full raw declaration inventory')
    inventory = {d['name']:d for d in records}
    safe,implementation = [],[]
    for d in records:
        require(d['module'] in MODULES and d['kind'] in ['definition','theorem'], 'Origin/kind '+d['name'])
        require(d['implementation_only'] == (d['unsafe'] or d['partial']), 'Classification flags '+d['name'])
        require(d['private'] == d['name'].startswith('_private.'), 'Private classification '+d['name'])
        require(set(d['axioms']) <= ALLOWED, 'Inventory axiom allowance')
        if d['implementation_only']:
            require(d['kind']=='definition' and re.search(r'\.(?:_cstage[12]|_unsafe_rec)$',d['name']), 'Unexplained implementation declaration '+d['name'])
            require(d['axioms']==[], 'Implementation axiom set')
            implementation.append(d)
        else:
            safe.append(d)
    require(len(safe)==123 and len(implementation)==51 and sum(d['private'] for d in safe)==14, 'Safe/implementation/private coverage')
    require(summary == {'safe_count':123,'implementation_count':51,'count':174,'axiom_union':['propext','Classical.choice','Quot.sound']}, 'Raw audit summary')
    require(verification['implementation_artifacts']==implementation, 'Receipt implementation inventory')
    for name in exports:
        require(name in inventory and not inventory[name]['implementation_only'] and not inventory[name]['private'], 'Safe public export '+name)
    for module,name in private_explicit:
        require(any(d['module']==module and d['name'].endswith('.'+name) and d['private'] for d in safe), 'Explicit private theorem missing '+name)
    public_log = (A/'logs/public-exports.log').read_text()
    public_axiom_texts = re.findall(r"^'[^']+' (?:does not depend on any axioms|depends on axioms: \[[^\]]*\])$", public_log, re.M)
    public_axioms = [parse_axiom_line(' '.join(value.splitlines())) for value in public_axiom_texts]
    require([n for n,a in public_axioms] == exports, 'Public print-axioms output order/coverage')
    for name,axioms in public_axioms:
        require(axioms==printed[name], 'Public/origin axiom mismatch '+name)
    require(len(re.findall(r'^(?:def|theorem) '+re.escape(PREFIX),public_log,re.M))==69, 'Public printed body coverage')
    require(not re.search(r'(^|\s)(?:error|warning):',public_log), 'Public diagnostics')
    tsv = list(csv.DictReader(io.StringIO((R/'declaration-coverage.tsv').read_text()),delimiter='\t'))
    converted=[]
    for row in tsv:
        for key in ['private','implementation_only','unsafe','partial']:
            require(row[key] in ['true','false'],'TSV boolean'); row[key]=row[key]=='true'
        row['axioms']=row['axioms'].split(',') if row['axioms'] else []
        converted.append(row)
    require(sorted(converted,key=lambda d:d['name'])==sorted(records,key=lambda d:d['name']), 'Complete TSV inventory')
    summary_record = read_json(R/'review-summary.json')
    require(summary_record['source_commit']==H and summary_record['source_tree']==TREE, 'Final summary source')
    for name,item in summary_record['required_endpoints'].items():
        require(item['signature']==signatures[name] and item['axioms']==printed[name], 'Endpoint signature/axioms '+name)
    signature_text = (R/'exact-public-signatures.txt').read_text()
    for name in exports:
        require(signatures[name] in signature_text, 'Public signature extraction '+name)
    per_module=[]
    for m in MODULES:
        ds=[d for d in records if d['module']==m]
        ss=[d for d in ds if not d['implementation_only']]
        per_module.append({'module':m,'explicit_exports':len(by_module[m]),'all_origin_declarations':len(ds),'safe_declarations':len(ss),'safe_private_declarations':sum(d['private'] for d in ss),'implementation_declarations':len(ds)-len(ss)})
    require(per_module==summary_record['coverage']['module_breakdown'], 'Module coverage summary')
    distribution=collections.Counter(tuple(d['axioms']) for d in safe)
    require(distribution=={():68,('propext',):1,('propext','Quot.sound'):43,('propext','Classical.choice','Quot.sound'):11}, 'Safe axiom distribution')
    require(all(not d['axioms'] for d in records if d['module']=='ChargeControls'), 'Control axioms')
    passed('complete_origin_and_public_axiom_coverage', origin_declarations=174, origin_signatures=174, origin_print_axioms=174, safe_declarations=123, safe_private=14, safe_public_including_generated=109, safe_definitions=sum(d['kind']=='definition' for d in safe), safe_theorems=sum(d['kind']=='theorem' for d in safe), implementation_declarations=51, implementation_unsafe=sum(d['unsafe'] for d in implementation), implementation_partial=sum(d['partial'] for d in implementation), explicit_public_prints=69, explicit_public_print_axioms=69, controls=9, safe_axiom_distribution=[{'axioms':list(k),'count':v} for k,v in distribution.items()], allowed_axiom_union=sorted(ALLOWED), by_module=per_module)

    infrastructure=[]
    for n in [1,2,3]:
        base=R/('infrastructure-%03d'%n); receipt=read_json(base/'verification.json')
        commands=[receipt] if n==1 else receipt['commands']
        exits=[c['exit_code'] for c in commands]
        require(exits==({1:[1],2:[0,1],3:[0,0]}[n]), 'Fixture status')
        for c in commands:
            require(all(f in c['argv'] for f in FLAGS), 'Fixture trust flags')
            log=base/('audit.log' if n==1 else Path(c['argv'][-1]).stem+'.log')
            if 'log_sha256' in c: require(sha(log.read_bytes())==c['log_sha256'],'Fixture log hash')
        if n==1:
            require("unknown option 'pp.width'" in (base/'audit.log').read_text() and 'type mismatch' in (base/'audit.log').read_text(), 'First retained failure')
        if n==2:
            require('UNSAFE_OR_PARTIAL_DECLARATION ReviewFixture ReviewFixture.visible._cstage1' in (base/'InfrastructureAudit.log').read_text(), 'Second retained failure')
        if n==3:
            ds,_,_,su=parse_origin_log(base/'InfrastructureAudit.log')
            require(len(ds)==22 and su['count']==22, 'Corrected fixture coverage')
        infrastructure.append({'attempt':n,'exit_codes':exits,'target_source_execution':False})
    correction=read_json(R/'cleanup-observation-correction.json')
    require(correction['status']=='HISTORICAL_DELETION_RECEIPT_NOT_CONFIRMED_BY_CURRENT_FILESYSTEM' and len(correction['observations'])==5, 'Cleanup correction preserved')
    passed('preserved_failed_infrastructure_and_environment_history', attempts=infrastructure, corrected_fixture_declarations=22, cleanup_discrepancy_preserved=True)

    semantic=read_json(S/'FINAL_SEMANTIC_REVIEW.json')
    require(semantic['reviewer']=='/root/ownership_scout' and semantic['source_modified_by_reviewer'] is False and semantic['lean_executed_by_reviewer'] is False, 'Semantic attribution')
    require(semantic['semantic_status']=='PASS' and semantic['remaining_semantic_blockers']==[] and semantic['source_commit']==H, 'Semantic scope verdict')
    require(sha((S/semantic['report']['path']).read_bytes())==semantic['report']['sha256'], 'Semantic report identity')
    require(summary_record['reviewer']=='runtime_scout' and 'did not author or modify any target Lean source' in summary_record['role'], 'Runtime attribution')
    require(summary_record['execution_result']=='PASS_CLEAN_BUILD_AND_ALL_DECLARATIONS', 'Runtime disposition')
    passed('review_attribution_consistency', original_runtime_reviewer='/root/runtime_scout', original_semantic_reviewer='/root/ownership_scout', evidence_validator='/root/pr145_finalverify', separate_github_identity_claimed=False, attribution_basis='explicit delegated task provenance and mutually consistent retained reports; filesystem is not a cryptographic identity attestation')
    RESULT['verdict']='PASS_REUSED_INDEPENDENT_FROZEN_EVIDENCE'
    RESULT['uncovered_evidence_gates']=[]
    RESULT['delivery_actions_outside_this_audit']=['Publish full recovered evidence packet under delivery-owner coordination authority.', 'Refresh actual PR head/base, platform checks, source/dependency identity, combined-tree compatibility, and acknowledged target-write ownership before guarded merge.']
    RESULT['limits']=['No Lean/compiler or retained script executed by this validator.', 'Retained official prebuilt Init/Std/Lean objects reused by original review; no fresh standard-library build or new upstream authentication claimed.', 'Remote-source identity validated from retained exact-H connector responses and prior pins; current remote state belongs to delivery owner.', 'No merge, Ready transition, source mutation, or remote publication performed by this auditor.']


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--check-originals',action='store_true',help='Also compare snapshot bytes with the authorized original filesystem paths.')
    options=parser.parse_args()
    try:
        main(options.check_originals)
    except Exception as exc:
        RESULT['verdict']='FAIL_RETAINED_EVIDENCE_VALIDATION'
        RESULT['error']=str(exc)
        RESULT['traceback']=traceback.format_exc()
    RESULT['validator_sha256']=sha(Path(__file__).read_bytes())
    output=ROOT/'validation-result.json'
    output.write_text(json.dumps(RESULT,indent=2)+'\n')
    print(json.dumps(RESULT,indent=2))
    raise SystemExit(0 if RESULT['verdict']=='PASS_REUSED_INDEPENDENT_FROZEN_EVIDENCE' else 1)
