#!/usr/bin/env python3
"""Independent publication-byte audit. Never imports or executes repository scripts or Lean."""
from pathlib import Path, PurePosixPath
import ast, collections, hashlib, json, subprocess, tarfile, traceback
P=Path('/dev/shm/p196-agent25-677aa81c663a/pr145-publication-delta')
PK=P/'published-package'
OR=Path('/dev/shm/p196-agent25-677aa81c663a/pr145-finalverify/originals')
AUTHOR=Path('/dev/shm/p196-agent15-43cf6e114472')
REL='proofs/contributions/agent-15/spectral-carry-charge-43cf6e114472/'
OLD='e8d706dc8a67248e1531b0b828fbe05ff50052ed'
HEAD='679d10a5b1382b51b68a7240bb9c6562ccf144d9'
checks=[]
def check(v,msg):
 checks.append({'check':msg,'pass':bool(v)})
 if not v:raise AssertionError(msg)
def j(p):return json.loads(p.read_text())
def save(name,v):(P/name).write_text(json.dumps(v,indent=2,ensure_ascii=False)+'\n')
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def entrymap(t):return {e['path']:e for e in t['tree']}
def treesha(entries):
 raw=b''
 for e in sorted(entries,key=lambda e:(e['path']+('/' if e['type']=='tree' else '')).encode()):
  mode='40000' if e['type']=='tree' else e['mode']
  raw+=mode.encode()+b' '+e['path'].encode()+b'\0'+bytes.fromhex(e['sha'])
 return hashlib.sha1(b'tree '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
def changed(a,b):
 a,b=entrymap(a),entrymap(b)
 return [x for x in sorted(a.keys()|b.keys()) if (a.get(x,{}).get('mode'),a.get(x,{}).get('sha'))!=(b.get(x,{}).get('mode'),b.get(x,{}).get('sha'))]
def safe(s):
 x=PurePosixPath(s);check(not x.is_absolute() and '..' not in x.parts and '.' not in x.parts,'safe path '+s);return x

def main():
 initial=j(P/'remote-initial.json');sub=j(P/'subtrees.json');commits=j(P/'publication-commit-receipts.json')
 trees={k:j(P/(k+'.json')) for k in ['headtree','oldtree','headproofs','oldproofs']};trees.update(sub)
 check(initial['headcommit']['sha']==HEAD and [x['sha'] for x in initial['headcommit']['parents']]==[OLD],'one publication commit, exact source parent')
 scope=[]
 for layer,only in [('tree','proofs'),('proofs','contributions'),('contributions','agent-15'),('agent15',REL.rstrip('/').split('/')[-1])]:
  h,o=trees['head'+layer],trees['old'+layer]
  check(not h['truncated'] and not o['truncated'],'complete ancestor tree '+layer)
  ds=changed(o,h);check(ds==[only],'only allowed ancestor delta '+layer)
  scope.append({'layer':layer,'old_count':len(o['tree']),'head_count':len(h['tree']),'changed':ds})
  for side,t in [('head',h),('old',o)]:
   expected=(initial['headcommit']['tree']['sha'] if side=='head' else commits[OLD]['tree']['sha']) if layer=='tree' else t['sha']
   check(treesha(t['tree'])==expected,'recomputed tree '+side+layer)
 for side in ['head','old']:
  t=trees[side+'package'];check(not t['truncated'],'complete recursive package '+side)
  dirs={'':t['sha']};dirs.update({e['path']:e['sha'] for e in t['tree'] if e['type']=='tree'})
  for directory,expected in dirs.items():
   es=[]
   for e in t['tree']:
    parent=str(PurePosixPath(e['path']).parent)
    if parent=='.':parent=''
    if parent==directory:es.append(dict(e,path=PurePosixPath(e['path']).name))
   check(treesha(es)==expected,'recomputed package subtree '+side+'/'+directory)
 h={x['path']:x for x in trees['headpackage']['tree'] if x['type']=='blob'}
 o={x['path']:x for x in trees['oldpackage']['tree'] if x['type']=='blob'}
 check(len(h)==210 and len(o)==32,'210 published and 32 frozen package files')
 check(sorted(REL+x for x in h)==sorted(initial['filenames']),'complete paginated PR paths equal package blobs')
 added=sorted(h.keys()-o.keys());modified=[x for x in sorted(h.keys()&o.keys()) if h[x]['sha']!=o[x]['sha'] or h[x]['mode']!=o[x]['mode']]
 check(len(added)==178 and modified==['BUILD.json','README.md'] and not o.keys()-h.keys(),'178 additions, only BUILD/README modified, no deletion')
 local_files={x.relative_to(PK).as_posix() for x in PK.rglob('*') if x.is_file()}
 local_extra=local_files-set(h)
 check(not set(h)-local_files,'all published files present in isolated snapshot')
 check(local_extra=={'development/weights/attempt-002/SpectralWeights.olean','development/weights/audit-001/SpectralWeights.olean','development/weights/audit-001/WeightsExports.olean'},'exact three known local-only historical objects')
 save('local-only-files.json',[{'path':x,'bytes':len((PK/x).read_bytes()),'sha256':sha((PK/x).read_bytes()),'published':False} for x in sorted(local_extra)])
 rows=[]
 for path,e in sorted(h.items()):
  safe(path);b=(PK/path).read_bytes();check(not (PK/path).is_symlink(),'regular local file '+path)
  check(e['mode']=='100644','published regular nonexecutable mode '+path)
  check(len(b)==e['size'] and blob(b)==e['sha'],'Git blob identity '+path)
  rows.append({'path':path,'bytes':len(b),'sha256':sha(b),'git_blob':blob(b),'status':'added' if path in added else 'modified' if path in modified else 'unchanged'})
 save('published-file-manifest.json',rows)
 save('scope-and-delta.json',{'ancestors':scope,'added':added,'modified':modified,'deleted':[],'unchanged':sorted(set(h)-set(added)-set(modified))})
 cm=j(PK/'evidence/independent/COPY_MANIFEST.json');am=j(PK/'evidence/independent/runtime-archive-manifest.json')
 check(set(cm)=={'frozen_source_commit','runtime_readable_records','runtime_compiled_objects_preserved_in_archive_only','semantic_records','complete_runtime_archive','all_copied_records_byte_identical','no_Lean_source_or_checker_changed'},'copy manifest complete known schema')
 check(cm['frozen_source_commit']==OLD and cm['all_copied_records_byte_identical'] is True and cm['no_Lean_source_or_checker_changed'] is True,'copy manifest source and identity labels')
 archive=PK/'evidence/independent/runtime-review-e8d706dc.tar.gz';ab=archive.read_bytes()
 check(len(ab)==629387 and sha(ab)=='b5d335c483e4b94ac573f4d00f047cc2cfa4303864469620cd1c20c8ead2b261' and blob(ab)=='841abd237eb22b289d879684ce233e9af384fad0','exact original archive and published Git blob')
 check(cm['complete_runtime_archive']=={'path':archive.name,'bytes':len(ab),'sha256':sha(ab)},'copy archive identity')
 check(am['archive_bytes']==len(ab) and am['archive_sha256']==sha(ab) and am['source_commit']==OLD and am['source_tree']==commits[OLD]['tree']['sha'],'archive publication metadata identity')
 check((PK/'evidence/independent/runtime-archive-manifest.json').read_bytes()==(OR/'runtime-review/delivery/package-manifest.json').read_bytes(),'delivery manifest copied without alteration')
 members={}
 with tarfile.open(archive,'r:gz') as tf:
  allnames=set()
  for m in tf.getmembers():
   path=safe(m.name);check(m.name not in allnames,'no duplicate archive member '+m.name);allnames.add(m.name)
   check(path.parts[0]=='runtime-review' and (m.isdir() or m.isfile()),'archive regular member/directory '+m.name)
   if m.isfile():members[PurePosixPath(*path.parts[1:]).as_posix()]=tf.extractfile(m).read()
 check(len(members)==am['archive_file_count']==136 and sum(map(len,members.values()))==am['archive_uncompressed_file_bytes']==2431703,'all 136 archive members and byte total')
 mapping=[]
 for key,kind,count in [('runtime_readable_records','runtime',125),('runtime_compiled_objects_preserved_in_archive_only','archive',11),('semantic_records','semantic',45)]:
  records=cm[key];check(len(records)==count and len({x['path'] for x in records})==count,'manifest cardinality '+kind)
  for r in records:
   check(set(r)=={'path','bytes','sha256'},'record full schema '+kind+'/'+r['path']);safe(r['path'])
   original=('semantic-review/' if kind=='semantic' else 'runtime-review/')+r['path'];ob=(OR/original).read_bytes()
   check(len(ob)==r['bytes'] and sha(ob)==r['sha256'],'original bytes '+original)
   check((AUTHOR/original).read_bytes()==ob,'untouched current author original '+original)
   if kind=='archive':
    check(PurePosixPath(r['path']).suffix in {'.olean','.ilean'},'archive-only record is compiled object '+r['path'])
    pb=members[r['path']];dest='evidence/independent/runtime-review-e8d706dc.tar.gz!runtime-review/'+r['path'];git=h['evidence/independent/runtime-review-e8d706dc.tar.gz']['sha']
    check('evidence/independent/runtime/'+r['path'] not in h,'compiled object not mislabeled readable '+r['path'])
   else:
    dest='evidence/independent/'+kind+'/'+r['path'];pb=(PK/dest).read_bytes();git=h[dest]['sha']
    if kind=='runtime':check(pb==members[r['path']],'readable runtime equals archive member '+r['path'])
   check(pb==ob,'published recovery exact '+original)
   mapping.append({'original':original,'publication':dest,'bytes':len(ob),'sha256':sha(ob),'published_container_or_file_git_blob':git,'kind':kind})
  if kind!='archive':check({x[len('evidence/independent/'+kind+'/'):] for x in h if x.startswith('evidence/independent/'+kind+'/')}=={r['path'] for r in records},'no extra or missing readable records '+kind)
 check(set(members)=={r['path'] for r in cm['runtime_readable_records']+cm['runtime_compiled_objects_preserved_in_archive_only']},'archive member partition exact')
 for original,dest,kind in [('runtime-review/delivery/runtime-review-e8d706dc.tar.gz','evidence/independent/runtime-review-e8d706dc.tar.gz','original_archive'),('runtime-review/delivery/package-manifest.json','evidence/independent/runtime-archive-manifest.json','delivery_manifest')]:
  b=(OR/original).read_bytes();check(b==(PK/dest).read_bytes()==(AUTHOR/original).read_bytes(),'delivery file exact '+original)
  mapping.append({'original':original,'publication':dest,'bytes':len(b),'sha256':sha(b),'published_container_or_file_git_blob':h[dest]['sha'],'kind':kind})
 snapshot=j(OR.parent/'snapshot-manifest.json');expected={r['copy'].removeprefix('originals/'):r for r in snapshot['files']};actual={r['original']:r for r in mapping}
 check(set(expected)==set(actual) and len(mapping)==183,'all 183 snapshot originals recover exactly with no exclusion')
 for n,r in expected.items():check((r['bytes'],r['sha256'])==(actual[n]['bytes'],actual[n]['sha256']),'snapshot mapping '+n)
 save('original-recovery-map.json',{'count':len(mapping),'bytes':sum(x['bytes'] for x in mapping),'missing':[],'excluded':[],'files':mapping})
 build=j(PK/'BUILD.json');registry=j(PK/'BUILD_REGISTRY.json');project=registry['projects']['agent15-spectral-carry-charge'];source=[]
 for name in ['SpectralWeights','BinaryCode','ChargeSymmetry','SourceFormula','ChargeControls','check']:
  path=name+('.py' if name=='check' else '.lean');b=(PK/path).read_bytes()
  check(h[path]['sha']==o[path]['sha'],'frozen source/checker Git identity '+path)
  source_path='runtime-review/freeze-inputs-001/check.py' if name=='check' else 'runtime-review/frozen-e8d706dc-attempt-001/source/'+path
  check(b==(OR/source_path).read_bytes() and b==(OR/('semantic-review/remote-freeze-e8d/files/'+path)).read_bytes(),'source/checker equals independently reviewed originals '+path)
  if name!='check':
   check(build['source_pins'][name]=={'sha256':sha(b),'bytes':len(b)},'BUILD source pin '+name)
   reg=project['modules'][name];check(reg['git_blob']==blob(b) and reg['sha256']==sha(b) and reg['path']==REL+path,'registry source pin '+name)
   check(reg['imports']==[line[7:].strip() for line in b.decode().splitlines() if line.startswith('import ')],'registry exact imports '+name)
  source.append({'file':path,'bytes':len(b),'sha256':sha(b),'git_blob':blob(b)})
 save('unchanged-source-and-checker.json',source)
 for name in ['BUILD.json','README.md']:
  b=(OR/('runtime-review/freeze-inputs-001/'+name)).read_bytes();check(blob(b)==o[name]['sha'],'prior modified-file original Git identity '+name);(P/('old-'+name)).write_bytes(b)
 check(registry['catalogue_complete'] is False and len(registry['projects'])==1 and project['roots']==['ChargeControls'] and 'not executed' in registry['integration_note'],'registry bounded scope and NOT_RUN shared runner')
 check(build['status']=='INDEPENDENTLY_REVIEWED' and build['repository_integration']=='NOT_YET_INTEGRATED' and build['frozen_source_commit']==OLD,'build bounded acceptance labels')
 check(build['independent_review']['execution']['official_standard_runtime_rebuilt'] is False,'prebuilt runtime boundary label')
 publication=j(PK/'PUBLICATION.json');checkpoint_receipts=[]
 for c in publication['checkpoints']:
  remote=commits[c['remote_commit']]['tree']['sha'];p=subprocess.run(['git','--no-replace-objects','-C',str(AUTHOR/'repo'),'cat-file','-p',c['local_commit']],capture_output=True,check=True)
  tree=p.stdout.decode().splitlines()[0].removeprefix('tree ');check(tree==remote==c['identical_tree'],'local/remote checkpoint tree identity '+c['kind']);checkpoint_receipts.append(dict(c,actual_local_tree=tree,actual_remote_tree=remote))
 save('checkpoint-tree-validation.json',checkpoint_receipts)
 script=(PK/'development/root/package-charge-reviews.py').read_bytes();check(script==(AUTHOR/'package-charge-reviews.py').read_bytes(),'published packaging script equals author original')
 tree=ast.parse(script);literal_failures=None;calls=[]
 for n in ast.walk(tree):
  if isinstance(n,ast.Call):
   if isinstance(n.func,ast.Attribute) and isinstance(n.func.value,ast.Name) and n.func.value.id=='subprocess':calls.append(ast.unparse(n))
   if isinstance(n.func,ast.Name) and n.func.id=='writej' and len(n.args)==2 and isinstance(n.args[1],ast.List):literal_failures=ast.literal_eval(n.args[1])
 check(literal_failures==j(PK/'development/root/review-packaging-failures.json'),'failure history equals statically read literal metadata')
 check(len(calls)==1 and calls[0].startswith("subprocess.check_output(['git', 'show',"),'packaging subprocess is read-only git show; no introduced build invocation')
 cov=j(PK/'COVERAGE.json');oldcov=None
 with tarfile.open(PK/'evidence/development-evidence.tar.gz','r:gz') as tf:oldcov=json.loads(tf.extractfile('coverage/coverage.json').read())
 diffs=[]
 def walk(a,b,path=''):
  if isinstance(a,dict) and isinstance(b,dict):
   for k in sorted(a.keys()|b.keys()):
    if k not in a or k not in b:diffs.append({'path':path+'/'+k,'old':a.get(k),'new':b.get(k)})
    else:walk(a[k],b[k],path+'/'+k)
  elif isinstance(a,list) and isinstance(b,list) and len(a)==len(b):
   for i,(x,y) in enumerate(zip(a,b)):walk(x,y,path+'/'+str(i))
  elif a!=b:diffs.append({'path':path,'old':a,'new':b})
 walk(oldcov,cov);save('coverage-reconciliation-delta.json',diffs)
 check(cov['inventory_complete'] is False and cov['formalization_complete'] is False and cov['status_reconciliation']['repository_wide_completion'] is False,'coverage explicitly incomplete')
 check([c['id'] for c in cov['claims'] if c['accepted_lean_identifiers']]==['A15-SPEC-002'],'only exact charge claim carries accepted identifiers')
 check([c['id'] for c in cov['claims'] if c['disposition']=='INDEPENDENTLY_REVIEWED']==['A15-SPEC-002'],'only exact charge claim reviewed')
 save('new-script-static-inspection.json',{'packaging_script_sha256':sha(script),'subprocess_calls':calls,'executed':False,'Lean':'NOT_RUN','copy_manifest_records_validated':181,'metadata_read_in_full':['BUILD_REGISTRY.json','COVERAGE.json','PUBLICATION.json','BUILD.json','README.md','development/root/package-charge-reviews.py','development/root/review-packaging-failures.json','evidence/independent/COPY_MANIFEST.json','evidence/independent/runtime-archive-manifest.json']})
 return {'status':'PASS_PUBLICATION_DELTA','source_commit':OLD,'publication_head':HEAD,'package_files':210,'added':178,'modified':2,'deleted':0,'original_files_recoverable':183,'original_bytes_recoverable':sum(r['bytes'] for r in mapping),'runtime_readable':125,'runtime_objects_archive_only':11,'semantic_files':45,'archive_bytes':len(ab),'archive_sha256':sha(ab),'archive_git_blob':blob(ab),'missing_originals':[],'excluded_originals':[],'Lean':'NOT_RUN','imported_scripts':'NOT_RUN','new_build_execution':'NONE','github_mutations':'NONE','checks':len(checks),'validator_sha256':sha(Path(__file__).read_bytes())}
try:
 result=main();save('validation-result.json',result);save('validation-checks.json',checks);print(json.dumps(result,indent=2))
except Exception as e:
 save('validation-result.json',{'status':'FAIL','error':str(e),'checks_completed':len(checks),'Lean':'NOT_RUN'});save('validation-checks.json',checks);traceback.print_exc();raise
