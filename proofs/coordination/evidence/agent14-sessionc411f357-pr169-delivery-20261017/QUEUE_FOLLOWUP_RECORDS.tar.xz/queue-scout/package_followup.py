#!/usr/bin/env python3
"""Losslessly package the completed Agent14 queue follow-up records.

This script performs no network requests, proof execution or repository writes.
Run only after the remaining-queue specialist reports its files complete.
"""
from __future__ import annotations

import hashlib
import io
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
OUT = ROOT.parent / "pr169" / "followup"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git_blob(data: bytes) -> str:
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    selected = [ROOT / "inputs.json", ROOT / "ROOT_FOLLOWUP_RECEIPT.json", ROOT / "FINAL_DELTA_RECEIPT.json", Path(__file__).resolve()]
    for dirname in ("next-scope", "remaining"):
        selected.extend(p for p in (ROOT / dirname).rglob("*") if p.is_file())
    selected = sorted(set(selected), key=lambda p: str(p.relative_to(ROOT)))
    assert selected and all(p.is_file() and not p.is_symlink() for p in selected)
    entries = []
    archive = OUT / "QUEUE_FOLLOWUP_RECORDS.tar.xz"
    with tarfile.open(archive, "w:xz", preset=6, format=tarfile.PAX_FORMAT) as tf:
        for path in selected:
            data = path.read_bytes()
            name = "queue-scout/" + path.relative_to(ROOT).as_posix()
            info = tarfile.TarInfo(name)
            info.size, info.mode, info.mtime = len(data), 0o644, 0
            info.uid = info.gid = 0
            info.uname = info.gname = ""
            tf.addfile(info, io.BytesIO(data))
            entries.append({"path": name, "bytes": len(data), "sha256": sha256(data), "git_blob": git_blob(data)})
    expected = {e["path"]: e for e in entries}
    with tarfile.open(archive, "r:xz") as tf:
        members = tf.getmembers()
        assert len(members) == len(entries)
        assert {m.name for m in members} == set(expected)
        for member in members:
            assert member.isfile()
            data = tf.extractfile(member).read()
            item = expected[member.name]
            assert len(data) == item["bytes"]
            assert sha256(data) == item["sha256"] and git_blob(data) == item["git_blob"]
    data = archive.read_bytes()
    manifest = {
        "schema": "agent14-queue-followup-lossless-v1",
        "purpose": "Preserve bounded queue availability evidence and immediate ownership-race reconciliation after completed PR169 qualification. No new mathematical acceptance is claimed.",
        "archive": {"path": archive.name, "bytes": len(data), "sha256": sha256(data), "git_blob": git_blob(data)},
        "files": entries,
        "total_original_files": len(entries),
        "total_original_bytes": sum(e["bytes"] for e in entries),
        "all_members_recovered_and_rehashed": True,
        "superseded_recommendation": "The original next-scope report recommended167 only at its recorded earlier cutoff. Root subsequently found Agent15's earlier claim; it never accepted167. Its later161 claim was immediately withdrawn in favor of earlier Agent7 before substantive work.",
        "scope_limit": "A bounded disposition of the accessible open queue; neither mathematical review of all PRs nor queue integration/completion. Existing owners and external blockers remain.",
        "exclusions": "No source-repository checkout, Git object database, runtime, proof objects, cache, or prior PR169 publication is included. Original selected reports, manifests, and receipts are preserved verbatim."
    }
    target = OUT / "QUEUE_FOLLOWUP_MANIFEST.json"
    target.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({"archive": manifest["archive"], "files": len(entries), "original_bytes": manifest["total_original_bytes"], "verified": True}))


if __name__ == "__main__":
    main()
