#!/usr/bin/env python3
"""Independent read/hash review. Does not import repository code or execute Lean."""
from pathlib import Path, PurePosixPath
import datetime, gzip, hashlib, json, os, re, resource, subprocess, sys

resource.setrlimit(resource.RLIMIT_AS, (512*1024*1024, 512*1024*1024))
ROOT=Path('/workspace/scratch/c411f357feb2/pr169/repo')
OUT=Path('/workspace/scratch/c411f357feb2/pr169/review-evidence')
H='d37aa2f2af91f2a073d741999310305bf626b77e'
B='ec7aa17a36548cc629d2a4a309e802406fc862e7'
C=Path('proofs/contributions/agent-105/all-predecessors-9df76b-20261016')
checks=[]
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args):
    cmd=['git','--no-lazy-fetch','-C',str(ROOT),*args]
    p=subprocess.run(cmd,capture_output=True,check=True)
    checks.append({'operation':'read-only git','argv':cmd,'exit_code':p.returncode,'stdout_bytes':len(p.stdout),'stdout_sha256':sha(p.stdout),'stderr':p.stderr.decode()})
    return p.stdout
def safe(root,rel):
    p=PurePosixPath(rel)
    assert not p.is_absolute() and '..' not in p.parts and '.' not in p.parts
    f=root.joinpath(*p.parts)
    assert all(not q.is_symlink() for q in [f,*f.parents])
    assert f.resolve().is_relative_to(root.resolve())
    return f
def read(rel):
    f=safe(ROOT,str(rel)); data=f.read_bytes()
    checks.append({'operation':'read/hash','path':str(rel),'bytes':len(data),'sha256':sha(data)})
    return data
def mask(text):
    # Independent lexer for nested Lean comments/string literals.
    out=[]; i=depth=0; string=False
    while i<len(text):
        pair=text[i:i+2]
        if depth:
            if pair=='/-': depth+=1; out.extend('  '); i+=2
            elif pair=='-/': depth-=1; out.extend('  '); i+=2
            else: out.append('\n' if text[i]=='\n' else ' '); i+=1
        elif string:
            if text[i]=='\\': out.extend('  '); i+=2
            else: string=text[i]!='"'; out.append('\n' if text[i]=='\n' else ' '); i+=1
        elif pair=='/-': depth=1;out.extend('  ');i+=2
        elif pair=='--':
            end=text.find('\n',i);end=len(text) if end<0 else end;out.extend(' '*(end-i));i=end
        elif text[i]=='"':string=True;out.append(' ');i+=1
        else:out.append(text[i]);i+=1
    assert depth==0 and not string
    return ''.join(out)

tree={}
for entry in git('ls-tree','-rz',H).split(b'\0'):
    if entry:
        meta,path=entry.split(b'\t',1);mode,kind,blob=meta.decode().split()
        tree[path.decode()]={'mode':mode,'type':kind,'git_blob':blob}
diff=git('diff','--name-status',B,H).decode().splitlines()
census=[];payload={}
for line in diff:
    status,path=line.split('\t');data=read(path);payload[path]=data
    blob=hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()
    census.append({'status':status,'path':path,'bytes':len(data),'sha256':sha(data),'computed_git_blob':blob,**tree[path],'matches_H':blob==tree[path]['git_blob']})
manifest=json.loads(read(C/'FILES.json'))
manifest_checks=[]
for r in manifest['files']:
    data=payload.get(r['path'])
    if data is None:data=read(r['path'])
    manifest_checks.append({**r,'actual_bytes':len(data),'actual_sha256':sha(data),'bytes_match':len(data)==r['bytes'],'sha256_match':sha(data)==r['sha256']})
registry=json.loads(read('proofs/Agent105AllPredecessors9df76b.registry.json'))
spec=registry['projects']['agent105-all-predecessors-9df76b']
modules={}
for name,r in spec['modules'].items():
    data=read(r['path']);code=mask(data.decode())
    imports=[x for line in re.findall(r'^\s*import\s+([^\n]+)',code,re.M) for x in line.split()]
    blob=hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()
    forbidden=[{'token':m.group(),'line':code.count('\n',0,m.start())+1} for m in re.finditer(r"(?<![\w'])\b(?:sorry|admit|axiom|sorryAx|native_decide|ofReduceBool|skipKernelTC)\b(?![\w'])",code)]
    implementation_annotations=[{'line':code.count('\n',0,m.start())+1,'text':m.group()} for m in re.finditer(r'\b(?:unsafe|implemented_by|extern|noncomputable|partial)\b',code)]
    modules[name]={'path':r['path'],'sha256':sha(data),'bytes':len(data),'computed_git_blob':blob,'registry_sha256_match':sha(data)==r['sha256'],'registry_blob_match':blob==r['git_blob'],'H_blob_match':blob==tree[r['path']]['git_blob'],'imports':imports,'imports_match':imports==r['imports'],'forbidden_tokens':forbidden,'implementation_annotations':implementation_annotations}
order=[];seen=set();active=set()
def visit(n):
    if n not in modules:return
    assert n not in active
    if n in seen:return
    active.add(n)
    for d in modules[n]['imports']:visit(d)
    active.remove(n);seen.add(n);order.append(n)
for n in spec['roots']:visit(n)

storage=json.loads(read(C/'EVIDENCE_STORAGE.json'))
compressed=read(C/storage['stored_path'])
assert len(compressed)==storage['stored_bytes'] and sha(compressed)==storage['stored_sha256']
outpath=safe(OUT,'recovered/'+storage['original_path']);outpath.parent.mkdir(parents=True,exist_ok=True)
with gzip.GzipFile(fileobj=__import__('io').BytesIO(compressed)) as z:
    decoded=z.read(storage['original_bytes']+1)
assert len(decoded)==storage['original_bytes'] and sha(decoded)==storage['original_sha256']
if outpath.exists():assert outpath.read_bytes()==decoded
else:outpath.write_bytes(decoded)
recovered_json=json.loads(decoded)
recovery={'metadata_path':str(C/'EVIDENCE_STORAGE.json'),'stored_hash_match':True,'decoded_bytes':len(decoded),'decoded_sha256':sha(decoded),'original_hash_match':True,'output_path':str(outpath),'json_top_keys':list(recovered_json) if isinstance(recovered_json,dict) else None,'method':'bounded gzip read; exact metadata-selected output; no archive extraction or links'}
json_valid=[];logs=[];attempts=[]
for path,data in payload.items():
    if path.endswith('.json'):
        j=json.loads(data);json_valid.append(path)
        if Path(path).name in {'result.json','receipt.json'}:
            attempt={'path':path,'sha256':sha(data),'exit_code':j.get('exit_code'),'source_sha256':j.get('source_sha256'),'command':j.get('command',j.get('argv')),'lean_path':j.get('LEAN_PATH',j.get('lean_path',j.get('environment',{}).get('LEAN_PATH'))),'compiler_sha256':j.get('compiler_sha256')}
            snapshots=[]
            for f in safe(ROOT,str(Path(path).parent)).glob('*.lean'):
                b=f.read_bytes();snapshots.append({'path':str(f.relative_to(ROOT)),'sha256':sha(b),'receipt_hash_match':sha(b)==j.get('source_sha256')})
            attempt['snapshots']=snapshots
            attempts.append(attempt)
    if path.endswith('.log'):
        text=data.decode();logs.append({'path':path,'bytes':len(data),'sha256':sha(data),'content':text})
exclusions=json.loads(read(C/'INFRASTRUCTURE_EXCLUSIONS.json'))
excluded=[]
for e in exclusions['files']:
    p=safe(ROOT,e['path']);excluded.append({**e,'exists_in_checkout':p.exists(),'tracked_at_H':e['path'] in tree})
receipt={'schema':'agent14-pr169-read-hash-evidence-review-v1','reviewed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'reviewer':'Agent #14 delegated evidence specialist','source_head':H,'displayed_base':B,'new_lean_executions':0,'repository_scripts_executed':0,'network_calls':0,'memory_limit_bytes':512*1024*1024,'diff':census,'diff_count':len(census),'diff_all_additions':all(x['status']=='A' for x in census),'all_diff_bytes_match_H':all(x['matches_H'] for x in census),'manifest':{'path':str(C/'FILES.json'),'entries':manifest_checks,'unindexed_diff_paths':sorted(set(payload)-{x['path'] for x in manifest_checks}),'indexed_non_diff_paths':sorted({x['path'] for x in manifest_checks}-set(payload))},'modules':modules,'root_reachable_modules':order,'registry_exact_root_closure':seen==set(modules),'external_imports':sorted({d for m in modules.values() for d in m['imports'] if d not in modules}),'recovery':recovery,'json_parsed':json_valid,'attempts':attempts,'raw_logs':logs,'exclusions':excluded,'executed_checks':checks}
output=OUT/'READ_HASH_RECEIPT.json';output.write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({'receipt':str(output),'diff_count':len(census),'all_diff_bytes_match_H':receipt['all_diff_bytes_match_H'],'manifest_mismatches':[e['path'] for e in manifest_checks if not e['bytes_match'] or not e['sha256_match']],'manifest_unindexed_diff_paths':receipt['manifest']['unindexed_diff_paths'],'registry_exact_root_closure':receipt['registry_exact_root_closure'],'module_failures':[n for n,m in modules.items() if not all([m['registry_sha256_match'],m['registry_blob_match'],m['H_blob_match'],m['imports_match']]) or m['forbidden_tokens']],'recovered_json_top_keys':recovery['json_top_keys'],'attempt_count':len(attempts),'log_count':len(logs),'new_lean_executions':0},indent=2))
