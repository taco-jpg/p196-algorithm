#!/usr/bin/env python3
"""Read/hash retained Agent11 exact-source evidence, without compiler execution."""
from pathlib import Path,PurePosixPath
from collections import Counter
import datetime, hashlib, json, re, resource
resource.setrlimit(resource.RLIMIT_AS,(512*1024*1024,512*1024*1024))
E=Path('/workspace/scratch/3da16b9c7d14/reviews169')
O=Path('/workspace/scratch/c411f357feb2/pr169/review-evidence')
R=Path('/workspace/scratch/c411f357feb2/pr169/repo')
F=E/'fresh-trust0-d37aa2f2-01'
def digest(f):
 h=hashlib.sha256();n=0
 with f.open('rb') as s:
  while b:=s.read(1048576):h.update(b);n+=len(b)
 return {'bytes':n,'sha256':h.hexdigest()}
def safe(root,name):
 p=PurePosixPath(name);assert not p.is_absolute() and '..' not in p.parts
 f=root.joinpath(*p.parts);assert not f.is_symlink() and f.resolve().is_relative_to(root.resolve());return f
def j(f):return json.loads(f.read_text())
v=j(F/'verification.json');ind=j(E/'independent-pr169-receipt.json');reg=j(R/'proofs/Agent105AllPredecessors9df76b.registry.json');spec=reg['projects']['agent105-all-predecessors-9df76b'];mapped=j(E/'strict-source-registry.json')
inventory=[]
for f in sorted(E.rglob('*')):
 if f.is_file() and not {'repo','borrowed-object-view'}.intersection(f.relative_to(E).parts):
  inventory.append({'path':str(f),**digest(f)})
man=j(F/'FILES.json');manifest=[]
for path,rec in man.items():
 actual=digest(safe(F,path));manifest.append({'path':path,'expected':rec,'actual':actual,'match':rec==actual})
reference_checks=[]
for name,rec in ind['evidence'].items():
 f=Path(rec['path']);actual=digest(f);reference_checks.append({'name':name,'path':str(f),'expected':{k:rec[k] for k in ['bytes','sha256']},'actual':actual,'match':actual=={k:rec[k] for k in ['bytes','sha256']}})
sources=[]
for name,rec in spec['modules'].items():
 snap=F/'source'/(name+'.lean');actual=digest(snap);mapping={k:mapped['modules'][name][k] for k in rec}
 sources.append({'name':name,'snapshot':str(snap),'actual':actual,'matches_H_bytes':snap.read_bytes()==(R/rec['path']).read_bytes(),'matches_registry_sha256':actual['sha256']==rec['sha256'],'matches_build_receipt_sha256':actual['sha256']==v['sources'][name]['build_sha256'],'mapping_equal':mapping==rec})
commands=[]
for cmd in v['commands']:
 h=digest(safe(F,cmd['log']));commands.append({**cmd,'actual_log_sha256':h['sha256'],'log_hash_match':h['sha256']==cmd['log_sha256']})
text=(F/'logs/IntervalClosureAudit.log').read_text();rows={}
for prefix in ['AUDIT_THEOREM','AUDIT_DEFINITION']:
 parsed=[]
 for mod,name,axs in re.findall(r'^'+prefix+r' (\S+) (\S+) : \[([^\]]*)\]$',text,re.M):
  ax=sorted(x.strip() for x in axs.split(',') if x.strip());parsed.append({'module':mod,'name':name,'axioms':ax})
 rows[prefix]=parsed
unsafe_ax=re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$',text,re.M)
unsafe_def=re.findall(r'^UNSAFE_IMPLEMENTATION_DEFINITION (\S+) (\S+)$',text,re.M)
allowed={'propext','Classical.choice','Quot.sound'}
allrows=rows['AUDIT_THEOREM']+rows['AUDIT_DEFINITION'];bad=[r for r in allrows if not set(r['axioms'])<=allowed]
named=E/'named-exports-d37aa2f2-01';nv=j(named/'verification.json');nt=(named/'Agent11PredecessorPublicAudit.log').read_text();literal={}
for name,axs in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",nt,re.S):literal[name]=sorted(x.strip() for x in axs.split(',') if x.strip())
for name in re.findall(r"'([^']+)' does not depend on any axioms",nt):literal[name]=[]
origin={x['name']:x['axioms'] for x in allrows}
literal_comparison={name:{'axioms':axs,'origin_match':origin.get(name)==axs} for name,axs in literal.items()}
compiler=[]
for path,expected in v['compiler']['files'].items():
 f=Path(path);actual=digest(f) if f.exists() else None;compiler.append({'path':path,'expected_sha256':expected,'present':f.exists(),'actual':actual,'hash_match':actual is not None and actual['sha256']==expected})
driver=Path(v['invocation'][1]);driverhash=digest(driver)
report={'schema':'agent14-pr169-retained-agent11-qualification-v1','checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'new_lean_executions':0,'new_repository_script_executions':0,'head':ind['head'],'inventory':inventory,'manifest':manifest,'manifest_self_entry_present':'FILES.json' in man,'manifest_mismatches':[x['path'] for x in manifest if not x['match']],'independent_receipt_references':reference_checks,'sources':sources,'roots_match':mapped['roots']==spec['roots']==v['roots'],'endpoints_match':mapped['endpoints']==reg['claims'][0]['endpoints']==v['endpoints'],'commands':commands,'all_commands_exit_zero':all(c['exit_code']==0 for c in commands),'all_command_log_hashes_match':all(c['log_hash_match'] for c in commands),'compiled_module_count':sum(c['label'] in spec['modules'] for c in commands),'explicit_flags_all_module_and_audit_commands':all(all(f in c['argv'] for f in ['--trust=0','-j1','-DElab.async=false']) for c in commands if c['label'] in spec['modules'] or c['label']=='IntervalClosureAudit'),'recorded_elapsed_seconds':v['finished_epoch']-v['started_epoch'],'sum_module_elapsed_seconds':sum(c['elapsed_seconds'] for c in commands if c['label'] in spec['modules']),'audit_rows':rows,'theorem_count':len(rows['AUDIT_THEOREM']),'safe_definition_count':len(rows['AUDIT_DEFINITION']),'theorem_names_unique':len({r['name'] for r in rows['AUDIT_THEOREM']})==len(rows['AUDIT_THEOREM']),'definition_names_unique':len({r['name'] for r in rows['AUDIT_DEFINITION']})==len(rows['AUDIT_DEFINITION']),'module_counts':{kind:dict(sorted(Counter(r['module'] for r in data).items())) for kind,data in rows.items()},'disallowed_axiom_rows':bad,'axiom_union':sorted({a for r in allrows for a in r['axioms']}),'unsafe_implementation_axioms':unsafe_ax,'unsafe_implementation_definition_count':len(unsafe_def),'unsafe_axiom_in_mathematical_dependency':any(set(r['axioms'])&{x[1] for x in unsafe_ax} for r in allrows),'named_audit':{'receipt':str(named/'verification.json'),'recorded_exit_code':nv['exit_code'],'source_hash_match':digest(named/'Agent11PredecessorPublicAudit.lean')['sha256']==nv['source_sha256'],'log_hash_match':digest(named/'Agent11PredecessorPublicAudit.log')['sha256']==nv['log_sha256'],'literals':literal_comparison,'literal_count':len(literal),'all_origin_match':all(r['origin_match'] for r in literal_comparison.values())},'compiler_rehash':compiler,'driver':{'path':str(driver),'actual':driverhash,'receipt_hash_match':driverhash['sha256']==v['workflow_sha256']},'retained_independent_receipt':{'path':str(E/'independent-pr169-receipt.json'),**digest(E/'independent-pr169-receipt.json')},'historical_99_90_98_50_status':ind['published_historical_run_claims_status']}
(O/'AGENT11_QUALIFICATION_RECEIPT.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['manifest_mismatches','manifest_self_entry_present','roots_match','endpoints_match','all_commands_exit_zero','all_command_log_hashes_match','compiled_module_count','explicit_flags_all_module_and_audit_commands','recorded_elapsed_seconds','theorem_count','safe_definition_count','theorem_names_unique','definition_names_unique','disallowed_axiom_rows','axiom_union','unsafe_implementation_definition_count','unsafe_axiom_in_mathematical_dependency','driver','historical_99_90_98_50_status']},indent=2))
print('compiler',json.dumps(compiler,indent=2));print('reference mismatches',[r['name'] for r in reference_checks if not r['match']]);print('snapshot checks',all(all(r[k] for k in ['matches_H_bytes','matches_registry_sha256','matches_build_receipt_sha256','mapping_equal']) for r in sources));print('literal',len(literal),report['named_audit']['all_origin_match'])
