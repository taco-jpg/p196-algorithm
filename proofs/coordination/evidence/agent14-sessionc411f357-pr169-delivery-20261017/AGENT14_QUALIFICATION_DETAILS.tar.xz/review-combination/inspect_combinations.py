"""Create prospective merge trees only; no checkout or remote mutation."""
import datetime
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT / "repo"
PINS = {
    "main": "74a1c3922eb7af438fe40b23d2105ad07556e3f5",
    "pr113": "cd11afd68833051c81051df22573e8827ab6b671",
    "pr134": "ec7aa17a36548cc629d2a4a309e802406fc862e7",
    "pr169": "d37aa2f2af91f2a073d741999310305bf626b77e",
}
ENV = dict(os.environ)
ENV.update(GIT_AUTHOR_NAME="Agent 14 prospective review", GIT_COMMITTER_NAME="Agent 14 prospective review",
           GIT_AUTHOR_EMAIL="prospective-review@example.invalid", GIT_COMMITTER_EMAIL="prospective-review@example.invalid",
           GIT_AUTHOR_DATE="2026-10-17T05:18:44Z", GIT_COMMITTER_DATE="2026-10-17T05:18:44Z")
for key in ["HTTPS_PROXY", "HTTP_PROXY", "ALL_PROXY"]:
    ENV.pop(key, None)

def run(label, args, stdin=None):
    command = ["git", "-c", "credential.helper=", "-C", str(REPO), *args]
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    p = subprocess.run(command, input=stdin, text=True, capture_output=True, env=ENV)
    (ROOT / (label + ".stdout.txt")).write_text(p.stdout)
    (ROOT / (label + ".stderr.txt")).write_text(p.stderr)
    receipt = {"command": command, "started_utc": started, "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
               "exit_status": p.returncode, "stdin": stdin}
    (ROOT / (label + ".receipt.json")).write_text(json.dumps(receipt, indent=2) + "\n")
    return p

results = {}
for name, oid in PINS.items():
    p = run("pin-" + name, ["show", "-s", "--format=%H %T %P", oid])
    if p.returncode:
        raise RuntimeError(p.stderr)

def merge(label, first, second):
    bases = run(label + "-bases", ["merge-base", "--all", first, second])
    p = run(label, ["merge-tree", "--write-tree", first, second])
    record = {"first_parent": first, "second_parent": second, "all_merge_bases": bases.stdout.splitlines(),
              "merge_tree_exit": p.returncode, "actual_merge": False, "tree": p.stdout.splitlines()[0] if p.stdout else None,
              "stdout": label + ".stdout.txt", "stderr": label + ".stderr.txt"}
    results[label] = record
    if p.returncode == 0:
        q = run(label + "-synthetic-commit", ["commit-tree", record["tree"], "-p", first, "-p", second],
                "PROSPECTIVE ONLY: " + label + "; no actual integration or source modification.\n")
        if q.returncode:
            raise RuntimeError(q.stderr)
        record["local_synthetic_commit"] = q.stdout.strip()
        return q.stdout.strip()
    return None

merge("direct-main-pr169", PINS["main"], PINS["pr169"])
stage1 = merge("staged-main-pr113", PINS["main"], PINS["pr113"])
if stage1:
    stage2 = merge("staged-plus-pr134", stage1, PINS["pr134"])
    if stage2:
        merge("staged-plus-pr169", stage2, PINS["pr169"])
(ROOT / "merge_results.json").write_text(json.dumps({"pins": PINS, "combinations": results}, indent=2) + "\n")
print(json.dumps(results, indent=2))
