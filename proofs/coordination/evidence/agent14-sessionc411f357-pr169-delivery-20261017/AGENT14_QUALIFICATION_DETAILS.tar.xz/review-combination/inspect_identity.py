"""Inspect Git objects, registry hashes and imports; execute no Lean or repository code."""
import datetime
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT / "repo"
MERGES = json.loads((ROOT / "merge_results.json").read_text())
PINS = MERGES["pins"]
RAW = ROOT / "identity-raw"
RAW.mkdir(exist_ok=False)
COMMANDS = []

def git(*args):
    command = ["git", "-c", "credential.helper=", "-C", str(REPO), *args]
    p = subprocess.run(command, capture_output=True)
    label = f"command-{len(COMMANDS)+1:03}"
    (RAW / (label + ".stdout")).write_bytes(p.stdout)
    (RAW / (label + ".stderr")).write_bytes(p.stderr)
    COMMANDS.append({"command": command, "exit_status": p.returncode, "stdout": label + ".stdout", "stderr": label + ".stderr"})
    (RAW / "commands.json").write_text(json.dumps(COMMANDS, indent=2)+"\n")
    if p.returncode:
        raise RuntimeError(p.stderr.decode())
    return p.stdout

def tree(ref):
    result = {}
    for entry in git("ls-tree", "-r", "-z", ref).split(b"\0"):
        if entry:
            meta, path = entry.split(b"\t", 1)
            mode, kind, oid = meta.decode().split()
            result[path.decode()] = {"mode": mode, "kind": kind, "oid": oid}
    return result

def difference(old, new):
    return {"added": sorted(new.keys() - old.keys()), "deleted": sorted(old.keys() - new.keys()),
            "changed": sorted(p for p in old.keys() & new.keys() if old[p] != new[p])}

def code_only(text):
    # Mask nested comments and strings before extracting imports.
    output, i, depth, string = [], 0, 0, False
    while i < len(text):
        pair = text[i:i+2]
        if depth:
            if pair == "/-": depth += 1; output.extend("  "); i += 2
            elif pair == "-/": depth -= 1; output.extend("  "); i += 2
            else: output.append("\n" if text[i] == "\n" else " "); i += 1
        elif string:
            if text[i] == "\\": output.extend("  "); i += 2
            else: string = text[i] != '"'; output.append("\n" if text[i] == "\n" else " "); i += 1
        elif pair == "/-": depth = 1; output.extend("  "); i += 2
        elif pair == "--":
            end = text.find("\n", i)
            if end < 0: end = len(text)
            output.extend(" " * (end-i)); i = end
        elif text[i] == '"': string = True; output.append(" "); i += 1
        else: output.append(text[i]); i += 1
    if depth or string: raise ValueError("Unterminated comment or string")
    return "".join(output)

trees = {name: tree(ref) for name, ref in PINS.items()}
trees.update({name: tree(rec["tree"]) for name, rec in MERGES["combinations"].items() if rec["merge_tree_exit"] == 0})
registry_path = "proofs/Agent105AllPredecessors9df76b.registry.json"
verifier_path = "proofs/verify_project__214bf7673efe116b.py"
registry_data = git("show", PINS["pr169"] + ":" + registry_path)
registry = json.loads(registry_data)
spec = registry["projects"]["agent105-all-predecessors-9df76b"]
module_records, imports = {}, {}
for name, record in spec["modules"].items():
    path = record["path"]
    data = git("show", PINS["pr169"] + ":" + path)
    code = code_only(data.decode())
    actual_imports = [dep for line in re.findall(r"^\s*import\s+([^\n]+)", code, re.M) for dep in line.split()]
    sha256 = hashlib.sha256(data).hexdigest()
    blob = hashlib.sha1(("blob " + str(len(data)) + "\0").encode()+data).hexdigest()
    imports[name] = actual_imports
    module_records[name] = {"path": path, "git_blob": blob, "sha256": sha256, "imports": actual_imports,
        "registry_blob_matches": blob == record["git_blob"], "registry_sha256_matches": sha256 == record["sha256"],
        "registry_imports_match": actual_imports == record["imports"],
        "prospective_identity": {label: entries.get(path) == trees["pr169"][path] for label, entries in trees.items() if label.startswith("direct-") or label == "staged-plus-pr169"}}
seen, active, order = set(), set(), []
def visit(name):
    if name not in imports:
        if name.split(".")[0] not in {"Init", "Std", "Lean"}: raise ValueError("Missing dependency " + name)
        return
    if name in active: raise ValueError("Import cycle " + name)
    if name in seen: return
    active.add(name)
    for dep in imports[name]: visit(dep)
    active.remove(name); seen.add(name); order.append(name)
for root in spec["roots"]: visit(root)
changes169 = difference(trees["pr134"], trees["pr169"])
main_differences = {name: difference(trees["main"], entries) for name, entries in trees.items() if name.startswith("direct-") or name.startswith("staged-")}
direct_vs_staged = difference(trees["direct-main-pr169"], trees["staged-plus-pr169"])
for label, entries in trees.items():
    if label.startswith("direct-") or label.startswith("staged-"):
        (ROOT / (label + ".tree-manifest.json")).write_text(json.dumps(entries, indent=2)+"\n")

report = {"utc": datetime.datetime.now(datetime.timezone.utc).isoformat(), "actual_merge": False,
    "lean_build_executed": False, "registry": {"path": registry_path, "git_blob": trees["pr169"][registry_path]["oid"],
    "sha256": hashlib.sha256(registry_data).hexdigest(), "module_count": len(module_records), "roots": spec["roots"],
    "all_modules_reachable_from_roots": seen == set(imports), "build_order": order, "modules": module_records},
    "identity_obligations": {label: {"registry": entries.get(registry_path) == trees["pr169"][registry_path],
        "canonical_verifier": entries.get(verifier_path) == trees["pr169"][verifier_path],
        "pr169_added_paths_total": len(changes169["added"]),
        "pr169_added_paths_identical": sum(entries.get(p) == trees["pr169"][p] for p in changes169["added"]),
        "pr169_added_paths_mismatched": [p for p in changes169["added"] if entries.get(p) != trees["pr169"][p]],
        "current_main_entries": len(trees["main"]), "current_main_entries_identical": sum(entries.get(p) == r for p,r in trees["main"].items()),
        "current_main_changed": [p for p,r in trees["main"].items() if entries.get(p) != r]}
        for label, entries in trees.items() if label in {"direct-main-pr169", "staged-plus-pr169"}},
    "pr169_changes_relative_to_pr134": changes169, "relative_to_main": main_differences,
    "direct_vs_staged": direct_vs_staged,
    "direct_vs_staged_identity": {p: {"direct": trees["direct-main-pr169"].get(p), "staged": trees["staged-plus-pr169"].get(p),
        "pr113": trees["pr113"].get(p), "pr134": trees["pr134"].get(p), "pr169": trees["pr169"].get(p)}
        for kind in direct_vs_staged.values() for p in kind},
    "canonical_verifier": {"path": verifier_path, "git_blob": trees["pr169"][verifier_path]["oid"],
        "main_blob": trees["main"][verifier_path]["oid"]}}
(ROOT / "identity_results.json").write_text(json.dumps(report, indent=2)+"\n")
summary = {"registry_modules": len(module_records), "closure": seen == set(imports),
    "identity": report["identity_obligations"], "counts_relative_main": {k: {n:len(v) for n,v in r.items()} for k,r in main_differences.items()},
    "direct_vs_staged": direct_vs_staged}
print(json.dumps(summary, indent=2))
