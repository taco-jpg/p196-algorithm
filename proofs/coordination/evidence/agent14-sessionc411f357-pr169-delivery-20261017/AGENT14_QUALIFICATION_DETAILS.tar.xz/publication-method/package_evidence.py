"""Package attributed PR169 records without changing their original bytes."""
from pathlib import Path, PurePosixPath
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path('/workspace/scratch/c411f357feb2/pr169')
selection_path = ROOT / 'review-evidence/PUBLICATION_INPUTS.json'
selection_bytes = selection_path.read_bytes()
selection = json.loads(selection_bytes)
out = ROOT / 'publication'
out.mkdir(exist_ok=True)
archive_path = out / 'AGENT11_RETAINED_EVIDENCE.tar.gz'
entries = []
seen = set()
with archive_path.open('xb') as raw:
    with gzip.GzipFile(filename='', mode='wb', fileobj=raw, mtime=0) as zipped:
        with tarfile.open(fileobj=zipped, mode='w|', format=tarfile.PAX_FORMAT) as archive:
            for item in selection['files']:
                member = item['archive_member']
                parts = PurePosixPath(member)
                assert not parts.is_absolute() and '..' not in parts.parts
                assert member not in seen
                seen.add(member)
                source = Path(item['source_absolute_path'])
                assert source.is_file() and not source.is_symlink()
                data = source.read_bytes()
                sha = hashlib.sha256(data).hexdigest()
                blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
                assert len(data) == item['bytes'] and sha == item['sha256']
                if item.get('git_blob'):
                    assert blob == item['git_blob']
                info = tarfile.TarInfo(member)
                info.size = len(data)
                info.mode = 0o644
                info.mtime = 0
                archive.addfile(info, io.BytesIO(data))
                entries.append({**item, 'git_blob': blob})

recovered = []
with tarfile.open(archive_path, 'r:gz') as archive:
    for expected, member in zip(entries, archive.getmembers(), strict=True):
        assert member.isfile() and member.name == expected['archive_member']
        stream = archive.extractfile(member)
        assert stream is not None
        data = stream.read(expected['bytes'] + 1)
        assert len(data) == expected['bytes']
        assert hashlib.sha256(data).hexdigest() == expected['sha256']
        recovered.append(member.name)

stored = archive_path.read_bytes()
manifest = {
    'schema': 'agent14-pr169-lossless-retained-evidence-v1',
    'source_head': selection['source_head'],
    'original_reviewer': 'Agent #11 /root/review134_resume',
    'publisher_and_qualification_owner': 'Agent #14/sessionc411f357feb2',
    'new_lean_run': False,
    'archive': {'path': archive_path.name, 'bytes': len(stored),
                'sha256': hashlib.sha256(stored).hexdigest(),
                'git_blob': hashlib.sha1(b'blob ' + str(len(stored)).encode() + b'\0' + stored).hexdigest()},
    'file_count': len(entries),
    'original_bytes': sum(x['bytes'] for x in entries),
    'all_members_read_back_and_rehashed': len(recovered) == len(entries),
    'selection_sha256': hashlib.sha256(selection_bytes).hexdigest(),
    'original_manifests_preserved_verbatim': True,
    'excluded_project_objects': selection['excluded_project_objects'],
    'excluded_large_directories': selection['excluded_large_directories'],
    'exclusion_reason': 'Reproducible compiled objects, complete runtime installations, Git object databases and duplicate full repository checkouts are infrastructure, not research source or raw execution evidence. Original manifests, object hashes, complete source snapshots, raw command logs, receipts, reports and runtime provenance are preserved.',
    'files': entries,
    'self_reference_policy': 'This manifest describes the archive and its members; it does not claim to hash itself.'
}
with (out / 'ARCHIVE_MANIFEST.json').open('x') as f:
    f.write(json.dumps(manifest, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({k:manifest[k] for k in ['archive','file_count','original_bytes','all_members_read_back_and_rehashed']}))
