"""Preserve Agent14 qualification records and raw prospective-tree evidence."""
from pathlib import Path, PurePosixPath
import hashlib
import io
import json
import tarfile

ROOT = Path('/workspace/scratch/c411f357feb2/pr169')
OUT = ROOT / 'publication'
files = []
for folder in ['review-evidence', 'review-semantics', 'review-combination']:
    base = ROOT / folder
    for path in sorted(base.rglob('*')):
        relative = path.relative_to(base)
        if any(part in {'repo', '.git', 'objects', 'git-cache', 'recovered', '__pycache__'} for part in relative.parts):
            continue
        if path.is_file():
            assert not path.is_symlink()
            files.append((path, PurePosixPath(folder) / relative.as_posix()))
for filename in ['package_evidence.py', 'package_qualification.py']:
    files.append((ROOT / filename, PurePosixPath('publication-method') / filename))
entries = []
archive_path = OUT / 'AGENT14_QUALIFICATION_DETAILS.tar.xz'
assert not archive_path.exists()
with tarfile.open(archive_path, 'w:xz', format=tarfile.PAX_FORMAT, preset=6) as archive:
    for source, relative in files:
        member = str(relative)
        assert not relative.is_absolute() and '..' not in relative.parts
        data = source.read_bytes()
        info = tarfile.TarInfo(member)
        info.mode = 0o644
        info.mtime = 0
        info.size = len(data)
        archive.addfile(info, io.BytesIO(data))
        entries.append({'source_absolute_path':str(source),'archive_member':member,
                        'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),
                        'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()})
with tarfile.open(archive_path, 'r:xz') as archive:
    for expected, member in zip(entries, archive.getmembers(), strict=True):
        assert member.isfile() and member.name == expected['archive_member']
        stream = archive.extractfile(member)
        assert stream is not None
        data = stream.read(expected['bytes'] + 1)
        assert len(data) == expected['bytes']
        assert hashlib.sha256(data).hexdigest() == expected['sha256']
data = archive_path.read_bytes()
manifest = {
    'schema':'agent14-pr169-qualification-archive-v1',
    'owner':'Agent #14/sessionc411f357feb2',
    'source_head':'d37aa2f2af91f2a073d741999310305bf626b77e',
    'new_lean_execution':False,
    'actual_main_merge':False,
    'archive':{'path':archive_path.name,'bytes':len(data),
               'sha256':hashlib.sha256(data).hexdigest(),
               'git_blob':hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()},
    'file_count':len(entries),'original_bytes':sum(x['bytes'] for x in entries),
    'all_members_read_back_and_rehashed':True,
    'files':entries,
    'exclusions':[
        'Git object databases, isolated repository copies and __pycache__ are reproducible infrastructure.',
        'The recovered scout JSON is an exact duplicate of the gzip already published at source H; its byte/hash recovery is preserved in SCOUT_RECOVERY_RECEIPT.json. No source or new research evidence is omitted.'
    ],
    'self_reference_policy':'This external manifest describes the archive, not its own hash.'
}
with (OUT/'QUALIFICATION_MANIFEST.json').open('x') as f:
    f.write(json.dumps(manifest,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({k:manifest[k] for k in ['archive','file_count','original_bytes','all_members_read_back_and_rehashed']}))
