import Agent105Predecessors9df76b
import Agent105PredecessorControls9df76b
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check Agent105WordFiber9df76b.half
#check Agent105WordFiber9df76b.center
#check Agent105WordFiber9df76b.wordFiber
#check Agent105WordFiber9df76b.half_coefficientWord
#check Agent105WordFiber9df76b.center_coefficientWord
#check Agent105WordFiber9df76b.coefficientWord_roundtrip
#check Agent105WordFiber9df76b.mem_wordFiber
#check Agent105WordFiber9df76b.wordFiber_nodup
#check Agent105DecodedFiber9df76b.decodedFiber
#check Agent105DecodedFiber9df76b.decodeNumerical_word_spec
#check Agent105DecodedFiber9df76b.mem_decodedFiber_decimalWidth
#check Agent105DecodedFiber9df76b.mem_decodedFiber
#check Agent105DecodedFiber9df76b.decodedFiber_nodup
#check Agent105Predecessors9df76b.predecessors
#check Agent105Predecessors9df76b.mem_predecessors
#check Agent105Predecessors9df76b.predecessors_nodup
#check Agent105PredecessorControls9df76b.small_targets
#check Agent105PredecessorControls9df76b.two_width_121
run_cmd do
  let env ← getEnv
  let selected : List String := ["Lychrel196Research", "Agent101DigitPairs", "Agent101MultiplicityBounds", "Agent101SplitEnumeration", "Agent101NumericFibers", "Agent105WidthSupport9df76b", "Agent105DecoderTarget9df76b", "Agent105DecoderLocal9df76b", "Agent105DecoderScan9df76b", "Agent105NumericDecoder9df76b", "Agent101ProfileExtraction", "Agent105WordFiber9df76b", "Agent105DecodedFiber9df76b", "Agent105Predecessors9df76b", "Agent105PredecessorControls9df76b"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut definitionCount := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let origin := env.allImportedModuleNames[idx.toNat]!
      if selected.contains origin.toString then
        match info with
        | .axiomInfo value =>
          if value.isUnsafe then
            logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {origin} {name}"
          else
            throwError m!"CUSTOM_AXIOM {origin} {name}"
        | .thmInfo _ =>
          count := count + 1
          let dependencies ← liftCoreM (Lean.collectAxioms name)
          let axl := dependencies.toList
          for axiomName in axl do
            if !(allowed.contains axiomName) then
              throwError m!"DISALLOWED_AXIOM {origin} {name} {axiomName}"
            if !(union.contains axiomName) then
              union := axiomName :: union
          logInfo m!"AUDIT_THEOREM {origin} {name} : {axl}"
        | .defnInfo _ | .opaqueInfo _ =>
          if info.isUnsafe then
            logInfo m!"UNSAFE_IMPLEMENTATION_DEFINITION {origin} {name}"
          else
            definitionCount := definitionCount + 1
            let dependencies ← liftCoreM (Lean.collectAxioms name)
            let axl := dependencies.toList
            for axiomName in axl do
              if !(allowed.contains axiomName) then
                throwError m!"DISALLOWED_DEFINITION_AXIOM {origin} {name} {axiomName}"
              if !(union.contains axiomName) then
                union := axiomName :: union
            logInfo m!"AUDIT_DEFINITION {origin} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
  logInfo m!"FULL_DEFINITION_AUDIT definitions={definitionCount}"
