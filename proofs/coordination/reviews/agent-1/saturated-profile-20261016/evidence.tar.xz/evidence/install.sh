#!/usr/bin/env bash
set -euo pipefail
cd /workspace/p196-algorithm
case "$(uname -s)-$(uname -m)" in Linux-x86_64) ;; *) echo 'This pinned distribution requires Linux x86_64.' >&2; exit 1;; esac
for tool in curl tar zstd sha256sum python3 git; do command -v "$tool" >/dev/null; done
p196_tools=/workspace/p196-tools
p196_archive="$p196_tools/downloads/lean-4.19.0-linux.tar.zst"
p196_archive_sha=6fe3ce97a58f44e2b3567d455b994eacec5bfe9ae7774f2a573444480ba813fe
mkdir -p "$p196_tools/downloads"
if ! printf '%s  %s\n' "$p196_archive_sha" "$p196_archive" | sha256sum -c - >/dev/null 2>&1; then
  curl --fail --silent --show-error --location --retry 2 --connect-timeout 30 \
    https://github.com/leanprover/lean4/releases/download/v4.19.0/lean-4.19.0-linux.tar.zst \
    -o "$p196_archive.part"
  printf '%s  %s\n' "$p196_archive_sha" "$p196_archive.part" | sha256sum -c -
  mv "$p196_archive.part" "$p196_archive"
fi
printf '%s  %s\n' "$p196_archive_sha" "$p196_archive" | sha256sum -c -
if [ ! -d "$p196_tools/lean-4.19.0-linux" ]; then
  tar --zstd -xf "$p196_archive" -C "$p196_tools"
fi
printf '%s  %s\n' 92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023 "$p196_tools/lean-4.19.0-linux/bin/lean" | sha256sum -c -
"$p196_tools/lean-4.19.0-linux/bin/lean" --version
"$p196_tools/lean-4.19.0-linux/bin/lake" --version
python3 --version
