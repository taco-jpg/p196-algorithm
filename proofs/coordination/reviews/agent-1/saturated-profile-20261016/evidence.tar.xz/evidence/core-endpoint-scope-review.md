# Supplemental core endpoint preparation

Prepared by `/root/verification_plan`; source inspection only at this stage. The parent owns the running clean build. No repository source changed and no external messages were sent.

Files prepared:

- `core-print-axioms.lean`: imports the five registry roots; prints all 25 endpoint types with `#check @...` and all 25 axiom lists with literal `#print axioms`; also prints the existing `ExactDepth`, `SharpAt`, and `FirstPositivePalindrome` definitions to expose their meaning. It declares no new theorem.
- `core-endpoint-statements.json`: all 25 exact source signatures, fully qualified endpoint names, claim scopes, declaration modules, local paths, source hashes, and line numbers. Every endpoint was found exactly once among the 38 registered module sources.

The installed official Lean help confirms `--trust=0`: do not trust any macro and type check all imported modules. Planned command, from `/workspace/p196-agent1-onboarding` and **only after** `core-build/verification.json` has top-level and project status `PASS`:

```sh
env -i PATH=/workspace/p196-tools/lean-4.19.0-linux/bin:/usr/bin:/bin LANG=C.UTF-8 LEAN_PATH=/workspace/p196-agent1-onboarding/core-build/consolidation-core/source /workspace/p196-tools/lean-4.19.0-linux/bin/lean --trust=0 -j1 -DElab.async=false core-print-axioms.lean
```

Retain stdout/stderr in `core-print-axioms.log`, exit status, and a machine-readable per-endpoint outcome record. The only project dependency objects must come from the just-clean build directory; bundled official Lean libraries remain necessary. This is a supplemental imported-object recheck and endpoint inspection, not a second independent clean source rebuild. At preparation time the parent build status was `RUNNING`; the audit has not executed.

| Registry claim | Source-level comparison and preserved restrictions |
| --- | --- |
| `agent113-thirteen-prefix` (15 endpoints) | `no_196_thirteen_arith` assumes the iterate is palindromic and excludes the listed thirteen quotients by powers of ten; it does not prove every iterate nonpalindromic. `startsTwo_iff` supplies exact digit-range and arithmetic-prefix equivalence. The 13 `ExactDepth` theorems combine an ancestry bound for every positive start with an attained first-palindrome witness. Their bounds are 10:1, 20:2, 32:2, 40:3, 41:3, 60:3, 64:3, 65:6, 76:3, 80:4, 81:4, 82:4, 83:4. |
| `agent3-five-step-charge` (3 endpoints) | The conclusion is **charge modulo 11 equals zero**, for the defined outer list map, with `Valid` initial state and time at least five. The return theorem additionally assumes a positive return period. Sharpness is witnessed by state `(1, [])`, with nonzero residue at time four and zero at five. This supplies no ordinary-integer semiconjugacy. |
| `agent9-alternating-spatial-boundary` (2 endpoints) | Contradiction follows from a finite spatial chain of `Step` relations between the specified constant root trace and either specified tail. `Trace` is a time-indexed slot function and `Step` existentially supplies the exact local tile equations. No actual reverse-add orbit bridge is asserted. |
| `agent11-high-base-first-hit` (3 endpoints) | `numeric_two_step_threshold` requires canonical positive digits, integer base at least three, pair sums in `[b-1, 2b-2]`, and outer pair sum at least `b`; its second-output palindrome criterion is the adjacent-sum bound. `numeric_interval_first_hit` uses the **smaller** upper bound `b+(b-1)/2-1` and concludes first positive time one or two, with exact cases. `binary_threshold_counterexample` is a concrete base-two exception, not an instance of the base-at-least-three theorem. The threshold and binary-control declarations originate in imported `HighBaseNumeric`, despite the claim root being `HighBaseFirstHit`; both belong to the registered closure. |
| `agent10-nine-carry-reconstruction` (2 endpoints) | Requires complete equal carry words at times zero through eight and a common admissible initial width; equality includes terminal carry positions. The abstract endpoint concludes pair-sum equality within that width. Its numeric consequence requires canonical digit representations and concludes equality of the **next** reverse-add integers, not the initial integers. |

The source-level descriptions are consistent with those restrictions. This comparison does not replace execution or assert unconditional Lychrel results. A correction was made to `verification-plan.md`: the generated audit uses `collectAxioms`, while original proof sources themselves already include some literal `#print axioms` commands.

## Executed result

Supplemental audit completed with **PASS**, exit **0**, using `--trust=0` and only the fresh core build’s project objects. All **25** endpoint statements and **25** distinct axiom lists were parsed, with no errors or disallowed axioms. The axiom union is `{propext, Classical.choice, Quot.sound}`. Twenty-three endpoints list all three; `P196.Agent3.Charge.five_step_bound_sharp` and `Agent11HighBase.binary_threshold_counterexample` list only `propext` and `Quot.sound`.

Successful evidence: `core-print-axioms-retry2.log`, `core-print-axioms-retry2.exit`, `core-print-axioms-retry2-run.json`, and `core-print-axioms-results.json` (all 25 individual outcomes and printed statements). The run record contains the exact working directory, isolated environment, command, source/toolchain/core-report/log hashes, and elapsed time. This was an imported-object recheck, not a duplicate clean build.

The first supplemental run exited 1 solely because its helper used unsupported presentation option `pp.width`. That source is retained as `core-print-axioms-attempt1.lean`; original failed evidence remains `core-print-axioms.log`, `core-print-axioms.exit`, and `core-print-axioms-run.json`. Only that option was removed from the helper before the successful run. No repository defect is implied; checkout remains unchanged.
