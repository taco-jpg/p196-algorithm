import OuterOrbit
import AlternatingScalarBoundary
import HighBaseFirstHit
import DifferenceObservability
import TwoDigitMain

/- Supplemental statement/axiom inspection of existing endpoints; no new theorem. -/
set_option pp.fullNames true

/- agent113-thirteen-prefix -/
#check @Agent113.TwoDigit.no_196_thirteen_arith
#print axioms Agent113.TwoDigit.no_196_thirteen_arith

#check @Agent113.TwoDigit.startsTwo_iff
#print axioms Agent113.TwoDigit.startsTwo_iff

#check @Agent113.TwoDigit.exact_depth_10
#print axioms Agent113.TwoDigit.exact_depth_10

#check @Agent113.TwoDigit.exact_depth_20
#print axioms Agent113.TwoDigit.exact_depth_20

#check @Agent113.TwoDigit.exact_depth_32
#print axioms Agent113.TwoDigit.exact_depth_32

#check @Agent113.TwoDigit.exact_depth_40
#print axioms Agent113.TwoDigit.exact_depth_40

#check @Agent113.TwoDigit.exact_depth_41
#print axioms Agent113.TwoDigit.exact_depth_41

#check @Agent113.TwoDigit.exact_depth_60
#print axioms Agent113.TwoDigit.exact_depth_60

#check @Agent113.TwoDigit.exact_depth_64
#print axioms Agent113.TwoDigit.exact_depth_64

#check @Agent113.TwoDigit.exact_depth_65
#print axioms Agent113.TwoDigit.exact_depth_65

#check @Agent113.TwoDigit.exact_depth_76
#print axioms Agent113.TwoDigit.exact_depth_76

#check @Agent113.TwoDigit.exact_depth_80
#print axioms Agent113.TwoDigit.exact_depth_80

#check @Agent113.TwoDigit.exact_depth_81
#print axioms Agent113.TwoDigit.exact_depth_81

#check @Agent113.TwoDigit.exact_depth_82
#print axioms Agent113.TwoDigit.exact_depth_82

#check @Agent113.TwoDigit.exact_depth_83
#print axioms Agent113.TwoDigit.exact_depth_83

/- agent3-five-step-charge -/
#check @P196.Agent3.Charge.charge_zero_from_five
#print axioms P196.Agent3.Charge.charge_zero_from_five

#check @P196.Agent3.Charge.returned_outer_charge_zero
#print axioms P196.Agent3.Charge.returned_outer_charge_zero

#check @P196.Agent3.Charge.five_step_bound_sharp
#print axioms P196.Agent3.Charge.five_step_bound_sharp

/- agent9-alternating-spatial-boundary -/
#check @Agent9.AlternatingScalarBoundary.no_six_boundary
#print axioms Agent9.AlternatingScalarBoundary.no_six_boundary

#check @Agent9.AlternatingScalarBoundary.no_twelve_boundary
#print axioms Agent9.AlternatingScalarBoundary.no_twelve_boundary

/- agent11-high-base-first-hit -/
#check @Agent11HighBase.numeric_two_step_threshold
#print axioms Agent11HighBase.numeric_two_step_threshold

#check @Agent11HighBase.numeric_interval_first_hit
#print axioms Agent11HighBase.numeric_interval_first_hit

#check @Agent11HighBase.binary_threshold_counterexample
#print axioms Agent11HighBase.binary_threshold_counterexample

/- agent10-nine-carry-reconstruction -/
#check @DifferenceObservability.nine_carry_words_determine_pair_sums
#print axioms DifferenceObservability.nine_carry_words_determine_pair_sums

#check @DifferenceObservability.nine_carry_words_determine_next_integer
#print axioms DifferenceObservability.nine_carry_words_determine_next_integer

/- Definitions needed to interpret the exported statements. -/
#print Agent113.TwoDigit.ExactDepth
#print Agent113.TwoDigit.SharpAt
#print Agent11HighBase.FirstPositivePalindrome
