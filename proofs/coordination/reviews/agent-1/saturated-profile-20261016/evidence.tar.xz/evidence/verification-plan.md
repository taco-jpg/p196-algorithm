# Verification findings for Agent #1

Prepared by subagent `/root/verification_plan` from checkout `4b4edf976b2c7a9ba1dad80636c0e21c66350325`. Read-only inspection and source-identity checks only; no Lean build, Git mutation, external message, or mathematical acceptance claim. Issue #61 access remains blocked according to the parent’s reported CONNECT 403; this note is available for attributed relay.

## Supported core build

From `/workspace/p196-algorithm`, use:

```sh
python3 -B proofs/verify_project.py --lean /absolute/path/to/lean-4.19.0-linux/bin/lean --project consolidation-core --output /absolute/new/output-directory
```

The output directory must **not already exist**. `-B` prevents Python bytecode output in the checkout. The current wrapper invokes `replay_original_layout.py`, which reconstructs the original layout in a retained temporary repository, then runs the mapped verifier. Do not run the flattened `verify_project__214bf7673efe116b.py` directly: its registry paths require that original layout. Sources: [wrapper](/workspace/p196-algorithm/proofs/verify_project.py:1), [replay](/workspace/p196-algorithm/proofs/replay_original_layout.py:15), [documented command](/workspace/p196-algorithm/proofs/README.md:9).

`SOURCE_MAP.json` pins original-layout base `2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5`; `proofs/verify_project.py` maps to current `proofs/verify_project__214bf7673efe116b.py`, byte-identical to its preserved original. The registry contains one project, 38 modules, five roots, and 25 claim endpoints. Roots: `OuterOrbit`, `AlternatingScalarBoundary`, `HighBaseFirstHit`, `DifferenceObservability`, `TwoDigitMain`. Sources: [mapping](/workspace/p196-algorithm/proofs/SOURCE_MAP.json:64125), [registry roots and claims](/workspace/p196-algorithm/proofs/ACCEPTED_BUILD.json:404).

## Dependencies and execution behavior

- Python standard library, Git, and official Lean **4.19.0, commit `6caaee842e94`, Release**. Python 3.9+ is needed for `Path.is_relative_to`. Core external imports are only `Lean` and `Std`; no Lake project, Mathlib, pip packages, or running services are needed for this check.
- Official Linux archive URL: `https://github.com/leanprover/lean4/releases/download/v4.19.0/lean-4.19.0-linux.tar.zst`; pinned SHA-256: `6fe3ce97a58f44e2b3567d455b994eacec5bfe9ae7774f2a573444480ba813fe`. Download/extraction needs curl, SHA-256 verification, tar, and zstd support. The historical core CI uses Ubuntu 24.04. [CI installation](/workspace/p196-algorithm/.github/workflows/agent1-consolidation-core.yml:39).
- The verifier compiles every registered module in dependency order into a new source directory with `-j1 -DElab.async=false`, isolated `LEAN_PATH`, and a 1,800-second timeout per command. It then executes `ProjectAudit.lean`. This is already a fresh project rebuild; do not delete checkout outputs or reuse old generated `.olean` files. [Verifier](/workspace/p196-algorithm/proofs/verify_project__214bf7673efe116b.py:141).
- Historical research requirements (`z3-solver==5.1.0.0`, `numpy==2.3.5`, `scipy==1.17.0`) belong to other workflows and are not imported by this verifier. [Archived requirements](/workspace/p196-algorithm/proofs/archive/source-trees/2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5/proofs/research/requirements.txt:1).

## Trust enforcement and required supplemental check

- The verifier checks registered SHA-256 and Git-blob identities, exact imports, root closure, and cycles. It masks comments/strings before rejecting `sorry`, `admit`, `axiom`, `sorryAx`, `native_decide`, `ofReduceBool`, and `skipKernelTC`. Only bundled `Init`/`Std`/`Lean` imports can fall outside the registry. One explicit foundation adapter verifies byte containment before generating a compatibility import. [Checks](/workspace/p196-algorithm/proofs/verify_project__214bf7673efe116b.py:107).
- Its generated audit examines every theorem originating in the selected modules using `Lean.collectAxioms`; the only permitted axioms are `propext`, `Classical.choice`, and `Quot.sound`. Safe custom axioms fail; unsafe implementation axioms are logged rather than automatically rejected, while any unapproved axiom in an audited theorem’s dependencies fails. Audit counts must be nonzero, unique, and consistent. Sources/build snapshots and compiler files are checked again for changes. [Audit](/workspace/p196-algorithm/proofs/verify_project__214bf7673efe116b.py:169).
- **Its generated `ProjectAudit.lean` uses `Lean.collectAxioms`, rather than literal `#print axioms` commands.** Original theorem sources also contain some `#print axioms` directives; those do execute during compilation. To provide one complete endpoint record for the session requirement, after a successful build create a separate temporary Lean audit file importing the five roots and containing `#print axioms <endpoint>` for each of the 25 registry endpoints. Execute it with the same official binary and `LEAN_PATH` pointing to the fresh `consolidation-core/source` directory; retain its command, exit status, and complete output. Keep this supplemental file outside the checkout and outside the verifier’s already-manifested evidence directory. Inspect exact theorem statements/hypotheses as well as axiom lists.
- Compiler hashes recorded by the verifier establish run consistency, not official-download authenticity; preserve the archive checksum verification during installation. The automated audit covers theorem declarations, not every arbitrary definition, and does not prove that a conditional theorem implies an unconditional research goal.

## Setup risks, scope, and efficient order

1. Verify the official runtime and its bundled `.olean` files, then invoke the supported wrapper once with a fresh output path. Replay reconstructs **all 9,161 mapped files**, about **492 MB** of selected source content, even for a scoped check or `--help`; it needs temporary disk space and the base Git object. Any unrelated mapped-file hash mismatch can block replay before Lean starts.
2. Preserve both the outer checkout commit and replay base. The verifier’s `source_commit` comes from the reconstructed repository and will identify the base, not outer checkout `4b4edf9…`; its cleanliness field is recorded but is not itself a failing condition.
3. Review `verification.json`, retained logs, theorem count, axiom union, and exit status; then perform the supplemental endpoint `#print axioms` check. No successful source-only mode substitutes for compilation.
4. If desired, match CI’s supplementary finite arithmetic controls using the mapped script [finite_controls__fbcd1dff8b4ee81f.py](/workspace/p196-algorithm/proofs/finite_controls__fbcd1dff8b4ee81f.py:1), with a new output filename and Python assertions enabled. These are bounded controls, not universal proofs.
5. `catalogue_complete` is false with blocker `PREEXISTING_ACCEPTED_SCOPE_CENSUS`. Scoped success must retain `repository_wide_pass=false`. Unscoped verification returns **2** for the incomplete catalogue; CI explicitly expects that exit code in `--check-only` mode. That mode still requires the pinned Lean binary, but performs no Lean proof compilation. [Status behavior](/workspace/p196-algorithm/proofs/verify_project__214bf7673efe116b.py:208), [CI expectation](/workspace/p196-algorithm/.github/workflows/agent1-consolidation-core.yml:60).

The CI file is historical: it explicitly checks out `a79036909714e34a2b8b7ccccd6d00caa6a04848`; its existence does not establish a successful current run. The README expressly limits replay to the corresponding original-mainline checks. Registry claims retain restricted-prefix, abstract-map, and exact-hypothesis scopes; no unrestricted Lychrel conclusion follows from a core PASS.

Checks actually completed here: base Git object exists; all 9,161 selected mapped paths exist; all 38 selected core files match both their mapping and registry SHA-256 pins; mapped verifier and registry match their preserved originals; checkout status was clean. I did not hash all non-core replay files or execute Lean. Runtime installation, replay execution, fresh compilation, and endpoint axiom output remain the parent’s execution tasks.
