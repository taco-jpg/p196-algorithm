import pathlib,json,hashlib,tarfile,shutil
src=pathlib.Path('/workspace/p196-agent1-onboarding')
out=pathlib.Path('/tmp/p196-agent1-coordination-20261016/proofs/coordination/reviews/agent-1/saturated-profile-20261016')
out.mkdir(parents=True,exist_ok=True)
selected=[];excluded=[]
for p in sorted(src.rglob('*')):
 if not p.is_file(): continue
 rel=p.relative_to(src)
 parts=rel.parts
 copied_source=(len(parts)>2 and parts[0] in ('core-build','saturated-profile-build') and 'source' in parts and p.name!='ProjectAudit.lean')
 if copied_source or p.suffix in ('.olean','.ilean','.pyc'):
  excluded.append({'path':str(rel),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'reason':'Reproducible compiled object or copied dependency source; original source commit and exact hashes are retained in build registry/receipt.'})
 else:selected.append(p)
manifest={str(p.relative_to(src)):{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in selected}
archive=out/'evidence.tar.xz'
with tarfile.open(archive,'w:xz') as t:
 for p in selected:t.add(p,arcname='evidence/'+str(p.relative_to(src)),recursive=False)
with tarfile.open(archive,'r:xz') as t:
 members=t.getmembers();assert len(members)==len(selected)
 for m in members:
  name=str(pathlib.PurePosixPath(m.name).relative_to('evidence'));data=t.extractfile(m).read();r=manifest[name]
  assert len(data)==r['bytes'] and hashlib.sha256(data).hexdigest()==r['sha256']
meta={'format':'tar.xz','stored_path':'evidence.tar.xz','stored_bytes':archive.stat().st_size,'stored_sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'original_selected_file_count':len(selected),'original_selected_bytes':sum(x['bytes'] for x in manifest.values()),'archive_members_verified':True,'files':manifest,'excluded_reproducible_infrastructure':excluded,'recovery_command':'mkdir evidence-recovery && tar -xJf evidence.tar.xz -C evidence-recovery','selection':'All substantive generated onboarding/review reports, failed and successful compiler/audit logs, audit sources, build/version receipts, finite control results, unsent drafts and exact reproduction scripts in this session. Copied dependency sources, compiled objects and cache products are explicitly excluded; source and object identities retained.'}
(out/'EVIDENCE.json').write_text(json.dumps(meta,indent=2)+'\n')
for name in ('saturated-profile-semantic-review.md','saturated-profile-source-identity.json','SETUP-RESULT.json','research-status.md'):
 shutil.copyfile(src/name,out/name)
print(json.dumps({k:meta[k] for k in ('stored_bytes','stored_sha256','original_selected_file_count','original_selected_bytes','archive_members_verified')},indent=2))
