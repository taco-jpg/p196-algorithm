import Agent2SaturatedProfile
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check Agent2.SaturatedProfile.saturatedEightCycleTarget
#check Agent2.SaturatedProfile.actualSaturatedEightCycleTarget
#check Agent2.SaturatedProfile.numeric_saturated_prefix_profile
#check Agent2.SaturatedProfile.closed_saturated_edges_tight
#check Agent2.SaturatedProfile.saturated_overflow_profile
run_cmd do
  let env ← getEnv
  let selected : List String := ["TemplateStep", "ReturnCertificate", "CertificateAccounting", "ExteriorCharge", "CertificateCharge", "LychrelDigitSums", "CertificateCarryBudget", "CertificatePhases", "CertificateConsequences", "PrefixModel", "CertificatePrefix", "SaturationCertificate", "SaturationTheorem", "CertificateSaturation", "WholeWordBridge", "Saturated8CycleProfile", "Agent2SaturatedProfile"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        match info with
        | .axiomInfo v =>
          if v.isUnsafe then logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {mod} {name}"
          else throwError m!"CUSTOM_AXIOM {mod} {name}"
        | .thmInfo _ =>
          count := count + 1
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          for ax in axl do
            if !(union.contains ax) then union := ax :: union
          if axl.any (fun ax => !(allowed.contains ax)) then throwError m!"DISALLOWED_AXIOMS {mod} {name} : {axl}"
          logInfo m!"AUDIT_THEOREM {mod} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
