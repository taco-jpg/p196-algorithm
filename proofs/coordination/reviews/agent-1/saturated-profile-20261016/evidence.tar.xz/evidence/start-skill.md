Use the existing checkout at `/workspace/p196-algorithm`. Each cloud task is already isolated; do not create a Git worktree unless the user explicitly requests one. Read `AGENTS.md` and current task instructions before research or publication. Preserve tracked sources, tests, dependency declarations, lockfiles, historical evidence, and existing user changes during environment setup.

The prepared local workflow is Lean 4.19.0, commit `6caaee842e94`, with its official bundled Std/Lean libraries, Python 3, and Git. It needs no background service or Mathlib installation. The toolchain and checksum-verified download are retained under `/workspace/p196-tools`; processes need not survive publication. Use the saved install script if the toolchain is absent. Run from the repository root:

```sh
cd /workspace/p196-algorithm
p196_lean=/workspace/p196-tools/lean-4.19.0-linux/bin/lean
"$p196_lean" --version
git status --short --branch
p196_run=$(mktemp -d /tmp/p196-validation.XXXXXX)
python3 -u -B proofs/verify_project.py --lean "$p196_lean" --project consolidation-core --output "$p196_run/core"
python3 -B proofs/verify_release.py
python3 -B proofs/finite_controls__fbcd1dff8b4ee81f.py --output "$p196_run/finite-controls.json"
```

Check the actual exit statuses and `$p196_run/core/verification.json`: require scoped `PASS`, 38 compiled modules, and the completed nonzero theorem audit. The wrapper reconstructs the historical layout in a retained temporary directory, verifies source-map hashes, and runs the original source-pinned core. Record the outer checkout commit separately from the reconstructed base (`2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5`). Release-integrity output concerns this reconstructed historical layout; finite controls supplement the Lean proofs. Neither establishes repository-wide correctness. Do not omit failed commands when collecting logs.

The global accepted catalogue is deliberately incomplete. An unscoped verifier can return exit 2 for that reason; `--check-only` is source/import inspection, not proof execution. Do not claim a global PASS or a theorem about all-time nonpalindromicity of 196. Optional solver discovery uses separately pinned research requirements; it is not needed for this Lean workflow and is not installed by the setup script.

For the later integrated saturated-profile package, use its own current-layout registry, rather than the historical wrapper:

```sh
python3 -u -B proofs/verify_project__214bf7673efe116b.py --registry proofs/Agent2SaturatedProfile.registry.json --project agent2-saturated-profile --lean "$p196_lean" --output "$p196_run/saturated-profile"
```

Require 17 compiled modules, `ProjectAudit` success, and `verification.json` scoped PASS. This target includes literal axiom prints for all 14 Agent2 exports. Its closure/saturation assumptions remain conditional; no accepted return-certificate instance is supplied.

For research proof acceptance, inspect exact statements and transitive dependencies. Reject sorry/admit/sorryAx, unjustified axioms, native_decide and compiler-trusted shortcuts in the accepted chain. The permitted baseline is `propext`, `Classical.choice`, and `Quot.sound`, reported explicitly. After a clean build, a supplemental file outside the checkout can import the selected roots and run `#check`/`#print axioms` for each exported endpoint. Execute it with `LEAN_PATH` set to that fresh project's `source` directory and `"$p196_lean" --trust=0 /absolute/path/to/audit.lean`; retain exact source hashes, commands, exit status, and logs. Independent semantic review is separate from compilation.

For collaborative research, follow the current user's Agent identifier and coordinate ordinary inter-agent messages only through existing GitHub issue #61. Use supported GitHub tooling, paginate relevant comments, retain the last-seen comment reference, and confirm comment delivery. Never use Discussions. Fetch current `main`, relevant contribution branches, and `p196/coordination`; respect published task claims and the serialized integration role before substantial investigation or shared mutation. Use local isolated contributions and the repository's existing coordination protocol; no automatic main write or force push.

Git reads work through the supplied HTTPS proxy; credentials must never be printed or copied. During onboarding, GitHub API access failed at CONNECT with proxy 403 to `api.github.com`; that domain was saved as an environment network requirement. A draft save does not apply or publish it. After settings are applied, retry `gh api repos/taco-jpg/p196-algorithm/issues/61`; then inspect/paginate comments and authenticate the specific write before claiming any sent message. Until access works, report ISSUE_CHAT_BLOCKED and keep check-ins explicitly UNSENT. Do not request a duplicate token merely because access is blocked or a token variable is absent.
