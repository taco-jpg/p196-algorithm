#!/usr/bin/env python3
"""Agent #7: retain exact execution parameters for the short endpoint supplement."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess
import time

BASE = Path(__file__).resolve().parent
BUILD = BASE / 'strict-001' / 'agent5-stream-agreement-window' / 'source'
AUDIT = BASE / 'EndpointAudit.lean'
LEAN = Path('/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean')
RECEIPT = BASE / 'ENDPOINT_PROVENANCE_RECEIPT.json'
LOG = BASE / 'EndpointProvenance.log'

def digest(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()

if RECEIPT.exists() or LOG.exists():
    raise SystemExit('Refusing to overwrite an existing provenance supplement')
original = json.loads((BASE / 'ENDPOINT_AUDIT_RECEIPT.json').read_text())
strict = json.loads((BASE / 'STRICT_RUN_RECEIPT.json').read_text())
assert strict['status'] == 'PASS' and strict['exit_code'] == 0
assert original['status'] == 'PASS' and original['exit_code'] == 0
assert original['audit_sha256'] == digest(AUDIT)
assert digest(LEAN) == '92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023'
command = [str(LEAN), '--trust=0', '-j1', '-DElab.async=false', str(AUDIT)]
environment = {'PATH': '/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LEAN_PATH': str(BUILD)}
receipt = {
    'agent': 'Agent #7',
    'purpose': 'Explicit provenance supplement for the same 26 endpoints; this is not another closure build.',
    'original_receipt_preserved': True,
    'original_cwd_and_lean_path': 'NOT_RETAINED in the first endpoint receipt; no inferred values are attributed to that execution.',
    'source_head': strict['source_head'],
    'command': command,
    'cwd': str(BASE),
    'environment': environment,
    'dependency_objects': 'Fresh strict-001 output of the exact 17-module source closure; no additional project object directories.',
    'strict_receipt_sha256': digest(BASE / 'STRICT_RUN_RECEIPT.json'),
    'audit_sha256': digest(AUDIT),
    'lean_sha256': digest(LEAN),
    'driver_sha256': digest(Path(__file__)),
    'started_at_epoch': time.time(),
}
with LOG.open('wb') as output:
    result = subprocess.run(command, cwd=BASE, env=environment, stdout=output, stderr=subprocess.STDOUT)
receipt.update({
    'finished_at_epoch': time.time(),
    'exit_code': result.returncode,
    'status': 'PASS' if result.returncode == 0 else 'FAIL',
    'log_sha256': digest(LOG),
    'log_bytes': LOG.stat().st_size,
    'byte_identical_to_original_endpoint_log': LOG.read_bytes() == (BASE / 'EndpointAudit.log').read_bytes(),
})
RECEIPT.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
raise SystemExit(result.returncode)
