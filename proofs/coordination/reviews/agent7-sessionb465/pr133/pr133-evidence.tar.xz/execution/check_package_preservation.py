#!/usr/bin/env python3
"""Agent #7: bind the complete PR delta and retained historical evidence to exact H."""
from __future__ import annotations
import hashlib
import json
from pathlib import Path
import subprocess

BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'source'
OBSERVATIONS = json.loads((BASE / 'REMOTE_BEFORE_CORRECTION.json').read_text())
HEAD = '9b1535d80ab3cb32d131306f089bcf524482ab09'

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

changes = OBSERVATIONS['files']
assert len(changes) == 27
checked = []
json_files = []
for item in changes:
    assert item['status'] == 'added' and item['deletions'] == 0
    path = item['filename']
    data = (SOURCE / path).read_bytes()
    oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    actual = subprocess.check_output(['git', '-C', str(SOURCE), 'rev-parse', HEAD + ':' + path]).decode().strip()
    assert oid == actual == item['sha']
    checked.append({'path': path, 'bytes': len(data), 'sha256': sha(data), 'git_blob': oid})
    if path.endswith('.json'):
        json.loads(data)
        json_files.append(path)

author = SOURCE / 'proofs/contributions/agent-5/stream-agreement-window-20261016/author/window'
manifest = json.loads((author / 'artifact-index.json').read_text())
for item in manifest['files']:
    data = (author / item['path']).read_bytes()
    assert len(data) == item['bytes'] and sha(data) == item['sha256']
registry = json.loads((SOURCE / 'proofs/Agent5StreamAgreementWindow.registry.json').read_text())
modules = registry['projects']['agent5-stream-agreement-window']['modules']
assert all('/attempts/' not in m['path'] and '/author/' not in m['path'] for m in modules.values())
assert (author / 'attempts/003/StreamAgreementWindow.lean').read_bytes() == (author.parent.parent / 'StreamAgreementWindow.lean').read_bytes()
assert 'sorryAx' in (author / 'attempts/001/compiler.log').read_text()
assert 'Failed' in (author / 'README.md').read_text()
receipt = {
    'agent': 'Agent #7',
    'source_head': HEAD,
    'status': 'PASS',
    'scope': 'Complete 27-path addition delta, JSON parseability, author 15-member byte manifest, final source equality and failed-attempt exclusion from accepted imports.',
    'changed_files': checked,
    'added': len(checked), 'modified': 0, 'deleted': 0,
    'json_files_parsed': json_files,
    'author_manifest_entries_checked': len(manifest['files']),
    'historical_failed_attempt_preserved': True,
    'failed_attempt_in_accepted_closure': False,
    'original_wip_and_not_run_records_preserved': True,
    'mathematical_source_changes_by_agent7': 0,
    'driver_sha256': sha(Path(__file__).read_bytes()),
}
(BASE / 'SCOPE_AND_PRESERVATION.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ['status', 'added', 'modified', 'deleted', 'author_manifest_entries_checked', 'mathematical_source_changes_by_agent7']}))
