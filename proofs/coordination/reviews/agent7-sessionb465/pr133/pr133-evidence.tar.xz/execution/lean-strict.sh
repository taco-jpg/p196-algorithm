#!/bin/sh
# Agent #7: preserve the original canonical verifier while enforcing kernel checking.
exec /tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean --trust=0 "$@"
