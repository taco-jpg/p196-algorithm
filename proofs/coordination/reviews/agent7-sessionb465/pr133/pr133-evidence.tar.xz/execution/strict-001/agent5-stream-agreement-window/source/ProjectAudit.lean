import StreamAgreementWindow
import StreamWindowSharpness
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check Agent5.OrdinaryStreamWindow.take_prefix_replicate
#check Agent5.OrdinaryStreamWindow.paired_bands_window
#check Agent5.OrdinaryStreamWindow.surrounded_raw_exterior_window
#check Agent5.OrdinaryStreamWindow.ordinary_raw_prefix_from_normalized_streams_window
#check Agent5.OrdinaryStreamWindow.ordinary_raw_prefix_from_streams_window
#check Agent5.OrdinaryStreamWindow.ordinary_raw_prefix_from_streams_window_quotient
#check Agent5.OrdinaryStreamWindow.ordinary_reverse_add_from_streams_window
#check Agent5.OrdinaryStreamWindow.Sharpness.D0
#check Agent5.OrdinaryStreamWindow.Sharpness.D1
#check Agent5.OrdinaryStreamWindow.Sharpness.D0_decimal
#check Agent5.OrdinaryStreamWindow.Sharpness.D1_decimal
#check Agent5.OrdinaryStreamWindow.Sharpness.D0_positive_last
#check Agent5.OrdinaryStreamWindow.Sharpness.D1_positive_last
#check Agent5.OrdinaryStreamWindow.Sharpness.D0_paired
#check Agent5.OrdinaryStreamWindow.Sharpness.D1_paired
#check Agent5.OrdinaryStreamWindow.Sharpness.D0_reverseAddDigits
#check Agent5.OrdinaryStreamWindow.Sharpness.D1_reverseAddDigits
#check Agent5.OrdinaryStreamWindow.Sharpness.D0_first_excluded_prefix
#check Agent5.OrdinaryStreamWindow.Sharpness.D1_first_excluded_prefix
#check Agent5.OrdinaryStreamWindow.Sharpness.empty_exterior_carry_controls
#check Agent5.OrdinaryStreamWindow.Sharpness.D0_coordinate_streams
#check Agent5.OrdinaryStreamWindow.Sharpness.D1_coordinate_streams
#check Agent5.OrdinaryStreamWindow.Sharpness.D0_stream_mismatch
#check Agent5.OrdinaryStreamWindow.Sharpness.D1_stream_mismatch
#check Agent5.OrdinaryStreamWindow.Sharpness.gap_zero_actual_prefixes
#check Agent5.OrdinaryStreamWindow.Sharpness.gap_zero_stream_prefixes
run_cmd do
  let env ← getEnv
  let selected : List String := ["OuterFinite", "TARGET", "ExteriorFactorizationProof", "DigitDefinitions", "AdicDigits", "FractionDigits", "CoordinateStreams", "CoordinateThreshold", "CoordinateOnlyStreams", "ExteriorCore", "ExteriorBridge", "ExteriorProjection", "ExteriorArithmetic", "RawPrefixStreams", "OrdinaryStreamStep", "StreamAgreementWindow", "StreamWindowSharpness"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        match info with
        | .axiomInfo v =>
          if v.isUnsafe then logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {mod} {name}"
          else throwError m!"CUSTOM_AXIOM {mod} {name}"
        | .thmInfo _ =>
          count := count + 1
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          for ax in axl do
            if !(union.contains ax) then union := ax :: union
          if axl.any (fun ax => !(allowed.contains ax)) then throwError m!"DISALLOWED_AXIOMS {mod} {name} : {axl}"
          logInfo m!"AUDIT_THEOREM {mod} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
