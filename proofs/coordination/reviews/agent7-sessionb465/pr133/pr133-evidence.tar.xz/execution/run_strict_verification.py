#!/usr/bin/env python3
"""Agent #7: run the unchanged PR133 verifier with an explicit trust-zero launcher."""
from __future__ import annotations
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

BASE = Path(__file__).resolve().parent
SOURCE = BASE / 'source'
HEAD = '9b1535d80ab3cb32d131306f089bcf524482ab09'
PROJECT = 'agent5-stream-agreement-window'
OUT = BASE / 'strict-001'
VERIFIER = SOURCE / 'proofs/verify_project__214bf7673efe116b.py'
REGISTRY = SOURCE / 'proofs/Agent5StreamAgreementWindow.registry.json'
LAUNCHER = BASE / 'lean-strict.sh'

def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def git(*args: str) -> bytes:
    return subprocess.check_output(['git', '-C', str(SOURCE), *args])

if OUT.exists():
    raise SystemExit('Refusing to overwrite an existing verification run')
assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert not git('status', '--porcelain', '--untracked-files=no')
registry = json.loads(REGISTRY.read_bytes())
source_records = []
for module, entry in registry['projects'][PROJECT]['modules'].items():
    data = (SOURCE / entry['path']).read_bytes()
    oid = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    remote_oid = git('rev-parse', HEAD + ':' + entry['path']).decode().strip()
    assert sha256(data) == entry['sha256']
    assert oid == entry['git_blob'] == remote_oid
    source_records.append({'module': module, 'path': entry['path'], 'bytes': len(data), 'sha256': sha256(data), 'git_blob': oid})
assert len(source_records) == 17
command = [sys.executable, '-B', str(VERIFIER), '--registry', str(REGISTRY), '--project', PROJECT, '--lean', str(LAUNCHER), '--output', str(OUT)]
receipt = {
    'agent': 'Agent #7',
    'status': 'RUNNING',
    'source_head': HEAD,
    'source_tree': git('rev-parse', HEAD + '^{tree}').decode().strip(),
    'tracked_source_clean': True,
    'source_modules': source_records,
    'registry_sha256': sha256(REGISTRY.read_bytes()),
    'verifier_git_blob': git('rev-parse', HEAD + ':proofs/verify_project__214bf7673efe116b.py').decode().strip(),
    'verifier_sha256': sha256(VERIFIER.read_bytes()),
    'verifier_unchanged': True,
    'launcher_sha256': sha256(LAUNCHER.read_bytes()),
    'launcher_policy': 'The inspected launcher execs the pinned official Lean binary with --trust=0 before every unchanged verifier argument.',
    'original_verifier_agent_field': 'Agent #1 is the unchanged script provenance; this run was executed by Agent #7.',
    'command': command,
    'started_at_epoch': time.time(),
    'repository_wide_pass': False,
    'fresh_output_directory': True,
    'reused_project_olean': False,
}
receipt_path = BASE / 'STRICT_RUN_RECEIPT.json'
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
driver = BASE / 'strict-001.driver.log'
with driver.open('w', encoding='utf-8') as log:
    process = subprocess.Popen(command, cwd=SOURCE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1)
    assert process.stdout is not None
    for line in process.stdout:
        log.write(line)
        log.flush()
        print(line, end='', flush=True)
    rc = process.wait()
receipt.update({'status': 'PASS' if rc == 0 else 'FAIL', 'exit_code': rc, 'finished_at_epoch': time.time(), 'driver_log_sha256': sha256(driver.read_bytes()), 'tracked_source_clean_after': not git('status', '--porcelain', '--untracked-files=no')})
if (OUT / 'verification.json').exists():
    verification = json.loads((OUT / 'verification.json').read_bytes())
    receipt['canonical_status'] = verification['status']
    receipt['canonical_verification_sha256'] = sha256((OUT / 'verification.json').read_bytes())
    project_report = verification.get('projects', {}).get(PROJECT, {})
    receipt['theorem_count'] = project_report.get('theorem_count')
    receipt['axiom_union'] = project_report.get('axiom_union')
receipt_path.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({key: receipt.get(key) for key in ['status', 'exit_code', 'canonical_status', 'theorem_count', 'axiom_union']}), flush=True)
raise SystemExit(rc)
