#!/usr/bin/env python3
"""Independent source identity, root closure, and endpoint binding; no Lean execution."""
from pathlib import Path
import hashlib
import importlib.util
import json
import re
import subprocess

OUT = Path(__file__).resolve().parent
SOURCE = OUT.parent / "pr133/source"
H = "9b1535d80ab3cb32d131306f089bcf524482ab09"
BASE = "5c4d394f20b70547aa7cb8dd14091bcd391e424c"
spec = importlib.util.spec_from_file_location("inspected_canonical_verifier", SOURCE / "proofs/verify_project__214bf7673efe116b.py")
verifier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verifier)
registry_path = SOURCE / "proofs/Agent5StreamAgreementWindow.registry.json"
registry = json.loads(registry_path.read_bytes())
project = registry["projects"]["agent5-stream-agreement-window"]
records = project["modules"]
sha256 = lambda b: hashlib.sha256(b).hexdigest()
blob = lambda b: hashlib.sha1(f"blob {len(b)}\0".encode() + b).hexdigest()
rows, source_codes, declarations = [], {}, {}
for module, rec in records.items():
    data = (SOURCE / rec["path"]).read_bytes()
    filename = module + (".lean" if module.startswith("Stream") else "") + ".response.json"
    raw = json.loads((OUT / "remote" / filename).read_bytes())
    response = raw.get("value", raw)["structuredContent"]
    code = verifier.code_only(data.decode())
    imports = [dep for line in re.findall(r"^\s*import\s+([^\n]+)", code, re.M) for dep in line.split()]
    forbidden = re.findall(r"(?<![\w'])\b(?:sorry|admit|axiom|sorryAx|native_decide|ofReduceBool|skipKernelTC)\b(?![\w'])", code)
    parent_data = None
    if not module.startswith("Stream"):
        parent_data = subprocess.check_output(["git", "show", f"{BASE}:{rec['path']}"], cwd=SOURCE)
    row = {"module": module, "path": rec["path"], "bytes": len(data), "lines": len(data.splitlines()),
           "sha256": sha256(data), "git_blob": blob(data),
           "registry_sha256_matches": sha256(data) == rec["sha256"],
           "registry_git_blob_matches": blob(data) == rec["git_blob"],
           "remote_exact_H_content_matches": response["content"].encode() == data,
           "remote_exact_H_blob_matches": response["sha"] == blob(data),
           "imports": imports, "imports_match_registry": imports == rec["imports"],
           "forbidden_source_tokens": forbidden,
           "unchanged_from_PR121_base": None if parent_data is None else parent_data == data}
    assert all(row[key] for key in ["registry_sha256_matches", "registry_git_blob_matches",
                                   "remote_exact_H_content_matches", "remote_exact_H_blob_matches",
                                   "imports_match_registry"])
    assert not forbidden
    assert parent_data is None or parent_data == data
    rows.append(row)
    source_codes[module] = code
    ns = re.search(r"^namespace\s+(\S+)", code, re.M).group(1)
    declarations[module] = [{"kind": m.group(1), "name": ns + "." + m.group(2)}
                            for m in re.finditer(r"^(?:@\[[^\n]*\]\s*)?(def|theorem)\s+(\S+)", code, re.M)]
active, seen, order = set(), set(), []
def visit(module):
    if module == "Std":
        return
    assert module in records
    assert module not in active
    if module in seen:
        return
    active.add(module)
    for dependency in records[module]["imports"]:
        visit(dependency)
    active.remove(module)
    seen.add(module)
    order.append(module)
for root in project["roots"]:
    visit(root)
assert seen == set(records)
root_declarations = [decl for root in project["roots"] for decl in declarations[root]]
endpoints = [endpoint for claim in registry["claims"] if claim["project"] == "agent5-stream-agreement-window"
             for endpoint in claim["endpoints"]]
assert sorted(endpoints) == sorted(decl["name"] for decl in root_declarations)
remote_registry = json.loads((OUT / "remote/Agent5StreamAgreementWindow.registry.json.response.json").read_bytes())["value"]["structuredContent"]
assert remote_registry["content"].encode() == registry_path.read_bytes()
assert remote_registry["sha"] == blob(registry_path.read_bytes())
result = {"reviewer": "Agent #7 independent semantic/source review specialist",
          "source_head": H, "prerequisite_head": BASE,
          "observed_local_head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=SOURCE, text=True).strip(),
          "registry_sha256": sha256(registry_path.read_bytes()),
          "registry_git_blob": blob(registry_path.read_bytes()),
          "status": "SOURCE_BINDING_PASS",
          "lean_execution": "NOT_PERFORMED_BY_THIS_REVIEWER",
          "root_closure_exact": True, "root_closure_modules": len(rows), "topological_order": order,
          "all_fifteen_prerequisites_unchanged": True,
          "all_twenty_six_root_declarations_registered_exactly_once": True,
          "root_theorem_count": sum(d["kind"] == "theorem" for d in root_declarations),
          "root_definition_count": sum(d["kind"] == "def" for d in root_declarations),
          "root_declarations": root_declarations, "modules": rows}
assert result["observed_local_head"] == H
(OUT / "SOURCE_BINDING.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k: v for k, v in result.items() if k not in {"modules", "root_declarations", "topological_order"}}, indent=2))

