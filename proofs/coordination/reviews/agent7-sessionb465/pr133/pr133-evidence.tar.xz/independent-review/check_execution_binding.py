#!/usr/bin/env python3
"""Independently bind the parent's completed execution records; does not invoke Lean."""
from pathlib import Path
import collections
import hashlib
import json
import re

OUT = Path(__file__).resolve().parent
PARENT = OUT.parent / "pr133"
RUN = PARENT / "strict-001"
PROJECT = "agent5-stream-agreement-window"
SOURCE = PARENT / "source"
sha256 = lambda b: hashlib.sha256(b).hexdigest()
read = lambda p: json.loads(p.read_bytes())
receipt = read(PARENT / "STRICT_RUN_RECEIPT.json")
verification = read(RUN / "verification.json")
project = verification["projects"][PROJECT]
binding = read(OUT / "SOURCE_BINDING.json")
registry = read(SOURCE / "proofs/Agent5StreamAgreementWindow.registry.json")
expected = registry["projects"][PROJECT]
endpoints = [e for c in registry["claims"] for e in c["endpoints"]]
assert receipt["source_head"] == verification["source_commit"] == binding["source_head"]
assert receipt["status"] == verification["status"] == project["status"] == "PASS"
assert receipt["exit_code"] == 0
assert receipt["tracked_source_clean"] and receipt["tracked_source_clean_after"]
assert not verification["repository_wide_pass"]
assert receipt["canonical_verification_sha256"] == sha256((RUN / "verification.json").read_bytes())
assert receipt["driver_log_sha256"] == sha256((PARENT / "strict-001.driver.log").read_bytes())
assert receipt["registry_sha256"] == verification["registry_sha256"] == binding["registry_sha256"]
assert receipt["launcher_sha256"] == sha256((PARENT / "lean-strict.sh").read_bytes())
assert receipt["verifier_sha256"] == sha256((SOURCE / "proofs/verify_project__214bf7673efe116b.py").read_bytes())
assert project["build_order"] == binding["topological_order"]
assert project["roots"] == expected["roots"]
assert project["endpoints"] == endpoints
assert len(project["commands"]) == 18
assert [c["label"] for c in project["commands"]] == project["build_order"] + ["ProjectAudit"]
for command in project["commands"]:
    assert command["exit_code"] == 0
    assert command["argv"][0] == str(PARENT / "lean-strict.sh")
    assert command["argv"][1:3] == ["-j1", "-DElab.async=false"]
    assert sha256((RUN / command["log"]).read_bytes()) == command["log_sha256"]
for module, entry in expected["modules"].items():
    original = (SOURCE / entry["path"]).read_bytes()
    staged = (RUN / PROJECT / "source" / (module + ".lean")).read_bytes()
    assert original == staged
    assert sha256(staged) == entry["sha256"] == project["sources"][module]["build_sha256"]
for path, entry in read(RUN / "FILES.json").items():
    data = (RUN / path).read_bytes()
    assert len(data) == entry["bytes"] and sha256(data) == entry["sha256"]
for path, digest in verification["compiler"]["files"].items():
    assert sha256(Path(path).read_bytes()) == digest
audit_path = RUN / PROJECT / "logs/ProjectAudit.log"
audit = audit_path.read_text()
declarations = re.findall(r"^AUDIT_THEOREM (\S+) (\S+) : \[([^\]]*)\]", audit, re.M)
assert len(declarations) == len({row[1] for row in declarations}) == project["theorem_count"] == 302
allowed = {"propext", "Classical.choice", "Quot.sound"}
audited = {}
union = set()
counts = collections.Counter()
for module, name, raw_axioms in declarations:
    axs = [s.strip() for s in raw_axioms.split(",") if s.strip()]
    assert set(axs) <= allowed
    assert module in expected["modules"]
    counts[module] += 1
    union.update(axs)
    audited[name] = {"module": module, "axioms": axs}
assert union == allowed
assert not re.search(r"^CUSTOM_AXIOM|^DISALLOWED_AXIOMS", audit, re.M)
for item in binding["root_declarations"]:
    if item["kind"] == "theorem":
        assert item["name"] in audited
unsafe = re.findall(r"^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$", audit, re.M)
assert [list(x) for x in unsafe] == project["unsafe_implementation_axioms"]
assert len(unsafe) == 3
supplement = read(PARENT / "ENDPOINT_AUDIT_RECEIPT.json")
assert supplement["source_head"] == binding["source_head"]
assert supplement["status"] == "PASS" and supplement["exit_code"] == 0
assert supplement["audit_sha256"] == sha256((PARENT / "EndpointAudit.lean").read_bytes())
assert supplement["log_sha256"] == sha256((PARENT / "EndpointAudit.log").read_bytes())
assert supplement["command"][1:4] == ["--trust=0", "-j1", "-DElab.async=false"]
supp_source = (PARENT / "EndpointAudit.lean").read_text()
assert re.findall(r"^#check (\S+)$", supp_source, re.M) == endpoints
assert re.findall(r"^#print axioms (\S+)$", supp_source, re.M) == endpoints
supp_log = (PARENT / "EndpointAudit.log").read_text()
endpoint_axioms = {}
for name, raw in re.findall(r"^'([^']+)' depends on axioms: \[([^\]]*)\]", supp_log, re.M):
    assert name not in endpoint_axioms
    endpoint_axioms[name] = [s.strip() for s in raw.split(",") if s.strip()]
for name in re.findall(r"^'([^']+)' does not depend on any axioms$", supp_log, re.M):
    assert name not in endpoint_axioms
    endpoint_axioms[name] = []
assert set(endpoint_axioms) == set(endpoints)
assert all(set(a) <= allowed for a in endpoint_axioms.values())
assert endpoint_axioms["Agent5.OrdinaryStreamWindow.Sharpness.D0"] == []
assert endpoint_axioms["Agent5.OrdinaryStreamWindow.Sharpness.D1"] == []
files = [PARENT / "STRICT_RUN_RECEIPT.json", RUN / "verification.json", RUN / "FILES.json",
         PARENT / "lean-strict.sh", PARENT / "run_strict_verification.py", PARENT / "strict-001.driver.log",
         RUN / PROJECT / "source/ProjectAudit.lean", audit_path,
         PARENT / "ENDPOINT_AUDIT_RECEIPT.json", PARENT / "EndpointAudit.lean", PARENT / "EndpointAudit.log"]
snapshots = OUT / "parent-execution-snapshots"
snapshots.mkdir(exist_ok=False)
identities = []
for path in files:
    data = path.read_bytes()
    target = snapshots / path.name
    target.write_bytes(data)
    identities.append({"parent_path": str(path), "snapshot_path": str(target.relative_to(OUT)),
                       "bytes": len(data), "sha256": sha256(data)})
result = {
    "reviewer": "Agent #7 independent semantic/source review specialist",
    "source_head": binding["source_head"],
    "status": "EXECUTION_EVIDENCE_PASS",
    "execution_owner": "Agent #7 parent",
    "reviewer_ran_lean": False,
    "canonical_module_commands": 17,
    "canonical_audit_commands": 1,
    "all_commands_exit_zero": True,
    "canonical_logs_hash_verified": True,
    "canonical_FILES_manifest_verified": True,
    "all_staged_source_bytes_match_exact_H": True,
    "pinned_compiler_files_unchanged": True,
    "strict_launcher_inspected": True,
    "canonical_verifier_unchanged": True,
    "audited_theorem_constant_count": len(audited),
    "per_origin_module_theorem_counts": dict(counts),
    "axiom_union": sorted(union),
    "unsafe_implementation_axioms": unsafe,
    "unsafe_implementation_axioms_in_any_accepted_theorem_dependency": False,
    "endpoint_count": len(endpoint_axioms),
    "endpoint_axioms": endpoint_axioms,
    "scope": "Exact PR133 seventeen-module closure only; no repository-wide or current-main combined-tree result.",
    "snapshots": identities,
}
(OUT / "EXECUTION_BINDING.json").write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({k:v for k,v in result.items() if k not in {"snapshots","endpoint_axioms","per_origin_module_theorem_counts"}}, indent=2))

