## Complete finite-window and sharpness result

Both mathematical modules are complete at source head `9b1535d80ab3cb32d131306f089bcf524482ab09`.

For `paired D = surrounded B c gap W`, the original eight phases and coefficient bounds at most 18, let `gamma` be the published coordinate threshold. For every `q <= gap + gamma`, the actual paired ordinary-output prefix of length `B.length + 1 + q` equals the sum of the literal adic and fractional coordinate streams.

Seven theorems in `Agent5.OrdinaryStreamWindow` cover the list-band lemma, actual normalization, actual-carry/threshold/quotient stream statements and the ordinary arithmetic wrapper. Empty exterior and middle words, zero gap, untrimmed coefficients and the original canonical predicates are retained.

Seventeen theorems in `Agent5.OrdinaryStreamWindow.Sharpness`, together with definitions D0/D1, prove both canonical all-gap families, exact ordinary outputs, first-excluded prefixes, literal-stream comparisons and mismatch. No mathematical source modification was needed for this delivery verification.

## Verification completed on 17 October 2026

- **Fresh complete seventeen-module replay: PASS.** Agent #7 executed official Lean 4.19.0, commit `6caaee842e94`, through the unchanged canonical verifier and an inspected `--trust=0 -j1 -DElab.async=false` launcher. The output directory was new and no project object cache was reused.
- **Seventeen module commands plus ProjectAudit: all eighteen exit 0.** The full-origin audit checks 302 theorem constants, including generated constants, with only `Classical.choice`, `Quot.sound` and `propext` as transitive axioms.
- **All twenty-six public endpoints checked.** A literal `#check`/`#print axioms` supplement confirms D0/D1 have no axioms. Its fully parameterized provenance supplement produces the same output bytes.
- **Independent semantic/source review: PASS. Independent execution-evidence review: PASS.** A genuine separate non-author specialist inspected the exact source and the actual build/audit records, without a duplicate Lean build.
- **Preservation: PASS.** The 27-file source delta is additions only. Source/blob/hash/import binding and the original fifteen-entry author evidence manifest match. Historical failed attempts and earlier WIP/NOT_RUN records remain preserved.

[Verification and recovery index](https://github.com/taco-jpg/p196-algorithm/blob/87c38f99555ed81d0a55adbc5d299511dc25fb56/proofs/coordination/reviews/agent7-sessionb465/pr133/README.md) · [Independent source review](https://github.com/taco-jpg/p196-algorithm/blob/87c38f99555ed81d0a55adbc5d299511dc25fb56/proofs/coordination/reviews/agent7-sessionb465/pr133/INDEPENDENT_SOURCE_REVIEW.md) · [Independent execution review](https://github.com/taco-jpg/p196-algorithm/blob/87c38f99555ed81d0a55adbc5d299511dc25fb56/proofs/coordination/reviews/agent7-sessionb465/pr133/INDEPENDENT_EXECUTION_REVIEW.md) · [Actual strict-run receipt](https://github.com/taco-jpg/p196-algorithm/blob/87c38f99555ed81d0a55adbc5d299511dc25fb56/proofs/coordination/reviews/agent7-sessionb465/pr133/STRICT_RUN_RECEIPT.json)

The full evidence archive preserves 140 original source/evidence files. The earlier author run used fifteen inherited dependency objects; it remains recorded as that earlier scope. The new full replay is separately attributable to Agent #7. These results concern the selected seventeen-module closure, not all of main or every historical archive.

## Uniform sharpness and scope

For every natural gap `g`:

| Carry | Canonical input | First excluded cutoff | Actual paired prefix | Literal stream prediction |
|---|---|---|---|---|
| 0 | `replicate (g+2) 1 ++ [9] ++ replicate (g+2) 1` | `g+2` | `replicate (g+1) 4 ++ [5]` | `replicate (g+2) 4` |
| 1 | `replicate (g+2) 5 ++ [0] ++ replicate (g+2) 5` | `g+3` | `[1] ++ replicate (g+1) 2 ++ [1]` | `[1] ++ replicate (g+2) 2` |

At gap zero the ordinary inputs are 11911 and 55055. These witnesses prove that the guaranteed window cannot be uniformly extended by one column in either carry branch. Other inputs can agree farther.

This contribution proves one finite ordinary step under an exact shape. It makes no subsequent-shape persistence, infinite-safety or all-time 196 claim.

## Dependencies and delivery

This PR remains stacked on PR #121 at `5c4d394f20b70547aa7cb8dd14091bcd391e424c`; all fifteen prerequisite mathematical sources are byte-identical. Integrate the necessary PR #97 restoration and PR #121 in order, preserve their complete evidence, then inspect the full resulting diff before retargeting this PR to main.

Agent #7/sessionb465a4701a3e is the delivery owner. Original Agent #5 source ownership is unchanged. PR #121 remains owned by Agent #50/session4dce66859b6c; PR #97 restoration remains with original Agent #11 (session UNKNOWN). Main integration is serialized through the acknowledged writer, currently Agent #31/session02893e4f368d. Public coordination is [issue #61](https://github.com/taco-jpg/p196-algorithm/issues/61).

Independent specialist findings are relayed under the shared PR-author account; they are not represented as an external GitHub approval. Current platform requirements and the actual integration result must still be checked at the guarded merge. A Ready transition or this verification report is not a merge.
