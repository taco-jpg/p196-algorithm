"""Read public Git trees and calculate hypothetical combinations; no remote writes or Lean runs."""
import hashlib, json, pathlib, subprocess, datetime
root=pathlib.Path(__file__).parent
repo=root/'tree-repo.git'
raw=root/'raw'; raw.mkdir(exist_ok=True)
commands=[]
checks=[]
def save(name, value):
    (root/name).write_text(json.dumps(value,indent=2)+'\n')
def check(name, condition, **data):
    checks.append({'name':name,'pass':bool(condition),**data})
def git(name,*args,expected=(0,)):
    argv=['git','--git-dir='+str(repo),*args]
    p=subprocess.run(argv,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    (raw/(name+'.stdout')).write_bytes(p.stdout)
    (raw/(name+'.stderr')).write_bytes(p.stderr)
    commands.append({'argv':argv,'exit_code':p.returncode,'stdout_path':'raw/'+name+'.stdout','stderr_path':'raw/'+name+'.stderr'})
    save('commands.json',commands)
    if p.returncode not in expected: raise RuntimeError((name,p.returncode,p.stderr.decode()))
    return p.stdout.decode(),p.returncode
def listing(label,ref):
    data,_=git('tree-'+label,'ls-tree','-r',ref)
    entries={}
    for line in data.splitlines():
        info,path=line.split('\t',1);mode,kind,oid=info.split()
        entries[path]={'mode':mode,'type':kind,'oid':oid}
    return entries
def delta(label,old,new):
    out,_=git('delta-'+label,'diff','--name-status','--no-renames',old,new)
    items=[{'status':s,'path':p} for s,p in (line.split('\t',1) for line in out.splitlines())]
    return {'base':old,'head_or_tree':new,'counts':{s:sum(x['status']==s for x in items) for s in ['A','M','D']},'files':items}
B='74a1c3922eb7af438fe40b23d2105ad07556e3f5'
H97='9e59a77ae4e13a84eedc25aff689339e0225ad90'
P97='5bbd70c486b3c274cfc9bf244cc92e551419d5d8'
H121='5c4d394f20b70547aa7cb8dd14091bcd391e424c'
H133='9b1535d80ab3cb32d131306f089bcf524482ab09'
T97=git('merge-main-pr97','merge-tree','--write-tree',B,H97)[0].strip()
T121=git('merge-pr97-pr121','merge-tree','--write-tree','--merge-base='+P97,T97,H121)[0].strip()
T133=git('merge-pr121-pr133','merge-tree','--write-tree','--merge-base='+H121,T121,H133)[0].strip()
Tdirect=git('merge-main-pr133-direct','merge-tree','--write-tree',B,H133)[0].strip()
refs={'B':B,'P97':P97,'H97':H97,'H121':H121,'H133':H133,'T97':T97,'T121':T121,'T133':T133,'Tdirect133':Tdirect}
trees={k:listing(k,v) for k,v in refs.items()}
for label,a,b in [('P97-ancestor-H121',P97,H121),('H97-not-ancestor-H121',H97,H121),('H121-ancestor-H133',H121,H133)]:
    _,code=git(label,'merge-base','--is-ancestor',a,b,expected=(0,1))
    check(label,code==(1 if label.startswith('H97-not') else 0),exit_code=code)
deltas={label:delta(label,a,b) for label,a,b in [('repair',P97,H97),('main-pr97',B,T97),('pr97-pr121',T97,T121),('pr121-pr133',T121,T133),('main-complete',B,T133),('direct-misses-restoration',Tdirect,T133)]}
for label,older,newer in [('main-preserved-in-pr97','B','T97'),('main-preserved-in-pr121','B','T121'),('main-preserved-in-pr133','B','T133'),('pr97-preserved-in-pr121','H97','T121'),('pr97-preserved-in-pr133','H97','T133'),('pr121-preserved-in-pr133','H121','T133'),('pr133-preserved-in-final','H133','T133')]:
    missing=[p for p in trees[older] if p not in trees[newer]]
    changed=[p for p,v in trees[older].items() if p in trees[newer] and trees[newer][p]!=v]
    check(label,not missing and not changed,old_file_count=len(trees[older]),new_file_count=len(trees[newer]),missing=missing,changed=changed)
inventory_response=json.loads((root/'observations/Agent11SnapshotRestoration.response.json').read_text())['response']['structuredContent']
inventory=json.loads(inventory_response['content'])
inventory_path='proofs/contributions/agent-5/exact-digit-streams-20261016/integration/Agent11SnapshotRestoration.json'
(raw/'Agent11SnapshotRestoration.json').write_text(inventory_response['content'])
restored=inventory['restored_files']
restoration_paths=[r['restore_path'] for r in restored]+[inventory_path]
check('repair-exact-17-additions',deltas['repair']['counts']=={'A':17,'M':0,'D':0} and set(restoration_paths)=={x['path'] for x in deltas['repair']['files']})
check('direct-pr133-misses-exact-17',deltas['direct-misses-restoration']['counts']=={'A':17,'M':0,'D':0} and set(restoration_paths)=={x['path'] for x in deltas['direct-misses-restoration']['files']})
restoration=[]
for r in restored:
    p=r['restore_path']; blob=r['source_git_blob']
    row={**r,'present':{k:p in trees[k] for k in trees},'blob_identity':{k:trees[k].get(p,{}).get('oid') for k in trees},'source_blob_at_P97':trees['P97'][r['retained_source']]['oid']}
    check('restored-blob-'+p,all(trees[k].get(p,{}).get('oid')==blob for k in ['H97','T97','T121','T133']) and row['source_blob_at_P97']==blob)
    check('restoration-missing-from-descendants-'+p,p not in trees['H121'] and p not in trees['H133'])
    restoration.append(row)
for k in ['H97','T97','T121','T133']:
    check('inventory-preserved-'+k,trees[k][inventory_path]['oid']==inventory_response['sha'])
for r in inventory['original_manifest_and_publication_records']:
    check('original-record-preserved-'+r['path'],all(trees[k].get(r['path'],{}).get('oid')==r['git_blob'] for k in trees))
strict_path=root.parent/'pr133/STRICT_RUN_RECEIPT.json'
strict=json.loads(strict_path.read_text())
binding=[]
for registry_key,source_key,tree_key,project in [('registry97','H97','T97','agent5-exact-digit-streams'),('registry121','H121','T121','agent5-ordinary-stream-prefix')]:
    wrapper=json.loads((root/'observations'/f'{registry_key}.json').read_text())
    response=wrapper['value']['response']['structuredContent']
    registry=json.loads(response['content'])
    modules=registry['projects'][project]['modules']
    matches=[]
    for name,spec in modules.items():
        exact=[m for m in strict['source_modules'] if m['module']==name]
        match=len(exact)==1 and all(exact[0][field]==spec[field] for field in ['path','git_blob','sha256'])
        tree_match=trees[source_key].get(spec['path'],{}).get('oid')==spec['git_blob'] and trees[tree_key].get(spec['path'],{}).get('oid')==spec['git_blob']
        check(registry_key+'-module-'+name,match and tree_match)
        matches.append({'module':name,'path':spec['path'],'git_blob':spec['git_blob'],'sha256':spec['sha256'],'strict_receipt_identity_matches':match,'source_and_combination_identity_match':tree_match})
    binding.append({'registry':registry_key,'registry_git_blob':response['sha'],'project':project,'modules':matches,'module_count':len(modules),'source':refs[source_key],'hypothetical_tree':refs[tree_key]})
for m in strict['source_modules']:
    check('final-compiled-source-'+m['module'],trees['T133'][m['path']]['oid']==m['git_blob'])
for path in ['proofs/Agent5StreamAgreementWindow.registry.json','proofs/verify_project__214bf7673efe116b.py']:
    check('final-verification-wiring-'+path,trees['T133'][path]==trees['H133'][path])
save('RESTORATION_DELTA.json',{'snapshot_bytes':sum(r['bytes'] for r in restored),'restored_snapshot_count':len(restored),'additional_inventory_path':inventory_path,'additional_inventory_git_blob':inventory_response['sha'],'inventory_bytes':len(inventory_response['content'].encode()),'snapshots':restoration,'deltas':deltas})
save('SOURCE_REUSE_BINDING.json',{'new_lean_execution':False,'strict_receipt_path':str(strict_path),'strict_receipt_sha256':hashlib.sha256(strict_path.read_bytes()).hexdigest(),'strict_source_head':strict['source_head'],'strict_status':strict['status'],'strict_theorem_count':strict['theorem_count'],'bound_prerequisites':binding,'scope':'Source/module closure reuse only; no claim of required platform checks or the unrelated repository build.'})
save('CHECKS.json',{'pass':all(c['pass'] for c in checks),'checks':checks,'count':len(checks),'failures':[c for c in checks if not c['pass']]})
save('COMBINATION.json',{'observed_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'PASS_HYPOTHETICAL_TREE_SOURCE_AND_PRESERVATION','actual_integration':False,'new_lean_execution':False,'remote_mutations':False,'refs':refs,'tree_file_counts':{k:len(v) for k,v in trees.items()},'deltas':{k:v['counts'] for k,v in deltas.items()},'construction':'git merge-tree in an isolated bare object store; later stages use explicit proven common ancestors and previous output trees; no synthetic commits and no source worktree mutation.'})
print(json.dumps({'refs':refs,'checks':len(checks),'failures':[c for c in checks if not c['pass']],'counts':{k:v['counts'] for k,v in deltas.items()}},indent=2))
