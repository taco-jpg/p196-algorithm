"""Generate machine-readable delivery facts and a substantive-file manifest."""
import datetime,hashlib,json,pathlib
r=pathlib.Path(__file__).parent
def read(name):return json.loads((r/name).read_text())
def api(name):
    v=read('observations/'+name+'.json')
    if v.get('status')=='fulfilled':v=v['value']
    response=v.get('response',v.get('value'))
    return json.loads(response['structuredContent']['content'])
combo=read('COMBINATION.json')
checks=read('CHECKS.json')
restoration=read('RESTORATION_DELTA.json')
facts={
 'schema_version':1,
 'author':'Agent #7/sessionb465a4701a3e delegated read-only dependency-delivery specialist',
 'generated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'PASS_HYPOTHETICAL_CURRENT_MAIN_SOURCE_BINDING_AND_PRESERVATION',
 'actual_integration':False,'remote_mutations':False,'new_lean_execution':False,'new_independent_source_review':False,'handoff_acknowledged':False,
 'refs':combo['refs'],
 'intended_order':[97,121,133],
 'owners':{'pr97':{'agent':11,'session':'UNKNOWN','task':'agent11-pr97-snapshot-restoration-20261016'},'pr121':{'agent':50,'session':'4dce66859b6c','task':'agent50-session4dce-pr121-delivery-20261016'},'pr133':{'agent':7,'session':'b465a4701a3e'},'main_writer':{'agent':31,'session':'02893e4f368d','status':'ACTIVE','selected_pr':104}},
 'tree_deltas':combo['deltas'],
 'checks':{'count':checks['count'],'pass':checks['pass'],'failures':checks['failures']},
 'restoration':{'snapshot_files':restoration['restored_snapshot_count'],'snapshot_bytes':restoration['snapshot_bytes'],'inventory_files':1,'inventory_bytes':restoration['inventory_bytes'],'all_missing_from_H121_and_H133':True,'all_preserved_in_hypothetical_stack':True,'detail':'RESTORATION_DELTA.json'},
 'reused_verification':{'executor':'Agent #7 parent','exact_H':combo['refs']['H133'],'modules_built_fresh':17,'audited_theorem_constants':302,'pr97_module_subset':9,'pr97_theorem_subset':179,'pr121_module_subset':15,'pr121_theorem_subset':267,'compiler':'Lean 4.19.0','flags':['--trust=0','-j1','-DElab.async=false'],'allowed_axioms':['propext','Classical.choice','Quot.sound'],'qualified_detail':'SOURCE_REUSE_BINDING.json','repository_wide':False,'platform_required_check_replacement':False},
 'review_reuse':[{'pr':97,'review':5554315857,'scope':'Original mathematical review; exact active source retained'},{'pr':97,'review':5554792309,'scope':'Completed narrow archival-restoration review at H97; no duplicate review'},{'pr':121,'review':5554315948,'scope':'Original six-contract semantic and inherited-dependency execution review at H121'}],
 'final_branch_readbacks':{key:{'sha':api(key)['commit']['sha'],'observation':'observations/'+key+'.json'} for key in ['final-main','final-pr97-source-branch','final-pr121-source-branch']},
 'platform':{},
 'actionable_prerequisites':[
 {'pr':97,'owner':'Original Agent #11/session UNKNOWN','action':'Resume delivery or explicitly acknowledge a named delivery handoff; update stale completed-review task state.'},
 {'pr':97,'owner':'Current main writer Agent #31/session02893e4f368d and acknowledged PR97 delivery owner','action':'Refresh exact B/H, remaining source-specific publication/platform obligations, and tested combination; execute ordinary guarded merge and actual target/parents/postcheck readback.'},
 {'pr':121,'owner':'Agent #50/session4dce66859b6c','action':'After actual PR97 integration, preserve seventeen restored files, retarget as warranted, inspect complete diff, rebind current main and execute guarded integration.'},
 {'pr':133,'owner':'Agent #7/sessionb465a4701a3e','action':'Complete current evidence/Ready work; after actual PR121 integration refresh/retarget and deliver with preserved prerequisite history.'}
 ],
 'denied_archive_boundary':{'retrieved':False,'repackaged':False,'exported':False,'old_archive_action':'Not resolved by this packet; payload-specific authorized path remains with legitimate owner.'},
 'limitations':['No actual merge, platform approval, owner acknowledgment, or post-merge check claimed.','Current-main proof reuse is restricted to the exact unchanged closure; unrelated main modules were not rebuilt.','Main/head/build-wiring changes require affected rebinding.','Queued application suites with zero runs are not interpreted as failed Lean checks or invented mandatory gates.']
}
for pr in [97,121]:
 cr=api(f'pr{pr}-checks');st=api(f'pr{pr}-status');wr=api(f'pr{pr}-runs');cs=api(f'pr{pr}-check-suites')
 facts['platform'][str(pr)]={'legacy_status_count':len(st['statuses']),'actions_run_count':wr['total_count'],'check_runs':[{'id':x['id'],'name':x['name'],'status':x['status'],'conclusion':x['conclusion'],'head_sha':x['head_sha']} for x in cr['check_runs']],'check_suites':[{'id':x['id'],'status':x['status'],'conclusion':x['conclusion'],'app':x['app']['slug'],'latest_check_runs_count':x['latest_check_runs_count']} for x in cs['check_suites']]}
(r/'DELIVERY_FACTS.json').write_text(json.dumps(facts,indent=2)+'\n')
entries=[]
for p in sorted(r.rglob('*')):
 if not p.is_file() or 'tree-repo.git' in p.relative_to(r).parts or p.name=='FILES.json':continue
 data=p.read_bytes();entries.append({'path':str(p.relative_to(r)),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(r/'FILES.json').write_text(json.dumps({'schema_version':1,'scope':'All substantive packet files; manifest itself excluded to avoid recursive hashing.','excluded':[{'path':'tree-repo.git/','reason':'Reproducible operational Git object store; exact public input hashes, command receipts and complete source-tree inventories are retained.'}],'files':entries,'file_count':len(entries),'total_bytes':sum(x['bytes'] for x in entries)},indent=2)+'\n')
print(json.dumps({'file_count':len(entries),'total_bytes':sum(x['bytes'] for x in entries),'checks_pass':checks['pass'],'manifest_sha256':hashlib.sha256((r/'FILES.json').read_bytes()).hexdigest()},indent=2))
