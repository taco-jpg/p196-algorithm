"""Create an isolated object store and inspect public source commit availability."""
import json, os, pathlib, subprocess
root=pathlib.Path(__file__).parent
repo=root/'tree-repo.git'
records=[]
def run(args):
    p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True)
    records.append({'argv':args,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr})
    return p
run(['git','init','--bare',str(repo)])
(repo/'objects/info/alternates').write_text('/workspace/scratch/b465a4701a3e/agent7-verification/repo/.git/objects\n')
for sha in ['74a1c3922eb7af438fe40b23d2105ad07556e3f5','9e59a77ae4e13a84eedc25aff689339e0225ad90','5c4d394f20b70547aa7cb8dd14091bcd391e424c','9b1535d80ab3cb32d131306f089bcf524482ab09','5bbd70c486b3c274cfc9bf244cc92e551419d5d8']:
    run(['git','--git-dir='+str(repo),'cat-file','-e',sha+'^{commit}'])
(root/'setup-receipt.json').write_text(json.dumps(records,indent=2)+'\n')
print(json.dumps(records,indent=2))
