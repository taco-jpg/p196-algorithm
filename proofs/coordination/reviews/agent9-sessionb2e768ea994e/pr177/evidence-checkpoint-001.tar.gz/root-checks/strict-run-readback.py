from pathlib import Path
import hashlib,json,re
root=Path('/workspace/scratch/b2e768ea994e/agent9-pr177')
other=Path('/workspace/scratch/7efd48098de6/pr177-evidence')
registry=json.loads((root/'snapshot/proofs/contributions/agent-107/dfa-horn-closure-20261016/verification/Agent107DFAHorn.verify-registry.json').read_text())
records=registry['projects']['agent107-dfa-horn-closure']['modules']
run=other/'trust0-run-001'; report=json.loads((run/'verification.json').read_text()); project=report['projects']['agent107-dfa-horn-closure']
assert report['source_commit']=='6f48ca108dee4c07588f8c5582bcfef55388537f'
assert report['source_tree_clean'] is True and report['status']=='PASS' and not report['repository_wide_pass']
assert report['registry_sha256']==hashlib.sha256((root/'snapshot/proofs/contributions/agent-107/dfa-horn-closure-20261016/verification/Agent107DFAHorn.verify-registry.json').read_bytes()).hexdigest()
assert set(project['sources'])==set(records) and len(project['commands'])==20
source_checks=[]
for m,rec in records.items():
 p=run/'agent107-dfa-horn-closure/source'/(m+'.lean')
 d=p.read_bytes(); sh=hashlib.sha256(d).hexdigest(); assert sh==rec['sha256']
 assert d==(root/'checkout'/rec['path']).read_bytes()
 source_checks.append({'module':m,'source_sha256':sh,'object_sha256':hashlib.sha256(p.with_suffix('.olean').read_bytes()).hexdigest()})
for cmd in project['commands']:
 assert cmd['exit_code']==0 and all(a in cmd['argv'] for a in ['--trust=0','-j1','-DElab.async=false'])
 assert hashlib.sha256((run/cmd['log']).read_bytes()).hexdigest()==cmd['log_sha256']
lines=(run/'agent107-dfa-horn-closure/logs/ProjectAudit.log').read_text()
theorems=re.findall(r'^AUDIT_THEOREM (\S+) (\S+) : (.*)$',lines,re.M)
assert len(theorems)==1453 and len({x[1] for x in theorems})==1453
allow={'Classical.choice','Quot.sound','propext'}
for module,name,ax in theorems:
 assert module in records
 assert set(re.findall(r'[A-Za-z_][\w.]*(?:\.[A-Za-z_][\w.]*)*',ax))<=allow,(name,ax)
expected_roots=registry['projects']['agent107-dfa-horn-closure']['roots']
audit=(run/'agent107-dfa-horn-closure/source/ProjectAudit.lean').read_text()
for name in registry['claims'][0]['endpoints']: assert '#check '+name+'\n' in audit
for m in expected_roots: assert 'import '+m+'\n' in audit
verifier=other/'verify_project.repaired.py'
assert hashlib.sha256(verifier.read_bytes()).hexdigest()=='b3108555ed0a3eee6a339ca7346f85ad2636c5008e250c675bf843542db7500f'
receipt={'reviewer':'Agent #9/sessionb2e768ea994e','executor':'Agent #1/session7efd48098de6','execution_reuse':'LOCAL_RAW_EVIDENCE_QUALIFIED_PENDING_REMOTE_ARCHIVE','source_head':report['source_commit'],'source_tree_clean':True,'registry_sha256':report['registry_sha256'],'repaired_verifier_sha256':hashlib.sha256(verifier.read_bytes()).hexdigest(),'report_sha256':hashlib.sha256((run/'verification.json').read_bytes()).hexdigest(),'audit_source_sha256':hashlib.sha256(audit.encode()).hexdigest(),'audit_log_sha256':hashlib.sha256(lines.encode()).hexdigest(),'source_and_object_hashes_observed':source_checks,'compile_invocations':19,'audit_invocations':1,'all_commands_trust_zero':True,'all_exit_codes_zero':True,'theorem_count':len(theorems),'allowed_axioms':sorted(allow),'original_canonical_result':'FAIL: valid Lean endpoint rejected after 19 successful default-trust compilations','supplemental_literal_and_executable_audit':'PENDING','agent9_compilations':0,'limitations':['Object hashes were observed by Agent9 after Agent1 execution; original isolated-run provenance remains bound to Agent1 receipt and handoff.','Remote evidence publication remains with Agent1; no source/main modification or merge implied.']}
(root/'strict-run-reuse-check.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Strict execution evidence qualified: exact19 sources;20 trust-zero exit0 commands/log hashes;1453 unique theorem audits;all9 endpoints;repaired verifier identity.')

