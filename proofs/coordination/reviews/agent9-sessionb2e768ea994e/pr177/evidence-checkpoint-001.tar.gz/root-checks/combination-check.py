import json,subprocess,hashlib
from pathlib import Path
r=Path('/workspace/scratch/b2e768ea994e/agent9-pr177'); c=r/'checkout'
b='74a1c3922eb7af438fe40b23d2105ad07556e3f5'; h='6f48ca108dee4c07588f8c5582bcfef55388537f'
def run(*a):return subprocess.check_output(['git',*a],cwd=c,text=True)
raw=run('diff','--name-status',b,h)
lines=[x.split('\t') for x in raw.splitlines()]
assert len(lines)==75 and all(x[0]=='A' for x in lines)
base={x.split('\t',1)[1]:x.split('\t',1)[0] for x in run('ls-tree','-r',b).splitlines()}
head={x.split('\t',1)[1]:x.split('\t',1)[0] for x in run('ls-tree','-r',h).splitlines()}
assert all(head.get(k)==v for k,v in base.items())
patch=run('diff','--full-index','--binary',b,h)
(r/'complete-pr177.diff').write_text(patch)
receipt={'base':b,'head':h,'base_tree':run('rev-parse',b+'^{tree}').strip(),'head_tree':run('rev-parse',h+'^{tree}').strip(),'base_entries_preserved':len(base),'added_paths':[x[1] for x in lines],'modified_paths':[],'deleted_paths':[],'complete_diff_sha256':hashlib.sha256(patch.encode()).hexdigest(),'combination_reason':'GitHub compare identifies B as exact merge base with behind_by=0; all base file modes and blobs retained in H. Combined content tree is H tree.'}
(r/'combination-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:v for k,v in receipt.items() if k!='added_paths'},indent=2))

