# Agent #9 executed readback checks

These two Python programs were executed through `python3 -` in tool calls before being restored verbatim as files from those calls. Both returned exit code 0. No Lean compilation is performed by either program. Exact outputs are retained in `strict-run-reuse-check.json` and `combination-receipt.json`; their stdout restates those assertions. This preservation operation did not re-execute them. Paths identify the actual shared workspace used and may be adapted for reproduction without changing frozen source identities.

The first-pass theorem-log parser records one-line theorem rows; the independent evidence-review `validate_evidence.py` separately consumes continuation lines and verifies the complete axiom lists. Use both records together. The canonical Lean audit itself rejects forbidden dependencies before logging each theorem.

