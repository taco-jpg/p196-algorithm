# Preserved raw evidence for the PR #177 semantic review

This directory preserves the programs and records underlying `../semantic-review.md` for exact source head `6f48ca108dee4c07588f8c5582bcfef55388537f`. It is a preservation continuation of the original independent review, not a new mathematical review.

## Original finite-data and active-source check

- `original-finite-data-source-scan.py` is the exact Python body recovered from the original visible shell here-document, including its final newline. It was not reconstructed from the report's prose description.
- `original-finite-data-source-scan.execution.json` preserves the exact original command and tool arguments, original tool-result fields, exit code, and the combined output string. Original chunk identifier: `15c700`; exit code: `0`.
- `original-finite-data-source-scan.output.txt` preserves the exact original combined output string. The original tool did not return separate stdout/stderr streams; this file is deliberately not labeled a separately captured stdout stream.

The check was run once in the original review. It was not run again while creating this directory. Its exact original start/end timestamps and resolved Python interpreter version/path were not captured; these facts remain unknown. A wall duration returned by the original tool is preserved in the execution record. The source paths in the original program intentionally remain unchanged to preserve its actual bytes and original invocation context.

## Original GitHub source identity check

`original-github-source-identity.execution.json`, `.py`, and `.output.txt` preserve the original second read-only Python check, which hashed the three source strings returned by the GitHub connector. Original chunk identifier: `92e4a9`; exit code: `0`. The `.py` file preserves the original `python3 -c` program argument exactly, with no final newline. The execution JSON also retains the exact source JSON argument and shell-quoted original command.

`github-fetch-0.json` through `github-fetch-2.json` preserve the actual persisted connector results, with JSON formatting supplied for readability. Their structured source strings and metadata are unchanged. `sources/` contains byte-for-byte UTF-8 copies of those returned historical Python sources. They were read and hashed, never imported or executed as repository programs. The data enumeration in the review was independently transcribed into the first program.

## Failures and provenance limits

`failed-attempts.json` states that no substantive mathematical, finite-data, source-scan, or source-identity execution failed during the original review. There were no hidden failed runs or retries. It also retains the preservation-only directory-inventory call that exited with code 2 because this directory did not yet exist. That inventory result is not a failed mathematical check.

`source-manifest.original.json` is an unchanged copy of the source manifest consumed by the original finite-data program. The 22 input files comprise 19 Lean files and three non-Lean provenance/verifier files. The exact original file bytes remain in the sibling `../snapshot/` directory. The original program checked all 22 file identities, but the prohibited-token scan operated only on the 19 Lean files. The source manifest and registry identify these distinct scopes.

`manifest.json` records artifact hashes, source pins, execution records, and explicit exclusions. The manifest is generated preservation metadata, not an original execution result. Its self-hash is intentionally not embedded recursively. `preserve-manifest.py` is the actual preservation utility used to create the manifest and check that retained program/output/source-copy bytes agree with the retained records. That utility does not rerun the finite-data enumeration, source scan, source-identity check, Lean, Z3, or repository programs.

## Generated-file and source exclusions

Every file in this `semantic-evidence/` directory and the sibling `semantic-review.md` is review evidence. None is a newly accepted Lean proof source, an importable dependency of the 19-module proof closure, an added build target, or a concrete invariant certificate. In particular:

- `sources/*.py` are historical comparator-source copies, excluded from the accepted Lean closure and not executed.
- `original-*.py` are reviewer-owned finite-data/identity check programs, excluded from the accepted Lean closure.
- `preserve-manifest.py`, `manifest.json`, execution JSON files, connector JSON records, output text, README, and the copied source manifest are generated preservation/provenance artifacts, excluded from proof-source scans and theorem acceptance.
- No `.olean`, generated Lean audit file, build cache, Lean execution log, or solver output is produced or claimed by this review.

The distinction between exact original records and later preservation metadata is intentional. Actual pinned Lean compilation and transitive declaration-axiom auditing remain separate evidence owned by the delivery agent.
