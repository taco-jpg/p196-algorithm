import sys,json,hashlib
for f in json.loads(sys.argv[1]):
 b=f['content'].encode(); h=hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest(); assert h==f['sha']; print(f['display_title'], 'bytes='+str(len(b)), 'git_blob='+h, 'sha256='+hashlib.sha256(b).hexdigest())