"""Preserve original review records; do not rerun any mathematical check."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json


base = Path(__file__).resolve().parent
review_root = base.parent
source_manifest_bytes = (review_root / "source-manifest.json").read_bytes()
(base / "source-manifest.original.json").write_bytes(source_manifest_bytes)
source_manifest = json.loads(source_manifest_bytes)

finite_record = json.loads((base / "original-finite-data-source-scan.execution.json").read_text())
identity_record = json.loads((base / "original-github-source-identity.execution.json").read_text())
(base / "original-github-source-identity.py").write_bytes(
    identity_record["original_program_argument"].encode("utf-8")
)

command = finite_record["original_tool_arguments"]["cmd"]
assert command.startswith("python3 - <<'PY'\n") and command.endswith("\nPY")
original_program = command[len("python3 - <<'PY'\n"):-2]
assert (base / "original-finite-data-source-scan.py").read_bytes() == original_program.encode("utf-8")
for stem, record in [
    ("original-finite-data-source-scan", finite_record),
    ("original-github-source-identity", identity_record),
]:
    assert (base / f"{stem}.output.txt").read_bytes() == record["original_tool_result"]["output"].encode("utf-8")

historical_sources = []
for i in range(3):
    fetched = json.loads((base / f"github-fetch-{i}.json").read_text())
    source = fetched["value"]["structuredContent"]
    p = base / "sources" / source["display_title"]
    assert p.read_bytes() == source["content"].encode("utf-8")
    historical_sources.append({
        "path": p.relative_to(base).as_posix(),
        "original_git_blob": source["sha"],
        "original_source_url": source["display_url"],
        "source_ref": source_manifest["source_head"],
        "copied_from": f"github-fetch-{i}.json:value.structuredContent.content",
        "executed_as_repository_program": False,
        "accepted_lean_source": False,
    })

def sha256(data):
    return hashlib.sha256(data).hexdigest()

files = []
for p in sorted(base.rglob("*")):
    if p.is_file() and p.name != "manifest.json":
        rel = p.relative_to(base).as_posix()
        data = p.read_bytes()
        if rel.startswith("sources/"):
            kind = "HISTORICAL_COMPARATOR_SOURCE_COPY"
        elif rel.startswith("original-") and rel.endswith(".py"):
            kind = "EXACT_ORIGINAL_REVIEW_PROGRAM"
        elif rel.startswith("original-") and rel.endswith(".output.txt"):
            kind = "EXACT_ORIGINAL_COMBINED_TOOL_OUTPUT"
        elif rel.startswith("original-") and rel.endswith(".execution.json"):
            kind = "ORIGINAL_COMMAND_AND_TOOL_RESULT_RECORD"
        elif rel.startswith("github-fetch-"):
            kind = "PERSISTED_ORIGINAL_CONNECTOR_RESULT_JSON"
        elif rel == "source-manifest.original.json":
            kind = "UNCHANGED_COPY_OF_ORIGINAL_INPUT_MANIFEST"
        else:
            kind = "GENERATED_PRESERVATION_METADATA_OR_UTILITY"
        files.append({
            "path": rel,
            "bytes": len(data),
            "sha256": sha256(data),
            "kind": kind,
            "accepted_lean_source": False,
            "included_in_original_19_file_active_token_scan": False,
        })

report_bytes = (review_root / "semantic-review.md").read_bytes()
manifest = {
    "schema_version": 1,
    "record_kind": "GENERATED_PRESERVATION_MANIFEST_NOT_A_NEW_REVIEW_RESULT",
    "preserved_at_utc": datetime.now(timezone.utc).isoformat(),
    "repository": "taco-jpg/p196-algorithm",
    "pull_request": 177,
    "source_head": source_manifest["source_head"],
    "assigned_base": "74a1c3922eb7af438fe40b23d2105ad07556e3f5",
    "review_task": "/root/pr177_semantic_review",
    "delivery_owner": "Agent #9/session b2e768ea994e",
    "semantic_verdict": "SEMANTIC_REVIEW_PASS",
    "review_repeated_for_preservation": False,
    "mathematical_programs_rerun_for_preservation": False,
    "lean_executed_by_reviewer": False,
    "z3_or_repository_python_executed_by_reviewer": False,
    "original_execution_time_limits": {
        "exact_start_end_utc": "NOT_CAPTURED",
        "python_version_and_resolved_path": "NOT_CAPTURED",
        "original_commands_and_returned_wall_durations": "PRESERVED_IN_EXECUTION_RECORDS",
    },
    "original_executions": [
        {
            "record": "original-finite-data-source-scan.execution.json",
            "program": "original-finite-data-source-scan.py",
            "output": "original-finite-data-source-scan.output.txt",
            "chunk_id": finite_record["original_tool_result"]["chunk_id"],
            "exit_code": finite_record["original_tool_result"]["exit_code"],
            "preservation_basis": "Exact body/command/result recovered from original visible tool history",
        },
        {
            "record": "original-github-source-identity.execution.json",
            "program": "original-github-source-identity.py",
            "output": "original-github-source-identity.output.txt",
            "chunk_id": identity_record["original_tool_result"]["chunk_id"],
            "exit_code": identity_record["original_tool_result"]["exit_code"],
            "preservation_basis": "Exact code/result from original tool history and unchanged persisted source JSON argument",
        },
    ],
    "failed_attempt_record": "failed-attempts.json",
    "original_source_manifest": {
        "path": "source-manifest.original.json",
        "sha256": sha256(source_manifest_bytes),
        "input_file_count": len(source_manifest["files"]),
        "source_snapshot_path": "../snapshot/",
    },
    "original_input_files": source_manifest["files"],
    "active_token_scan_source_paths": [f["path"] for f in source_manifest["files"] if f["path"].endswith(".lean")],
    "identity_only_non_lean_inputs": [f["path"] for f in source_manifest["files"] if not f["path"].endswith(".lean")],
    "historical_source_copies": historical_sources,
    "report": {
        "path": "../semantic-review.md",
        "bytes": len(report_bytes),
        "sha256": sha256(report_bytes),
        "original_report_before_preservation_supplement_sha256": "cafb473b915d5a60754e9eb811a6fc78fd9af3e15f84e46ecf027e6ada07a0f2",
        "change_scope": "Added raw-program preservation supplement only; semantic verdict unchanged",
        "accepted_lean_source": False,
    },
    "exclusions": {
        "all_files_beneath_semantic_evidence": "Review-only artifacts; excluded from accepted Lean module closure, build roots, and original proof-source scan",
        "historical_python_source_copies": "Read-only comparator evidence; not imported/executed, not accepted proof dependencies",
        "reviewer_python_programs": "Finite-data/source-identity review utilities; not accepted Lean proof sources",
        "preservation_metadata_and_utility": "Generated after original execution; not original verification results or proof sources",
        "lean_compilation_artifacts": "NONE_PRODUCED_BY_REVIEWER",
        "solver_outputs": "NONE_PRODUCED_BY_REVIEWER",
        "manifest_self_hash": "Excluded from recursive embedded hash listing; caller can hash manifest.json externally",
    },
    "preservation_utility": {
        "path": "preserve-manifest.py",
        "invocation": "python3 /workspace/scratch/b2e768ea994e/agent9-pr177/semantic-evidence/preserve-manifest.py",
        "scope": "Writes preservation copies/manifest and compares retained bytes with retained records; does not execute original review programs",
    },
    "files": files,
}
(base / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
print("Preservation integrity: original program, outputs, and historical source copies match retained command/result records.")
print("Original mathematical/data checks rerun: NO")
print("Lean or repository programs executed: NO")
print("Preserved indexed files:", len(files))
print("Manifest SHA-256:", sha256((base / "manifest.json").read_bytes()))
print("Updated report SHA-256:", sha256(report_bytes))
