from pathlib import Path
import re,json,hashlib
root=Path('/workspace/scratch/b2e768ea994e/agent9-pr177')
manifest=json.loads((root/'source-manifest.json').read_text())
for f in manifest['files']:
    data=(root/'snapshot'/f['path']).read_bytes()
    assert len(data)==f['bytes'],f['path']
    assert hashlib.sha256(data).hexdigest()==f['sha256'],f['path']
    assert hashlib.sha1(b'blob '+str(len(data)).encode()+b'\x00'+data).hexdigest()==f['git_blob'],f['path']
print('Manifest identity: all 22 files match byte counts, SHA-256, and Git blob IDs.')
text=(root/'snapshot/proofs/Agent107TransducerTablesData.lean').read_text()
rows=re.findall(r'def state(\d+) : State := ⟨(\d+), (\d+), (\d+), (\(-1\)|\d+), (false|true)⟩',text)
assert [int(x[0]) for x in rows]==list(range(46))
states=[(int(e),int(a),int(c),int(d.strip('()')),started=='true') for _,e,a,c,d,started in rows]
edge_blocks=re.findall(r'def edges(\d+) : List Edge := \[\n(.*?)\n\]',text,re.S)
terminal_blocks=re.findall(r'def terminals(\d+) : List TerminalRow := \[\n(.*?)\n\]',text,re.S)
assert [int(i) for i,_ in edge_blocks]==list(range(46))
assert [int(i) for i,_ in terminal_blocks]==list(range(46))
edges=[]
for _,block in edge_blocks:
    lines=block.splitlines()
    for line in lines:
        m=re.fullmatch(r'  ⟨state(\d+), (\d+), (\d+), state(\d+)⟩,?',line)
        assert m,line
        edges.append(tuple(map(int,m.groups())))
def opt(s):
    return None if s=='none' else int(s[6:-1])
terminals=[]
for _,block in terminal_blocks:
    for line in block.splitlines():
        m=re.fullmatch(r'  ⟨state(\d+), (none|\(some \d+\)), (none|\(some \d+\)), (none|\(some \d+\))⟩,?',line)
        assert m,line
        i,c,x,o=m.groups();terminals.append((int(i),opt(c),opt(x),opt(o)))
# Independently transcribed arithmetic enumeration; no repository Python executed.
expected_states=[(0,0,0,-1,False),(1,0,1,1,False)]
index={s:i for i,s in enumerate(expected_states)}
expected_edges=[]
pos=0
while pos<len(expected_states):
    e,a,c,t,started=expected_states[pos]
    for q in range(0 if started else 1,19):
        for b in range(2):
            if (q+b)//10!=c:continue
            lo=(q+a)%10;hi=(q+b)%10
            target=(e,(q+a)//10,b,hi if e else -1,True)
            if target not in index:
                index[target]=len(expected_states);expected_states.append(target)
            expected_edges.append((pos,q,lo+t if e else lo+hi,index[target]))
    pos+=1
expected_terminals=[]
for i,(e,a,b,t,started) in enumerate(expected_states):
    for c in [None]+list(range(0,19,2)):
        if not started and (c is None or c==0):continue
        x=None
        if c is None:
            if a!=b:continue
            o=2*t if e else None
        else:
            if (c+a)//10!=b:continue
            if e:x=(c+a)%10+t;o=None
            else:o=2*((c+a)%10)
        expected_terminals.append((i,c,x,o))
assert states==expected_states
assert edges==expected_edges
assert terminals==expected_terminals
assert len(states)==len(set(states))==46
assert len(edges)==len(set(edges))==872
assert len(terminals)==len(set(terminals))==251
assert all(0<=q<19 and 0<=o<19 for _,q,o,_ in edges)
assert all(c is None or 0<=c<=18 and c%2==0 for _,c,_,_ in terminals)
assert all(o is None or 0<=o<=18 and o%2==0 for _,_,_,o in terminals)
assert all(x is None or 0<=x<19 and o is None for _,_,x,o in terminals)
print('Literal finite graph: exactly 46 unique states, 872 unique edges, 251 unique terminals; all match the independent arithmetic enumeration in exact original order.')
print('Alphabet/terminal bounds: all input/output pairs are 0..18; all centers are None or even 0..18; every extra pair has output center None.')
checks=(root/'snapshot/proofs/Agent107TransducerTablesChecks.lean').read_text()
blocks=re.findall(r'(theorem row\d+_separated.*?)(?=theorem row\d+_separated|end Agent107)',checks,re.S)
assert len(blocks)==46
normalized=[re.sub(r'(?<=[a-z])\d+','INDEX',block).strip() for block in blocks]
assert all(b==normalized[0] for b in normalized)
assert normalized[0].count(':= by decide')==6
print('Finite-table proof templates: all 46 blocks match the six inspected soundness/completeness/separation statements by uniform index substitution.')
# Strip nested Lean comments, then search active source tokens.
def uncomment(s):
    out=[];i=0;depth=0
    while i<len(s):
        if s.startswith('/-',i):depth+=1;i+=2
        elif depth and s.startswith('-/',i):depth-=1;i+=2
        elif depth:i+=1
        elif s.startswith('--',i):
            n=s.find('\n',i);i=len(s) if n==-1 else n
        else:out.append(s[i]);i+=1
    assert depth==0
    return ''.join(out)
violations=[]
lean_files=list((root/'snapshot/proofs').glob('*.lean'))
for p in lean_files:
    active=uncomment(p.read_text())
    for m in re.finditer(r'\b(sorry|admit|sorryAx|native_decide|axiom|unsafe)\b',active):
        violations.append((p.name,m.group(),active.count('\n',0,m.start())+1))
assert not violations,violations
print('Static active-token scan: no sorry/admit/sorryAx/native_decide/axiom/unsafe in the 19 Lean source files. This is not a transitive Lean axiom audit or compilation.')
