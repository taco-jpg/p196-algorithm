#!/usr/bin/env python3
"""Replay Agent #9's Python-only source, log, and validator integrity checks.

This program never invokes Lean and never changes source or GitHub state.
Its only output file is validation-replay.json beside this program.
Agent #1's retained local execution bundle is read, not rerun.
"""
from pathlib import Path
import ast
import collections
import hashlib
import json
import re
import subprocess

ROOT = Path(__file__).resolve().parent
CHECKOUT = ROOT.parent / 'checkout'
AGENT1 = Path('/workspace/scratch/7efd48098de6/pr177-evidence')
H = '6f48ca108dee4c07588f8c5582bcfef55388537f'
PROJECT = 'agent107-dfa-horn-closure'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    result = {'compiler_invoked': False, 'github_mutated': False}
    rows = json.loads((ROOT / 'source-identities.json').read_text())
    assert len(rows) == 75
    for row in rows:
        data = (ROOT / 'source' / row['path']).read_bytes()
        assert len(data) == row['bytes']
        assert sha(data) == row['sha256']
        assert hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest() == row['blob']
        assert data == (CHECKOUT / row['path']).read_bytes()
    result['full_added_sources_bound'] = len(rows)
    base = ROOT / 'source/proofs/contributions/agent-107/dfa-horn-closure-20261016/author'
    attempts = []
    for execution in sorted(base.rglob('execution.json')):
        rec = json.loads(execution.read_text())
        source = execution.parent / Path(rec['source']).name
        assert sha(source.read_bytes()) == rec['source_sha256']
        for command in rec.get('commands', []):
            assert '--trust=0' in command['argv']
            for stream in ['stdout', 'stderr']:
                log = execution.parent / (command['label'] + '.' + stream + '.log')
                assert sha(log.read_bytes()) == command[stream + '_sha256']
        if 'command' in rec:
            assert '--trust=0' in rec['command']
        attempts.append({'attempt': execution.parent.name, 'recorded_exit_code': rec['exit_code']})
    result['author_attempts_bound'] = attempts
    manifests = []
    for manifest in sorted(base.glob('*FILES.json')):
        entries = json.loads(manifest.read_text())
        for relative, rec in entries.items():
            data = (base / relative).read_bytes()
            assert len(data) == rec['bytes'] and sha(data) == rec['sha256']
        manifests.append({'manifest': manifest.name, 'entries': len(entries)})
    result['author_manifests'] = manifests
    candidate = (ROOT / 'verifier-endpoint-fix.py').read_text()
    parsed = ast.parse(candidate)
    expressions = {
        node.targets[0].id: ast.literal_eval(node.value.args[0])
        for node in parsed.body
        if isinstance(node, ast.Assign) and isinstance(node.targets[0], ast.Name)
        and node.targets[0].id in ['NAME', 'ENDPOINT_NAME']
    }
    original_name = re.compile(expressions['NAME'])
    endpoint_name = re.compile(expressions['ENDPOINT_NAME'])
    prior_cases = json.loads((ROOT / 'endpoint-validator-tests.json').read_text())['cases']
    for case in prior_cases:
        assert bool(endpoint_name.fullmatch(case['case'])) == case['expected']
    assert not original_name.fullmatch('Agent107.FoldedDFA.Encoding.stateIndex?_stateAt')
    registry_path = 'proofs/contributions/agent-107/dfa-horn-closure-20261016/verification/Agent107DFAHorn.verify-registry.json'
    registry_bytes = (CHECKOUT / registry_path).read_bytes()
    registry = json.loads(registry_bytes)
    endpoints = [e for c in registry['claims'] for e in c['endpoints']]
    assert len(endpoints) == 9
    assert sum(bool(original_name.fullmatch(e)) for e in endpoints) == 8
    assert all(endpoint_name.fullmatch(e) for e in endpoints)
    result['validator_cases'] = len(prior_cases)
    result['validator_regexes_from_actual_candidate'] = expressions
    applied = subprocess.run(['git', 'apply', '--check', str(ROOT / 'endpoint-validator.patch')],
                             cwd=CHECKOUT, capture_output=True, text=True)
    assert applied.returncode == 0, applied.stderr
    result['nonmutating_patch_check'] = {'exit_code': applied.returncode, 'stderr': applied.stderr}
    result['agent1_observed'] = {}
    for run in ['canonical-run-001', 'trust0-run-001']:
        root = AGENT1 / run
        report = json.loads((root / 'verification.json').read_text())
        project = report['projects'][PROJECT]
        assert report['source_commit'] == H and report['source_tree_clean'] is True
        assert report['registry_sha256'] == sha(registry_bytes)
        assert len(project['sources']) == 19
        for module, source in project['sources'].items():
            assert sha((root / PROJECT / 'source' / (module + '.lean')).read_bytes()) == source['build_sha256']
            assert sha((CHECKOUT / source['path']).read_bytes()) == source['sha256']
        for command in project['commands']:
            assert command['exit_code'] == 0
            assert sha((root / command['log']).read_bytes()) == command['log_sha256']
        outcome = {'status': report['status'], 'commands_bound': len(project['commands']),
                   'source_count': len(project['sources']), 'registry_sha256': report['registry_sha256']}
        if run == 'canonical-run-001':
            assert report['status'] == 'FAIL'
            assert report['error'] == 'Missing or invalid claim endpoints'
            assert len(project['commands']) == 19
        else:
            assert report['status'] == 'PASS'
            assert len(project['commands']) == 20
            assert all('--trust=0' in command['argv'] for command in project['commands'])
            log = (root / PROJECT / 'logs/ProjectAudit.log').read_text()
            entries = re.findall(r'^AUDIT_THEOREM (\S+) (\S+) : \[([^\]]*)\]', log, re.M)
            assert len(entries) == project['theorem_count'] == 1453
            assert len({entry[1] for entry in entries}) == 1453
            for _, _, axioms in entries:
                actual = {x.strip() for x in axioms.replace('\n', ' ').split(',') if x.strip()}
                assert actual <= {'propext', 'Classical.choice', 'Quot.sound'}
            outcome.update({'theorem_count': len(entries),
                            'module_theorem_counts': dict(collections.Counter(x[0] for x in entries)),
                            'all_theorem_axioms_allowed': True,
                            'unsafe_implementation_axiom_count': len(project['unsafe_implementation_axioms'])})
        result['agent1_observed'][run] = outcome
    result['status'] = 'PASS'
    (ROOT / 'validation-replay.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    main()
