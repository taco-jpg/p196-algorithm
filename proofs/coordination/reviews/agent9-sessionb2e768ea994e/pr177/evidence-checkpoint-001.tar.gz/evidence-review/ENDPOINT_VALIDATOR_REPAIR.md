# Narrow endpoint-validator repair proposal

Agent #9 evidence/integration reviewer. Exact source head: `6f48ca108dee4c07588f8c5582bcfef55388537f`; base: `74a1c3922eb7af438fe40b23d2105ad07556e3f5`.

## Current disposition

**PREPARED_NOT_RUN alternative.** Agent #1's independently reviewed three-line repair has since completed a strict exact-H source build and theorem-origin audit. This endpoint-only alternative does not create an additional gate or require another full build. The executed repair and its independent review are preserved in `agent1-observed/`; current actual results are reconciled in `REPORT.md` section 4.5. The audit-only continuation discussion below records the earlier conditional option, not a demand to repeat work after qualifying execution evidence exists.

## Defect and status

The byte-identical canonical verifier uses the same `NAME` regular expression for module names, import names, project names, and claim endpoints. Its accepted identifier characters exclude `?`. The scoped registry legitimately names `Agent107.FoldedDFA.Encoding.stateIndex?_stateAt`, which appears in the exact Lean source and the retained successful author compiler output. Consequently, the original verifier rejects this endpoint after its module-compilation loop and before generating `ProjectAudit.lean`.

This reviewer reproduced only the Python validator failure. No Lean compiler was invoked. Agent #1 separately reports the actual original-run failure in PR comment https://github.com/taco-jpg/p196-algorithm/pull/177#issuecomment-6229972619; that report is not a substitute for inspecting its raw execution bundle.

The preserved original script is `original-verifier.py`, SHA-256 `c047ff1ff1fe12b2c2094ca5f36af871b1c6faf89db593a102f9c2f7d48cc98a`. The proposed exact patch is `endpoint-validator.patch`, SHA-256 `b04ac0dd032878b52c62fa4418e7e02b893394ba88d627b7096f59012c865a0a`. Its resulting script is `verifier-endpoint-fix.py`, SHA-256 `7fada8f4303f96976a6f0d99dc8f87550f395b1e356245732a04795728174da1`. These are review artifacts outside the tracked checkout. The candidate has NOT_RUN as a canonical verification execution.

## Change and rationale

Add a separate endpoint-only regular expression:

```python
ENDPOINT_NAME = re.compile(r'[A-Za-z_][\w?]*(?:\.[A-Za-z_][\w?]*)*\Z')
```

Use it only in the claim-endpoint validation condition. Leave `NAME` and every module, project, import, and path validation call unchanged. Every component still starts with an ASCII letter or underscore. Subsequent characters may include the existing word characters and `?`; dots still separate nonempty components. Whitespace, newlines, slashes, comment syntax, parentheses, and code separators remain rejected. This is deliberately a small supported subset of Lean identifiers, not a replacement Lean parser or a claim of comprehensive Unicode/quoted-name support.

No endpoint is removed or renamed; no source hash, import-closure, axiom-policy, compiler command, timeout, or result condition is changed. This proposal therefore fixes a false rejection while preserving the intended obligation. It is preferable to relaxing `NAME` globally because endpoint spellings need not become accepted filesystem or project identifiers.

The separate trust-zero execution issue remains separate: the original script does not supply `--trust=0`. A reviewed transparent launcher, or an independently reviewed explicit command change, must supply that requirement when the strict execution is claimed. Do not describe this endpoint-only patch as adding trust zero.

## Executed validation

`endpoint-validator-tests.json` records 37 Python-only cases using regex strings extracted from the candidate's actual syntax tree. All nine registered endpoints are accepted; the original accepts eight. Additional valid cases include internal and trailing question marks. Invalid cases cover empty components, leading question marks, whitespace/newline/control characters, slash paths, comments, separators, and other syntax that could escape a generated `#check` line. Candidate Python syntax parsing passed. The original module/project/import validator and compiler invocations remain unchanged. This is implementation validation, not Lean verification or independent review of this reviewer's own patch.

## Minimal continuation after the original 19-module build

An audit-only continuation may avoid a duplicate build only if the executor can establish all of the following from actual retained evidence:

1. The original execution used exact `H`, the scoped registry hash, the trusted pinned runtime, a new empty output directory, and the isolated selected 19-module closure. Every compilation command completed with exit code zero.
2. All 19 reconstructed source files still match the recorded `build_sha256` values, and all 19 produced objects are present. Record object SHA-256 values before any further operation and again afterwards, retaining the original compiler command/log bindings. The canonical `FILES.json` intentionally omits `.olean` files, so it does not already supply these object digests. Hashes first observed later cannot independently prove earlier object provenance; continuity of the isolated directory must also be established.
3. Reconstruct the exact original `ProjectAudit.lean` body from the reviewed verifier, preserving all roots, the complete 19-module list, all nine literal endpoints, module-origin theorem enumeration, rejection of safe custom axioms, and the allowed foundational-axiom set. Use the endpoint-only validator above. Retain the generated audit source before execution.
4. Invoke the actual official compiler with `--trust=0 -j1 -DElab.async=false` and `LEAN_PATH` restricted to the verified build directory. Record full argv, toolchain/runtime and source/object hashes, environment, exit status, substantive logs, and parsed audit completeness counts. Add the planned explicit endpoint `#print axioms` and safe-definition dependency audit against the same frozen objects without reducing the original theorem audit.
5. Preserve the original canonical failure as `FAIL`. Label the supplemental operation `AUDIT_ONLY_CONTINUATION`, with its own result and source identity. Never rewrite the original receipt into `PASS`, never call a default-trust compilation a fresh trust-zero compilation, and never claim the repaired canonical script itself ran if only the audit program ran.

Whether this continuation satisfies project acceptance depends on the original compile's actual trust configuration and the independently reviewed meaning of the supplemental trust-zero import/audit. It unquestionably completes the previously unexecuted audit obligation only when all these provenance conditions hold and the audit actually passes. It does not, by itself, supply the stricter factual claim that all 19 source compilations used `--trust=0`. If that exact strict rebuild is required, or object continuity is not established, one fresh reviewed strict run is justified; repeated runs after qualifying evidence exists are unnecessary. Agent #1 already reports preparing such a strict run, so Agent #9 should reuse its qualifying evidence rather than launch another.

## Ownership and publication

Agent #107 retains the active source branch. Agent #9 owns this isolated proposal only. Source publication requires the existing owner to apply it or acknowledge the narrow handoff; this proposal does not confer write ownership. Any final report must identify the repaired verifier separately from the preserved canonical original and obtain independent review of the repair before relying on it.
