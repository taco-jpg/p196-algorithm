#!/usr/bin/env python3
"""Preserve a prepared recipe before correcting its recovered-corpus root."""
from pathlib import Path
import hashlib
import json
import shutil
ROOT = Path(__file__).resolve().parents[1]
history = ROOT / "publication-002" / "prepublication-001"
history.mkdir(exist_ok=False)
recipe = ROOT / "publication-002" / "REPLAY.md"
old = recipe.read_bytes()
shutil.copy2(recipe, history / "REPLAY.md")
old_text = old.decode()
before = "P196_EVIDENCE_ROOT=/absolute/path/to/recovered/execution-evidence-copy"
after = before + "/corpus"
assert old_text.count(before) == 1 and after not in old_text
recipe.write_text(old_text.replace(before, after))
archive = ROOT / "evidence-checkpoint-002.tar.gz"
manifest = ROOT / "ARCHIVE_MANIFEST_002.json"
shutil.copy2(manifest, history / "ARCHIVE_MANIFEST_002.json")
receipt = {
  "status": "PREPUBLICATION_DOCUMENTATION_PATH_CORRECTED",
  "lean_execution": False,
  "remote_publication": False,
  "reason": "The preserved execution evidence uses corpus/pr177-evidence, so the prepared recipe must point to execution-evidence-copy/corpus.",
  "original_recipe_sha256": hashlib.sha256(old).hexdigest(),
  "corrected_recipe_sha256": hashlib.sha256(recipe.read_bytes()).hexdigest(),
  "original_archive_sha256": hashlib.sha256(archive.read_bytes()).hexdigest(),
  "original_manifest_sha256": hashlib.sha256(manifest.read_bytes()).hexdigest(),
  "preservation": "Original recipe and manifest are included here; original compressed transport is retained locally under a preparation filename. All source and executed evidence bytes remain unchanged."
}
archive.rename(ROOT / "evidence-checkpoint-002.prepublication.tar.gz")
manifest.rename(ROOT / "ARCHIVE_MANIFEST_002.prepublication.json")
(history / "CORRECTION_RECEIPT.json").write_text(json.dumps(receipt, indent=2) + "\n")
print(json.dumps(receipt, indent=2))

