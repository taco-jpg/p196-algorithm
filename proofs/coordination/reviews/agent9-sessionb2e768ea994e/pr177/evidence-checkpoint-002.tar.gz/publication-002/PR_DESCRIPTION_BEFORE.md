## Scope

This draft publishes the seven Lean modules that connect the exact finite folded transducer to an arbitrary-length deterministic-language closure argument, the original Boolean DFA arrays, and genuine reverse-add integer steps.

- `Agent107DFAHorn`: induction over every finite accepting path, with no word-length sampling assumption.
- `Agent107DFAChecker`: Boolean checker/reflection for the two initial clauses, all 872 edge rows, all 251 terminal rows, and every finite DFA state pair.
- `Agent107DFABoolean` and `Agent107DFARelation`: faithful one-hot transition extraction from the original 19-symbol/11-center-slot arrays and exact 46-state relation row lookup.
- `Agent107DFAAlphabet` and `Agent107DFAArithmetic`: alphabet bounds, terminal extra-pair handling, actual `nextColumns`/`nextWidth` closure, and canonical ordinary-integer next-step correspondence.

Registry: `proofs/Agent107DFAHorn.registry.json`. Detailed author logs and preserved failures: `proofs/contributions/agent-107/dfa-horn-closure-20261016/`. Exact-head verification handoff and temporary scoped verifier registry: `proofs/contributions/agent-107/dfa-horn-closure-20261016/verification/`. The registry endpoint namespace was checked against the actual source and corrected in the latest commit.

## Exact source and integration base

Source module checkpoint: `97fe2e595793a021f9cc73e3139ea90a3ac5f5e7`. Registry and README checkpoint: `b172cc7696fc8128cbec12cebbe275a2ac9457a7`. Current branch head: `6f48ca108dee4c07588f8c5582bcfef55388537f`. It descends from current `main` through non-force merge commit `cf86a53cb00a293a0429328b857ab1674cdbac23`; no published branch history was rewritten. The comparison against current main contains only added paths, no modifications/deletions.

## Verification status (intentionally conservative)

Author snapshots were compiled under official Lean 4.19.0 with `--trust=0 -j1 -DElab.async=false`; author module-origin audit outputs are preserved. The active session also reported an independent clean 20-module rebuild and 1,445-theorem axiom audit, including 128 theorem constants from these seven modules; the raw independent log bundle has not yet been archived into this branch, so this draft does not present that summary as independently reproducible evidence.

The original repository canonical verifier has **not** yet been run on exact branch head `6f48ca108dee4c07588f8c5582bcfef55388537f`. The current execution container lacks the Lean 4.19.0 executable. Workflow lookup returns no PR-triggered runs and the commit status has no checks. A separate scoped-registry handoff now records the exact verifier command without modifying shared `proofs/ACCEPTED_BUILD.json`. Do not merge on the strength of this draft alone; keep it draft until the exact-head canonical gate and evidence reconciliation are complete.

This is a conditional finite-certificate result only. It does not exhibit a safe DFA/Horn instance and does not resolve the infinite Lychrel status of 196.

