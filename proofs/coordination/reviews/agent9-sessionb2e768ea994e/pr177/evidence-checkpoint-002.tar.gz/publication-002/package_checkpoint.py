#!/usr/bin/env python3
"""Package frozen PR177 stage002 records without modifying source evidence."""
from pathlib import Path
import base64
import gzip
import hashlib
import io
import json
import tarfile

ROOT = Path(__file__).resolve().parents[1]
ARCHIVE = ROOT / "evidence-checkpoint-002.tar.gz"
MANIFEST = ROOT / "ARCHIVE_MANIFEST_002.json"
COLLECTIONS = (
    "supplement-review-002",
    "execution-evidence-copy",
    "publication-001",
    "publication-002",
    "queue-availability",
)
EXTRA = ("DELIVERY_STAGE_002.md",)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def main():
    if ARCHIVE.exists() or MANIFEST.exists():
        raise SystemExit("Refusing to replace a frozen checkpoint")
    for required in ("execution-evidence-copy/README.md",
                     "supplement-review-002/REPORT.md"):
        if not (ROOT / required).is_file():
            raise SystemExit("Missing completed evidence: " + required)
    paths = []
    for name in COLLECTIONS:
        directory = ROOT / name
        if not directory.is_dir():
            raise SystemExit("Missing collection: " + name)
        paths.extend(p for p in directory.rglob("*") if p.is_file())
    paths.extend(ROOT / name for name in EXTRA)
    names = sorted({p.relative_to(ROOT).as_posix(): p for p in paths}.items())
    inventory = []
    with ARCHIVE.open("xb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, mtime=0, compresslevel=9) as zipped:
            with tarfile.open(fileobj=zipped, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for name, path in names:
                    if path.is_symlink():
                        raise SystemExit("Symlink is not a frozen regular input: " + name)
                    data = path.read_bytes()
                    info = tarfile.TarInfo(name)
                    info.size = len(data)
                    info.mode = 0o644
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    archive.addfile(info, io.BytesIO(data))
                    inventory.append({"path": name, "bytes": len(data), "sha256": digest(data)})
    expected = {entry["path"]: entry for entry in inventory}
    with tarfile.open(ARCHIVE, "r:gz") as archive:
        members = archive.getmembers()
        if len(members) != len(expected):
            raise AssertionError("Member count mismatch")
        for member in members:
            if not member.isfile() or member.name not in expected:
                raise AssertionError("Unexpected archive entry")
            data = archive.extractfile(member).read()
            entry = expected[member.name]
            if len(data) != entry["bytes"] or digest(data) != entry["sha256"]:
                raise AssertionError("Lossless verification failed: " + member.name)
    packed = ARCHIVE.read_bytes()
    result = {
        "schema_version": 1,
        "agent": "Agent #9",
        "session": "b2e768ea994e",
        "source_head": "6f48ca108dee4c07588f8c5582bcfef55388537f",
        "archive": {"path": ARCHIVE.name, "bytes": len(packed), "sha256": digest(packed),
                    "member_count": len(inventory),
                    "decoded_bytes": sum(entry["bytes"] for entry in inventory)},
        "lossless_readback": "PASS: every member decoded and matched its original byte count and SHA256",
        "recovery": "tar -xzf evidence-checkpoint-002.tar.gz -C NEW_EMPTY_DIRECTORY",
        "files": inventory,
        "exclusions": [
            "Previously published checkpoint001 remains independently recoverable; it is not nested here.",
            "Regenerable Git checkouts, toolchains and object caches are excluded; exact execution-copy inventory records concrete excluded files and reasons.",
            "The transport base64 and this external manifest are not recursively archived."
        ]
    }
    MANIFEST.write_text(json.dumps(result, indent=2) + "\n")
    (ROOT / "archive-002.b64").write_text(base64.b64encode(packed).decode("ascii"))
    print(json.dumps({"archive": result["archive"],
                      "manifest_sha256": digest(MANIFEST.read_bytes()),
                      "base64_chars": len(base64.b64encode(packed)),
                      "lossless_readback": result["lossless_readback"]}, indent=2))

if __name__ == "__main__":
    main()

