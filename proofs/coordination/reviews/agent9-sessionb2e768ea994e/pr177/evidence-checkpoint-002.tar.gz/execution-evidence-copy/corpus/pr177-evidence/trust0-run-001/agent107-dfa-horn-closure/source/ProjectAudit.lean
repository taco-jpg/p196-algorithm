import Agent107DFAArithmetic
import Agent107DFABoolean
import Agent107DFARelation
import Agent107TransducerBoundary
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check Agent107.FoldedDFA.horn_prefix_invariant
#check Agent107.FoldedDFA.horn_accepting_output
#check Agent107.FoldedDFA.checkHorn_iff
#check Agent107.FoldedDFA.Encoding.checkOneHot_iff
#check Agent107.FoldedDFA.Encoding.BooleanDFA.transition_iff
#check Agent107.FoldedDFA.Encoding.stateIndex?_stateAt
#check Agent107.FoldedDFA.Encoding.liftRelation_stateAt
#check Agent107.FoldedDFA.horn_next_closed
#check Agent107.FoldedDFA.horn_canonical_step
run_cmd do
  let env ← getEnv
  let selected : List String := ["Lychrel196Research", "Agent107TransducerDefs", "Agent107TransducerPath", "Agent107TransducerInput", "Agent107TransducerOutput", "Agent107TransducerNumeric", "Agent107TransducerTablesData", "Agent107TransducerTablesChecks", "Agent107TransducerTables", "Agent107TransducerReachable", "Agent107TransducerGraph", "Agent107DFA", "Agent107DFAHorn", "Agent107DFAArithmetic", "Agent107DFAAlphabet", "Agent107DFAChecker", "Agent107DFABoolean", "Agent107DFARelation", "Agent107TransducerBoundary"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        match info with
        | .axiomInfo v =>
          if v.isUnsafe then logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {mod} {name}"
          else throwError m!"CUSTOM_AXIOM {mod} {name}"
        | .thmInfo _ =>
          count := count + 1
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          for ax in axl do
            if !(union.contains ax) then union := ax :: union
          if axl.any (fun ax => !(allowed.contains ax)) then throwError m!"DISALLOWED_AXIOMS {mod} {name} : {axl}"
          logInfo m!"AUDIT_THEOREM {mod} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
