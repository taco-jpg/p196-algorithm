#!/usr/bin/env python3
"""Audit the freshly built PR177 trust-zero closure without rebuilding modules.

This is separate evidence, not a replacement for the retained original failure
or the independently reviewed repaired-verifier run.
"""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess
import sys
import time
import traceback


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    if len(sys.argv) not in (4, 5):
        raise SystemExit('usage: run_supplement.py TRUST_ZERO_OUTPUT LEAN NEW_OUTPUT [REUSE_SAFE_AUDIT_OUTPUT]')
    prior, lean, out = map(lambda s: Path(s).resolve(), sys.argv[1:4])
    reuse_safe = Path(sys.argv[4]).resolve() if len(sys.argv) == 5 else None
    out.mkdir(parents=True, exist_ok=False)
    report = {'status': 'RUNNING', 'started_at': time.time(), 'commands': [],
              'scope': 'PR177 safe-definition, theorem-origin and literal endpoint audit',
              'full_module_rebuild': False}

    def save():
        (out / 'RESULT.json').write_text(json.dumps(report, indent=2) + '\n')

    try:
        original_report = (prior / 'verification.json').read_bytes()
        checked = json.loads(original_report)
        project = checked['projects']['agent107-dfa-horn-closure']
        assert checked['status'] == 'PASS' and project['status'] == 'PASS'
        assert checked['source_commit'] == '6f48ca108dee4c07588f8c5582bcfef55388537f'
        assert len(project['build_order']) == 19
        assert len(project['commands']) == 20
        assert all(c['exit_code'] == 0 and '--trust=0' in c['argv']
                   for c in project['commands'])
        assert str(lean) in checked['compiler']['files']
        assert all(sha(Path(p).read_bytes()) == h for p, h in checked['compiler']['files'].items())
        source = prior / 'agent107-dfa-horn-closure/source'
        for name, rec in project['sources'].items():
            assert sha((source / (name.replace('.', '/') + '.lean')).read_bytes()) == rec['build_sha256']
        object_pins = {str(p.relative_to(source)): sha(p.read_bytes())
                       for p in sorted(source.rglob('*.olean'))}
        assert len(object_pins) == 19
        report.update(source_commit=checked['source_commit'],
                      prior_report_sha256=sha(original_report),
                      prior_report=str(prior / 'verification.json'),
                      compiler=checked['compiler'], object_pins=object_pins,
                      sources=project['sources'])
        imports = '\n'.join('import ' + n for n in project['roots'])
        selected = json.dumps(project['build_order'])
        audit = imports + '''
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
run_cmd do
  let env ← getEnv
  let selected : List String := ''' + selected + '''
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut theoremCount := 0
  let mut definitionCount := 0
  let mut opaqueCount := 0
  let mut unsafeCount := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let origin := env.allImportedModuleNames[idx.toNat]!
      if selected.contains origin.toString then
        if info.isUnsafe || info.isPartial then
          unsafeCount := unsafeCount + 1
          logInfo m!"UNSAFE_IMPLEMENTATION {origin} {name}"
        else
          match info with
          | .axiomInfo _ => throwError m!"CUSTOM_AXIOM {origin} {name}"
          | _ => pure ()
          let category := match info with
            | .thmInfo _ => "THEOREM"
            | .defnInfo _ => "DEFINITION"
            | .opaqueInfo _ => "OPAQUE"
            | _ => ""
          if category != "" then
            if (Lean.Compiler.getImplementedBy? env name).isSome then
              throwError m!"PROJECT_IMPLEMENTED_BY {origin} {name}"
            if (Lean.getExternAttrData? env name).isSome then
              throwError m!"PROJECT_EXTERN {origin} {name}"
            let axs ← liftCoreM (Lean.collectAxioms name)
            let axl := axs.toList
            if axl.any (fun ax => !(allowed.contains ax)) then
              throwError m!"DISALLOWED_AXIOMS {origin} {name} : {axl}"
            for ax in axl do
              if !(union.contains ax) then union := ax :: union
            if category == "THEOREM" then theoremCount := theoremCount + 1
            if category == "DEFINITION" then definitionCount := definitionCount + 1
            if category == "OPAQUE" then opaqueCount := opaqueCount + 1
            logInfo m!"AUDIT_{category} {origin} {name} : {axl}"
  logInfo m!"SAFE_AUDIT theorems={theoremCount} definitions={definitionCount} opaques={opaqueCount} unsafe_implementation={unsafeCount} union={union}"
'''
        audit_path = out / 'SafeDefinitionAudit.lean'
        audit_path.write_text(audit)
        env = {'PATH': str(lean.parent) + ':/usr/bin:/bin',
               'LANG': 'C.UTF-8', 'LEAN_PATH': str(source)}

        def run(label, path):
            argv = [str(lean), '--trust=0', '-j1', '-DElab.async=false', str(path)]
            start = time.monotonic()
            log = out / (label + '.log')
            with log.open('wb') as stream:
                try:
                    rc = subprocess.run(argv, cwd=out, env=env, stdout=stream,
                                        stderr=subprocess.STDOUT, timeout=600).returncode
                except subprocess.TimeoutExpired:
                    rc = 124
            report['commands'].append({'label': label, 'argv': argv, 'exit_code': rc,
                                       'elapsed_seconds': time.monotonic() - start,
                                       'source_sha256': sha(path.read_bytes()),
                                       'log_sha256': sha(log.read_bytes())})
            save()
            print(label, 'exit=' + str(rc), flush=True)
            if rc != 0:
                raise RuntimeError('Failed ' + label + '; retained log: ' + str(log))
            return log.read_text()

        if reuse_safe is None:
            audit_log = run('SafeDefinitionAudit', audit_path)
        else:
            retained = json.loads((reuse_safe / 'RESULT.json').read_text())
            command = retained['commands'][0]
            assert retained['prior_report_sha256'] == report['prior_report_sha256']
            assert retained['sources'] == report['sources']
            assert retained['object_pins'] == report['object_pins']
            assert retained['compiler'] == report['compiler']
            assert command['label'] == 'SafeDefinitionAudit' and command['exit_code'] == 0
            assert command['argv'][:4] == [str(lean), '--trust=0', '-j1', '-DElab.async=false']
            assert sha(audit_path.read_bytes()) == command['source_sha256']
            assert (reuse_safe / 'SafeDefinitionAudit.lean').read_bytes() == audit_path.read_bytes()
            retained_log = (reuse_safe / 'SafeDefinitionAudit.log').read_bytes()
            assert sha(retained_log) == command['log_sha256']
            (out / 'SafeDefinitionAudit.log').write_bytes(retained_log)
            report['commands'].append(dict(command, execution='REUSED_EXACT_SUCCESS',
                                           reused_from=str(reuse_safe / 'RESULT.json')))
            audit_log = retained_log.decode()
            print('SafeDefinitionAudit reused exact successful execution', flush=True)
        rows = re.findall(r'^AUDIT_(THEOREM|DEFINITION|OPAQUE) (\S+) (\S+) : (.*)$', audit_log, re.M)
        assert len({r[2] for r in rows}) == len(rows)
        summaries = re.findall(r'^SAFE_AUDIT theorems=(\d+) definitions=(\d+) opaques=(\d+) unsafe_implementation=(\d+) union=(\[[\s\S]*?\])', audit_log, re.M)
        assert len(summaries) == 1
        counts = {k: sum(r[0] == k for r in rows) for k in ('THEOREM', 'DEFINITION', 'OPAQUE')}
        assert [int(x) for x in summaries[0][:3]] == list(counts.values())
        assert counts['THEOREM'] == project['theorem_count']
        assert counts['DEFINITION'] > 0
        unsafe = re.findall(r'^UNSAFE_IMPLEMENTATION (\S+) (\S+)$', audit_log, re.M)
        assert len(unsafe) == int(summaries[0][3])
        fresh_modules = {n for n in project['build_order'] if n.startswith('Agent107DFA')}
        literal_names = sorted(r[2] for r in rows if r[0] == 'THEOREM' and r[1] in fresh_modules)
        assert literal_names
        literal = imports + '''
import Lean
open Lean Elab Command
run_cmd do
  let env ← getEnv
  let selected : List String := ''' + json.dumps(sorted(fresh_modules)) + '''
  let mut count := 0
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let origin := env.allImportedModuleNames[idx.toNat]!
      if selected.contains origin.toString then
        match info with
        | .thmInfo _ =>
          count := count + 1
          elabCommand (← `(#print axioms $(mkIdent name)))
        | _ => pure ()
  logInfo m!"LITERAL_AXIOM_COMMAND_COUNT {count}"
''' + '\n'.join('#check ' + n for n in project['endpoints']) + '\n'
        literal_path = out / 'LiteralEndpointAudit.lean'
        literal_path.write_text(literal)
        literal_log = run('LiteralEndpointAudit', literal_path)
        printed_names = re.findall(r"^'([^']+)' (?:depends on axioms:|does not depend on any axioms)", literal_log, re.M)
        assert sorted(printed_names) == literal_names
        assert len(printed_names) == len(set(printed_names))
        assert re.findall(r'^LITERAL_AXIOM_COMMAND_COUNT (\d+)$', literal_log, re.M) == [str(len(literal_names))]
        assert all(sha((source / p).read_bytes()) == h for p, h in object_pins.items())
        for name, rec in project['sources'].items():
            assert sha((source / (name.replace('.', '/') + '.lean')).read_bytes()) == rec['build_sha256']
        assert all(sha(Path(p).read_bytes()) == h for p, h in checked['compiler']['files'].items())
        assert (prior / 'verification.json').read_bytes() == original_report
        report.update(status='PASS', counts=counts, axiom_union=' '.join(summaries[0][4].split()),
                      unsafe_implementation_declarations=unsafe,
                      literal_theorem_count=len(literal_names),
                      literal_theorem_names=literal_names,
                      checked_endpoints=project['endpoints'],
                      new_modules=sorted(fresh_modules))
        return 0
    except Exception as error:
        report.update(status='FAIL', error=str(error))
        (out / 'failure.txt').write_text(traceback.format_exc())
        print('FAIL:', error, flush=True)
        return 1
    finally:
        report['finished_at'] = time.time()
        save()
        files = {p.name: {'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
                 for p in sorted(out.iterdir()) if p.is_file() and p.name != 'FILES.json'}
        (out / 'FILES.json').write_text(json.dumps(files, indent=2) + '\n')


if __name__ == '__main__':
    raise SystemExit(main())
