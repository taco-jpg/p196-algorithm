import Agent107DFAArithmetic
import Agent107DFABoolean
import Agent107DFARelation
import Agent107TransducerBoundary
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
run_cmd do
  let env ← getEnv
  let selected : List String := ["Lychrel196Research", "Agent107TransducerDefs", "Agent107TransducerPath", "Agent107TransducerInput", "Agent107TransducerOutput", "Agent107TransducerNumeric", "Agent107TransducerTablesData", "Agent107TransducerTablesChecks", "Agent107TransducerTables", "Agent107TransducerReachable", "Agent107TransducerGraph", "Agent107DFA", "Agent107DFAHorn", "Agent107DFAArithmetic", "Agent107DFAAlphabet", "Agent107DFAChecker", "Agent107DFABoolean", "Agent107DFARelation", "Agent107TransducerBoundary"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut theoremCount := 0
  let mut definitionCount := 0
  let mut opaqueCount := 0
  let mut unsafeCount := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let origin := env.allImportedModuleNames[idx.toNat]!
      if selected.contains origin.toString then
        if info.isUnsafe || info.isPartial then
          unsafeCount := unsafeCount + 1
          logInfo m!"UNSAFE_IMPLEMENTATION {origin} {name}"
        else
          match info with
          | .axiomInfo _ => throwError m!"CUSTOM_AXIOM {origin} {name}"
          | _ => pure ()
          let category := match info with
            | .thmInfo _ => "THEOREM"
            | .defnInfo _ => "DEFINITION"
            | .opaqueInfo _ => "OPAQUE"
            | _ => ""
          if category != "" then
            if (Lean.Compiler.getImplementedBy? env name).isSome then
              throwError m!"PROJECT_IMPLEMENTED_BY {origin} {name}"
            if (Lean.getExternAttrData? env name).isSome then
              throwError m!"PROJECT_EXTERN {origin} {name}"
            let axs ← liftCoreM (Lean.collectAxioms name)
            let axl := axs.toList
            if axl.any (fun ax => !(allowed.contains ax)) then
              throwError m!"DISALLOWED_AXIOMS {origin} {name} : {axl}"
            for ax in axl do
              if !(union.contains ax) then union := ax :: union
            if category == "THEOREM" then theoremCount := theoremCount + 1
            if category == "DEFINITION" then definitionCount := definitionCount + 1
            if category == "OPAQUE" then opaqueCount := opaqueCount + 1
            logInfo m!"AUDIT_{category} {origin} {name} : {axl}"
  logInfo m!"SAFE_AUDIT theorems={theoremCount} definitions={definitionCount} opaques={opaqueCount} unsafe_implementation={unsafeCount} union={union}"
