import Agent107DFAArithmetic
import Agent107DFABoolean
import Agent107DFARelation
import Agent107TransducerBoundary
import Lean
open Lean Elab Command
set_option pp.width 120
run_cmd do
  let env ← getEnv
  let selected : List String := ["Agent107DFA", "Agent107DFAAlphabet", "Agent107DFAArithmetic", "Agent107DFABoolean", "Agent107DFAChecker", "Agent107DFAHorn", "Agent107DFARelation"]
  let mut count := 0
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let origin := env.allImportedModuleNames[idx.toNat]!
      if selected.contains origin.toString then
        match info with
        | .thmInfo _ =>
          count := count + 1
          elabCommand (← `(#print axioms $(mkIdent name)))
        | _ => pure ()
  logInfo m!"LITERAL_AXIOM_COMMAND_COUNT {count}"
#check Agent107.FoldedDFA.horn_prefix_invariant
#check Agent107.FoldedDFA.horn_accepting_output
#check Agent107.FoldedDFA.checkHorn_iff
#check Agent107.FoldedDFA.Encoding.checkOneHot_iff
#check Agent107.FoldedDFA.Encoding.BooleanDFA.transition_iff
#check Agent107.FoldedDFA.Encoding.stateIndex?_stateAt
#check Agent107.FoldedDFA.Encoding.liftRelation_stateAt
#check Agent107.FoldedDFA.horn_next_closed
#check Agent107.FoldedDFA.horn_canonical_step
