#!/usr/bin/env python3
"""Read-only Agent1 evidence snapshot; no Lean, GitHub, or source mutations.

Run once in a fresh directory containing only this program. The program copies
exact bytes, verifies recorded claims, writes its receipt and freezes its output.
All paths below are scope restrictions, not a general workspace backup.
"""
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256, sha1
import json
import io
import os
from pathlib import Path
import stat
import sys
import tarfile

ORIGIN = Path('/workspace/scratch/7efd48098de6')
OUT = Path(__file__).resolve().parent
H = '6f48ca108dee4c07588f8c5582bcfef55388537f'
B = '74a1c3922eb7af438fe40b23d2105ad07556e3f5'
ROOTS = ('pr177-evidence', 'pr177-review')
EXTRA = (
    'proofs/verify_project__214bf7673efe116b.py',
    'proofs/verify_project_pr177_reviewed.py',
    'proofs/contributions/agent-107/dfa-horn-closure-20261016/verification/Agent107DFAHorn.verify-registry.json',
)
EXPECTED_OLD_DRAFT = {
    'bytes': 8817,
    'sha256': '7b195d686863dde8b7b9e7fe281614e2a67579cc4c26062a89a52f405dd8dc70',
}
checks = []
observations = []


def utc():
    return datetime.now(timezone.utc).isoformat()


def digest(data):
    return {'bytes': len(data), 'sha256': sha256(data).hexdigest()}


def write_json(name, data):
    p = OUT / name
    p.parent.mkdir(parents=True, exist_ok=True)
    with p.open('x', encoding='utf-8') as f:
        f.write(json.dumps(data, indent=2, sort_keys=True, ensure_ascii=False) + '\n')


def check(label, actual, expected):
    checks.append({'check': label, 'status': 'PASS' if actual == expected else 'FAIL',
                   'actual': actual, 'expected': expected})


def enumerate_roots():
    result = {}
    for label in ROOTS:
        root = ORIGIN / label
        for directory, dirs, files in os.walk(root, followlinks=False):
            dirs.sort()
            files.sort()
            for name in files:
                p = Path(directory) / name
                result[str(p.relative_to(ORIGIN))] = p
            for name in list(dirs):
                p = Path(directory) / name
                if p.is_symlink():
                    result[str(p.relative_to(ORIGIN))] = p
                    dirs.remove(name)
    return result


def stat_record(s):
    return {'device': s.st_dev, 'inode': s.st_ino, 'bytes': s.st_size,
            'mtime_ns': s.st_mtime_ns, 'ctime_ns': s.st_ctime_ns,
            'mode': stat.S_IMODE(s.st_mode)}


def read_observed(p, phase):
    before = p.lstat()
    if not stat.S_ISREG(before.st_mode):
        raise ValueError(f'Non-regular input: {p}')
    data = p.read_bytes()
    after = p.lstat()
    if stat_record(before) != stat_record(after):
        observations.append({'kind': 'CHANGED_DURING_READ', 'phase': phase,
                             'origin': str(p), 'before': stat_record(before),
                             'after': stat_record(after)})
    return data, stat_record(before), stat_record(after)


def exclusion(label):
    p = Path(label)
    if '.git' in p.parts:
        return 'Git checkout infrastructure; outside the requested evidence corpus.'
    if p.suffix in {'.olean', '.ilean'}:
        return 'Reproducible Lean compiled object; exact origin, byte count and SHA256 retained; source and execution evidence copied.'
    if p.suffix in {'.pyc', '.pyo'}:
        return 'Reproducible Python bytecode cache; complete Python source versions copied.'
    if p.suffix in {'.o', '.obj', '.a', '.so', '.dll', '.dylib', '.bc'}:
        return 'Reproducible native/compiler object; exact origin, byte count and SHA256 retained.'
    return None


def copied(label):
    return OUT / 'corpus' / label


def load(label):
    return json.loads(copied(label).read_text())


def copied_digest(label):
    return digest(copied(label).read_bytes())


def safe_child(parent, name):
    q = Path(name)
    if q.is_absolute() or '..' in q.parts:
        raise ValueError(f'Unexpected manifest path: {name}')
    return str(Path(parent) / q)


started = utc()
if set(OUT.iterdir()) != {Path(__file__).resolve()}:
    raise SystemExit('Refusing to overwrite a pre-existing snapshot directory.')

# Preserve the complete frozen first archival-validation attempt. Its seven
# failed comparisons came from an Agent9 schema mistake: PRELIMINARY_FILES
# records also include path. No source or actual Lean execution failed here.
prior_attempt = OUT.with_name('execution-evidence-copy-attempt-001')
prior_manifest = json.loads((prior_attempt / 'FILES.json').read_text())
for rel, pin in prior_manifest.items():
    check('retained archival attempt manifest: ' + rel,
          digest((prior_attempt / rel).read_bytes()), pin)
prior_copy_count = 0
for p in sorted(prior_attempt.rglob('*')):
    if p.is_file():
        target = OUT / 'preservation-attempt-001' / p.relative_to(prior_attempt)
        target.parent.mkdir(parents=True, exist_ok=True)
        data = p.read_bytes()
        with target.open('xb') as f:
            f.write(data)
        check('retained archival attempt byte identity: ' + str(p.relative_to(prior_attempt)), digest(target.read_bytes()), digest(data))
        prior_copy_count += 1

initial = enumerate_roots()
# Limited historical-byte search in the available saved package copies. This
# hashes data and reads archive members in memory; it executes/extracts nothing.
package_root = ORIGIN / 'pr177-package'
package_files = sorted(p for p in package_root.rglob('*') if p.is_file())
package_search = {'root': str(package_root), 'target': EXPECTED_OLD_DRAFT,
                  'files': [], 'archive_members': [], 'matches': [],
                  'qualification': 'Read-only comparison of available saved bytes; no guessed reconstruction, archive extraction, tests, or Lean execution.'}
for p in package_files:
    data, before, after = read_observed(p, 'historical draft package search')
    pin = digest(data)
    package_search['files'].append({'origin': str(p), **pin})
    if pin == EXPECTED_OLD_DRAFT:
        package_search['matches'].append({'origin': str(p), **pin})
        initial[str(p.relative_to(ORIGIN))] = p
    if p.name.endswith('.tar.xz'):
        with tarfile.open(fileobj=io.BytesIO(data), mode='r:xz') as archive:
            for member in archive:
                if member.isfile():
                    member_data = archive.extractfile(member).read()
                    member_pin = digest(member_data)
                    row = {'archive': str(p), 'member': member.name, **member_pin}
                    package_search['archive_members'].append(row)
                    if member_pin == EXPECTED_OLD_DRAFT:
                        package_search['matches'].append(row)
                        recovered = OUT / 'recovered-historical-draft' / (sha256(member_data).hexdigest() + '.py')
                        recovered.parent.mkdir(parents=True, exist_ok=True)
                        if not recovered.exists():
                            recovered.write_bytes(member_data)
package_search['listing_unchanged'] = package_files == sorted(p for p in package_root.rglob('*') if p.is_file())
check('saved package search listing stability', package_search['listing_unchanged'], True)
review_data, _, _ = read_observed(ORIGIN / 'pr177-review/review-inputs.json', 'input discovery')
review_inputs = json.loads(review_data)
extra_paths = sorted({x['path'] for x in review_inputs['files']} | set(EXTRA))
for rel in extra_paths:
    if Path(rel).is_absolute() or '..' in Path(rel).parts or not rel.startswith('proofs/'):
        raise ValueError(f'Out-of-scope review input: {rel}')
    label = 'agent1-repo/' + rel
    initial[label] = ORIGIN / label

inventory = []
excluded = []
copy_manifest = {}
for label, path in sorted(initial.items()):
    try:
        data, before, after = read_observed(path, 'snapshot')
    except Exception as exc:
        observations.append({'kind': 'MISSING_OR_UNREADABLE_INPUT', 'origin': str(path),
                             'error': repr(exc)})
        continue
    row = {'origin': str(path), 'origin_relative': label, **digest(data),
           'stat_before': before, 'stat_after': after}
    reason = exclusion(label)
    if reason:
        row.update(disposition='EXCLUDED', reason=reason)
        excluded.append(dict(row))
    else:
        target = copied(label)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as f:
            f.write(data)
        row.update(disposition='COPIED', copy_path=str(target.relative_to(OUT)))
        copy_manifest[row['copy_path']] = digest(data)
        check('copy byte identity: ' + label, digest(target.read_bytes()), digest(data))
    inventory.append(row)

# Verify all original per-attempt manifests against preserved bytes.
manifest_results = []
for run in ('canonical-run-001', 'trust0-run-001', 'supplement-001', 'supplement-002'):
    parent = 'pr177-evidence/' + run
    entries = load(parent + '/FILES.json')
    for rel, pin in entries.items():
        label = safe_child(parent, rel)
        check('original manifest: ' + label, copied_digest(label), pin)
    manifest_results.append({'manifest': parent + '/FILES.json', 'entries': len(entries)})

# The preliminary manifest intentionally remains unmodified, including its stale
# pre-execution draft pin. Treat only this known exact historical pin as a caveat.
preliminary = load('pr177-evidence/PRELIMINARY_FILES.json')
historical_caveats = []
for rel, full_pin in preliminary.items():
    pin = {k: full_pin[k] for k in ('bytes', 'sha256')}
    check('preliminary manifest origin: ' + rel, full_pin['path'], str(ORIGIN / 'pr177-evidence' / rel))
    actual = copied_digest(safe_child('pr177-evidence', rel))
    if rel == 'run_supplement.py' and pin == EXPECTED_OLD_DRAFT and actual != pin:
        matching = [x['origin_relative'] for x in inventory if x['sha256'] == pin['sha256']]
        historical_caveats.append({
            'status': ('HISTORICAL_SUPERSEDED_DRAFT_RECOVERED' if matching or package_search['matches'] else 'HISTORICAL_SUPERSEDED_DRAFT_NOT_LOCATED_IN_SCOPED_INPUTS_OR_SAVED_PACKAGES'),
            'manifest': 'pr177-evidence/PRELIMINARY_FILES.json', 'path': rel,
            'historical_pin': pin, 'current_copied_pin': actual,
            'matching_scoped_input_paths': matching,
            'saved_package_matches': package_search['matches'],
            'pre_execution_qualification_source': {'file': 'corpus/pr177-review/supplement-review.md', 'section': 'Review and corrections', 'statement': 'The first draft had two concrete evidence issues, both fixed before execution', 'evidence_type': 'Statement in retained independent review, not independently timestamp-attested by Agent9.'},
            'qualification': 'The retained independent supplement review identifies corrections to the first draft before execution. Both actual executed runner versions and both actual attempts are preserved. No missing executed attempt is inferred from this pre-execution draft mismatch.'})
    else:
        check('preliminary manifest: ' + rel, actual, pin)

check('copied input manifest equals discovery bytes',
      copied('pr177-review/review-inputs.json').read_bytes() == review_data, True)
check('review input source head', review_inputs['head'], H)
check('review input source base', review_inputs['base'], B)
check('review input path count', len(review_inputs['files']), 75)
for row in review_inputs['files']:
    data = copied('agent1-repo/' + row['path']).read_bytes()
    check('review input byte/hash pin: ' + row['path'], digest(data),
          {'bytes': row['bytes'], 'sha256': row['sha256']})
    blob = sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    check('review input Git blob pin: ' + row['path'], blob, row['git_blob'])

scope_registry = 'agent1-repo/' + EXTRA[2]
registry_sha = copied_digest(scope_registry)['sha256']
run_summaries = []
reports = {}
for run, expected_status, count in (('canonical-run-001', 'FAIL', 19), ('trust0-run-001', 'PASS', 20)):
    prefix = 'pr177-evidence/' + run
    d = load(prefix + '/verification.json')
    reports[run] = d
    project_name = 'agent107-dfa-horn-closure'
    project = d['projects'][project_name]
    check(run + ' source head', d['source_commit'], H)
    check(run + ' recorded clean source tree', d['source_tree_clean'], True)
    check(run + ' report status', d['status'], expected_status)
    check(run + ' registry binding', d['registry_sha256'], registry_sha)
    check(run + ' module count', len(project['sources']), 19)
    check(run + ' command count', len(project['commands']), count)
    for module, source in project['sources'].items():
        label = prefix + '/' + project_name + '/source/' + module + '.lean'
        actual = copied_digest(label)['sha256']
        check(run + ' source SHA256: ' + module, actual, source['sha256'])
        check(run + ' build SHA256: ' + module, actual, source['build_sha256'])
    for cmd in project['commands']:
        check(run + ' log SHA256: ' + cmd['label'],
              copied_digest(safe_child(prefix, cmd['log']))['sha256'], cmd['log_sha256'])
        check(run + ' command exit: ' + cmd['label'], cmd['exit_code'], 0)
        check(run + ' explicit trust zero: ' + cmd['label'], '--trust=0' in cmd['argv'], run == 'trust0-run-001')
    run_summaries.append({'run': run, 'recorded_status': d['status'],
                          'commands': len(project['commands']),
                          'command_exits': dict(Counter(str(x['exit_code']) for x in project['commands'])),
                          'explicit_trust_zero': run == 'trust0-run-001',
                          'error': d.get('error'), 'repository_wide_pass': d['repository_wide_pass']})

strict = reports['trust0-run-001']
strict_project = strict['projects']['agent107-dfa-horn-closure']
by_origin = {x['origin_relative']: x for x in inventory}
for run, expected_status, expected_exits in (('supplement-001', 'FAIL', [0, 1]), ('supplement-002', 'PASS', [0, 0])):
    prefix = 'pr177-evidence/' + run
    d = load(prefix + '/RESULT.json')
    check(run + ' source head', d['source_commit'], H)
    check(run + ' status', d['status'], expected_status)
    check(run + ' command exits', [x['exit_code'] for x in d['commands']], expected_exits)
    check(run + ' no full rebuild', d['full_module_rebuild'], False)
    check(run + ' compiler map continuity', d['compiler'], strict['compiler'])
    check(run + ' source map continuity', d['sources'], strict_project['sources'])
    check(run + ' prior report binding', d['prior_report_sha256'],
          copied_digest('pr177-evidence/trust0-run-001/verification.json')['sha256'])
    check(run + ' object pin count', len(d['object_pins']), 19)
    for name, pin in d['object_pins'].items():
        obj_label = 'pr177-evidence/trust0-run-001/agent107-dfa-horn-closure/source/' + name
        check(run + ' excluded object hash: ' + name, by_origin[obj_label]['sha256'], pin)
        check(run + ' excluded object disposition: ' + name, by_origin[obj_label]['disposition'], 'EXCLUDED')
    for cmd in d['commands']:
        label = prefix + '/' + cmd['label']
        check(run + ' audit source hash: ' + cmd['label'], copied_digest(label + '.lean')['sha256'], cmd['source_sha256'])
        check(run + ' audit log hash: ' + cmd['label'], copied_digest(label + '.log')['sha256'], cmd['log_sha256'])
        check(run + ' explicit trust zero: ' + cmd['label'], '--trust=0' in cmd['argv'], True)
    if run == 'supplement-002':
        prior = load('pr177-evidence/supplement-001/RESULT.json')['commands'][0]
        current = d['commands'][0]
        check('supplement-002 exact successful safe command reuse',
              {k: current[k] for k in prior}, prior)
        check('supplement-002 reuse label', current.get('execution'), 'REUSED_EXACT_SUCCESS')
        for suffix in ('.lean', '.log'):
            check('supplement-002 reused safe bytes ' + suffix,
                  copied_digest(prefix + '/SafeDefinitionAudit' + suffix),
                  copied_digest('pr177-evidence/supplement-001/SafeDefinitionAudit' + suffix))
    run_summaries.append({'run': run, 'recorded_status': d['status'],
                          'command_exits': [x['exit_code'] for x in d['commands']],
                          'commands': [{k: v for k, v in c.items() if k in ('label', 'exit_code', 'execution', 'reused_from')} for c in d['commands']],
                          'error': d.get('error'), 'full_module_rebuild': False})

for source, reference in (
    ('agent1-repo/' + EXTRA[0], 'pr177-evidence/verify_project.original.py'),
    ('agent1-repo/' + EXTRA[1], 'pr177-evidence/verify_project.repaired.py'),
    ('agent1-repo/proofs/Agent107DFAHorn.registry.json', 'pr177-evidence/registry-original.json'),
):
    check('actual input duplicate binding: ' + source, copied_digest(source), copied_digest(reference))
approved_runners = {
    'pr177-evidence/run_supplement.v1.py': 'a96fb1f93b13eed7a733cf871d875c5d5c0ef878cf7d7072fc3e4196cfbfe3c9',
    'pr177-evidence/run_supplement.py': '1aeedfea7977790e0eea844532e33809ce0976a83df754d00aca8c56275daf5f',
    'pr177-evidence/verify_project.repaired.py': 'b3108555ed0a3eee6a339ca7346f85ad2636c5008e250c675bf843542db7500f',
}
for label, pin in approved_runners.items():
    check('retained reviewed executable script: ' + label, copied_digest(label)['sha256'], pin)

# Re-enumerate roots and re-read every included/excluded regular file. This is a
# bounded stability observation, not an atomic filesystem snapshot guarantee.
final_roots = enumerate_roots()
original_root_names = {x for x in initial if x.split('/')[0] in ROOTS}
added = sorted(set(final_roots) - original_root_names)
removed = sorted(original_root_names - set(final_roots))
if added or removed:
    observations.append({'kind': 'ROOT_LISTING_CHANGED', 'added': added, 'removed': removed})
for row in inventory:
    try:
        data, before, after = read_observed(Path(row['origin']), 'final stability read')
        row['final_read'] = {**digest(data), 'stat_before': before, 'stat_after': after}
        if digest(data) != {k: row[k] for k in ('bytes', 'sha256')} or before != row['stat_after']:
            observations.append({'kind': 'INPUT_CHANGED_AFTER_COPY', 'origin': row['origin'],
                                 'initial_sha256': row['sha256'], 'final_sha256': digest(data)['sha256'],
                                 'initial_stat': row['stat_after'], 'final_stat': before})
    except Exception as exc:
        observations.append({'kind': 'MISSING_DURING_FINAL_READ', 'origin': row['origin'], 'error': repr(exc)})
check('all scoped inputs read', len(inventory), len(initial))
check('no observed source mutation or disappearance', observations, [])
check('no lost root paths', removed, [])
check('no unpreserved newly added root paths', added, [])

failed = [c for c in checks if c['status'] == 'FAIL']
status = 'FAIL' if failed else ('PASS_WITH_HISTORICAL_MANIFEST_CAVEAT' if historical_caveats else 'PASS')
summary = {
    'status': status, 'source_head': H, 'source_base': B,
    'started_at_utc': started, 'completed_at_utc': utc(),
    'actual_lean_executor': 'Agent #1', 'preservation_and_readback': 'Agent #9 scoped evidence reviewer',
    'prior_preservation_attempt': {'path': 'preservation-attempt-001', 'files': prior_copy_count, 'status': 'FAIL', 'exit_code': 1, 'reason': 'Agent9 validator compared a bytes/SHA256 pair to preliminary manifest records also containing path. Six current content hashes already matched; the seventh was the acknowledged historical draft. Corrected attempt separately verifies path and content fields. The entire first attempt remains byte-identical.'},
    'lean_execution_by_this_program': 'NOT_RUN', 'remote_writes': 'NOT_PERFORMED',
    'repository_wide_pass': False, 'source_and_main_writes': 'NOT_PERFORMED',
    'scope': {'full_roots': [str(ORIGIN / x) for x in ROOTS],
              'selected_checkout_inputs': ['agent1-repo/' + p for p in extra_paths],
              'checkout_infrastructure': 'Not traversed; only explicit review input paths and verifier files were read.',
              'runtime_binaries': 'Not copied. Compiler pins remain in actual receipts; this preservation program compares their continuity but does not execute or re-certify the runtime.'},
    'counts': {'inventoried_files': len(inventory), 'copied_files': len(copy_manifest),
               'copied_bytes': sum(x['bytes'] for x in copy_manifest.values()),
               'excluded_files': len(excluded), 'excluded_bytes': sum(x['bytes'] for x in excluded),
               'excluded_suffixes': dict(Counter(Path(x['origin']).suffix for x in excluded)),
               'original_manifests_checked': len(manifest_results),
               'original_manifest_entries_checked': sum(x['entries'] for x in manifest_results),
               'checks': len(checks), 'failed_checks': len(failed)},
    'original_manifests': manifest_results, 'execution_history': run_summaries,
    'historical_caveats': historical_caveats, 'movement_or_missing_observations': observations,
    'historical_draft_package_search': {'files_compared': len(package_search['files']), 'archive_members_compared': len(package_search['archive_members']), 'matches': package_search['matches'], 'details': 'HISTORICAL_DRAFT_SEARCH.json'},
    'stability_qualification': 'Complete root listings and all scoped file bytes/stat metadata agreed across the two observations. This is not an atomic filesystem snapshot and does not promise future immutability of external origins.',
    'freeze_policy': 'Program writes complete receipts and manifest, then chmods every output file 0444 and every output directory 0555. No further mutation is authorized for this frozen copy.',
}
write_json('ORIGIN_INVENTORY.json', inventory)
write_json('EXCLUDED_FILES.json', excluded)
write_json('COPY_MANIFEST.json', copy_manifest)
write_json('CHECKS.json', checks)
write_json('SNAPSHOT_RESULT.json', summary)
write_json('HISTORICAL_DRAFT_SEARCH.json', package_search)

readme = f'''# PR177 execution evidence preservation

## Result and custody

**{status}** for byte-preserving archival and recorded-hash readback.
Source head: `{H}`. Base: `{B}`.
Snapshot observation window: {started} to {summary['completed_at_utc']}.

The actual Lean executor and verification publisher is **Agent #1**. Agent #9
only copied and checked evidence bytes. Agent #9 did not execute Lean, rebuild
the 19-module closure, alter source, publish remotely, or assume verification
ownership. Agent #107 remains source owner and Agent #31 remains main writer.
This archive is ready for Agent #9's authorized publication without waiting for
another Agent #1 packaging step. It does not claim repository-wide PASS.

## Exact retained scope

- `corpus/pr177-evidence/`: every substantive file from the named evidence root,
  including original/repaired verifier scripts, both supplemental runner versions,
  patches, registries, all four console logs, all run receipts, raw logs, generated
  Lean audit programs, source snapshots, manifests and failure files.
- `corpus/pr177-review/`: all six review/input files from the named review root.
  These are retained reports by their original authors, not new reviews by Agent #9.
- `corpus/agent1-repo/`: all 75 exact paths named in `review-inputs.json`, plus the
  original and repaired runnable verifier scripts. The scoped input registry is
  already among the 75 paths. This preserves the actual author failure snapshots
  and logs, input sources, metadata and verifier registry without checkout
  infrastructure. Every path matches its recorded byte count, SHA256 and Git blob
  identifier. Full origin names are retained in `ORIGIN_INVENTORY.json`.

There are **{len(copy_manifest)} copied source artifacts** totaling
**{sum(x['bytes'] for x in copy_manifest.values()):,} bytes**. There are
**{len(excluded)} explicitly excluded files**, each with origin, exact size,
SHA256 and reason in `EXCLUDED_FILES.json`: 38 reproducible `.olean` files and
one Python bytecode cache. Both supplements' 19 exact object pins match the
excluded strict-run object hashes. No object is presented as source evidence.
No `.ilean` or native objects occurred in the two enumerated roots. Checkout
and `.git` infrastructure were not traversed. Runtime binaries outside these
roots are not duplicated; their original pins remain in the receipts.

## Preserved actual execution history

| Attempt | Preserved outcome | Exact qualification |
|---|---|---|
| `canonical-run-001` | FAIL | All 19 module commands exited 0; original commands omit explicit `--trust=0`; endpoint validation then failed before ProjectAudit. The nested project status remains RUNNING in the original FAIL receipt and is not rewritten. |
| `trust0-run-001` | PASS | Repaired verifier: 19 module commands plus ProjectAudit, all 20 exit 0 with explicit `--trust=0`. Retained exact-head report, clean-source receipt, 19 source snapshots and all logs. |
| `supplement-001` | FAIL | SafeDefinitionAudit exit 0; LiteralEndpointAudit exit 1 because `pp.width` is not registered. Raw failed source, output and failure receipt remain unchanged. |
| `supplement-002` | PASS | The exact successful safe stage from attempt 001 is reused and labeled `REUSED_EXACT_SUCCESS`; corrected literal stage freshly exits 0. No third closure build or duplicate safe-stage execution is claimed. |

The retained supplemental result reports 1,453 theorem constants, 414 safe
definitions, no safe opaque declarations, all 115 literal theorem outputs from
the seven new modules, and all nine checked endpoints. Original raw multiline
axiom output is copied in full. The 3,940 implementation entries use the audit's
combined unsafe-or-partial predicate; they must not be called 3,940 unsafe axioms.
The already completed independent supplement readback remains in the separate
frozen `supplement-review-002` deliverable. This preservation program verifies
provenance and hash continuity; it does not repeat that proof/audit review.

## Historical preliminary-manifest caveat

`corpus/pr177-evidence/PRELIMINARY_FILES.json` remains byte-identical. Its
`run_supplement.py` entry names an earlier 8,817-byte draft with SHA256
`{EXPECTED_OLD_DRAFT['sha256']}`. The scoped input search found
{len(historical_caveats[0]['matching_scoped_input_paths']) if historical_caveats else 0}
matching files. A separate read-only search of all {len(package_search['files'])}
available package files and {len(package_search['archive_members'])} regular
members in saved tar.xz archives found **{len(package_search['matches'])} matches**;
every compared path, member and digest is in `HISTORICAL_DRAFT_SEARCH.json`.
The retained independent `supplement-review.md`, section "Review and corrections",
states: "The first draft had two concrete evidence issues, both fixed before
execution". This is an attributed review statement, not an independent Agent9
timestamp attestation. The actual first-run
version is retained as `run_supplement.v1.py` (9,643 bytes, SHA256
`a96fb1f93b13eed7a733cf871d875c5d5c0ef878cf7d7072fc3e4196cfbfe3c9`), and the corrected
continuation is retained as `run_supplement.py` (11,091 bytes, SHA256
`1aeedfea7977790e0eea844532e33809ce0976a83df754d00aca8c56275daf5f`).

The historical mismatch is explicit, not silently repaired or counted as a
matching entry. It is not evidence of an absent executed attempt. All actual
attempt directories currently present are preserved, including failures. A
claim that this archive contains every intermediate pre-execution draft would
be unsupported. Any later recovery of that draft belongs in a separate addendum.

## Agent9 archival-validator attempt preserved

`preservation-attempt-001/` contains the complete original first preservation
attempt, unchanged, including its exact program, FAIL receipt, comparison data,
manifest, README and copied corpus. That program exited 1 after seven comparison
failures because Agent9 compared byte-count/hash pairs against preliminary
manifest records that additionally contain an origin `path` key. Six actual
content hashes already matched. The seventh is the known historical draft
mismatch described above. This is an archival-validator schema error, not a
Lean failure or new source defect. Its original README did not successfully
classify the historical exception; the current README and result supply that
qualification while retaining the original record. The corrected program checks
origin paths separately and compares only bytes/SHA256 for content. No original
manifest or external input was edited.

## Verification and freeze

`snapshot_and_verify.py` is the exact preservation/validation program. It reads
external files only, writes inside this new directory, verifies copied bytes,
checks all {sum(x['entries'] for x in manifest_results)} entries of the four
per-attempt manifests, all recorded command-log and source hashes, both
supplemental audit-source hashes, report and registry bindings, exact successful
reuse, source review pins, and the excluded object pins. `CHECKS.json` records
every comparison; `SNAPSHOT_RESULT.json` records scope, observations and outcomes.

The program observed **{len(observations)} moving/missing-file events**. It
compares complete root listings and rereads all scoped regular files at the end.
This bounded observation is not an atomic filesystem-snapshot guarantee.

`COPY_MANIFEST.json` lists every copied original artifact. Root `FILES.json`
lists every file in this delivery, including original nested manifests and this
program, except itself (self-hashing is not claimed). Each entry has bytes and
SHA256. The program checks the generated manifest and then freezes all files
read-only and all directories non-writable. Its final stdout supplies the root
manifest hash. Root may archive/publish these exact bytes. No earlier checkpoint
or `supplement-review-002` file was changed.

To reproduce preservation in a new authorized directory, copy the exact program
there and run `python snapshot_and_verify.py` while the named origins remain
available. It refuses to overwrite an existing corpus. To verify the frozen
delivery, recompute every entry of root `FILES.json`; no Lean runtime is needed.
'''
with (OUT / 'README.md').open('x', encoding='utf-8') as f:
    f.write(readme)
with (OUT / 'EXECUTION.log').open('x', encoding='utf-8') as f:
    f.write(json.dumps({'program': str(Path(__file__).resolve()), 'argv': sys.argv,
                        'python': sys.version, 'status': status,
                        'checks': len(checks), 'failed_checks': len(failed),
                        'lean_execution': 'NOT_RUN',
                        'result': 'SNAPSHOT_RESULT.json'}, indent=2) + '\n')

manifest = {str(p.relative_to(OUT)): digest(p.read_bytes())
            for p in sorted(OUT.rglob('*')) if p.is_file()}
write_json('FILES.json', manifest)
for rel, pin in manifest.items():
    if digest((OUT / rel).read_bytes()) != pin:
        raise RuntimeError('Generated manifest readback failed: ' + rel)
for p in OUT.rglob('*'):
    if p.is_file():
        p.chmod(0o444)
for p in sorted((p for p in OUT.rglob('*') if p.is_dir()), key=lambda p: len(p.parts), reverse=True):
    p.chmod(0o555)
OUT.chmod(0o555)
if any(stat.S_IMODE(p.stat().st_mode) != (0o555 if p.is_dir() else 0o444) for p in [OUT, *OUT.rglob('*')]):
    raise RuntimeError('Freeze permission readback failed')
print(json.dumps({'status': status, 'result': str(OUT / 'SNAPSHOT_RESULT.json'),
                  'counts': summary['counts'], 'manifest_entries': len(manifest),
                  'root_manifest': digest((OUT / 'FILES.json').read_bytes()),
                  'freeze_applied_and_read_back': True,
                  'lean_execution': 'NOT_RUN'}, indent=2))
sys.exit(1 if failed else 0)
