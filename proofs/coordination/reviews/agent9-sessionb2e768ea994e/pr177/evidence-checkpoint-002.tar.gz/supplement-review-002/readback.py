#!/usr/bin/env python3
"""Read and qualify retained Agent #1 supplement evidence; never invoke Lean.

Only this script's own directory is written. Original/frozen evidence is read-only.
The output explicitly distinguishes reused execution from fresh execution.
"""
from pathlib import Path
import ast
import collections
import datetime
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
EVIDENCE = Path('/workspace/scratch/7efd48098de6/pr177-evidence')
CHECKOUT = Path('/workspace/scratch/b2e768ea994e/agent9-pr177/checkout')
H = '6f48ca108dee4c07588f8c5582bcfef55388537f'
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}
PROJECT = 'agent107-dfa-horn-closure'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def snapshot(relative):
    data = (EVIDENCE / relative).read_bytes()
    dest = ROOT / 'snapshots' / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    return data


def axiom_list(bracket):
    assert bracket.startswith('[') and bracket.endswith(']')
    names = [x.strip() for x in bracket[1:-1].replace('\n', ' ').split(',') if x.strip()]
    assert len(names) == len(set(names)), names
    assert set(names) <= ALLOWED, names
    return sorted(names)


def code_only(text):
    """Mask nested Lean comments and strings while retaining line positions."""
    out, i, depth, string = [], 0, 0, False
    while i < len(text):
        pair = text[i:i+2]
        if depth:
            if pair == '/-': depth += 1; out.extend('  '); i += 2
            elif pair == '-/': depth -= 1; out.extend('  '); i += 2
            else: out.append('\n' if text[i] == '\n' else ' '); i += 1
        elif string:
            if text[i] == '\\': out.extend('  '); i += 2
            else: string = text[i] != '"'; out.append(' '); i += 1
        elif pair == '/-': depth = 1; out.extend('  '); i += 2
        elif pair == '--':
            end = text.find('\n', i); end = len(text) if end < 0 else end
            out.extend(' ' * (end-i)); i = end
        elif text[i] == '"': string = True; out.append(' '); i += 1
        else: out.append(text[i]); i += 1
    assert not depth and not string
    return ''.join(out)


def main():
    result = {'reviewed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
              'source_head': H, 'base': '74a1c3922eb7af438fe40b23d2105ad07556e3f5',
              'lean_invocations_by_reviewer': 0, 'full_module_rebuild_by_reviewer': False,
              'status': 'RUNNING'}
    for name in ['run_supplement.v1.py', 'run_supplement.py',
                 'supplement-001.console.log', 'supplement-002.console.log']:
        snapshot(name)
    old = json.loads(snapshot('supplement-001/RESULT.json'))
    new = json.loads(snapshot('supplement-002/RESULT.json'))
    prior_bytes = snapshot('trust0-run-001/verification.json')
    prior = json.loads(prior_bytes)
    project = prior['projects'][PROJECT]
    assert prior['status'] == project['status'] == 'PASS'
    assert prior['source_commit'] == H and prior['source_tree_clean'] is True
    assert len(project['commands']) == 20
    assert all(c['exit_code'] == 0 and '--trust=0' in c['argv'] for c in project['commands'])
    assert old['status'] == 'FAIL' and new['status'] == 'PASS'
    assert old['source_commit'] == new['source_commit'] == H
    for key in ['prior_report_sha256', 'sources', 'object_pins', 'compiler']:
        assert old[key] == new[key], key
    assert new['prior_report_sha256'] == sha(prior_bytes)
    assert new['sources'] == project['sources'] and new['compiler'] == prior['compiler']
    assert len(new['sources']) == len(new['object_pins']) == 19
    build = EVIDENCE / 'trust0-run-001' / PROJECT / 'source'
    object_results = []
    for name, pin in new['object_pins'].items():
        assert sha((build / name).read_bytes()) == pin
        object_results.append({'name': name, 'sha256': pin})
    source_results = []
    source_tokens = []
    for name, rec in new['sources'].items():
        source = (build / (name + '.lean')).read_bytes()
        assert sha(source) == rec['build_sha256']
        assert sha((CHECKOUT / rec['path']).read_bytes()) == rec['sha256']
        assert rec['sha256'] == rec['build_sha256']
        source_results.append({'module': name, 'sha256': rec['sha256']})
        masked = code_only(source.decode())
        hits = re.findall(r"(?<![\w'])\b(?:unsafe|partial|axiom|sorry|admit|sorryAx|native_decide|implemented_by|extern)\b(?![\w'])", masked)
        if hits: source_tokens.append({'module': name, 'tokens': hits})
    assert source_tokens == [], source_tokens
    for path, pin in new['compiler']['files'].items():
        assert sha(Path(path).read_bytes()) == pin
    manifest_counts = {}
    command_records = []
    for run, data in [('supplement-001', old), ('supplement-002', new)]:
        manifest = json.loads(snapshot(run + '/FILES.json'))
        for name, rec in manifest.items():
            raw = snapshot(run + '/' + name)
            assert len(raw) == rec['bytes'] and sha(raw) == rec['sha256']
        manifest_counts[run] = len(manifest)
        for command in data['commands']:
            label = command['label']
            assert '--trust=0' in command['argv']
            assert '-j1' in command['argv'] and '-DElab.async=false' in command['argv']
            source = EVIDENCE / run / (label + '.lean')
            log = EVIDENCE / run / (label + '.log')
            assert sha(source.read_bytes()) == command['source_sha256']
            assert sha(log.read_bytes()) == command['log_sha256']
            assert sha(Path(command['argv'][-1]).read_bytes()) == command['source_sha256']
            command_records.append({'run': run, **command})
    assert [x['exit_code'] for x in old['commands']] == [0, 1]
    assert [x['exit_code'] for x in new['commands']] == [0, 0]
    assert new['commands'][0]['execution'] == 'REUSED_EXACT_SUCCESS'
    assert {k: v for k, v in new['commands'][0].items() if k not in ['execution', 'reused_from']} == old['commands'][0]
    for name in ['SafeDefinitionAudit.lean', 'SafeDefinitionAudit.log']:
        assert (EVIDENCE / 'supplement-001' / name).read_bytes() == (EVIDENCE / 'supplement-002' / name).read_bytes()
    old_literal = (EVIDENCE / 'supplement-001/LiteralEndpointAudit.lean').read_text()
    literal_source = (EVIDENCE / 'supplement-002/LiteralEndpointAudit.lean').read_text()
    assert old_literal.replace('set_option pp.width 120\n', '') == literal_source
    assert "error: unknown option 'pp.width'" in (EVIDENCE / 'supplement-001/LiteralEndpointAudit.log').read_text()
    safe_log = (EVIDENCE / 'supplement-002/SafeDefinitionAudit.log').read_text()
    safe_re = re.compile(r'^AUDIT_(THEOREM|DEFINITION|OPAQUE) (\S+) (\S+) : (\[[^\[\]]*\])', re.M)
    matches = list(safe_re.finditer(safe_log))
    assert len(matches) == len(re.findall(r'^AUDIT_', safe_log, re.M))
    rows = [{'category': m[1], 'module': m[2], 'name': m[3], 'axioms': axiom_list(m[4]),
             'multiline': '\n' in m[4]} for m in matches]
    assert len(rows) == len({r['name'] for r in rows})
    counts = dict(collections.Counter(r['category'] for r in rows))
    counts.setdefault('OPAQUE', 0)
    assert counts == new['counts'] == {'THEOREM': 1453, 'DEFINITION': 414, 'OPAQUE': 0}
    summary_re = re.compile(r'^SAFE_AUDIT theorems=(\d+) definitions=(\d+) opaques=(\d+) unsafe_implementation=(\d+) union=(\[[^\[\]]*\])', re.M)
    summaries = list(summary_re.finditer(safe_log));assert len(summaries) == 1
    summary = summaries[0]
    assert [int(summary[x]) for x in [1, 2, 3]] == [1453, 414, 0]
    union = sorted({ax for row in rows for ax in row['axioms']})
    assert union == axiom_list(summary[5]) == axiom_list(new['axiom_union'])
    unsafe_re = re.compile(r'^UNSAFE_IMPLEMENTATION (\S+) (\S+)\s*$', re.M)
    unsafe_matches = list(unsafe_re.finditer(safe_log))
    unsafe = [[m[1], m[2]] for m in unsafe_matches]
    assert unsafe == new['unsafe_implementation_declarations']
    assert len(unsafe) == int(summary[4]) == 3940
    assert len({name for _, name in unsafe}) == len(unsafe)
    residue = list(safe_log)
    for match in matches + summaries + unsafe_matches:
        residue[match.start():match.end()] = ' ' * (match.end()-match.start())
    assert not ''.join(residue).strip(), ''.join(residue)[:500]
    prior_theorem_log = (EVIDENCE / 'trust0-run-001' / PROJECT / 'logs/ProjectAudit.log').read_text()
    prior_theorem_names = set(re.findall(r'^AUDIT_THEOREM \S+ (\S+) :', prior_theorem_log, re.M))
    assert {r['name'] for r in rows if r['category'] == 'THEOREM'} == prior_theorem_names
    literal_log = (EVIDENCE / 'supplement-002/LiteralEndpointAudit.log').read_text()
    literal_re = re.compile(r"^'(.+)' (does not depend on any axioms|depends on axioms: (\[[^\[\]]*\]))", re.M)
    literals = [{'name': m[1], 'axioms': [] if m[3] is None else axiom_list(m[3]),
                 'multiline': m[3] is not None and '\n' in m[3]} for m in literal_re.finditer(literal_log)]
    expected = {r['name']: r['axioms'] for r in rows if r['category'] == 'THEOREM' and r['module'] in new['new_modules']}
    assert len(literals) == len(expected) == new['literal_theorem_count'] == 115
    assert len({r['name'] for r in literals}) == 115
    assert {r['name']: r['axioms'] for r in literals} == expected
    assert sorted(expected) == new['literal_theorem_names']
    assert re.findall(r'^LITERAL_AXIOM_COMMAND_COUNT (\d+)$', literal_log, re.M) == ['115']
    assert new['checked_endpoints'] == project['endpoints']
    assert re.findall(r'^#check (\S+)$', literal_source, re.M) == project['endpoints']
    for endpoint in project['endpoints']:
        assert re.search(r'^' + re.escape(endpoint) + r'\s', literal_log, re.M)
        assert endpoint in expected
    assert not re.search(r'error:|sorryAx|DISALLOWED_AXIOMS|CUSTOM_AXIOM|PROJECT_EXTERN|PROJECT_IMPLEMENTED_BY', safe_log + literal_log)
    classification = collections.Counter('cstage' if '._cstage' in n else 'unsafe_rec' if n.endswith('._unsafe_rec') else 'specialization' if '._spec_' in n else 'elambda' if '._elambda_' in n else 'unclassified' for _, n in unsafe)
    assert classification.get('unclassified', 0) == 0
    old_axioms = project['unsafe_implementation_axioms']
    assert all(x in unsafe for x in old_axioms)
    result.update(status='PASS', commands=command_records, manifest_entries=manifest_counts,
                  source_pins=source_results, object_pins=object_results,
                  compiler_files_verified=len(new['compiler']['files']),
                  prior_report_sha256=sha(prior_bytes), counts=counts, axiom_union=union,
                  complete_safe_axiom_rows=len(rows), multiline_safe_axiom_rows=sum(r['multiline'] for r in rows),
                  literal_theorem_count=len(literals), checked_endpoints=project['endpoints'],
                  source_forbidden_or_unsafe_partial_tokens=source_tokens,
                  unsafe_or_partial_count=len(unsafe), unsafe_name_family_counts=dict(classification),
                  unsafe_origin_counts=dict(collections.Counter(x[0] for x in unsafe)),
                  canonical_unsafe_axioms_present=len(old_axioms),
                  unsafe_partial_boolean_split='NOT_RECORDED_BY_AUDIT',
                  new_module_counts={m: dict(collections.Counter(r['category'] for r in rows if r['module']==m)) for m in new['new_modules']},
                  remarks=['SafeDefinitionAudit reused an exact successful execution from supplement-001.',
                           'LiteralEndpointAudit was executed afresh in supplement-002.',
                           'The historical failed literal command remains FAIL.',
                           'Object pins are supplementary before/after receipts linked to the same retained strict build, not hashes retroactively claimed from initial compiler output.'])
    (ROOT / 'PARSED_SAFE_DECLARATIONS.json').write_text(json.dumps(rows, indent=2) + '\n')
    (ROOT / 'PARSED_LITERAL_THEOREMS.json').write_text(json.dumps(literals, indent=2) + '\n')
    (ROOT / 'UNSAFE_OR_PARTIAL.json').write_text(json.dumps(unsafe, indent=2) + '\n')
    (ROOT / 'READBACK_RESULT.json').write_text(json.dumps(result, indent=2) + '\n')
    print(json.dumps({k: v for k, v in result.items() if k not in ['commands','source_pins','object_pins','checked_endpoints','unsafe_origin_counts']}, indent=2))


if __name__ == '__main__':
    main()
