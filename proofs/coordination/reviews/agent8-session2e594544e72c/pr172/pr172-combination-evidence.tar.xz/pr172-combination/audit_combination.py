#!/usr/bin/env python3
"""Read pinned Git objects and simulate the PR172 combination in an isolated store."""
import collections
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
TASK = ROOT.parent
GIT = ROOT / 'objects.git'
H = 'b8c17a5204ae56ad1fc99d8f9932ca9f57b6ac80'
B = '74a1c3922eb7af438fe40b23d2105ad07556e3f5'
P = '7f23ce839fcc88acb235b1816c2c57dc12e16a33'
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1',
           GIT_CONFIG_NOSYSTEM='1', GIT_CONFIG_GLOBAL='/dev/null',
           GIT_TERMINAL_PROMPT='0')
COMMANDS = []

def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')

def git(label, *args, expected=(0,)):
    command = ['git', '--git-dir=' + str(GIT), *args]
    p = subprocess.run(command, stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                       env=ENV, timeout=120)
    stdout_path = ROOT / (label + '.stdout')
    stderr_path = ROOT / (label + '.stderr')
    stdout_path.write_bytes(p.stdout)
    stderr_path.write_bytes(p.stderr)
    COMMANDS.append({'label': label, 'argv': command, 'returncode': p.returncode,
                     'stdout': stdout_path.name, 'stderr': stderr_path.name,
                     'stdout_bytes': len(p.stdout),
                     'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(),
                     'stderr_bytes': len(p.stderr)})
    save('commands.json', COMMANDS)
    if p.returncode not in expected:
        raise RuntimeError(label + ': ' + p.stderr.decode(errors='replace'))
    return p.stdout

def tree(label, ref):
    raw = git('tree-' + label, 'ls-tree', '-r', '-z', '--full-tree', ref)
    entries = {}
    for record in raw.split(b'\0'):
        if not record:
            continue
        metadata, rawpath = record.split(b'\t', 1)
        mode, kind, sha = metadata.decode().split()
        path = rawpath.decode()
        assert path not in entries
        entries[path] = {'mode': mode, 'type': kind, 'sha': sha}
    save('inventory-' + label + '.json', entries)
    return entries

def delta(left, right):
    result = []
    for path in sorted(left.keys() | right.keys()):
        a, b = left.get(path), right.get(path)
        if a != b:
            result.append({'path': path, 'status': 'added' if a is None else
                           'deleted' if b is None else 'modified',
                           'before': a, 'after': b})
    return result

def summarize(changes):
    return dict(collections.Counter(x['status'] for x in changes))

git('git-version', '--version')
git('objects-size', 'count-objects', '-vH')
git('refs-before', 'show-ref', expected=(0, 1))
M = git('merge-base-B-H', 'merge-base', '--all', B, H).decode().strip()
assert '\n' not in M
git('P-is-ancestor-H', 'merge-base', '--is-ancestor', P, H)
git('M-is-ancestor-B', 'merge-base', '--is-ancestor', M, B)
git('M-is-ancestor-H', 'merge-base', '--is-ancestor', M, H)
git('divergence-counts', 'rev-list', '--left-right', '--count', B + '...' + H)
git('H-exclusive-history', 'rev-list', '--parents', H, '^' + B)
for label, ref in [('B', B), ('H', H), ('P', P), ('M', M)]:
    git('commit-' + label, 'cat-file', 'commit', ref)
trees = {label: tree(label, ref) for label, ref in [('B', B), ('H', H), ('P', P), ('M', M)]}
deltas = {}
for left, right in [('M', 'B'), ('M', 'H'), ('P', 'H'), ('B', 'H')]:
    changes = delta(trees[left], trees[right])
    deltas[left + '-' + right] = changes
    save('changes-' + left + '-' + right + '.json', changes)
pr = json.loads((TASK / 'pr-files.json').read_text())
assert len(pr) == len(deltas['P-H']) == 288
prmap = {row['filename']: (row['status'], row['sha']) for row in pr}
assert all(prmap[row['path']] == (row['status'], row['after']['sha']) for row in deltas['P-H'])
assert all(row['status'] == 'added' for row in deltas['P-H'])
for row in deltas['P-H']:
    data = (TASK / 'source' / row['path']).read_bytes()
    sha = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    assert sha == row['after']['sha']

merge_raw = git('merge-tree-B-H', 'merge-tree', '--write-tree', B, H, expected=(0, 1))
merge_lines = merge_raw.decode().splitlines()
assert COMMANDS[-1]['returncode'] == 0, 'Merge conflict; inspect retained merge output.'
T = merge_lines[0]
assert len(T) == 40 and len(merge_lines) == 1
trees['T'] = tree('T', T)
prerequisite_raw = git('merge-tree-B-P', 'merge-tree', '--write-tree', B, P)
prerequisite_lines = prerequisite_raw.decode().splitlines()
assert len(prerequisite_lines) == 1
U = prerequisite_lines[0]
trees['U'] = tree('U', U)
for left, right in [('B', 'U'), ('U', 'T')]:
    changes = delta(trees[left], trees[right])
    deltas[left + '-' + right] = changes
    save('changes-' + left + '-' + right + '.json', changes)
assert deltas['U-T'] == deltas['P-H']
assert all(trees['U'].get(p) == v for p, v in trees['B'].items())
assert all(trees['U'].get(p) == v for p, v in trees['P'].items())
for left, right in [('B', 'T'), ('H', 'T'), ('P', 'T')]:
    changes = delta(trees[left], trees[right])
    deltas[left + '-' + right] = changes
    save('changes-' + left + '-' + right + '.json', changes)
preserved_B = [p for p, v in trees['B'].items() if trees['T'].get(p) == v]
changed_B = [p for p, v in trees['B'].items() if trees['T'].get(p) != v]
preserved_H = [p for p, v in trees['H'].items() if trees['T'].get(p) == v]
changed_H = [p for p, v in trees['H'].items() if trees['T'].get(p) != v]
binding = json.loads((TASK / 'CANONICAL_BINDING_RESULT.json').read_text())
dependencies = []
for row in binding['rows']:
    path = row['path']
    value = trees['T'].get(path)
    expected = row['reviewed_git_blob']
    assert value and value['sha'] == expected and value['mode'] == row['H']['mode']
    dependencies.append({'module': row['module'], 'path': path,
                         'reviewed_git_blob': expected, 'combined': value,
                         'present_at_B': path in trees['B'],
                         'present_at_P': path in trees['P']})
save('dependency-inclusion.json', dependencies)
binding_input = json.loads((TASK / 'CANONICAL_BINDING_INPUT.json').read_text())
controls = []
for entry in binding_input['refs']['H']['selected']:
    if entry['path'].endswith('.lean'):
        continue
    value = trees['T'].get(entry['path'])
    assert value and value['sha'] == entry['sha'] and value['mode'] == entry['mode']
    controls.append({'path': entry['path'], 'combined': value})
save('registry-and-verifier-inclusion.json', controls)
top_additions = [r['path'] for r in deltas['B-T'] if r['status'] == 'added'
                 and len(Path(r['path']).parts) == 2]
overlap = sorted({r['path'] for r in deltas['M-B']} & {r['path'] for r in deltas['M-H']})
overlap_rows = [{'path': p, 'M': trees['M'].get(p), 'B': trees['B'].get(p),
                 'H': trees['H'].get(p), 'T': trees['T'].get(p)} for p in overlap]
save('branch-change-overlap.json', overlap_rows)
refs_after = git('refs-after', 'show-ref', expected=(0, 1))
assert refs_after == (ROOT / 'refs-before.stdout').read_bytes()
result = {
 'status': 'PASS_PINNED_GIT_COMBINATION', 'B': B, 'H': H, 'P': P, 'merge_base': M,
 'combined_tree': T, 'git_merge_tree_executed': True, 'merge_conflicts': False,
 'prerequisite_combined_tree': U, 'prerequisite_merge_tree_executed': True,
 'post_prerequisite_delta_exactly_PR172': True,
 'tree_entry_counts': {k: len(v) for k, v in trees.items()},
 'change_counts': {k: summarize(v) for k, v in deltas.items()},
 'B_entries_preserved': len(preserved_B), 'B_entries_changed_or_deleted': changed_B,
 'H_entries_preserved': len(preserved_H), 'H_entries_changed_or_deleted': changed_H,
 'branch_change_overlap_count': len(overlap), 'dependency_modules_preserved': len(dependencies),
 'dependencies_already_on_B': sum(r['present_at_B'] for r in dependencies),
 'missing_B_dependencies_inherited_from_P': [r['module'] for r in dependencies
                                          if not r['present_at_B'] and r['present_at_P']],
 'new_PR172_dependencies': [r['module'] for r in dependencies if not r['present_at_P']],
 'top_level_proofs_additions_to_B': top_additions,
 'pr172_diff_matches_all_288_api_entries_and_materialized_bytes': True,
 'fresh_lean_execution': False, 'remote_mutations': False, 'refs_created': False,
 'scope': 'Exact pinned B/H Git merge simulation; prerequisite integration and acceptance are separate.'}
save('COMBINATION_RESULT.json', result)
print(json.dumps(result, indent=2))
