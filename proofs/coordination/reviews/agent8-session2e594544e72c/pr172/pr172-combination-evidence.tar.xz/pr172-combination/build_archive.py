#!/usr/bin/env python3
"""Build a deterministic archive without loading evidence files into memory."""
import gzip
import hashlib
import json
from pathlib import Path
import tarfile

ROOT = Path(__file__).resolve().parent
PREFIX = 'pr172-combination/'
ARCHIVE = ROOT / 'pr172-combination-evidence.tar.gz'
MANIFEST = ROOT / 'ARCHIVE_MEMBERS.json'
RESULT = ROOT / 'ARCHIVE_RESULT.json'
CHUNK = 1024 * 1024

def identity(path):
    size = path.stat().st_size
    sha256 = hashlib.sha256()
    gitblob = hashlib.sha1(b'blob ' + str(size).encode() + b'\0')
    with path.open('rb') as stream:
        while data := stream.read(CHUNK):
            sha256.update(data)
            gitblob.update(data)
    return {'bytes': size, 'sha256': sha256.hexdigest(), 'git_blob': gitblob.hexdigest()}

excluded = {ARCHIVE.name, MANIFEST.name, RESULT.name, 'EVIDENCE_FILES.json'}
files = sorted(p for p in ROOT.iterdir() if p.is_file() and p.name not in excluded)
evidence = [{'path': p.name, **identity(p)} for p in files]
(ROOT / 'EVIDENCE_FILES.json').write_text(json.dumps(evidence, indent=2, sort_keys=True) + '\n')
files.append(ROOT / 'EVIDENCE_FILES.json')
files.sort()
members = [{'member': PREFIX + p.name, **identity(p)} for p in files]
manifest = {'format': 'P196 evidence archive member manifest v1',
            'scope': 'Every evidence member except ARCHIVE_MEMBERS.json itself; manifest identity is in external ARCHIVE_RESULT.json.',
            'excluded': ['objects.git/', ARCHIVE.name, RESULT.name],
            'members': members}
MANIFEST.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
files.append(MANIFEST)
files.sort()
with ARCHIVE.open('wb') as output:
    with gzip.GzipFile(filename='', mode='wb', compresslevel=6, mtime=0, fileobj=output) as compressed:
        with tarfile.open(fileobj=compressed, mode='w|', format=tarfile.USTAR_FORMAT) as archive:
            for path in files:
                info = tarfile.TarInfo(PREFIX + path.name)
                info.size = path.stat().st_size
                info.mode = 0o644
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ''
                with path.open('rb') as stream:
                    archive.addfile(info, stream)

expected = {r['member']: r for r in members}
expected[PREFIX + MANIFEST.name] = identity(MANIFEST)
seen = []
with tarfile.open(ARCHIVE, mode='r|gz') as archive:
    for member in archive:
        assert member.isfile() and member.name in expected and member.name not in seen
        assert member.uid == member.gid == member.mtime == 0
        assert member.mode == 0o644 and member.uname == member.gname == ''
        digest = hashlib.sha256()
        length = 0
        stream = archive.extractfile(member)
        while data := stream.read(CHUNK):
            digest.update(data)
            length += len(data)
        assert member.size == length == expected[member.name]['bytes']
        assert digest.hexdigest() == expected[member.name]['sha256']
        seen.append(member.name)
assert seen == sorted(expected)
result = {'status': 'PASS_STREAM_VERIFIED_ARCHIVE', 'archive': ARCHIVE.name,
          **identity(ARCHIVE), 'member_count': len(seen),
          'total_member_bytes': sum(r['bytes'] for r in expected.values()),
          'manifest': {'member': PREFIX + MANIFEST.name, **identity(MANIFEST)},
          'determinism': {'sorted_members': True, 'tar_format': 'USTAR',
                          'member_uid_gid_mtime': 0, 'member_mode': '0644',
                          'gzip_mtime': 0, 'gzip_filename': '', 'gzip_level': 6},
          'stream_chunk_bytes': CHUNK, 'original_files_deleted': False,
          'git_object_store_included': False, 'remote_mutations': False}
RESULT.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')
print(json.dumps(result, indent=2))
