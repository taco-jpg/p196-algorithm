#!/usr/bin/env python3
"""Bind a selected replay registry and its complete source bytes to a merge tree."""
import argparse
import hashlib
import json
import subprocess
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--repo', type=Path, required=True)
p.add_argument('--head', required=True)
p.add_argument('--tree', required=True)
p.add_argument('--package', required=True)
p.add_argument('--registry', required=True)
p.add_argument('--driver', required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()

def git(*args):
    return subprocess.run(['git', '-C', str(a.repo), *args], check=True, capture_output=True).stdout

def content(ref, path):
    return git('show', f'{ref}:{path}')

registry_path = a.package.rstrip('/') + '/' + a.registry
driver_path = a.package.rstrip('/') + '/' + a.driver
registry_data = content(a.head, registry_path)
driver_data = content(a.head, driver_path)
registry = json.loads(registry_data)
rows = []
for name, record in registry['modules'].items():
    if record['base'] == 'repository':
        path = record['path']
    elif record['base'] == 'package':
        path = a.package.rstrip('/') + '/' + record['path']
    else:
        raise ValueError(f'Unknown source base for {name}: {record["base"]}')
    h = content(a.head, path)
    t = content(a.tree, path)
    oid = hashlib.sha1(b'blob ' + str(len(t)).encode() + b'\0' + t).hexdigest()
    digest = hashlib.sha256(t).hexdigest()
    row = {'module': name, 'path': path, 'bytes': len(t), 'git_blob': oid, 'sha256': digest,
           'head_equals_combination': h == t,
           'matches_registry_sha256': digest == record['sha256'],
           'matches_registry_git_blob': not record.get('git_blob') or oid == record['git_blob']}
    rows.append(row)
out = {'schema_version': 1, 'auditor': 'Agent #12 / root', 'head': a.head, 'combined_tree': a.tree,
       'registry_path': registry_path, 'registry_sha256': hashlib.sha256(registry_data).hexdigest(),
       'driver_path': driver_path, 'driver_sha256': hashlib.sha256(driver_data).hexdigest(),
       'registry_identical_in_combination': registry_data == content(a.tree, registry_path),
       'driver_identical_in_combination': driver_data == content(a.tree, driver_path),
       'source_module_count': len(rows), 'source_bindings': rows,
       'interpretation': 'Fresh verification of these exact pinned sources applies to this combination without re-executing unchanged sources. This binding is not itself a Lean execution.'}
out['status'] = 'PASS' if out['registry_identical_in_combination'] and out['driver_identical_in_combination'] and all(r['head_equals_combination'] and r['matches_registry_sha256'] and r['matches_registry_git_blob'] for r in rows) else 'FAIL'
a.output.parent.mkdir(parents=True, exist_ok=True)
if a.output.exists():
    raise FileExistsError(a.output)
a.output.write_text(json.dumps(out, indent=2) + '\n')
print(json.dumps({k: v for k, v in out.items() if k != 'source_bindings'}, indent=2))
if out['status'] != 'PASS':
    raise SystemExit(1)
