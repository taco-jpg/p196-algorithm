#!/usr/bin/env python3
"""Record an exact, non-mutating Git integration-tree preservation check."""

import argparse
import hashlib
import json
import subprocess
from datetime import datetime, timezone
from pathlib import Path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--repo', type=Path, required=True)
    parser.add_argument('--base', required=True)
    parser.add_argument('--head', required=True)
    parser.add_argument('--prefix', required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=False)
    commands = []

    def git(*parts):
        command = ['git', '-C', str(args.repo), *parts]
        result = subprocess.run(command, capture_output=True)
        commands.append({'argv': command, 'exit_code': result.returncode,
                         'stderr': result.stderr.decode(errors='replace')})
        if result.returncode:
            (args.output / 'failed-command.stdout').write_bytes(result.stdout)
            (args.output / 'failed-command.stderr').write_bytes(result.stderr)
            (args.output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
            raise RuntimeError(f'Git command failed: {parts!r}')
        return result.stdout

    def tree(ref):
        entries = {}
        for line in git('ls-tree', '-r', '-z', ref).split(b'\0'):
            if not line:
                continue
            info, path = line.split(b'\t', 1)
            mode, kind, oid = info.decode().split()
            entries[path.decode()] = {'mode': mode, 'type': kind, 'git_object': oid}
        return entries

    base = git('rev-parse', args.base).decode().strip()
    head = git('rev-parse', args.head).decode().strip()
    ancestor = git('merge-base', base, head).decode().strip()
    merge_output = git('merge-tree', '--write-tree', base, head)
    (args.output / 'merge-tree.stdout').write_bytes(merge_output)
    combined = merge_output.decode().splitlines()[0]
    base_tree, head_tree, ancestor_tree, combined_tree = map(tree, [base, head, ancestor, combined])
    submitted = {p for p in ancestor_tree.keys() | head_tree.keys()
                 if ancestor_tree.get(p) != head_tree.get(p)}
    effective = {p for p in base_tree.keys() | combined_tree.keys()
                 if base_tree.get(p) != combined_tree.get(p)}
    outside_scope = sorted(p for p in submitted if not p.startswith(args.prefix))
    deleted = sorted(p for p in base_tree if p not in combined_tree)
    changed_existing = sorted(p for p in base_tree if p in combined_tree and base_tree[p] != combined_tree[p])
    unexpected = sorted(effective - submitted)
    mismatched_head = sorted(p for p in submitted if combined_tree.get(p) != head_tree.get(p))
    preserved_existing = not deleted and not changed_existing
    record = {
        'schema_version': 1, 'auditor': 'Agent #12 / root',
        'checked_at': datetime.now(timezone.utc).isoformat(),
        'base': base, 'head': head, 'merge_base': ancestor,
        'combined_tree': combined,
        'base_tracked_entries': len(base_tree),
        'combined_tracked_entries': len(combined_tree),
        'submitted_paths': sorted(submitted),
        'effective_paths': sorted(effective),
        'outside_owned_prefix': outside_scope,
        'deleted_base_paths': deleted,
        'changed_existing_base_paths': changed_existing,
        'unexpected_effective_paths': unexpected,
        'submitted_paths_not_identical_to_head': mismatched_head,
        'all_existing_base_entries_preserved': preserved_existing,
        'accepted_scope': args.prefix,
        'fresh_lean_execution': False,
        'interpretation': 'This is a complete Git tree/content preservation check. A separate exact-source Lean and semantic review is required. Evidence can be reused for the combination only where source and verifier closure bytes match.',
    }
    inventory = []
    for path in sorted(effective):
        item = {'path': path, 'base_entry': base_tree.get(path), 'combined_entry': combined_tree.get(path)}
        if path in combined_tree and combined_tree[path]['type'] == 'blob':
            data = git('cat-file', 'blob', combined_tree[path]['git_object'])
            item.update(bytes=len(data), sha256=hashlib.sha256(data).hexdigest())
        inventory.append(item)
    (args.output / 'incoming-inventory.json').write_text(json.dumps(inventory, indent=2) + '\n')
    (args.output / 'submitted.patch').write_bytes(git('diff', '--binary', '--full-index', ancestor, head))
    (args.output / 'effective.patch').write_bytes(git('diff', '--binary', '--full-index', base, combined))
    record['status'] = 'PASS_ADDITIVE_COMBINATION' if not any([outside_scope, deleted, changed_existing, unexpected, mismatched_head]) else 'REQUIRES_SEMANTIC_RESOLUTION'
    record['inventory_sha256'] = hashlib.sha256((args.output / 'incoming-inventory.json').read_bytes()).hexdigest()
    (args.output / 'commands.json').write_text(json.dumps(commands, indent=2) + '\n')
    (args.output / 'receipt.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({k: v for k, v in record.items() if k not in ['submitted_paths', 'effective_paths']}, indent=2))
    print('submitted_count', len(submitted), 'effective_count', len(effective))


if __name__ == '__main__':
    main()
