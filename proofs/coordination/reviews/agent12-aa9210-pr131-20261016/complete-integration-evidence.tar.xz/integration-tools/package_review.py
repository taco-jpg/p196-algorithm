#!/usr/bin/env python3
"""Losslessly package new integration evidence and explicit reproducible exclusions."""
import argparse
import hashlib
import io
import json
import tarfile
from pathlib import Path

p = argparse.ArgumentParser()
p.add_argument('--review', type=Path, required=True)
p.add_argument('--combination', type=Path, action='append', default=[])
p.add_argument('--output', type=Path, required=True)
p.add_argument('--pr', type=int, required=True)
p.add_argument('--head', required=True)
a = p.parse_args()
a.output.mkdir(parents=True, exist_ok=False)
included = []
excluded = []
for label, root in [('independent-review', a.review)] + [(f'combination/{x.name}', x) for x in a.combination]:
    for path in sorted(root.rglob('*')):
        if not path.is_file():
            continue
        rel = path.relative_to(root)
        reason = None
        if 'recovered-evidence' in rel.parts or 'recovered' in rel.parts:
            reason = 'Duplicate original evidence already losslessly preserved in the reviewed PR archive; current validation reports are retained.'
        elif path.suffix in ['.olean', '.ilean', '.o', '.pyc'] or '__pycache__' in rel.parts:
            reason = 'Reproducible compiled object or cache, excluded under PUBLICATION_POLICY.md; source and substantive logs are retained.'
        if reason:
            excluded.append({'path': f'{label}/{rel.as_posix()}', 'reason': reason})
        else:
            included.append((f'{label}/{rel.as_posix()}', path.read_bytes()))
for name in ['verify_combination.py', 'verify_source_closure.py', 'package_review.py']:
    path = Path(__file__).parent / name
    included.append((f'integration-tools/{name}', path.read_bytes()))
archive = a.output / 'complete-integration-evidence.tar.xz'
with tarfile.open(archive, 'w:xz', preset=6) as t:
    for name, data in included:
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        t.addfile(info, io.BytesIO(data))
manifest = {'schema_version': 1, 'agent': 'Agent #12', 'pull_request': a.pr, 'head': a.head,
            'archive': archive.name, 'archive_bytes': archive.stat().st_size,
            'archive_sha256': hashlib.sha256(archive.read_bytes()).hexdigest(),
            'format': 'tar.xz',
            'recovery_command': 'tar -xJf complete-integration-evidence.tar.xz -C /absolute/empty/recovery-directory',
            'file_count': len(included), 'original_bytes': sum(len(data) for _, data in included),
            'files': [{'path': name, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()} for name, data in included],
            'exclusions': excluded}
with tarfile.open(archive, 'r:xz') as t:
    names = t.getnames()
    assert len(names) == len(set(names)) == len(included)
    for row in manifest['files']:
        data = t.extractfile(row['path']).read()
        assert len(data) == row['bytes']
        assert hashlib.sha256(data).hexdigest() == row['sha256']
manifest['round_trip_verification'] = 'PASS_ALL_FILES'
(a.output / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({k: v for k, v in manifest.items() if k not in ['files', 'exclusions']}, indent=2))
print('excluded_files', len(excluded))
