#!/usr/bin/env python3
"""Independently validate and safely recover the pinned PR131 research archive."""
import hashlib
import io
import json
import lzma
from pathlib import Path, PurePosixPath
import tarfile

ROOT = Path('/workspace/scratch/aa9210d02a75/agent12-review131')
PACKAGE = Path('/workspace/scratch/aa9210d02a75/agent12-pr131/proofs/contributions/agent-9/one-step-digit-sum-collapse-20261016')
manifest = json.loads((PACKAGE / 'evidence/MANIFEST.json').read_bytes())
sha = lambda data: hashlib.sha256(data).hexdigest()
archive = (PACKAGE / manifest['stored_path']).read_bytes()
assert len(archive) == manifest['stored_bytes']
assert sha(archive) == manifest['stored_sha256']
unpacked = lzma.decompress(archive)
assert len(unpacked) == manifest['uncompressed_tar_bytes']
assert sha(unpacked) == manifest['uncompressed_tar_sha256']
expected = {item['original_path']: item for item in manifest['files']}
assert len(expected) == len(manifest['files']) == manifest['original_files']
out = ROOT / 'recovered-evidence'
out.mkdir(exist_ok=False)
observed = {}
with tarfile.open(fileobj=io.BytesIO(unpacked), mode='r:') as tf:
    for member in tf.getmembers():
        relative = PurePosixPath(member.name)
        assert not relative.is_absolute() and '..' not in relative.parts
        assert str(relative) == member.name and member.name not in observed
        assert member.isfile(), f'Non-regular archive member: {member.name}'
        assert member.name in expected, f'Unexpected archive member: {member.name}'
        content = tf.extractfile(member).read()
        record = expected[member.name]
        assert len(content) == member.size == record['bytes']
        assert sha(content) == record['sha256']
        target = out / member.name
        assert target.resolve().is_relative_to(out.resolve())
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
        observed[member.name] = {'bytes': len(content), 'sha256': sha(content)}
assert set(observed) == set(expected)
assert sum(item['bytes'] for item in observed.values()) == manifest['original_payload_bytes']
tracked_overlap = []
for name, record in observed.items():
    source = PACKAGE / name
    if source.exists():
        assert source.read_bytes() == (out / name).read_bytes(), f'Tracked/archive divergence: {name}'
        tracked_overlap.append(name)
report = {'status': 'PASS', 'archive_sha256': sha(archive), 'archive_bytes': len(archive),
          'tar_sha256': sha(unpacked), 'tar_bytes': len(unpacked),
          'regular_files': len(observed), 'payload_bytes': sum(r['bytes'] for r in observed.values()),
          'no_absolute_paths': True, 'no_parent_traversal': True, 'no_links_or_devices': True,
          'no_duplicate_members': True, 'exact_manifest_membership': True,
          'all_file_hashes_and_sizes_match': True, 'tracked_overlap_identical': tracked_overlap,
          'files': observed}
(ROOT / 'archive-validation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({k:v for k,v in report.items() if k not in {'files', 'tracked_overlap_identical'}}, indent=2))
print('Tracked/archive byte-identical overlap:', len(tracked_overlap))
