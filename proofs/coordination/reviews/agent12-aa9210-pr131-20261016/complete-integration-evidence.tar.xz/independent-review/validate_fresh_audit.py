#!/usr/bin/env python3
"""Independently parse the complete multiline Lean audit and verify raw evidence."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re

ROOT = Path('/workspace/scratch/aa9210d02a75/agent12-review131')
RUN = ROOT / 'fresh-replay'
sha = lambda data: hashlib.sha256(data).hexdigest()
report = json.loads((RUN / 'verification.json').read_bytes())
registry = json.loads((RUN / 'source-manifest.json').read_bytes())
raw = (RUN / 'logs/CollapseIndependentAudit.log').read_text()
allowed = {'propext', 'Classical.choice', 'Quot.sound'}
assert report['status'] == 'PASS_SELECTED_SOURCE_CLOSURE'
assert report['precompile_object_count'] == 0
assert report['repository_head_before'] == report['repository_head_after'] == '0bfe5347de0e5085307a3432975a18b83a3a2bba'
assert report['repository_status_before'] == report['repository_status_after'] == ''
assert report['all_selected_sources_unchanged'] and report['compiler_snapshot_unchanged']
for command in report['commands']:
    assert command['exit_code'] == 0
    assert sha((RUN / command['log']).read_bytes()) == command['log_sha256']
    if command['label'] in registry['modules'] or command['label'] == 'CollapseIndependentAudit':
        assert all(flag in command['argv'] for flag in ['--trust=0', '-j1', '-DElab.async=false'])
for name, rec in json.loads((RUN / 'FILES.json').read_bytes()).items():
    data = (RUN / name).read_bytes()
    assert len(data) == rec['bytes'] and sha(data) == rec['sha256'], name

records = {}
for category in ['THEOREM', 'DEFINITION']:
    matches = re.findall(r'^AUDIT_' + category + r' (\S+) (\S+) : \[([^\]]*)\]', raw, re.M | re.S)
    assert len(matches) == len({name for _,name,_ in matches})
    for origin, name, ax in matches:
        assert origin in registry['modules']
        assert {a.strip() for a in ax.split(',') if a.strip()} <= allowed, name
    records[category] = matches
assert len(records['THEOREM']) == 1320
assert len(records['DEFINITION']) == 183
origins_match = re.search(r'^AUDITED_MODULE_ORIGINS \[([^\]]*)\]', raw, re.M | re.S)
assert origins_match
origins = [name.strip() for name in origins_match[1].split(',')]
assert len(origins) == 6 and set(origins) == set(registry['modules'])
union_match = re.search(r'^FULL_MODULE_AUDIT theorems=(\d+) union=\[([^\]]*)\]', raw, re.M | re.S)
assert union_match and int(union_match[1]) == len(records['THEOREM'])
assert {name.strip() for name in union_match[2].split(',')} == allowed
assert re.search(r'^FULL_DEFINITION_AUDIT definitions=183$', raw, re.M)
exports = {}
for endpoint in registry['endpoints']:
    literal = re.search(r'^' + re.escape(endpoint) + r'(?=\s)(.*?)^\'' + re.escape(endpoint) + r"' depends on axioms: \[([^\]]*)\]", raw, re.M | re.S)
    assert literal, endpoint
    axioms = [a.strip() for a in literal[2].split(',')]
    assert set(axioms) == allowed
    exports[endpoint] = {'literal_type': endpoint + literal[1].rstrip(), 'axioms': axioms}
assert len(exports) == 10
assert not re.search(r'^(CUSTOM_AXIOM|DISALLOWED_AXIOM|DISALLOWED_DEFINITION_AXIOM|MISSING_MODULE_ORIGIN)', raw, re.M)
new_rows = [row for row in records['THEOREM'] if row[0] == 'Agent9OneStepDigitSumCollapse']
unsafe_axioms = re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$', raw, re.M)
unsafe_definitions = re.findall(r'^UNSAFE_IMPLEMENTATION_DEFINITION (\S+) (\S+)$', raw, re.M)
assert len(new_rows) == 21
assert all(row[0] != 'Agent9OneStepDigitSumCollapse' for row in unsafe_axioms + unsafe_definitions)
result = {'status': 'PASS', 'theorem_constants': len(records['THEOREM']),
          'safe_definitions': len(records['DEFINITION']),
          'theorems_by_module': dict(sorted(Counter(r[0] for r in records['THEOREM']).items())),
          'safe_definitions_by_module': dict(sorted(Counter(r[0] for r in records['DEFINITION']).items())),
          'all_six_origins_present': origins, 'axiom_union': sorted(allowed),
          'unsafe_implementation_axiom_count': len(unsafe_axioms),
          'unsafe_implementation_definition_count': len(unsafe_definitions),
          'unsafe_implementation_entries': {'axioms': unsafe_axioms, 'definitions': unsafe_definitions},
          'all_ten_public_exports': exports,
          'all_raw_command_statuses_zero': True, 'fresh_object_count': 0,
          'all_run_file_hashes_verified': True, 'all_multiline_axiom_closures_allowed': True,
          'new_module_theorem_constants': len(new_rows), 'new_module_safe_definitions': 0}
(ROOT / 'fresh-audit-validation.json').write_text(json.dumps(result, indent=2) + '\n')
(ROOT / 'PUBLIC_EXPORTS.log').write_text('\n\n'.join(v['literal_type'] + '\nAxioms: ' + str(v['axioms']) for v in exports.values()) + '\n')
print(json.dumps({k:v for k,v in result.items() if k not in {'unsafe_implementation_entries', 'all_ten_public_exports'}}, indent=2))
