#!/usr/bin/env python3
"""Check every retained evidence manifest and exact historical command-log hash."""
import hashlib
import json
from pathlib import Path

ROOT = Path('/workspace/scratch/aa9210d02a75/agent12-review131')
P = ROOT / 'recovered-evidence'
sha = lambda data: hashlib.sha256(data).hexdigest()
checks = []

def verify(root, name, rec):
    target = (root / name).resolve()
    assert target.is_relative_to(P.resolve()), name
    data = target.read_bytes()
    assert len(data) == rec['bytes'], name
    assert sha(data) == rec['sha256'], name

for rel, wrapped in [('AUTHOR_FILES.json', True), ('review/runtime-audit/EVIDENCE_FILES.json', True),
                     ('development/attempt-001/FILES.json', False), ('development/attempt-002/FILES.json', False)]:
    mf = P / rel
    records = json.loads(mf.read_bytes())
    if wrapped:
        records = records['files']
    for name, rec in records.items():
        verify(mf.parent, name, rec)
    checks.append({'manifest': rel, 'verified_entries': len(records)})
for rel in ['SHA256SUMS', 'review/runtime-audit/MANIFEST.sha256']:
    mf = P / rel
    lines = mf.read_text().splitlines()
    for line in lines:
        expected, name = line.split('  ', 1)
        assert sha((mf.parent / name).read_bytes()) == expected, name
    checks.append({'manifest': rel, 'verified_entries': len(lines)})

runs = []
for rel in ['development/attempt-001', 'development/attempt-002', 'review/runtime-audit/runs/full-001']:
    run = P / rel
    report = json.loads((run / 'verification.json').read_bytes())
    old_inventory = json.loads((run / 'original-run-FILES.json').read_bytes())
    missing = []
    for name, record in old_inventory.items():
        if (run / name).exists():
            verify(run, name, record)
        elif name == 'source/CollapseIndependentAudit.lean':
            verify(run, 'CollapseIndependentAudit.lean', record)
        elif name.startswith('source/') and name.endswith('.lean'):
            module = Path(name).stem
            alternate = (P / 'Agent9OneStepDigitSumCollapse.lean' if module == 'Agent9OneStepDigitSumCollapse'
                         else run / 'logs' / (module + '-original-source.log'))
            data = alternate.read_bytes()
            assert sha(data) == record['sha256'] and len(data) == record['bytes']
            missing.append({'path': name, 'classification': 'byte-identical source retained elsewhere'})
        else:
            assert name.startswith('build/') and name.endswith('.olean'), name
            missing.append({'path': name, 'classification': 'reproducible compiled project object'})
    for command in report['commands']:
        assert sha((run / command['log']).read_bytes()) == command['log_sha256'], command['label']
    runs.append({'path': rel, 'recorded_status': report['status'],
                 'commands': [{'label': c['label'], 'exit_code': c['exit_code']} for c in report['commands']],
                 'all_original_manifest_references_accounted_for': True,
                 'all_raw_command_logs_hash_valid': True, 'omissions': missing})
assert runs[0]['recorded_status'] == 'FAIL'
assert [c['label'] for c in runs[0]['commands'] if c['exit_code']] == ['Agent9OneStepDigitSumCollapse']
assert runs[1]['recorded_status'] == runs[2]['recorded_status'] == 'PASS_SELECTED_SOURCE_CLOSURE'
assert all(c['exit_code'] == 0 for r in runs[1:] for c in r['commands'])
report = {'status': 'PASS', 'nested_manifests': checks, 'historical_runs': runs,
          'failed_attempt_source_and_full_errors_retained': True,
          'historical_failures_not_relabelled': True}
(ROOT / 'retained-record-validation.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'nested_manifests': checks,
                  'historical_runs': [{'path': r['path'], 'recorded_status': r['recorded_status'],
                                       'commands': len(r['commands']), 'accounted_omissions':len(r['omissions'])} for r in runs]}, indent=2))
