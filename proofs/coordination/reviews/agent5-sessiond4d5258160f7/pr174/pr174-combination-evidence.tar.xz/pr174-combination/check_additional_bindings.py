from run_capture import *
import collections
obj=OUT/'objects.git';r=json.loads((OUT/'combination-receipt.json').read_text())
def g(label,*args):return run(label,['git','-c','credential.helper=','-c','core.askPass=','--git-dir='+str(obj),*args])
def inv(label,pin):
 result={}
 for x in g(label,'ls-tree','-r','-z','--full-tree',pin).stdout.split(b'\0'):
  if x:
   a,b=x.split(b'\t',1);result[b.decode()]=a.decode()
 return result
direct=g('direct-B-pr172-merge','merge-tree','--write-tree','--no-messages',r['main'],r['direct_base']).stdout.decode().strip()
assert direct=='05c11aa0f150ca8a600d1d7cb2b44a1867462a68'
a=inv('direct-B-pr172-tree',direct);b=inv('full-stack-pr172-tree',r['tree172'])
delta=[{'path':p,'status':'A' if p not in a else 'D' if p not in b else 'M','direct':a.get(p),'full':b.get(p)} for p in sorted(a.keys()|b.keys()) if a.get(p)!=b.get(p)]
reg=json.loads((OUT/'raw/registry.stdout').read_text());origin=json.loads((OUT/'remote/origin-registry-blob.json').read_text())['structuredContent']['content'].encode();originjson=json.loads(origin)
assert hashlib.sha256(origin).hexdigest()==reg['source_pin_origins'][0]['sha256']
inherited={k:v for k,v in reg['projects']['agent1-periodic-nine-control']['modules'].items() if k!='Agent1PeriodicNinesExtraStrip'}
assert inherited==originjson['projects']['agent1-periodic-quotient']['modules']
numstat=(OUT/'raw/stacked-numstat.stdout').read_text().splitlines();counts=[line.split('\t',2) for line in numstat];assert sum(int(x[0]) for x in counts)==43601 and sum(int(x[1]) for x in counts)==0
v={'status':'PASS','narrow_PR172_packet_tree_reproduced':direct,'full_order_PR172_tree':r['tree172'],'full_minus_narrow_counts':dict(collections.Counter(x['status'] for x in delta)),'full_minus_narrow_delta':delta,'source_registry_origin_sha256_matches':True,'inherited_14_module_records_identical_to_pinned_quotient_registry':True,'PR174_changed_files':len(counts),'PR174_added_lines':43601,'PR174_deleted_lines':0,'PR174_own_delta_top_level':[x['path'] for x in r['stacked_delta'] if x['path'].count('/')==1]}
(OUT/'additional-bindings.json').write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps({k:v for k,v in v.items() if k!='full_minus_narrow_delta'},indent=2))
