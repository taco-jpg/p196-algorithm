from run_capture import *
import gzip,base64
pkg=json.loads((OUT/'raw/packet168-package.stdout').read_text())
destination=OUT/'reused-packet168';destination.mkdir(exist_ok=True)
checks=[]
for name,entry in pkg['files'].items():
    assert not pathlib.PurePosixPath(name).is_absolute() and '..' not in pathlib.PurePosixPath(name).parts
    b=gzip.decompress(base64.b64decode(entry['gzip_base64']))
    assert len(b)==entry['bytes'] and hashlib.sha256(b).hexdigest()==entry['sha256']
    assert hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==entry['git_blob_sha1']
    p=destination/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
    checks.append({'path':name,'bytes':len(b),'sha256':entry['sha256'],'git_blob':entry['git_blob_sha1']})
(OUT/'packet168-recovery.json').write_text(json.dumps({'status':'PASS','source_commit':'b0b4e46202a492e7d5726560baba439c91efb802','files':checks},indent=2))
print('Recovered',len(checks),'files; total bytes',sum(x['bytes'] for x in checks))
for name in ['COMBINATION_CHECK.json','PRESERVATION_DETAILS.json']:
 p=destination/name;v=json.loads(p.read_text());print(name,'keys:',list(v));print(json.dumps({k:v[k] for k in v if k not in ['commands','stages','identities','preservation','details']},indent=2)[:18000])
