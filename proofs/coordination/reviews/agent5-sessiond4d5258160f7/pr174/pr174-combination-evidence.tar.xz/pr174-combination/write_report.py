from run_capture import *
R=json.loads((OUT/'combination-receipt.json').read_text());C=json.loads((OUT/'closure-binding.json').read_text());A=json.loads((OUT/'additional-bindings.json').read_text());F=json.loads((OUT/'final-ref-check.json').read_text())
owners={146:'Agent #16/session2b1962844ca1',147:'Agent #17/session0abe49735fe9',150:'Agent #17/session0abe49735fe9',154:'Agent #20/session86350e418736',166:'Agent #10/session2a8fba7b8570',168:'Agent #16/session02ac12cc16be',172:'Agent #8/session2e594544e72c',174:'Agent #5/sessiond4d5258160f7'}
rows='\n'.join('| '+str(s['pr'])+' | `'+s['head']+'` | '+owners[s['pr']]+' | '+str(s['added'])+' | `'+s['tree']+'` |' for s in R['steps'])
stale='\n'.join('- `'+x['path']+'`' for x in A['full_minus_narrow_delta'] if x['status']=='M')
report=f'''# PR174 stacked test merge, full dependency combination, and selected closure binding

## Result and exact scope

**PASS_STACKED_AND_FULL_DEPENDENCY_COMBINATION; PASS_EXACT_15_SOURCE_AND_CONTROL_BINDING.** At the final actual-ref observation ({F['checked_at']}), main remained `{R['main']}`, all eight inspected source branches retained their tested heads, and PR174's test-merge ref retained `{R['test_merge']}`. The native prospective full-stack tree is **`{R['tree174']}`**. It has **24,399 leaf entries: all 22,212 actual-main entries unchanged, plus 2,187 additions**, with zero modification or deletion relative to actual main.

This is a local Git object/source binding result. It is not actual main integration, a fresh Lean run, independent mathematical approval of the entire stack, a Ready transition, retargeting, a platform-gate decision, or ownership transfer. No remote write, source edit, shared index/worktree write, branch update, claim, merge, or Lean invocation was performed. The source and evidence qualification is handled separately by the parent and its assigned specialist.

## Actual PR174 stacked test merge

The actual GitHub ref `refs/pull/174/merge` is `{R['test_merge']}`. Full `git cat-file -p` output, rather than shallow log parent display, establishes these ordered parents:

1. PR172 direct base `{R['direct_base']}`.
2. PR174 head `{R['head']}`.

Its root tree is `{R['commits']['test-merge']['tree']}`, exactly equal to PR174 H. PR174 H has sole parent `{R['source']}`; that source checkpoint has sole parent `{R['direct_base']}`. The direct base is therefore a true ancestor of H, and the stacked test merge preserves every direct-base entry.

The exact direct-base-to-H delta consists of **157 additions, 43,601 added lines, zero modifications, and zero deletions**. Two additions are the root proof and scoped registry:

- `proofs/Agent1PeriodicNinesExtraStrip.lean`
- `proofs/Agent1PeriodicNinesExtraStrip.registry.json`

The remaining 155 additions are under `proofs/contributions/agent-1/periodic-nine-control-20261017/`. Full path, mode, type, and object identities are retained in `stacked-delta.json`; the complete diff and numstat are in raw command outputs. This test merge is into the current research base, **not main**.

## Current prerequisite owner and inspected packets

Coordination commit `f0ab0f35eda96eee5891613901082de293e2a566` contains the PR172 task `proofs/coordination/tasks/agent8-session2e594544e72c-pr172-delivery-20261017.json` and its packet under `proofs/coordination/reviews/agent8-session2e594544e72c/pr172/`. The task identifies **Agent #8/session2e594544e72c** as delivery owner, status EXTERNALLY_BLOCKED, and PR168 as its unintegrated prerequisite. Original Agent #1 source ownership remains unchanged.

That existing PR172 packet correctly proves the narrower direct combination of actual B and H172: tree `05c11aa0f150ca8a600d1d7cb2b44a1867462a68`, 23,720 entries, and 1,508 additions to B. This task reproduced that exact tree with native Git. The narrower proof is valid for its stated inputs. It does not include later prerequisite evidence already present on the six current prerequisite heads. The stronger ordered result after PR172 is `{R['tree172']}`, with **522 additional evidence paths and five newer inherited metadata/script blobs** compared with the narrower tree. Those five paths are:

{stale}

The stronger PR168 packet was read at immutable coordination checkpoint `b0b4e46202a492e7d5726560baba439c91efb802`, path `proofs/coordination/reviews/agent16-session02ac12/pr168/DELIVERY_PACKET.md`. Its `EVIDENCE_PACKAGE.json` was recovered losslessly: all 33 members, totaling 2,898,992 original bytes, verified their byte lengths, SHA256s, and Git blob identities. The complete original scripts, reports, errors, and command records are under `reused-packet168/`; `packet168-recovery.json` binds their identities.

The complete prospective tree object was not initially present locally. Native metadata-only reconstruction qualified every retained stage tree and exact delta, then extended the result through PR172 and PR174. No prerequisite proof build was repeated. This gives complete current-head preservation while retaining the narrower packet and its original interpretation.

## Exact prospective order and preservation

All eight native `git merge-tree --write-tree --no-messages` operations exited zero. Each stage was represented by an unreferenced local diagnostic commit with ordered parents [previous diagnostic stage, incoming source head]. These diagnostic commits are not actual integration commits. Full `cat-file` parent/tree records are retained, and no local branch or tag refs were created.

| PR | Actual inspected source head | Existing delivery owner | Additions at this stage | Resulting tree |
| --- | --- | --- | ---: | --- |
{rows}

The six stages through PR168 reproduce its retained tree and delta byte for byte. Every earlier stage's leaf entries remain unchanged at every later stage. The PR172 stage adds exactly 288 entries. The PR174 stage adds exactly the same 157 [path, mode, type, blob] entries as the actual stacked PR174 delta. Thus, **after the pinned prerequisites have really been integrated with this content, the intended PR174 retargeted contribution is precisely those 157 additions**.

Current B is an actual observed main ref, not stale PR-base metadata. The final result does not pretend that the prospective tree is already main. The complete B-to-final inventory is `main-to-final-delta.json`. All original PR174 additions are retained exactly. Incoming branches sometimes carry older inherited snapshots; the checker identifies every such mismatch, proves the incoming value equals an actual merge-ancestor value, and proves the combination keeps the newer prior-stage value. The five distinct paths listed above are such inherited evidence/metadata, not discarded PR174 changes. Their older versions remain reachable through unchanged original source-parent history. No blanket ours/theirs conflict policy was used.

At the PR168 stage, **`git merge-base --all` returns two merge bases**: `2d5cfe447811155e93cef173192e96f64ec824e1` and `ebcaf723d61f9513c8bae30440d02ba4a46343b4`. The original packet's ordinary merge-base command printed one. Native merge-tree handled the full ancestry without a forced base and reproduced the original expected tree. This supplements the retained metadata; it does not alter a proof, source, or prior result.

## Unchanged exact selected closure

`closure-binding.json` provides all 15 module paths, Git blobs, SHA256s, actual parsed imports, and identities at B, direct base P, source S, head H, the actual stacked test merge M, full prospective T172, and full prospective T174. Exact import DFS from `Agent1PeriodicNinesExtraStrip` equals the 15-module scoped registry; `Std` is the only external import root. No PR173 module appears.

All 15 source bytes, modes, and Git identities are identical at S, H, M, and T174. **All 14 inherited modules are already byte-identical on actual B**, on P, and on T172. The one new proof is Git blob `21dc3897b77499d95aee131ab02d7056ee676ae2`, SHA256 `e50a7e04b272f8b0d78d380b1ec1e2df80fc4b1647719dd31bdac02109a8107e`.

The control registry remains Git blob `{C['registry_git_blob']}`, SHA256 `{C['registry_sha256']}`, unchanged from S through H, M, and T174. Its 14 inherited module records exactly equal those of the pinned original Quotient registry; that origin's actual bytes satisfy the recorded SHA256 and Git blob. The canonical checker `proofs/verify_project__214bf7673efe116b.py` stays blob `21131b03dfa516eb19a0a7a4df4f2a41020d4db1`. The wrapper, `SOURCE_MAP.json`, scoped origin registry, and every PR174 Python helper are inventoried and retain the relevant original identities in the combination. The full 22,212-entry B-preservation proof also covers shared registries, accepted indexes, archive files, and historical evidence already in main.

This establishes unchanged inputs for reuse of independently qualified retained strict fresh15 evidence. It does not independently relabel parent flags, rerun Lean, treat frozen pending registry metadata as current state, or accept unreviewed upstream mathematical obligations. The original registry, failed attempts, source snapshots, and commands are preserved exactly.

## Owners, remaining external action, and intended execution

The inspected main role is `proofs/coordination/roles/integration.json`, status ACTIVE, owned by **Agent #31/session02893e4f368d**, selected PR104. No expiry or acknowledged handoff is supplied by that record. The unchanged role is an external serialization condition; it is not a failed local proof or tree obligation.

Agent #8 owns PR172's actual delivery, including PR168 and its prerequisite chain. Agent #5 retains PR174 delivery responsibility. Agent #1 retains source authorship. The PR168 and earlier owners in the table are preserved; this report does not claim their review obligations have all been satisfied merely because their trees combine.

The next concrete external action is for the named upstream owners and acknowledged main writer to complete and verify actual prerequisite integration. Then PR174's delivery owner must refresh actual main/source refs and relevant checks, rebind the precise combination to the real target, inspect the full intended diff, and only then arrange an eligible main retarget and guarded ordinary merge through the serialized writer. Require the reviewed PR174 H or qualify an actual change. If actual prerequisite content matches these pins and no other relevant change intervenes, require the exact 157 additions. After any supported merge, independently read back merged PR state, target, actual ordered parents, tree, preservation, and applicable postchecks. A source-head guard alone does not freeze main.

No Ready transition, retarget, merge, comment, claim, or platform-gate mutation was attempted here. PR172 and main ownership remain external conditions. Parent handles formal platform review and publication; this report neither introduces an optional build requirement nor requests transfer of the writer role.

## Reproduction, failures, and evidence inventory

The final checkers are `check_combination.py`, `check_closure_binding.py`, `check_additional_bindings.py`, and `final_ref_check.py`, with `run_capture.py` retaining exact argument vectors, timestamps, controlled environment, exit status, stdin when present, full stdout/stderr, and their SHA256s in `commands.jsonl` and `raw/`. `machine-receipt.json` summarizes the combined result. Binary NUL-delimited complete Git inventories are retained without API truncation.

All substantive diagnostic failures are retained. Initial absent local coordination/pin probes returned 128 before bounded public fetches. The first combination run could not find a merge base across the shallow boundary; bounded read-only main ancestry acquisition into the isolated object store resolved it. The second run's checker incorrectly assumed a unique PR168 merge base; its original source and failure receipt are retained under `attempt-002/`, and the final checker handles the genuine two-base graph. A follow-up inspection tried to open an output not produced after that assertion and failed; its traceback remains. The first closure-binding run encountered a missing origin-registry blob and a sandbox network failure during Git's attempted lazy fetch; the exact blob was then fetched through the connected read-only GitHub tool, Git-hash verified, and written only into the local isolated object store. The second closure-binding run passed. `binding-attempt-001/` preserves the original checker, and raw errors are not overwritten. These are acquisition/diagnostic failures, not Lean/source failures.

The isolated bare object cache uses the parent's Git object store as a read-only alternate, with no dependency on the intentionally partial worktree/index. The cache is reconstructible and excluded from the deliverable archive. The lossless archive includes the reports, machine receipts, full original/recovered packet, checker sources, command records, exact tree outputs, failed attempts, and remote observations; its manifest lists all included bytes. No claim of a standalone complete Git repository is made.
'''
(OUT/'COMBINATION_REPORT.md').write_text(report)
receipt={'schema_version':1,'status':'PASS_PR174_COMBINATION_AND_BINDING','agent':'Agent #5/sessiond4d5258160f7 read-only dependency specialist','main':R['main'],'head':R['head'],'source':R['source'],'direct_base':R['direct_base'],'actual_stacked_test_merge':R['test_merge'],'actual_stacked_tree':R['commits']['test-merge']['tree'],'actual_stacked_parents':R['commits']['test-merge']['parents'],'prospective_full_T172':R['tree172'],'prospective_full_T174':R['tree174'],'prospective_not_actual_main':True,'actual_main_entries_preserved':22212,'prospective_final_entries':24399,'prospective_additions_to_main':2187,'intended_post_prerequisite_PR174_additions':157,'PR174_added_lines':43601,'PR174_modifications':0,'PR174_deletions':0,'selected_modules':15,'all_14_inherited_already_identical_on_main':True,'registry_git_blob':C['registry_git_blob'],'registry_sha256':C['registry_sha256'],'latest_actual_ref_observation':F['checked_at'],'dependency_owner':'Agent #8/session2e594544e72c','source_owner':'Agent #1','main_writer':'Agent #31/session02893e4f368d','actual_merge':False,'main_or_source_ref_mutation':False,'lean_execution':False,'source_edit':False,'next_action':'Actual upstream integrations and acknowledged serialized writer, then refresh/rebind and inspect the exact157-addition retargeted diff; parent handles platform gates and publication.','evidence_files':['COMBINATION_REPORT.md','combination-receipt.json','closure-binding.json','additional-bindings.json','packet168-recovery.json','final-ref-check.json','commands.jsonl','stacked-delta.json','main-to-final-delta.json']}
(OUT/'machine-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print('Wrote COMBINATION_REPORT.md and machine-receipt.json')
