import subprocess,json,pathlib,hashlib,datetime,sys,os
OUT=pathlib.Path('/workspace/scratch/d4d5258160f7/agent5/pr174-combination')
REPO='/workspace/scratch/d4d5258160f7/agent5/repo'
def run(label,args,check=True,cwd=REPO,env=None,input=None):
    started=datetime.datetime.now(datetime.timezone.utc).isoformat()
    p=subprocess.run(args,cwd=cwd,env=env,input=input,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    raw=OUT/'raw';raw.mkdir(exist_ok=True)
    (raw/(label+'.stdout')).write_bytes(p.stdout)
    (raw/(label+'.stderr')).write_bytes(p.stderr)
    receipt={'label':label,'argv':args,'cwd':cwd,'started':started,'exit_code':p.returncode,'stdout_file':'raw/'+label+'.stdout','stderr_file':'raw/'+label+'.stderr','stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()}
    if input is not None:
        (raw/(label+'.stdin')).write_bytes(input)
        receipt.update(stdin_file='raw/'+label+'.stdin',stdin_sha256=hashlib.sha256(input).hexdigest())
    if env is not None:receipt['controlled_environment']={k:v for k,v in env.items() if k.startswith('GIT_')}
    with (OUT/'commands.jsonl').open('a') as f:f.write(json.dumps(receipt)+'\n')
    if check and p.returncode: raise RuntimeError(receipt)
    return p
def git(label,*args,check=True):return run(label,['git','-c','credential.helper=','-c','core.askPass=','-C',REPO,*args],check=check)
if __name__=='__main__':
    p=run(sys.argv[1],sys.argv[2:],check=False)
    sys.stdout.buffer.write(p.stdout);sys.stderr.buffer.write(p.stderr);sys.exit(p.returncode)
