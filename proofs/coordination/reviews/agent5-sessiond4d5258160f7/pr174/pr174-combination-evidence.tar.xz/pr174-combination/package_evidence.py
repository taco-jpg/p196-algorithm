from run_capture import *
import tarfile,lzma
archive=OUT/'pr174-combination-evidence.tar.xz'
excluded={'objects.git','__pycache__'}
files=[]
for p in sorted(OUT.rglob('*')):
 if not p.is_file():continue
 rel=p.relative_to(OUT)
 if any(x in excluded for x in rel.parts) or p.name in ['FILES.json','ARCHIVE_RECEIPT.json','pr174-combination-evidence.tar.xz']:continue
 data=p.read_bytes();files.append({'path':str(rel),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
manifest={'schema_version':1,'scope':'All delivery evidence excluding reconstructible object store, interpreter cache, archive/receipt, and manifest self-entry','files':files}
mf=OUT/'FILES.json';mf.write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(archive,'w:xz',preset=6,format=tarfile.PAX_FORMAT) as tar:
 for p in [OUT/x['path'] for x in files]+[mf]:
  info=tar.gettarinfo(str(p),arcname='pr174-combination/'+str(p.relative_to(OUT)))
  info.mtime=0;info.uid=0;info.gid=0;info.uname='';info.gname='';info.mode=0o644
  with p.open('rb') as f:tar.addfile(info,f)
expected={x['path']:x for x in files};seen=set()
with tarfile.open(archive,'r:xz') as tar:
 for member in tar:
  name=member.name.removeprefix('pr174-combination/');b=tar.extractfile(member).read();seen.add(name)
  if name=='FILES.json':assert b==mf.read_bytes()
  else:assert len(b)==expected[name]['bytes'] and hashlib.sha256(b).hexdigest()==expected[name]['sha256']
assert seen==set(expected)|{'FILES.json'}
receipt={'status':'PASS_LOSSLESS_ARCHIVE','archive':archive.name,'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'manifest_sha256':hashlib.sha256(mf.read_bytes()).hexdigest(),'members':len(seen),'evidence_bytes':sum(x['bytes'] for x in files),'excluded':['objects.git/','__pycache__/','archive and external receipt','FILES.json self-entry'],'verification':'Every archive member read and SHA256/length checked; archive bytes hashed.'}
(OUT/'ARCHIVE_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
