from run_capture import *
prs=[146,147,150,154,166,168,172,174]
values=[json.loads(json.loads((OUT/'remote'/('pr'+str(p)+'.json')).read_text())['value']['structuredContent']['content']) for p in prs]
refs={'refs/heads/main':'74a1c3922eb7af438fe40b23d2105ad07556e3f5'}
refs.update({'refs/heads/'+v['head']['ref']:v['head']['sha'] for v in values})
refs['refs/pull/174/merge']='139ead8fb3a3faccbb7857c9bd41eeb2b3a82389'
raw=run('final-live-ref-observation',['git','-c','credential.helper=','-c','core.askPass=','ls-remote','https://github.com/taco-jpg/p196-algorithm.git',*refs]).stdout.decode()
actual={line.split()[1]:line.split()[0] for line in raw.splitlines()};assert actual==refs
receipt={'status':'PASS_ALL_10_ACTUAL_REFS_STILL_PINNED','actual':actual,'expected':refs,'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUT/'final-ref-check.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2))
