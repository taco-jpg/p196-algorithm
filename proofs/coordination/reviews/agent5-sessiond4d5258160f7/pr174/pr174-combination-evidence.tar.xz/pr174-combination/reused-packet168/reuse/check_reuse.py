#!/usr/bin/env python3
"""Read-only retained-evidence qualification. Does not invoke Lean or retained code."""
import pathlib, json, hashlib, re, subprocess, collections, datetime
R=pathlib.Path(__file__).resolve().parent
REPO=R.parents[1]/'agent16-repo'
P='proofs/contributions/agent-1/periodic-cycle-adapter-20261017/'
E=R/'retained'/P
H='7f23ce839fcc88acb235b1816c2c57dc12e16a33'
S='6f169320a7a750ea7978093c4cd05140d5d6cc73'
def js(p): return json.loads(p.read_text())
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def tree(commit):
    s=subprocess.check_output(['git','-C',str(REPO),'ls-tree','-r',commit],text=True)
    return {line.split('\t')[1]:line.split()[2] for line in s.splitlines()}
T=tree(H);TS=tree(S)
checks=[]
def ck(name,ok,details=None):
    row={'check':name,'passed':bool(ok)}
    if details is not None: row['details']=details
    checks.append(row)
    print(('PASS ' if ok else 'FAIL ')+name)
def manifest(base,fn,count):
    m=js(base/fn);rows=[]
    for name,pin in m.items():
        f=base/name;b=f.read_bytes() if f.exists() else b''
        ok=f.exists() and sha(b)==pin['sha256'] and len(b)==pin['bytes']
        rows.append({'path':str(f.relative_to(R/'retained')),'sha256':sha(b),'bytes':len(b),'passed':ok})
    ck(fn+': count and all exact bytes',len(m)==count and all(x['passed'] for x in rows),{'count':len(m),'expected':count})
    return rows
allfiles=[]
for path,gitsha in T.items():
    if path.startswith(P) and any(path.startswith(P+x+'/') for x in ['review','verification','complementary-review']):
        f=R/'retained'/path;b=f.read_bytes() if f.exists() else b''
        allfiles.append({'path':path,'git_blob':gitsha,'sha256':sha(b),'bytes':len(b),'passed':f.exists() and blob(b)==gitsha})
ck('All 184 retained evidence paths match head Git blobs',len(allfiles)==184 and all(x['passed'] for x in allfiles))
manifests={
    'review':manifest(E/'review','evidence-files.json',108),
    'parent_original':manifest(E/'verification/parent-clean-001','FILES.json',63),
    'parent_package':manifest(E/'verification/parent-clean-001','PACKAGE_FILES.json',67),
    'complementary':manifest(E/'complementary-review','FILES.json',6),
}
regpath='proofs/Agent1PeriodicCycleNumeric.registry.json';rb=(R/'retained'/regpath).read_bytes();registry=js(R/'retained'/regpath)
ck('Final registry exact bytes at H and S',sha(rb)=='239a98f425775ffa41298e1776e7618aed4793f064115f8571f4a29bc0dabac7' and blob(rb)==T[regpath]==TS[regpath],{'git_blob':blob(rb),'sha256':sha(rb)})
ident=js(E/'review/final-source-identity.json');sources=ident['sources'];modules=registry['projects']['agent1-periodic-cycle-adapter']['modules']
ck('Registry and independently pinned source list agree',len(sources)==len(modules)==30 and all({k:v for k,v in e.items() if k!='module'}==modules[e['module']] for e in sources))
def mask(source):
    out=[];i=0;depth=0
    while i<len(source):
        if depth:
            if source.startswith('/-',i): depth+=1;i+=2;out.extend('  ')
            elif source.startswith('-/',i): depth-=1;i+=2;out.extend('  ')
            else: out.append('\n' if source[i]=='\n' else ' ');i+=1
        elif source.startswith('/-',i): depth=1;i+=2;out.extend('  ')
        elif source.startswith('--',i):
            j=source.find('\n',i);j=len(source) if j<0 else j;out.extend(' '*(j-i));i=j
        elif source[i]=='"':
            out.append(' ');i+=1
            while i<len(source):
                ch=source[i];i+=1;out.append('\n' if ch=='\n' else ' ')
                if ch=='\\' and i<len(source): out.append(' ');i+=1
                elif ch=='"': break
        else: out.append(source[i]);i+=1
    assert depth==0
    return ''.join(out)
source_checks=[];graph={};order=[]
for e in sources:
    m=e['module'];b=(E/'review/clean-001/compiled-sources'/(m+'.lean')).read_bytes();code=mask(b.decode());imports=[]
    for group in re.findall(r'^\s*import\s+([^\n]+)',code,re.M): imports.extend(group.split())
    graph[m]=imports
    row=dict(e,observed_sha256=sha(b),observed_git_blob=blob(b),actual_imports=imports)
    row['passed']=sha(b)==e['sha256'] and blob(b)==e['git_blob']==T.get(e['path'])==TS.get(e['path']) and imports==e['imports']
    row['parent_source_identical']=b==(E/'verification/parent-clean-001/agent1-periodic-cycle-adapter/source'/(m+'.lean')).read_bytes()
    row['topological_order']=all(i in order or i=='Std' for i in imports)
    row['forbidden_tokens']=re.findall(r'\b(?:sorry|admit|sorryAx|native_decide|axiom)\b|Lean\.ofReduceBool',code)
    source_checks.append(row);order.append(m)
    out=R/'retained'/e['path'];out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(b)
ck('Every one of 30 compiled source pins equals H and S',all(x['passed'] for x in source_checks))
ck('All 30 parent source snapshots are identical',all(x['parent_source_identical'] for x in source_checks))
ck('Source compilation order satisfies project imports',all(x['topological_order'] for x in source_checks))
seen=set();external=set()
def dfs(m):
    if m in seen:return
    if m not in graph:external.add(m);return
    seen.add(m)
    for i in graph[m]:dfs(i)
dfs('Agent1PeriodicCycleNumeric')
ck('Actual root transitive project closure is exactly 30 modules',seen==set(modules) and external=={'Std'},{'project_modules':sorted(seen),'external_toolchain_imports':sorted(external)})
ck('Auxiliary source token scan has no proof shortcuts',all(not x['forbidden_tokens'] for x in source_checks))
results=js(E/'review/clean-001/results.json');command_checks=[]
for run in results:
    b=(E/'review/clean-001'/(run['module']+'.log')).read_bytes();cmd=run['command']
    ok=run['exit_code']==0 and not run['timed_out'] and sha(b)==run['log_sha256'] and all(f in cmd for f in ['--trust=0','-j1','-DElab.async=false']) and cmd[-1]==run['module']+'.lean'
    command_checks.append(dict(run,passed=ok,log_bytes=len(b)))
ck('Independent 31 commands, exit statuses, flags and raw log hashes',len(results)==31 and [x['module'] for x in results]==order+['ReviewAudit'] and all(x['passed'] for x in command_checks))
compiler=js(E/'review/clean-001/compiler.json');limits=js(E/'review/clean-001/resource-limits.json')
ck('Pinned compiler and resources are consistent',compiler['sha256']=='92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023' and 'version 4.19.0' in compiler['version'] and '6caaee842e94' in compiler['version'] and all(r['resource_limits']==limits for r in results) and limits['address_space_mib_per_child']==8192 and limits['timeout_seconds_per_command']==600)
log=(E/'review/clean-001/ReviewAudit.log').read_text();audit_source=(E/'review/clean-001/ReviewAudit.lean').read_text()
selected=json.loads(re.search(r'let selected : List String := (\[[^\n]+\])',audit_source).group(1))
ck('Retained audit selects exactly the registered 30-module closure',selected==order and audit_source.count('Lean.collectAxioms name')==3)
theorems=re.findall(r'^AUDIT_THEOREM (\S+) (\S+) : \[([^\]]*)\]',log,re.M)
defs=re.findall(r'^AUDIT_SAFE_(?:DEFINITION|OPAQUE) (\S+) (\S+) : \[([^\]]*)\]',log,re.M)
axs=lambda s:set(re.findall(r'[A-Za-z][A-Za-z0-9_.]*',s))
allowed={'propext','Quot.sound','Classical.choice'}
tu=set().union(*(axs(x[2]) for x in theorems));du=set().union(*(axs(x[2]) for x in defs))
ck('Raw theorem origin audit count and transitive axiom closure',len(theorems)==1506 and len(set((m,n) for m,n,a in theorems))==1506 and set(m for m,n,a in theorems)==set(modules) and tu==allowed and all(axs(a)<=allowed for m,n,a in theorems))
ck('Raw safe definition audit count and transitive axiom closure',len(defs)==243 and len(set((m,n) for m,n,a in defs))==243 and du=={'propext'})
newmods={'Agent1PeriodicCyclePath','Agent1PeriodicCycleGuard','Agent1PeriodicCycleNumeric'}
newth=[x for x in theorems if x[0] in newmods];newdefs=[x for x in defs if x[0] in newmods]
ck('New module full-origin counts',len(newth)==31 and len(newdefs)==2,{'theorem_counts':dict(collections.Counter(x[0] for x in newth)),'safe_definition_counts':dict(collections.Counter(x[0] for x in newdefs))})
checked=re.findall(r'^#check\s+(\S+)',audit_source,re.M)
ck('Twelve advertised exports have full checked output',all(n in checked and re.search(r'^'+re.escape(n)+r'(?:\s|:)',log,re.M) for n in ident['new_module_exports']) and len(checked)==126)
ck('All ten public theorem exports have printed axiom outputs',all(any(("'"+n+"' depends on axioms:") in (E/'review/clean-001'/(m+'.log')).read_text() or ("'"+n+"' does not depend on any axioms") in (E/'review/clean-001'/(m+'.log')).read_text() for m in newmods) for n in ident['new_module_theorems']))
non=re.findall(r'^NONSAFE_DEFINITION (\S+) (\S+)',log,re.M);unsafeax=re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)',log,re.M);opaque=re.findall(r'^UNSAFE_OPAQUE (\S+) (\S+)',log,re.M)
cstage=[x for x in non if re.search(r'\._cstage[12](?:\.|$)',x[1])];rec=[x for x in non if x[1].endswith('._unsafe_rec')];safe={(m,n) for m,n,a in defs}
ck('Runtime helpers and implementation axioms remain separately accounted',len(non)==976 and len(cstage)==945 and len(rec)==31 and all((m,n[:-len('._unsafe_rec')]) in safe for m,n in rec) and len(unsafeax)==13 and all(m=='LychrelDigitSums' for m,n in unsafeax) and not opaque)
ck('Raw audit contains no disallowed proof finding',not re.search(r'CUSTOM_AXIOM|DISALLOWED_|MODULE_NOT_AUDITED|sorryAx|Lean\.ofReduceBool|error:',log))
parentbase=E/'verification/parent-clean-001';pv=js(parentbase/'verification.json');pp=pv['projects']['agent1-periodic-cycle-adapter'];pc=[]
for run in pp['commands']:
    b=(parentbase/run['log']).read_bytes();pc.append({'label':run['label'],'passed':run['exit_code']==0 and sha(b)==run['log_sha256'],'explicit_trust_flag':any('trust' in a for a in run['argv'])})
ck('Parent canonical 31 commands and log hashes qualify with historical flags',len(pc)==31 and all(r['passed'] and not r['explicit_trust_flag'] for r in pc) and pv['source_tree_clean'] is True and pp['theorem_count']==1506 and pv['status']=='PASS')
pkg=js(parentbase/'PACKAGE.json');cb=(parentbase/'CHECKER.py').read_bytes();cp=pkg['checker_snapshot']['path']
ck('Canonical checker snapshot exact at reviewed source and H',sha(cb)==pkg['checker_snapshot']['sha256'] and blob(cb)==T[cp]==TS[cp])
receipt=(E/'review/frozen-receipt.json').read_bytes();fr=json.loads(receipt)
ck('Final reviewer receipt exact expected hash',sha(receipt)=='8a8b48e385b9208917e86a57035253a335add0168ee7ce355593f63b96e45914')
ck('Receipt linked evidence hashes match actual bytes',all(sha((E/'review'/p).read_bytes())==s for p,s in fr['review_evidence'].items()))
formal=js(R/'actual-review-5555324338.json')
ck('Actual formal review belongs to exact H and remains COMMENTED',formal['id']==5555324338 and formal['commit_id']==H and formal['state']=='COMMENTED')
comp=js(E/'complementary-review/source-inspection-receipt.json');cr=js(E/'complementary-review/observed-sources-001/Agent1PeriodicCycleNumeric.registry.json')
ck('Complementary review source hashes qualify without execution attribution',comp['new_lean_execution'] is False and comp['proof_authorship'] is False and all(next(e['sha256'] for e in sources if e['module']==x['module'])==x['sha256'] for x in comp['new_source_pins']) and cr['projects']['agent1-periodic-cycle-adapter']['modules']==modules)
out={'status':'PASS_REUSABLE' if all(x['passed'] for x in checks) else 'NEEDS_INVESTIGATION','checked_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'source_head':H,'reviewed_source_commit':S,'scope':'Qualification of retained exact-source evidence; no Lean execution or merge verification in this task.','checks':checks,'source_checks':source_checks,'command_checks':command_checks,'parent_command_checks':pc,'manifests':manifests,'evidence_files':allfiles,'compiler_record':compiler,'resource_limits':limits,'raw_audit_counts':{'theorems':len(theorems),'safe_definitions':len(defs),'new_theorems':len(newth),'new_safe_definitions':len(newdefs),'nonsafe_definitions':len(non),'cstage_helpers':len(cstage),'unsafe_rec_helpers':len(rec),'implementation_axioms':len(unsafeax)},'theorem_axiom_union':sorted(tu),'safe_definition_axiom_union':sorted(du),'formal_review':{'id':formal['id'],'state':formal['state'],'commit_id':formal['commit_id'],'url':formal['html_url'],'author_login':formal['user']['login']},'qualification_limits':['No new Lean execution; retained output is reused.','No platform approval inferred from COMMENTED or same-account specialist independence.','No new independent semantic review of previously authored frozen dependencies is claimed.','Combined current-main tree and final integration are the delivery owner responsibility.']}
(R/'checks.json').write_text(json.dumps(out,indent=2)+'\n')
(R/'audit-extracted.json').write_text(json.dumps({'theorems':[{'module':m,'name':n,'axioms':sorted(axs(a))} for m,n,a in theorems],'safe_definitions':[{'module':m,'name':n,'axioms':sorted(axs(a))} for m,n,a in defs],'new_checked_export_names':ident['new_module_exports']},indent=2)+'\n')
print(out['status'])
raise SystemExit(0 if out['status']=='PASS_REUSABLE' else 1)
