#!/usr/bin/env python3
"""Recover exact evidence files from the accompanying JSON package."""
import base64
import gzip
import hashlib
import json
from pathlib import Path
import sys

package_path = Path(sys.argv[1])
destination = Path(sys.argv[2]).resolve()
package = json.loads(package_path.read_text())
for name, item in package["files"].items():
    target = (destination / name).resolve()
    if destination not in target.parents:
        raise ValueError(f"Package path escapes destination: {name}")
    content = gzip.decompress(base64.b64decode(item["gzip_base64"], validate=True))
    assert len(content) == item["bytes"]
    assert hashlib.sha256(content).hexdigest() == item["sha256"]
    if target.exists():
        if target.read_bytes() != content:
            raise FileExistsError(f"Refusing to overwrite different file: {target}")
    else:
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(content)
print(f"Verified and recovered {len(package['files'])} exact evidence files.")
