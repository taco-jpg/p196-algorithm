#!/usr/bin/env python3
"""Read-only byte, archive, and provenance checks; never executes Lean or archived scripts."""
from pathlib import Path
import collections
import datetime
import hashlib
import json
import subprocess

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[1] / 'agent16-repo'
REUSE = HERE.parent / 'reuse'
PREFIX = 'proofs/contributions/agent-1/periodic-cycle-adapter-20261017/'
H = '7f23ce839fcc88acb235b1816c2c57dc12e16a33'
B = 'cb753e1f5e6edf409bbf8c35c8a90c63a52545d1'
ANCESTOR = '2d5cfe447811155e93cef173192e96f64ec824e1'
UPSTREAM = 'ebcaf723d61f9513c8bae30440d02ba4a46343b4'
FOUNDATION = '3b018f7032b537cd7f6218fb9ad979842bb286d0'
CLAIM = 'b4dc82e6d8d521b4295236f171b8d9e1a1d690cd'
FINAL_TREE = 'fe482076a7a4bfab705a2f64a94133da3f489b4e'

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def blob(raw):
    return hashlib.sha1(b'blob ' + str(len(raw)).encode() + b'\0' + raw).hexdigest()

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args])

def tree(ref):
    out = {}
    for line in git('ls-tree', '-r', ref).decode().splitlines():
        metadata, path = line.split('\t')
        mode, kind, oid = metadata.split()
        out[path] = {'mode': mode, 'kind': kind, 'blob': oid}
    return out

def raw(path):
    for root in (HERE / 'retained', REUSE / 'retained'):
        candidate = root / path
        if candidate.is_file():
            return candidate.read_bytes()
    raise FileNotFoundError(path)

def archive(path):
    return raw(PREFIX + path)

def data(path):
    return json.loads(archive(path))

checks = []
def check(name, passed, detail=None):
    checks.append({'name': name, 'passed': bool(passed), 'detail': detail})

inventory = json.loads((HERE / 'inventory.json').read_text())
reuse = json.loads((REUSE / 'checks.json').read_text())
combination = json.loads((HERE.parent / 'COMBINATION_CHECK.json').read_text())
trees = {ref: tree(ref) for ref in (H, UPSTREAM, FOUNDATION, CLAIM, FINAL_TREE)}
diff = [line.split('\t') for line in git('diff', '--no-renames', '--name-status', ANCESTOR, H).decode().splitlines()]
check('original_three_dot_delta_is_488_additions', len(diff) == 488 and all(row[0] == 'A' for row in diff))
check('frozen_merge_base', git('merge-base', B, H).decode().strip() == ANCESTOR)
check('inventory_complete', {r['path'] for r in inventory['rows']} == {r[1] for r in diff})
counts = dict(collections.Counter(r['category'] for r in inventory['rows']))
check('partition_counts', counts == {'upstream-return-clock-154': 193, 'accepted-cycle-root': 4, 'new-archive-inspection': 107, 'reused-review-evidence': 184}, counts)
check('all_changed_entries_regular_files', all(trees[H][r[1]]['mode'] == '100644' and trees[H][r[1]]['kind'] == 'blob' for r in diff))
upstream = [r for r in inventory['rows'] if r['category'] == 'upstream-return-clock-154']
check('all_193_upstream_entries_identical_to_PR154', all(trees[H][r['path']] == trees[UPSTREAM].get(r['path']) for r in upstream))
check('all_488_entries_preserved_in_combined_tree', all(trees[H][r[1]] == trees[FINAL_TREE].get(r[1]) for r in diff))
check('combination_evidence_reusable', combination['status'] == 'PASS_PROSPECTIVE_COMBINATION' and combination['final_tree'] == FINAL_TREE and all(combination['conditions'].values()))
check('independent_evidence_reusable', reuse['status'] == 'PASS_REUSABLE' and reuse['source_head'] == H and all(x['passed'] for x in reuse['checks']))
cycle_rows = [r for r in inventory['rows'] if r['category'] != 'upstream-return-clock-154']
byte_checks = []
for row in cycle_rows:
    payload = raw(row['path'])
    byte_checks.append({'path': row['path'], 'category': row['category'], 'bytes': len(payload), 'sha256': sha(payload), 'git_blob': blob(payload), 'passed': blob(payload) == trees[H][row['path']]['blob'] == row['blob']})
check('all_295_cycle_files_have_exact_H_bytes', len(byte_checks) == 295 and all(x['passed'] for x in byte_checks))
reuse_paths = {x['path']: x for x in reuse['evidence_files']}
check('184_reused_paths_exactly_match_qualified_set', {r['path'] for r in cycle_rows if r['category'] == 'reused-review-evidence'} == set(reuse_paths) and all(x['passed'] for x in reuse_paths.values()))
check('only_four_cycle_root_files', {r['path'] for r in cycle_rows if r['category'] == 'accepted-cycle-root'} == {'proofs/Agent1PeriodicCyclePath.lean', 'proofs/Agent1PeriodicCycleGuard.lean', 'proofs/Agent1PeriodicCycleNumeric.lean', 'proofs/Agent1PeriodicCycleNumeric.registry.json'})

manifests = []
for name, style in [('guard-author/manifest.json', 'list'), ('numeric-author/FILES.json', 'mapping'), ('path-author/frozen-receipt.json', 'sha_mapping'), ('registry-preflight/FILES.json', 'list')]:
    obj = data(name)
    if style == 'list': entries = obj['files']
    elif style == 'mapping': entries = [{'path': k, **v} for k, v in obj.items()]
    else: entries = [{'path': k, 'sha256': v} for k, v in obj['files_sha256'].items()]
    base = str(Path(name).parent)
    details = []
    for entry in entries:
        payload = archive(base + '/' + entry['path'])
        details.append({'path': base + '/' + entry['path'], 'sha256': sha(payload), 'bytes': len(payload), 'passed': sha(payload) == entry['sha256'] and ('bytes' not in entry or len(payload) == entry['bytes'])})
    manifests.append({'manifest': name, 'manifest_sha256': sha(archive(name)), 'entry_count': len(entries), 'entries': details})
check('all_four_remaining_manifests_match', all(e['passed'] for m in manifests for e in m['entries']), {m['manifest']: m['entry_count'] for m in manifests})

source_pins = {x['module']: x for x in reuse['source_checks']}
registry = json.loads(raw('proofs/Agent1PeriodicCycleNumeric.registry.json'))
registered = registry['projects']['agent1-periodic-cycle-adapter']['modules']
check('archive_sources_excluded_from_accepted_registry', len(registered) == 30 and all(not x['path'].startswith('proofs/contributions/') for x in registered.values()))
new_sources = {'Agent1PeriodicCyclePath': 'path-author/attempt-001/Agent1PeriodicCyclePath.lean', 'Agent1PeriodicCycleGuard': 'guard-author/attempt-003/Agent1PeriodicCycleGuard.lean', 'Agent1PeriodicCycleNumeric': 'numeric-author/attempt-002/Agent1PeriodicCycleNumeric.lean'}
check('successful_author_snapshots_equal_accepted_sources', all(sha(archive(path)) == source_pins[name]['sha256'] and blob(archive(path)) == source_pins[name]['git_blob'] for name, path in new_sources.items()))
check('Guard002_Guard003_source_identical', archive('guard-author/attempt-002/Agent1PeriodicCycleGuard.lean') == archive('guard-author/attempt-003/Agent1PeriodicCycleGuard.lean'))
check('Numeric001_Numeric002_source_identical', archive('numeric-author/attempt-001/Agent1PeriodicCycleNumeric.lean') == archive('numeric-author/attempt-002/Agent1PeriodicCycleNumeric.lean'))
check('failed_Guard001_source_is_distinct', blob(archive('guard-author/attempt-001/Agent1PeriodicCycleGuard.lean')) != source_pins['Agent1PeriodicCycleGuard']['git_blob'])

command_rows = []
expected = {'guard-author/attempt-001': [1], 'guard-author/attempt-002': [0, 1], 'guard-author/attempt-003': [0, 0], 'numeric-author/attempt-001': [0, 1], 'numeric-author/attempt-002': [0, 0]}
for attempt, exits in expected.items():
    commands = data(attempt + '/commands.json')
    result = data(attempt + '/result.json')
    commands_valid = [x['exit_code'] for x in commands] == exits and result['exit_code'] == exits[-1]
    for command in commands:
        flags = command['command']
        payload = archive(attempt + '/' + command['name'] + '.log')
        command_rows.append({'attempt': attempt, 'kind': command['name'], 'exit_code': command['exit_code'], 'command': flags, 'compiler_sha256': command['compiler_sha256'], 'log_sha256': sha(payload), 'log_bytes': len(payload)})
        commands_valid &= all(flag in flags for flag in ['--trust=0', '-j1', '-DElab.async=false'])
    check('historical_commands_' + attempt.replace('/', '_'), commands_valid and result['dependency_objects_reused'] is True and result['fresh_full_closure'] is False)
for attempt in ['path-author/attempt-001', 'path-author/audit-001']:
    receipt = data(attempt + '/receipt.json')
    check('historical_commands_' + attempt.replace('/', '_'), receipt['status'] == 'PASS' and receipt['exit_code'] == 0 and receipt['fresh_dependency_build'] is False and receipt['source_and_dependencies_unchanged'] is True and '--trust=0' in receipt['command'])
    command_rows.append({'attempt': attempt, 'kind': 'compile' if 'attempt-' in attempt else 'audit', 'exit_code': receipt['exit_code'], 'command': receipt['command'], 'log_sha256': sha(archive(attempt + '/lean.log'))})

failure_details = [
    ('guard-author/attempt-001/compile.log', 'unknown tactic', 'Source compilation failed at line 71: conv_lhs unavailable; downstream unsolved goals and sorryAx are retained only in this failed historical run.'),
    ('guard-author/attempt-002/audit.log', 'UNEXPECTED_UNSAFE_DEFINITION Agent1.Periodic.quotientCycleExponent._cstage1', 'Compilation passed; a conservative audit rejected a generated runtime helper. Attempt003 inventories exactly two helpers and still audits the safe definition and theorem closure.'),
    ('guard-author/runtime-inventory-001/output.log', 'Expected exactly one file name', 'Read-only inventory passed -o without an output filename; corrected inventory002 removes that option and exits zero.'),
    ('numeric-author/attempt-001/audit.log', 'INCOMPLETE_DEFINITION_INVENTORY', 'Compilation passed; copied Guard-specific definition-count assertion failed after all four theorem dependency lists. Attempt002 expects zero definitions and rejects any unexpected definition; source is unchanged.')]
failures = [{'path': p, 'first_meaningful_error': e, 'diagnosis': d, 'sha256': sha(archive(p))} for p, e, d in failure_details]
check('all_four_historical_failures_substantiated', all(e in archive(p).decode() for p, e, d in failure_details))
check('failed_guard_sorryAx_kept_outside_accepted_source', 'sorryAx' in archive(failure_details[0][0]).decode() and all('sorryAx' not in raw(v['path']).decode() for v in registered.values()))
check('inventory_repair_retained', data('guard-author/runtime-inventory-001/command.json')['exit_code'] == 1 and data('guard-author/runtime-inventory-002/command.json')['exit_code'] == 0 and '-o' not in data('guard-author/runtime-inventory-002/command.json')['command'])

dependency_checks = []
for attempt in expected:
    deps = data(attempt + '/dependencies.json')
    dependency_checks.append({'attempt': attempt, 'count': len(deps), 'passed': all(x['source_sha256'] == source_pins[x['module']]['sha256'] for x in deps)})
for attempt in ['path-author/attempt-001', 'path-author/audit-001']:
    deps = data(attempt + '/source-and-dependencies.json')['dependencies']
    dependency_checks.append({'attempt': attempt, 'count': len(deps), 'passed': all(x['sha256'] == source_pins[name]['sha256'] and x['git_blob'] == source_pins[name]['git_blob'] for name, x in deps.items())})
check('author_dependency_source_pins_match_qualified_closure', all(x['passed'] for x in dependency_checks))

confirmation = data('registry-preflight/author-confirmation.json')
confirmation_checks = []
for name, record in confirmation['modules'].items():
    for receipt in record['receipts']:
        confirmation_checks.append({'path': receipt['path'], 'passed': sha(raw(receipt['path'])) == receipt['sha256']})
check('author_confirmation_receipt_links_match', confirmation['author_confirmation_received'] is True and len(confirmation_checks) == 14 and all(x['passed'] for x in confirmation_checks))
claimraw = archive('registry-preflight/claim.json')
claimread = data('registry-preflight/claim-read.json')
check('original_claim_exact_commit_and_bytes', trees[CLAIM][claimread['path']]['blob'] == claimread['git_blob'] == blob(claimraw) and sha(claimraw) == claimread['sha256'])
parents = [x.split()[1] for x in git('cat-file', '-p', FOUNDATION).decode().splitlines() if x.startswith('parent ')]
check('source_foundation_has_exact_two_documented_parents', parents == [ANCESTOR, UPSTREAM], parents)
preflight = []
for run, count, status in [('run-000', 27, 'INHERITED_SOURCE_PREFLIGHT_PASS'), ('run-001', 30, 'SOURCE_PREFLIGHT_PASS_PROVISIONAL'), ('run-002', 30, 'SOURCE_PREFLIGHT_PASS_AUTHOR_FROZEN')]:
    report = data('registry-preflight/' + run + '/report.json')
    modules = data('registry-preflight/' + run + '/modules.json')
    ok = report['status'] == status and report['module_count'] == len(modules) == count and report['lean_execution_performed'] is False and report['source_snapshots_stable_during_run'] is True
    ok &= report['script_sha256'] == sha(archive('registry-preflight/' + run + '/prepare.py'))
    ok &= all(all(v[k] == registered[name][k] for k in ['path', 'sha256', 'git_blob', 'imports']) for name, v in modules.items())
    ok &= all(trees[FOUNDATION][x['path']]['blob'] == x['git_blob'] for x in report['prior_registry_origins'])
    preflight.append({'run': run, 'status': status, 'module_count': count, 'passed': bool(ok)})
check('three_preflight_stages_preserved_and_consistent', all(x['passed'] for x in preflight))
check('final_preflight_registry_equals_published_registry', archive('registry-preflight/run-002/registry.json') == raw('proofs/Agent1PeriodicCycleNumeric.registry.json'))
claimdata = json.loads(claimraw)
check('historical_scout_hashes_match_original_claim', all(sha(archive(path)) == expected_sha for path, expected_sha in claimdata['ownership_check']['reports'].items()))

direct = [x.split('\t') for x in git('diff', '--no-renames', '--name-status', B, H).decode().splitlines()]
direct_counts = dict(collections.Counter(x[0] for x in direct))
check('direct_snapshot_difference_is_distinguished', len(direct) == 675 and direct_counts == {'A': 488, 'M': 1, 'D': 186}, direct_counts)
recovery = json.loads((HERE / 'fetched-hashes.json').read_text())
check('all_68_recovered_blobs_have_verified_identity', len(recovery) == 68 and all(all(blob(raw(path)) == entry['git_blob'] and sha(raw(path)) == entry['sha256'] for path in entry['paths']) for entry in recovery))

result = {
    'status': 'PASS_scoped' if all(c['passed'] for c in checks) else 'FAIL_scoped',
    'checked_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'scope': 'Full original PR delta accounting and remaining Cycle adapter author/preflight/archive byte provenance only',
    'agent': 'Agent #16 archive-scope specialist', 'source_head': H, 'current_stack_base': B,
    'original_merge_base': ANCESTOR, 'upstream_PR154_head': UPSTREAM, 'prospective_combined_tree': FINAL_TREE,
    'lean_execution': False, 'remote_mutation': False, 'new_independent_review_gate': False,
    'counts': counts, 'checks': checks, 'cycle_file_bytes': byte_checks, 'manifests': manifests,
    'historical_commands': command_rows, 'historical_failure_evidence': failures,
    'dependency_source_pin_checks': dependency_checks, 'confirmation_links': confirmation_checks,
    'preflight_stages': preflight, 'reused_evidence': {
        'review': reuse['formal_review'],
        'reuse_report_sha256': sha((REUSE / 'EVIDENCE_REUSE.md').read_bytes()),
        'reuse_checks_sha256': sha((REUSE / 'checks.json').read_bytes()),
        'combination_check_sha256': sha((HERE.parent / 'COMBINATION_CHECK.json').read_bytes())},
    'qualification_limits': [
        'The 193 upstream ReturnClock entries were assigned by exact tree identity to PR154; upstream semantic review remains with its existing owner.',
        'Author dependency object hashes are preserved historical metadata; no original object is needed or reused by the independently qualified clean build.',
        'This task did not execute a Lean compiler, archived driver, preflight generator, or verification checker.',
        'Current-main ownership, dependency integration, platform gates, Ready state, and actual merging remain with delivery owner Agent #16.',
        'Historical pending metadata is immutable evidence and is superseded only by later actual review and execution receipts.'
    ]}
(HERE / 'checks.json').write_text(json.dumps(result, indent=2) + '\n')
for c in checks:
    print(('PASS' if c['passed'] else 'FAIL') + ' ' + c['name'])
print(json.dumps({'status': result['status'], 'checks': len(checks), 'passed': sum(c['passed'] for c in checks), 'partition': counts}, indent=2))
raise SystemExit(0 if result['status'] == 'PASS_scoped' else 1)
