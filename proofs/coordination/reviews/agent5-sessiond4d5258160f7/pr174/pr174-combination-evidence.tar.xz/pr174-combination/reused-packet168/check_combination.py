#!/usr/bin/env python3
"""Inspect a prospective ordered PR stack without modifying any Git ref.

This is a Git tree and source-identity check, not a Lean execution or merge.
The original PR three-dot delta is distinct from a direct base/head comparison.
"""

import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
from datetime import datetime, timezone

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / "agent16-repo"
MAIN = "74a1c3922eb7af438fe40b23d2105ad07556e3f5"
STACK = [
    (146, "159ed83569f5cc4d058557c2b24b28839552b75a"),
    (147, "e77289c5f58a3238f53c0f3c6951a73515c5d7d2"),
    (150, "946c69edf3d2e6a87f5516db1fd0091eae29e663"),
    (154, "ebcaf723d61f9513c8bae30440d02ba4a46343b4"),
    (166, "cb753e1f5e6edf409bbf8c35c8a90c63a52545d1"),
    (168, "7f23ce839fcc88acb235b1816c2c57dc12e16a33"),
]
ENV = os.environ.copy()
ENV.update({
    "GIT_AUTHOR_NAME": "Agent #16 prospective integration diagnostic",
    "GIT_AUTHOR_EMAIL": "agent16@example.invalid",
    "GIT_COMMITTER_NAME": "Agent #16 prospective integration diagnostic",
    "GIT_COMMITTER_EMAIL": "agent16@example.invalid",
    "GIT_AUTHOR_DATE": "2026-10-17T05:24:00Z",
    "GIT_COMMITTER_DATE": "2026-10-17T05:24:00Z",
})
commands = []


def git(*args, stdin=None, log=True):
    argv = ["git", "-C", str(REPO), *args]
    result = subprocess.run(argv, input=stdin, capture_output=True, text=True, env=ENV)
    if log:
        commands.append({"argv": argv, "exit_code": result.returncode,
                         "stdout": result.stdout, "stderr": result.stderr})
    if result.returncode:
        raise RuntimeError(f"Git command failed ({result.returncode}): {args!r}")
    return result.stdout.strip()


def entries(ref):
    raw = git("ls-tree", "-r", "-z", ref, log=False)
    found = {}
    for record in raw.split("\0"):
        if not record:
            continue
        metadata, path = record.split("\t", 1)
        mode, kind, object_id = metadata.split()
        found[path] = {"mode": mode, "type": kind, "object_id": object_id}
    return found


def fingerprint(value):
    data = json.dumps(value, sort_keys=True, separators=(",", ":")).encode()
    return hashlib.sha256(data).hexdigest()


def mismatches(expected, actual):
    return [{"path": path, "expected": item, "actual": actual.get(path)}
            for path, item in sorted(expected.items()) if actual.get(path) != item]


def delta(left, right):
    result = []
    for path in sorted(set(left) | set(right)):
        if left.get(path) == right.get(path):
            continue
        status = "A" if path not in left else "D" if path not in right else "M"
        result.append({"status": status, "path": path,
                       "before": left.get(path), "after": right.get(path)})
    return result


report = {"schema_version": 1, "status": "IN_PROGRESS", "agent": "Agent #16",
          "session": "02ac12cc16be", "started_at": datetime.now(timezone.utc).isoformat(),
          "scope": "Prospective ordered Git combination and exact source/preservation check only",
          "lean_execution": False, "remote_mutation": False,
          "main": MAIN, "stack": [{"pr": pr, "head": head} for pr, head in STACK],
          "steps": []}
exit_code = 0
try:
    refs_before = git("show-ref")
    main_entries = entries(MAIN)
    prior = MAIN
    prior_entries = main_entries
    report["main_entry_count"] = len(main_entries)
    report["main_entries_sha256"] = fingerprint(main_entries)
    for pr, head in STACK:
        ancestor = git("merge-base", prior, head)
        tree = git("merge-tree", "--write-tree", "--no-messages", prior, head)
        if len(tree) != 40:
            raise RuntimeError(f"Unexpected merge-tree output for PR {pr}: {tree!r}")
        combined = entries(tree)
        changes = delta(prior_entries, combined)
        preservation = mismatches(prior_entries, combined)
        commit = git("commit-tree", tree, "-p", prior, "-p", head,
                     stdin=f"Agent #16 local prospective combination of PR #{pr}; not a remote integration.\n")
        step = {"pr": pr, "head": head, "prior": prior, "merge_base": ancestor,
                "combined_tree": tree, "local_unreferenced_commit": commit,
                "ordered_parents": [prior, head], "entry_count": len(combined),
                "entries_sha256": fingerprint(combined),
                "prior_path_count": len(prior_entries),
                "changed_existing_prior_paths": preservation,
                "delta_status_counts": {s: sum(r["status"] == s for r in changes)
                                        for s in ["A", "M", "D"]},
                "delta": changes}
        report["steps"].append(step)
        prior, prior_entries = commit, combined
    final_entries = prior_entries
    report["final_tree"] = report["steps"][-1]["combined_tree"]
    report["final_local_unreferenced_commit"] = prior
    report["main_preservation_mismatches"] = mismatches(main_entries, final_entries)
    report["full_input_head_preservation"] = [
        {"pr": pr, "head": head, "path_count": len(entries(head)),
         "mismatches": mismatches(entries(head), final_entries)} for pr, head in STACK
    ]
    registry = json.loads((HERE / "registry-input.json").read_text())
    modules = registry["projects"]["agent1-periodic-cycle-adapter"]["modules"]
    source_head = entries(STACK[-1][1])
    report["selected_sources"] = []
    for name, spec in modules.items():
        expected = {"mode": "100644", "type": "blob", "object_id": spec["git_blob"]}
        actual = final_entries.get(spec["path"])
        source = source_head.get(spec["path"])
        report["selected_sources"].append({"module": name, "path": spec["path"],
            "expected_registry_blob": spec["git_blob"], "expected_sha256": spec["sha256"],
            "head": source, "combined": actual,
            "pass": source == expected and actual == expected})
    original_base = STACK[-2][1]
    original_head = STACK[-1][1]
    original_ancestor = git("merge-base", original_base, original_head)
    direct = delta(entries(original_base), entries(original_head))
    pr_delta = delta(entries(original_ancestor), entries(original_head))
    report["original_PR_comparison"] = {
        "base_head": original_base, "source_head": original_head,
        "three_dot_merge_base": original_ancestor,
        "two_way_status_counts": {s: sum(r["status"] == s for r in direct) for s in ["A", "M", "D"]},
        "three_dot_status_counts": {s: sum(r["status"] == s for r in pr_delta) for s in ["A", "M", "D"]},
        "three_dot_delta": pr_delta,
        "explanation": "PR166 contains later evidence absent from PR168's fork. Direct comparison is not the PR's three-dot delta; ordered three-way integration retains that evidence."
    }
    report["refs_unchanged"] = git("show-ref") == refs_before
    conditions = {
        "all_six_merges_conflict_free": len(report["steps"]) == 6,
        "all_30_selected_sources_match": len(modules) == 30 and all(s["pass"] for s in report["selected_sources"]),
        "main_preserved": not report["main_preservation_mismatches"],
        "all_stage_prior_paths_preserved": all(not s["changed_existing_prior_paths"] for s in report["steps"]),
        "original_PR_exact_488_additions": len(pr_delta) == 488 and all(s["status"] == "A" for s in pr_delta),
        "all_refs_unchanged": report["refs_unchanged"],
    }
    report["conditions"] = conditions
    report["status"] = "PASS_PROSPECTIVE_COMBINATION" if all(conditions.values()) else "FINDINGS_REQUIRE_INSPECTION"
except Exception as error:
    report["status"] = "DIAGNOSTIC_FAILED"
    report["error"] = repr(error)
    exit_code = 1
finally:
    report["finished_at"] = datetime.now(timezone.utc).isoformat()
    report["commands"] = commands
    destination = HERE / "COMBINATION_CHECK.json"
    destination.write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({"status": report["status"], "conditions": report.get("conditions"),
                      "final_tree": report.get("final_tree"),
                      "steps": [{k: s[k] for k in ["pr", "combined_tree", "entry_count", "delta_status_counts"]}
                                for s in report["steps"]],
                      "report": str(destination), "error": report.get("error")}, indent=2))
sys.exit(exit_code)
