#!/usr/bin/env python3
"""Qualify stale inherited snapshots separately from actual PR changes."""
import hashlib
import json
from pathlib import Path
import subprocess

here = Path(__file__).resolve().parent
repo = here.parent / "agent16-repo"
report = json.loads((here / "COMBINATION_CHECK.json").read_text())
calls = []


def entry(ref, path):
    args = ["git", "-C", str(repo), "ls-tree", ref, "--", path]
    result = subprocess.run(args, text=True, capture_output=True)
    calls.append({"argv": args, "exit_code": result.returncode,
                  "stdout": result.stdout, "stderr": result.stderr})
    assert result.returncode == 0
    if not result.stdout:
        return None
    metadata, found = result.stdout.rstrip("\n").split("\t", 1)
    assert found == path
    mode, kind, object_id = metadata.split()
    return {"mode": mode, "type": kind, "object_id": object_id}


stale = []
for source in report["full_input_head_preservation"]:
    step = next(s for s in report["steps"] if s["pr"] == source["pr"])
    for mismatch in source["mismatches"]:
        path = mismatch["path"]
        ancestor = entry(step["merge_base"], path)
        prior = entry(step["prior"], path)
        result = dict(pr=source["pr"], **mismatch,
                      ancestor=ancestor, prior=prior,
                      unchanged_on_incoming_branch=mismatch["expected"] == ancestor,
                      preserves_newer_previous_stage=mismatch["actual"] == prior)
        stale.append(result)

target = report["final_tree"]
pins = {
    "proofs/Agent1PeriodicCycleNumeric.registry.json": "6bda231e3e4c1e4ac4bfabcbb62016de4a04fd7e",
    "proofs/verify_project__214bf7673efe116b.py": "21131b03dfa516eb19a0a7a4df4f2a41020d4db1",
    "proofs/Agent1PeriodicReturnClock.registry.json": "e49fd9dbe91dce01762e2277eab53a794b1bb5a2",
    "proofs/Agent1PeriodicGuardedPath.registry.json": "6ae574f68c09ea1cfb5178126dd0ce643c46759a",
}
pin_results = []
for path, blob in pins.items():
    actual = entry(target, path)
    pin_results.append({"path": path, "expected_blob": blob, "actual": actual,
                        "pass": actual == {"mode": "100644", "type": "blob", "object_id": blob}})
final_step = report["steps"][-1]
prefix = "proofs/contributions/agent-1/periodic-cycle-adapter-20261017/"
roots = {
    "proofs/Agent1PeriodicCyclePath.lean",
    "proofs/Agent1PeriodicCycleGuard.lean",
    "proofs/Agent1PeriodicCycleNumeric.lean",
    "proofs/Agent1PeriodicCycleNumeric.registry.json",
}
scope_pass = len(final_step["delta"]) == 295 and all(
    item["status"] == "A" and (item["path"] in roots or item["path"].startswith(prefix))
    for item in final_step["delta"])
checks = {
    "all_stale_inherited_snapshots_unchanged_from_ancestor": all(x["unchanged_on_incoming_branch"] for x in stale),
    "all_stale_snapshots_resolve_to_retained_newer_previous_stage": all(x["preserves_newer_previous_stage"] for x in stale),
    "registries_and_checker_exact": all(x["pass"] for x in pin_results),
    "post_prerequisite_PR168_delta_exact_295_cycle_only_additions": scope_pass,
}
out = {"status": "PASS_PRESERVATION_DETAILS" if all(checks.values()) else "FINDING",
       "checks": checks, "stale_inherited_snapshot_comparisons": stale,
       "registry_and_checker_pins": pin_results, "final_tree": target,
       "original_PR_additions": 488, "already_owned_return_clock_additions": 193,
       "remaining_cycle_additions": 295,
       "interpretation": "Incoming branches retain older unmodified inherited snapshots. Three-way integration keeps the newer prerequisite blobs; old versions remain in the source-parent history. No original PR change is discarded and no blanket conflict resolution is used.",
       "lean_execution": False, "remote_mutation": False, "commands": calls}
(here / "PRESERVATION_DETAILS.json").write_text(json.dumps(out, indent=2) + "\n")
print(json.dumps({"status": out["status"], "checks": checks,
                  "stale_comparison_count": len(stale),
                  "distinct_stale_paths": len({s["path"] for s in stale})}, indent=2))
assert all(checks.values())
