#!/usr/bin/env python3
"""Package newly produced PR168 evidence losslessly, excluding copied caches."""
import base64
import gzip
import hashlib
import json
from pathlib import Path

here = Path(__file__).resolve().parent
items = {}
excluded = []
for p in sorted(here.iterdir()):
    if p.is_file() and p.name != "EVIDENCE_PACKAGE.json":
        items[p.name] = p
for folder in ["reuse", "archive_scope"]:
    for p in sorted((here / folder).iterdir()):
        if p.is_file() and p.name != "tree-H.txt":
            items[f"{folder}/{p.name}"] = p
        elif p.name == "tree-H.txt":
            excluded.append({"path": f"{folder}/{p.name}",
                "reason": "Reconstructible full Git tree cache, not a new research result",
                "sha256": hashlib.sha256(p.read_bytes()).hexdigest()})
for p in sorted((here.parent / "agent16-next-actions").iterdir()):
    if p.is_file():
        items[f"ownership/{p.name}"] = p
assert (here / "archive_scope/ARCHIVE_SCOPE.md").exists(), "Archive scope report must be finalized before packaging"
files = {}
for name, path in items.items():
    content = path.read_bytes()
    packed = gzip.compress(content, compresslevel=9, mtime=0)
    assert gzip.decompress(packed) == content
    files[name] = {"bytes": len(content), "sha256": hashlib.sha256(content).hexdigest(),
        "git_blob_sha1": hashlib.sha1(b"blob " + str(len(content)).encode() + b"\0" + content).hexdigest(),
        "gzip_base64": base64.b64encode(packed).decode()}
package = {
    "schema_version": 1,
    "format": "Per-file deterministic gzip plus RFC4648 base64; lossless original bytes",
    "identity": "Agent #16/session02ac12cc16be",
    "repository": "taco-jpg/p196-algorithm",
    "pr": 168,
    "source_head": "7f23ce839fcc88acb235b1816c2c57dc12e16a33",
    "source_review": "https://github.com/taco-jpg/p196-algorithm/pull/168#pullrequestreview-5555324338",
    "prospective_main": "74a1c3922eb7af438fe40b23d2105ad07556e3f5",
    "prospective_final_tree": "fe482076a7a4bfab705a2f64a94133da3f489b4e",
    "status": "Qualified retained evidence and prospective combination; no remote merge, Ready transition, or new Lean build",
    "recovery": "For each files[name], base64-decode gzip_base64, gzip-decompress, then verify bytes and sha256 before writing to name. The included recover_evidence_package.py performs this without overwriting differing files. Run: python3 recover_evidence_package.py EVIDENCE_PACKAGE.json recovered-evidence",
    "readable_primary_reports": ["DELIVERY_PACKET.md", "reuse/EVIDENCE_REUSE.md", "archive_scope/ARCHIVE_SCOPE.md"],
    "exclusions": excluded + [
        {"paths": ["reuse/retained/", "reuse/blobs/", "archive_scope/retained/", "archive_scope/blobs/"],
         "reason": "Copied recovery caches of already published immutable Git blobs at source_head. Exact original paths, Git IDs, byte sizes, SHA256s, and fetch identity checks remain in the included complete provenance/manifest records. No new report, substantive failed attempt, or source is omitted from publication; originals remain in their source commits."},
        {"paths": ["agent16-repo/.git", "local toolchains", "compiled objects"],
         "reason": "Reconstructible Git/runtime/build caches are not repository research deliverables. This task performed no Lean compilation. The diagnostic scripts, exact heads, trees, ordered parents, commands, and full outputs are preserved."}
    ],
    "file_count": len(files), "uncompressed_bytes": sum(f["bytes"] for f in files.values()),
    "files": files,
}
destination = here / "EVIDENCE_PACKAGE.json"
destination.write_text(json.dumps(package, indent=2) + "\n")
print(json.dumps({"path": str(destination), "file_count": len(files),
                  "uncompressed_bytes": package["uncompressed_bytes"],
                  "package_bytes": destination.stat().st_size,
                  "sha256": hashlib.sha256(destination.read_bytes()).hexdigest()}, indent=2))
