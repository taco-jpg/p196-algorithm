import pathlib, subprocess, json, hashlib
ROOT=pathlib.Path('/workspace/scratch/02ac12cc16be/agent16-pr168-evidence/reuse')
REPO=pathlib.Path('/workspace/scratch/02ac12cc16be/agent16-repo')
H='7f23ce839fcc88acb235b1816c2c57dc12e16a33'
PREFIX='proofs/contributions/agent-1/periodic-cycle-adapter-20261017/'
def git(*a): return subprocess.run(['git','-C',str(REPO),*a],capture_output=True)
tree=git('ls-tree','-r',H).stdout.decode()
(ROOT/'tree-H.txt').write_text(tree)
rows=[]
for line in tree.splitlines():
    meta,path=line.split('\t'); mode,typ,sha=meta.split()
    if not ((path.startswith(PREFIX) and any('/'+x+'/' in path for x in ['review','complementary-review','verification'])) or (path.startswith('proofs/') and path.count('/')==1 and (path.endswith('.lean') or 'registry' in path)) or path in ['lean-toolchain','proofs/lean-toolchain','proofs/lakefile.lean','proofs/lake-manifest.json','AGENTS.md','proofs/AGENTS.md']): continue
    data=git('cat-file','blob',sha)
    row={'path':path,'git_blob_sha1':sha,'available_local_object':data.returncode==0}
    if data.returncode==0:
        out=ROOT/'retained'/path;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data.stdout)
        row.update(sha256=hashlib.sha256(data.stdout).hexdigest(),bytes=len(data.stdout))
    rows.append(row)
(ROOT/'collection.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'selected':len(rows),'available':sum(r['available_local_object'] for r in rows),'missing':[r for r in rows if not r['available_local_object'] and r['path'].startswith(PREFIX)]},indent=2))
