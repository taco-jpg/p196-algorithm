from run_capture import *
C='f0ab0f35eda96eee5891613901082de293e2a566'
paths=git('coord-current-paths','ls-tree','-r','--name-only',C).stdout.decode().splitlines()
matches=[x for x in paths if x.startswith('proofs/coordination/') and (('172' in x) or 'agent8-' in x or ('pr168' in x and x.endswith('DELIVERY_PACKET.md')))]
(OUT/'coord-path-matches.json').write_text(json.dumps(matches,indent=2))
print('\n'.join(matches))
for i,path in enumerate(x for x in matches if x.endswith('.md') or '/tasks/' in x):
    data=git('coord-document-'+str(i),'show',C+':'+path).stdout
    print('\nDOCUMENT:',path,'\n',data.decode()[:25000])
