from run_capture import *
import re,collections
B='74a1c3922eb7af438fe40b23d2105ad07556e3f5';H='790ee166caf3c60c7176d53209e3e755e7ed9a9d';S='bfa0247b78845558d087eec08e113e91decaaddb';P='b8c17a5204ae56ad1fc99d8f9932ca9f57b6ac80';M='139ead8fb3a3faccbb7857c9bd41eeb2b3a82389'
packet=json.loads((OUT/'reused-packet168/COMBINATION_CHECK.json').read_text())
stack=[(r['pr'],r['head']) for r in packet['stack']]+[(172,P),(174,H)]
obj=OUT/'objects.git'
env=os.environ.copy();env.update(GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0',GIT_CONFIG_GLOBAL='/dev/null',GIT_AUTHOR_NAME='Agent5 local tree diagnostic',GIT_AUTHOR_EMAIL='agent5@example.invalid',GIT_COMMITTER_NAME='Agent5 local tree diagnostic',GIT_COMMITTER_EMAIL='agent5@example.invalid',GIT_AUTHOR_DATE='2026-10-17T05:50:00Z',GIT_COMMITTER_DATE='2026-10-17T05:50:00Z')
def g(label,*args,check=True,input=None):return run(label,['git','-c','credential.helper=','-c','core.askPass=','--git-dir='+str(obj),*args],check=check,env=env,input=input)
def inv(label,ref):
 raw=g(label+'-inventory','ls-tree','-r','-z','--full-tree',ref).stdout
 out={}
 for r in raw.split(b'\0'):
  if r:
   meta,path=r.split(b'\t',1);mode,kind,oid=meta.decode().split();out[path.decode()]={'mode':mode,'type':kind,'object_id':oid}
 return out
def diff(a,b):return [{'status':'A' if p not in a else 'D' if p not in b else 'M','path':p,'before':a.get(p),'after':b.get(p)} for p in sorted(a.keys()|b.keys()) if a.get(p)!=b.get(p)]
def save(name,data):(OUT/name).write_text(json.dumps(data,indent=2)+'\n')
def commit_info(label,pin):
 raw=g(label+'-commit','cat-file','-p',pin).stdout.decode();return {'commit':pin,'tree':re.search(r'^tree (\w+)$',raw,re.M)[1],'parents':re.findall(r'^parent (\w+)$',raw,re.M)}
report={'status':'IN_PROGRESS','scope':'Read-only identity and prospective Git combination; no Lean or mathematical review','main':B,'head':H,'source':S,'direct_base':P,'test_merge':M,'remote_writes':False,'source_edits':False,'lean_execution':False,'steps':[]}
try:
 if not obj.exists():
  run('init-isolated-objects',['git','init','--bare',str(obj)],env=env)
  alternate=pathlib.Path(REPO)/'.git/objects';(obj/'objects/info/alternates').write_text(str(alternate)+'\n')
  shallow=pathlib.Path(REPO)/'.git/shallow'
  if shallow.exists():(obj/'shallow').write_bytes(shallow.read_bytes())
 save('isolation.json',{'object_store':str(obj),'read_only_alternate':str(pathlib.Path(REPO)/'.git/objects'),'shallow_metadata_copied_from_parent':(obj/'shallow').exists(),'source_worktree_not_used':True})
 refs_before=g('refs-before','show-ref',check=False).stdout
 report['commits']={label:commit_info(label,pin) for label,pin in [('main',B),('head',H),('source',S),('direct-base',P),('test-merge',M)]}
 assert report['commits']['test-merge']['parents']==[P,H]
 assert report['commits']['test-merge']['tree']==report['commits']['head']['tree']
 assert report['commits']['head']['parents']==[S] and report['commits']['source']['parents']==[P]
 entries={x:inv(x,p) for x,p in [('B',B),('H',H),('S',S),('P',P),('M',M)]}
 report['stacked_delta']=diff(entries['P'],entries['H']);save('stacked-delta.json',report['stacked_delta'])
 assert len(report['stacked_delta'])==157 and all(x['status']=='A' for x in report['stacked_delta'])
 g('stacked-full-diff','diff','--no-ext-diff','--binary',P,H)
 g('stacked-numstat','diff','--numstat',P,H)
 prior=B;previous=entries['B'];legacy_hash_matches=[]
 for number,head in stack:
  remote=json.loads(json.loads((OUT/'remote'/('pr'+str(number)+'.json')).read_text())['value']['structuredContent']['content'])
  assert remote['head']['sha']==head and not remote['merged']
  ci=commit_info('pr'+str(number),head)
  incoming=inv('pr'+str(number),head)
  ancestor_list=g('merge-base-'+str(number),'merge-base','--all',prior,head).stdout.decode().splitlines();assert ancestor_list and all(len(a)==40 for a in ancestor_list)
  raw=g('merge-tree-'+str(number),'merge-tree','--write-tree','--no-messages',prior,head).stdout.decode().strip();assert len(raw)==40
  combined=inv('stage'+str(number),raw);delta=diff(previous,combined)
  assert all(x['status']=='A' for x in delta)
  ancestor_entries=[inv('ancestor'+str(number)+'-'+str(j),a) for j,a in enumerate(ancestor_list)]
  mismatches=[{'path':p,'incoming':e,'combined':combined.get(p),'ancestors':[a.get(p) for a in ancestor_entries],'prior':previous.get(p)} for p,e in incoming.items() if combined.get(p)!=e]
  assert all(x['incoming'] in x['ancestors'] and x['combined']==x['prior'] for x in mismatches)
  virtual=g('virtual-commit-'+str(number),'commit-tree',raw,'-p',prior,'-p',head,input=('Local diagnostic only: prospective PR'+str(number)+'; no actual integration.\n').encode()).stdout.decode().strip()
  vci=commit_info('virtual-'+str(number),virtual);assert vci['parents']==[prior,head]
  result={'pr':number,'head':head,'head_commit':ci,'prior':prior,'merge_bases':ancestor_list,'tree':raw,'local_diagnostic_commit':virtual,'ordered_diagnostic_parents':[prior,head],'entries':len(combined),'added':len(delta),'modifications':0,'deletions':0,'all_prior_entries_preserved':True,'stale_inherited_snapshots':mismatches}
  if number<=168:
   old=next(x for x in packet['steps'] if x['pr']==number)
   assert raw==old['combined_tree'] and delta==old['delta']
   result['reproduces_retained_packet168_tree_and_delta']=True
  save('stage-'+str(number)+'-delta.json',delta);report['steps'].append(result)
  if number==172:entries['T172']=combined;report['tree172']=raw
  if number==168:entries['T168']=combined
  prior=virtual;previous=combined
 entries['T174']=previous;report['tree174']=report['steps'][-1]['tree'];report['final_diagnostic_commit']=prior
 assert diff(entries['T172'],entries['T174'])==report['stacked_delta']
 assert all(previous.get(p)==v for p,v in entries['B'].items())
 assert all(previous[x['path']]==x['after'] for x in report['stacked_delta'])
 report['main_entries_preserved']=len(entries['B']);report['final_entries']=len(previous);report['additions_to_main']=len(previous)-len(entries['B'])
 report['exact_post_prerequisite_delta']=True
 save('main-to-final-delta.json',diff(entries['B'],previous))
 report['refs_unchanged']=g('refs-after','show-ref',check=False).stdout==refs_before;assert report['refs_unchanged']
 report['status']='PASS_STACKED_AND_FULL_DEPENDENCY_COMBINATION'
except Exception as e:
 import traceback
 report['status']='DIAGNOSTIC_FAILED';report['error']=repr(e);report['traceback']=traceback.format_exc()
finally:
 save('combination-receipt.json',report)
 print(json.dumps({k:v for k,v in report.items() if k not in ['stacked_delta','steps']},indent=2))
 print(json.dumps([{k:v for k,v in r.items() if k not in ['stale_inherited_snapshots','head_commit']} for r in report['steps']],indent=2))
if report['status']=='DIAGNOSTIC_FAILED':sys.exit(1)
