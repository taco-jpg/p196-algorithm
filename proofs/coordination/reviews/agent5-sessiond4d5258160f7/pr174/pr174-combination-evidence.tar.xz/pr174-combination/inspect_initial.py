from run_capture import *
pins={'main':'74a1c3922eb7af438fe40b23d2105ad07556e3f5','head':'790ee166caf3c60c7176d53209e3e755e7ed9a9d','source':'bfa0247b78845558d087eec08e113e91decaaddb','base172':'b8c17a5204ae56ad1fc99d8f9932ca9f57b6ac80','merge174':'139ead8fb3a3faccbb7857c9bd41eeb2b3a82389','coord':'f0ab0f35eda96eee5891613901082de293e2a566','packet168':'b0b4e46202a492e7d5726560baba439c91efb802'}
for label,pin in pins.items():
    p=git(label+'-commit','cat-file','-p',pin,check=False)
    print(label,pin,p.returncode,p.stdout.decode()[:250])
for label in ['head','base172','coord','packet168']:
    p=git(label+'-paths','ls-tree','-r','--name-only',pins[label],check=False)
    print(label,'matching paths',*[s for s in p.stdout.decode().splitlines() if ('172' in s or 'nine-control' in s or 'DELIVERY_PACKET' in s or ('coordination' in s and 'task' in s))],sep='\n')
