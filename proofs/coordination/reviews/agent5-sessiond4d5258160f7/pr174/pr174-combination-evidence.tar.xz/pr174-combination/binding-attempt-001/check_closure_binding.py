from run_capture import *
import re
report=json.loads((OUT/'combination-receipt.json').read_text());assert report['status']=='PASS_STACKED_AND_FULL_DEPENDENCY_COMBINATION'
obj=OUT/'objects.git'
pins={'B':report['main'],'P':report['direct_base'],'S':report['source'],'H':report['head'],'M':report['test_merge'],'T172':report['tree172'],'T174':report['tree174']}
def g(label,*args):return run(label,['git','-c','credential.helper=','-c','core.askPass=','--git-dir='+str(obj),*args])
def inv(label,pin):
 result={}
 for r in g('binding-tree-'+label,'ls-tree','-r','-z','--full-tree',pin).stdout.split(b'\0'):
  if r:
   a,b=r.split(b'\t',1);mode,kind,oid=a.decode().split();result[b.decode()]={'mode':mode,'type':kind,'git_blob':oid}
 return result
trees={k:inv(k,v) for k,v in pins.items()}
rp='proofs/Agent1PeriodicNinesExtraStrip.registry.json';raw=g('binding-registry','show',pins['H']+':'+rp).stdout;reg=json.loads(raw);mods=reg['projects']['agent1-periodic-nine-control']['modules'];assert len(mods)==15
def mask(s):
 out=[];i=0;depth=0;string=False
 while i<len(s):
  if depth:
   if s.startswith('/-',i):depth+=1;out+=[' ',' '];i+=2
   elif s.startswith('-/',i):depth-=1;out+=[' ',' '];i+=2
   else:out.append('\n' if s[i]=='\n' else ' ');i+=1
  elif string:
   if s[i]=='\\':out+=[' ',' '];i+=2
   elif s[i]=='"':string=False;out.append(' ');i+=1
   else:out.append('\n' if s[i]=='\n' else ' ');i+=1
  elif s.startswith('--',i):
   while i<len(s) and s[i]!='\n':out.append(' ');i+=1
  elif s.startswith('/-',i):depth=1;out+=[' ',' '];i+=2
  elif s[i]=='"':string=True;out.append(' ');i+=1
  else:out.append(s[i]);i+=1
 assert depth==0 and not string
 return ''.join(out)
rows=[]
for name,spec in mods.items():
 path=spec['path'];data=g('binding-source-'+name,'show',pins['H']+':'+path).stdout
 sha=hashlib.sha256(data).hexdigest();blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 assert sha==spec['sha256'] and blob==spec['git_blob']
 imports=[]
 for line in mask(data.decode()).splitlines():
  m=re.match(r'^\s*(?:public\s+|private\s+)?import\s+(.*)$',line)
  if m:imports.extend(m[1].split())
 assert imports==spec['imports'],(name,imports,spec['imports'])
 assert all(x in mods or x=='Std' for x in imports)
 expected={'mode':'100644','type':'blob','git_blob':blob}
 assert all(trees[t].get(path)==expected for t in ['S','H','M','T174'])
 if name!='Agent1PeriodicNinesExtraStrip':assert all(trees[t].get(path)==expected for t in ['B','P','T172'])
 rows.append({'module':name,'path':path,'sha256':sha,'git_blob':blob,'imports':imports,'identities':{k:v.get(path) for k,v in trees.items()}})
visited=set()
def visit(n):
 if n=='Std' or n in visited:return
 visited.add(n)
 for d in mods[n]['imports']:visit(d)
for root in reg['projects']['agent1-periodic-nine-control']['roots']:visit(root)
assert visited==set(mods)
controls=[rp,'proofs/Agent1PeriodicQuotient.registry.json','proofs/verify_project__214bf7673efe116b.py','proofs/verify_project.py','proofs/SOURCE_MAP.json']
controls += [p for p in trees['H'] if p.startswith('proofs/contributions/agent-1/periodic-nine-control-20261017/') and p.endswith('.py')]
control_rows=[]
for i,path in enumerate(controls):
 data=g('binding-control-'+str(i),'show',pins['H']+':'+path).stdout
 identities={k:v.get(path) for k,v in trees.items()};expected=identities['H'];assert expected==identities['M']==identities['T174']
 if path==rp:assert identities['S']==expected
 if path in ['proofs/Agent1PeriodicQuotient.registry.json','proofs/verify_project__214bf7673efe116b.py','proofs/verify_project.py','proofs/SOURCE_MAP.json']:assert all(x==expected for x in identities.values())
 control_rows.append({'path':path,'sha256':hashlib.sha256(data).hexdigest(),'identities':identities})
v={'status':'PASS_EXACT_15_SOURCE_AND_CONTROL_BINDING','source_count':15,'inherited_14_already_identical_on_actual_main':True,'imports_and_exact_DFS_match_registry':True,'source_registry_unchanged_S_to_H':True,'stacked_test_merge_and_full_prospective_tree_preserve_all_selected_sources':True,'registry_git_blob':trees['H'][rp]['git_blob'],'registry_sha256':hashlib.sha256(raw).hexdigest(),'sources':rows,'controls':control_rows,'lean_run':False,'mathematical_or_build_evidence_requalification':'Handled separately; this result proves byte/import/registry binding only.'}
(OUT/'closure-binding.json').write_text(json.dumps(v,indent=2)+'\n')
print(json.dumps({k:v for k,v in v.items() if k not in ['sources','controls']},indent=2))
