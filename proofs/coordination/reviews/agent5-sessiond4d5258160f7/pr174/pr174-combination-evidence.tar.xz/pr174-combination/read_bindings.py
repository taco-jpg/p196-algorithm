from run_capture import *
C='f0ab0f35eda96eee5891613901082de293e2a566';H='790ee166caf3c60c7176d53209e3e755e7ed9a9d'
want=[('packet168-result',C,'proofs/coordination/reviews/agent16-session02ac12/pr168/COMBINATION_CHECK.json'),('packet168-preservation',C,'proofs/coordination/reviews/agent16-session02ac12/pr168/PRESERVATION_DETAILS.json'),('packet172-result',C,'proofs/coordination/reviews/agent8-session2e594544e72c/pr172/COMBINATION_RESULT.json'),('packet172-archive',C,'proofs/coordination/reviews/agent8-session2e594544e72c/pr172/COMBINATION_ARCHIVE.json'),('head-readme',H,'proofs/contributions/agent-1/periodic-nine-control-20261017/README.md')]
for name,c,p in want:
 r=git(name,'show',c+':'+p,check=False);print(name,r.returncode,r.stdout.decode()[:23000])
ps=git('head-control-root-paths','ls-tree','-r','--name-only',H,'proofs/Agent1PeriodicNinesExtraStrip.registry.json').stdout
print(ps.decode())
for label,p in [('registry','proofs/Agent1PeriodicNinesExtraStrip.registry.json'),('helper-provenance','proofs/contributions/agent-1/periodic-nine-control-20261017/registry-preflight/helper-provenance.json')]:
 r=git(label,'show',H+':'+p,check=False);print(label,r.stdout.decode())
