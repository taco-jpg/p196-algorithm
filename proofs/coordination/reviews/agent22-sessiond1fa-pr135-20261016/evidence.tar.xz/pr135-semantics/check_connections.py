#!/usr/bin/env python3
"""Bounded connection/history review; exact offline Git reads, no Lean/generator run."""
import ast
from collections import Counter
from datetime import datetime, timezone
import hashlib
import itertools
import json
import os
from pathlib import Path
import re
import subprocess
import time

OUT=Path(__file__).resolve().parent
REPO='/dev/shm/p196-agent22-d1fa86c3a213/repo'
H='786ea690d8221503ae93dc3f981b1b56749ff40f'
N='32d2b92ec79becfbb4d2aa2cf9bd42f8bbd5597e'
B='a38b83ec83b74ad046207c5848ec05d39a878cfb'
C='proofs/contributions/agent-104/prefix620-kernel-20261016/'
ENV=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
started=time.monotonic()
records={}
def sha(b):return hashlib.sha256(b).hexdigest()
def require(ok,message):
    if not ok:raise AssertionError(message)
def git(*args):return subprocess.check_output(['git','-C',REPO,*args],env=ENV)
p=subprocess.Popen(['git','-C',REPO,'cat-file','--batch'],env=ENV,stdin=subprocess.PIPE,stdout=subprocess.PIPE)
def read(path,ref=H):
    spec=ref+':'+path;p.stdin.write((spec+'\n').encode());p.stdin.flush()
    header=p.stdout.readline().decode().strip().split()
    require(len(header)==3 and header[1]=='blob',('missing blob',spec,header))
    oid,_,size=header;b=p.stdout.read(int(size));require(p.stdout.read(1)==b'\n','batch framing')
    require(hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()==oid,('Git blob identity',spec))
    records[spec]={'path':path,'ref':ref,'git_blob':oid,'sha256':sha(b),'bytes':len(b)}
    return b
def text(path,ref=H):return read(path,ref).decode()
concrete=json.loads((OUT/'CONCRETE_SOURCES.json').read_bytes())['modules']
deps=json.loads((OUT/'DEPENDENCIES.json').read_bytes())['dependencies']
incoming=json.loads((OUT/'INCOMING_LEAN_SCOPE.json').read_bytes())['sources']
for name,rec in (concrete|deps).items():
    raw=read(rec['path'],N)
    require(sha(raw)==rec['sha256'] and records[N+':'+rec['path']]['git_blob']==rec['git_blob'],('new head changed mathematical source',name))
    if name in deps:require(read(rec['path'],B)==raw,('new accepted base changed dependency',name))
require(git('rev-parse',N+'^').decode().strip()==H,'repair parent')
repair=git('diff','--name-status','--no-renames',H,N).decode().splitlines()
expected_repair=['M\t'+C+'README.md','A\t'+C+'corrections/agent22-verification-wording/CORRECTION.json','A\t'+C+'corrections/agent22-verification-wording/README-at-786ea690.md']
require(repair==expected_repair,('repair path scope',repair))
require(read(C+'README.md')==read(C+'corrections/agent22-verification-wording/README-at-786ea690.md',N),'original README preserved')

header="/- Agent #104 finite-list partition of the frozen 620 instance.\nAgent #124's original semantic checker and enumerations are unchanged. -/\n"
ns='\nnamespace Agent104.Prefix620\nopen Agent124.CodeCert Agent124.PrefixK Agent124.PrefixR\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\n\n'
def wrapper(imports,body):return header+''.join('import '+i+'\n' for i in imports)+ns+body+'\nend Agent104.Prefix620\n'
initial=['theorem initial_cover_short : initialShortWords = initial_block000 := by\n  rfl\n']
for a,b in itertools.product(range(10),repeat=2):
    initial.append(f'theorem initial_cover_{a}_{b} : initialSlice {a} {b} = initial_block{1+10*a+b:03d} := by\n  rfl\n')
require(text('proofs/Agent104Prefix620InitialCoverage.lean')==wrapper(['Agent104Prefix620DataCoverage','Agent104Prefix620DataInitialWords'],'\n'.join(initial)),'full initial coverage source')
short=[]
for n in (1,2):short.append(f'theorem short_cover_w{n} : symWords {n} = short_block{n-1:03d} := by\n  rfl\n')
for n,a in itertools.product(range(3,7),range(19)):
    short.append(f'theorem short_cover_w{n}_{a} : shortSlice {n} {(n+1)//2-1} {a} = short_block{2+19*(n-3)+a:03d} := by\n  rfl\n')
require(text('proofs/Agent104Prefix620ShortCoverage.lean')==wrapper(['Agent104Prefix620DataCoverage','Agent104Prefix620DataShortWords'],'\n'.join(short)),'full short coverage source')
ia=text('proofs/Agent104Prefix620InitialAll.lean')
sa=text('proofs/Agent104Prefix620ShortAll.lean')
require(re.findall(r'rw \[initial_cover_(\d+)_(\d+)\]\s+exact initial_ok(\d+)',ia)==[(str(a),str(b),f'{1+10*a+b:03d}') for a,b in itertools.product(range(10),repeat=2)],'all 100 initial assembly mappings')
require('apply initial_all_of_slices (initOKC ranks 11)' in ia and 'rw [initial_cover_short]\n    exact initial_ok000' in ia,'initial original domain and short part')
require(re.findall(r'rw \[short_cover_w(\d+)_(\d+)\]\s+exact short_ok(\d+)',sa)==[(str(n),str(a),f'{2+19*(n-3)+a:03d}') for n,a in itertools.product(range(3,7),range(19))],'all 76 short assembly mappings')
require(re.findall(r'apply short_all_of_slices \(shortOKC ranks\) (\d+) (\d+) \(by decide \+kernel\)',sa)==[(str(n),str((n+1)//2-1)) for n in range(3,7)],'short half-width proof instantiations')
require(re.findall(r'rw \[short_cover_w(\d+)\]\s+exact short_ok(\d+)',sa)==[('1','000'),('2','001')],'two direct short widths')
require('theorem short_w0 : (symWords 0).all (shortOKC ranks) = true := by\n  decide +kernel' in sa,'width zero handled')
require(re.findall(r'  · exact short_w(\d+)',sa)==[str(i) for i in range(7)],'all seven short width alternatives')
require(re.findall(r'^import (.+)$',ia,re.M)==['Agent104Prefix620InitialCoverage']+[f'Agent104Prefix620Initial{i:03d}' for i in range(101)],'initial exact imports')
require(re.findall(r'^import (.+)$',sa,re.M)==['Agent104Prefix620ShortCoverage']+[f'Agent104Prefix620Short{i:03d}' for i in range(78)],'short exact imports')

cert=json.loads(read(C+'generator/inputs/certificate_620.json'))
rank_codes={19**len(r['word'])+sum(d*19**(len(r['word'])-1-i) for i,d in enumerate(r['word'])):r['rank'] for r in cert['nodes']}
initial_expected=[];short_expected=[]
for n in range(3,8):
    for tail in itertools.product(range(10),repeat=n-3):
        w=(6,2,0)+tail
        if n==7 or (w==w[::-1] and (n%2==0 or w[n//2]%2==0)):initial_expected.append(list(w))
for n in range(7):
    for half in itertools.product(range(19),repeat=(n+1)//2):
        w=[half[min(i,n-1-i)] for i in range(n)]
        if w and w[0]>0 and (n%2==0 or w[n//2]%2==0):short_expected.append(w)

# Literal-only parsing; full expressions must use exactly this constructor grammar.
def tree_pairs(expr):
    toks=[];end=0
    for m in re.finditer(r'\s*(\.node|\.empty|leaf\d+|\d+|\(|\))',expr):
        require(m.start()==end,('unexpected tree token',expr[end:m.start()]));toks.append(m[1]);end=m.end()
    require(not expr[end:].strip(),'unparsed tree suffix')
    index=0;pairs=[];leaves=[]
    def item():
        nonlocal index
        t=toks[index];index+=1
        if t=='(':
            item();require(toks[index]==')','tree parenthesis');index+=1
        elif t=='.node':
            c,r=int(toks[index]),int(toks[index+1]);index+=2;pairs.append((c,r));item();item()
        elif t=='.empty':pass
        else:require(re.fullmatch(r'leaf\d+',t),'tree reference');leaves.append(t)
    item();require(index==len(toks),'unconsumed tree expression')
    return pairs,leaves

historical=[];seen=set();numeric_pairs=0;literal_trees=0;literal_lists=0;word_occurrences=0;row_claims=0;history_hash_paths=0
for rec in incoming:
    if rec['category']=='active_concrete':continue
    raw=read(rec['path']);require(sha(raw)==rec['sha256'],'historical identity changed')
    m=re.search(r'/generator/development/([0-9a-f]{64})/',rec['path'])
    if m:require(m[1]==sha(raw),('preservation hash path',rec['path']));history_hash_paths+=1
    if rec['sha256'] in seen:continue
    seen.add(rec['sha256']);source=raw.decode();record={'path':rec['path'],'sha256':rec['sha256'],'bytes':len(raw),'code_tree_definitions':0,'code_rank_literals':0,'row_claims':0,'full_literal_word_domain':None}
    for symbol,expr in re.findall(r'^(?:noncomputable )?def (\w+) : CodeTree := (.+)$',source,re.M):
        pairs,leaves=tree_pairs(expr)
        require(all(rank_codes.get(c)==r for c,r in pairs),('historical code/rank differs from original certificate',rec['path'],symbol))
        record['code_tree_definitions']+=1;record['code_rank_literals']+=len(pairs)
        literal_trees+=1;numeric_pairs+=len(pairs)
    for c,r in re.findall(r'rowOK ranks 7 (\d+) (\d+) = true',source):
        require(rank_codes.get(int(c))==int(r),('historical internal row wrong',rec['path'],c,r))
        row_claims+=1;record['row_claims']+=1
    lists={}
    for match in re.finditer(r'^(?:noncomputable )?def ((?:initial|short)_block\d+) : List \(List Nat\) := ',source,re.M):
        start=match.end()
        while source[start].isspace():start+=1
        require(source[start]=='[','literal list start')
        depth=0;end=start
        while end<len(source):
            if source[end]=='[':depth+=1
            elif source[end]==']':
                depth-=1
                if depth==0:break
            end+=1
        require(depth==0,'unterminated literal list')
        lists[match[1]]=ast.literal_eval(source[start:end+1])
    if lists:
        values=[w for block in lists.values() for w in block]
        kind='initial' if next(iter(lists)).startswith('initial') else 'short'
        require(values==(initial_expected if kind=='initial' else short_expected),('historical full word-domain mismatch',rec['path']))
        record['full_literal_word_domain']={'kind':kind,'blocks':len(lists),'words':len(values)}
        literal_lists+=len(lists);word_occurrences+=len(values)
    historical.append(record)
# Independently read the retired generator and the development coverage runner.
for path in [C+'development/check_coverage.py',C+'generator/development/8b4de433710d8a2e38d8b47cdf26859aead57d77751c08f4cff278269914efed/generate_frozen620.py']:
    raw=read(path)
    m=re.search(r'/development/([0-9a-f]{64})/',path)
    if m:require(m[1]==sha(raw),'retired generator hash path')
p.stdin.close();require(p.wait()==0,'offline Git reader exit')
result={'status':'PASS_CONNECTIONS_HISTORY_AND_UPDATED_HEAD_BINDING','source_head':H,'updated_head':N,'accepted_base_checked':B,'executed_at_utc':datetime.now(timezone.utc).isoformat(),'script_sha256':sha(Path(__file__).read_bytes()),'active_concrete_unchanged':510,'generic_dependencies_unchanged':13,'generic_dependencies_equal_new_base':True,'repair_paths':repair,'original_readme_preserved':True,'full_initial_coverage_declarations':101,'full_short_coverage_declarations':78,'initial_assembly_slice_mappings':100,'short_assembly_slice_mappings':76,'short_direct_widths':[1,2],'short_width_zero_covered':True,'historical_lean_paths_read':len(incoming)-510,'historical_distinct_lean_blobs':len(seen),'content_addressed_historical_lean_paths_checked':history_hash_paths,'historical_literal_tree_definitions_parsed':literal_trees,'historical_code_rank_literals_match_original':numeric_pairs,'historical_concrete_internal_row_claims_match_original':row_claims,'historical_literal_word_blocks_parsed':literal_lists,'historical_word_occurrences_match_full_original_domains':word_occurrences,'historical_diagnostic_limit':'Data identities are checked; preserved failed or superseded modules are outside the accepted endpoint import closure and are not newly compiled or certified here.','lean_executed':False,'author_generator_executed':False,'elapsed_seconds':round(time.monotonic()-started,3)}
for name,value in [('CONNECTIONS_HISTORY_CHECK.json',result),('HISTORICAL_STRUCTURAL_SCOPE.json',historical),('FINAL_BINDING_READ_OBJECTS.json',list(records.values()))]:
    (OUT/name).write_text(json.dumps(value,indent=2)+'\n')
print(json.dumps(result,indent=2))
