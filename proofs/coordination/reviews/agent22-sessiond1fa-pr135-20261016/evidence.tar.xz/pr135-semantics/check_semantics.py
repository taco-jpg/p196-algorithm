#!/usr/bin/env python3
"""Agent #22 nonauthor PR135 bounded source and certificate review.

Reads exact Git objects offline without checkout, ref or index changes. Reuses
only inspected arithmetic/parser functions from the retained nonauthor semantic
review, not the author generator. These diagnostics are not Lean execution.
"""
from __future__ import annotations
import ast
from collections import Counter, defaultdict
from datetime import datetime, timezone
import hashlib
import itertools
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import time
import types

REPO = Path('/dev/shm/p196-agent22-d1fa86c3a213/repo')
OUT = Path(__file__).resolve().parent
HEAD = '786ea690d8221503ae93dc3f981b1b56749ff40f'
BASE = 'ae8bbdfd2a18e8910eebc25fd2a81661c01abc16'
FREEZE = 'dc2123ae4a4513acfe75e0a6cd21c3b6a044bec4'
OBSERVED_BASE = 'cc3de9834bef628d1083ce637641f07ed3953b13'
CONTRIB = 'proofs/contributions/agent-104/prefix620-kernel-20261016/'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
MANIFEST_SHA = 'd2b92c7139f59fe1cb8268addd0d10073780275f06b109bc3cf72933f9170c03'
CERT_SHA = 'e6c447fa7efa26e94d1a8064a9336922d3eeb2e1e55176f8043e1cd9dbe3cea5'
HELPER_SHA = 'd8d672edcda4b39d14247927ee7c7eef221e1da71bee68a0bb67f233006115f5'
started = time.monotonic()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def require(ok, message):
    if not ok:
        raise AssertionError(message)

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], env=ENV)

class Objects:
    def __init__(self):
        self.p = subprocess.Popen(['git', '-C', str(REPO), 'cat-file', '--batch'],
                                  env=ENV, stdin=subprocess.PIPE, stdout=subprocess.PIPE)
        self.cache = {}
        self.records = {}
    def read(self, path, ref=HEAD):
        spec = ref + ':' + path
        self.p.stdin.write((spec + '\n').encode()); self.p.stdin.flush()
        header = self.p.stdout.readline().decode().strip().split()
        require(len(header) == 3 and header[1] == 'blob', ('missing/nonblob', spec, header))
        oid, _, size = header
        data = self.p.stdout.read(int(size))
        require(len(data) == int(size) and self.p.stdout.read(1) == b'\n', ('batch truncation', spec))
        actual = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        require(actual == oid, ('blob identity', spec))
        self.records[spec] = {'path': path, 'ref': ref, 'git_blob': oid, 'sha256': sha(data), 'bytes': len(data)}
        self.cache[spec] = data
        return data
    def record(self, path, ref=HEAD):
        return self.records[ref + ':' + path]
    def close(self):
        self.p.stdin.close(); require(self.p.wait() == 0, 'cat-file status')

obj = Objects()
def read(path, ref=HEAD): return obj.read(path, ref)
def text(path, ref=HEAD): return read(path, ref).decode()
def js(path, ref=HEAD): return json.loads(read(path, ref))

scope = json.loads(Path('/dev/shm/p196-agent22-d1fa86c3a213/root-evidence/initial-source-scope.json').read_bytes())
changes = scope['changed_paths']
actual_diff = git('diff', '--name-status', '--no-renames', BASE, HEAD).decode().splitlines()
require(actual_diff == [r['change'] + '\t' + r['path'] for r in changes], 'complete exact diff inventory')
require(len(changes) == 2703 and all(r['change'] == 'A' and r['mode'] == '100644' for r in changes), 'add-only regular-file scope')
require(git('merge-base', BASE, HEAD).decode().strip() == BASE, 'merge base ancestor')
for ref in (HEAD, OBSERVED_BASE):
    read('AGENTS.md', ref)
require(obj.record('AGENTS.md', HEAD)['sha256'] == obj.record('AGENTS.md', OBSERVED_BASE)['sha256'], 'policy identity')
manifest_raw = read(CONTRIB + 'generator/GENERATION_MANIFEST.json')
require(sha(manifest_raw) == MANIFEST_SHA, 'frozen generated manifest')
manifest = json.loads(manifest_raw)
deps = js(CONTRIB + 'verification/author-base/dependency-map.json')
review_deps = js(CONTRIB + 'review/source-pins.json')
require(len(manifest['sources']) == len(manifest['build_order']) == len(set(manifest['build_order'])) == 510, 'module counts')
require(set(manifest['sources']) == set(manifest['build_order']), 'build/source module domain')
require(len(deps['modules']) == 13 and set(deps['modules']) == set(review_deps['modules']), 'generic dependency domain')
active_paths = {'proofs/' + n + '.lean' for n in manifest['sources']}
flat_paths = {r['path'] for r in changes if re.fullmatch(r'proofs/Agent104Prefix620\w*\.lean', r['path'])}
require(active_paths == flat_paths, 'all incoming flat Lean covered by manifest')
sources = {}
source_records = {}
for name, record in manifest['sources'].items():
    path = 'proofs/' + name + '.lean'
    raw = read(path)
    require(sha(raw) == record['sha256'] and len(raw) == record['bytes'], ('concrete source pin', name))
    require(read(path, FREEZE) == raw, ('concrete differs from mathematical freeze', name))
    sources[name] = raw.decode()
    source_records[name] = obj.record(path)
for name, record in deps['modules'].items():
    path = record['source_path']
    raw = read(path)
    require(sha(raw) == record['sha256'] and len(raw) == record['bytes'] and
            obj.record(path)['git_blob'] == record['git_blob'], ('generic source pin', name))
    require(read(path, BASE) == raw and read(path, OBSERVED_BASE) == raw, ('generic changed from accepted source', name))
    other = review_deps['modules'][name]
    require(other['path'] == path and other['sha256'] == sha(raw), ('retained review dependency pin', name))
    sources[name] = raw.decode()
    source_records[name] = obj.record(path)
require(sha(sources['Agent104Prefix620DataCoverage'].encode()) == HELPER_SHA, 'reviewed coverage helper')
order = deps['build_order'] + manifest['build_order']
seen = {'Std'}
imports = {}
for name in order:
    imp = re.findall(r'^import ([A-Za-z0-9_.]+)\s*$', sources[name], re.M)
    require(set(imp) <= seen, ('undeclared/non-topological import', name, sorted(set(imp) - seen)))
    imports[name] = imp
    seen.add(name)
reachable = set()
def visit(name):
    if name == 'Std' or name in reachable: return
    reachable.add(name)
    for i in imports[name]: visit(i)
visit('Agent104Prefix620')
require(reachable == set(sources), ('endpoint closure coverage', set(sources) - reachable))

upstream = js(CONTRIB + 'generator/UPSTREAM_PINS.json')
for name, rec in upstream.items():
    preserved = read(CONTRIB + 'generator/' + rec['retained_path'])
    original = read(rec['source_path'])
    require(original == preserved and sha(preserved) == rec['sha256'] and len(preserved) == rec['bytes'], ('upstream exact input', name))
    require(obj.record(rec['source_path'])['git_blob'] == rec['git_blob_sha1'], ('upstream blob', name))
certificate_raw = read(CONTRIB + 'generator/inputs/certificate_620.json')
require(sha(certificate_raw) == CERT_SHA, 'certificate identity')
certificate = json.loads(certificate_raw)
require((certificate['schema'], certificate['width'], certificate['prefix'], certificate['palindrome_height_bound']) == (1, 7, '620', 12), 'certificate advertised scope')
ranks = {tuple(r['word']): r['rank'] for r in certificate['nodes']}
require(len(ranks) == len(certificate['nodes']) == 59189, 'unique rank nodes')
require(all(type(r) is int and r >= 0 for r in ranks.values()), 'natural ranks')
require(all(0 < w[0] and len(w) in (5,6,7) and all(type(d) is int and 0 <= d < 19 for d in w) for w in ranks), 'coefficient/width domain')

# Reuse inspected, nonauthor controls only as finite functions. Their main
# entry points are not invoked; no checked-in files, subprocesses or outputs
# are mutated by this execution.
controls = {}
for filename in ('independent_control.py', 'independent_slice_control.py', 'independent_final_connection.py'):
    path = CONTRIB + 'review/' + filename
    raw = read(path)
    module = types.ModuleType('retained_' + filename[:-3])
    module.__file__ = 'git:' + HEAD + ':' + path
    exec(compile(raw, module.__file__, 'exec'), module.__dict__)
    controls[filename] = module
retained_control = js(CONTRIB + 'review/independent_control.json')
retained_slice = js(CONTRIB + 'review/independent_slice_control.json')
retained_connection = js(CONTRIB + 'review/independent_final_connection.json')
for filename, report, key in [
    ('independent_control.py', retained_control, 'control_script_sha256'),
    ('independent_slice_control.py', retained_slice, 'script_sha256'),
    ('independent_final_connection.py', retained_connection, 'script_sha256')]:
    require(obj.record(CONTRIB + 'review/' + filename)['sha256'] == report[key], ('retained control script changed', filename))
require(retained_control['certificate_sha256'] == CERT_SHA and
        retained_slice['manifest_sha256'] == retained_connection['manifest_sha256'] == MANIFEST_SHA and
        retained_connection['published_commit'] == FREEZE, 'retained control exact scope')
for path, rec in retained_connection['published_source_links'].items():
    raw = read(path)
    require(sha(raw) == rec['sha256'] and len(raw) == rec['bytes'] and obj.record(path)['git_blob'] == rec['git_blob'], ('retained published source connection', path))
require(len(retained_connection['published_source_links']) == 526, 'retained reviewed source closure')

# Independently enumerate both finite domains, then parse every Lean literal.
initial_expected = []
for n in range(3,8):
    for tail in itertools.product(range(10), repeat=n-3):
        w = (6,2,0) + tail
        if n == 7 or (w == w[::-1] and (n % 2 == 0 or w[n//2] % 2 == 0)):
            initial_expected.append(w)
require(len(initial_expected) == 10002 and set(initial_expected) == {tuple(w) for w in certificate['initial']}, 'original full initial domain')
parse_blocks = controls['independent_slice_control.py'].blocks
initials = parse_blocks(sources['Agent104Prefix620DataInitialWords'], 'initial')
shorts = parse_blocks(sources['Agent104Prefix620DataShortWords'], 'short')
require(list(initials) == list(range(101)) and list(shorts) == list(range(78)), 'finite block index domain')
require([tuple(w) for block in initials.values() for w in block] == initial_expected, 'all literal initial words/order')
require(initials[0] == [[6,2,0,2,6],[6,2,0,0,2,6]], 'short initial cases')
for a,b in itertools.product(range(10), repeat=2):
    require(initials[1+10*a+b] == [[6,2,0,a,b,c,d] for c,d in itertools.product(range(10),repeat=2)], ('initial slice',a,b))
short_words_by_width = {}
short_all = []
for n in range(7):
    words=[]
    for half in itertools.product(range(19), repeat=(n+1)//2):
        w=tuple(half[min(i,n-1-i)] for i in range(n))
        if w and w[0]>0 and (n%2==0 or w[n//2]%2==0): words.append(w)
    short_words_by_width[n]=len(words)
    if n in (1,2): require([tuple(w) for w in shorts[n-1]] == words, ('direct short width',n))
    elif n>=3:
        for a in range(19):
            index=2+19*(n-3)+a
            require([tuple(w) for w in shorts[index]] == [w for w in words if w[0]==a], ('short coefficient slice',n,a))
    short_all += words
require(short_words_by_width == {0:0,1:9,2:18,3:180,4:342,5:3420,6:6498}, 'all short boundary counts')
require(sum(map(len, shorts.values())) == len(short_all) == 10467, 'all short source words')
require([len(initials[i]) for i in range(101)] == manifest['finite_partition']['initial_block_sizes'], 'initial block manifest')
require([len(shorts[i]) for i in range(78)] == manifest['finite_partition']['short_block_sizes'], 'short block manifest')

# Check complete small checker modules, including exact imports and same tree.
finite_header = "/- Agent #104 finite-list partition of the frozen 620 instance.\nAgent #124's original semantic checker and enumerations are unchanged. -/\n"
finite_ns = '\nnamespace Agent104.Prefix620\nopen Agent124.CodeCert Agent124.PrefixK Agent124.PrefixR\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\n\n'
for kind, number, predicate in [('initial',101,'initOKC ranks 11'),('short',78,'shortOKC ranks')]:
    for i in range(number):
        name='Agent104Prefix620'+kind.title()+f'{i:03d}'
        expected = finite_header + 'import Agent104Prefix620DataTree\nimport Agent104Prefix620Data'+kind.title()+'Words\n'+finite_ns
        expected += f'theorem {kind}_ok{i:03d} : {kind}_block{i:03d}.all ({predicate}) = true := by\n  decide +kernel\n\nend Agent104.Prefix620\n'
        require(sources[name] == expected, ('full finite checker source contract',name))

Parser = controls['independent_final_connection.py'].LiteralParser
definitions={}
for name,source in sources.items():
    if re.fullmatch(r'Agent104Prefix620Data\d{3}',name) or name=='Agent104Prefix620DataTree':
        for symbol,literal in re.findall(r'^def (leaf\d{4}|ranks) : CodeTree := (.+)$',source,re.M):
            require(symbol not in definitions, ('duplicate code-tree definition',symbol))
            parser=Parser(literal); definitions[symbol]=parser.tree(); parser.done()
require(set(definitions)=={'ranks'}|{f'leaf{i:04d}' for i in range(256)}, 'complete literal definition domain')
leaf_uses=Counter(); ordered=[]
def walk(tree):
    if tree is None: return
    if isinstance(tree,str):
        leaf_uses[tree]+=1
        require(leaf_uses[tree]==1, ('duplicate/cyclic leaf reference',tree))
        walk(definitions[tree]);return
    c,r,l,rt=tree
    walk(l);ordered.append((c,r));walk(rt)
walk(definitions['ranks'])
expected_codes=sorted((19**len(w)+sum(d*19**(len(w)-1-i) for i,d in enumerate(w)),r) for w,r in ranks.items())
require(ordered==expected_codes and len(ordered)==59189, 'every literal code/rank equals original JSON')
require(all(ordered[i][0]<ordered[i+1][0] for i in range(len(ordered)-1)), 'unique sorted code keys')
require(leaf_uses==Counter({f'leaf{i:04d}':1 for i in range(256)}), 'all leaves exactly once')
rows=sources['Agent104Prefix620RowsAll']
proof_text=rows.split('theorem allRowsAll :',1)[1].split(':=',1)[1].split('theorem allRows :',1)[0].strip()
parser=Parser(proof_text,proof=True); proof=parser.proof(); parser.done()
branches={name:(int(c),int(r)) for name,c,r in re.findall(r'theorem (row_branch\d{4}) : rowOK ranks 7 (\d+) (\d+) = true := by\s+decide \+kernel', sources['Agent104Prefix620RowsBranch'])}
require(set(branches)=={f'row_branch{i:04d}' for i in range(255)}, 'every branch checker')
branch_uses=Counter(); proof_leaf_uses=Counter()
def match(tree,p):
    if isinstance(tree,str):
        require(p=='rows_'+tree, ('wrong proof leaf',tree,p));proof_leaf_uses[tree]+=1;return
    require(tree is not None and isinstance(p,tuple),'row proof tree shape')
    c,r,l,rt=tree;lp,b,rp=p
    require(branches[b]==(c,r), ('wrong internal row theorem',b))
    branch_uses[b]+=1;match(l,lp);match(rt,rp)
match(definitions['ranks'],proof)
require(proof_leaf_uses==leaf_uses and branch_uses==Counter({b:1 for b in branches}), 'complete same-tree long row assembly')
for i in range(256):
    name=f'Agent104Prefix620Rows{i:03d}'
    proposition=f'theorem rows_leaf{i:04d} : leaf{i:04d}.All (fun c r => rowOK ranks 7 c r = true) :=\n  allRowsC_sound (by decide +kernel)'
    require(proposition in sources[name] and imports[name]==['Agent104Prefix620DataTree'], ('leaf full checker contract',i))
require('theorem allRows : RowsClosed 7 (R ranks) := rowsClosed_of_all (by decide +kernel) allRowsAll' in rows,'long row original interface')

# Bounded replay of the retained nonauthor literal-column algorithm. No new
# discovery search or generated rank is used. All ranked rows are checked.
math=controls['independent_control.py']
short_inverse=defaultdict(set)
short_edges=[]
for w in short_all:
    target=math.exact_pair_step(w)
    short_inverse[target].add(w)
    if target in ranks:
        require(w in ranks and ranks[w]<ranks[target], ('short descent',w,target))
        short_edges.append({'source':list(w),'target':list(target),'source_rank':ranks[w],'target_rank':ranks[target]})
graph={}; long_graph={}; forward_checks=0
for target in ranks:
    pred=math.long_predecessors(target)
    long_graph[target]=pred
    graph[target]=pred|short_inverse.get(target,set())
    for source in pred:
        require(target in {math.forward_prefix(source,0),math.forward_prefix(source,1)}, ('forward control',source,target))
        forward_checks+=1
require(math.rank_failure(ranks,graph) is None,'finite complete predecessor descent')
for target,pred in graph.items():
    require(ranks[target]==(1+max(ranks[w] for w in pred) if pred else 0), ('exact rank',target))
require(sum(map(len,graph.values()))==71560 and forward_checks==71554 and len(short_edges)==6,'full finite edge totals')
require(sorted(short_edges,key=lambda x:(x['source'],x['target']))==retained_control['short_edges'],'retained short-edge identity')
current=set(initial_expected);reached=set();layers=[]
while current:
    layers.append(len(current));reached.update(current)
    current=set().union(*(graph[w] for w in current))
    require(len(layers)<=12,'bounded layer depth')
layers.append(0)
require(reached==set(ranks) and layers==certificate['layer_counts']==retained_control['layer_counts'],'complete backward reachable ranks')
require(max(ranks[w] for w in initial_expected)==max(ranks.values())==11,'original initial bound')

# Concrete ordinary-numeral witness mentioned in the README; no use in proof.
value=19014942070
witness=[]
for t in range(13):
    palindrome=str(value)==str(value)[::-1]
    witness.append({'t':t,'value':str(value),'palindrome':palindrome})
    if t<12:
        require(not palindrome,('README witness early palindrome',t))
        value += int(str(value)[::-1])
require(value==62003033030026 and witness[12]['palindrome'] and str(value).startswith('620'),'README witness at time 12')

# Inventory all incoming Lean bytes, separating replay snapshots and preserved
# development from active proof sources. Exact blob equality records duplicates.
lean_scope=[]
known_by_sha=defaultdict(list)
for name,record in source_records.items(): known_by_sha[record['sha256']].append(name)
for change in changes:
    path=change['path']
    if not path.endswith('.lean'): continue
    raw=read(path)
    require(obj.record(path)['git_blob']==change['sha'],('incoming source blob',path))
    if path in active_paths: category='active_concrete'
    elif '/verification/independent620/canonical/' in path: category='retained_canonical_replay_source'
    elif '/upstream-output-leaf256/' in path: category='untrusted_upstream_emitter_output'
    elif '/development/' in path or '/generator/evidence/' in path: category='preserved_development_or_stage_source'
    else: category='verification_helper'
    rec=dict(obj.record(path),category=category,byte_identical_active_or_generic=known_by_sha.get(sha(raw),[]))
    lean_scope.append(rec)

# Record a lexical screen only; full transitive axiom auditing is assigned to
# the separate evidence reviewer and is not inferred from this scan.
def uncomment(s):
    out=[];i=0;depth=0
    while i<len(s):
        if s.startswith('/-',i): depth+=1;i+=2;continue
        if depth and s.startswith('-/',i): depth-=1;i+=2;continue
        if depth: i+=1;continue
        if s.startswith('--',i):
            j=s.find('\n',i);i=len(s) if j<0 else j;continue
        out.append(s[i]);i+=1
    require(depth==0,'unterminated Lean block comment')
    return ''.join(out)
lexical=[]
for name,source in sources.items():
    matches=re.findall(r'\b(?:sorry|admit|sorryAx|native_decide|axiom)\b',uncomment(source))
    if matches: lexical.append({'module':name,'tokens':matches})
require(not lexical,'active/generic source forbidden-token diagnostic')

# Save only small own evidence manifests, not a repository/source copy.
report={
    'status':'PASS_BOUNDED_SOURCE_AND_MATHEMATICAL_DATA_REVIEW',
    'agent':'Agent #22', 'role':'nonauthor mathematical/source reviewer',
    'head':HEAD,'mathematical_freeze':FREEZE,'merge_base':BASE,'observed_target_base':OBSERVED_BASE,
    'executed_at_utc':datetime.now(timezone.utc).isoformat(),
    'script_sha256':sha(Path(__file__).read_bytes()),
    'incoming_files':len(changes),'incoming_all_additions':True,
    'incoming_extensions':dict(sorted(Counter(PurePosixPath(r['path']).suffix for r in changes).items())),
    'incoming_lean_files':len(lean_scope),'incoming_lean_categories':dict(Counter(r['category'] for r in lean_scope)),
    'incoming_lean_distinct_blobs':len({r['git_blob'] for r in lean_scope}),
    'concrete_modules':510,'generic_modules':13,'exact_endpoint_import_closure':len(reachable),
    'all_concrete_bytes_match_freeze':True,'all_generic_bytes_match_accepted_and_observed_bases':True,
    'generation_manifest_sha256':MANIFEST_SHA,'certificate_sha256':CERT_SHA,'coverage_helper_sha256':HELPER_SHA,
    'preserved_upstream_input_files_equal_originals':3,
    'retained_review_published_source_paths_matched':526,
    'fresh_finite_control':'Reviewed retained nonauthor arithmetic and strict literal-parser functions, executed from pinned Git source; no author generator and no Lean compiler invoked.',
    'nodes':len(ranks),'node_width_counts':dict(sorted(Counter(map(len,ranks)).items())),
    'rank_counts':dict(sorted(Counter(ranks.values()).items())),
    'initial_words':len(initial_expected),'initial_blocks':len(initials),'initial_max_rank':11,
    'short_words':len(short_all),'short_blocks':len(shorts),'short_width_counts':short_words_by_width,
    'short_empty_slices':[2,21,40,59],'short_edges':short_edges,
    'long_edges':forward_checks,'total_edges':sum(map(len,graph.values())),
    'all_rows_rank_descent':True,'all_nodes_backward_reachable':True,'layer_counts':layers,
    'code_tree_nodes':len(ordered),'unique_sorted_codes':True,'leaf_proofs':256,'internal_proofs':255,
    'same_tree_complete_long_assembly':True,'complete_finite_checker_module_bytes_checked':179,
    'lexical_source_screen':'PASS; not a transitive axiom audit',
    'lean_executed':False,'full_axiom_audit':'Separate evidence reviewer responsibility',
    'readme_pr128_witness_arithmetic':witness,
    'elapsed_seconds':round(time.monotonic()-started,3)
}
(OUT/'SOURCE_DATA_CHECK.json').write_text(json.dumps(report,indent=2)+'\n')
(OUT/'DEPENDENCIES.json').write_text(json.dumps({'head':HEAD,'dependencies':{n:source_records[n] for n in deps['build_order']}},indent=2)+'\n')
(OUT/'CONCRETE_SOURCES.json').write_text(json.dumps({'head':HEAD,'modules':{n:source_records[n] for n in manifest['build_order']}},indent=2)+'\n')
(OUT/'INCOMING_LEAN_SCOPE.json').write_text(json.dumps({'head':HEAD,'sources':lean_scope},indent=2)+'\n')
(OUT/'READ_OBJECTS.json').write_text(json.dumps({'objects':list(obj.records.values())},indent=2)+'\n')
(OUT/'UNMATCHED_RETAINED_LEAN.json').write_text(json.dumps([r for r in lean_scope if not r['byte_identical_active_or_generic']],indent=2)+'\n')
obj.close()
print(json.dumps({k:report[k] for k in ['status','incoming_files','incoming_lean_files','incoming_lean_distinct_blobs','incoming_lean_categories','exact_endpoint_import_closure','nodes','initial_words','short_words','long_edges','total_edges','elapsed_seconds']},indent=2))
