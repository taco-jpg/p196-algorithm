#!/usr/bin/env python3
"""Read-only independent review checks for Agent #22's PR135 README repair."""
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
REPO = "/dev/shm/p196-agent22-d1fa86c3a213/repo"
OLD = "786ea690d8221503ae93dc3f981b1b56749ff40f"
NEW = "32d2b92ec79becfbb4d2aa2cf9bd42f8bbd5597e"
PREFIX = "proofs/contributions/agent-104/prefix620-kernel-20261016/"
ENV = {**os.environ, "GIT_NO_LAZY_FETCH": "1", "GIT_OPTIONAL_LOCKS": "0"}
EXPECTED = [
    ("M", PREFIX + "README.md"),
    ("A", PREFIX + "corrections/agent22-verification-wording/CORRECTION.json"),
    ("A", PREFIX + "corrections/agent22-verification-wording/README-at-786ea690.md"),
]
CHECKS = []
CACHE = {}

def git(*args):
    proc = subprocess.run(["git", "-C", REPO, *args], env=ENV,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if proc.returncode:
        raise RuntimeError({"git_argv": list(args), "exit_code": proc.returncode,
                            "stderr": proc.stderr.decode()})
    return proc.stdout

def read(ref, path):
    key = (ref, path)
    if key not in CACHE:
        CACHE[key] = git("show", ref + ":" + path)
    return CACHE[key]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(("blob " + str(len(data)) + "\0").encode() + data).hexdigest()

def check(name, actual, expected=True):
    CHECKS.append({"check": name, "pass": actual == expected,
                   "actual": actual, "expected": expected})
    return actual == expected

def obj(path, ref=NEW):
    return json.loads(read(ref, PREFIX + path))

receipt = obj("corrections/agent22-verification-wording/CORRECTION.json")
remote = json.loads((ROOT / "remote-evidence.json").read_text())
parents = git("rev-list", "--parents", "-n", "1", NEW).decode().strip().split()
check("repair has the exact sole parent", parents, [NEW, OLD])
trees = {ref: git("rev-parse", ref + "^{tree}").decode().strip() for ref in [OLD, NEW]}
changes = [tuple(line.split("\t")) for line in git(
    "diff-tree", "--no-commit-id", "-r", "--name-status", "--no-renames", OLD, NEW
).decode().splitlines()]
check("entire repair changed paths and statuses", changes, EXPECTED)
check("git diff --check has no findings", git("diff", "--check", OLD, NEW), b"")
check("receipt source head", receipt["source_head"], OLD)
check("receipt eleven source pins", len(receipt["evidence_sources"]), 11)
check("receipt disclaims new Lean run", receipt["factual_basis"]["fresh_lean_by_agent22"], "NOT_RUN")
old = read(OLD, PREFIX + "README.md")
new = read(NEW, PREFIX + "README.md")
original = receipt["original_readme"]
preserved = read(NEW, original["preserved_at"])
check("preserved original is byte-identical", preserved == old)
check("original README Git blob", blob(old), "db7f68cc0c4575fb6b6219806cd777e73c84e88f")
check("original README SHA256", sha(old), "c05c43508e33e93fbd820aa9b0aa92ed83ffd7a41cf8831c2cc4d59b5c70421f")
check("original README byte length", len(old), 6755)
for key, actual in [("source_head", OLD), ("git_blob", blob(old)), ("sha256", sha(old)), ("bytes", len(old))]:
    check("receipt original README " + key, original[key], actual)
check("corrected README SHA256", sha(new), "0f5f3eecd9c6d26f67fee7c400e9dc9180dc73f7ad81e0f2364a0583760f5dd7")
check("receipt corrected README SHA256", receipt["corrected_readme_sha256"], sha(new))
check("original scope and attribution preamble unchanged",
      old.split(b"## Verification status")[0] == new.split(b"## Verification status")[0])
check("all text from root theorem axioms onward unchanged",
      old.split(b"The root predicate-fidelity theorem")[1] ==
      new.split(b"The root predicate-fidelity theorem")[1])
for published in remote["published_file_readbacks"]:
    check("published blob agrees with local exact repair: " + published["path"],
          blob(read(NEW, published["path"])), published["git_blob"])
pins = []
for entry in receipt["evidence_sources"]:
    data = read(OLD, entry["path"])
    outcome = {"path": entry["path"], "source_head": entry["source_head"],
               "git_blob": blob(data), "sha256": sha(data), "bytes": len(data),
               "same_in_repaired_tree": data == read(NEW, entry["path"])}
    expected = {"path": entry["path"], "source_head": OLD,
                "git_blob": entry["git_blob"], "sha256": entry["sha256"],
                "bytes": entry["bytes"], "same_in_repaired_tree": True}
    check("receipt pin identity: " + entry["path"], outcome, expected)
    pins.append(outcome)
generic = obj("verification/author-base/build.json")
generic_commands = generic["commands"][2:15]
check("generic module command count", len(generic_commands), 13)
check("generic report identifies runtime_scout", generic["specialist"], "runtime_scout")
check("generic report status", generic["status"], "PASS_GENERIC_DEPENDENCIES_ONLY")
check("generic exact build order", [r["argv"][-1].removesuffix(".lean") for r in generic_commands], generic["build_order"])
generic_argv_failures = []
for index, command in enumerate(generic_commands, 2):
    name = generic["build_order"][index - 2]
    expected_argv = [command["argv"][0], "-j1", "-DElab.async=false", "-o",
                     name + ".olean", name + ".lean"]
    if command["argv"] != expected_argv or command["exit_code"] != 0:
        generic_argv_failures.append({"index": index, "record": command})
check("all thirteen generic commands omit trust override and exit zero", generic_argv_failures, [])
generic_logs = []
for c in generic["commands"]:
    if sha(read(NEW, PREFIX + "verification/author-base/" + c["log"])) != c["log_sha256"]:
        generic_logs.append(c["label"])
check("all sixteen generic retained command logs match hashes", generic_logs, [])
driver = read(NEW, PREFIX + "verification/author-base/build_base.py").decode()
check("generic driver constructs default-trust module argv",
      '[str(lean), "-j1", "-DElab.async=false", "-o", name + ".olean", name + ".lean"]' in driver)
stages = {}
for e in receipt["evidence_sources"]:
    if "/generator/evidence/" in e["path"] and e["path"].endswith("/verification.json"):
        stages[e["path"].split("/evidence/")[1].split("/")[0]] = json.loads(read(NEW, e["path"]))
stage_summary = []
stage_command_bad = []
stage_log_bad = []
for name, report in stages.items():
    expected_jobs = 1 if name == "all-001" else 2
    check("stage process limit " + name, report["jobs"], expected_jobs)
    counts = collections.Counter(str(c["exit_code"]) for c in report["commands"])
    stage_summary.append({"stage": name, "status": report["status"], "jobs": report["jobs"],
                          "commands": len(report["commands"]), "exit_code_counts": dict(counts),
                          "max_rss_kib_this_stage": report["max_rss_kib_this_stage"]})
    for c in report["commands"]:
        expected = [c["command"][0], "-j1", "-DElab.async=false", "--trust=0",
                    "-o", c["module"] + ".olean", c["module"] + ".lean"]
        if c["command"] != expected:
            stage_command_bad.append({"stage": name, "module": c["module"]})
        if sha(read(NEW, PREFIX + "generator/" + c["log"])) != c["log_sha256"]:
            stage_log_bad.append({"stage": name, "module": c["module"]})
check("all retained author-stage module commands use exact explicit-trust-zero argv", stage_command_bad, [])
check("all retained author-stage logs including failed attempts match", stage_log_bad, [])
final = stages["all-001"]
completion = obj("generator/AUTHOR_BUILD_COMPLETE.json")
manifest_bytes = read(NEW, PREFIX + "generator/GENERATION_MANIFEST.json")
manifest = json.loads(manifest_bytes)
success_bytes = read(NEW, PREFIX + "generator/evidence/successful-builds.json")
success = json.loads(success_bytes)
check("author completion points to exact successful-build index", sha(success_bytes), completion["successful_build_index"]["sha256"])
check("final report and author completion manifest", final["manifest_sha256"], sha(manifest_bytes))
check("completion manifest", completion["manifest_sha256"], sha(manifest_bytes))
check("exact successful manifest module set", sorted(success), sorted(manifest["build_order"]))
check("successful concrete module count", len(success), 510)
check("final selected manifest module set", sorted(final["selected"]), sorted(success))
check("final new command count", len(final["commands"]), 431)
check("final reused count", len(final["reused_concrete_objects"]), 79)
new_modules = {c["module"] for c in final["commands"]}
reused_modules = set(final["reused_concrete_objects"])
check("final compiled and reused sets form exact disjoint coverage",
      len(new_modules) == 431 and len(reused_modules) == 79 and
      not (new_modules & reused_modules) and new_modules | reused_modules == set(success))
check("final wall time", final["wall_seconds"], 1077.408)
check("final maximum recorded process RSS", final["max_rss_kib_this_stage"], 3335928)
check("final process RSS computed from retained commands",
      max(c["max_rss_kib"] for c in final["commands"]), 3335928)
check("all final-stage commands exited zero", all(c["exit_code"] == 0 for c in final["commands"]))
source_bad = []
success_bad = []
record_link_bad = []
import_bad = []
import_count = 0
for module, record in success.items():
    data = read(NEW, "proofs/" + module + ".lean")
    if (sha(data) != manifest["sources"][module]["sha256"] or
        len(data) != manifest["sources"][module]["bytes"] or
        sha(data) != record["source_sha256"]):
        source_bad.append(module)
    if record["exit_code"] != 0 or record["command"][1:] != [
        "-j1", "-DElab.async=false", "--trust=0", "-o", module + ".olean", module + ".lean"]:
        success_bad.append(module)
    matching = [(stage, c) for stage, r in stages.items() for c in r["commands"]
                if c["module"] == module and c == record]
    if not matching:
        record_link_bad.append(module)
    for dep, digest in record.get("import_object_sha256", {}).items():
        import_count += 1
        expected = success[dep]["object_sha256"] if dep in success else generic["outputs"][dep]["olean_sha256"]
        if digest != expected:
            import_bad.append({"module": module, "dependency": dep})
check("all 510 successful records match current published manifest/source bytes", source_bad, [])
check("all 510 successful commands explicitly use trust zero and exit zero", success_bad, [])
check("all 510 records exactly link to one retained stage command", record_link_bad, [])
check("recorded import-object digests remain consistent", import_bad, [])
check("recorded import-object digest count", import_count, 1057)
for k, v in final["dependency_objects"].items():
    check("generic object link into concrete stage: " + k, v, generic["outputs"][k]["olean_sha256"])
for k, v in final["dependency_sources"].items():
    check("generic source link into concrete stage: " + k, v, generic["outputs"][k]["source_sha256"])
canonical_bytes = read(NEW, PREFIX + "verification/independent620/canonical/verification.json")
canonical = json.loads(canonical_bytes)
project = canonical["projects"]["agent104-prefix620-kernel"]
check("unchanged canonical report identity", sha(canonical_bytes), "52992057d5f3051a6db6413ed724375e06f903ef8ea78a145ef23693f2edba30")
check("canonical compiled source count", len(project["sources"]), 523)
check("canonical command count", len(project["commands"]), 524)
check("all canonical commands use per-command settings and omit trust override",
      all(c["argv"][1:3] == ["-j1", "-DElab.async=false"] and
          not any(a.startswith(("--trust", "-t")) for a in c["argv"][1:]) and
          c["exit_code"] == 0 for c in project["commands"]))
claim = json.loads(remote["repair_claim"]["content"])
check("exact claim blob from connector", blob(remote["repair_claim"]["content"].encode()),
      remote["repair_claim"]["git_blob"])
check("receipt pins exact accepted scoped claim", receipt["repair_claim"], remote["repair_claim"]["commit"])
check("scoped claim old head", claim["repair_scope"]["source_head"], OLD)
check("scoped claim owner", claim["owner"], "Agent #22")
check("scoped claim paths cover exactly this correction",
      claim["repair_scope"]["paths"],
      [PREFIX + "README.md", PREFIX + "corrections/agent22-verification-wording/"])
check("source attribution retained", b"Agent #104, 2026-10-16." in new)
summary = {
    "status": "PASS" if all(c["pass"] for c in CHECKS) else "FAIL",
    "reviewer": "Genuine nonauthor subagent /root/pr135_repair_review, delegated by Agent #22",
    "scope": "Independent review of documentation repair only; not full PR135 mathematical acceptance",
    "source_head": OLD, "repair_head": NEW, "trees": trees,
    "recorded_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "read_only_execution": {"git_no_lazy_fetch": True, "git_optional_locks": False,
        "source_mutations": False, "lean_executions": 0, "new_builds": 0,
        "local_check_command": "GIT_NO_LAZY_FETCH=1 python3 " + str(ROOT / "checks.py")},
    "observed_remote_reads": remote,
    "source_pin_checks": pins, "stage_command_summary": stage_summary,
    "source_and_log_checks": {"generic_module_commands": 13, "generic_all_logs": len(generic["commands"]),
        "author_stage_command_records": sum(len(r["commands"]) for r in stages.values()),
        "distinct_successful_concrete_sources": len(success), "final_new": len(new_modules),
        "final_reused": len(reused_modules), "recorded_import_object_digests": import_count,
        "canonical_sources": len(project["sources"]), "canonical_commands": len(project["commands"])},
    "checks": CHECKS,
}
# Bytes appear only as empty stdout in the diff-whitespace check.
for c in summary["checks"]:
    for key in ("actual", "expected"):
        if isinstance(c[key], bytes):
            c[key] = c[key].decode()
(ROOT / "checks.json").write_text(json.dumps(summary, indent=2) + "\n")
print(json.dumps({k: summary[k] for k in [
    "status", "source_head", "repair_head", "trees", "source_and_log_checks",
    "stage_command_summary"]}, indent=2))
print("CHECKS", len(CHECKS), "FAILED", sum(not c["pass"] for c in CHECKS))
for check_result in CHECKS:
    if not check_result["pass"]:
        print("FAIL", json.dumps(check_result))
sys.exit(0 if summary["status"] == "PASS" else 1)
