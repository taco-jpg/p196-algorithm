#!/usr/bin/env python3
"""Bind Agent #22's retained-evidence audit to PR135's documentation repair.

Read-only Git and file checks. No Lean process, generator, network request,
repository mutation, or merge is performed.
"""
import argparse
import datetime
import hashlib
import json
from pathlib import Path
import traceback
from check_retained_evidence import GitReader, H, MATH, BASE, P, V, sha

NEW = '32d2b92ec79becfbb4d2aa2cf9bd42f8bbd5597e'
README = P+'README.md'
CORRECTIONS = P+'corrections/agent22-verification-wording/'
OLD_README = CORRECTIONS+'README-at-786ea690.md'
RECEIPT = CORRECTIONS+'CORRECTION.json'


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,required=True)
    ap.add_argument('--prior-report',type=Path,required=True)
    ap.add_argument('--report',type=Path,required=True)
    args=ap.parse_args()
    report={'schema_version':1,'agent':'Agent #22','specialist':'pr135_evidence',
            'source_head':NEW,'previous_source_head':H,'mathematical_source_commit':MATH,
            'generic_source_commit':BASE,'scope':'Retained proof-evidence reuse and exact documentation-repair binding',
            'new_lean_invocations':0,'checks':[],'timestamp_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
    rd=GitReader(args.repo)
    def check(name,condition,details=None):
        report['checks'].append({'name':name,'status':'PASS' if condition else 'FAIL','details':details})
    try:
        prior_bytes=args.prior_report.read_bytes();prior=json.loads(prior_bytes)
        check('prior_exact_source_audit_pass',prior['source_head']==H and prior['evidence_reuse_verdict']=='PASS' and
              len(prior['checks'])==42 and all(c['status']=='PASS' for c in prior['checks']) and prior['new_lean_invocations']==0)
        report['original_full_evidence_audit']={'path':str(args.prior_report),'sha256':sha(prior_bytes),
            'check_script_sha256':prior['check_script_sha256'],'checks':42,'result':prior['status']}
        commit=rd.obj(NEW).decode();parents=[x[7:] for x in commit.splitlines() if x.startswith('parent ')]
        check('repair_direct_parent_is_reviewed_head',parents==[H],{'parents':parents})
        oldtree,newtree=rd.tree(H),rd.tree(NEW)
        delta={p:('ADD' if p not in oldtree else 'DELETE' if p not in newtree else 'MODIFY')
               for p in set(oldtree)|set(newtree) if oldtree.get(p)!=newtree.get(p)}
        expected={README:'MODIFY',OLD_README:'ADD',RECEIPT:'ADD'}
        check('exact_three_path_documentation_delta',delta==expected,delta)
        original=rd.read(README,H);corrected=rd.read(README,NEW);receipt=rd.js(RECEIPT,NEW)
        info=receipt['original_readme']
        check('original_readme_preserved_byte_for_byte',rd.read(OLD_README,NEW)==original and
              info['path']==README and info['source_head']==H and info['git_blob']==oldtree[README]['oid'] and
              info['sha256']==sha(original) and info['bytes']==len(original) and info['preserved_at']==OLD_README and
              receipt['corrected_readme_sha256']==sha(corrected),
              {'original_sha256':sha(original),'corrected_sha256':sha(corrected),'preserved_path':OLD_README})
        pin_errors=[]
        for rec in receipt['evidence_sources']:
            b=rd.read(rec['path'],H)
            if (rec['source_head']!=H or rec['git_blob']!=oldtree[rec['path']]['oid'] or rec['sha256']!=sha(b)
                    or rec['bytes']!=len(b) or rd.read(rec['path'],NEW)!=b):pin_errors.append(rec['path'])
        check('all_correction_evidence_pins_match_original_audit',not pin_errors,{'pins':len(receipt['evidence_sources']),'errors':pin_errors})
        unchanged=[p for p in oldtree if p!=README and newtree.get(p)!=oldtree[p]]
        source_errors=[]
        for module,rec in prior['selected_sources'].items():
            b=rd.read(rec['source_path'],NEW)
            if sha(b)!=rec['sha256'] or newtree[rec['source_path']]['oid']!=rec['git_blob']:source_errors.append(module)
        check('all_retained_proof_source_and_evidence_unchanged',not unchanged and not source_errors,
              {'all_previous_paths_except_readme_unchanged':len(oldtree)-1,'selected_sources_rebound':len(prior['selected_sources']),
               'source_errors':source_errors,'unexpected_changed_paths':unchanged})
        text=corrected.decode()
        facts=receipt['factual_basis']
        check('corrected_execution_attribution_matches_audited_records',
              'all 510 concrete modules actually compiled using\nofficial Lean 4.19.0 with explicit `--trust=0`' in text and
              'The 13 generic dependencies were\nseparately rebuilt by `runtime_scout` with the compiler\'s default trust=max' in text and
              'early author stages ran\nup to two concurrent processes, while the final stage ran one' in text and
              'compiled 431 new modules and reused 79' in text and
              facts['generic_modules']==13 and facts['concrete_modules']==510 and
              facts['early_stage_process_limit']==2 and facts['final_stage_process_limit']==1 and
              facts['final_stage_new_modules']==431 and facts['final_stage_reused_objects']==79,
              {'resolved_finding':'README_TRUST_AND_CONCURRENCY_LABEL','proof_rebuild_needed':False})
        report['evidence_reuse_verdict']='PASS' if all(c['status']=='PASS' for c in report['checks']) else 'GAPS'
        report['status']=report['evidence_reuse_verdict']
        report['remaining_evidence_gaps']=[] if report['status']=='PASS' else [c['name'] for c in report['checks'] if c['status']=='FAIL']
        report['review_boundary']='Mathematical semantics, platform gates, current-main combination, ownership and merge execution are handled by the named root delivery owner and other assigned independent reviewers.'
    except Exception:
        report['status']='AUDIT_EXECUTION_FAILED';report['evidence_reuse_verdict']='UNDETERMINED';report['exception']=traceback.format_exc()
    finally:
        report['check_script_sha256']=sha(Path(__file__).read_bytes())
        with args.report.open('x') as f:json.dump(report,f,indent=2);f.write('\n')
        rd.close()
    print(json.dumps(report,indent=2))
    return 0 if report['status']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
