#!/usr/bin/env python3
"""Agent #22: offline audit of PR135's retained execution and source provenance.

This program only reads Git objects and small local origin manifests. It does
not invoke Lean, execute repository programs, access the network, modify Git
state, or assert that it performed the retained builds. New reports use exclusive
creation so a failed audit remains available for investigation.
"""
from __future__ import annotations
import argparse
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import time
import traceback

H = '786ea690d8221503ae93dc3f981b1b56749ff40f'
MATH = 'dc2123ae4a4513acfe75e0a6cd21c3b6a044bec4'
BASE = 'ae8bbdfd2a18e8910eebc25fd2a81661c01abc16'
OLD = '2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5'
P = 'proofs/contributions/agent-104/prefix620-kernel-20261016/'
V = P + 'verification/independent620/'
G = P + 'generator/'
PROJECT = 'agent104-prefix620-kernel'
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}
ENDPOINTS = ['Agent104.Prefix620.palindromeStarts620_iff',
             'Agent104.Prefix620.ancestry_bound12',
             'Agent104.Prefix620.no_196_620_palindrome']
ARCHIVE_SHA = '6fe3ce97a58f44e2b3567d455b994eacec5bfe9ae7774f2a573444480ba813fe'
MEMBERS_SHA = 'd7485aac2bce75037c914c94f90bbd96d6f5bd272cfe99211730b3b02e02e012'
EXPECTED = {
    V+'canonical/verification.json': '52992057d5f3051a6db6413ed724375e06f903ef8ea78a145ef23693f2edba30',
    V+'canonical/'+PROJECT+'/logs/ProjectAudit.log': '8c59855ddc50189307e0da9d08d9b9f917ae30ec7bbf0c7e15db11f8c30b5ca6',
    V+'canonical/'+PROJECT+'/source/ProjectAudit.lean': '08db920c5f80724b9bc0b85f9f3fa2c474ac607f0b841b9803dff6672a1c53d5',
    V+'build.json': 'f044307147ccd1541aea7b0a537ca05347bf0100f5aafa50433332a7809a5a36',
    V+'REGISTRY.json': '509310b61aefbef5f4330eb0e8bbbc1f4d71a1728edaeeb5f147d48eb6a603a3',
    V+'source-snapshot.json': '09e0c610ba247e3e16995cd4ed4c4eddc815735a43a5c2e04cbae56834c75035',
    G+'GENERATION_MANIFEST.json': 'd2b92c7139f59fe1cb8268addd0d10073780275f06b109bc3cf72933f9170c03',
    P+'review/reviewer-freeze.json': '7613d167b298cb1420d1aef5810bdafc9a9ec92141b6bc07301c1f10ee5f370e',
    'proofs/Agent104Prefix620.lean': '9c4af5ff576c4184c1beb7fded6e1c0a33a815bfb1130793029815e66ab3e653',
}

def sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def mask_lean(s: str) -> str:
    """Mask comments and strings for a separately implemented import census."""
    result, i, level, quoted = [], 0, 0, False
    while i < len(s):
        a = s[i:i+2]
        if level:
            if a == '/-': level += 1; result.append('  '); i += 2
            elif a == '-/': level -= 1; result.append('  '); i += 2
            else: result.append('\n' if s[i]=='\n' else ' '); i += 1
        elif quoted:
            if s[i] == '\\': result.append('  '); i += 2
            else: quoted = s[i] != '"'; result.append('\n' if s[i]=='\n' else ' '); i += 1
        elif a == '/-': level=1; result.append('  '); i += 2
        elif a == '--':
            j=s.find('\n', i)
            if j<0: j=len(s)
            result.append(' '*(j-i)); i=j
        elif s[i]=='"': quoted=True; result.append(' '); i+=1
        else: result.append(s[i]); i+=1
    if level or quoted: raise ValueError('Unterminated comment/string in selected Lean source')
    return ''.join(result)


class GitReader:
    def __init__(self, repo: Path):
        self.repo = repo
        self.env = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
        self.trees, self.cache, self.receipts = {}, {}, {}
        self.proc = subprocess.Popen(['git','-C',str(repo),'cat-file','--batch'],
            env=self.env, stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    def git(self,*args):
        return subprocess.check_output(['git','-C',str(self.repo),*args],env=self.env)
    def tree(self,ref):
        if ref not in self.trees:
            records={}
            for line in self.git('ls-tree','-rz','--full-tree',ref).split(b'\0'):
                if not line: continue
                header,path=line.split(b'\t',1)
                mode,kind,oid=header.decode().split()
                records[path.decode()]={'mode':mode,'kind':kind,'oid':oid}
            self.trees[ref]=records
        return self.trees[ref]
    def obj(self,oid):
        if oid not in self.cache:
            self.proc.stdin.write((oid+'\n').encode());self.proc.stdin.flush()
            header=self.proc.stdout.readline().decode().rstrip()
            fields=header.split()
            if len(fields)!=3:raise RuntimeError('OFFLINE_GIT_OBJECT_UNAVAILABLE '+header)
            actual,kind,size=fields;data=self.proc.stdout.read(int(size));end=self.proc.stdout.read(1)
            if actual!=oid or end!=b'\n' or hashlib.sha1(f'{kind} {len(data)}\0'.encode()+data).hexdigest()!=oid:
                raise ValueError('Git object identity failure '+oid)
            self.cache[oid]=data
        return self.cache[oid]
    def read(self,path,ref=H):
        rec=self.tree(ref).get(path)
        if not rec:raise KeyError('Path absent at '+ref+':'+path)
        if rec['kind']!='blob':raise ValueError('Expected blob '+path)
        data=self.obj(rec['oid'])
        self.receipts[ref+':'+path]={'git_blob':rec['oid'],'sha256':sha(data),'bytes':len(data),'mode':rec['mode']}
        return data
    def js(self,path,ref=H):return json.loads(self.read(path,ref))
    def close(self):
        self.proc.stdin.close();self.proc.wait(timeout=10)


def main():
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--repo',type=Path,required=True)
    ap.add_argument('--report',type=Path,required=True)
    ap.add_argument('--official-members',type=Path,required=True)
    ap.add_argument('--official-comparison',type=Path,required=True)
    args=ap.parse_args()
    started=time.monotonic()
    report={'schema_version':1,'agent':'Agent #22','specialist':'pr135_evidence',
            'scope':'Independent nonauthor audit of retained execution/provenance evidence; no new Lean build',
            'source_head':H,'mathematical_source_commit':MATH,'generic_source_commit':BASE,
            'new_lean_invocations':0,'repository_source_mutations':0,'network_access_by_script':False,
            'started_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'checks':[],'findings':[],'retained_runs':[]}
    rd=GitReader(args.repo)
    def check(name,passed,details=None,obligation=None):
        rec={'name':name,'status':'PASS' if passed else 'FAIL'}
        if details is not None:rec['details']=details
        if obligation and not passed:rec['required_action']=obligation
        report['checks'].append(rec)
        return passed
    def same(path,expected,ref=H,expected_bytes=None):
        b=rd.read(path,ref)
        return sha(b)==expected and (expected_bytes is None or len(b)==expected_bytes)
    def logfile(command,prefix):
        path=prefix+command['log']
        data=rd.read(path)
        if sha(data)!=command['log_sha256']:raise ValueError('Log digest mismatch '+path)
        return data
    try:
        for ref in [H,MATH,BASE,OLD]:
            rd.obj(ref)
        incoming={p:v for p,v in rd.tree(H).items() if p not in rd.tree(BASE)}
        modifications=[p for p,v in rd.tree(BASE).items() if p in rd.tree(H) and v!=rd.tree(H)[p]]
        deletions=sorted(set(rd.tree(BASE))-set(rd.tree(H)))
        check('full_frozen_pr_scope',len(incoming)==2703 and not modifications and not deletions,
              {'added_paths':len(incoming),'modified_paths':modifications,'deleted_paths':deletions})
        digest_paths={}
        for path in incoming:
            data=rd.read(path)
            digest_paths[path]={'git_blob':incoming[path]['oid'],'sha256':sha(data),'bytes':len(data)}
        check('all_incoming_blob_contents_read',len(digest_paths)==2703,
              {'path_count':len(digest_paths),'unique_blobs':len({v['git_blob'] for v in digest_paths.values()}),
               'bytes_counting_paths':sum(v['bytes'] for v in digest_paths.values())})
        report['incoming_inventory_sha256']=sha((json.dumps(digest_paths,sort_keys=True,separators=(',',':'))+'\n').encode())
        check('published_key_digest_pins',all(same(p,h) for p,h in EXPECTED.items()),EXPECTED)
        gen=rd.js(G+'GENERATION_MANIFEST.json')
        dep=rd.js(P+'verification/author-base/dependency-map.json')
        snap=rd.js(V+'source-snapshot.json')
        link=rd.js(V+'SOURCE_SNAPSHOT_LINKAGE.json')
        reg=rd.js(V+'REGISTRY.json')
        can=rd.js(V+'canonical/verification.json')
        outer=rd.js(V+'build.json')
        original_inv=rd.js(V+'canonical/FILES.json')
        retained=rd.js(V+'CANONICAL_RETAINED_FILES.json')
        stats=rd.js(V+'THEOREM_AUDIT_STATISTICS.json')
        replay=rd.js(V+'CANONICAL_REPLAY_SOURCE_MAP.json')
        additions=rd.js(V+'SOURCE_MAP_ADDITIONS.json')
        pr=can['projects'][PROJECT];spec=reg['projects'][PROJECT]
        modules=snap['modules']; names=set(modules)
        check('all_source_and_registry_module_sets',len(names)==523 and len(gen['sources'])==510 and len(dep['modules'])==13 and
              names==set(gen['sources'])|set(dep['modules'])==set(link['modules'])==set(spec['modules'])==set(pr['sources']),
              {'compiled_source_count':len(names),'generated':len(gen['sources']),'generic':len(dep['modules'])})
        source_errors=[];source_bytes={};actual_imports={};source_receipts={}
        for module,rec in modules.items():
            ref=BASE if module in dep['modules'] else MATH
            data=rd.read(rec['source_path'],ref);source_bytes[module]=data
            actual_imports[module]=[d for line in re.findall(r'^\s*import\s+([^\n]+)',mask_lean(data.decode()),re.M) for d in line.split()]
            expected_blob=rd.tree(ref)[rec['source_path']]['oid']
            cond=(rec['source_ref']==ref and rec['source_kind']=='pinned_git_object' and
                  rec['git_blob']==expected_blob and rec['sha256']==sha(data) and rec['bytes']==len(data) and
                  rec['imports']==actual_imports[module] and rd.read(rec['source_path'],H)==data)
            r=spec['modules'][module];s=pr['sources'][module];l=link['modules'][module]
            cond=cond and r['sha256']==sha(data) and r['git_blob']==expected_blob and r['imports']==actual_imports[module]
            cond=cond and s['sha256']==s['build_sha256']==sha(data) and s['imports']==actual_imports[module] and s['adapter'] is None
            cond=cond and all(l[k]==rec[k] for k in ['source_ref','source_path','git_blob','sha256','bytes'])
            cond=cond and l['canonical_snapshot_path']==PROJECT+'/source/'+module+'.lean' and l['canonical_inventory_sha256']==sha(data)
            cond=cond and original_inv[l['canonical_snapshot_path']]=={'bytes':len(data),'sha256':sha(data)}
            cond=cond and l['source_url']=='https://github.com/taco-jpg/p196-algorithm/blob/'+ref+'/'+rec['source_path']
            if module in gen['sources']:
                g=gen['sources'][module];cond=cond and g['sha256']==sha(data) and g['bytes']==len(data)
            else:
                d=dep['modules'][module]
                cond=cond and all(d[k]==rec[k] for k in ['source_ref','source_path','git_blob','sha256','bytes','imports'])
                if 'preserved_original_ref' in d:
                    cond=cond and rd.read(d['preserved_original_path'],d['preserved_original_ref'])==data
            if not cond:source_errors.append(module)
            source_receipts[module]={'source_ref':ref,'source_path':rec['source_path'],'git_blob':expected_blob,'sha256':sha(data),'bytes':len(data),'imports':actual_imports[module]}
        check('all_523_actual_git_bytes_and_snapshot_links',not source_errors,{'errors':source_errors,'source_refs':{MATH:510,BASE:13},'source_adapters':0})
        report['selected_sources']=source_receipts
        order=[];active=set();seen=set();external=set()
        def visit(name):
            if name not in modules:external.add(name);return
            if name in active:raise ValueError('Selected import cycle '+name)
            if name in seen:return
            active.add(name)
            for d in actual_imports[name]:visit(d)
            active.remove(name);seen.add(name);order.append(name)
        visit('Agent104Prefix620')
        check('exact_selected_root_import_closure',seen==names and order==snap['build_order']==outer['build_order']==pr['build_order'],
              {'reachable':len(seen),'outside_root_closure':sorted(names-seen),'external_imports':sorted(external)})
        check('source_freeze_and_replay_metadata',outer['published_source']['commit']==MATH and outer['selected_source_commit']==MATH and
              outer['published_source']['generation_manifest_sha256']==sha(rd.read(G+'GENERATION_MANIFEST.json',MATH)) and
              outer['published_source']['generation_manifest_git_blob']==rd.tree(MATH)[G+'GENERATION_MANIFEST.json']['oid'] and
              snap['selected_source_commit']==MATH and snap['published_source_required'] and not snap['source_refs_are_null_for_uncommitted_author_files'] and
              can['source_commit']==OLD and can['source_tree_clean'] is False and can['agent']=='Agent #1' and replay['base']==OLD,
              {'raw_source_commit':can['source_commit'],'raw_agent':can['agent'],'raw_tree_clean':can['source_tree_clean'],
               'actual_executor':outer['agent']+' '+outer['specialist'],'actual_math_source':MATH})
        check('all_retained_canonical_evidence_bytes',len(retained)==527 and all(same(V+p,r['sha256'],expected_bytes=r['bytes']) for p,r in retained.items()),
              {'retained_files':len(retained),'canonical_inventory_entries':len(original_inv)})
        inventory_errors=[]
        for path,rec in original_inv.items():
            if path.startswith(PROJECT+'/source/') and path.endswith('.lean') and not path.endswith('/ProjectAudit.lean'):
                module=PurePosixPath(path).stem;data=source_bytes[module]
            else:data=rd.read(V+'canonical/'+path)
            if rec!={'sha256':sha(data),'bytes':len(data)}:inventory_errors.append(path)
        check('all_1049_original_output_inventory_entries',len(original_inv)==1049 and not inventory_errors,{'errors':inventory_errors})
        check('source_linkage_inventory_digest',link['raw_canonical_inventory_sha256']==sha(rd.read(V+'canonical/FILES.json')),
              {'snapshot_linkages':len(link['modules'])})
        origins=outer['canonical']['verifier_origins'];origin_errors=[]
        for key,info in origins.items():
            path=info.get('source_path',key);data=rd.read(path,MATH)
            if info['source_ref']!=MATH or info['git_blob']!=rd.tree(MATH)[path]['oid'] or info['sha256']!=sha(data) or rd.read(path,H)!=data:
                origin_errors.append(key)
        check('unchanged_original_wrapper_replay_backend',not origin_errors,{'origins':origins,'errors':origin_errors})
        map_errors=[]
        for name in order:
            r=spec['modules'][name];m=replay['paths'][r['path']];rec=modules[name]
            if m['sha256']!=rec['sha256'] or m['oid']!=rec['git_blob'] or rd.read(m.get('current') or m['preserved'],MATH)!=source_bytes[name]:map_errors.append(name)
        check('exact_original_layout_replay_mapping',len(replay['paths'])==524 and len(additions['paths'])==514 and not map_errors,
              {'selected_paths_including_backend':len(replay['paths']),'additions':len(additions['paths']),'errors':map_errors})
        linkage_hashes={
            V+'REGISTRY.json':outer['canonical']['registry_sha256'],
            V+'CANONICAL_REPLAY_SOURCE_MAP.json':outer['canonical']['replay_source_map_sha256'],
            V+'SOURCE_MAP_ADDITIONS.json':outer['canonical']['source_map_additions_sha256'],
            V+'CANONICAL_RETAINED_FILES.json':outer['canonical']['retained_raw_evidence_manifest_sha256'],
            V+'source-snapshot.json':outer['source_snapshot_sha256'],
            V+'canonical/verification.json':outer['canonical']['report_sha256'],
        }
        for oldpath,digest in outer['input_sha256'].items():
            path=oldpath[oldpath.index('proofs/'):];linkage_hashes[path]=digest
        check('execution_input_and_derived_manifest_digests',all(same(p,h) for p,h in linkage_hashes.items()),{'count':len(linkage_hashes)})
        commands=pr['commands'];cmd_errors=[]
        lean=outer['commands'][0]['argv'][0]
        for i,c in enumerate(commands):
            if i<len(order):expected=[lean,'-j1','-DElab.async=false','-o',order[i]+'.olean',order[i]+'.lean'];label=order[i]
            else:expected=[lean,'-j1','-DElab.async=false','ProjectAudit.lean'];label='ProjectAudit'
            if c['argv']!=expected or c['label']!=label or c['exit_code']!=0:cmd_errors.append(c['label'])
            logfile(c,V+'canonical/')
        check('complete_original_canonical_execution_524_commands',len(commands)==524 and not cmd_errors,
              {'commands':len(commands),'module_compilations':len(commands)-1,'zero_exit_commands':sum(c['exit_code']==0 for c in commands),
               'explicit_trust_0_commands':sum('--trust=0' in c['argv'] for c in commands),'trust_mode':'default max','errors':cmd_errors})
        for c in outer['commands']:logfile(c,V)
        raw_outer=rd.read(V+'logs/canonical-verifier.log').decode()
        actual_outer_lines=re.findall(r'^'+PROJECT+r' (\S+) exit=0$',raw_outer,re.M)
        check('outer_actual_execution_and_empty_build',outer['status']=='PASS_CANONICAL_SELECTED_620_CLOSURE' and len(outer['commands'])==3 and
              all(c['exit_code']==0 for c in outer['commands']) and outer['empty_build_at_start'] is True and outer['reused_olean_files']==[] and
              actual_outer_lines==order+['ProjectAudit'] and '--check-only' not in outer['commands'][-1]['argv'],
              {'empty_build_at_start':outer['empty_build_at_start'],'reused_author_oleans':outer['reused_olean_files'],
               'wall_seconds':outer['finished_at_epoch']-outer['started_at_epoch'],'outer_success_lines':len(actual_outer_lines)})
        check('correct_scoped_pass_and_claim_registry',can['status']==pr['status']=='PASS' and can['mathematical_proof_check'] is True and
              can['repository_wide_pass'] is False and reg['catalogue_complete'] is False and
              spec['roots']==['Agent104Prefix620'] and pr['endpoints']==outer['requested_endpoints']==ENDPOINTS and
              reg['claims']==[{'id':'agent104-prefix620-endpoints','project':PROJECT,'endpoints':ENDPOINTS}] and
              reg['toolchain']['allowed_axioms']==['propext','Classical.choice','Quot.sound'],
              {'repository_wide_pass':can['repository_wide_pass'],'endpoints':ENDPOINTS})
        audit=rd.read(V+'canonical/'+PROJECT+'/logs/ProjectAudit.log').decode()
        audit_src=rd.read(V+'canonical/'+PROJECT+'/source/ProjectAudit.lean').decode()
        declarations=re.findall(r'^AUDIT_THEOREM (\S+) (\S+) : (.*)$',audit,re.M)
        unsafe=re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$',audit,re.M)
        summaries=re.findall(r'^FULL_MODULE_AUDIT theorems=(\d+) union=(.*)$',audit,re.M)
        union=set();hist=collections.Counter();counts=collections.Counter();axs_by_name={}
        for module,name,axs in declarations:
            aset=set(x.strip() for x in axs.strip('[]').split(',') if x.strip())
            union|=aset;hist[tuple(sorted(aset))]+=1;counts[module]+=1;axs_by_name[name]=sorted(aset)
        selected=json.loads(re.search(r'let selected : List String := (\[.*\])',audit_src).group(1))
        required=['env.constants.toList','env.getModuleIdxFor? name','env.allImportedModuleNames[idx.toNat]!',
                  'selected.contains mod.toString','Lean.collectAxioms name','.axiomInfo v',
                  'if v.isUnsafe then logInfo','else throwError m!"CUSTOM_AXIOM','.thmInfo _',
                  'if axl.any (fun ax => !(allowed.contains ax)) then throwError']
        check('exhaustive_module_origin_theorem_audit',len(declarations)==3047==pr['theorem_count']==outer['theorem_count'] and
              len(axs_by_name)==3047 and len(summaries)==1 and int(summaries[0][0])==3047 and union==ALLOWED and
              all(set(x for x in aset)<=ALLOWED for aset in axs_by_name.values()) and set(counts)<=names and
              selected==order and all(x in audit_src for x in required) and
              not re.search(r'^(?:CUSTOM_AXIOM|DISALLOWED_AXIOMS)\b',audit,re.M),
              {'theorems':len(declarations),'module_origins':len(counts),'without_theorems':len(names-set(counts)),
               'axiom_union':sorted(union),'histogram':{'['+', '.join(k)+']':v for k,v in sorted(hist.items())}})
        check('unsafe_implementation_axioms_separate_from_theorems',len(unsafe)==70 and len({name for mod,name in unsafe})==70 and
              [list(x) for x in unsafe]==pr['unsafe_implementation_axioms']==outer['unsafe_implementation_axioms'] and
              not ({name for mod,name in unsafe}&union) and {mod for mod,name in unsafe}<=names,
              {'unsafe_entries':len(unsafe),'safe_custom_axioms':0,'unsafe_in_theorem_union':sorted({name for mod,name in unsafe}&union)})
        endpoint_axioms={name:axs_by_name.get(name) for name in ENDPOINTS}
        check('three_exported_endpoint_audits',endpoint_axioms=={ENDPOINTS[0]:[],ENDPOINTS[1]:sorted(ALLOWED),ENDPOINTS[2]:sorted(ALLOWED)},endpoint_axioms)
        calculated_counts={m:counts.get(m,0) for m in order}
        check('theorem_statistics_match_full_raw_log',stats['module_theorem_counts']==calculated_counts and stats['theorem_count']==3047 and
              stats['modules_with_theorems']==456 and set(stats['modules_without_theorems'])==names-set(counts) and
              stats['unsafe_implementation_axiom_count']==70 and stats['safe_custom_axioms']==0 and
              stats['raw_canonical_report_sha256']==EXPECTED[V+'canonical/verification.json'] and
              stats['raw_audit_log_sha256']==EXPECTED[V+'canonical/'+PROJECT+'/logs/ProjectAudit.log'],
              {'reported_modules':len(stats['module_theorem_counts']),'audited_modules':len(calculated_counts)})
        members_bytes=args.official_members.read_bytes();members=json.loads(members_bytes);official={x['path']:x for x in members}
        cmp_bytes=args.official_comparison.read_bytes();comparison=json.loads(cmp_bytes)
        std=rd.js(V+'standard-library-integrity.json')
        std_errors=[]
        for path,info in std['records'].items():
            orig=official.get(path,{})
            if orig.get('type')!='file' or orig.get('archive_sha256')!=info['sha256'] or orig.get('archive_bytes')!=info['bytes'] or not orig.get('matches'):
                std_errors.append(path)
        official_oleans={p for p,x in official.items() if p.endswith('.olean') and x['type']=='file'}
        check('all_1471_stdlib_pins_match_independently_checked_official_archive',sha(members_bytes)==MEMBERS_SHA and
              comparison['all_passed'] and comparison['official_archive_sha256']==ARCHIVE_SHA and
              len(members)==4617 and std['archive_sha256']==ARCHIVE_SHA and std['module_count']==1471 and
              set(std['records'])==official_oleans and not std_errors and sum(x['bytes'] for x in std['records'].values())==std['bytes'],
              {'stdlib_objects':len(std['records']),'stdlib_bytes':std['bytes'],'official_member_count':len(members),'errors':std_errors,
               'archive_sha256':ARCHIVE_SHA,'origin_manifest_path':str(args.official_members),'origin_manifest_sha256':sha(members_bytes),
               'origin_comparison_path':str(args.official_comparison),'origin_comparison_sha256':sha(cmp_bytes),
               'new_runtime_rehash_by_this_script':False})
        compiler_errors=[]
        old_runtime=std['runtime'].rstrip('/')+'/'
        for path,digest in outer['compiler']['files'].items():
            relative=path.removeprefix(old_runtime)
            if official.get(relative,{}).get('archive_sha256')!=digest:compiler_errors.append(path)
        check('all_recorded_compiler_and_library_pins_match_official_members',not compiler_errors and
              len(outer['compiler']['files'])==1475 and all(outer['compiler']['files'].get(p)==h for p,h in can['compiler']['files'].items()) and
              outer['compiler']['standard_library_origin']['manifest_sha256']==sha(rd.read(V+'standard-library-integrity.json')),
              {'recorded_files':len(outer['compiler']['files']),'errors':compiler_errors,'compiler_sha256':official['bin/lean']['archive_sha256']})
        for ext in external|{'Lean'}:
            check('official_import_'+ext,'lib/lean/'+ext.replace('.','/')+'.olean' in std['records'])
        freeze=rd.js(P+'review/reviewer-freeze.json');pubpaths=rd.read(P+'review/PUBLISH_REVIEW_FILES.txt').decode().splitlines()
        review_errors=[p for p,r in freeze['files'].items() if not same(p,r['sha256'],expected_bytes=r['bytes'])]
        check('twelve_frozen_nonauthor_review_files',len(pubpaths)==12 and set(pubpaths)==set(freeze['files'])|{P+'review/reviewer-freeze.json'} and
              len(freeze['files'])==11 and not review_errors and freeze['reviewer']=='/root/strategy_review' and
              not freeze['mathematical_sources_modified_by_reviewer'] and freeze['published_math_commit']==MATH and
              freeze['manifest_sha256']==EXPECTED[G+'GENERATION_MANIFEST.json'],
              {'frozen_files':len(pubpaths),'reviewer':freeze['reviewer'],'relationship':freeze['relationship'],'errors':review_errors})
        review_source=rd.js(P+'review/source-pins.json')
        check('semantic_review_same_thirteen_generic_sources',set(review_source['modules'])==set(dep['modules']) and
              all(r['path']==dep['modules'][m]['source_path'] and all(r[k]==dep['modules'][m][k] for k in ['sha256','git_blob','bytes','imports']) for m,r in review_source['modules'].items()))
        structural=rd.js(P+'review/structural-coverage-pins.json')
        review_pin_errors=[]
        for module,r in structural['modules'].items():
            if not same(r['path'],r['sha256'],MATH,r['bytes']) or r['git_blob']!=rd.tree(MATH)[r['path']]['oid'] or r['imports']!=actual_imports[module]:review_pin_errors.append(module)
        for name,r in structural['evidence_files'].items():
            if not same(P+'review/'+name,r['sha256'],expected_bytes=r['bytes']):review_pin_errors.append(name)
        controls={}
        for stem,hashkey in [('independent_control','control_script_sha256'),('independent_slice_control','script_sha256'),('independent_final_connection','script_sha256')]:
            o=rd.js(P+'review/'+stem+'.json');controls[stem]=o
            if not same(P+'review/'+stem+'.py',o[hashkey]):review_pin_errors.append(stem)
        final_control=controls['independent_final_connection']
        for path,r in final_control['published_source_links'].items():
            if not same(path,r['sha256'],MATH,r['bytes']) or rd.tree(MATH)[path]['oid']!=r['git_blob']:review_pin_errors.append(path)
        check('semantic_control_results_exact_published_sources_and_scripts',not review_pin_errors and
              structural['published_commit']==MATH and final_control['published_commit']==MATH and
              len(final_control['published_source_links'])==526 and len(final_control['selected_byte_readback_paths'])==13 and
              controls['independent_control']['status']=='PASS' and structural['status']=='PASS_FINAL_FROZEN_SEMANTICS_AND_CONNECTION',
              {'errors':review_pin_errors,'source_links_actually_reread':len(final_control['published_source_links']),
               'original_explicit_byte_readback_subset':len(final_control['selected_byte_readback_paths']),
               'new_finite_math_control_executions_by_this_script':0})
        check('independent_review_roles_and_completion_order',structural['reviewer']=='/root/strategy_review' and
              structural['new_helper_author']=='/root' and structural['slice_generator_author']=='/root/scope_scout' and
              outer['specialist']=='runtime_scout' and outer['status']=='PASS_CANONICAL_SELECTED_620_CLOSURE' and
              datetime.datetime.fromisoformat(freeze['frozen_at_utc']).timestamp()<outer['finished_at_epoch'],
              {'source_author_roles':['Agent #104 /root','Agent #104 /root/scope_scout'],
               'semantic_reviewer':'Agent #104 /root/strategy_review','execution_reviewer':'Agent #104 /root/runtime_scout',
               'same_session_shared_account':True,'external_peer_review':False,'completion':'Retained canonical build completes the explicitly pending execution at semantic freeze'})
        public=rd.js(V+'PUBLICATION_SHA256.json');pub=rd.read(V+'PUBLISH_INDEPENDENT_VERIFICATION.txt').decode().splitlines()
        public_errors=[p for p,r in public['files'].items() if not same(p,r['sha256'],expected_bytes=r['bytes'])]
        check('complete_independent_evidence_publication_inventory',len(pub)==547 and len(public['files'])==546 and
              set(pub)==set(public['files'])|{V+'PUBLICATION_SHA256.json'} and not public_errors and
              public['file_count_including_inventory']==547,
              {'listed_files':len(pub),'hashed_nonself_files':len(public['files']),'self_exclusion':V+'PUBLICATION_SHA256.json','errors':public_errors})
        # Read all historical run records and every command's complete original log.
        author_base=rd.js(P+'verification/author-base/build.json')
        for c in author_base['commands']:logfile(c,P+'verification/author-base/')
        base_audit=rd.read(P+'verification/author-base/logs/015-module-axiom-audit.log').decode()
        base_theorems=re.findall(r'^AUDIT_THEOREM (\S+) (\S+) : (.*)$',base_audit,re.M)
        check('generic_base_build_actual_sixteen_commands',len(author_base['commands'])==16 and all(c['exit_code']==0 for c in author_base['commands']) and
              author_base['status']=='PASS_GENERIC_DEPENDENCIES_ONLY' and len(base_theorems)==1453 and
              all(c['argv'][1:]==['-j1','-DElab.async=false','-o',m+'.olean',m+'.lean'] for c,m in zip(author_base['commands'][2:15],dep['build_order'])) and
              author_base['dependency_map_sha256']==sha(rd.read(P+'verification/author-base/dependency-map.json')),
              {'compiled_modules':13,'theorem_count':len(base_theorems),'trust_mode':'default max','source_ref':author_base['source_ref']})
        author_success=rd.js(G+'evidence/successful-builds.json');all_stage=rd.js(G+'evidence/all-001/verification.json');author=rd.js(G+'AUTHOR_BUILD_COMPLETE.json')
        author_run_paths=[p for p in rd.tree(H) if p.startswith(G+'evidence/') and p.endswith('/verification.json')]
        recorded_commands=[];historical_sources={}
        for path,receipt in digest_paths.items():historical_sources.setdefault(receipt['sha256'],[]).append(path)
        run_errors=[];failures=[]
        for path in author_run_paths:
            o=rd.js(path);cmds=o.get('commands',[o] if 'command' in o else [])
            run={'path':path,'sha256':sha(rd.read(path)),'status':o.get('status','UNLABELLED_PILOT'),'kind':o.get('kind'),
                 'jobs':o.get('jobs'),'commands':len(cmds),'exit_codes':[c['exit_code'] for c in cmds],
                 'source_manifest_sha256':o.get('manifest_sha256'),'failures':[]}
            if o.get('manifest_sha256') not in historical_sources and o.get('manifest_sha256') is not None:run_errors.append(path+': manifest missing')
            for c in cmds:
                if 'log' in c:log=logfile(c,G)
                else:
                    candidates=[q for q in rd.tree(H) if q.startswith(str(PurePosixPath(path).parent)+'/') and q.endswith('.log')]
                    log=b'\n'.join(rd.read(q) for q in candidates)
                if '--trust=0' not in c['command']:run_errors.append(path+': trust flag absent')
                if c['source_sha256'] not in historical_sources:run_errors.append(path+': source bytes absent '+c.get('module','probe'))
                if c['exit_code']:
                    finding={'module':c.get('module'),'exit_code':c['exit_code'],'source_sha256':c['source_sha256'],'log':G+c['log'],'log_sha256':sha(log),'complete_log_text':log.decode()}
                    run['failures'].append(finding);failures.append(finding)
                    failed_path=str(PurePosixPath(path).parent)+'/failed-sources/'+c['module']+'.lean'
                    if failed_path not in rd.tree(H) or not same(failed_path,c['source_sha256']):run_errors.append(path+': failed source not preserved')
                recorded_commands.append(c)
            if o.get('status')=='PASS' and any(c['exit_code'] for c in cmds):run_errors.append(path+': false PASS')
            report['retained_runs'].append(run)
        check('all_historical_author_command_source_and_log_evidence',not run_errors,
              {'runs':len(author_run_paths),'commands':len(recorded_commands),'failed_commands':len(failures),'errors':run_errors})
        report['preserved_failed_compilations']=failures
        success_errors=[];import_links=0;records_without_import_hashes=[]
        by_identity={json.dumps(c,sort_keys=True) for c in recorded_commands}
        for module,c in author_success.items():
            if module not in gen['sources'] or c['source_sha256']!=gen['sources'][module]['sha256'] or c['exit_code']!=0 or json.dumps(c,sort_keys=True) not in by_identity:
                success_errors.append(module+': success record mismatch')
            logfile(c,G)
            if 'import_object_sha256' in c:
                expected_obj={d:(author_success[d]['object_sha256'] if d in author_success else author_base['outputs'][d]['olean_sha256']) for d in actual_imports[module]}
                if expected_obj!=c['import_object_sha256']:success_errors.append(module+': imported object hash mismatch')
                import_links+=len(expected_obj)
            else:records_without_import_hashes.append(module)
        check('author_current_510_successes_and_431_plus_79_partition',len(author_success)==510 and set(author_success)==set(gen['sources']) and
              len(all_stage['commands'])==431 and len(all_stage['reused_concrete_objects'])==79 and all_stage['jobs']==1 and
              {c['module'] for c in all_stage['commands']}|set(all_stage['reused_concrete_objects'])==set(author_success) and
              not ({c['module'] for c in all_stage['commands']}&set(all_stage['reused_concrete_objects'])) and not success_errors,
              {'new_final_stage':431,'reused_author_objects':79,'final_jobs':1,'recorded_import_hash_links':import_links,
               'early_successes_without_per_import_object_field':records_without_import_hashes,'errors':success_errors,
               'object_bytes_rehashed_now':False,'reason':'Compiled outputs excluded as reproducible infrastructure; retained clean independent build does not reuse them'})
        author_index_errors=[]
        for path,r in author['evidence_report_index'].items():
            if not same(G+path,r['sha256']):author_index_errors.append(path)
        check('author_completion_index_and_unpromoted_pending_labels',not author_index_errors and author['independent_review'] is False and
              author['published_source_commit']==MATH and author['manifest_sha256']==EXPECTED[G+'GENERATION_MANIFEST.json'] and
              same(G+author['final_stage_report']['path'],author['final_stage_report']['sha256']) and
              same(G+author['successful_build_index']['path'],author['successful_build_index']['sha256']) and
              same(G+author['source_freeze_snapshot']['path'],author['source_freeze_snapshot']['sha256']),
              {'errors':author_index_errors,'independent_status_at_author_completion':author['independent_canonical_status_at_completion']})
        retired=rd.js(G+'development/retired-outputs.json')
        development_errors=[]
        for path in digest_paths:
            relative=path.removeprefix(G+'development/')
            if path.startswith(G+'development/') and re.match(r'[0-9a-f]{64}/',relative):
                if sha(rd.read(path))!=relative.split('/')[0]:development_errors.append(path)
        for rec in retired:
            if not same(G+rec['preserved_path'],rec['sha256']):development_errors.append(rec['preserved_path'])
        check('all_content_addressed_development_and_retired_sources_preserved',not development_errors,
              {'retired_modules':len(retired),'content_addressed_paths':sum(p.startswith(G+'development/') and bool(re.match(r'[0-9a-f]{64}/',p.removeprefix(G+'development/'))) for p in digest_paths),'errors':development_errors})
        for n in ['001','002']:
            pp=P+'development/coverage/attempt-'+n+'/'
            o=rd.js(pp+'result.json')
            check('coverage_helper_attempt_'+n,same(pp+'Agent104Prefix620DataCoverage.lean',o['source_sha256']) and
                  o['exit_code']==0 and '--trust=0' in o['command'],{'result':o,'log_sha256':sha(rd.read(pp+'lean.log'))})
        termination=[]
        for p in digest_paths:
            if p.endswith('-termination.json'):
                for t in rd.js(p):termination.append({'path':p,**t})
        check('explicit_deliberate_terminations_preserved',len(termination)==2 and all(t['signal']=='SIGTERM' for t in termination),termination)
        trans_path=P+'verification/canonical-transport-check/';trans=rd.js(trans_path+'build.json')
        for c in trans['commands']:logfile(c,trans_path)
        check('source_transport_check_not_promoted_to_Lean_pass',trans['status']=='PASS_CANONICAL_SOURCE_IMPORT_CHECK_ONLY' and
              trans['compiled_module_count']==0 and trans['mathematical_proof_check'] is False and
              '--check-only' in trans['commands'][-1]['argv'] and all(c['exit_code']==0 for c in trans['commands']),
              {'module_count':trans['module_count'],'proof_compilations':0,'status':trans['status']})
        readme=rd.read(P+'README.md').decode()
        overbroad='all 510 concrete modules and 13 generic dependencies\nhave actually compiled using official Lean 4.19.0, explicit `--trust=0`, one\nworker'
        if overbroad in readme:
            report['findings'].append({'id':'README_TRUST_AND_CONCURRENCY_LABEL','severity':'documentation correction',
              'path':P+'README.md','source_head':H,'finding':'The opening author-build sentence attributes explicit trust=0 and one worker to all 510 concrete plus 13 generic sources. The generic base commands use default trust=max; early author stages use two concurrent Lean processes, with -j1 per process. Only the final 431-module stage uses one process.',
              'required_action':'Preserve the original README, correct the author-build paragraph, and independently check the documentation delta. No Lean rebuild is required when source and evidence bytes remain unchanged.',
              'invalidates_retained_proof_build':False})
        report['evidence_reuse_verdict']='PASS' if all(c['status']=='PASS' for c in report['checks']) else 'GAPS'
        report['publication_label_status']='CORRECTION_REQUIRED' if report['findings'] else 'PASS'
        report['status']='PASS_RETAINED_EVIDENCE_WITH_DOCUMENTATION_CORRECTION' if report['evidence_reuse_verdict']=='PASS' and report['findings'] else report['evidence_reuse_verdict']
    except Exception:
        report['status']='AUDIT_EXECUTION_FAILED';report['evidence_reuse_verdict']='UNDETERMINED'
        report['exception']=traceback.format_exc()
    finally:
        report['finished_at_utc']=datetime.datetime.now(datetime.timezone.utc).isoformat()
        report['elapsed_seconds']=time.monotonic()-started
        report['read_receipt_count']=len(rd.receipts)
        report['unique_git_objects_read']=len(rd.cache)
        report['read_receipts_sha256']=sha(json.dumps(rd.receipts,sort_keys=True,separators=(',',':')).encode())
        report['check_script_sha256']=sha(Path(__file__).read_bytes())
        args.report.parent.mkdir(parents=True,exist_ok=True)
        with args.report.open('x') as f:json.dump(report,f,indent=2,ensure_ascii=False);f.write('\n')
        rd.close()
    print(json.dumps({'status':report['status'],'evidence_reuse_verdict':report['evidence_reuse_verdict'],'checks':len(report['checks']),
        'failures':[c for c in report['checks'] if c['status']=='FAIL'],'findings':report['findings'],'exception':report.get('exception'),
        'report':str(args.report),'elapsed_seconds':report['elapsed_seconds']},indent=2,ensure_ascii=False))
    return 0 if report['evidence_reuse_verdict']=='PASS' else 1

if __name__=='__main__':raise SystemExit(main())
