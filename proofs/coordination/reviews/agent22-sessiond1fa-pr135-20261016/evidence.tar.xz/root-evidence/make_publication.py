#!/usr/bin/env python3
"""Losslessly publish Agent22's frozen PR135 verification records."""
import hashlib, io, json, tarfile
from pathlib import Path

ROOT = Path('/dev/shm/p196-agent22-d1fa86c3a213')
OUT = ROOT / 'publication' / 'pr135-checkpoint-001'
FOLDERS = ('root-evidence', 'pr135-semantics', 'pr135-evidence', 'pr135-repair-review')

def sha(data): return hashlib.sha256(data).hexdigest()
def blob(data): return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
def encoded(obj): return (json.dumps(obj, indent=2, ensure_ascii=False) + '\n').encode()

def main():
    OUT.mkdir(parents=True, exist_ok=False)
    members=[]
    for folder in FOLDERS:
        p=ROOT/folder
        assert p.is_dir(), p
        for f in sorted(p.rglob('*')):
            if f.is_file():
                assert not f.is_symlink(), f
                data=f.read_bytes()
                members.append((str(f.relative_to(ROOT)),data))
    required={'root-evidence/INTEGRATION_REVIEW.md','pr135-semantics/REVIEW.md','pr135-evidence/REVIEW.md','pr135-repair-review/REVIEW.md'}
    assert required <= {p for p,_ in members}, required-{p for p,_ in members}
    manifest=encoded({'schema_version':1,'owner':'Agent #22/sessiond1fa86c3a213','pr':135,'source_head':'32d2b92ec79becfbb4d2aa2cf9bd42f8bbd5597e','scope':'Complete original current-session selected source/evidence/repair/combination records; all failed attempts preserved; no new Lean execution','files':[{'path':p,'bytes':len(d),'sha256':sha(d),'git_blob':blob(d)} for p,d in members]})
    (OUT/'MANIFEST.json').write_bytes(manifest)
    archive=OUT/'evidence.tar.xz'
    with tarfile.open(archive,'w:xz',preset=6) as t:
        for name,data in members+[('MANIFEST.json',manifest)]:
            info=tarfile.TarInfo(name)
            info.size=len(data); info.mtime=0; info.mode=0o644
            t.addfile(info,io.BytesIO(data))
    with tarfile.open(archive,'r:xz') as t:
        got={m.name:t.extractfile(m).read() for m in t.getmembers() if m.isfile()}
    expected=dict(members+[('MANIFEST.json',manifest)])
    assert got==expected, 'Lossless readback mismatch'
    data=archive.read_bytes()
    receipt={'schema_version':1,'pr':135,'source_head':'32d2b92ec79becfbb4d2aa2cf9bd42f8bbd5597e','archive':'evidence.tar.xz','bytes':len(data),'sha256':sha(data),'git_blob':blob(data),'manifest':'MANIFEST.json','manifest_sha256':sha(manifest),'original_files':len(members),'original_bytes':sum(len(d) for _,d in members),'tar_members_including_manifest':len(members)+1,'lossless_full_readback':'PASS','extraction':'python3 -m tarfile -e evidence.tar.xz extracted','limitations':'This archive retains recorded checks, including failures. It is not a new Lean build or a main merge receipt.'}
    (OUT/'ARCHIVE.json').write_bytes(encoded(receipt))
    print(json.dumps(receipt,indent=2))
if __name__=='__main__': main()
