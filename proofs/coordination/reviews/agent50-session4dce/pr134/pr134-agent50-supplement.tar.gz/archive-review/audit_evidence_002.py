#!/usr/bin/env python3
"""Independent retained-evidence byte and coverage check; no repository execution."""
import collections, contextlib, datetime, gzip, hashlib, io, json, re, sys, tarfile, traceback
from pathlib import Path, PurePosixPath

ROOT = Path(sys.argv[1])
ATTEMPT = ROOT / "checker-attempts/002-full-evidence"
ATTEMPT.mkdir(parents=True, exist_ok=False)
HEAD = "ec7aa17a36548cc629d2a4a309e802406fc862e7"
CHECKPOINT = "64bb07e9f8d3ffcfd141d58e01ec7e27964c5e5d"
PROJECT = "agent105-numeric-decoder-9df76b"
CONTRIB = "proofs/contributions/agent-105/numeric-decoder-9df76b-20261016"
FRESH, STRICT = "verification/fresh-scope105-001/", "verification/strict-scope105-001/"
ALLOWED = {"propext", "Classical.choice", "Quot.sound"}
NEW = {"Agent105DecoderLocal9df76b", "Agent105DecoderTarget9df76b", "Agent105DecoderScan9df76b",
       "Agent105NumericDecoder9df76b", "Agent105DecoderControls9df76b"}
CHECKS = []

def require(ok, label, detail=None):
    CHECKS.append({"check": label, "status": "PASS" if ok else "FAIL", "detail": detail})
    if not ok:
        raise ValueError(label + (": " + str(detail) if detail is not None else ""))

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode("ascii") + b"\0" + data).hexdigest()

def write_json(path, value):
    with path.open("x", encoding="utf-8") as stream:
        json.dump(value, stream, indent=2, ensure_ascii=False)
        stream.write("\n")

def read_json(path):
    return json.loads(path.read_bytes())

def parse_axioms(text):
    values = [value.strip() for value in text.split(",") if value.strip()]
    require(len(values) == len(set(values)) and
            all(re.fullmatch(r"[A-Za-z_][A-Za-z_0-9.]*", value) for value in values),
            "axiom list contains unique plain names", values)
    return sorted(values)

def parse_audit(log, label):
    matches = list(re.finditer(r"^AUDIT_THEOREM (\S+) (\S+) : \[([^\]]*)\]$", log, re.M))
    require(len(matches) == sum(line.startswith("AUDIT_THEOREM ") for line in log.splitlines()),
            label + " every theorem occurrence parsed with full multiline axiom list")
    mapping = {}
    for match in matches:
        module, name, body = match.groups()
        require(name not in mapping, label + " theorem name unique", name)
        deps = parse_axioms(body)
        require(set(deps) <= ALLOWED, label + " theorem has no forbidden dependency", name)
        mapping[name] = {"module": module, "axioms": deps}
    summaries = re.findall(r"^FULL_MODULE_AUDIT theorems=(\d+) union=\[([^\]]*)\]$", log, re.M)
    require(len(summaries) == 1, label + " unique audit completion record")
    count, union = summaries[0]
    observed = set(ax for rec in mapping.values() for ax in rec["axioms"])
    require(int(count) == len(mapping) == 1096, label + " exact 1096 distinct theorems")
    require(set(parse_axioms(union)) == observed == ALLOWED, label + " full recomputed axiom union")
    unsafe = re.findall(r"^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$", log, re.M)
    require(len(unsafe) == len(set(unsafe)) == 22 and
            len(unsafe) == sum(line.startswith("UNSAFE_IMPLEMENTATION_AXIOM ") for line in log.splitlines()),
            label + " all 22 unsafe implementation declaration records")
    require(not re.search(r"CUSTOM_AXIOM|DISALLOWED_AXIOMS|\bsorryAx\b|\bnative_decide\b|\bofReduceBool\b|\bskipKernelTC\b", log),
            label + " no forbidden audit markers")
    return mapping, sorted(unsafe)

def main():
    manifest = read_json(ROOT / "inputs/VERIFICATION_ARCHIVE.json")
    canonical = read_json(ROOT / "inputs/canonical-verification.json")
    strict = read_json(ROOT / "inputs/strict-verification.json")
    final = read_json(ROOT / "inputs/scope105-final-review.json")
    project = canonical["projects"][PROJECT]
    archive = (ROOT / "inputs/verification-evidence.tar.gz").read_bytes()
    require(len(archive) == manifest["archive"]["bytes"] == 174360, "compressed byte count")
    require(sha(archive) == manifest["archive"]["sha256"] == "068b07e5af5aabd6390d9e8636ce8f1efecef450bbeec04af4dfd2782aed23d9", "compressed SHA256")
    require(blob(archive) == manifest["archive"]["git_blob"] == "6edcaec03b229e117613d57df9ad22f4c43e97b3", "compressed Git blob")
    require(archive[:3] == b"\x1f\x8b\x08" and archive[3] & 8 == 0 and
            int.from_bytes(archive[4:8], "little") == 0, "normalized gzip header")
    with gzip.GzipFile(fileobj=io.BytesIO(archive), mode="rb") as stream:
        tar_bytes = stream.read(2 * 1024 * 1024 + 1)
        require(len(tar_bytes) <= 2 * 1024 * 1024 and stream.read(1) == b"", "bounded gzip decompression")
    expected = {row["archive_member"]: row for row in manifest["members"]}
    require(len(expected) == len(manifest["members"]) == 71, "71 unique manifest members")
    members = {}
    with tarfile.open(fileobj=io.BytesIO(tar_bytes), mode="r:") as tar:
        for item in tar.getmembers():
            path = PurePosixPath(item.name)
            require(item.isfile() and item.name not in members and not path.is_absolute()
                    and ".." not in path.parts and "." not in path.parts
                    and item.name == path.as_posix() and path.parts[0] == "verification",
                    "safe unique regular member", item.name)
            require(item.mode == 0o644 and item.uid == item.gid == item.mtime == 0,
                    "normalized tar metadata", item.name)
            require(item.name in expected, "member listed in full manifest", item.name)
            with tar.extractfile(item) as stream:
                data = stream.read(item.size + 1)
            row = expected[item.name]
            require(len(data) == item.size == row["bytes"] and sha(data) == row["sha256"],
                    "member size and SHA256", item.name)
            require((ROOT / "retained" / item.name).read_bytes() == data,
                    "retained raw member unchanged", item.name)
            members[item.name] = data
    require(set(members) == set(expected) and len(members) == 71, "exact full member set")
    require(sum(map(len, members.values())) == manifest["archive"]["uncompressed_member_bytes"] == 929758,
            "exact uncompressed member byte sum")
    for row in manifest["direct_review_copies"]:
        data = (ROOT / "inputs" / row["contribution_relative_path"]).read_bytes()
        require(data == members[row["archive_member"]] and len(data) == row["bytes"] and
                sha(data) == row["sha256"], "direct review copy identity", row["contribution_relative_path"])
    retrieval = read_json(ROOT / "retrieval/github-fetch-metadata.json")
    source_meta = read_json(ROOT / "retrieval/head-source-metadata.json")
    require(retrieval["head"] == source_meta["head"] == HEAD, "all retrievals pinned to exact PR head")
    for row in retrieval["results"]:
        data = (ROOT / "inputs" / row["display_title"]).read_bytes()
        require(blob(data) == row["sha"] and ("/blob/" + HEAD + "/") in row["display_url"],
                "input connector Git identity", row["display_title"])
    metadata = {row["path"]: row for row in source_meta["results"]}
    for path, row in metadata.items():
        data = (ROOT / "head-sources" / path).read_bytes()
        require(blob(data) == row["sha"] and ("/blob/" + HEAD + "/") in row["display_url"],
                "head source connector Git identity", path)

    original = json.loads(members["verification/scope105-evidence-manifest.json"])
    row = manifest["original_manifest"]
    require(len(members[row["path"]]) == row["bytes"] and sha(members[row["path"]]) == row["sha256"],
            "original evidence manifest identity")
    require(len(original["files"]) == row["covered_file_count"] == 70 and
            {"verification/" + name for name in original["files"]} == set(members) - {row["path"]},
            "original manifest exact 70-file coverage")
    for name, row in original["files"].items():
        data = members["verification/" + name]
        require(len(data) == row["bytes"] and sha(data) == row["sha256"], "original manifest size and hash", name)
    index_counts = {}
    for prefix in [FRESH, STRICT]:
        index = json.loads(members[prefix + "FILES.json"])
        names = {name[len(prefix):] for name in members if name.startswith(prefix) and name != prefix + "FILES.json"}
        require(set(index) == names, "run FILES index exact coverage", prefix)
        for name, row in index.items():
            data = members[prefix + name]
            require(len(data) == row["bytes"] and sha(data) == row["sha256"], "run FILES size and hash", prefix + name)
        index_counts[prefix] = len(index)
    require({manifest["source_checkpoint"], canonical["source_commit"], strict["source_commit"],
             final["source_commit"], original["source_commit"]} == {CHECKPOINT}, "consistent recorded checkpoint")
    require(canonical["status"] == project["status"] == "PASS" and canonical["mathematical_proof_check"] is True
            and strict["status"] == "PASS_EXPLICIT_TRUST_ZERO", "actual receipt completion statuses")
    require(all(value["repository_wide_pass"] is False for value in [canonical, strict, final]),
            "receipts consistently scoped")
    require(canonical["source_tree_clean"] is True and strict["source_tree_clean_at_original_verification"] is True,
            "recorded tracked-source cleanliness")

    registry_bytes = (ROOT / "head-sources" / final["registry"]["path"]).read_bytes()
    registry = json.loads(registry_bytes)
    require(registry_bytes == members[STRICT + "registry-used.json"], "head registry equals retained registry bytes")
    require(sha(registry_bytes) == canonical["registry_sha256"] == strict["registry_sha256"] ==
            final["registry"]["sha256"] == "10aa02456c15914a8dd00a1b3bf639a7e9f129262c54ef7bd894ec635eec9f52",
            "all registry SHA256 pins agree")
    require(registry["toolchain"]["version"] == "4.19.0" and
            registry["toolchain"]["release_commit"] == "6caaee842e94" and
            set(registry["toolchain"]["allowed_axioms"]) == ALLOWED, "registry toolchain and axiom policy")
    spec = registry["projects"][PROJECT]
    modules, order = spec["modules"], project["build_order"]
    require(len(order) == len(set(order)) == len(modules) == 12 and
            set(order) == set(modules) == set(project["sources"]) and strict["build_order"] == order and
            set(strict["sources"]) == set(modules) | {"ProjectAudit"}, "exact twelve-module build coverage")
    require(set(final["modules"]) == set(original["published_sources"]) == set(modules), "complete source pin maps")
    source_rows = []
    for module in order:
        info = modules[module]
        published = (ROOT / "head-sources" / info["path"]).read_bytes()
        fresh_data = members[FRESH + PROJECT + "/source/" + module + ".lean"]
        strict_data = members[STRICT + "source/" + module + ".lean"]
        require(published == fresh_data == strict_data, "head equals both source snapshots", module)
        require(sha(published) == info["sha256"] == project["sources"][module]["sha256"] ==
                project["sources"][module]["build_sha256"] == strict["sources"][module]["sha256"] ==
                final["modules"][module]["sha256"] == original["published_sources"][module]["sha256"],
                "all source SHA256 pins agree", module)
        require(blob(published) == info["git_blob"] == final["modules"][module]["git_blob"] ==
                original["published_sources"][module]["git_blob"] == metadata[info["path"]]["sha"],
                "all source Git blob pins agree", module)
        require(len(published) == strict["sources"][module]["bytes"] and
                project["sources"][module]["adapter"] is None and
                project["sources"][module]["imports"] == info["imports"], "source size and no adapter", module)
        require(all(dep not in modules or order.index(dep) < order.index(module) for dep in info["imports"]),
                "imports compiled before importer", module)
        source_rows.append({"module": module, "path": info["path"], "bytes": len(published),
                            "sha256": sha(published), "git_blob": blob(published), "new_decoder_module": module in NEW})
    endpoints = [ep for claim in registry["claims"] if claim["project"] == PROJECT for ep in claim.get("endpoints", [])]
    require(project["roots"] == spec["roots"] and len(endpoints) == len(set(endpoints)) == 29 and
            endpoints == project["endpoints"] == final["public_endpoints"], "exact roots and 29 endpoints")
    audit_source = members[FRESH + PROJECT + "/source/ProjectAudit.lean"]
    require(audit_source == members[STRICT + "source/ProjectAudit.lean"] and
            sha(audit_source) == strict["sources"]["ProjectAudit"]["sha256"] ==
            final["generated_audit_source_sha256"] == "2b09bd716fc3964f4e33988c3b0acef3842479e1f7b190ce4feb1850ece8d56b" and
            len(audit_source) == strict["sources"]["ProjectAudit"]["bytes"] == 3230, "exact generated audit identity")
    expected_tail = """
  let allowed : List Name := [@@propext, @@Classical.choice, @@Quot.sound]
  let mut count := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        match info with
        | .axiomInfo v =>
          if v.isUnsafe then logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {mod} {name}"
          else throwError m!"CUSTOM_AXIOM {mod} {name}"
        | .thmInfo _ =>
          count := count + 1
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          for ax in axl do
            if !(union.contains ax) then union := ax :: union
          if axl.any (fun ax => !(allowed.contains ax)) then throwError m!"DISALLOWED_AXIOMS {mod} {name} : {axl}"
          logInfo m!"AUDIT_THEOREM {mod} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
""".replace("@@", chr(96) * 2)
    expected_audit = ("\n".join("import " + module for module in spec["roots"]) +
                      "\nimport Lean\nopen Lean Elab Command\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\n" +
                      "\n".join("#check " + ep for ep in endpoints) +
                      "\nrun_cmd do\n  let env ← getEnv\n  let selected : List String := " +
                      json.dumps(order) + expected_tail).encode("utf-8")
    require(audit_source == expected_audit, "exact intended full module-origin audit program")
    canonical_log = members[FRESH + PROJECT + "/logs/ProjectAudit.log"]
    strict_log = members[STRICT + "logs/ProjectAudit.log"]
    require(canonical_log == strict_log, "complete audit logs byte-identical")
    canonical_map, canonical_unsafe = parse_audit(canonical_log.decode("utf-8"), "canonical")
    strict_map, strict_unsafe = parse_audit(strict_log.decode("utf-8"), "strict")
    require(canonical_map == strict_map, "full theorem-to-axiom maps equal")
    require(canonical_unsafe == strict_unsafe ==
            sorted(tuple(row) for row in project["unsafe_implementation_axioms"]) ==
            sorted(tuple(row) for row in final["unsafe_implementation_axioms"]),
            "full unsafe declaration sets agree")
    require(not any(module in NEW for module, name in canonical_unsafe), "no new-module unsafe implementation declaration")
    counts = collections.Counter(row["module"] for row in canonical_map.values())
    require(set(counts) == set(modules), "all twelve selected modules represented in audit")
    for module in modules:
        require(counts[module] == final["modules"][module]["theorem_count"] ==
                original["published_sources"][module]["theorem_count"], "per-module theorem count agrees", module)
    require(set(endpoints) <= set(canonical_map), "all endpoints in complete audit")
    prelude = re.split(r"^(?:AUDIT_THEOREM|UNSAFE_IMPLEMENTATION_AXIOM) ", canonical_log.decode("utf-8"), maxsplit=1, flags=re.M)[0]
    require(all(any(line.startswith(ep + " ") or line.startswith(ep + ":") for line in prelude.splitlines())
                for ep in endpoints), "actual type-check output covers all 29 endpoints")
    require(project["theorem_count"] == strict["theorem_count"] == final["theorem_count"] == len(canonical_map),
            "receipt counts equal independently parsed map")

    require(canonical["compiler"] == strict["compiler"] == final["compiler"], "recorded compiler identities agree")
    lean_paths = [path for path in canonical["compiler"]["files"] if path.endswith("/bin/lean")]
    require(len(lean_paths) == 1 and canonical["compiler"]["version"] ==
            "Lean (version 4.19.0, x86_64-unknown-linux-gnu, commit 6caaee842e94, Release)",
            "recorded official compiler path and version")
    lean = lean_paths[0]
    require(sha(members[FRESH + "verification.json"]) == strict["original_verification_sha256"] ==
            final["runs"]["unchanged"]["receipt_sha256"], "canonical receipt linked by actual bytes")
    require(sha(members[STRICT + "strict-verification.json"]) ==
            final["runs"]["explicit_trust_zero"]["receipt_sha256"], "strict receipt linked by actual bytes")
    command_rows, driver_rows = [], []
    for run, receipt, prefix, count in [("canonical", project, FRESH, 13), ("strict", strict, STRICT, 14)]:
        commands = receipt["commands"]
        labels = (["official-help"] if run == "strict" else []) + order + ["ProjectAudit"]
        require(len(commands) == count and [row["label"] for row in commands] == labels,
                run + " exact command count and sequence")
        for row in commands:
            label = row["label"]
            argv = [lean]
            if label == "official-help":
                argv += ["--help"]
            else:
                if run == "strict":
                    argv += ["--trust=0"]
                argv += ["-j1", "-DElab.async=false"]
                if label != "ProjectAudit":
                    argv += ["-o", label + ".olean"]
                argv += [label + ".lean"]
            require(row["argv"] == argv and row["exit_code"] == 0 and row["elapsed_seconds"] >= 0,
                    run + " exact actual command and zero exit", label)
            log_path = prefix + row["log"]
            data = members[log_path]
            require(sha(data) == row["log_sha256"], run + " actual complete command log hash", label)
            text = data.decode("utf-8")
            require(not re.search(r"\berror:|^error\b|^FAIL:|declaration uses ['\"]sorry['\"]|\bsorryAx\b|^CUSTOM_AXIOM|^DISALLOWED_AXIOMS",
                                  text, re.M | re.I), run + " no failure diagnostic", label)
            command_rows.append({"run": run, "label": label, "argv": argv, "exit_code": 0,
                                 "log_member": log_path, "log_bytes": len(data), "log_sha256": sha(data),
                                 "warning_count": len(re.findall(r"\bwarning:", text, re.I))})
        driver_name = "verification/" + ("fresh-scope105-001" if run == "canonical" else "strict-scope105-001")
        driver = json.loads(members[driver_name + ".driver.json"])
        require(driver["status"] == "completed" and driver["exit_code"] == 0 and driver["source_head"] == CHECKPOINT,
                run + " driver completion receipt")
        expected_lines = [((PROJECT + " ") if run == "canonical" else "") + label + " exit=0" for label in labels]
        require(members[driver_name + ".driver.log"].decode("utf-8").splitlines() == expected_lines,
                run + " actual driver log agrees with every command exit")
        require(driver["command"][0] == "python3" and "--check-only" not in driver["command"] and
                driver["command"][driver["command"].index("--project") + 1] == PROJECT,
                run + " actual scoped proof execution selected")
        script_path = "proofs/verify_project__214bf7673efe116b.py" if run == "canonical" else CONTRIB + "/verification/replay_strict_trust0.py"
        require(driver["command"][1].endswith(script_path), run + " driver script provenance")
        start = datetime.datetime.fromisoformat(driver["started_at_utc"])
        end = datetime.datetime.fromisoformat(driver["finished_at_utc"])
        require(start < end and abs((end - start).total_seconds() - driver["elapsed_seconds"]) < 0.1,
                run + " consistent driver timestamps and elapsed time")
        driver_rows.append({"run": run, "source_checkpoint": driver["source_head"], "exit_code": 0,
                            "started_utc": driver["started_at_utc"], "finished_utc": driver["finished_at_utc"],
                            "elapsed_seconds": driver["elapsed_seconds"], "driver_member": driver_name + ".driver.json"})
    require(datetime.datetime.fromisoformat(driver_rows[0]["finished_utc"]) <
            datetime.datetime.fromisoformat(driver_rows[1]["started_utc"]), "recorded runs sequential")
    for module in order + ["ProjectAudit"]:
        require(members[FRESH + PROJECT + "/logs/" + module + ".log"] ==
                members[STRICT + "logs/" + module + ".log"], "corresponding complete command logs identical", module)
    print_records = linked_records = 0
    for module in order:
        log = members[FRESH + PROJECT + "/logs/" + module + ".log"].decode("utf-8")
        pattern = r"^'([^']+)' (?:does not depend on any axioms|depends on axioms: \[([^\]]*)\])$"
        for match in re.finditer(pattern, log, re.M):
            name, dep_text = match.groups()
            deps = parse_axioms(dep_text or "")
            require(set(deps) <= ALLOWED, "direct print-axioms dependency policy", name)
            if name in canonical_map:
                require(deps == canonical_map[name]["axioms"], "direct print agrees with full theorem map", name)
                linked_records += 1
            print_records += 1

    verifier = (ROOT / "head-sources" / final["unchanged_verifier"]["path"]).read_bytes()
    helper = members["verification/replay_strict_trust0.py"]
    require(sha(verifier) == final["unchanged_verifier"]["sha256"] ==
            "c047ff1ff1fe12b2c2094ca5f36af871b1c6faf89db593a102f9c2f7d48cc98a", "canonical verifier source pin")
    require(sha(helper) == final["explicit_replay_helper"]["sha256"] ==
            "5836600e3e5a70bc891e1c3e393c4314eb27d08a0e5674a11819c94b5b7c7e6f", "retained replay helper source pin")
    require(b"out.mkdir(parents=True, exist_ok=False)" in verifier and b"source.mkdir()" in verifier and
            b"'LEAN_PATH': str(source)" in verifier and b"for module in order:" in verifier,
            "source inspection support: canonical newly staged source compilation")
    require(b"output.mkdir(parents=True, exist_ok=False)" in helper and b"source.mkdir()" in helper and
            b"'LEAN_PATH': str(source)" in helper and b"'--trust=0'" in helper,
            "source inspection support: replay newly staged source compilation")
    require(not any(name.endswith(("failure.txt", ".olean", ".ilean", ".o")) for name in members),
            "archive scope excludes compiled outputs and contains no failure record")
    new_count = sum(counts[module] for module in NEW)
    require(new_count == 112, "five new decoder modules total 112 audited theorem constants")
    full_map = {name: canonical_map[name] for name in sorted(canonical_map)}
    strict_map = {name: strict_map[name] for name in sorted(strict_map)}
    write_json(ROOT / "canonical-theorem-axiom-map.json", full_map)
    write_json(ROOT / "strict-theorem-axiom-map.json", strict_map)
    write_json(ROOT / "unsafe-implementation-declarations.json",
               [{"module": module, "name": name} for module, name in canonical_unsafe])
    result = {
        "schema": "agent50-pr134-retained-evidence-check-v1",
        "status": "PASS_RETAINED_EVIDENCE_BYTES_AND_AUDIT_COVERAGE",
        "agent": "Agent #50/session4dce66859b6c", "delivery_owner": "Agent #18/session1a324de41cc8",
        "pr_number": 134, "source_head": HEAD, "recorded_source_checkpoint": CHECKPOINT,
        "archive": {"bytes": len(archive), "sha256": sha(archive), "git_blob": blob(archive),
                    "members": len(members), "uncompressed_member_bytes": sum(map(len, members.values())),
                    "original_manifest_entries": len(original["files"]), "direct_copies": 4},
        "run_file_index_entries": index_counts, "sources": source_rows, "registry_sha256": sha(registry_bytes),
        "audit_source_sha256": sha(audit_source), "audit_log_sha256": sha(canonical_log),
        "theorem_count": len(full_map), "per_module_theorem_counts": {module: counts[module] for module in order},
        "new_decoder_theorem_count": new_count, "public_endpoint_count": len(endpoints),
        "full_theorem_axiom_maps_equal": True, "full_audit_logs_byte_identical": True,
        "axiom_union": sorted(ALLOWED), "forbidden_theorem_dependency_count": 0,
        "unsafe_implementation_declaration_count": 22, "new_decoder_unsafe_implementation_declaration_count": 0,
        "direct_print_axioms_records_checked": print_records,
        "direct_print_axioms_records_linked_to_full_map": linked_records,
        "commands": command_rows, "drivers": driver_rows,
        "compiler_identity_status": "Recorded version and five file digests agree; runtime binaries were not rehashed here.",
        "canonical_verifier_sha256": sha(verifier), "strict_helper_sha256": sha(helper),
        "source_snapshots_at_head": "All twelve source modules and the registry match H byte for byte.",
        "execution_scope": "Python standard-library archive, hash, JSON, and retained-log validation only.",
        "lean_executed_here": False, "repository_code_executed_here": False,
        "imported_proof_rechecking_claimed": False, "repository_wide_pass_claimed": False,
        "current_base_combination_checked": False,
        "limitations": [
            "Retained evidence validation, not a new Lean compilation or independent runtime binary authentication.",
            "The recorded fresh-source commands and actual module-origin axiom audit are the evidence; --trust=0 or help wording alone does not establish imported-proof rechecking.",
            "No assertion about historical attempts outside this exact 71-member archive.",
            "No ownership takeover, readiness transition, merge claim, or current-target combined-tree validation."
        ],
        "checks_passed": len(CHECKS), "failed_checks": 0
    }
    write_json(ROOT / "results.json", result)
    write_json(ROOT / "checks.json", CHECKS)
    summary_keys = ["status", "source_head", "archive", "theorem_count", "per_module_theorem_counts",
                    "new_decoder_theorem_count", "public_endpoint_count", "full_theorem_axiom_maps_equal",
                    "axiom_union", "forbidden_theorem_dependency_count", "unsafe_implementation_declaration_count",
                    "new_decoder_unsafe_implementation_declaration_count", "direct_print_axioms_records_checked",
                    "direct_print_axioms_records_linked_to_full_map", "checks_passed", "failed_checks"]
    print(json.dumps({key: result[key] for key in summary_keys}, indent=2))

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
exit_code = 0
with (ATTEMPT / "stdout.log").open("x", encoding="utf-8") as stdout, (ATTEMPT / "stderr.log").open("x", encoding="utf-8") as stderr:
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        try:
            main()
        except BaseException:
            traceback.print_exc()
            write_json(ATTEMPT / "partial-checks.json", CHECKS)
            exit_code = 1
write_json(ATTEMPT / "exit.json", {"script": str(Path(__file__)), "script_sha256": sha(Path(__file__).read_bytes()),
           "started_utc": started, "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
           "exit_code": exit_code, "execution": "Python standard-library data checks only; no repository code or Lean."})
print((ATTEMPT / "stdout.log").read_text())
print((ATTEMPT / "stderr.log").read_text(), file=sys.stderr)
sys.exit(exit_code)
