#!/usr/bin/env python3
"""Independently validate and retain PR134 archive bytes; never execute archive code."""
import base64
import contextlib
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import sys
import tarfile
import traceback

ROOT = Path(sys.argv[1])
ATTEMPT = ROOT / "checker-attempts" / "001-archive-structure"
ATTEMPT.mkdir(parents=True, exist_ok=False)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def git_blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode("ascii") + b"\0" + data).hexdigest()

def write_json(path, value):
    with path.open("x", encoding="utf-8") as out:
        json.dump(value, out, indent=2, ensure_ascii=False)
        out.write("\n")

def main():
    manifest = json.loads((ROOT / "inputs/VERIFICATION_ARCHIVE.json").read_bytes())
    assert manifest["schema"] == "agent105-verification-archive-v1"
    parts = sorted((ROOT / "retrieval").glob("archive-base64-part-*.txt"))
    assert len(parts) == 6
    encoded = b"".join(path.read_bytes() for path in parts)
    archive = base64.b64decode(b"".join(encoded.split()), validate=True)
    assert len(archive) == manifest["archive"]["bytes"] == 174360
    assert sha(archive) == manifest["archive"]["sha256"] == "068b07e5af5aabd6390d9e8636ce8f1efecef450bbeec04af4dfd2782aed23d9"
    assert git_blob(archive) == manifest["archive"]["git_blob"] == "6edcaec03b229e117613d57df9ad22f4c43e97b3"
    assert archive[:3] == b"\x1f\x8b\x08"
    assert archive[3] & 0x08 == 0
    assert int.from_bytes(archive[4:8], "little") == 0
    (ROOT / "inputs/verification-evidence.tar.gz").open("xb").write(archive)
    with gzip.GzipFile(fileobj=io.BytesIO(archive), mode="rb") as stream:
        tar_bytes = stream.read(2 * 1024 * 1024 + 1)
        assert len(tar_bytes) <= 2 * 1024 * 1024
        assert stream.read(1) == b""
    expected = {item["archive_member"]: item for item in manifest["members"]}
    assert len(expected) == len(manifest["members"]) == 71
    members = {}
    rows = []
    with tarfile.open(fileobj=io.BytesIO(tar_bytes), mode="r:") as tar:
        entries = tar.getmembers()
        assert len(entries) == 71
        for entry in entries:
            name = entry.name
            pure = PurePosixPath(name)
            assert not pure.is_absolute() and name == pure.as_posix()
            assert ".." not in pure.parts and "." not in pure.parts
            assert pure.parts[0] == "verification"
            assert name not in members
            assert entry.isfile() and not entry.issym() and not entry.islnk()
            assert entry.mode == 0o644 and entry.uid == 0 and entry.gid == 0 and entry.mtime == 0
            assert name in expected
            wanted = expected[name]
            assert entry.size == wanted["bytes"]
            with tar.extractfile(entry) as stream:
                data = stream.read(entry.size + 1)
            assert len(data) == entry.size and sha(data) == wanted["sha256"]
            members[name] = data
            rows.append({"member": name, "bytes": len(data), "sha256": sha(data), "status": "PASS"})
    assert set(members) == set(expected)
    assert sum(map(len, members.values())) == manifest["archive"]["uncompressed_member_bytes"] == 929758
    original = manifest["original_manifest"]
    assert sha(members[original["path"]]) == original["sha256"]
    assert len(members[original["path"]]) == original["bytes"]
    direct = []
    for item in manifest["direct_review_copies"]:
        data = (ROOT / "inputs" / item["contribution_relative_path"]).read_bytes()
        assert data == members[item["archive_member"]]
        assert len(data) == item["bytes"] and sha(data) == item["sha256"]
        direct.append({"file": item["contribution_relative_path"], "sha256": sha(data), "status": "PASS_BYTE_IDENTICAL"})
    for name, data in members.items():
        target = ROOT / "retained" / name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.open("xb").write(data)
    result = {
        "status": "PASS_COMPLETE_ARCHIVE_BYTES",
        "source_head": "ec7aa17a36548cc629d2a4a309e802406fc862e7",
        "source_checkpoint": manifest["source_checkpoint"],
        "archive_bytes": len(archive),
        "archive_sha256": sha(archive),
        "archive_git_blob": git_blob(archive),
        "regular_member_count": len(members),
        "uncompressed_member_bytes": sum(map(len, members.values())),
        "gzip_mtime": 0,
        "gzip_filename_header_absent": True,
        "tar_headers_checked": "All regular files, mode 0644, uid/gid/mtime zero, safe unique relative paths",
        "members": rows,
        "direct_copies": direct,
        "source_code_executed": False,
        "lean_executed": False,
    }
    write_json(ROOT / "archive-member-checks.json", result)
    print(json.dumps({k:v for k,v in result.items() if k not in {"members","direct_copies"}}, indent=2))
    selections = [
        "verification/fresh-scope105-001.driver.json",
        "verification/fresh-scope105-001.driver.log",
        "verification/strict-scope105-001.driver.json",
        "verification/strict-scope105-001.driver.log",
        "verification/fresh-scope105-001/agent105-numeric-decoder-9df76b/source/ProjectAudit.lean",
    ]
    for name in selections:
        print("\nFILE " + name + "\n" + members[name].decode("utf-8"))
    for name in [
        "verification/scope105-evidence-manifest.json",
        "verification/fresh-scope105-001/FILES.json",
        "verification/strict-scope105-001/FILES.json",
        "verification/strict-scope105-001/registry-used.json",
    ]:
        value = json.loads(members[name])
        print("\nJSON_SCHEMA " + name + "\n" + json.dumps(
            {"keys": list(value), "sample": {k: (v[:2] if isinstance(v, list) else v) for k,v in value.items()}}, indent=2))
    log = members["verification/fresh-scope105-001/agent105-numeric-decoder-9df76b/logs/ProjectAudit.log"].decode("utf-8")
    print("\nAUDIT_LOG_PREFIX\n" + log[:3500] + "\nAUDIT_LOG_SUFFIX\n" + log[-3500:])
    print("\nTOTAL_EVIDENCE_BYTES " + str(sum(p.stat().st_size for p in ROOT.rglob("*") if p.is_file())))

start = datetime.datetime.now(datetime.timezone.utc).isoformat()
exit_code = 0
with (ATTEMPT / "stdout.log").open("x", encoding="utf-8") as stdout, (ATTEMPT / "stderr.log").open("x", encoding="utf-8") as stderr:
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        try:
            main()
        except BaseException:
            traceback.print_exc()
            exit_code = 1
write_json(ATTEMPT / "exit.json", {
    "script": str(Path(__file__)),
    "started_utc": start,
    "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "exit_code": exit_code,
    "statement": "Python standard-library byte checks only; no repository code, Lean compiler, or retained helper executed.",
})
print((ATTEMPT / "stdout.log").read_text())
print((ATTEMPT / "stderr.log").read_text(), file=sys.stderr)
sys.exit(exit_code)
