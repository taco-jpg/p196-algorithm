#!/usr/bin/env python3
"""Independent finite data check of PR121's retained boundary controls.

No Lean or repository script is executed. Low digits use an inverse of 9 modulo
10**k, rather than the retained script's recurrence. High digits use successive
exact quotients. This is finite diagnostic evidence, not a universal proof.
Every bounded and long-pattern case is retained in the CSV output.
"""
import csv
import hashlib
from itertools import product
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
P = ROOT/'remote/proofs/contributions/agent-5/ordinary-stream-prefix-20261016'
RETAINED = json.loads((P/'review/boundary-controls.json').read_text())
PHASES = [2,4,6,8,10,12,14,16]
MIDDLES = [[],[0],[18],[1,1],[18,0,18],[0,18,18,0],[9,18,1]]


def value(word):
    result = 0
    for digit in reversed(word): result = 10*result + digit
    return result


def normalize(word):
    result, carry = [], 0
    for coefficient in word:
        total = coefficient + carry
        result.append(total % 10); carry = total // 10
    if carry: result.append(carry)
    return result


def pair(word):
    return [word[i]+word[-1-i] for i in range(len(word))]


def shape(B,c,gap,W):
    return B + [c]*(gap+2) + W + [c]*(gap+2) + B[::-1]


def stream_digits(B,c,count):
    n = len(B)
    numerator = 9*value(B) - c*10**n
    r = 9*value(B[::-1]) + c
    base = 9*10**n
    den = base*(10 if r >= base else 1)
    modulus = 10**count
    low_residue = (numerator*pow(9,-1,modulus)) % modulus
    low = [(low_residue//10**j)%10 for j in range(count)]
    high = [(r*10**(j+1)//den) - 10*(r*10**j//den) for j in range(count)]
    return low, high, [a+b for a,b in zip(low,high)]


def ordinary(n):
    return n+int(str(n)[::-1])


def digits(n):
    return [int(d) for d in str(n)[::-1]]


def realize(coefficients):
    result = [0]*len(coefficients)
    for i in range((len(coefficients)+1)//2):
        j = len(coefficients)-1-i
        a = coefficients[i]
        result[i] = a//2
        result[j] = a-result[i]
    assert pair(result) == coefficients
    assert all(0 <= d < 10 for d in result)
    return result


def trace(D,B,c,gap,W,count=None):
    count = len(B)+1 if count is None else count
    output = normalize(pair(D))
    low,high,predicted = stream_digits(B,c,count)
    return {'D_low_first':D,'B':B,'c':c,'gap_parameter':gap,'actual_band_length':gap+2,'W':W,
            'shape_holds':pair(D)==shape(B,c,gap,W),'input_decimal_digits':all(0<=d<10 for d in D),
            'input_positive_last':bool(D) and D[-1]>0,'numeral_D':value(D),'literal_reversed_word_numeral':value(D[::-1]),
            'ordinary_numeric_step':ordinary(value(D)),'reverseAddDigits_D':output,'output_numeral':value(output),
            'requested_prefix_length':count,'actual_raw_pair_prefix':pair(output)[:count],
            'low_stream':low,'high_stream':high,'stream_sum':predicted}


def main():
    stats = {key:0 for key in RETAINED['counts']}
    failures=[]
    raw_path=ROOT/'checks/boundary-cases-01.csv'
    rows=0
    with raw_path.open('x',newline='') as stream:
        writer=csv.writer(stream)
        writer.writerow(['family','case_id','B','phase','gap','W','actual_prefix','closed_form_stream_sum','canonical_realization','passed'])
        for n in range(3):
            for coefficients in product(range(19),repeat=n):
                B=list(coefficients)
                for c in PHASES:
                    for gap in [0,1,4]:
                        for W in MIDDLES:
                            output=normalize(shape(B,c,gap,W))
                            expected=stream_digits(B,c,n+1)[2]
                            observed=pair(output)[:n+1]
                            passed=observed==expected and len(observed)==n+1
                            stats['bounded_coefficient_word_cases']+=1
                            stats['zero_head_structural_cases']+=int(bool(B) and B[0]==0)
                            stats['empty_B_cases']+=int(not B)
                            stats['empty_W_cases']+=int(not W)
                            stats['negative_adic_numerator_cases']+=int(9*value(B)-c*10**n<0)
                            canonical=False
                            if W==W[::-1] and (not W or len(W)%2==0 or W[len(W)//2]%2==0):
                                D=realize(shape(B,c,gap,W))
                                if D and D[-1]>0:
                                    canonical=True
                                    passed=passed and output==digits(ordinary(value(D))) and bool(output) and output[-1]>0
                                    passed=passed and all(0<=d<10 for d in output) and value(output)==value(D)+value(D[::-1])
                                    stats['canonical_ordinary_realization_cases']+=1
                                else:
                                    passed=passed and bool(B) and B[0]==0
                            rows+=1
                            writer.writerow(['bounded',rows,json.dumps(B),c,gap,json.dumps(W),json.dumps(observed),json.dumps(expected),canonical,passed])
                            if not passed: failures.append({'row':rows,'B':B,'phase':c,'gap':gap,'W':W})
        for n in [7,40]:
            for c in PHASES:
                for B in [[0]*n,[18]*n,[c]*n,[18 if i%2 else 0 for i in range(n)]]:
                    for W in [[],[18]*30,[0,18]*15]:
                        for gap in [0,9]:
                            observed=pair(normalize(shape(B,c,gap,W)))[:n+1]
                            expected=stream_digits(B,c,n+1)[2]
                            passed=observed==expected
                            stats['long_pattern_cases']+=1; rows+=1
                            writer.writerow(['long',rows,json.dumps(B),c,gap,json.dumps(W),json.dumps(observed),json.dumps(expected),'not_claimed',passed])
                            if not passed: failures.append({'row':rows,'B':B,'phase':c,'gap':gap,'W':W})
    boundary_checks=[]
    for key in ['positive_last_counterexample','decimal_digits_counterexample','valid_exact_prefix','invalid_longer_prefix',
                'middle_bound_counterexample','neutral_phase_counterexample','allowed_zero_least_significant_digit']:
        expected=RETAINED[key]
        observed=trace(expected['D_low_first'],expected['B'],expected['c'],expected['gap_parameter'],expected['W'],expected['requested_prefix_length'])
        boundary_checks.append({'name':key,'passed':observed==expected,'observed':observed})
    for i,expected in enumerate(RETAINED['empty_B_and_W_nonvacuity']):
        observed=trace(expected['D_low_first'],expected['B'],expected['c'],expected['gap_parameter'],expected['W'],expected['requested_prefix_length'])
        boundary_checks.append({'name':'empty_B_and_W_nonvacuity_'+str(i),'passed':observed==expected,'observed':observed})
    short={'D':[1,9,1],'integer':191,'actual_band_length':1,'coefficient_word':pair([1,9,1]),
           'output_digits':normalize(pair([1,9,1])),'actual_prefix':pair(normalize(pair([1,9,1])))[:1],
           'invalid_stream_prefix':stream_digits([],2,1)[2]}
    boundary_checks.append({'name':'short_band_counterexample','passed':short==RETAINED['short_band_counterexample'],'observed':short})
    for i,expected in enumerate(RETAINED['empty_and_zero_digit_boundaries']):
        D=expected['D']
        observed={'D':D,'DecimalDigits':all(0<=x<10 for x in D),'PositiveLast':bool(D) and D[-1]>0,
                  'numeral':value(D),'literal_output':normalize(pair(D))}
        boundary_checks.append({'name':'empty_and_zero_digit_boundaries_'+str(i),'passed':observed==expected,'observed':observed})
    source_hashes={name:hashlib.sha256((P/name).read_bytes()).hexdigest() for name in ['RawPrefixStreams.lean','OrdinaryStreamStep.lean']}
    count_match=stats==RETAINED['counts']
    source_match=source_hashes==RETAINED['source_sha256']
    boundary_match=all(row['passed'] for row in boundary_checks)
    report={'schema_version':1,'status':'PASS_INDEPENDENT_FINITE_CONTROLS' if not failures and count_match and source_match and boundary_match else 'FAIL',
            'agent':'Agent #50 /root/pr121_evidence_check','head':'5c4d394f20b70547aa7cb8dd14091bcd391e424c',
            'proof_status':'Finite exact-integer checks only; no Lean or repository script executed.',
            'method':'Modular inverse low-digit extraction and successive exact-quotient high digits, independently written from inspected definitions.',
            'counts':stats,'counts_match_retained':count_match,'source_sha256':source_hashes,'source_hashes_match_retained':source_match,
            'raw_case_count':rows,'failed_cases':failures,'boundary_trace_checks':boundary_checks,
            'raw_cases':str(raw_path.relative_to(ROOT)),'raw_cases_sha256':hashlib.sha256(raw_path.read_bytes()).hexdigest(),
            'raw_cases_bytes':raw_path.stat().st_size}
    (ROOT/'checks/boundary-check-01.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in {'boundary_trace_checks','source_sha256'}},indent=2))
    return int(report['status']!='PASS_INDEPENDENT_FINITE_CONTROLS')


if __name__=='__main__':
    raise SystemExit(main())
