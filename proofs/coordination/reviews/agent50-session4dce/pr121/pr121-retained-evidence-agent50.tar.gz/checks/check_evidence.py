#!/usr/bin/env python3
"""Independent data-only retained-evidence checker for PR121; never invokes Lean.

All inputs are read from the exact-head connector snapshots under ../remote.
The only non-snapshot reads are the five already authorized pinned runtime files,
which are hashed as data in bounded blocks. Outputs remain in this evidence folder.
No repository Python code is imported or executed, and no source is modified.
"""
import argparse
import base64
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
REMOTE = ROOT / 'remote'
PACKAGE = 'proofs/contributions/agent-5/ordinary-stream-prefix-20261016'
P = REMOTE / PACKAGE
CAN = P / 'verification/canonical-published-source'
REV = P / 'review/strict-replay-01'
HEAD = '5c4d394f20b70547aa7cb8dd14091bcd391e424c'
FREEZE = '5b4238ebe95f5fb80512d1b1ad3dbe3b062279a3'
PROJECT = 'agent5-ordinary-stream-prefix'
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}
results = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()


def read_json(path):
    return json.loads(path.read_text())


def record(label, passed, **details):
    results.append({'check': label, 'passed': bool(passed), **details})
    return bool(passed)


def verify_file(label, path, expected_hash, expected_bytes=None, expected_blob=None):
    if not path.is_file():
        return record(label, False, path=str(path.relative_to(ROOT)), failure='MISSING_REFERENCED_FILE')
    data = path.read_bytes()
    observed = {'sha256': sha(data), 'bytes': len(data), 'git_blob': blob(data)}
    passed = observed['sha256'] == expected_hash
    if expected_bytes is not None:
        passed = passed and len(data) == expected_bytes
    if expected_blob is not None:
        passed = passed and observed['git_blob'] == expected_blob
    return record(label, passed, path=str(path.relative_to(ROOT)), expected_sha256=expected_hash,
                  expected_bytes=expected_bytes, expected_git_blob=expected_blob, observed=observed)


def mask_lean(text):
    """Independently mask nested comments and strings; preserve line positions."""
    output, i, depth, string = [], 0, 0, False
    while i < len(text):
        pair = text[i:i+2]
        if depth:
            if pair == '/-':
                depth += 1; output.extend('  '); i += 2
            elif pair == '-/':
                depth -= 1; output.extend('  '); i += 2
            else:
                output.append('\n' if text[i] == '\n' else ' '); i += 1
        elif string:
            if text[i] == '\\':
                output.extend('  '); i += 2
            else:
                string = text[i] != '"'; output.append('\n' if text[i] == '\n' else ' '); i += 1
        elif pair == '/-':
            depth = 1; output.extend('  '); i += 2
        elif pair == '--':
            end = text.find('\n', i)
            if end < 0: end = len(text)
            output.extend(' ' * (end-i)); i = end
        elif text[i] == '"':
            string = True; output.append(' '); i += 1
        else:
            output.append(text[i]); i += 1
    if depth or string: raise ValueError('Unterminated source comment or string')
    return ''.join(output)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    registry = read_json(REMOTE / 'proofs/Agent5OrdinaryStreamPrefix.registry.json')
    top = read_json(REMOTE / 'proofs/Agent5OrdinaryStreamPrefix.verification.json')
    modules = registry['projects'][PROJECT]['modules']
    exports = registry['claims'][0]['endpoints']
    canonical = read_json(CAN / 'verification.json')
    cp = canonical['projects'][PROJECT]
    review = read_json(REV / 'verification.json')
    inventory = read_json(P / 'review/semantic-source-inventory.json')
    pub = read_json(P / 'PUBLICATION.json')
    changed = read_json(ROOT / 'raw-changed-filenames.json')['structuredContent']['filenames']
    info = read_json(ROOT / 'raw-pr-info.json')['structuredContent']
    record('exact_PR_head_and_diff_scope', info['head_sha'] == HEAD and info['changed_files'] == 92
           and info['additions'] == 10638 and info['deletions'] == 0,
           head=info['head_sha'], base=info['base_sha'], changed_files=info['changed_files'],
           additions=info['additions'], deletions=info['deletions'])
    downloads = read_json(ROOT / 'raw-file-fetches.json')
    record('exact_head_92_downloads', downloads['head'] == HEAD and len(downloads['files']) == 92)
    for item in downloads['files']:
        content = item['result']['structuredContent']
        data = base64.b64decode(content['content'])
        record('download_blob:' + item['path'], blob(data) == content['sha'] and
               (REMOTE / item['path']).read_bytes() == data,
               path=item['path'], bytes=len(data), sha256=sha(data), git_blob=blob(data))
    patches = read_json(ROOT / 'raw-pr-patch-complete.json')['structuredContent']['patches']
    record('complete_patch_inventory', len(patches) == 92 and {p['filename'] for p in patches} == set(changed))
    additions = 0
    for item in patches:
        path, patch = item['filename'], item.get('patch') or ''
        data = (REMOTE / path).read_bytes()
        added = [line[1:] for line in patch.splitlines() if line.startswith('+')]
        significant = [line for line in patch.splitlines() if not line.startswith(('+', '@@', '\\'))]
        content_lines = data.decode().splitlines()
        passed = added == content_lines and not significant
        record('full_added_file_patch:' + path, passed, added_lines=len(added), source_lines=len(content_lines),
               non_addition_lines=significant, sha256=sha(data))
        additions += len(added)
    record('complete_patch_added_line_total', additions == 10638, observed=additions)

    manifest_summaries = []
    for rel, parent, mapping in [
        ('PUBLICATION.json', REMOTE, pub['files']),
        ('verification/canonical-published-source/FILES.json', CAN, read_json(CAN / 'FILES.json')['files']),
        ('review/strict-replay-01/FILES.json', REV, read_json(REV / 'FILES.json')),
        ('author/raw-prefix/artifact-index.json', P / 'author/raw-prefix', read_json(P / 'author/raw-prefix/artifact-index.json')),
    ]:
        start = len(results)
        for path, expected in mapping.items():
            if isinstance(expected, str): expected = {'sha256': expected}
            verify_file('manifest:' + rel + ':' + path, parent / path, expected['sha256'], expected.get('bytes'))
        manifest_summaries.append({'manifest': rel, 'entries': len(mapping), 'passed': all(r['passed'] for r in results[start:])})
    for rel in ['author/arithmetic/MANIFEST.sha256', 'review/REVIEW_MANIFEST.sha256']:
        manifest = P / rel; start = len(results); entries = 0
        for line in manifest.read_text().splitlines():
            expected_hash, path = re.split(r'\s+', line, maxsplit=1)
            verify_file('manifest:' + rel + ':' + path, manifest.parent / path, expected_hash)
            entries += 1
        manifest_summaries.append({'manifest': rel, 'entries': entries, 'passed': all(r['passed'] for r in results[start:])})
    record('publication_covers_all_other_changed_files', set(pub['files']) == set(changed) - {PACKAGE + '/PUBLICATION.json'},
           publication_entries=len(pub['files']))
    can_files = read_json(CAN / 'FILES.json')
    record('canonical_archive_scope_is_explicit', len(can_files['files']) == 18 and
           can_files['exact_published_source_commit'] == FREEZE and
           'registered mathematical source is already retained at its exact repository path' in can_files['excluded'],
           excluded=can_files['excluded'])

    source_rows = []
    masks = {}
    for module, spec in modules.items():
        data = (REMOTE / spec['path']).read_bytes()
        verify_file('registered_source:' + module, REMOTE / spec['path'], spec['sha256'], expected_blob=spec['git_blob'])
        verify_file('retained_review_source:' + module, REV / ('source/' + module + '.lean'), spec['sha256'], expected_blob=spec['git_blob'])
        code = mask_lean(data.decode()); masks[module] = code
        forbidden = re.findall(r'\b(?:sorry|admit|axiom|sorryAx|native_decide|ofReduceBool|skipKernelTC|unsafe)\b', code)
        imports = [part for line in re.findall(r'^\s*import\s+([^\n]+)', code, re.M) for part in line.split()]
        record('source_scan_and_imports:' + module, not forbidden and imports == spec['imports'], forbidden=forbidden, imports=imports)
        for label, rec in [('canonical', cp['sources'][module]), ('review', review['sources'][module]), ('inventory', inventory['modules'][module])]:
            record('source_record:' + label + ':' + module, rec['path'] == spec['path'] and rec['sha256'] == spec['sha256']
                   and rec['imports'] == spec['imports'] and (not rec.get('build_sha256') or rec['build_sha256'] == spec['sha256'])
                   and not rec.get('adapter'))
        source_rows.append({'module': module, **spec, 'bytes': len(data), 'canonical_build_source_sha256': cp['sources'][module]['build_sha256'],
                            'review_snapshot': str((REV / ('source/' + module + '.lean')).relative_to(ROOT))})
    order, active, visited = [], set(), set()
    def visit(module):
        if module not in modules:
            record('external_standard_import:' + module, module.split('.')[0] in {'Init', 'Std', 'Lean'})
            return
        if module in active: raise ValueError('Dependency cycle: ' + module)
        if module in visited: return
        active.add(module)
        for dep in modules[module]['imports']: visit(dep)
        active.remove(module); visited.add(module); order.append(module)
    visit('OrdinaryStreamStep')
    record('complete_fifteen_module_closure', len(order) == 15 and visited == set(modules) and
           order == cp['build_order'] == review['build_order'] == inventory['build_order'], order=order)

    for module, contracts in inventory['new_source_contracts'].items():
        code = masks[module]
        for contract in contracts:
            local = contract['name'].rsplit('.', 1)[1]
            match = re.search(r'^theorem\s+' + re.escape(local) + r'\b', code, re.M)
            delimiter = re.search(r':=\s+by\b', code[match.start():]) if match else None
            actual = code[match.start():match.start()+delimiter.start()].strip() if delimiter else None
            record('export_contract:' + contract['name'], actual == contract['contract'] and
                   sha(contract['contract'].encode()) == contract['contract_sha256'],
                   expected_sha256=contract['contract_sha256'], actual_sha256=sha(actual.encode()) if actual else None)
    record('six_export_maps', len(exports) == 6 and len(set(exports)) == 6 and exports == review['expected_exports'] ==
           cp['endpoints'] == inventory['new_exports'])

    top_pairs = [
        ('registry_sha256', REMOTE / 'proofs/Agent5OrdinaryStreamPrefix.registry.json'),
        ('independent_report_sha256', REMOTE / top['independent_report']),
        ('independent_semantic_review_sha256', REMOTE / top['independent_semantic_review']),
        ('independent_review_manifest_sha256', P / 'review/REVIEW_MANIFEST.sha256'),
        ('parent_canonical_report_sha256', REMOTE / top['parent_canonical_report']),
    ]
    for key, path in top_pairs: verify_file('top_level_reference:' + key, path, top[key])
    verify_file('canonical_registry_hash', REMOTE / 'proofs/Agent5OrdinaryStreamPrefix.registry.json', canonical['registry_sha256'])
    verify_file('inventory_registry_hash', P / 'review/registry.json', inventory['registry_sha256'])
    verify_file('review_registry_snapshot', REV / review['registry']['snapshot_path'], review['registry']['sha256'])
    verify_file('prior_audit_template', REMOTE / inventory['audit_template_path'], inventory['audit_template_sha256'])
    verify_file('inherited_artifact_index', REMOTE / inventory['inherited_artifact_index_path'], inventory['inherited_artifact_index_sha256'])
    verify_file('publication_canonical_receipt', CAN / 'verification.json', pub['canonical_receipt_sha256'])
    record('canonical_exact_published_source_identity', canonical['source_commit'] == FREEZE and canonical['source_tree_clean']
           and top['published_source_commit'] == FREEZE and pub['verified_source_commit'] == FREEZE,
           source_commit=canonical['source_commit'], source_tree_clean=canonical['source_tree_clean'])

    command_sets = [
        ('canonical', cp['commands'], CAN),
        ('review', review['commands'], REV),
        ('review_preflight', review['preflight_commands'], REV),
        ('author_arithmetic_baseline', read_json(P / 'author/arithmetic/baseline/baseline.json')['runs'], P / 'author/arithmetic/baseline'),
    ]
    command_rows = []
    for group, commands, parent in command_sets:
        for item in commands:
            name = item.get('label', item.get('module'))
            argv = item.get('argv', item.get('command'))
            verify_file('command_log:' + group + ':' + name, parent / item['log'], item['log_sha256'])
            record('command_exit:' + group + ':' + name, item['exit_code'] == 0, argv=argv, exit_code=item['exit_code'],
                   elapsed_seconds=item['elapsed_seconds'])
            command_rows.append({'group': group, 'module': name, **item})
    record('canonical_full_fresh_command_coverage', [r['label'] for r in cp['commands']] == order + ['ProjectAudit'] and
           all(r['argv'] == [r['argv'][0], '-j1', '-DElab.async=false', '-o', r['label']+'.olean', r['label']+'.lean']
               for r in cp['commands'][:-1]), flags=['-j1', '-DElab.async=false'], command_count=len(cp['commands']))
    record('review_exact_partial_replay_coverage', [r['label'] for r in review['commands']] == ['RawPrefixStreams','OrdinaryStreamStep','ProjectAudit'] and
           review['freshly_compiled_modules'] == ['RawPrefixStreams','OrdinaryStreamStep'] and
           review['is_fresh_full_dependency_rebuild'] is False and len(review['inherited_objects']) == 13 and
           all(r['argv'][1:4] == ['--trust=0','-j1','-DElab.async=false'] for r in review['commands']),
           fresh_modules=review['freshly_compiled_modules'], inherited_count=len(review['inherited_objects']))
    for rel, source, log in [
        ('author/arithmetic/attempt01/receipt.json', P/'OrdinaryStreamStep.lean', P/'author/arithmetic/attempt01/compile.log'),
        ('author/arithmetic/audit/receipt.json', P/'author/arithmetic/audit/OrdinaryStreamStepAxiomAudit.lean', P/'author/arithmetic/audit/OrdinaryStreamStepAxiomAudit.log'),
    ]:
        receipt = read_json(P/rel)
        verify_file('author_receipt_source:' + rel, source, receipt['source_sha256'])
        verify_file('author_receipt_log:' + rel, log, receipt['log_sha256'])
        record('author_receipt_exit:' + rel, receipt['exit_code'] == 0 and receipt['command'][1:4] == ['--trust=0','-j1','-DElab.async=false'])
    raw_receipt = read_json(P/'author/raw-prefix/attempts/001/receipt.json')
    verify_file('raw_author_receipt_source', P/'author/raw-prefix/attempts/001/RawPrefixStreams.lean', raw_receipt['source_sha256'])
    record('raw_author_receipt_exit', raw_receipt['exit_code'] == 0 and raw_receipt['command'][1:4] == ['--trust=0','-j1','-DElab.async=false'])

    inheritance = read_json(P/'author/raw-prefix/inherited-artifacts.json')
    inherited = {r['module']: r for r in inheritance['modules'] + inheritance['new_arithmetic_dependencies']}
    for module, observed in review['inherited_objects'].items():
        source = inherited[module]; spec = modules[module]
        has_prior_object = 'olean_sha256' in source
        record('inherited_object_record:' + module, observed['source_sha256'] == source['source_sha256'] == spec['sha256']
               and source['git_blob'] == spec['git_blob'] and source['repository_source'] == spec['path'] and
               observed['preexisting_author_olean_hash_verified'] == has_prior_object and
               (not has_prior_object or observed['olean_sha256_at_import'] == source['olean_sha256']),
               prior_object_hash_present=has_prior_object, object_hash_at_import=observed['olean_sha256_at_import'],
               object_bytes_rechecked_here=False)
    for item in inheritance['new_arithmetic_dependencies']:
        verify_file('original_arithmetic_archive:' + item['module'], REMOTE/item['source_map_preserved'], item['source_sha256'], expected_blob=item['git_blob'])
    verify_file('identical_alternate_core', REMOTE/inheritance['core_snapshot_crosscheck']['review_snapshot'], modules['ExteriorCore']['sha256'])
    record('raw_author_object_inheritance_record', read_json(P/'author/arithmetic/raw-prefix-inheritance.json')['olean_sha256'] == raw_receipt['olean_sha256'],
           object_bytes_rechecked_here=False)
    for rel in ['author/arithmetic/baseline/inherited-artifacts.json','review/strict-replay-01/provenance/author-inherited-artifacts.json']:
        record('identical_inheritance_record:' + rel, (P/rel).read_bytes() == (P/'author/raw-prefix/inherited-artifacts.json').read_bytes())
    for rel in ['author/raw-prefix/baseline.json','review/strict-replay-01/provenance/author-baseline.json']:
        record('identical_baseline_receipt:' + rel, (P/rel).read_bytes() == (P/'author/arithmetic/baseline/baseline.json').read_bytes())

    audit_source = (P/'review/ProjectAudit.lean').read_bytes()
    for path in [REV/'source/ProjectAudit.lean', CAN/(PROJECT+'/source/ProjectAudit.lean')]:
        record('identical_generated_audit:' + str(path.relative_to(ROOT)), path.read_bytes() == audit_source)
    record('unchanged_canonical_audit_body', audit_source.decode().split('  let allowed : List Name :=',1)[1] ==
           (REMOTE/inventory['audit_template_path']).read_text().split('  let allowed : List Name :=',1)[1])
    selected_match = re.search(r'let selected : List String := (\[[^\n]+\])', audit_source.decode())
    checks = re.findall(r'^#check\s+(\S+)\s*$', audit_source.decode(), re.M)
    record('generated_audit_exact_scope', checks == exports and json.loads(selected_match.group(1)) == order)
    audit_logs = {}
    for label, path in [('canonical',CAN/(PROJECT+'/logs/ProjectAudit.log')),('review',REV/'logs/ProjectAudit.log')]:
        text = path.read_text()
        matches = re.findall(r'^AUDIT_THEOREM (\S+) (\S+) : \[([^\]]*)\]$', text, re.M)
        declarations = [{'module': module, 'name': name, 'axioms': [a.strip() for a in axes.split(',') if a.strip()],
                         'fixed_export': name in exports} for module,name,axes in matches]
        summaries = re.findall(r'^FULL_MODULE_AUDIT theorems=(\d+) union=\[([^\]]*)\]$',text,re.M)
        union = set().union(*(set(d['axioms']) for d in declarations))
        unsafe = [list(x) for x in re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$',text,re.M)]
        names = [d['name'] for d in declarations]
        record('actual_complete_axiom_audit:' + label, len(declarations)==267 and len(set(names))==267 and len(summaries)==1 and
               int(summaries[0][0])==267 and set(exports)<=set(names) and union==ALLOWED and
               all(d['module'] in modules and set(d['axioms'])<=ALLOWED for d in declarations) and
               not re.search(r'CUSTOM_AXIOM|DISALLOWED_AXIOMS|sorryAx',text) and
               not ({u[1] for u in unsafe} & union), theorem_count=len(declarations), fixed_exports=sum(d['fixed_export'] for d in declarations),
               axiom_union=sorted(union), unsafe_implementation_axioms=unsafe,
               module_theorem_counts=dict(sorted(Counter(d['module'] for d in declarations).items())))
        audit_logs[label]={'declarations':declarations,'unsafe_implementation_axioms':unsafe,'sha256':sha(path.read_bytes())}
    record('audits_byte_identical', audit_logs['canonical']['sha256']==audit_logs['review']['sha256'])
    record('structured_review_audit_matches_raw_log', review['audit']['declarations']==audit_logs['review']['declarations'] and
           review['audit']['unsafe_implementation_axioms']==audit_logs['review']['unsafe_implementation_axioms'])
    record('canonical_audit_summary_matches_raw_log', cp['theorem_count']==267 and cp['unsafe_implementation_axioms']==audit_logs['canonical']['unsafe_implementation_axioms'])

    compiler = canonical['compiler']
    record('canonical_review_toolchain_fingerprints_identical', compiler['files']==review['toolchain']['files'] and compiler['version']==review['toolchain']['version'])
    runtime_files=[]
    for name, expected in compiler['files'].items():
        path=Path(name); h=hashlib.sha256()
        if path.is_file():
            with path.open('rb') as stream:
                while True:
                    block=stream.read(1024*1024)
                    if not block: break
                    h.update(block)
            observed=h.hexdigest(); exists=True
        else: observed=None; exists=False
        runtime_files.append({'path':name,'exists':exists,'expected_sha256':expected,'observed_sha256':observed,'matches':observed==expected})
        record('pinned_runtime_data_hash:' + name, observed==expected, expected_sha256=expected, observed_sha256=observed,
               compiler_executed=False)
    record('retained_scope_labels', canonical['repository_wide_pass'] is False and top['repository_wide_pass'] is False and
           review['repository_wide_pass'] is False and registry['catalogue_complete'] is False and
           top['actual_canonical_executor']=='Agent #5 parent' and canonical['agent']=='Agent #1',
           actual_canonical_executor=top['actual_canonical_executor'], inherited_verifier_metadata=canonical['agent'])
    failures=[r for r in results if not r['passed']]
    report={'schema_version':1,'head':HEAD,'mathematical_source_freeze':FREEZE,'status':'PASS_RETAINED_EVIDENCE_CHECK' if not failures else 'FINDINGS',
            'new_Lean_executions':0,'executed_repository_scripts':[], 'check_count':len(results),'failure_count':len(failures),
            'failures':failures,'manifest_summaries':manifest_summaries,'source_identity_rows':source_rows,
            'command_rows':command_rows,'actual_audits':audit_logs,'runtime_files':runtime_files,'checks':results,
            'coverage_limits':['Retained Lean executions are reused, not rerun by Agent #50.',
                               'Thirteen imported .olean bytes are intentionally unretained and were not rehashed here; recorded cross-references were compared.',
                               'The independent reviewer freshly compiled two modules; the parent canonical run freshly compiled all fifteen project modules.',
                               'trust=0 alone is not evidence that imported theorem proofs were kernel rechecked.',
                               'Historical removed runtime download bytes were not available for a new hash check; the extracted pinned runtime was checked as data.',
                               'This checker does not decide mathematical meaning, current platform gates, or a current combined-tree merge.']}
    args.output.write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'status':report['status'],'checks':len(results),'failure_count':len(failures),
                      'manifest_summaries':manifest_summaries,'failures':failures},indent=2))
    return int(bool(failures))


if __name__=='__main__':
    raise SystemExit(main())
