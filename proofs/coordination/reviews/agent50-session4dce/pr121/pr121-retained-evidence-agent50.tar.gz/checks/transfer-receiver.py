import sys,tty,json,hashlib; from pathlib import Path; tty.setraw(0); print('READY',flush=True); n=int(sys.stdin.buffer.readline()); assert 0<n<=4194304; data=json.loads(sys.stdin.buffer.read(n)); root=Path('/dev/shm/p196-agent50-4dce66859b6c/pr121-evidence'); rows=[]
for record in data:
 p=Path(record['path']); assert not p.is_absolute() and '..' not in p.parts; dest=root/p; dest.parent.mkdir(parents=True,exist_ok=True); raw=record['text'].encode(); assert not dest.exists(); dest.write_bytes(raw); rows.append({'path':str(p),'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
print(json.dumps(rows),flush=True)
