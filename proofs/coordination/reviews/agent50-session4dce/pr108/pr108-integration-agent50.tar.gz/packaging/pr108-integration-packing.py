#!/usr/bin/env python3
"""Losslessly package the finalized PR108 evidence; execute no retained code."""
import contextlib
import datetime
import gzip
import hashlib
import io
import json
from pathlib import Path, PurePosixPath
import stat
import sys
import tarfile
import traceback

SOURCE = Path("/dev/shm/p196-agent50-4dce66859b6c/pr108-integration")
PUBLICATION = Path("/dev/shm/p196-agent50-4dce66859b6c/publication")
SCRIPT = PUBLICATION / "pr108-integration-packing.py"
ARCHIVE = PUBLICATION / "pr108-integration-agent50.tar.gz"
PACKAGE_MANIFEST = PUBLICATION / "pr108-integration-package-manifest.json"
METADATA = PUBLICATION / "pr108-integration-package-metadata.json"
STDOUT = PUBLICATION / "pr108-integration-packing.stdout.log"
STDERR = PUBLICATION / "pr108-integration-packing.stderr.log"
EXIT = PUBLICATION / "pr108-integration-packing.exit.json"
SOURCE_PREFIX = "pr108-integration/"
SCRIPT_MEMBER = "packaging/pr108-integration-packing.py"
MANIFEST_MEMBER = "packaging/PACKAGE_MANIFEST.json"
EXPECTED_MANIFEST_SHA = "f0deda1449e63e37bdce9cd65bfdddd6215d6adcacbb6c024688377a80090a2e"
EXPECTED_REPORT_SHA = "6abd6d20ca3866e6f7b4a1a82534ed150ec5e8c4af390bcd0902da0010abc5d2"
BUDGET = 8 * 1024 * 1024
CHUNK = 64 * 1024

def require(condition, message):
    if not condition:
        raise ValueError(message)

def sha(data):
    return hashlib.sha256(data).hexdigest()

def encode_json(value):
    return (json.dumps(value, indent=2, sort_keys=True) + "\n").encode("utf-8")

def identity(path):
    info = path.lstat()
    require(stat.S_ISREG(info.st_mode), "Nonregular source file: " + str(path))
    digest = hashlib.sha256()
    size = 0
    with path.open("rb") as stream:
        for part in iter(lambda: stream.read(CHUNK), b""):
            digest.update(part)
            size += len(part)
    require(size == info.st_size, "File size changed while reading: " + str(path))
    return {"bytes": size, "sha256": digest.hexdigest()}

def safe_name(name):
    path = PurePosixPath(name)
    return bool(name) and not path.is_absolute() and name == path.as_posix() and "." not in path.parts and ".." not in path.parts

def write_new(path, data):
    with path.open("xb") as stream:
        stream.write(data)

def main():
    require(Path(__file__).absolute() == SCRIPT, "Unexpected packaging-script location.")
    for path in [ARCHIVE, PACKAGE_MANIFEST, METADATA]:
        require(not path.exists(), "Refusing to overwrite prior output: " + str(path))
    raw_manifest = (SOURCE / "EVIDENCE_MANIFEST.json").read_bytes()
    require(sha(raw_manifest) == EXPECTED_MANIFEST_SHA, "Original evidence-manifest hash mismatch.")
    original = json.loads(raw_manifest)
    require(original["schema_version"] == 1, "Unexpected original manifest schema.")
    require(len(original["files"]) == 13, "Original manifest must cover exactly 13 files, excluding itself.")
    source_rows = {}
    for row in original["files"]:
        name = row["path"]
        require(safe_name(name) and name not in source_rows, "Unsafe or duplicate original manifest path.")
        source_rows[name] = {"bytes": row["bytes"], "sha256": row["sha256"]}
    require("EVIDENCE_MANIFEST.json" not in source_rows, "Unexpected original manifest self-inclusion.")
    source_rows["EVIDENCE_MANIFEST.json"] = {"bytes": len(raw_manifest), "sha256": EXPECTED_MANIFEST_SHA}
    actual = set()
    for path in SOURCE.rglob("*"):
        info = path.lstat()
        require(not stat.S_ISLNK(info.st_mode), "Symlink forbidden within evidence directory.")
        if stat.S_ISREG(info.st_mode):
            actual.add(str(path.relative_to(SOURCE)))
        else:
            require(stat.S_ISDIR(info.st_mode), "Special file forbidden within evidence directory.")
    require(actual == set(source_rows) and len(actual) == 14, "Finalized source directory is not the exact expected 14-file set.")
    require(sum(row["bytes"] for row in source_rows.values()) == 4410477, "Source byte total mismatch.")
    require(source_rows["INTEGRATION_REPORT.md"]["sha256"] == EXPECTED_REPORT_SHA, "Report identity mismatch.")
    for name, row in sorted(source_rows.items()):
        require(identity(SOURCE / name) == row, "Original file differs from its manifest pin: " + name)
    require(source_rows["capture.json"]["bytes"] == 0, "Failed empty capture must remain retained.")
    script_bytes = SCRIPT.read_bytes()

    # The package manifest covers 15 payload files: all 14 original evidence
    # files and this exact packaging script. It excludes only itself among tar
    # members. The archive and post-creation metadata/log/exit files are outside
    # the archive and cannot recursively describe their own final bytes.
    payload = {SOURCE_PREFIX + name: {"source_path": SOURCE / name, **row}
               for name, row in sorted(source_rows.items())}
    payload[SCRIPT_MEMBER] = {"inline": script_bytes, "bytes": len(script_bytes), "sha256": sha(script_bytes)}
    manifest = {
        "schema": "agent50-pr108-lossless-package-manifest-v1",
        "purpose": "Package finalized evidence only; no new mathematical, Lean, tree, or dependency verification.",
        "source_directory": str(SOURCE),
        "original_source_file_count": 14,
        "original_source_bytes": 4410477,
        "original_manifest_archive_member": SOURCE_PREFIX + "EVIDENCE_MANIFEST.json",
        "original_manifest_sha256": EXPECTED_MANIFEST_SHA,
        "original_manifest_scope": "13 listed original files; the unchanged original manifest is the fourteenth source file.",
        "source_refs": {
            "base": "74a1c3922eb7af438fe40b23d2105ad07556e3f5",
            "old_unpatched_head": "6deb8522c14fa2127d5d565bafec0cff781ccdd3",
            "candidate_tree": "eb961cd4662051e61d8c4c1e08b8e13ade6e25a3"
        },
        "covered_payload_file_count": len(payload),
        "archive_regular_member_count_including_this_manifest": len(payload) + 1,
        "self_exclusion": MANIFEST_MEMBER,
        "excluded_external_outputs": [
            ARCHIVE.name, METADATA.name, STDOUT.name, STDERR.name, EXIT.name
        ],
        "external_manifest_copy": PACKAGE_MANIFEST.name,
        "external_manifest_copy_policy": "Byte-identical convenience copy of the included package manifest; not another archive member.",
        "header_policy": "All members are regular files, mode 0644, uid/gid/mtime zero, empty owner names; gzip filename absent and mtime zero.",
        "files": [{"path": name, "bytes": row["bytes"], "sha256": row["sha256"]} for name, row in sorted(payload.items())]
    }
    manifest_bytes = encode_json(manifest)
    write_new(PACKAGE_MANIFEST, manifest_bytes)
    payload[MANIFEST_MEMBER] = {"inline": manifest_bytes, "bytes": len(manifest_bytes), "sha256": sha(manifest_bytes)}
    require(len(payload) == 16, "Expected exactly 16 regular archive members.")
    with ARCHIVE.open("xb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, compresslevel=9, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w|", format=tarfile.PAX_FORMAT) as tar:
                for name, row in sorted(payload.items()):
                    require(safe_name(name), "Unsafe package member name.")
                    info = tarfile.TarInfo(name)
                    info.size = row["bytes"]
                    info.mode, info.uid, info.gid, info.mtime = 0o644, 0, 0, 0
                    info.uname = info.gname = ""
                    if "source_path" in row:
                        with row["source_path"].open("rb") as stream:
                            tar.addfile(info, stream)
                    else:
                        tar.addfile(info, io.BytesIO(row["inline"]))

    restored = []
    seen = set()
    with ARCHIVE.open("rb") as raw:
        header = raw.read(10)
        require(header[:3] == b"\x1f\x8b\x08" and header[3] & 8 == 0 and
                int.from_bytes(header[4:8], "little") == 0, "Gzip header policy failed.")
        raw.seek(0)
        with gzip.GzipFile(fileobj=raw, mode="rb") as compressed:
            with tarfile.open(fileobj=compressed, mode="r|") as tar:
                for info in tar:
                    name = info.name
                    require(safe_name(name) and name in payload and name not in seen and info.isfile(),
                            "Unexpected, duplicate, unsafe, or nonregular archive member.")
                    require(info.mode == 0o644 and info.uid == info.gid == info.mtime == 0 and
                            info.uname == info.gname == "", "Tar header policy failed: " + name)
                    row = payload[name]
                    require(info.size == row["bytes"], "Archived size differs: " + name)
                    reference = row["source_path"].open("rb") if "source_path" in row else io.BytesIO(row["inline"])
                    digest = hashlib.sha256()
                    size = 0
                    with reference, tar.extractfile(info) as member:
                        while True:
                            chunk = member.read(CHUNK)
                            require(chunk == reference.read(CHUNK), "Restored bytes differ from original: " + name)
                            if not chunk:
                                break
                            digest.update(chunk)
                            size += len(chunk)
                    require(size == row["bytes"] and digest.hexdigest() == row["sha256"],
                            "Restored member identity mismatch: " + name)
                    seen.add(name)
                    restored.append({"path": name, "bytes": size, "sha256": digest.hexdigest(), "status": "PASS_BYTE_IDENTICAL"})
            # Consume the gzip trailer and remaining tar padding to validate CRC.
            for padding in iter(lambda: compressed.read(CHUNK), b""):
                require(not padding.strip(b"\0"), "Unexpected data after tar end markers.")
    require(seen == set(payload), "Restoration did not cover the exact complete member set.")
    for name, row in sorted(source_rows.items()):
        require(identity(SOURCE / name) == row, "Original source changed during packaging: " + name)

    archive_info = identity(ARCHIVE)
    git_digest = hashlib.sha1(b"blob " + str(archive_info["bytes"]).encode("ascii") + b"\0")
    with ARCHIVE.open("rb") as stream:
        for chunk in iter(lambda: stream.read(CHUNK), b""):
            git_digest.update(chunk)
    metadata = {
        "schema": "agent50-pr108-lossless-package-metadata-v1",
        "status": "PASS_LOSSLESS_14_ORIGINAL_FILES_AND_PACKAGING",
        "scope": "Packaging and byte restoration only; no retained code, Lean, finite mathematics, GitHub mutation, or new verification executed.",
        "archive_path": str(ARCHIVE),
        "bytes": archive_info["bytes"],
        "sha256": archive_info["sha256"],
        "git_blob_sha": git_digest.hexdigest(),
        "member_count": len(seen),
        "member_bytes": sum(row["bytes"] for row in payload.values()),
        "original_file_count": 14,
        "original_file_bytes": 4410477,
        "original_manifest_sha256": EXPECTED_MANIFEST_SHA,
        "original_report_sha256": EXPECTED_REPORT_SHA,
        "source_refs": manifest["source_refs"],
        "packing_code": {"path": str(SCRIPT), "archive_member": SCRIPT_MEMBER,
                         "bytes": len(script_bytes), "sha256": sha(script_bytes)},
        "package_manifest": {"path": str(PACKAGE_MANIFEST), "archive_member": MANIFEST_MEMBER,
                             "bytes": len(manifest_bytes), "sha256": sha(manifest_bytes),
                             "covered_payload_count": 15, "self_exclusion": MANIFEST_MEMBER},
        "restoration_check": {
            "status": "PASS_BYTE_FOR_BYTE_ALL_MEMBERS",
            "verified_members": len(restored),
            "exact_member_set": True,
            "safe_relative_regular_members_only": True,
            "every_member_size_and_sha256_verified": True,
            "every_original_file_unchanged": True,
            "empty_failed_capture_preserved": True,
            "filesystem_extraction_performed": False,
            "restored_members": restored
        },
        "additional_file_budget_bytes": BUDGET,
        "generated_utc": datetime.datetime.now(datetime.timezone.utc).isoformat()
    }
    # Reserve 64 KiB for metadata and run logs; all new files are below 8 MiB.
    new_bytes_before_metadata = len(script_bytes) + len(manifest_bytes) + archive_info["bytes"]
    require(new_bytes_before_metadata + 65536 <= BUDGET, "Additional package output budget exceeded.")
    metadata["new_file_bytes_before_metadata_and_run_logs"] = new_bytes_before_metadata
    metadata["metadata_and_log_reserve_bytes"] = 65536
    metadata["within_additional_8MiB_budget"] = True
    write_new(METADATA, encode_json(metadata))
    print(json.dumps({key: metadata[key] for key in [
        "status", "archive_path", "bytes", "sha256", "git_blob_sha", "member_count",
        "member_bytes", "original_file_count", "original_file_bytes", "packing_code",
        "package_manifest", "within_additional_8MiB_budget"]}, indent=2))
    print("METADATA " + str(METADATA))
    print("RESTORATION PASS_BYTE_FOR_BYTE_ALL_MEMBERS")

started = datetime.datetime.now(datetime.timezone.utc).isoformat()
exit_code = 0
with STDOUT.open("x", encoding="utf-8") as stdout, STDERR.open("x", encoding="utf-8") as stderr:
    with contextlib.redirect_stdout(stdout), contextlib.redirect_stderr(stderr):
        try:
            main()
        except BaseException:
            traceback.print_exc()
            exit_code = 1
write_new(EXIT, encode_json({
    "script": str(SCRIPT), "script_sha256": sha(SCRIPT.read_bytes()),
    "started_utc": started, "finished_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
    "exit_code": exit_code, "stdout": str(STDOUT), "stderr": str(STDERR),
    "scope": "Bounded packaging and byte restoration; source evidence remains unchanged."
}))
print(STDOUT.read_text())
print(STDERR.read_text(), file=sys.stderr)
sys.exit(exit_code)
