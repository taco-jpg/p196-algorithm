#!/usr/bin/env python3
"""Verify PR108's exact frozen-base add-only Git tree combination.

This program uses only captured public GitHub tool responses and Python's
standard library. It does not execute Lean, repository code, Git, or network
requests. It does not validate a mathematical proof or a later patched head.
"""
import argparse
import hashlib
import json
import pathlib
import re
import sys

EXPECTED_BASE = "74a1c3922eb7af438fe40b23d2105ad07556e3f5"
EXPECTED_HEAD = "6deb8522c14fa2127d5d565bafec0cff781ccdd3"
EXPECTED_CAPTURE_SHA256 = "2055bdd82fae7b52058ee3d0bc4114a76da2f3c4716848e029a089df6650f7ab"
DEPENDENCY_COMMIT = "2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5"
PREFIX = "proofs/contributions/agent-113/descending-prefix-maximality-20261016"
EXPECTED_PATHS = [
    ".github/workflows/agent113-triple-cycles.yml",
    PREFIX + "/Agent113TripleCycles.lean",
    PREFIX + "/Agent113TripleRepeat.lean",
    PREFIX + "/README.md",
    PREFIX + "/audit.json",
    PREFIX + "/check.py",
    PREFIX + "/generate_lean.py",
    PREFIX + "/witnesses.txt",
]


def require(condition, message):
    if not condition:
        raise ValueError(message)


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def git_oid(kind, body):
    return hashlib.sha1(kind.encode("ascii") + b" " +
                        str(len(body)).encode("ascii") + b"\0" + body).hexdigest()


def content(response):
    require(not response.get("isError", False), "Captured tool error")
    obj = response.get("structuredContent", {})
    if "content" in obj:
        return obj["content"]
    return obj["structuredContent"]["content"]


def parsed(record):
    return json.loads(content(record["response"]))


def entry_identity(entry):
    return (entry["mode"], entry["type"], entry["sha"])


def normalized(entry):
    return {key: entry[key] for key in ("path", "mode", "type", "sha")}


def tree_oid(entries):
    names = set()
    for entry in entries:
        name = entry["path"]
        require(name not in names and name not in ("", ".", ".."),
                "Duplicate or invalid tree entry")
        require("/" not in name and "\0" not in name, "Nonlocal tree name")
        require(re.fullmatch(r"[0-9a-f]{40}", entry["sha"]) is not None,
                "Invalid object ID")
        allowed = {"tree": {"040000"}, "blob": {"100644", "100755", "120000"},
                   "commit": {"160000"}}
        require(entry["mode"] in allowed.get(entry["type"], set()),
                "Unexpected Git object mode/type")
        names.add(name)
    ordered = sorted(entries, key=lambda entry: entry["path"].encode("utf-8") +
                     (b"/" if entry["type"] == "tree" else b""))
    body = b"".join(entry["mode"].lstrip("0").encode("ascii") + b" " +
                    entry["path"].encode("utf-8") + b"\0" +
                    bytes.fromhex(entry["sha"]) for entry in ordered)
    return git_oid("tree", body)


def verify(capture_path):
    capture_bytes = capture_path.read_bytes()
    require(sha256(capture_bytes) == EXPECTED_CAPTURE_SHA256,
            "Captured responses differ from the frozen artifact")
    capture = json.loads(capture_bytes)
    require(capture["base"] == EXPECTED_BASE, "Unexpected frozen base")
    require(capture["source_head"] == EXPECTED_HEAD, "Unexpected source head")
    require(capture["dependency_commit"] == DEPENDENCY_COMMIT,
            "Unexpected dependency commit")
    rows = capture["records"]
    records = {row["label"]: row for row in rows}
    require(len(records) == len(rows), "Duplicate response label")
    main = parsed(records["main"])
    head = parsed(records["head_commit"])
    pr = parsed(records["pr"])
    files = parsed(records["pr_files"])
    require(main["commit"]["sha"] == EXPECTED_BASE, "Base response mismatch")
    require(head["sha"] == EXPECTED_HEAD, "Head commit response mismatch")
    require(pr["head"]["sha"] == EXPECTED_HEAD, "PR response head mismatch")
    require(pr["base"]["ref"] == "main", "Unexpected PR target branch")
    require(pr["changed_files"] == 8 and len(files) == 8,
            "Unexpected changed-file count")
    require(sorted(row["filename"] for row in files) == sorted(EXPECTED_PATHS),
            "Changed paths differ from the assigned eight paths")
    require(all(row["status"] == "added" and row["deletions"] == 0 for row in files),
            "PR file list is not strictly add-only")

    trees = {}
    authenticated_trees = []
    for label, row in records.items():
        if not label.startswith("tree_"):
            continue
        obj = parsed(row)
        require(obj.get("truncated") is False, "Truncated tree response: " + label)
        calculated = tree_oid(obj["tree"])
        require(calculated == obj["sha"], "Git tree hash mismatch: " + label)
        if calculated in trees:
            require(trees[calculated] == [normalized(x) for x in obj["tree"]],
                    "Inconsistent response for the same tree")
        trees[calculated] = [normalized(x) for x in obj["tree"]]
        authenticated_trees.append({"label": label, "git_tree": calculated,
                                    "direct_entries": len(obj["tree"]),
                                    "truncated": False})

    base_root = main["commit"]["commit"]["tree"]["sha"]
    head_root = head["tree"]["sha"]
    require(base_root == parsed(records["tree_base_root"])["sha"],
            "Base root tree binding failed")
    require(head_root == parsed(records["tree_head_root"])["sha"],
            "Head root tree binding failed")

    def lookup(root, path):
        oid = root
        parts = path.split("/")
        for index, part in enumerate(parts):
            require(oid in trees, "Missing required tree object: " + oid)
            matches = [entry for entry in trees[oid] if entry["path"] == part]
            if not matches:
                return None
            entry = matches[0]
            if index == len(parts) - 1:
                return entry
            require(entry["type"] == "tree", "Nondirectory path ancestor: " + path)
            oid = entry["sha"]
        raise AssertionError("Unreachable empty lookup")

    additions = []
    for row in files:
        path = row["filename"]
        source = lookup(head_root, path)
        require(source is not None and source["type"] == "blob",
                "Missing head file: " + path)
        require(source["sha"] == row["sha"], "Head/file-list SHA mismatch: " + path)
        require(lookup(base_root, path) is None, "Path conflict on frozen base: " + path)
        blob_row = records["blob_" + path]
        body = content(blob_row["response"]).encode("utf-8")
        require(blob_row["blob_sha"] == source["sha"], "Captured blob binding mismatch")
        require(git_oid("blob", body) == source["sha"], "Blob content mismatch: " + path)
        additions.append({"path": path, "mode": source["mode"], "type": source["type"],
                          "git_blob": source["sha"], "bytes": len(body),
                          "sha256": sha256(body), "absent_on_frozen_base": True})

    build_records = []

    def add_tree(old_oid, prefix, changes):
        before = {e["path"]: dict(e) for e in trees[old_oid]} if old_oid else {}
        after = {name: dict(entry) for name, entry in before.items()}
        groups = {}
        for relative_path, entry in changes:
            name, separator, rest = relative_path.partition("/")
            groups.setdefault(name, []).append((rest if separator else "", entry))
        for name, group in groups.items():
            leaf = [x for x in group if x[0] == ""]
            if leaf:
                require(len(group) == len(leaf) == 1, "Duplicate or mixed addition")
                require(name not in before, "Would overwrite an existing path")
                item = leaf[0][1]
                after[name] = {"path": name, "mode": item["mode"],
                               "type": item["type"], "sha": item["git_blob"]}
            else:
                existing = before.get(name)
                require(existing is None or existing["type"] == "tree",
                        "Would replace a nondirectory ancestor")
                child_prefix = prefix + "/" + name if prefix else name
                child = add_tree(existing["sha"] if existing else None,
                                 child_prefix, group)
                after[name] = {"path": name, "mode": "040000",
                               "type": "tree", "sha": child}
        new_entries = sorted(after.values(),
                             key=lambda e: e["path"].encode("utf-8") +
                             (b"/" if e["type"] == "tree" else b""))
        new_oid = tree_oid(new_entries)
        trees[new_oid] = new_entries
        build_records.append({"path": prefix or "/", "base_tree": old_oid,
                              "candidate_tree": new_oid, "base_direct_entries": len(before),
                              "candidate_direct_entries": len(after)})
        return new_oid

    candidate = add_tree(base_root, "", [(row["path"], row) for row in additions])
    diff = {"added": [], "deleted": [], "modified": []}
    unchanged_links = []
    inspected_base_entries = 0

    def compare(old_oid, new_oid, prefix):
        nonlocal inspected_base_entries
        if old_oid == new_oid:
            unchanged_links.append({"path": prefix, "mode": "040000",
                                    "type": "tree", "sha": old_oid})
            return
        old = {e["path"]: e for e in trees[old_oid]} if old_oid else {}
        new = {e["path"]: e for e in trees[new_oid]} if new_oid else {}
        inspected_base_entries += len(old)
        for name in sorted(set(old) | set(new)):
            path = prefix + "/" + name if prefix else name
            a, b = old.get(name), new.get(name)
            if a is None:
                if b["type"] == "tree":
                    compare(None, b["sha"], path)
                else:
                    diff["added"].append({"path": path, **{k: b[k] for k in
                                                           ("mode", "type", "sha")}})
            elif b is None:
                diff["deleted"].append({"path": path, "entry": a})
            elif entry_identity(a) == entry_identity(b):
                unchanged_links.append({"path": path, **{k: a[k] for k in
                                                         ("mode", "type", "sha")}})
            elif a["type"] == b["type"] == "tree" and a["mode"] == b["mode"]:
                compare(a["sha"], b["sha"], path)
            else:
                diff["modified"].append({"path": path, "before": a, "after": b})

    compare(base_root, candidate, "")
    require(not diff["deleted"] and not diff["modified"],
            "Candidate changes or deletes an existing base path")
    require(sorted(x["path"] for x in diff["added"]) == sorted(EXPECTED_PATHS),
            "Candidate adds paths outside the assigned eight")
    for row in additions:
        require(lookup(candidate, row["path"])["sha"] == row["git_blob"],
                "Candidate addition binding failed")

    base_proofs = parsed(records["tree_base_proofs"])
    dependencies = []
    module_sources = {}
    for module, expected_import in [("LychrelDigitSums", "Std"),
                                    ("TwoDigitProjection", "LychrelDigitSums")]:
        row = records["dependency_original_" + module]
        response = row["response"]["structuredContent"]
        require(row["arguments"]["ref"] == DEPENDENCY_COMMIT,
                "Dependency original ref mismatch")
        body = content(row["response"]).encode("utf-8")
        blob = git_oid("blob", body)
        require(blob == response["sha"] == row["blob_sha"],
                "Dependency bytes do not match Git blob")
        matches = [e for e in base_proofs["tree"]
                   if e["type"] == "blob" and e["sha"] == blob]
        require(bool(matches), "Original dependency content absent from current proofs")
        imports = re.findall(r"(?m)^\s*import\s+([A-Za-z0-9_.]+)\s*$",
                             body.decode("utf-8"))
        require(imports == [expected_import], "Unexpected observed dependency imports")
        paths = ["proofs/" + e["path"] for e in matches]
        require(all(lookup(candidate, path)["sha"] == blob for path in paths),
                "Candidate did not preserve dependency content")
        item = {"module": module, "source_commit": DEPENDENCY_COMMIT,
                "original_source_path": row["arguments"]["path"],
                "git_blob": blob, "bytes": len(body), "sha256": sha256(body),
                "observed_imports": imports, "identical_current_main_paths": paths,
                "identical_current_main_path_count": len(paths),
                "candidate_preserves_all_listed_paths": True}
        dependencies.append(item)
        module_sources[module] = item
    for module, expected_import in [("Agent113TripleCycles", "TwoDigitProjection"),
                                    ("Agent113TripleRepeat", "Agent113TripleCycles")]:
        path = PREFIX + "/" + module + ".lean"
        body = content(records["blob_" + path]["response"]).encode("utf-8")
        imports = re.findall(r"(?m)^\s*import\s+([A-Za-z0-9_.]+)\s*$",
                             body.decode("utf-8"))
        require(imports == [expected_import], "Unexpected observed new-module imports")
        item = next(x for x in additions if x["path"] == path)
        module_sources[module] = {"module": module, "source_commit": EXPECTED_HEAD,
                                  "original_source_path": path,
                                  "git_blob": item["git_blob"], "bytes": len(body),
                                  "sha256": sha256(body), "observed_imports": imports}

    archive_before = lookup(base_root, "proofs/archive")
    archive_after = lookup(candidate, "proofs/archive")
    require(entry_identity(archive_before) == entry_identity(archive_after),
            "Historical archive subtree changed")
    workflow = content(records["blob_.github/workflows/agent113-triple-cycles.yml"]["response"])
    require("ref: " + DEPENDENCY_COMMIT in workflow, "Workflow pin missing")
    for row in dependencies:
        require(row["original_source_path"] in workflow,
                "Workflow does not name the inspected dependency path")

    certificate = {"base_entries_examined_at_changed_ancestors": inspected_base_entries,
                   "unchanged_entry_count": len(unchanged_links),
                   "unchanged_entries": unchanged_links,
                   "preservation_argument":
                       "At every changed ancestor, every prior entry is retained with the "
                       "same mode/type/object ID or recursed into as an existing tree. "
                       "Equal tree IDs preserve their complete descendant object graph. "
                       "No deleted or modified blob/submodule/symlink appears in the diff. "
                       "Only the eight listed leaf paths are added.",
                   "historical_archive_tree_unchanged": archive_before["sha"],
                   "candidate_added_leaf_count": len(diff["added"]),
                   "deleted_existing_leaf_count": len(diff["deleted"]),
                   "modified_existing_leaf_count": len(diff["modified"])}
    certificate_bytes = (json.dumps(certificate, ensure_ascii=False, sort_keys=True,
                                    indent=2) + "\n").encode("utf-8")
    result = {
        "schema_version": 1,
        "status": "PASS_SCOPED_TREE_AND_DEPENDENCY_IDENTITY",
        "agent": "Agent #50",
        "session": "4dce66859b6c",
        "base": EXPECTED_BASE,
        "base_root_tree": base_root,
        "base_observed_at": records["main"]["observed_at"],
        "source_head": EXPECTED_HEAD,
        "source_head_tree": head_root,
        "pr_target": pr["base"]["ref"],
        "pr_response_base_sha": pr["base"]["sha"],
        "pr_response_base_sha_note":
            "Recorded metadata only; the current-main branch response above defines tested B.",
        "candidate_root_tree": candidate,
        "candidate_kind": "In-memory exact add-only overlay; no Git object or ref was written",
        "candidate_is_patched_head": False,
        "eight_additions": additions,
        "authenticated_captured_tree_count": len(authenticated_trees),
        "authenticated_captured_trees": authenticated_trees,
        "candidate_tree_construction": build_records,
        "preservation": {k: v for k, v in certificate.items() if k != "unchanged_entries"},
        "preservation_certificate_sha256": sha256(certificate_bytes),
        "source_modules": [module_sources[m] for m in
                           ("LychrelDigitSums", "TwoDigitProjection",
                            "Agent113TripleCycles", "Agent113TripleRepeat")],
        "dependency_identity_status": "Both original dependency blobs are present unchanged on B",
        "capture_sha256": sha256(capture_bytes),
        "capture_bytes": len(capture_bytes),
        "lean_invocations": 0,
        "project_python_invocations": 0,
        "remote_mutations": 0,
        "mathematical_review_status": "NOT_PERFORMED_BY_THIS_SUBTASK",
        "trust_zero_correction":
            "Compiler help wording alone does not establish kernel rechecking of every "
            "imported .olean proof. No such semantic claim is made here.",
        "limitations": [
            "This is a tree/content-identity result for exactly the recorded B and unpatched H.",
            "The reported Repeat repair and matching workflow hash update are not in this H.",
            "The parent must bind the final patched H and target-write-slot B before delivery.",
            "No compilation, finite simulation, independent mathematical review, Ready action, "
            "merge action, platform acceptance, or target publication is certified by this result.",
            "Matching source contents under current suffixed paths is not a claim that default "
            "Lake targets resolve the original unqualified import names.",
            "Unchanged subtrees are authenticated by their exact Git object IDs, not by "
            "recursively enumerating every historical leaf.",
        ],
    }
    return result, certificate_bytes


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("capture", type=pathlib.Path)
    parser.add_argument("--result", type=pathlib.Path)
    parser.add_argument("--certificate", type=pathlib.Path)
    args = parser.parse_args()
    result, certificate = verify(args.capture)
    output = (json.dumps(result, ensure_ascii=False, sort_keys=True, indent=2) +
              "\n").encode("utf-8")
    if args.certificate:
        with args.certificate.open("xb") as stream:
            stream.write(certificate)
    if args.result:
        with args.result.open("xb") as stream:
            stream.write(output)
        print(json.dumps({"status": result["status"], "result": str(args.result),
                          "result_sha256": sha256(output),
                          "candidate_root_tree": result["candidate_root_tree"],
                          "additions": len(result["eight_additions"]),
                          "lean_invocations": 0}, sort_keys=True))
    else:
        sys.stdout.buffer.write(output)


if __name__ == "__main__":
    main()
