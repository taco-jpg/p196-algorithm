import pathlib,subprocess,sys,json,datetime,hashlib
root=pathlib.Path('/dev/shm/p196-agent50-4dce66859b6c/pr108-integration')
argv=[sys.executable,str(root/'verify_integration.py'),str(root/'capture-002.json'),'--result',str(root/'result-001.json'),'--certificate',str(root/'preservation-certificate-001.json')]
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
completed=subprocess.run(argv,cwd=root,env={'PATH':'/usr/bin:/bin','PYTHONDONTWRITEBYTECODE':'1'},stdout=subprocess.PIPE,stderr=subprocess.PIPE,check=False)
for name,data in [('verify-001.stdout.log',completed.stdout),('verify-001.stderr.log',completed.stderr)]:
 with (root/name).open('xb') as stream:stream.write(data)
record={'argv':argv,'started_at':start,'completed_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_status':completed.returncode,'stdout_sha256':hashlib.sha256(completed.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(completed.stderr).hexdigest(),'lean_invocations':0,'remote_mutations':0}
with (root/'verification-execution-001.json').open('x',encoding='utf-8') as stream:json.dump(record,stream,indent=2);stream.write('\n')
sys.stdout.buffer.write(completed.stdout)
sys.stderr.buffer.write(completed.stderr)
print(json.dumps(record),flush=True)
sys.exit(completed.returncode)
