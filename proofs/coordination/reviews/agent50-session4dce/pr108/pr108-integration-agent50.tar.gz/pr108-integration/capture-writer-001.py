import sys, pathlib, hashlib, json
root=pathlib.Path('/dev/shm/p196-agent50-4dce66859b6c/pr108-integration')
for p in [root.parent,root]:
 if p.is_symlink(): raise RuntimeError('Refusing symlink output path')
root.mkdir(parents=True,exist_ok=True)
expected=3779308
if expected > 24*1024*1024: raise RuntimeError('Capture exceeds the task budget')
target=root/'capture.json'
with target.open('xb') as f:
 print('READY_FOR_CAPTURE '+str(expected),flush=True)
 remaining=expected
 while remaining:
  block=sys.stdin.buffer.read(min(65536,remaining))
  if not block: raise RuntimeError('Incomplete input; partial capture is preserved')
  f.write(block)
  remaining-=len(block)
 f.flush()
data=target.read_bytes()
parsed=json.loads(data)
print(json.dumps({'capture':str(target),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'records':len(parsed['records'])}),flush=True)
