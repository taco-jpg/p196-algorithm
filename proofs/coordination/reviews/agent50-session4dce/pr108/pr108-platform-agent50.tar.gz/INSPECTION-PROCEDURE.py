from pathlib import Path
import urllib.request, zipfile, hashlib, json, io
base=Path("/dev/shm/p196-agent50-4dce66859b6c/pr108-platform")
base.mkdir(parents=True, exist_ok=True)
url="RETRIEVAL_URL_FROM_GITHUB_CONNECTOR_NOT_PERSISTED"
with urllib.request.urlopen(url, timeout=20) as response:
    raw=response.read(20000)
expected="857967f241ec1bccf00ec1a6fd63275ff240a53abb1ff605326ef13aab2f97bd"
assert len(raw)==5286, len(raw)
assert hashlib.sha256(raw).hexdigest()==expected
path=base/"pr108-pr-failure-12077732963.zip"
path.write_bytes(raw)
records=[]
with zipfile.ZipFile(io.BytesIO(raw)) as z:
    for i in z.infolist():
        p=Path(i.filename)
        assert not p.is_absolute() and ".." not in p.parts
        assert i.file_size<1000000 and not i.is_dir()
        data=z.read(i)
        target=base/"pr-run-artifact"/p
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
        records.append({"path":i.filename,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest(),"text":data.decode("utf-8")})
manifest={"artifact_id":12077732963,"run_id":38973450553,"job_id":117217088762,"head":"6deb8522c14fa2127d5d565bafec0cff781ccdd3","bytes":len(raw),"sha256":expected,"members":records,"new_lean_execution":"NOT_RUN"}
(base/"pr-run-artifact-inspection.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps(manifest))
