#!/usr/bin/env python3
"""Run the frozen PR155 verifier and retain complete, bounded-run evidence."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'agent4-pr155'
attempt = sys.argv[1]
if not attempt.isdecimal() or len(attempt) != 3:
    raise SystemExit('Use one three-digit attempt identifier')
output = ROOT / f'canonical-strict-{attempt}'
driver = ROOT / f'canonical-driver-{attempt}.json'
console = ROOT / f'canonical-console-{attempt}.log'
if any(path.exists() for path in (output, driver, console)):
    raise SystemExit('Refusing to overwrite an existing attempt')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

command = [sys.executable, '-B', str(SOURCE / 'proofs/verify_project__214bf7673efe116b.py'),
           '--lean', str(ROOT / 'strict_lean.py'),
           '--project', 'agent51-reciprocal-moment',
           '--registry', str(SOURCE / 'proofs/Agent51ReciprocalMoment.registry.json'),
           '--output', str(output)]
receipt = {'agent': 'Agent #4', 'command': command, 'cwd': str(SOURCE),
           'start_epoch': time.time(), 'status': 'RUNNING',
           'max_wall_seconds': 300, 'lean_rlimit_as_bytes': 4 * 1024**3,
           'launcher_sha256': digest(ROOT / 'strict_lean.py'),
           'driver_sha256': digest(Path(__file__)),
           'canonical_verifier_sha256': digest(SOURCE / 'proofs/verify_project__214bf7673efe116b.py'),
           'resource_note': 'Cgroup counters are shared observations, not per-process attribution.'}

def snapshot(stage):
    for name in ('memory.current', 'memory.max', 'memory.events'):
        path = Path('/sys/fs/cgroup') / name
        if path.exists():
            receipt[f'{stage}_{name}'] = path.read_text()

snapshot('before')
driver.write_text(json.dumps(receipt, indent=2) + '\n')
started = time.monotonic()
with console.open('wb') as stream:
    process = subprocess.Popen(command, cwd=SOURCE, stdout=stream,
                               stderr=subprocess.STDOUT, start_new_session=True)
    try:
        receipt['exit_code'] = process.wait(timeout=300)
        receipt['status'] = 'PASS' if process.returncode == 0 else 'FAIL'
    except subprocess.TimeoutExpired:
        receipt['status'] = 'TIMEOUT'
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        receipt['exit_code'] = process.returncode
receipt['elapsed_seconds'] = time.monotonic() - started
receipt['finish_epoch'] = time.time()
receipt['console_sha256'] = digest(console)
snapshot('after')
driver.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
print(console.read_text())
raise SystemExit(0 if receipt['status'] == 'PASS' else 1)
