#!/usr/bin/env python3
"""Inspect a frozen hypothetical merge using a private Git object directory."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent.parent / "agent4-pr155"
H = "4c0382b16f0600a3dd07ff36c40793e710b92c96"
B = "7360b12a0a5889761c845a56a4b8d8a1df5f39b5"
M = "74a1c3922eb7af438fe40b23d2105ad07556e3f5"
ENV = os.environ.copy()
ENV.update(GIT_OPTIONAL_LOCKS="0", GIT_NO_REPLACE_OBJECTS="1",
           GIT_ATTR_NOSYSTEM="1")
COMMANDS = []


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def git(label, args, allowed=(0,)):
    command = ["git", "-c", "core.attributesFile=/dev/null", *args]
    result = subprocess.run(command, cwd=REPO, env=ENV, capture_output=True)
    out = ROOT / (label + ".stdout")
    err = ROOT / (label + ".stderr")
    out.write_bytes(result.stdout)
    err.write_bytes(result.stderr)
    COMMANDS.append({"label": label, "command": command, "cwd": str(REPO),
                     "exit_code": result.returncode,
                     "stdout": out.name, "stderr": err.name,
                     "stdout_sha256": sha256(result.stdout),
                     "stderr_sha256": sha256(result.stderr)})
    (ROOT / "commands.json").write_text(json.dumps(COMMANDS, indent=2) + "\n")
    if result.returncode not in allowed:
        raise RuntimeError(f"Command {label} returned {result.returncode}")
    return result


def tree(label, ref):
    raw = git(label, ["ls-tree", "-rz", ref]).stdout
    result = {}
    for item in raw.split(b"\0"):
        if not item:
            continue
        metadata, path = item.split(b"\t", 1)
        mode, kind, oid = metadata.decode().split()
        result[path.decode()] = {"mode": mode, "type": kind, "oid": oid}
    return result


def delta(left, right):
    result = []
    for path in sorted(left.keys() | right.keys()):
        before, after = left.get(path), right.get(path)
        if before != after:
            status = "A" if before is None else "D" if after is None else "M"
            result.append({"status": status, "path": path,
                           "before": before, "after": after})
    return result


def counts(items):
    return {key: sum(item["status"] == key for item in items)
            for key in ["A", "M", "D"]}


def blob(label, ref, path):
    return git(label, ["show", ref + ":" + path]).stdout


if (ROOT / "manifest.json").exists() or (ROOT / "objects").exists():
    raise SystemExit("Refusing to overwrite an existing evidence run")

freeze_bytes = (ROOT.parent / "source-freeze.json").read_bytes()
(ROOT / "source-freeze.snapshot.json").write_bytes(freeze_bytes)
freeze = json.loads(freeze_bytes)
assert (freeze["source_head"], freeze["base_head"], freeze["main_observed"]) == (H, B, M)
common = Path(git("git-common-dir", ["rev-parse", "--git-common-dir"]).stdout.decode().strip())
if not common.is_absolute():
    common = (REPO / common).resolve()
attributes = common / "info" / "attributes"
if attributes.exists() and attributes.read_bytes().strip():
    raise SystemExit("Nonempty repository info/attributes requires inspection")

before_head = git("before-head", ["rev-parse", "HEAD"]).stdout
assert before_head.decode().strip() == H
before_status = git("before-status", ["status", "--porcelain=v1"]).stdout
assert not before_status
before_refs = git("before-refs", ["show-ref"]).stdout
for name, ref in [("H", H), ("B", B), ("M", M)]:
    git("object-" + name, ["cat-file", "-e", ref + "^{commit}"])
    git("commit-" + name, ["show", "--no-patch", "--format=raw", ref])
base = git("merge-base", ["merge-base", M, H]).stdout.decode().strip()
b_in_h = git("B-ancestor-H", ["merge-base", "--is-ancestor", B, H], (0, 1)).returncode == 0
b_in_m = git("B-ancestor-M", ["merge-base", "--is-ancestor", B, M], (0, 1)).returncode == 0

objects = ROOT / "objects"
objects.mkdir()
ENV["GIT_OBJECT_DIRECTORY"] = str(objects)
ENV["GIT_ALTERNATE_OBJECT_DIRECTORIES"] = str(common / "objects")
environment = {key: ENV[key] for key in ["GIT_OPTIONAL_LOCKS", "GIT_NO_REPLACE_OBJECTS",
               "GIT_ATTR_NOSYSTEM", "GIT_OBJECT_DIRECTORY", "GIT_ALTERNATE_OBJECT_DIRECTORIES"]}
(ROOT / "environment.json").write_text(json.dumps(environment, indent=2) + "\n")
merge = git("merge-tree", ["merge-tree", "--write-tree", "--messages", M, H], (0, 1))
C = merge.stdout.decode().splitlines()[0]
git("combined-object-type", ["cat-file", "-t", C])
trees = {name: tree("tree-" + name, ref) for name, ref in [("M", M), ("B", B), ("H", H), ("C", C)]}
for name in ["M", "H"]:
    assert not any(Path(path).name == ".gitattributes" for path in trees[name])
deltas = {"M_to_C": delta(trees["M"], trees["C"]),
          "B_to_C": delta(trees["B"], trees["C"]),
          "B_to_H": delta(trees["B"], trees["H"]),
          "H_to_C": delta(trees["H"], trees["C"])}
for label, left, right in [("M-to-C", M, C), ("B-to-C", B, C), ("B-to-H", B, H), ("H-to-C", H, C)]:
    git("diff-" + label + "-name-status", ["diff", "--no-ext-diff", "--no-textconv", "--no-renames", "--name-status", left, right])
    git("diff-" + label + "-stat", ["diff", "--no-ext-diff", "--no-textconv", "--no-renames", "--stat", left, right])
    git("diff-" + label + "-patch", ["diff", "--no-ext-diff", "--no-textconv", "--no-renames", "--binary", left, right])
    git("diff-" + label + "-check", ["diff", "--no-ext-diff", "--no-textconv", "--check", left, right], (0, 2))

checks = []
targets = [(name, entry["path"], entry["sha256"], entry.get("git_blob")) for name, entry in freeze["modules"].items()]
targets.extend([("registry", "proofs/Agent51ReciprocalMoment.registry.json", freeze["registry_sha256"], None),
                ("canonical-verifier", "proofs/verify_project__214bf7673efe116b.py", freeze["canonical_verifier_sha256"], None)])
for name, path, expected, expected_oid in targets:
    content = blob("frozen-" + name, C, path)
    checks.append({"name": name, "path": path, "expected_sha256": expected,
                   "combined_sha256": sha256(content), "sha256_matches": sha256(content) == expected,
                   "H_entry": trees["H"].get(path), "C_entry": trees["C"].get(path),
                   "H_equals_C": trees["H"].get(path) == trees["C"].get(path),
                   "expected_git_blob": expected_oid,
                   "expected_blob_matches": expected_oid is None or trees["C"][path]["oid"] == expected_oid})

pr155 = deltas["B_to_H"]
preserved_pr155 = [dict(item, preserved_in_combination=trees["H"].get(item["path"]) == trees["C"].get(item["path"])) for item in pr155]
preservation = {}
for name in ["M", "B", "H"]:
    lost = [path for path in trees[name] if path not in trees["C"]]
    changed = [path for path in trees[name] if path in trees["C"] and trees[name][path] != trees["C"][path]]
    archive = [path for path in trees[name] if path.startswith("proofs/archive/")]
    archive_changed = [path for path in archive if trees[name][path] != trees["C"].get(path)]
    preservation[name] = {"file_entries": len(trees[name]), "deleted_paths": lost,
                          "changed_existing_paths": changed, "archive_entries": len(archive),
                          "archive_changed_or_deleted_paths": archive_changed}
after_head = git("after-head", ["rev-parse", "HEAD"]).stdout
after_status = git("after-status", ["status", "--porcelain=v1"]).stdout
after_refs = git("after-refs", ["show-ref"]).stdout
manifest = {"agent": "Agent #4", "scope": "Structural hypothetical-tree review only; no Lean execution or merge publication",
            "observed_utc": datetime.datetime.now(datetime.timezone.utc).isoformat(),
            "source_head": H, "stack_base": B, "main_observed": M, "merge_base": base,
            "combined_tree": C, "merge_tree_exit_code": merge.returncode,
            "B_is_ancestor_of_H": b_in_h, "B_is_ancestor_of_M": b_in_m,
            "source_freeze_snapshot_sha256": sha256(freeze_bytes),
            "git_environment": environment, "diff_counts": {key: counts(items) for key, items in deltas.items()},
            "diffs": deltas, "frozen_input_checks": checks,
            "PR155_addition_preservation": preserved_pr155, "input_preservation": preservation,
            "HEAD_unchanged": before_head == after_head,
            "worktree_status_unchanged_and_clean": before_status == after_status == b"",
            "refs_unchanged": before_refs == after_refs,
            "limitations": ["PR148 is an unintegrated dependency of this hypothetical result.",
                            "No mathematical acceptance of PR148 modules is established.",
                            "No integration into main is established.",
                            "A real PR148 merge or any main/head change requires recomputing the combined tree and comparing the affected closure."]}
(ROOT / "manifest.json").write_text(json.dumps(manifest, indent=2) + "\n")
summary = {key: manifest[key] for key in ["combined_tree", "merge_base", "merge_tree_exit_code",
          "B_is_ancestor_of_H", "B_is_ancestor_of_M", "diff_counts", "input_preservation",
          "HEAD_unchanged", "worktree_status_unchanged_and_clean", "refs_unchanged"]}
summary["frozen_input_checks_pass"] = all(c["sha256_matches"] and c["H_equals_C"] and c["expected_blob_matches"] for c in checks)
summary["all_13_PR155_additions_preserved"] = len(pr155) == 13 and all(c["status"] == "A" and c["preserved_in_combination"] for c in preserved_pr155)
print(json.dumps(summary, indent=2))
