import ReciprocalMoment
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check P196.Agent51.inputDigit
#check P196.Agent51.pairWord
#check P196.Agent51.inputDigit_bounded
#check P196.Agent51.inputDigit_zero
#check P196.Agent51.inputDigit_last
#check P196.Agent51.inputDigit_pair
#check P196.Agent51.pairWord_values
#check P196.Agent51.pairWord_zero
#check P196.Agent51.finiteSum
#check P196.Agent51.finiteSum_eq_range
#check P196.Agent51.polynomialValue
#check P196.Agent51.polynomialValue_eq_finiteSum
#check P196.Agent51.finiteSum_congr
#check P196.Agent51.finiteSum_add_length
#check P196.Agent51.finiteSum_const
#check P196.Agent51.finiteSum_mul_left
#check P196.Agent51.pairWord_polynomial_blocks
#check P196.Agent51.int_one_pow
#check P196.Agent51.pairWord_value_one
#check P196.Agent51.int_pow_add
#check P196.Agent51.neg_one_pow
#check P196.Agent51.alternating_prefix
#check P196.Agent51.power_prefix_shift
#check P196.Agent51.pairWord_value_neg_one
#check P196.Agent51.pairWord_neg_one_dvd
#check P196.Agent51.pairWord_neg_one_even
#check P196.Agent51.sourceS
#check P196.Agent51.sourceR
#check P196.Agent51.pairWord_half_value_one
#check P196.Agent51.pairWord_sourceS
#check P196.Agent51.pairWord_sourceS_nat
#check P196.Agent51.pairWord_sourceR
#check P196.Agent51.residue_parameter
#check P196.Agent51.polynomialValue_congr
#check P196.Agent51.sourceS_congr
#check P196.Agent51.sourceR_congr
#check P196.Agent51.finiteSum_add_values
#check P196.Agent51.finiteSum_shift
#check P196.Agent51.finiteSum_reflected
#check P196.Agent51.reciprocal_first_moment
#check P196.Agent51.reciprocal_first_moment_literal
#check P196.Agent51.formalDerivativeValue
#check P196.Agent51.derivativeAtOne
#check P196.Agent51.derivativeAtOne_eq_finiteSum
#check P196.Agent51.formalDerivativeValue_one
#check P196.Agent51.reciprocal_derivative_at_one
#check P196.Agent51.reciprocal_derivative_mod_nine
#check P196.Agent51.reciprocal_derivative_mod_nine_determined
#check P196.Agent51.natural_mass_eq_polynomialValue
#check P196.Agent51.natural_reciprocal_derivative
run_cmd do
  let env ← getEnv
  let selected : List String := ["OverflowDigits", "ResidueSums", "ReciprocalMoment"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        match info with
        | .axiomInfo v =>
          if v.isUnsafe then logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {mod} {name}"
          else throwError m!"CUSTOM_AXIOM {mod} {name}"
        | .thmInfo _ =>
          count := count + 1
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          for ax in axl do
            if !(union.contains ax) then union := ax :: union
          if axl.any (fun ax => !(allowed.contains ax)) then throwError m!"DISALLOWED_AXIOMS {mod} {name} : {axl}"
          logInfo m!"AUDIT_THEOREM {mod} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
