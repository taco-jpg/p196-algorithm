#!/usr/bin/env python3
"""Diagnose bounded-address-space failure using only an import of official Lean."""
import hashlib
import json
from pathlib import Path
import resource
import subprocess
import time

ROOT = Path(__file__).resolve().parent / 'runtime-diagnostic'
ROOT.mkdir(exist_ok=False)
LEAN = Path('/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean')
identity = hashlib.sha256(LEAN.read_bytes()).hexdigest()
assert identity == '92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023'
(ROOT / 'ImportLean.lean').write_text('import Lean\n#check Lean.collectAxioms\n')
results = []
for gib in (2, 4):
    limit = gib * 1024**3
    def bound():
        resource.setrlimit(resource.RLIMIT_AS, (limit, limit))
        resource.setrlimit(resource.RLIMIT_CORE, (0, 0))
    command = [str(LEAN), '--trust=0', '-j1', '-DElab.async=false', 'ImportLean.lean']
    receipt = {'rlimit_as_bytes': limit, 'command': command,
               'lean_sha256': identity, 'start_epoch': time.time(),
               'scope': 'Runtime diagnostic only; not PR proof acceptance.',
               'samples': [], 'source_sha256': hashlib.sha256((ROOT / 'ImportLean.lean').read_bytes()).hexdigest()}
    started = time.monotonic()
    with (ROOT / f'import-{gib}g.log').open('wb') as stream:
        process = subprocess.Popen(command, cwd=ROOT, stdout=stream,
                                   stderr=subprocess.STDOUT, preexec_fn=bound,
                                   env={'PATH': str(LEAN.parent) + ':/usr/bin:/bin',
                                        'LANG': 'C.UTF-8', 'LEAN_PATH': str(ROOT)})
        while process.poll() is None and time.monotonic() - started < 30:
            try:
                status = Path(f'/proc/{process.pid}/status').read_text()
                receipt['samples'].append({'seconds': time.monotonic() - started,
                    'memory': [line for line in status.splitlines() if line.startswith(('VmPeak:', 'VmSize:', 'VmHWM:', 'VmRSS:'))]})
            except FileNotFoundError:
                pass
            time.sleep(0.02)
        if process.poll() is None:
            process.kill()
            receipt['timeout_seconds'] = 30
        receipt['exit_code'] = process.wait()
    receipt['elapsed_seconds'] = time.monotonic() - started
    receipt['log_sha256'] = hashlib.sha256((ROOT / f'import-{gib}g.log').read_bytes()).hexdigest()
    (ROOT / f'import-{gib}g.json').write_text(json.dumps(receipt, indent=2) + '\n')
    results.append({key: value for key, value in receipt.items() if key != 'samples'})
    print(json.dumps(results[-1]))
    print((ROOT / f'import-{gib}g.log').read_text())
