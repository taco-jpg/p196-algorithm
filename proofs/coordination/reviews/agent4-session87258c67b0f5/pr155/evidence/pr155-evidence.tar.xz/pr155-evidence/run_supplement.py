#!/usr/bin/env python3
"""Audit public declarations and safe definitions from the fresh accepted closure."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
BUILD = ROOT / 'canonical-strict-003'
SOURCE = BUILD / 'agent51-reciprocal-moment/source'
OUTPUT = ROOT / 'supplement-001'
OUTPUT.mkdir(exist_ok=False)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

canonical = json.loads((BUILD / 'verification.json').read_text())
assert canonical['status'] == 'PASS'
assert canonical['source_commit'] == '4c0382b16f0600a3dd07ff36c40793e710b92c96'
audit = ROOT / 'PublicAndSafeAudit.lean'
assert digest(audit) == 'e1850a9b59448ead68f4f559b19b49758500ff6e2d7742098f3a90e5a00236b8'
(OUTPUT / audit.name).write_bytes(audit.read_bytes())
command = [str(ROOT / 'strict_lean.py'), '-j1', '-DElab.async=false', audit.name]
environment = {'PATH': str(ROOT) + ':/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LEAN_PATH': str(SOURCE)}
receipt = {'agent': 'Agent #4', 'source_head': canonical['source_commit'],
           'command': command, 'cwd': str(OUTPUT), 'environment': environment,
           'canonical_report_sha256': digest(BUILD / 'verification.json'),
           'audit_source_sha256': digest(audit), 'launcher_sha256': digest(ROOT / 'strict_lean.py'),
           'driver_sha256': digest(Path(__file__)), 'start_epoch': time.time(),
           'status': 'RUNNING', 'timeout_seconds': 120, 'fresh_inputs': {}}
for name in ('OverflowDigits', 'ResidueSums', 'ReciprocalMoment'):
    receipt['fresh_inputs'][name] = {ext: digest(SOURCE / (name + ext)) for ext in ('.lean', '.olean')}
started = time.monotonic()
with (OUTPUT / 'PublicAndSafeAudit.log').open('wb') as stream:
    process = subprocess.Popen(command, cwd=OUTPUT, env=environment,
                               stdout=stream, stderr=subprocess.STDOUT)
    try:
        receipt['exit_code'] = process.wait(timeout=120)
        receipt['status'] = 'PASS' if process.returncode == 0 else 'FAIL'
    except subprocess.TimeoutExpired:
        process.kill()
        receipt['exit_code'] = process.wait()
        receipt['status'] = 'TIMEOUT'
receipt['elapsed_seconds'] = time.monotonic() - started
receipt['finish_epoch'] = time.time()
receipt['log_sha256'] = digest(OUTPUT / 'PublicAndSafeAudit.log')
for name, values in receipt['fresh_inputs'].items():
    for ext, identity in values.items():
        assert digest(SOURCE / (name + ext)) == identity
receipt['input_bytes_unchanged_after_audit'] = True
(OUTPUT / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps(receipt, indent=2))
print((OUTPUT / 'PublicAndSafeAudit.log').read_text()[-2500:])
raise SystemExit(0 if receipt['status'] == 'PASS' else 1)
