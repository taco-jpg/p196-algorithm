#!/usr/bin/python3
"""Run the pinned official Lean binary with explicit trust zero and bounded memory.

This launcher does not change source or the canonical verifier. It records the
actual compiler arguments before replacing itself with that compiler process.
"""
import hashlib
import json
import os
import resource
from pathlib import Path
import sys
import time

LEAN_BINARY = Path('/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean')
LEAN_SHA256 = '92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023'
LAUNCH_LOG = Path(__file__).resolve().parent / 'strict-launches.jsonl'

if hashlib.sha256(LEAN_BINARY.read_bytes()).hexdigest() != LEAN_SHA256:
    raise SystemExit('Pinned Lean executable identity mismatch')
arguments = sys.argv[1:]
if any(arg.startswith(('--trust', '-t', '-M', '--memory')) for arg in arguments):
    raise SystemExit('Caller must not override the strict trust or memory limits')
memory_cap_bytes = 4 * 1024**3
resource.setrlimit(resource.RLIMIT_AS, (memory_cap_bytes, memory_cap_bytes))
effective = [str(LEAN_BINARY), '--trust=0', *arguments]
with LAUNCH_LOG.open('a', encoding='utf-8') as stream:
    stream.write(json.dumps({'time_epoch': time.time(), 'pid': os.getpid(),
                             'cwd': os.getcwd(), 'argv': effective,
                             'lean_sha256': LEAN_SHA256,
                             'rlimit_as_bytes': memory_cap_bytes}) + '\n')
    stream.flush()
    os.fsync(stream.fileno())
os.execv(str(LEAN_BINARY), effective)
