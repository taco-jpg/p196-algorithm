import Lean
#check Lean.collectAxioms
