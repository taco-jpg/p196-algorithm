#!/usr/bin/env python3
"""Check retained PR155 evidence identities and audit coverage without rerunning Lean."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'agent4-pr155'
H = '4c0382b16f0600a3dd07ff36c40793e710b92c96'
allowed = {'propext', 'Classical.choice', 'Quot.sound'}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

checked = []
for attempt, expected in [('001', 'FAIL'), ('002', 'FAIL'), ('003', 'PASS')]:
    folder = ROOT / ('canonical-strict-' + attempt)
    report = json.loads((folder / 'verification.json').read_text())
    assert report['status'] == expected
    assert report['source_commit'] == H and report['source_tree_clean']
    for name, entry in json.loads((folder / 'FILES.json').read_text()).items():
        path = folder / name
        assert path.stat().st_size == entry['bytes']
        assert digest(path) == entry['sha256']
        checked.append(str(path.relative_to(ROOT)))

canonical = json.loads((ROOT / 'canonical-strict-003/verification.json').read_text())
project = canonical['projects']['agent51-reciprocal-moment']
assert project['status'] == 'PASS'
assert len(project['commands']) == 4
assert all(command['exit_code'] == 0 for command in project['commands'])
assert canonical['repository_wide_pass'] is False
assert canonical['catalogue_complete'] is False

registry = json.loads((REPO / 'proofs/Agent51ReciprocalMoment.registry.json').read_text())
audit_source = (ROOT / 'PublicAndSafeAudit.lean').read_text()
public_checks = re.findall(r'^#check (\S+)$', audit_source, re.M)
public_prints = re.findall(r'^#print axioms (\S+)$', audit_source, re.M)
assert len(public_checks) == len(set(public_checks)) == 50
assert public_checks == public_prints

theorem_log = (ROOT / 'canonical-strict-003/agent51-reciprocal-moment/logs/ProjectAudit.log').read_text()
theorems = re.findall(r'^AUDIT_THEOREM (\S+) (\S+) : \[(.*?)\]$', theorem_log, re.M)
assert len(theorems) == len({name for module, name, axioms in theorems}) == 95
union = set()
for module, name, axioms in theorems:
    axset = {x.strip() for x in axioms.split(',') if x.strip()}
    assert axset <= allowed
    union |= axset
assert union == allowed

supplement = json.loads((ROOT / 'supplement-002/result.json').read_text())
assert supplement['status'] == 'PASS' and supplement['exit_code'] == 0
assert supplement['canonical_report_sha256'] == digest(ROOT / 'canonical-strict-003/verification.json')
assert supplement['audit_source_sha256'] == digest(ROOT / 'PublicAndSafeAudit.lean')
assert supplement['launcher_sha256'] == digest(ROOT / 'strict_lean.py')
assert supplement['log_sha256'] == digest(ROOT / 'supplement-002/PublicAndSafeAudit.log')
supplement_log = (ROOT / 'supplement-002/PublicAndSafeAudit.log').read_text()
printed = re.findall(r"^'(\S+)' (depends on axioms: \[(.*?)\]|does not depend on any axioms)$", supplement_log, re.M)
assert [name for name, text, axioms in printed] == public_prints
for name, text, axioms in printed:
    assert {x.strip() for x in axioms.split(',') if x.strip()} <= allowed
definitions = re.findall(r'^AUDIT_SAFE_DEFINITION (\S+) (\S+) : \[(.*?)\]$', supplement_log, re.M)
assert len(definitions) == 11
assert len({name for module, name, axioms in definitions}) == 11
assert all(not axioms.strip() for module, name, axioms in definitions)
exclusions = re.findall(r'^EXCLUDED_.*$', supplement_log, re.M)
assert len(exclusions) == 35

launches = [json.loads(line) for line in (ROOT / 'strict-launches.jsonl').read_text().splitlines()]
accepted_launches = [item for item in launches if '/canonical-strict-003/' in item['cwd'] or item['cwd'].endswith('/supplement-002')]
assert len(accepted_launches) == 5
for item in accepted_launches:
    assert item['argv'][1] == '--trust=0'
    assert '-j1' in item['argv'] and '-DElab.async=false' in item['argv']
    assert item['rlimit_as_bytes'] == 4 * 1024**3
    assert item['lean_sha256'] == '92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023'

freeze = json.loads((ROOT / 'source-freeze.json').read_text())
for name, entry in freeze['modules'].items():
    assert digest(REPO / entry['path']) == entry['sha256']
    assert digest(ROOT / 'canonical-strict-003/agent51-reciprocal-moment/source' / (name + '.lean')) == entry['sha256']
    for ext, identity in supplement['fresh_inputs'][name].items():
        assert digest(ROOT / 'canonical-strict-003/agent51-reciprocal-moment/source' / (name + ext)) == identity
head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip()
status = subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=REPO, text=True)
assert head == H and not status

result = {'agent': 'Agent #4', 'status': 'PASS', 'scope': 'Exact PR155 three-module closure and retained evidence consistency only',
          'source_head': H, 'source_tree_clean': True, 'canonical_manifest_members_checked': checked,
          'canonical_report_sha256': digest(ROOT / 'canonical-strict-003/verification.json'),
          'supplement_report_sha256': digest(ROOT / 'supplement-002/result.json'),
          'launcher_sha256': digest(ROOT / 'strict_lean.py'),
          'supplement_source_sha256': digest(ROOT / 'PublicAndSafeAudit.lean'),
          'theorem_counts_by_module': dict(Counter(module for module, name, axioms in theorems)),
          'theorem_axiom_union': sorted(union), 'public_declarations': len(public_checks),
          'safe_definitions': len(definitions), 'safe_definition_axiom_union': [],
          'reported_unsafe_or_partial_implementation_exclusions': len(exclusions),
          'accepted_actual_compiler_launches': accepted_launches,
          'failed_attempts_preserved': ['canonical-strict-001', 'canonical-strict-002', 'supplement-001'],
          'repository_wide_pass': False, 'merge_commit': None,
          'verifier_agent_field_note': 'The unchanged canonical implementation writes Agent #1 in its report. Agent #4 actually executed these new attempts through the separately recorded drivers.'}
(ROOT / 'final-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({key: value for key, value in result.items() if key not in ('canonical_manifest_members_checked', 'accepted_actual_compiler_launches')}, indent=2))
