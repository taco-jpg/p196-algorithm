# PR155 hypothetical combined-tree review

## Finding

Git constructed the frozen hypothetical combination without conflicts. This is a structural preservation result, not mathematical acceptance or integration into main. The combination includes PR148, which remains an unintegrated dependency under the parent assignment. Agent #4 remains delivery owner for PR155; this review does not acquire source ownership from Agent #51, dependency ownership from Agent #28, or the main write slot from Agent #31.

## Frozen identities

| Role | Git identity |
|---|---|
| Observed main M | `74a1c3922eb7af438fe40b23d2105ad07556e3f5` |
| PR155 head H | `4c0382b16f0600a3dd07ff36c40793e710b92c96` |
| Stack base B | `7360b12a0a5889761c845a56a4b8d8a1df5f39b5` |
| Actual merge base of M and H | `54ac7c885e54ce74190b85ec82cceca2b23c2e38` |
| Hypothetical combined tree C | `7c0f8f1942197a10501e689bdc4f0e1a683359cd` |

`git merge-tree --write-tree --messages M H` exited 0 and reported only the tree identity, with no conflict messages. B is an ancestor of H, but B is not an ancestor of M. B must not be substituted for the actual merge base.

## Complete change scope

| Comparison | Added paths | Modified existing paths | Deleted paths |
|---|---:|---:|---:|
| M → C | 38 | 0 | 0 |
| B → C | 4,236 | 0 | 0 |
| B → H | 13 | 0 | 0 |
| H → C | 4,223 | 0 | 0 |

M → C consists exclusively of the 13 PR155 additions and 25 PR148 additions. The latter comprise `proofs/Agent51OverflowSaturation.registry.json` and 24 files beneath `proofs/contributions/agent-51/spectral-overflow-saturation-20261016/`. Those files include the current OverflowDigits, ResidueSums, OverflowWitness and Saturation modules, README, retained failed attempts and drafts, receipts, task evidence, and reviews. No acceptance claim for OverflowWitness, Saturation, or other PR148 mathematics is made here.

B → C contains the 13 PR155 additions plus 4,223 main-side additions absent from H. H → C consists of exactly those 4,223 main-side additions. Thus the large B-relative diff is not PR155 contribution scope. The exhaustive path lists, before/after mode/type/blob identities, and complete patches are retained; no path is omitted from the manifest.

### The 13 PR155 additions

- `proofs/Agent51ReciprocalMoment.registry.json`
- `proofs/contributions/agent-51/spectral-reciprocal-moment-20261016/README.md`
- `proofs/contributions/agent-51/spectral-reciprocal-moment-20261016/ReciprocalMoment.lean`
- `proofs/contributions/agent-51/spectral-reciprocal-moment-20261016/author/AUTHOR_RECEIPT.json`
- `proofs/contributions/agent-51/spectral-reciprocal-moment-20261016/author/attempts/001/ReciprocalMoment.lean`
- `proofs/contributions/agent-51/spectral-reciprocal-moment-20261016/author/attempts/001/compile.log`
- `proofs/contributions/agent-51/spectral-reciprocal-moment-20261016/author/attempts/001/result.json`
- `proofs/contributions/agent-51/spectral-reciprocal-moment-20261016/author/attempts/002/ReciprocalMoment.lean`
- `proofs/contributions/agent-51/spectral-reciprocal-moment-20261016/author/attempts/002/compile.log`
- `proofs/contributions/agent-51/spectral-reciprocal-moment-20261016/author/attempts/002/result.json`
- `proofs/contributions/agent-51/spectral-reciprocal-moment-20261016/claim-receipt.json`
- `proofs/contributions/agent-51/spectral-reciprocal-moment-20261016/review/CONTRACT_REVIEW.md`
- `proofs/contributions/agent-51/spectral-reciprocal-moment-20261016/task.json`

## Preservation checks

All existing file entries of M (22,212), B (18,014), and H (18,027) survive in C with identical mode, object type, and object ID. No existing source was changed or deleted. C contains 22,250 file entries. The 10,976 entries under `proofs/archive/` are identical across the inputs and preserved in C. Both retained PR155 attempt sources and their compile/result logs are among the unchanged 13 additions.

Every frozen module, the PR155 registry, and the canonical verifier matches the SHA-256 value in the captured `source-freeze.json`; all three module Git blob IDs match too:

| Input | SHA-256 in C |
|---|---|
| OverflowDigits | `65adeb3ae7bea93e390a95fc5f8b58ec43f0f64f01ed9db3f51392657ba89a41` |
| ResidueSums | `1333e156e2da6f02a18ff67f83e8ce36955e93c00e425cf67aff713f916140d4` |
| ReciprocalMoment | `76bad5a81d0fd7ddbd8c3a9a6a1fee433573b1276f4ba84b9b90b11967afc11a` |
| registry | `186a233cefeeb506a4cfacb109129f83df85abade478844ab4ab51de3da1bffd` |
| canonical-verifier | `c047ff1ff1fe12b2c2094ca5f36af871b1c6faf89db593a102f9c2f7d48cc98a` |

The canonical verifier path is `proofs/verify_project__214bf7673efe116b.py`. It was read as content and never executed. The frozen-source snapshot is retained as `source-freeze.snapshot.json`; its SHA-256 is `379e15109d193ae1b31ae0820dc473175a980c2fe7da0b0aec88addc107ec8cf`.

### Whitespace diagnostics

`git diff --check M C` and `git diff --check B H` both exited 0. The B → C and H → C checks exited 2 with identical output: 15 trailing-whitespace or final-blank-line notices in the unchanged main-side additions. These notices do not indicate merge conflicts and are not new PR155/PR148 changes. Full diagnostics are retained. No unrelated source was edited to remove them.

## Isolation and execution record

All three input commits were already available; no download or remote operation was used. The worktree uses the common object database at `/workspace/scratch/87258c67b0f5/agent4-pr177/.git/objects`. The merge wrote new objects only into the private `combined-tree-review/objects` directory, with the common database supplied as a read-only alternate. `GIT_OPTIONAL_LOCKS=0` prevented optional index refresh writes. Git replacement objects were disabled. Neither input tree contains `.gitattributes`; system and global attributes were disabled for this invocation, and no nonempty repository `info/attributes` was present.

Before/after checks confirmed unchanged HEAD, unchanged refs, and an unchanged clean worktree. No checkout, update-ref, commit creation, source edit, Lean invocation, remote mutation, or ownership acquisition occurred. The generated object is a tree, not a merge commit.

## Reuse after a real PR148 integration

1. Refresh actual main, PR148 integration outcome, PR155 source head, and the applicable source/target ownership records. Do not assume B ancestry is sufficient or required for all permitted merge methods; inspect the accepted dependency content and provenance.
2. Recompute merge-tree using the new main and current PR155 head. The present tree hash applies only to the exact M/H pair above. If main has changed, this record alone does not establish that the new combination is conflict-free.
3. Compare all 13 PR155 additions, both dependency sources in the frozen closure, the registry, verifier, and all original evidence against this manifest. Any dependency repair or source change invalidates the affected source-specific verification/review scope and requires the appropriate new checks.
4. If the new hypothetical result equals C byte-for-byte and required history/ownership gates remain satisfied, the structural content evidence can be reused accurately. If unrelated content changed but the audited closure remains identical, only the unchanged closure evidence may be reusable under project policy; rerun the affected structural checks and assess actual build coverage.
5. This report supplies no Lean pass, independent mathematical approval of the remaining PR148 modules, platform-check result, source-ready transition, integration-slot claim, or actual main merge. Those obligations remain separate.

## Evidence index

- `manifest.json`: full input identities, exact changed-path maps, preservation checks, source checks, and before/after invariants.
- `summary.json`: PR148/PR155 scope separation and precise result labels.
- `commands.json`: actual commands, exit status, output filenames, and output SHA-256 hashes.
- `environment.json`: only the relevant nonsecret Git isolation settings.
- `merge-tree.stdout` and `.stderr`: actual merge-tree result.
- `diff-*-name-status.stdout`, `diff-*-stat.stdout`, `diff-*-patch.stdout`, and `diff-*-check.stdout`: complete scope, patches, and diagnostics.
- `tree-M.stdout`, `tree-B.stdout`, `tree-H.stdout`, `tree-C.stdout`: exact NUL-delimited recursive tree entries used for preservation checks.
- `inspect_combination.py`: the inspection implementation; it refuses to overwrite an existing run.
- `objects/`: private Git tree objects. Read this tree with the environment recorded in `environment.json` and the original common object database available.
