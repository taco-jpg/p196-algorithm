import Saturation
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check P196.Agent51.witness_polynomialValue
#check P196.Agent51.witness_value_one
#check P196.Agent51.witness_value_neg_one
#check P196.Agent51.witness_sourceS
#check P196.Agent51.witness_sourceR
#check P196.Agent51.overflow_saturation
#check P196.Agent51.even_overflow_saturation
#check P196.Agent51.odd_overflow_saturation
#check P196.Agent51.finiteSum
#check P196.Agent51.finiteSum_eq_range
#check P196.Agent51.polynomialValue
#check P196.Agent51.polynomialValue_eq_finiteSum
#check P196.Agent51.finiteSum_congr
#check P196.Agent51.finiteSum_add_length
#check P196.Agent51.finiteSum_const
#check P196.Agent51.finiteSum_mul_left
#check P196.Agent51.pairWord_polynomial_blocks
#check P196.Agent51.int_one_pow
#check P196.Agent51.pairWord_value_one
#check P196.Agent51.int_pow_add
#check P196.Agent51.neg_one_pow
#check P196.Agent51.alternating_prefix
#check P196.Agent51.power_prefix_shift
#check P196.Agent51.pairWord_value_neg_one
#check P196.Agent51.pairWord_neg_one_dvd
#check P196.Agent51.pairWord_neg_one_even
#check P196.Agent51.sourceS
#check P196.Agent51.sourceR
#check P196.Agent51.pairWord_half_value_one
#check P196.Agent51.pairWord_sourceS
#check P196.Agent51.pairWord_sourceS_nat
#check P196.Agent51.pairWord_sourceR
#check P196.Agent51.residue_parameter
#check P196.Agent51.polynomialValue_congr
#check P196.Agent51.sourceS_congr
#check P196.Agent51.sourceR_congr
#check P196.Agent51.witnessNumber
#check P196.Agent51.witness_canonical
#check P196.Agent51.witness_positive
#check P196.Agent51.witness_columnSum
#check P196.Agent51.witness_not_palindrome
#check P196.Agent51.witness_overflow
#check P196.Agent51.witness_step_palindrome
#check P196.Agent51.witness_step_canonical
#check P196.Agent51.inputDigit
#check P196.Agent51.pairWord
#check P196.Agent51.inputDigit_bounded
#check P196.Agent51.inputDigit_zero
#check P196.Agent51.inputDigit_last
#check P196.Agent51.inputDigit_pair
#check P196.Agent51.pairWord_values
#check P196.Agent51.pairWord_zero
run_cmd do
  let env ← getEnv
  let selected : List String := ["LychrelDigitSums", "OverflowDigits", "OverflowWitness", "ResidueSums", "Saturation"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        match info with
        | .axiomInfo v =>
          if v.isUnsafe then logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {mod} {name}"
          else throwError m!"CUSTOM_AXIOM {mod} {name}"
        | .thmInfo _ =>
          count := count + 1
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          for ax in axl do
            if !(union.contains ax) then union := ax :: union
          if axl.any (fun ax => !(allowed.contains ax)) then throwError m!"DISALLOWED_AXIOMS {mod} {name} : {axl}"
          logInfo m!"AUDIT_THEOREM {mod} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
