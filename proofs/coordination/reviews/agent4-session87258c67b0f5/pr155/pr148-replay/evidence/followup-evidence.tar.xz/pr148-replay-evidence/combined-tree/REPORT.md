# PR148 provisional combined-tree preservation review

## Conclusion and exact scope

**STRUCTURAL COMBINATION VERIFIED.** Combining the pinned main commit with the pinned PR148 head using `git merge-tree --write-tree --messages` produced a conflict-free hypothetical tree containing exactly 25 additions relative to main. No existing main path was modified or deleted. All entries from both input trees retain their exact path, Git mode, object type, and blob identity. The 13 PR155 additions are absent.

This is Git tree and byte-preservation evidence for Agent #28's PR148 delivery. It is not a new mathematical review, a Lean build, a recovery of missing author execution evidence, or an integration into main. Agent #4's separate reproduction must retain its own execution identity and results.

| Identity | Value |
|---|---|
| Pinned main M | `74a1c3922eb7af438fe40b23d2105ad07556e3f5` |
| PR148 head H148 | `7360b12a0a5889761c845a56a4b8d8a1df5f39b5` |
| Actual merge base | `54ac7c885e54ce74190b85ec82cceca2b23c2e38` |
| Hypothetical combined tree T148 | `d6a9dcb8406615e10091e4a8b34e6c0196e7858f` |
| Merge exit code | 0, no conflict messages |
| `git diff --check M T148` | Exit 0 |
| Changes relative to M | 25 added files, 89,711 payload bytes; 0 modifications; 0 deletions |
| Combined tree entries | 22,237 |

The pinned M is the main commit supplied for this task. This inspection performed no remote refresh and makes no claim about a later remote main value.

## Preservation evidence

The actual combined recursive tree was compared with the exact union of the two input maps. Every overlapping path had identical mode, type, and blob. Equality of that complete union with the actual `git ls-tree -rz T148` output establishes preservation across the entire tree, including original sources, archives, documentation, historical failures, and unrelated main contents.

| Input | Entries checked | Changed or missing entries | Archive entries preserved |
|---|---:|---:|---:|
| M | 22,212 | 0 | 10,976 |
| H148 | 18,014 | 0 | 10,976 |

All 25 additions have Git mode `100644` and type `blob`. Their complete path, mode, type, blob ID, byte count, and SHA-256 are recorded in `MANIFEST.json`. The complete patch is retained in `diff-complete.stdout`; the full name-status and stat outputs are retained separately. All 25 patch sections were inspected. Their classification is recorded per path in `CONTENT_CLASSIFICATION.json`.

To avoid copying previously frozen multi-megabyte maps, this review verified and reused the following immutable references under `/workspace/scratch/87258c67b0f5/pr155-evidence/combined-tree-review/`:

| Reference | Bytes | SHA-256 |
|---|---:|---|
| `tree-M.stdout` | 3,967,128 | `a8289e7067a247532d09ca036bee3db660fcbff0061d76265c32278858bf4061` |
| `tree-B.stdout` (B is H148) | 3,251,994 | `8a979d2df9d09b8791cd63f58372fe6f88f060c4a8239b73c877b4a27606f772` |
| `manifest.json` | 2,930,476 | `647c659ea48de9e2cdac6294746f6c74cd47b5bff6a6e67a7471524975eb016e` |

The actual combined NUL-delimited recursive map contains 3,971,065 bytes with SHA-256 `e652793433c4818d95e0e0c256e8c1c567aefc3b2fc7568bedbe70b3a58ada0d`. It is represented without another full copy by the hash-pinned M map plus the 25 exact additions, or equivalently by the union of the two referenced input maps. The corresponding command and output hash are recorded in `commands.json`.

The original mathematical source named by the registry is also directly byte-checked:

- Path: `proofs/archive/source-trees/2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5/proofs/research/astra_spectral_carry_quotient.md`
- Git blob: `eac5b8f61385a615d9cc3e7796a4d698c66b716b`
- SHA-256: `d39212c9ab98f4c5b0fccb733d3b662e41a09804878178c82b8762684e97fb09`
- Exact same entry in M, H148, and T148. See `ORIGINAL_SOURCE.json`.

## Registry, verifier, and five-module closure

The canonical verifier, the PR148 registry, and all five registered modules were read from T148 and matched against the H148 input receipt in `../runtime-plan/INPUT_MANIFEST.json`, whose SHA-256 is `b1c910b0c1f078eaf8571f6e50080aa48ee3ce5aa8c8e4baff4a64308e07b278`. Both Git blob identity and SHA-256 match for every input.

| Input | Bytes | SHA-256 |
|---|---:|---|
| `proofs/verify_project__214bf7673efe116b.py` | 14,531 | `c047ff1ff1fe12b2c2094ca5f36af871b1c6faf89db593a102f9c2f7d48cc98a` |
| `proofs/Agent51OverflowSaturation.registry.json` | 5,376 | `7622d9321f96acecb583ac1958cc72691fa5e3da92fc044908464d4d6fd767e3` |
| `Saturation.lean` | 4,387 | `e2379506a0b70c1502fea88e8daff4241282be73f6f11672effff182a10bc722` |
| `ResidueSums.lean` | 10,515 | `1333e156e2da6f02a18ff67f83e8ce36955e93c00e425cf67aff713f916140d4` |
| `OverflowWitness.lean` | 3,241 | `fbf7568256e31948a20563e5d9e1335ce45b6859d2343917395180970114c901` |
| `OverflowDigits.lean` | 1,378 | `65adeb3ae7bea93e390a95fc5f8b58ec43f0f64f01ed9db3f51392657ba89a41` |
| `proofs/LychrelDigitSums__0810ace083af80c5.lean` | 218,799 | `ca5f46523b7cff02c00918b6466a97963087b499fb5f184232b8b3d806dc0b57` |

The four short module names in the table are under `proofs/contributions/agent-51/spectral-overflow-saturation-20261016/`. The canonical verifier and legacy Lychrel dependency are existing, unchanged main files. Registry entries themselves match the five recorded source hashes and blobs. None of the historical `evidence/` files is registered as a module.

Byte preservation allows a separately qualified verification of these exact inputs to be associated with this hypothetical tree's matching source closure. This report supplies no execution verdict or new proof-integrity verdict.

## Complete addition scope and retained history

| Category | Added files | Treatment |
|---|---:|---|
| Current registry | 1 | Exact H148 registry retained |
| Current registered Lean sources | 4 | Exact H148 candidate source bytes retained |
| Scope and attribution README | 1 | Historical checkpoint wording retained |
| Historical author attempt files | 13 | All source snapshots, logs, and result receipts retained, including failures and the empty log |
| Historical draft | 1 | Preserved outside the registered source closure |
| Dependency, publication, and task records | 3 | Original attribution and historical states retained |
| Existing semantic reviews | 2 | Original reviewer statements retained with their stated limits |
| **Total** | **25** | No PR155 additions |

The historical `OverflowWitness-001` and `OverflowWitness-002` attempts retain their failed source files, unknown-identifier error logs, `sorryAx` output, and `FAIL` result records. They use the unsuccessful namespace references `DecimalDigits.canonical_next_overflow` and `DecimalDynamics.canonical_next_overflow`. They are development failure evidence outside the registered closure; they are not accepted proof evidence.

The current registered `OverflowWitness.lean` uses `FoldedDecimal.canonical_next_overflow` and has the same blob as the retained `OverflowWitness-003` snapshot. The historical third-attempt PASS record is attributed to the original author, without being represented as an execution by this reviewer. The separate draft `evidence/drafts/OverflowWitness-001.lean` is preserved outside the registry and is not converted into an execution claim. The zero-byte `OverflowDigits-001/compile.log` is preserved as a real file.

The existing `review/FINAL_REVIEW.md` explicitly reports a semantic review without a Lean execution by that reviewer, and separates independent rebuilding from semantic review. It cites author records for `ResidueSums-005` and `Saturation-001`; those records are not among these 25 additions. This structural inspection does not recover that absent corpus or promote the review summary into a build PASS. The earlier `reviews/CONTRACT_REVIEW.md`, historical task status, publication receipts, and README checkpoint claims are retained unchanged.

The README retains attribution to Agent #51 and its named collaborators and reviewers. No source repair or rewritten historical verdict was introduced. The selected registered sources are identified here as the current candidate closure; mathematical acceptance belongs to the separately qualified review and execution process.

## Isolation, commands, and side effects

All Git operations used `GIT_NO_LAZY_FETCH=1`, `GIT_OPTIONAL_LOCKS=0`, `GIT_NO_REPLACE_OBJECTS=1`, and `GIT_ATTR_NOSYSTEM=1`. Git was invoked with `-c core.attributesFile=/dev/null`; no input-tree `.gitattributes` or nonempty common `info/attributes` was present. Patch operations disabled external diffs and text conversion.

New Git objects were written only to this directory's private `objects/`. The existing object database `/workspace/scratch/87258c67b0f5/agent4-pr177/.git/objects` was used read-only through `GIT_ALTERNATE_OBJECT_DIRECTORIES`. The working-directory context was `/workspace/scratch/87258c67b0f5/agent4-pr155`; no checkout, update-ref, fetch, source modification, or remote operation was performed. Recorded before/after HEAD and refs agree, and the worktree remained clean and unchanged.

`environment.json`, `commands.json`, and `classification-commands.json` record the exact environment overrides, argv, exit codes, output sizes, and hashes. `inspect_tree.py` and `finish_report.py` are the local inspection procedures. They only inspect Git data and write evidence in this assigned directory; they do not run repository scripts or Lean. Existing inspection manifests are protected against an ordinary accidental rerun by exclusive creation/refusal checks.

## Reuse limits and ownership

This evidence is tied to the exact M and H148 above. A different main or PR head requires a fresh structural comparison before making the same claim. An actual merge may have different commit metadata while sharing T148; actual equality of its tree must be checked before treating this exact combined-tree result as applicable. If its tree differs, compare its actual path/mode/type/blob map, all 25 contribution entries, original-source preservation, and the seven verification inputs against the relevant pins; this report alone does not certify the changed tree.

No PR155 source or evidence additions were imported. No PR148 delivery lease, source ownership, or main-writing authority was acquired. Ownership remains Agent #28 for delivery, Agent #51 for source, and Agent #31 for main. Agent #4's support is covered by announcement `6230444562`. All outputs here are local Git-backed evidence intended for the authorized coordinator; no publication was performed.
