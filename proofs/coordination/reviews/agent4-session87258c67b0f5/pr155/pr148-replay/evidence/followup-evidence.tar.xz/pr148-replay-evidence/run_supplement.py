#!/usr/bin/env python3
"""Audit every registered public declaration and safe definition in the new PR148 closure."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
HEAD = '7360b12a0a5889761c845a56a4b8d8a1df5f39b5'
if len(sys.argv) != 3 or any(not x.isdecimal() or len(x) != 3 for x in sys.argv[1:]):
    raise SystemExit('Use canonical attempt and supplemental attempt as three-digit identifiers')
BUILD = ROOT / ('canonical-strict-' + sys.argv[1])
SOURCE = BUILD / 'agent51-overflow-saturation/source'
OUTPUT = ROOT / ('supplement-' + sys.argv[2])
OUTPUT.mkdir(exist_ok=False)

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

canonical = json.loads((BUILD / 'verification.json').read_text())
freeze = json.loads((ROOT / 'source-freeze.json').read_text())
assert canonical['status'] == 'PASS' and canonical['source_commit'] == HEAD
assert canonical['source_tree_clean'] is True and canonical['repository_wide_pass'] is False
audit = ROOT / 'PublicAndSafeAudit.lean'
assert digest(audit) == freeze['supplement_audit_sha256']
assert digest(ROOT / 'strict_lean.py') == freeze['launcher_sha256']
for path, identity in canonical['compiler']['files'].items():
    assert digest(Path(path)) == identity, path
(OUTPUT / audit.name).write_bytes(audit.read_bytes())
command = [str(ROOT / 'strict_lean.py'), '-j1', '-DElab.async=false', audit.name]
environment = {'PATH': str(ROOT) + ':/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LEAN_PATH': str(SOURCE)}
receipt = {'agent': 'Agent #4', 'classification': 'NEW_EXECUTION_NOT_ORIGINAL_ARCHIVE_RECOVERY',
           'source_head': HEAD, 'command': command, 'cwd': str(OUTPUT), 'environment': environment,
           'canonical_report_sha256': digest(BUILD / 'verification.json'),
           'audit_source_sha256': digest(audit), 'launcher_sha256': digest(ROOT / 'strict_lean.py'),
           'driver_sha256': digest(Path(__file__)), 'start_epoch': time.time(),
           'status': 'RUNNING', 'timeout_seconds': 180, 'fresh_inputs': {},
           'compiler_files': canonical['compiler']['files']}
for name in freeze['module_selection']:
    receipt['fresh_inputs'][name] = {ext: digest(SOURCE / (name + ext)) for ext in ('.lean', '.olean')}
(OUTPUT / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
started = time.monotonic()
with (OUTPUT / 'PublicAndSafeAudit.log').open('wb') as stream:
    process = subprocess.Popen(command, cwd=OUTPUT, env=environment,
                               stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    try:
        receipt['exit_code'] = process.wait(timeout=receipt['timeout_seconds'])
        receipt['status'] = 'PASS' if process.returncode == 0 else 'FAIL'
    except subprocess.TimeoutExpired:
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        receipt['exit_code'] = process.returncode
        receipt['status'] = 'TIMEOUT'
receipt['elapsed_seconds'] = time.monotonic() - started
receipt['finish_epoch'] = time.time()
receipt['log_sha256'] = digest(OUTPUT / 'PublicAndSafeAudit.log')
for name, values in receipt['fresh_inputs'].items():
    for ext, identity in values.items():
        assert digest(SOURCE / (name + ext)) == identity
for path, identity in receipt['compiler_files'].items():
    assert digest(Path(path)) == identity, path
receipt['input_and_compiler_bytes_unchanged_after_audit'] = True
(OUTPUT / 'result.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'status': receipt['status'], 'exit_code': receipt['exit_code'],
                  'elapsed_seconds': receipt['elapsed_seconds'], 'receipt': str(OUTPUT / 'result.json')}, indent=2))
print((OUTPUT / 'PublicAndSafeAudit.log').read_text()[-2500:])
raise SystemExit(0 if receipt['status'] == 'PASS' else 1)
