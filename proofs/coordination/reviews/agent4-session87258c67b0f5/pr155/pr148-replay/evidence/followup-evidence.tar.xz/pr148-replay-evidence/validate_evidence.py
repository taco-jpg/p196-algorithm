#!/usr/bin/env python3
"""Validate the retained new PR148 execution corpus without repeating Lean."""
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'agent4-pr148'
HEAD = '7360b12a0a5889761c845a56a4b8d8a1df5f39b5'
PROJECT = 'agent51-overflow-saturation'
BUILD = ROOT / 'canonical-strict-001'
SOURCE = BUILD / PROJECT / 'source'
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def axioms(text):
    return {x.strip() for x in text.split(',') if x.strip()}

freeze = json.loads((ROOT / 'source-freeze.json').read_text())
canonical = json.loads((BUILD / 'verification.json').read_text())
project = canonical['projects'][PROJECT]
assert canonical['status'] == project['status'] == 'PASS'
assert canonical['source_commit'] == freeze['source_head'] == HEAD
assert canonical['source_tree_clean'] is True
assert canonical['repository_wide_pass'] is False and canonical['catalogue_complete'] is False
checked = []
for name, entry in json.loads((BUILD / 'FILES.json').read_text()).items():
    path = BUILD / name
    assert path.stat().st_size == entry['bytes'] and digest(path) == entry['sha256'], name
    checked.append(name)
assert len(project['commands']) == 6
assert [c['label'] for c in project['commands']] == freeze['module_selection'] + ['ProjectAudit']
assert all(c['exit_code'] == 0 for c in project['commands'])
for command in project['commands']:
    assert digest(BUILD / command['log']) == command['log_sha256']
registry = json.loads((REPO / 'proofs/Agent51OverflowSaturation.registry.json').read_text())
public = [e for c in registry['claims'] if c['project'] == PROJECT for e in c['endpoints']]
assert len(public) == len(set(public)) == 52
assert project['endpoints'] == freeze['public_declarations'] == public
audit_text = (ROOT / 'PublicAndSafeAudit.lean').read_text()
assert re.findall(r'^#check (\S+)$', audit_text, re.M) == public
assert re.findall(r'^#print axioms (\S+)$', audit_text, re.M) == public
assert digest(ROOT / 'PublicAndSafeAudit.lean') == freeze['supplement_audit_sha256']

theorem_log = (BUILD / PROJECT / 'logs/ProjectAudit.log').read_text()
theorems = re.findall(r'^AUDIT_THEOREM (\S+) (\S+) : \[([^\]]*)\]$', theorem_log, re.M)
assert len(theorems) == len({name for module, name, axs in theorems}) == project['theorem_count'] == 1083
summary = re.findall(r'^FULL_MODULE_AUDIT theorems=(\d+) union=\[([^\]]*)\]$', theorem_log, re.M)
assert len(summary) == 1 and int(summary[0][0]) == len(theorems)
theorem_union = set()
for module, name, raw in theorems:
    assert module in freeze['module_selection'] and axioms(raw) <= ALLOWED
    theorem_union |= axioms(raw)
assert theorem_union == axioms(summary[0][1]) == ALLOWED

supplement = json.loads((ROOT / 'supplement-001/result.json').read_text())
assert supplement['status'] == 'PASS' and supplement['exit_code'] == 0
assert supplement['source_head'] == HEAD
assert supplement['canonical_report_sha256'] == digest(BUILD / 'verification.json')
assert supplement['audit_source_sha256'] == digest(ROOT / 'PublicAndSafeAudit.lean')
assert supplement['launcher_sha256'] == digest(ROOT / 'strict_lean.py')
assert supplement['driver_sha256'] == digest(ROOT / 'run_supplement.py')
assert supplement['log_sha256'] == digest(ROOT / 'supplement-001/PublicAndSafeAudit.log')
assert supplement['input_and_compiler_bytes_unchanged_after_audit'] is True
log = (ROOT / 'supplement-001/PublicAndSafeAudit.log').read_text()
printed = re.findall(r"^'(\S+)' (depends on axioms: \[([^\]]*)\]|does not depend on any axioms)$", log, re.M)
assert [name for name, text, raw in printed] == public
public_union = set()
for name, text, raw in printed:
    assert axioms(raw) <= ALLOWED
    public_union |= axioms(raw)
definitions = re.findall(r'^AUDIT_SAFE_DEFINITION (\S+) (\S+) : \[([^\]]*)\]$', log, re.M)
assert len(definitions) == len({name for module, name, raw in definitions}) == 141
definition_union = set()
for module, name, raw in definitions:
    assert module in freeze['module_selection'] and axioms(raw) <= ALLOWED
    definition_union |= axioms(raw)
summary = re.findall(r'^FULL_SAFE_DEFINITION_AUDIT definitions=(\d+) union=\[([^\]]*)\] excluded=(\d+)$', log, re.M)
exclusions = re.findall(r'^(EXCLUDED_\S+) (\S+) (\S+)$', log, re.M)
assert len(summary) == 1 and int(summary[0][0]) == len(definitions)
assert definition_union == axioms(summary[0][1]) == {'propext'}
assert int(summary[0][2]) == len(exclusions) == 813
assert len({name for kind, module, name in exclusions}) == len(exclusions)
assert all(module in freeze['module_selection'] for kind, module, name in exclusions)
assert not ({name for kind, module, name in exclusions} & set(public))

launches = [json.loads(line) for line in (ROOT / 'strict-launches.jsonl').read_text().splitlines()]
assert len(launches) == 9
proof_launches = [x for x in launches if '/canonical-strict-001/' in x['cwd'] or x['cwd'].endswith('/supplement-001')]
assert len(proof_launches) == 7
for launch in launches:
    assert launch['argv'][1] == '--trust=0'
    assert launch['rlimit_as_bytes'] == 4 * 1024**3
    assert launch['lean_sha256'] == '92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023'
for launch in proof_launches:
    assert '-j1' in launch['argv'] and '-DElab.async=false' in launch['argv']
for record in freeze['source_files']:
    assert digest(REPO / record['path']) == record['sha256']
    assert digest(ROOT / 'inputs/repository' / record['path']) == record['sha256']
for name, record in registry['projects'][PROJECT]['modules'].items():
    assert digest(SOURCE / (name + '.lean')) == record['sha256']
    for ext, identity in supplement['fresh_inputs'][name].items():
        assert digest(SOURCE / (name + ext)) == identity
for path, identity in canonical['compiler']['files'].items():
    assert digest(Path(path)) == identity
driver = json.loads((ROOT / 'canonical-driver-001.json').read_text())
assert driver['status'] == 'PASS' and driver['exit_code'] == 0
assert driver['driver_sha256'] == digest(ROOT / 'run_canonical.py')
assert driver['console_sha256'] == digest(ROOT / 'canonical-console-001.log')
assert driver['launcher_sha256'] == digest(ROOT / 'strict_lean.py') == freeze['launcher_sha256']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=REPO, text=True).strip() == HEAD
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=REPO)

result = {
    'agent': 'Agent #4', 'status': 'PASS', 'classification': 'NEW_EXECUTION_NOT_ORIGINAL_ARCHIVE_RECOVERY',
    'source_head': HEAD, 'source_tree_clean': True, 'scoped_project': PROJECT,
    'fresh_modules': 5, 'canonical_commands': 6, 'supplemental_commands': 1,
    'canonical_elapsed_seconds': driver['elapsed_seconds'], 'supplement_elapsed_seconds': supplement['elapsed_seconds'],
    'canonical_manifest_members_checked': checked,
    'canonical_report_sha256': digest(BUILD / 'verification.json'),
    'supplement_report_sha256': digest(ROOT / 'supplement-001/result.json'),
    'canonical_theorem_log_sha256': digest(BUILD / PROJECT / 'logs/ProjectAudit.log'),
    'supplement_log_sha256': digest(ROOT / 'supplement-001/PublicAndSafeAudit.log'),
    'launcher_sha256': digest(ROOT / 'strict_lean.py'), 'supplement_audit_sha256': digest(ROOT / 'PublicAndSafeAudit.lean'),
    'theorem_counts_by_module': dict(Counter(module for module, name, raw in theorems)),
    'theorem_constants': len(theorems), 'theorem_axiom_union': sorted(theorem_union),
    'safe_definitions_by_module': dict(Counter(module for module, name, raw in definitions)),
    'safe_definitions': len(definitions), 'safe_definition_axiom_union': sorted(definition_union),
    'public_declarations': len(public), 'public_axiom_union': sorted(public_union),
    'implementation_exclusions': len(exclusions),
    'implementation_exclusions_by_kind': dict(Counter(kind for kind, module, name in exclusions)),
    'actual_proof_compiler_launches': proof_launches, 'toolchain_probe_launches': 2,
    'new_failed_lean_attempts': [],
    'published_author_failed_attempts': 'Retained byte-exact under inputs/repository/proofs/contributions/agent-51/spectral-overflow-saturation-20261016/evidence/',
    'original_117_payload_archive_recovered': False,
    'historical_count_note': 'This execution counts theorem constants and safe definitions separately; it does not retrospectively validate the original unavailable 1238-safe-declaration summary.',
    'resource_measurement_limit': 'The retained /proc peak sample covers the Python supervisor only. No Lean peak RSS is claimed. The hard 4GiB address-space cap is present in all actual compiler launcher records.',
    'canonical_agent_label_note': 'The unmodified canonical verifier writes Agent #1 in its report. Agent #4 actually executed this distinct replay; the original field is preserved.',
    'repository_wide_pass': False, 'merge_commit': None
}
(ROOT / 'final-verification.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k:v for k,v in result.items() if k not in ('canonical_manifest_members_checked','actual_proof_compiler_launches')}, indent=2))
