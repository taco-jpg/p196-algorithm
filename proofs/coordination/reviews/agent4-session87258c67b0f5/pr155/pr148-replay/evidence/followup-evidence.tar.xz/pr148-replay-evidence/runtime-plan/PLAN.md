# PR148 new replay: runtime preparation plan

Status: **PREPARED_NOT_EXECUTED**. This plan supports a new explicitly identified reproduction, not recovery of the missing historical corpus. No Lean process, repository script, compiler version probe, source snapshot creation, source modification, remote operation, or ownership claim was performed.

## Scope and ownership

The frozen candidate is PR148 head `7360b12a0a5889761c845a56a4b8d8a1df5f39b5`, as recorded in the parent's existing PR148 queue snapshot. The parent is awaiting a fresh scout before execution; this local inspection is not a fresh remote-state check. Agent #28 retains delivery ownership, Agent #51 source ownership, and Agent #31 main ownership. The replay is a dependency action for Agent #4's PR155 delivery.

The currently inspected checkout `/workspace/scratch/87258c67b0f5/agent4-pr155` is at `4c0382b16f0600a3dd07ff36c40793e710b92c96`. Local Git comparisons, with `GIT_NO_LAZY_FETCH=1`, `GIT_OPTIONAL_LOCKS=0`, and `GIT_NO_REPLACE_OBJECTS=1`, establish that the unchanged canonical verifier, PR148 registry, and all five required source files are byte-identical to H148. No object download was attempted.

## Minimal source inputs

| Role | Exact repository path |
|---|---|
| Canonical verifier | `proofs/verify_project__214bf7673efe116b.py` |
| Registry | `proofs/Agent51OverflowSaturation.registry.json` |
| LychrelDigitSums | `proofs/LychrelDigitSums__0810ace083af80c5.lean` |
| OverflowDigits | `proofs/contributions/agent-51/spectral-overflow-saturation-20261016/OverflowDigits.lean` |
| OverflowWitness | `proofs/contributions/agent-51/spectral-overflow-saturation-20261016/OverflowWitness.lean` |
| ResidueSums | `proofs/contributions/agent-51/spectral-overflow-saturation-20261016/ResidueSums.lean` |
| Saturation | `proofs/contributions/agent-51/spectral-overflow-saturation-20261016/Saturation.lean` |

The verifier SHA-256 is `c047ff1ff1fe12b2c2094ca5f36af871b1c6faf89db593a102f9c2f7d48cc98a`. The registry SHA-256 is `7622d9321f96acecb583ac1958cc72691fa5e3da92fc044908464d4d6fd767e3`. `INPUT_MANIFEST.json` records every source's bytes, SHA-256, Git blob, imports, and equality against H148. No Mathlib package is needed; the closure uses the installed pinned Lean/Std libraries.

## Reuse the passed launcher without changing frozen PR155 evidence

The existing launcher is `/workspace/scratch/87258c67b0f5/pr155-evidence/strict_lean.py`, SHA-256 `a9d32e8bb8658a25b799d3bf2f466c8862a95e25b8fd2e44ab042af931b11dec`. Its actual 4-GiB/trust-zero form passed PR155 canonical attempt003. Copy its exact bytes and executable mode into the new PR148 evidence directory before use. **Do not execute the original PR155 launcher path:** it appends `strict-launches.jsonl` beside itself and would alter the frozen PR155 package.

The launcher verifies the pinned executable SHA-256, rejects caller trust/memory overrides, applies `RLIMIT_AS=4294967296`, prepends `--trust=0`, records effective argv/cwd/PID/cap, and execs the compiler. The verifier supplies `-j1 -DElab.async=false`. The launcher uses neither the problematic `-M` flag nor the insufficient earlier 2-GiB cap. Preserve the previous failed PR155 attempts as historical evidence; they are not new PR148 results.

The executable is `/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean`, SHA-256 `92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023`. All five runtime files recorded by the prior canonical PASS (executable and four shared libraries) currently match those hashes; see `RUNTIME_MANIFEST.json`. Version evidence is the retained prior run: Lean 4.19.0, commit 6caaee842e94. No fresh compiler execution was performed here.

## Invocation and accurate provenance

The canonical verifier sets ROOT from its own file location and records `git rev-parse HEAD` and tracked-worktree cleanliness there. Running it directly from `agent4-pr155` would truthfully record H155, not H148. For an exact-H148 run, the parent should create a genuine isolated H148 checkout containing the original verifier at its original relative path. A plain data copy without valid Git provenance may fail or report an enclosing unrelated HEAD; do not fabricate a Git identity to avoid that requirement.

Proposed paths, for the parent to create, are `/workspace/scratch/87258c67b0f5/pr148-replay-source` and `/workspace/scratch/87258c67b0f5/pr148-replay-evidence`. `INVOCATION.json` contains the exact argument vector. With those proposed paths:

```bash
python3 -B /workspace/scratch/87258c67b0f5/pr148-replay-source/proofs/verify_project__214bf7673efe116b.py \
  --lean /workspace/scratch/87258c67b0f5/pr148-replay-evidence/strict_lean.py \
  --project agent51-overflow-saturation \
  --registry /workspace/scratch/87258c67b0f5/pr148-replay-source/proofs/Agent51OverflowSaturation.registry.json \
  --output /workspace/scratch/87258c67b0f5/pr148-replay-evidence/canonical-strict-001
```

Use the already approved execution mechanism required by this installed runtime; ordinary sandbox execution previously reported `failed to locate application`. The original PR155 `run_canonical.py` is a reference for parent supervision only: it is hard-coded to PR155 paths/project and must not be invoked as a PR148 driver. A new parent-owned wrapper can record the new command, cap, timer, hashes, stdout/stderr and process-group termination while leaving the canonical verifier and launcher bytes unchanged.

## Budget and expected operations

The actual registry-driven compilation order is:

1. LychrelDigitSums
2. OverflowDigits
3. OverflowWitness
4. ResidueSums
5. Saturation
6. Generated ProjectAudit

There are five source compilations and one audit command, executed sequentially. The verifier also invokes the launcher for `--version` and `--print-prefix`, so expect eight launch records for a fully successful canonical run. It reuses no prior project objects: it creates a new output directory and copies the exact source closure before compiling it. The copied modules retain their original logical bytes and imports; no adapter is specified in this registry.

Recommend the existing PR155 supervisor's 300-second outer budget for the initial bounded attempt, one Lean process at a time, one Lean thread, and the unchanged 4-GiB address-space cap. The canonical verifier's own per-command timeout is 1,800 seconds; the shorter outer supervisor limit controls this attempt. This is a budget, not a runtime prediction or a success guarantee.

The published author receipt reports LychrelDigitSums source compilation in 74.085780703 seconds, peak RSS 2,351,604 KiB, with a **6-GiB** address-space cap and 1,800-second wall cap. The source hash matches the current registry. This makes the legacy module the known budget concern, but does not establish that it fits a 4-GiB virtual-address cap in the new run. If it fails or times out, preserve the exact new command/log/resource receipt and diagnose that failure before considering a changed cap or another attempt. Do not reinterpret the historical author PASS as the new run's outcome.

## Required retained output and acceptance interpretation

For proposed output root `canonical-strict-001`, retain:

- `verification.json`, including actual source_commit, source_tree_clean, registry/compiler hashes, source/build hashes, order, command exits/times, theorem count, axiom union, endpoints and unsafe implementation inventory.
- `FILES.json`, generated source snapshots, generated `ProjectAudit.lean`, and all six logs under `agent51-overflow-saturation/logs/`.
- `failure.txt` when produced; outer console/driver receipts even if the supervisor interrupts before the verifier's finalizer writes its usual files.
- The copied launcher's sibling `strict-launches.jsonl` and exact launcher/driver bytes.
- Original published claims, historical failed attempts and logs already retained by the parent; identify this attempt as a new reproduction.

The unchanged canonical verifier checks all five source SHA-256/Git pins, import closure, forbidden tokens, source immutability, and the declared toolchain. It performs `#check` on 52 registered endpoints and audits actual-origin theorem constants throughout the five-module closure. Allowed logical axioms are only `propext`, `Classical.choice`, and `Quot.sound`; safe custom axioms cause failure, while unsafe compiler implementation axioms are separately listed.

**Scope limit:** its generated audit does not separately enumerate all safe definitions/opaques or print axioms for each public definition. It also does not assert fixed historical theorem counts. A canonical PASS must not be described as a separate supplemental safe-definition audit. The procedure reviewer should determine any precisely uncovered audit obligation; this specialist has not created or executed an additional audit.

A successful result remains a scoped new reproduction, with `repository_wide_pass=false`. It does not recover the missing original corpus, accept an ownership handoff, or integrate PR148/PR155 into main. Execution remains gated on the parent's fresh scout and independent procedure review.
