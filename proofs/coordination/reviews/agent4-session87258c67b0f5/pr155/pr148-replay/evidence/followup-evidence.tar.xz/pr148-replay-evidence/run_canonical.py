#!/usr/bin/env python3
"""Run the unmodified exact-H148 verifier and retain a bounded new execution."""
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'agent4-pr148'
HEAD = '7360b12a0a5889761c845a56a4b8d8a1df5f39b5'
attempt = sys.argv[1]
if not attempt.isdecimal() or len(attempt) != 3:
    raise SystemExit('Use one three-digit attempt identifier')
output = ROOT / f'canonical-strict-{attempt}'
driver = ROOT / f'canonical-driver-{attempt}.json'
console = ROOT / f'canonical-console-{attempt}.log'
if any(path.exists() for path in (output, driver, console)):
    raise SystemExit('Refusing to overwrite an existing attempt')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

freeze = json.loads((ROOT / 'source-freeze.json').read_text())
assert freeze['source_head'] == HEAD
for rec in freeze['source_files']:
    assert digest(SOURCE / rec['path']) == rec['sha256'], rec['path']
assert digest(ROOT / 'strict_lean.py') == freeze['launcher_sha256']
assert subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=SOURCE, text=True).strip() == HEAD
assert not subprocess.check_output(['git', 'status', '--porcelain', '--untracked-files=no'], cwd=SOURCE)
command = [sys.executable, '-B', str(SOURCE / 'proofs/verify_project__214bf7673efe116b.py'),
           '--lean', str(ROOT / 'strict_lean.py'), '--project', 'agent51-overflow-saturation',
           '--registry', str(SOURCE / 'proofs/Agent51OverflowSaturation.registry.json'),
           '--output', str(output)]
receipt = {'agent': 'Agent #4', 'classification': 'NEW_EXECUTION_NOT_ORIGINAL_ARCHIVE_RECOVERY',
           'source_head': HEAD, 'command': command, 'cwd': str(SOURCE),
           'start_epoch': time.time(), 'status': 'RUNNING', 'max_wall_seconds': 600,
           'lean_rlimit_as_bytes': 4 * 1024**3, 'launcher_sha256': digest(ROOT / 'strict_lean.py'),
           'driver_sha256': digest(Path(__file__)),
           'canonical_verifier_sha256': digest(SOURCE / 'proofs/verify_project__214bf7673efe116b.py'),
           'resource_note': 'Cgroup observations are shared; descendant process observations refer only to this launched verifier.',
           'process_peak_samples': {}}

def snapshot(stage):
    for name in ('memory.current', 'memory.max', 'memory.events', 'memory.stat'):
        path = Path('/sys/fs/cgroup') / name
        if path.exists():
            receipt[f'{stage}_{name}'] = path.read_text()

def sample_tree(pid):
    try:
        base = Path('/proc') / str(pid)
        status = (base / 'status').read_text()
        fields = dict(line.split(':', 1) for line in status.splitlines() if ':' in line)
        rec = receipt['process_peak_samples'].setdefault(str(pid), {'name': fields.get('Name', '').strip()})
        for key in ('VmPeak', 'VmHWM', 'VmSize', 'VmRSS'):
            if key in fields:
                value = int(fields[key].split()[0])
                rec[key + '_max_kib'] = max(value, rec.get(key + '_max_kib', 0))
        for child in (base / 'task' / str(pid) / 'children').read_text().split():
            sample_tree(int(child))
    except (FileNotFoundError, ProcessLookupError, PermissionError):
        pass

snapshot('before')
driver.write_text(json.dumps(receipt, indent=2) + '\n')
started = time.monotonic()
with console.open('wb') as stream:
    process = subprocess.Popen(command, cwd=SOURCE, stdout=stream,
                               stderr=subprocess.STDOUT, start_new_session=True)
    deadline = started + receipt['max_wall_seconds']
    while process.poll() is None and time.monotonic() < deadline:
        sample_tree(process.pid)
        try:
            process.wait(timeout=min(5, max(0.01, deadline - time.monotonic())))
        except subprocess.TimeoutExpired:
            pass
    if process.poll() is None:
        receipt['status'] = 'TIMEOUT'
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=5)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
    else:
        receipt['status'] = 'PASS' if process.returncode == 0 else 'FAIL'
    receipt['exit_code'] = process.returncode
receipt['elapsed_seconds'] = time.monotonic() - started
receipt['finish_epoch'] = time.time()
receipt['console_sha256'] = digest(console)
snapshot('after')
if receipt['status'] == 'PASS':
    canonical = json.loads((output / 'verification.json').read_text())
    assert canonical['status'] == 'PASS' and canonical['source_commit'] == HEAD
    assert canonical['source_tree_clean'] is True
    for rec in freeze['source_files']:
        assert digest(SOURCE / rec['path']) == rec['sha256'], rec['path']
    receipt['source_inputs_unchanged'] = True
driver.write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'status': receipt['status'], 'exit_code': receipt['exit_code'],
                  'elapsed_seconds': receipt['elapsed_seconds'], 'driver_receipt': str(driver)}, indent=2))
print(console.read_text())
raise SystemExit(0 if receipt['status'] == 'PASS' else 1)
