#!/usr/bin/env python3
"""Read back the exact published public archive and verify its complete byte identity."""
import datetime
import hashlib
import json
from pathlib import Path
import time
import urllib.request

ROOT = Path(__file__).resolve().parent / 'remote-readback'
ROOT.mkdir(exist_ok=False)
COMMIT = '286545e5717d2cf9de5c94a8066d28b0e55c24ff'
URL = ('https://raw.githubusercontent.com/taco-jpg/p196-algorithm/' + COMMIT +
       '/proofs/coordination/reviews/agent4-session87258c67b0f5/pr155/evidence/pr155-evidence.tar.xz')
EXPECTED_SIZE = 8696788
EXPECTED_SHA256 = '7074071e389c6f9d70f1ab72cdcb5ca598af48c3e4ffccc58c1484e8e35fb1d7'
EXPECTED_GIT_BLOB = '18b5269920b575977b263eb227cddcdb0c69aadd'
sha256 = hashlib.sha256()
git_blob = hashlib.sha1(b'blob ' + str(EXPECTED_SIZE).encode() + b'\0')
started = time.monotonic()
count = 0
with urllib.request.urlopen(urllib.request.Request(URL, headers={'User-Agent': 'P196-Agent4-evidence-readback'}), timeout=60) as response:
    status = response.status
    final_url = response.url
    with (ROOT / 'pr155-evidence.tar.xz').open('xb') as output:
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            output.write(chunk)
            count += len(chunk)
            sha256.update(chunk)
            git_blob.update(chunk)
result = {'agent': 'Agent #4', 'commit': COMMIT, 'url': URL, 'response_url': final_url,
          'http_status': status, 'bytes': count, 'sha256': sha256.hexdigest(),
          'git_blob': git_blob.hexdigest(), 'elapsed_seconds': time.monotonic() - started,
          'readback_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'status': 'PASS' if (status == 200 and count == EXPECTED_SIZE and
                               sha256.hexdigest() == EXPECTED_SHA256 and
                               git_blob.hexdigest() == EXPECTED_GIT_BLOB) else 'FAIL',
          'scope': 'Full published compressed-byte identity. The identical local archive was already recovered and checked against every original payload and manifest; no Lean execution is repeated.'}
(ROOT / 'result.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps(result, indent=2))
raise SystemExit(0 if result['status'] == 'PASS' else 1)
