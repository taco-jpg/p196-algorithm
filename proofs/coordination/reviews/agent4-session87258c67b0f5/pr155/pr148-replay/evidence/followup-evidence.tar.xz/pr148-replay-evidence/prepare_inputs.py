#!/usr/bin/env python3
"""Freeze exact PR148 inputs for a distinct new replay, preserving published history."""
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT.parent / 'agent4-pr148'
PR155 = ROOT.parent / 'pr155-evidence'
HEAD = '7360b12a0a5889761c845a56a4b8d8a1df5f39b5'
REGISTRY = 'proofs/Agent51OverflowSaturation.registry.json'
PROJECT = 'agent51-overflow-saturation'
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1')

def git(*args):
    return subprocess.check_output(['git', *args], cwd=SOURCE, env=ENV)

def sha(data):
    return hashlib.sha256(data).hexdigest()

assert git('rev-parse', 'HEAD').decode().strip() == HEAD
assert not git('status', '--porcelain', '--untracked-files=no')
registry = json.loads((SOURCE / REGISTRY).read_text())
assert len(registry['projects'][PROJECT]['modules']) == 5
public = [e for c in registry['claims'] if c['project'] == PROJECT for e in c['endpoints']]
assert len(public) == len(set(public)) == 52
contribution = 'proofs/contributions/agent-51/spectral-overflow-saturation-20261016/'
paths = set(git('ls-tree', '-r', '--name-only', HEAD, '--', contribution).decode().splitlines())
paths.update([REGISTRY, 'AGENTS.md', 'proofs/PUBLICATION_POLICY.md',
              'proofs/verify_project__214bf7673efe116b.py',
              registry['claims'][0]['source_path']])
paths.update(m['path'] for m in registry['projects'][PROJECT]['modules'].values())
destination = ROOT / 'inputs/repository'
if destination.exists():
    raise SystemExit('Refusing to overwrite the source snapshot')
records = []
for relative in sorted(paths):
    data = (SOURCE / relative).read_bytes()
    original = git('show', HEAD + ':' + relative)
    assert data == original, relative
    out = destination / relative
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_bytes(data)
    records.append({'path': relative, 'bytes': len(data), 'sha256': sha(data),
                    'git_blob': hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()})
for name, record in registry['projects'][PROJECT]['modules'].items():
    actual = next(x for x in records if x['path'] == record['path'])
    assert actual['sha256'] == record['sha256'], name
    assert actual['git_blob'] == record['git_blob'], name
launcher = (PR155 / 'strict_lean.py').read_bytes()
assert sha(launcher) == 'a9d32e8bb8658a25b799d3bf2f466c8862a95e25b8fd2e44ab042af931b11dec'
assert not (ROOT / 'strict_lean.py').exists()
(ROOT / 'strict_lean.py').write_bytes(launcher)
(ROOT / 'strict_lean.py').chmod(0o755)
prior_audit = (PR155 / 'PublicAndSafeAudit.lean').read_bytes()
assert sha(prior_audit) == 'ab597e30ea4a22d77bbf7acd574a91c37e6492debe2d13b0308bec5320dee720'
tail = prior_audit.decode().split('run_cmd do\n', 1)[1]
old_selection = '["OverflowDigits", "ResidueSums", "ReciprocalMoment"]'
selection = ['LychrelDigitSums', 'OverflowDigits', 'OverflowWitness', 'ResidueSums', 'Saturation']
assert tail.count(old_selection) == 1
tail = tail.replace(old_selection, json.dumps(selection))
audit = 'import Saturation\nimport Lean\nopen Lean Elab Command\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\n'
audit += '\n'.join('#check ' + name for name in public) + '\n'
audit += '\n'.join('#print axioms ' + name for name in public) + '\n'
audit += 'run_cmd do\n' + tail
(ROOT / 'PublicAndSafeAudit.lean').write_text(audit)
receipt = {'agent': 'Agent #4', 'classification': 'NEW_EXECUTION_NOT_ORIGINAL_ARCHIVE_RECOVERY',
           'source_head': HEAD, 'worktree_clean': True, 'source_files': records,
           'public_declarations': public, 'module_selection': selection,
           'canonical_verifier_sha256': sha((SOURCE / 'proofs/verify_project__214bf7673efe116b.py').read_bytes()),
           'launcher_sha256': sha(launcher), 'supplement_audit_sha256': sha(audit.encode()),
           'supplement_template_sha256': sha(prior_audit),
           'supplement_logic_change': 'Only root import, exact 52 public declarations and five-module selection; safe-definition audit body unchanged.',
           'original_archive_recovered': False,
           'original_archive_reported_sha256': '9acf14d0b1eacc34d4ec7334eee37917e7e2367f4406468165de9a10a8930c15',
           'prepared_by_sha256': sha(Path(__file__).read_bytes())}
(ROOT / 'source-freeze.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'status': 'PASS', 'source_head': HEAD, 'files': len(records),
                  'public_declarations': len(public), 'audit_sha256': receipt['supplement_audit_sha256']}, indent=2))
