import Saturation
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check P196.Agent51.witness_polynomialValue
#check P196.Agent51.witness_value_one
#check P196.Agent51.witness_value_neg_one
#check P196.Agent51.witness_sourceS
#check P196.Agent51.witness_sourceR
#check P196.Agent51.overflow_saturation
#check P196.Agent51.even_overflow_saturation
#check P196.Agent51.odd_overflow_saturation
#check P196.Agent51.finiteSum
#check P196.Agent51.finiteSum_eq_range
#check P196.Agent51.polynomialValue
#check P196.Agent51.polynomialValue_eq_finiteSum
#check P196.Agent51.finiteSum_congr
#check P196.Agent51.finiteSum_add_length
#check P196.Agent51.finiteSum_const
#check P196.Agent51.finiteSum_mul_left
#check P196.Agent51.pairWord_polynomial_blocks
#check P196.Agent51.int_one_pow
#check P196.Agent51.pairWord_value_one
#check P196.Agent51.int_pow_add
#check P196.Agent51.neg_one_pow
#check P196.Agent51.alternating_prefix
#check P196.Agent51.power_prefix_shift
#check P196.Agent51.pairWord_value_neg_one
#check P196.Agent51.pairWord_neg_one_dvd
#check P196.Agent51.pairWord_neg_one_even
#check P196.Agent51.sourceS
#check P196.Agent51.sourceR
#check P196.Agent51.pairWord_half_value_one
#check P196.Agent51.pairWord_sourceS
#check P196.Agent51.pairWord_sourceS_nat
#check P196.Agent51.pairWord_sourceR
#check P196.Agent51.residue_parameter
#check P196.Agent51.polynomialValue_congr
#check P196.Agent51.sourceS_congr
#check P196.Agent51.sourceR_congr
#check P196.Agent51.witnessNumber
#check P196.Agent51.witness_canonical
#check P196.Agent51.witness_positive
#check P196.Agent51.witness_columnSum
#check P196.Agent51.witness_not_palindrome
#check P196.Agent51.witness_overflow
#check P196.Agent51.witness_step_palindrome
#check P196.Agent51.witness_step_canonical
#check P196.Agent51.inputDigit
#check P196.Agent51.pairWord
#check P196.Agent51.inputDigit_bounded
#check P196.Agent51.inputDigit_zero
#check P196.Agent51.inputDigit_last
#check P196.Agent51.inputDigit_pair
#check P196.Agent51.pairWord_values
#check P196.Agent51.pairWord_zero
#print axioms P196.Agent51.witness_polynomialValue
#print axioms P196.Agent51.witness_value_one
#print axioms P196.Agent51.witness_value_neg_one
#print axioms P196.Agent51.witness_sourceS
#print axioms P196.Agent51.witness_sourceR
#print axioms P196.Agent51.overflow_saturation
#print axioms P196.Agent51.even_overflow_saturation
#print axioms P196.Agent51.odd_overflow_saturation
#print axioms P196.Agent51.finiteSum
#print axioms P196.Agent51.finiteSum_eq_range
#print axioms P196.Agent51.polynomialValue
#print axioms P196.Agent51.polynomialValue_eq_finiteSum
#print axioms P196.Agent51.finiteSum_congr
#print axioms P196.Agent51.finiteSum_add_length
#print axioms P196.Agent51.finiteSum_const
#print axioms P196.Agent51.finiteSum_mul_left
#print axioms P196.Agent51.pairWord_polynomial_blocks
#print axioms P196.Agent51.int_one_pow
#print axioms P196.Agent51.pairWord_value_one
#print axioms P196.Agent51.int_pow_add
#print axioms P196.Agent51.neg_one_pow
#print axioms P196.Agent51.alternating_prefix
#print axioms P196.Agent51.power_prefix_shift
#print axioms P196.Agent51.pairWord_value_neg_one
#print axioms P196.Agent51.pairWord_neg_one_dvd
#print axioms P196.Agent51.pairWord_neg_one_even
#print axioms P196.Agent51.sourceS
#print axioms P196.Agent51.sourceR
#print axioms P196.Agent51.pairWord_half_value_one
#print axioms P196.Agent51.pairWord_sourceS
#print axioms P196.Agent51.pairWord_sourceS_nat
#print axioms P196.Agent51.pairWord_sourceR
#print axioms P196.Agent51.residue_parameter
#print axioms P196.Agent51.polynomialValue_congr
#print axioms P196.Agent51.sourceS_congr
#print axioms P196.Agent51.sourceR_congr
#print axioms P196.Agent51.witnessNumber
#print axioms P196.Agent51.witness_canonical
#print axioms P196.Agent51.witness_positive
#print axioms P196.Agent51.witness_columnSum
#print axioms P196.Agent51.witness_not_palindrome
#print axioms P196.Agent51.witness_overflow
#print axioms P196.Agent51.witness_step_palindrome
#print axioms P196.Agent51.witness_step_canonical
#print axioms P196.Agent51.inputDigit
#print axioms P196.Agent51.pairWord
#print axioms P196.Agent51.inputDigit_bounded
#print axioms P196.Agent51.inputDigit_zero
#print axioms P196.Agent51.inputDigit_last
#print axioms P196.Agent51.inputDigit_pair
#print axioms P196.Agent51.pairWord_values
#print axioms P196.Agent51.pairWord_zero
run_cmd do
  let env ← getEnv
  let selected : List String := ["LychrelDigitSums", "OverflowDigits", "OverflowWitness", "ResidueSums", "Saturation"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut excluded := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        let eligible : Bool := match info with
          | .defnInfo v => v.safety == .safe
          | .opaqueInfo v => !v.isUnsafe
          | _ => false
        if eligible then
          count := count + 1
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          for ax in axl do
            if !(union.contains ax) then union := ax :: union
          if axl.any (fun ax => !(allowed.contains ax)) then
            throwError m!"DISALLOWED_DEFINITION_AXIOMS {mod} {name} : {axl}"
          logInfo m!"AUDIT_SAFE_DEFINITION {mod} {name} : {axl}"
        else
          match info with
          | .axiomInfo v =>
            if v.isUnsafe then
              excluded := excluded + 1
              logInfo m!"EXCLUDED_UNSAFE_IMPLEMENTATION_AXIOM {mod} {name}"
            else throwError m!"CUSTOM_AXIOM {mod} {name}"
          | .defnInfo _ =>
            excluded := excluded + 1
            logInfo m!"EXCLUDED_UNSAFE_OR_PARTIAL_DEFINITION {mod} {name}"
          | .opaqueInfo _ =>
            excluded := excluded + 1
            logInfo m!"EXCLUDED_UNSAFE_OPAQUE {mod} {name}"
          | _ => pure ()
  logInfo m!"FULL_SAFE_DEFINITION_AUDIT definitions={count} union={union} excluded={excluded}"

