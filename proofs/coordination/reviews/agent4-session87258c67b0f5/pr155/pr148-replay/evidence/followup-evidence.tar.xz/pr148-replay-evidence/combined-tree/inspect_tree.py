#!/usr/bin/env python3
"""Inspect only frozen main plus PR148, with private Git objects and no Lean."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent.parent
REPO = WORKSPACE / "agent4-pr155"
PRIOR = WORKSPACE / "pr155-evidence/combined-tree-review"
M = "74a1c3922eb7af438fe40b23d2105ad07556e3f5"
H = "7360b12a0a5889761c845a56a4b8d8a1df5f39b5"
ENV = os.environ.copy()
ENV.update(GIT_NO_LAZY_FETCH="1", GIT_OPTIONAL_LOCKS="0",
           GIT_NO_REPLACE_OBJECTS="1", GIT_ATTR_NOSYSTEM="1")
COMMANDS = []


def digest(data):
    return hashlib.sha256(data).hexdigest()


def write_json(name, data):
    with (ROOT / name).open("x") as output:
        json.dump(data, output, indent=2)
        output.write("\n")


def git(label, arguments, store=True, allowed=(0,)):
    command = ["git", "-c", "core.attributesFile=/dev/null", *arguments]
    result = subprocess.run(command, cwd=REPO, env=ENV, capture_output=True)
    entry = {"label": label, "argv": command, "cwd": str(REPO),
             "exit_code": result.returncode, "stdout_bytes": len(result.stdout),
             "stdout_sha256": digest(result.stdout), "stderr": result.stderr.decode()}
    if store:
        filename = label + ".stdout"
        (ROOT / filename).write_bytes(result.stdout)
        entry["stdout_file"] = filename
    else:
        entry["stdout_storage"] = "Hash recorded; complete content represented by immutable input maps and exact scoped additions, or already-present source objects."
    COMMANDS.append(entry)
    if result.returncode not in allowed:
        write_json("failed-commands.json", COMMANDS)
        raise RuntimeError(f"{label} exited {result.returncode}")
    return result


def parse_tree(data):
    tree = {}
    for entry in data.split(b"\0"):
        if not entry:
            continue
        metadata, path = entry.split(b"\t", 1)
        mode, kind, oid = metadata.decode().split()
        tree[path.decode()] = {"mode": mode, "type": kind, "oid": oid}
    return tree


if (ROOT / "objects").exists() or (ROOT / "MANIFEST.json").exists():
    raise SystemExit("Refusing to overwrite a prior inspection")
old_manifest_bytes = (PRIOR / "manifest.json").read_bytes()
assert digest(old_manifest_bytes) == "647c659ea48de9e2cdac6294746f6c74cd47b5bff6a6e67a7471524975eb016e"
prior = json.loads(old_manifest_bytes)
assert prior["main_observed"] == M and prior["stack_base"] == H
references = []
maps = {}
for name, filename, expected in [
    ("M", "tree-M.stdout", "a8289e7067a247532d09ca036bee3db660fcbff0061d76265c32278858bf4061"),
    ("H148", "tree-B.stdout", "8a979d2df9d09b8791cd63f58372fe6f88f060c4a8239b73c877b4a27606f772")]:
    data = (PRIOR / filename).read_bytes()
    assert digest(data) == expected
    references.append({"role": name, "path": str(PRIOR / filename), "bytes": len(data), "sha256": expected})
    maps[name] = parse_tree(data)
before_head = git("before-head", ["rev-parse", "HEAD"]).stdout
before_refs = git("before-refs", ["show-ref"]).stdout
before_status = git("before-status", ["status", "--porcelain=v1"]).stdout
assert not before_status
common = Path(git("common-dir", ["rev-parse", "--git-common-dir"]).stdout.decode().strip())
if not common.is_absolute():
    common = (REPO / common).resolve()
attrs = common / "info/attributes"
assert not attrs.exists() or not attrs.read_bytes().strip()
assert not any(Path(p).name == ".gitattributes" for t in maps.values() for p in t)
for name, ref in [("M", M), ("H148", H)]:
    git("commit-" + name, ["cat-file", "-t", ref])
    git("tree-id-" + name, ["rev-parse", ref + "^{tree}"])
base = git("merge-base", ["merge-base", M, H]).stdout.decode().strip()
(ROOT / "objects").mkdir()
ENV["GIT_OBJECT_DIRECTORY"] = str(ROOT / "objects")
ENV["GIT_ALTERNATE_OBJECT_DIRECTORIES"] = str(common / "objects")
environment = {key: ENV[key] for key in ["GIT_NO_LAZY_FETCH", "GIT_OPTIONAL_LOCKS", "GIT_NO_REPLACE_OBJECTS",
              "GIT_ATTR_NOSYSTEM", "GIT_OBJECT_DIRECTORY", "GIT_ALTERNATE_OBJECT_DIRECTORIES"]}
write_json("environment.json", environment)
merge = git("merge-tree", ["merge-tree", "--write-tree", "--messages", M, H], allowed=(0, 1))
T = merge.stdout.decode().splitlines()[0]
actual_tree_raw = git("combined-tree-map", ["ls-tree", "-rz", T], store=False).stdout
combined = parse_tree(actual_tree_raw)
union = dict(maps["M"])
for path, entry in maps["H148"].items():
    if path in union:
        assert union[path] == entry
    union[path] = entry
assert combined == union
added = []
for path in sorted(combined):
    if path not in maps["M"]:
        data = git("blob-" + str(len(added)+1), ["show", T + ":" + path], store=False).stdout
        added.append({"path": path, "status": "A", "before": None, "after": combined[path],
                      "bytes": len(data), "sha256": digest(data)})
pr155_paths = {x["path"] for x in prior["diffs"]["B_to_H"]}
expected_148 = {x["path"] for x in prior["diffs"]["M_to_C"]} - pr155_paths
assert len(added) == 25 and {x["path"] for x in added} == expected_148
assert all(p not in combined for p in pr155_paths)
git("diff-name-status", ["diff", "--no-ext-diff", "--no-textconv", "--no-renames", "--name-status", M, T])
git("diff-stat", ["diff", "--no-ext-diff", "--no-textconv", "--no-renames", "--stat", M, T])
git("diff-complete", ["diff", "--no-ext-diff", "--no-textconv", "--no-renames", "--binary", M, T])
whitespace = git("diff-check", ["diff", "--no-ext-diff", "--no-textconv", "--check", M, T], allowed=(0, 2))
input_manifest_path = ROOT.parent / "runtime-plan/INPUT_MANIFEST.json"
input_manifest_bytes = input_manifest_path.read_bytes()
input_manifest = json.loads(input_manifest_bytes)
checks = []
for item in input_manifest["inputs"]:
    if "path" not in item:
        continue
    data = git("input-" + item["role"], ["show", T + ":" + item["path"]], store=False).stdout
    match = digest(data) == item["sha256"] and combined[item["path"]]["oid"] == item["git_blob"]
    assert match
    checks.append({"role": item["role"], "path": item["path"], "bytes": len(data), "sha256": digest(data),
                   "git_entry": combined[item["path"]], "matches_frozen_H148": match})
after_head = git("after-head", ["rev-parse", "HEAD"]).stdout
after_refs = git("after-refs", ["show-ref"]).stdout
after_status = git("after-status", ["status", "--porcelain=v1"]).stdout
preservation = {}
for name, t in maps.items():
    changed = [p for p, entry in t.items() if combined.get(p) != entry]
    preservation[name] = {"entries": len(t), "changed_or_deleted_paths": changed,
                          "archive_entries": sum(p.startswith("proofs/archive/") for p in t)}
manifest = {"status": "STRUCTURAL_COMBINATION_VERIFIED" if merge.returncode == 0 else "CONFLICTED",
            "M": M, "H148": H, "actual_merge_base": base, "combined_tree": T,
            "merge_exit_code": merge.returncode, "diff_check_exit_code": whitespace.returncode,
            "scope": "PR148 only: 25 additions; all 13 PR155 additions are absent.",
            "added_paths": added, "modified_paths": [], "deleted_paths": [],
            "input_map_references": references, "prior_manifest_reference": {"path": str(PRIOR / "manifest.json"), "sha256": digest(old_manifest_bytes)},
            "combined_map": {"entries": len(combined), "bytes": len(actual_tree_raw), "sha256": digest(actual_tree_raw),
                             "reconstruction": "Exact union of the two hash-pinned NUL-delimited ls-tree input maps. Every overlapping path has identical mode/type/blob. Equivalently, extend M with the 25 added_paths entries."},
            "input_preservation": preservation, "frozen_input_checks": checks,
            "runtime_input_manifest_reference": {"path": str(input_manifest_path), "sha256": digest(input_manifest_bytes)},
            "all_PR155_additions_absent": True, "HEAD_unchanged": before_head == after_head,
            "refs_unchanged": before_refs == after_refs, "worktree_clean_and_unchanged": before_status == after_status == b"",
            "Lean_execution": "NOT_RUN", "mathematical_review": "NOT_PERFORMED",
            "ownership": "Agent28 delivery; Agent51 source; Agent31 main; Agent4 support announcement6230444562; no ownership acquired.",
            "remote_operations": False, "publication": "LOCAL_ONLY"}
write_json("MANIFEST.json", manifest)
write_json("commands.json", COMMANDS)
print(json.dumps({key: manifest[key] for key in ["status", "M", "H148", "actual_merge_base", "combined_tree",
      "merge_exit_code", "diff_check_exit_code", "input_preservation", "all_PR155_additions_absent",
      "HEAD_unchanged", "refs_unchanged", "worktree_clean_and_unchanged"]}, indent=2))
