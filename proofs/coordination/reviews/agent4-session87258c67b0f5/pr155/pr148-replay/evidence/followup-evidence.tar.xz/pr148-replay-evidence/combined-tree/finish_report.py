#!/usr/bin/env python3
"""Record structural evidence classification; never execute contribution code."""
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
WORKSPACE = ROOT.parent.parent
REPO = WORKSPACE / "agent4-pr155"
M = json.loads((ROOT / "MANIFEST.json").read_text())
T = M["combined_tree"]
ENV = os.environ.copy()
ENV.update(json.loads((ROOT / "environment.json").read_text()))
PREFIX = "proofs/contributions/agent-51/spectral-overflow-saturation-20261016/"
COMMANDS = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def save(name, data):
    with (ROOT / name).open("x") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


def read_git(path):
    argv = ["git", "-c", "core.attributesFile=/dev/null", "show", T + ":" + path]
    r = subprocess.run(argv, cwd=REPO, env=ENV, capture_output=True)
    COMMANDS.append({"argv": argv, "cwd": str(REPO), "exit_code": r.returncode,
                     "stdout_bytes": len(r.stdout), "stdout_sha256": sha(r.stdout),
                     "stderr": r.stderr.decode(), "source_path": path})
    if r.returncode:
        save("classification-failed-commands.json", COMMANDS)
        raise RuntimeError("Git data read failed; no retry or fetch authorized")
    return r.stdout


added = {x["path"]: x for x in M["added_paths"]}
registry_path = "proofs/Agent51OverflowSaturation.registry.json"
registry_bytes = read_git(registry_path)
assert sha(registry_bytes) == added[registry_path]["sha256"]
registry = json.loads(registry_bytes)
modules = registry["projects"]["agent51-overflow-saturation"]["modules"]
selected = {x["path"] for x in modules.values()}
assert len(selected) == 5
assert not any("/evidence/" in p for p in selected)
for module in modules.values():
    check = next(x for x in M["frozen_input_checks"] if x["path"] == module["path"])
    assert module["sha256"] == check["sha256"]
    assert module["git_blob"] == check["git_entry"]["oid"]

classification = []
for path, entry in added.items():
    rel = path.removeprefix(PREFIX)
    if path == registry_path:
        group = "current_registry"
    elif path in selected:
        group = "current_registered_source"
    elif rel.startswith("evidence/attempts/"):
        group = "historical_author_attempt"
    elif rel.startswith("evidence/drafts/"):
        group = "historical_draft_not_registered"
    elif rel == "README.md":
        group = "scope_attribution_and_historical_checkpoint_document"
    elif rel.startswith(("review/", "reviews/")):
        group = "attributed_historical_semantic_review"
    else:
        group = "historical_provenance_record"
    classification.append({"path": path, "classification": group,
                           "registered_as_module": path in selected,
                           "git_entry": entry["after"], "bytes": entry["bytes"],
                           "sha256": entry["sha256"]})

attempts = []
for attempt in ["LychrelDigitSums-001", "OverflowDigits-001", "OverflowWitness-001", "OverflowWitness-002", "OverflowWitness-003"]:
    path = PREFIX + "evidence/attempts/" + attempt + "/result.json"
    data = read_git(path)
    assert sha(data) == added[path]["sha256"]
    attempts.append({"attempt": attempt, "source_path": path,
                     "attribution": "Preserved original author record; not executed by this reviewer",
                     "record": json.loads(data)})

claim = registry["claims"][0]
source_path = claim["source_path"]
source_bytes = read_git(source_path)
assert sha(source_bytes) == "d39212c9ab98f4c5b0fccb733d3b662e41a09804878178c82b8762684e97fb09"
source_entries = {}
for reference in M["input_map_references"]:
    raw = Path(reference["path"]).read_bytes()
    assert sha(raw) == reference["sha256"]
    matches = [x for x in raw.split(b"\0") if x.endswith(b"\t" + source_path.encode())]
    assert len(matches) == 1
    mode, kind, oid = matches[0].split(b"\t", 1)[0].decode().split()
    source_entries[reference["role"]] = {"mode": mode, "type": kind, "oid": oid}
assert source_entries["M"] == source_entries["H148"]
assert source_entries["M"]["oid"] == claim["source_blob"]
save("ORIGINAL_SOURCE.json", {"path": source_path, "bytes": len(source_bytes),
                             "sha256": sha(source_bytes), "input_entries": source_entries,
                             "combined_tree_entry": source_entries["M"],
                             "preserved_in_combined_tree": True,
                             "basis": "Exact combined-map union plus direct Git blob byte hash"})
save("CONTENT_CLASSIFICATION.json", {
    "status": "STRUCTURAL_CLASSIFICATION_ONLY",
    "added_file_count": len(classification), "added_file_bytes": sum(x["bytes"] for x in classification),
    "files": classification, "registry_module_count": len(selected),
    "registered_module_paths": sorted(selected), "historical_paths_registered_as_modules": [],
    "preserved_author_attempt_records": attempts,
    "historical_failure_handling": "OverflowWitness-001 and OverflowWitness-002 retain FAIL records, error logs and source bytes, outside the registered import closure. Their sorryAx output is failed-development evidence, not accepted proof evidence.",
    "historical_draft_handling": "The separate OverflowWitness-001 draft remains preserved outside the registry and is not represented as an executed attempt.",
    "review_limit": "Historical semantic PASS language is attributed to the existing reviewers. No mathematical review or Lean execution was performed in this structural inspection.",
    "unrecovered_history_limit": "FINAL_REVIEW.md cites ResidueSums-005 and Saturation-001 author records; those records are not included in the 25 additions. This inspection does not recover or certify that absent corpus."})
save("classification-commands.json", COMMANDS)
print(json.dumps({"classified_paths": len(classification), "added_payload_bytes": sum(x["bytes"] for x in classification),
                  "original_source_sha256": sha(source_bytes), "historical_paths_registered": 0}))
