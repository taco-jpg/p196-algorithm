from pathlib import Path
import collections
import hashlib
import json
import os
import re
import subprocess

R = Path(__file__).resolve().parent
REPO = R / 'repo'
PKG = 'proofs/contributions/agent-105/numeric-decoder-9df76b-20261016'
P = REPO / PKG
A = R / 'evidence-recovered'
F = R / 'fresh-trust0-ec7aa17a-01'
H = 'ec7aa17a36548cc629d2a4a309e802406fc862e7'
S = '64bb07e9f8d3ffcfd141d58e01ec7e27964c5e5d'
I = '4514f5ef7e5155c7ec5b01882a93e1a2dda06193'
COMMON = '5923015f86eb1ef898becd77ce2ee328ff338b69'
BASE113 = 'cd11afd68833051c81051df22573e8827ab6b671'
PROJECT = 'agent105-numeric-decoder-9df76b'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def j(path):
    return json.loads(path.read_text())

def git(*args):
    return subprocess.check_output(['git', '-C', str(REPO), *args], env={**os.environ, 'GIT_NO_LAZY_FETCH': '1'})

def blob(commit, path):
    return git('show', commit + ':' + path)

def check(path, pin):
    data = path.read_bytes()
    assert sha(data) == pin['sha256'] and len(data) == pin['bytes'], str(path)

def parents(commit):
    header = git('cat-file', '-p', commit).decode().split('\n\n', 1)[0]
    return re.findall(r'^parent (\w+)$', header, re.M)

assert git('rev-parse', 'HEAD').decode().strip() == H
assert git('status', '--porcelain').strip() == b''
assert parents(H) == [S] and parents(S) == [I] and parents(I) == [COMMON]
assert parents(BASE113) == [COMMON]
reg = j(R / 'published-registry.json')
project = reg['projects'][PROJECT]
converted = j(R / 'strict-source-registry.json')
assert converted['roots'] == project['roots']
assert converted['modules'] == {name: {'base': 'repository', **pin} for name, pin in project['modules'].items()}
assert converted['endpoints'] == reg['claims'][0]['endpoints']
assert len(project['modules']) == 12 and len(converted['new_modules']) == 5

oldnormal = A / 'verification/fresh-scope105-001'
oldproject = oldnormal / PROJECT
oldstrict = A / 'verification/strict-scope105-001'
sources = []
for name, pin in project['modules'].items():
    data = blob(H, pin['path'])
    assert sha(data) == pin['sha256']
    assert git('rev-parse', H + ':' + pin['path']).decode().strip() == pin['git_blob']
    assert blob(S, pin['path']) == data
    for folder in [F, oldproject, oldstrict]:
        assert (folder / 'source' / (name + '.lean')).read_bytes() == data
    if name not in converted['new_modules']:
        assert blob(BASE113, pin['path']) == data
        assert data == (R.parent / 'reviews113/repo' / pin['path']).read_bytes()
    if name.startswith('Agent101'):
        assert blob('326645944168ad2b035a1e653b61527d79684156', pin['path']) == data
    if name in ['Agent105DecoderLocal9df76b', 'Agent105DecoderTarget9df76b']:
        assert blob(I, pin['path']) == data
    sources.append({'module': name, **pin, 'frozen_current_and_all_build_snapshots_identical': True})

registry_path = 'proofs/Agent105NumericDecoder9df76b.registry.json'
verifier_path = 'proofs/verify_project__214bf7673efe116b.py'
assert blob(H, registry_path) == blob(S, registry_path) == (R / 'published-registry.json').read_bytes()
assert blob(H, verifier_path) == blob(S, verifier_path) == blob(BASE113, verifier_path)
assert sha(blob(H, verifier_path)) == 'c047ff1ff1fe12b2c2094ca5f36af871b1c6faf89db593a102f9c2f7d48cc98a'

changes = []
for line in git('diff', '--no-renames', '--name-status', COMMON, H).decode().splitlines():
    status, path = line.split('\t')
    assert status == 'A'
    assert path.startswith(PKG + '/') or path in [registry_path] + [project['modules'][m]['path'] for m in converted['new_modules']]
    data = blob(H, path)
    assert (REPO / path).read_bytes() == data
    changes.append({'status': status, 'path': path, 'bytes': len(data), 'sha256': sha(data), 'git_blob': git('rev-parse', H + ':' + path).decode().strip()})
assert len(changes) == 83

written_blob = 'ecd101823b261fdac15d185fea963d9c9f16c601'
written = git('cat-file', 'blob', written_blob)
historical = '2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5'
assert blob(historical, 'proofs/research/persist_inverse_notes.txt') == written
assert blob(historical, 'proofs/research/Lychrel196Research.lean') == blob(H, project['modules']['Lychrel196Research']['path'])

archive = j(P / 'VERIFICATION_ARCHIVE.json')
assert archive['source_checkpoint'] == S
check(P / archive['archive']['path'], archive['archive'])
assert len(archive['members']) == 71
for pin in archive['members']:
    assert pin['archive_member'] == pin['contribution_relative_path']
    assert pin['original_path'] == PKG + '/' + pin['archive_member']
    check(A / pin['archive_member'], pin)
assert sum(p['bytes'] for p in archive['members']) == 929758
for pin in archive['direct_review_copies']:
    assert pin['published_path'] == PKG + '/' + pin['contribution_relative_path']
    check(P / pin['contribution_relative_path'], pin)
    assert (P / pin['contribution_relative_path']).read_bytes() == (A / pin['archive_member']).read_bytes()
scope_manifest = j(A / 'verification/scope105-evidence-manifest.json')
assert scope_manifest['source_commit'] == S and len(scope_manifest['files']) == 70
for name, pin in scope_manifest['files'].items():
    check(A / 'verification' / name, pin)
archived_manifests = []
for manifest in sorted(A.rglob('FILES.json')):
    records = j(manifest)
    for name, pin in records.items():
        check(manifest.parent / name, pin)
    archived_manifests.append({'path': str(manifest.relative_to(A)), 'entries': len(records), 'all_paths_present_exact': True})
direct = j(P / 'FILES.json')
assert len(direct) == 76
assert set(direct) == {str(p.relative_to(P)) for p in P.rglob('*') if p.is_file()} - {'FILES.json'}
for name, pin in direct.items():
    check(P / name, pin)
exclusions = j(P / 'INFRASTRUCTURE_EXCLUSIONS.json')
for name, pin in exclusions.items():
    if 'archive_member' in pin:
        assert pin['archive_member'] == name
        check(A / name, pin)
    elif name.endswith('.lean'):
        assert name == 'local/build/Agent105DecoderLocal9df76b.lean'
        check(REPO / 'proofs/Agent105DecoderLocal9df76b.lean', pin)
    else:
        assert name.endswith('.olean')

normal = j(P / 'canonical-verification.json')
strict = j(P / 'strict-verification.json')
fresh = j(F / 'verification.json')
assert normal['status'] == 'PASS' and normal['source_commit'] == S and normal['source_tree_clean']
assert strict['status'] == 'PASS_EXPLICIT_TRUST_ZERO' and strict['source_commit'] == S
assert strict['original_verification_sha256'] == sha((P / 'canonical-verification.json').read_bytes())
assert (oldproject / 'source/ProjectAudit.lean').read_bytes() == (oldstrict / 'source/ProjectAudit.lean').read_bytes()
command_checks = []
for label, folder, commands in [('retained canonical default trust', oldnormal, normal['projects'][PROJECT]['commands']), ('retained explicit trust zero', oldstrict, strict['commands']), ('fresh explicit trust zero', F, fresh['commands'])]:
    for c in commands:
        assert c['exit_code'] == 0
        assert sha((folder / c['log']).read_bytes()) == c['log_sha256']
        if c['label'] in [*converted['modules'], 'ProjectAudit', 'IntervalClosureAudit']:
            assert ('--trust=0' in c['argv']) == (label != 'retained canonical default trust')
    command_checks.append({'run': label, 'commands': len(commands), 'all_exit_zero_and_log_hashes_exact': True})
assert fresh['status'] == 'PASS_SELECTED_SOURCE_CLOSURE'
assert fresh['lean_trust_level'] == 0 and fresh['precompile_object_count'] == 0
assert fresh['all_selected_sources_unchanged'] and fresh['compiler_snapshot_unchanged']
assert fresh['repository_head_before'] == fresh['repository_head_after'] == H
for name, pin in j(F / 'FILES.json').items():
    check(F / name, pin)

def origin(data, kind):
    result = {}
    for module, name, axioms in re.findall(r'^AUDIT_' + kind + r' (\S+) (.+?) : \[([^\]]*)\]', data, re.M | re.S):
        key = module + ' ' + name
        assert key not in result
        result[key] = sorted(x.strip() for x in axioms.split(',') if x.strip())
    return result

flog = (F / 'logs/IntervalClosureAudit.log').read_text()
theorems = origin(flog, 'THEOREM')
definitions = origin(flog, 'DEFINITION')
assert len(theorems) == 1096 and len(definitions) == 206
assert fresh['new_module_theorem_count'] == 112 and fresh['new_module_safe_definition_count'] == 42
for original in [oldproject / 'logs/ProjectAudit.log', oldstrict / 'logs/ProjectAudit.log']:
    assert origin(original.read_text(), 'THEOREM') == theorems
allowed = {'propext', 'Classical.choice', 'Quot.sound'}
assert all(set(a) <= allowed for a in [*theorems.values(), *definitions.values()])
named = j(R / 'named-exports-ec7aa17a-01/verification.json')
assert named['status'] == 'PASS' and named['literal_count'] == 42
decls = j(R / 'new-declarations.json')
assert len(decls) == 38
assert {d['name'] for d in decls if d['kind'] == 'theorem'} == set(converted['endpoints'])
for decl in decls:
    found = theorems if decl['kind'] == 'theorem' else definitions
    assert found[decl['module'] + ' ' + decl['name']] == named['printed_axioms'][decl['name']]
for name in ['instDecidableValidEdge', 'instDecidableValidCenter']:
    full = 'Agent105DecoderLocal9df76b.' + name
    assert definitions['Agent105DecoderLocal9df76b ' + full] == named['printed_axioms'][full]
for name in ['Edge', 'Edge.mk']:
    assert named['printed_axioms']['Agent105DecoderLocal9df76b.' + name] == []

def statements(path):
    text = re.sub(r'/\-[\s\S]*?\-/|--[^\n]*', '', path.read_text())
    result = {}
    for m in re.finditer(r'^(?:private )?theorem (\S+)', text, re.M):
        end = text.index(':=', m.end())
        result[m[1]] = ' '.join(text[m.start():end].split())
    return result

attempts = []
for family, source, statuses, active in [('local', 'Agent105DecoderLocal9df76b.lean', [1, 0], 'Agent105DecoderLocal9df76b.lean'), ('target', 'source.lean', [1, 0], 'Agent105DecoderTarget9df76b.lean'), ('numeric', 'source.lean', [0], 'Agent105NumericDecoder9df76b.lean')]:
    prior = {}
    for i, status in enumerate(statuses, 1):
        directory = P / family / (('attempt-' if family == 'local' else 'attempt') + '%03d' % i)
        record = j(directory / 'result.json')
        assert record['exit_code'] == status and sha((directory / source).read_bytes()) == record['source_sha256']
        now = statements(directory / source)
        assert all(now[n] == s for n, s in prior.items())
        attempts.append({'family': family, 'attempt': i, 'exit_code': status, 'source_sha256': record['source_sha256'], 'all_prior_theorem_statements_preserved': True})
        prior = now
    assert (directory / source).read_bytes() == (REPO / 'proofs' / active).read_bytes()
previous = {}
for i, status in enumerate([1, 0, 1, 1, 0, 1, 0, 0], 1):
    source = P / 'scan' / ('attempt%03d.lean' % i)
    record = j(source.with_suffix('.json'))
    assert record['exit_code'] == status and sha(source.read_bytes()) == record['source_sha256']
    now = statements(source)
    assert all(now[n] == s for n, s in previous.items())
    attempts.append({'family': 'scan', 'attempt': i, 'exit_code': status, 'source_sha256': record['source_sha256'], 'all_prior_theorem_statements_preserved': True, 'new_theorems': sorted(set(now) - set(previous))})
    previous = now
assert source.read_bytes() == (REPO / 'proofs/Agent105DecoderScan9df76b.lean').read_bytes()
assert sum(a['exit_code'] != 0 for a in attempts) == 6
controls_dir = P / 'controls/kernel-attempt-001'
control = j(controls_dir / 'receipt.json')
for name, pin in control['modules'].items():
    data = (controls_dir / 'source' / (name + '.lean')).read_bytes()
    assert sha(data) == pin['source_sha256'] and data == (REPO / 'proofs' / (name + '.lean')).read_bytes()
for c in control['commands']:
    assert c['exit_code'] == 0 and '--trust=0' in c['argv']
    assert sha((controls_dir / c['log']).read_bytes()) == c['log_sha256']
for module in ['Target', 'Scan']:
    name = 'Agent105Decoder' + module + '9df76b.lean'
    assert (P / 'local' / (module.lower() + '-semantic-reviewed-source') / name).read_bytes() == (REPO / 'proofs' / name).read_bytes()

record = {
    'status': 'PASS', 'head': H, 'head_tree': git('rev-parse', H + '^{tree}').decode().strip(),
    'frozen_source_commit': S, 'incremental_source_commit': I, 'common_source_ancestor': COMMON,
    'stacked_publication_base': BASE113,
    'integration_caveat': 'PR134 and PR113 publication are sibling descendants of the frozen PR113 source. The actual PR134 contribution is 83 additions from their common ancestor. Preserve the later PR113 publication by normal three-way merge; never substitute the entire PR134 tree for main.',
    'actual_new_files': changes, 'actual_new_file_count': len(changes), 'actual_new_bytes': sum(x['bytes'] for x in changes),
    'sources': sources, 'seven_dependencies_identical_to_previously_reviewed_pr113': True,
    'written_source': {'blob': written_blob, 'sha256': sha(written), 'historical_commit': historical, 'path': 'proofs/research/persist_inverse_notes.txt', 'read_scope': 'Original section 6, with fixed-width numeric versus nextColumns and integer-enumeration scope boundaries retained.'},
    'archive_checks': 'archive-checks.json', 'direct_FILES_entries': len(direct), 'original_manifest_entries': len(scope_manifest['files']), 'archived_manifests': archived_manifests,
    'all_infrastructure_exclusions_either_exact_archived_bytes_or_reproducible_objects_or_exact_duplicate_source': True,
    'command_checks': command_checks,
    'origin_audit': {'theorems': 1096, 'safe_definitions': 206, 'new_module_theorems': 112, 'new_module_safe_definitions': 42, 'full_theorem_origin_name_axiom_map_matches_both_retained_runs': True, 'all_38_named_theorem_definition_and_two_instance_axiom_maps_match_literal_audit': True, 'edge_type_and_constructor_axiom_free': True, 'unsafe_implementation_axiom_count': len(fresh['unsafe_implementation_constants']), 'unsafe_implementation_definition_count': len(fresh['unsafe_implementation_definitions']), 'none_enter_mathematical_axiom_sets': True},
    'development_attempts': attempts, 'retained_failed_attempt_count': 6,
    'all_failed_to_successful_tactic_repairs_preserve_original_theorem_statements_and_hypotheses': True,
    'no_source_changes_by_reviewer': True, 'source_or_provenance_blockers': [],
    'repository_status_after': git('status', '--porcelain').decode()
}
(R / 'evidence-validation.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'status': record['status'], 'new_files': len(changes), 'new_bytes': record['actual_new_bytes'], 'archived_manifests': archived_manifests, 'command_checks': command_checks, 'origin_audit': record['origin_audit'], 'sha256': sha((R / 'evidence-validation.json').read_bytes())}, indent=2))
