#!/usr/bin/env python3
"""Bind PR123's preserved runtime registry aliases to exact published source bytes."""
import argparse, hashlib, json, subprocess
from pathlib import Path
p=argparse.ArgumentParser()
for n in ("repo","head","tree","review","output"): p.add_argument("--"+n,required=True)
a=p.parse_args()
review=Path(a.review)
package="proofs/contributions/agent-9/finite-ensemble-marker-count-20261016"
def data(ref,path):
    r=subprocess.run(["git","-C",a.repo,"show",ref+":"+path],capture_output=True,check=True)
    return r.stdout
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b"blob "+str(len(b)).encode()+b"\0"+b).hexdigest()
post_bytes=(review/"POSTCHECK.json").read_bytes()
post=json.loads(post_bytes)
assert post["status"]=="PASS" and post["exact_head"]==a.head
registry_path=package+"/review/horizon-safety/verification/source-registry.json"
driver_path=package+"/review/horizon-safety/verify.py"
registry_bytes=data(a.head,registry_path); driver_bytes=data(a.head,driver_path)
reg=json.loads(registry_bytes)
assert sha(registry_bytes)==post["registry_sha256"]
assert sha(driver_bytes)==post["driver_sha256"]
assert set(reg["modules"])==set(post["source_closure"])
rows=[]
for name,record in reg["modules"].items():
    mapping=post["source_closure"][name]
    path=mapping["exact_head_path"]
    head=data(a.head,path); target=data(a.tree,path)
    fresh=(review/mapping["fresh_snapshot"]).read_bytes()
    checks={
      "head_equals_combination":head==target,
      "equals_fresh_compiled_source":target==fresh,
      "matches_registry_sha256":sha(target)==record["sha256"],
      "matches_registry_git_blob":not record.get("git_blob") or blob(target)==record["git_blob"],
      "matches_review_sha256":sha(target)==mapping["sha256"],
      "matches_review_git_blob":blob(target)==mapping["git_blob"],
      "matches_review_size":len(target)==mapping["bytes"]}
    rows.append({"module":name,"registry_base":record["base"],"registry_runtime_path":record["path"],
      "exact_head_path":path,"fresh_snapshot":mapping["fresh_snapshot"],"bytes":len(target),
      "sha256":sha(target),"git_blob":blob(target),**checks})
out={"schema_version":1,"auditor":"Agent #12 / root","head":a.head,"combined_tree":a.tree,
 "registry_path":registry_path,"registry_sha256":sha(registry_bytes),
 "driver_path":driver_path,"driver_sha256":sha(driver_bytes),
 "registry_identical_in_combination":registry_bytes==data(a.tree,registry_path),
 "driver_identical_in_combination":driver_bytes==data(a.tree,driver_path),
 "review_source_map_sha256":sha(post_bytes),"source_module_count":len(rows),"source_bindings":rows,
 "resolution":"The preserved runtime registry names five author-frozen snapshots under frozen-source/. These aliases are resolved through the independent POSTCHECK source map and verified against every exact head, combined-tree, fresh-compiled snapshot, registry SHA256 and recorded Git blob. Neither registry nor mathematical source is edited.",
 "fresh_lean_execution":False,
 "interpretation":"Exact source binding of the earlier fresh passing16-module audit to the current combination; this check is not a new Lean execution."}
check_names=["head_equals_combination","equals_fresh_compiled_source","matches_registry_sha256","matches_registry_git_blob","matches_review_sha256","matches_review_git_blob","matches_review_size"]
out["status"]="PASS" if out["registry_identical_in_combination"] and out["driver_identical_in_combination"] and all(all(r[k] for k in check_names) for r in rows) else "FAIL"
dest=Path(a.output)
assert not dest.exists()
dest.write_text(json.dumps(out,indent=2)+"\n")
print(json.dumps({k:v for k,v in out.items() if k!="source_bindings"},indent=2))
if out["status"]!="PASS": raise SystemExit(1)
