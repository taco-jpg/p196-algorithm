#!/usr/bin/env python3
"""Validate retained subordinate manifests and original attempt identities."""
import hashlib,json,pathlib
root=pathlib.Path(__file__).resolve().parent
pkg=root/'recovered-evidence'
digest=lambda b:hashlib.sha256(b).hexdigest()
records=[]
def check(label, base, entries, omit_objects=False):
    result={'manifest':label,'checked':0,'explicitly_omitted_compiled_objects':[],'validated_source_aliases':[]}
    retention=json.loads((base/'RETENTION.json').read_text()) if omit_objects else {}
    for p,row in entries.items():
        path=base/p
        assert not pathlib.PurePosixPath(p).is_absolute() and '..' not in pathlib.PurePosixPath(p).parts
        if not path.is_file() and omit_objects and p.startswith('build/') and p.endswith('.olean'):
            record=retention['omitted'][p]
            assert record['sha256']==row['sha256'] and record['bytes']==row['bytes'] and record['retained_as'] is None
            result['explicitly_omitted_compiled_objects'].append({'path':p,**row}); continue
        if not path.is_file() and omit_objects and p.startswith('source/'):
            record=retention['omitted'][p]
            assert record['sha256']==row['sha256'] and record['bytes']==row['bytes']
            alias=record['retained_as']
            path=(pathlib.Path('/workspace/scratch/aa9210d02a75/agent12-pr123')/alias if alias.startswith('proofs/') else pkg/'review/horizon-safety'/alias)
            result['validated_source_aliases'].append({'path':p,'retained_as':alias})
        data=path.read_bytes()
        assert digest(data)==row['sha256'],(label,p)
        assert len(data)==row['bytes'],(label,p)
        result['checked']+=1
    records.append(result)
d=json.loads((pkg/'MANIFEST.json').read_text())
check('MANIFEST.json',pkg,{r['path']:r for r in d['entries']})
assert d['files']==len(d['entries']) and d['bytes']==sum(r['bytes'] for r in d['entries'])
d=json.loads((pkg/'checkpoint-001/MANIFEST.json').read_text())
check('checkpoint-001/MANIFEST.json',pkg,{r['path']:r for r in d['files']})
d=json.loads((pkg/'review/horizon-safety/REVIEW_FILES.json').read_text())
check('review/horizon-safety/REVIEW_FILES.json',pkg/'review/horizon-safety',d['files'])
for p in sorted(pkg.rglob('FILES.json')):
    check(str(p.relative_to(pkg)),p.parent,json.loads(p.read_text()),'runs/full-001' in str(p))
for path in [pkg/'MANIFEST.sha256',pkg/'review/horizon-safety/SHA256SUMS']:
    count=0
    for line in path.read_text().splitlines():
        sha,name=line.split(maxsplit=1); name=name.lstrip('*')
        target=path.parent/name
        assert digest(target.read_bytes())==sha,(path,name)
        count+=1
    records.append({'manifest':str(path.relative_to(pkg)),'checked':count})
attempts=[]
for p in sorted((pkg/'development').glob('*/*/status.json')):
    d=json.loads(p.read_text())
    source=p.parent/(d['module']+'.lean')
    assert digest(source.read_bytes())==d['source_sha256']
    assert (p.parent/'stdout.log').is_file() and (p.parent/'stderr.log').is_file()
    attempts.append({'path':str(p.parent.relative_to(pkg)),'exit_code':d['exit_code'],
                     'source_sha256':d['source_sha256']})
assert len(attempts)==23 and sum(r['exit_code']!=0 for r in attempts)==6
result={'status':'PASS','manifests':records,'development_attempts':attempts,
        'development_attempt_count':len(attempts),'development_failure_count':6,
        'omitted_objects_policy':'Original reviewer run explicitly omits reproducible build/*.olean; original hashes remain in its unchanged FILES.json and retention inventory.'}
(root/'subordinate-manifest-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'status':'PASS','manifests':len(records),'manifest_entry_checks':sum(r['checked'] for r in records),'attempts':23,'failures':6}))
