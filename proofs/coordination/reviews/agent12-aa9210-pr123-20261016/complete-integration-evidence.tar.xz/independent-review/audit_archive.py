#!/usr/bin/env python3
"""Read-only validation and safe extraction of PR123's lossless evidence."""
import hashlib, json, lzma, pathlib, tarfile, io

root = pathlib.Path('/workspace/scratch/aa9210d02a75/agent12-pr123/proofs/contributions/agent-9/finite-ensemble-marker-count-20261016')
out = pathlib.Path('/workspace/scratch/aa9210d02a75/agent12-review123')
dest = out / 'recovered-evidence'
dest.mkdir(exist_ok=False)
manifest = json.loads((root/'evidence/MANIFEST.json').read_text())
digest = lambda b: hashlib.sha256(b).hexdigest()
compressed = (root/manifest['stored_path']).read_bytes()
assert len(compressed) == manifest['stored_bytes']
assert digest(compressed) == manifest['stored_sha256']
raw = lzma.decompress(compressed)
assert len(raw) == manifest['uncompressed_tar_bytes']
assert digest(raw) == manifest['uncompressed_tar_sha256']
expected = {r['original_path']:r for r in manifest['files']}
assert len(expected) == len(manifest['files']) == manifest['original_files']
seen = set(); identical = []; changed = []
with tarfile.open(fileobj=io.BytesIO(raw), mode='r:') as archive:
    for member in archive.getmembers():
        path = pathlib.PurePosixPath(member.name)
        assert not path.is_absolute() and '..' not in path.parts
        assert member.isfile() and member.name not in seen
        assert member.name in expected
        row = expected[member.name]
        data = archive.extractfile(member).read()
        assert len(data) == member.size == row['bytes']
        assert digest(data) == row['sha256']
        target = dest/member.name
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_bytes(data)
        seen.add(member.name)
        direct = root/member.name
        if direct.is_file():
            (identical if direct.read_bytes() == data else changed).append(member.name)
assert seen == set(expected)
assert sum(r['bytes'] for r in expected.values()) == manifest['original_payload_bytes']
result = {'status':'PASS','archive':manifest['stored_path'],'archive_sha256':digest(compressed),
          'uncompressed_tar_sha256':digest(raw),'files':len(seen),
          'payload_bytes':manifest['original_payload_bytes'],
          'direct_duplicate_identical':identical,'direct_files_different_from_archived':changed,
          'safe_extraction':'Only unique regular relative file paths; no traversal, links, devices, or overwrite'}
(out/'archive-audit.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
