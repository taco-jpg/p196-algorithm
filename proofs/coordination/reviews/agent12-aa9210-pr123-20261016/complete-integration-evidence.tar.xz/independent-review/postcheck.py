#!/usr/bin/env python3
"""Independent log, export, provenance, and exact-head source postcheck."""
import hashlib,json,pathlib,re,subprocess
from collections import Counter
root=pathlib.Path(__file__).resolve().parent
repo=root.parent/'agent12-pr123'
relative='proofs/contributions/agent-9/finite-ensemble-marker-count-20261016'
pkg=repo/relative
fresh=root/'fresh-full-001'
digest=lambda b:hashlib.sha256(b).hexdigest()
verification=json.loads((fresh/'verification.json').read_text())
registry=json.loads((fresh/'source-manifest.json').read_text())
assert verification['status']=='PASS_SELECTED_SOURCE_CLOSURE'
assert verification['repository_head_before']==verification['repository_head_after']=='0d1eea6c69078111366d9d7235bd47c3e16aadf8'
assert verification['precompile_object_count']==0
assert verification['all_selected_sources_unchanged'] and verification['compiler_snapshot_unchanged']
assert not verification['repository_status_before'] and not verification['repository_status_after']
assert all(r['exit_code']==0 for r in verification['commands'])
log=(fresh/'logs/EnsembleAudit.log').read_text()
allowed={'propext','Classical.choice','Quot.sound'}
endpoints=json.loads((pkg/'exports.json').read_text())
assert len(endpoints)==len(set(endpoints))==100 and endpoints==registry['endpoints']
printed={n:{a.strip() for a in s.split(',') if a.strip()} for n,s in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]",log)}
printed.update({n:set() for n in re.findall(r"'([^']+)' does not depend on any axioms",log)})
types=re.findall(r'^(P196\.Agent9\.Ensemble\.\S+)(?=\s|\{)',log,re.M)
assert set(types)==set(endpoints) and len(types)==100
for n in endpoints: assert n in printed and printed[n]<=allowed
rows=re.findall(r'^AUDIT_(THEOREM|DEFINITION) (\S+) (\S+) : \[([^\]]*)\]',log,re.M)
assert len(rows)==1744 and len({r[2] for r in rows})==1744
counts=Counter(); origins=set(); union=set()
for kind,origin,name,ax in rows:
    axioms={a.strip() for a in ax.split(',') if a.strip()}
    assert axioms<=allowed,(name,axioms)
    counts[kind]+=1;origins.add(origin);union|=axioms
assert counts=={'THEOREM':1505,'DEFINITION':239} and union==allowed
assert origins==set(registry['modules'])-{'Lychrel196Research'}
assert (fresh/'source/Lychrel196Research.lean').read_text().strip().endswith('import LychrelDigitSums')
assert not re.search(r'^\s*(def|theorem|axiom|opaque|instance|inductive|structure)\b',(fresh/'source/Lychrel196Research.lean').read_text(),re.M)
literal=[]; source_rows={}
freeze=json.loads((pkg/'AUTHOR_FREEZE.json').read_text())
assert digest((pkg/'AUTHOR_FREEZE.json').read_bytes())==registry['author_freeze_sha256']
for row in freeze['mathematical_modules']:
    assert row['sha256']==registry['modules'][row['module']]['sha256']
assert digest((pkg/'Agent9EnsembleAudit.lean').read_bytes())==freeze['audit_sha256']
for module,record in registry['modules'].items():
    data=(fresh/'source'/(module+'.lean')).read_bytes()
    assert digest(data)==record['sha256']
    actual=(pkg/(module+'.lean') if module in registry['new_modules'] else repo/record['path'])
    assert actual.read_bytes()==data
    source_rows[module]={'exact_head_path':str(actual.relative_to(repo)),'bytes':len(data),'sha256':digest(data),'git_blob':record['git_blob'],'fresh_snapshot':'fresh-full-001/source/'+module+'.lean'}
    if module in registry['new_modules']:
        for kind,name in re.findall(r'^(def|theorem)\s+(\w+)',data.decode(),re.M): literal.append((kind,'P196.Agent9.Ensemble.'+name))
assert {n for k,n in literal}==set(endpoints)
assert Counter(k for k,n in literal)=={'def':22,'theorem':78}
origin='2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5:proofs/contributions/2026-10-14-finite-horizon-density/README.md'
blob=subprocess.check_output(['git','rev-parse',origin],cwd=repo,text=True).strip()
assert blob=='6d6d188df78e26eb6ffdde6ebc3bdb6fc749eb9c'
original=subprocess.check_output(['git','cat-file','blob',blob],cwd=repo)
assert original==(root/'recovered-evidence/source/README.original.md').read_bytes()
checkpoint='cf7935d24ce8180d6181de01d1050fc02b66802c'
tree=subprocess.check_output(['git','ls-tree','-r',checkpoint,relative],cwd=repo,text=True)
checkpoint_rows=[]
for line in tree.splitlines():
    mode,typ,oid,path=line.split(maxsplit=3)
    data=(root/'recovered-evidence'/path.removeprefix(relative+'/')).read_bytes()
    actual=hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()
    assert actual==oid
    checkpoint_rows.append({'path':path,'git_blob':oid,'sha256':digest(data)})
assert len(checkpoint_rows)==24
result={'status':'PASS','exact_head':verification['repository_head_before'],'fresh_driver_exit_code':0,
    'literal_exports':100,'literal_theorems':78,'literal_definitions':22,'types_checked':100,
    'theorem_constants':1505,'safe_definitions':239,'module_origins':sorted(origins),
    'import_only_adapter':'Lychrel196Research','allowed_axiom_union':sorted(union),
    'source_closure':source_rows,'all_export_axioms':{n:sorted(printed[n]) for n in endpoints},
    'original_manuscript':{'historical_path':origin,'git_blob':blob,'sha256':digest(original)},
    'original_checkpoint_files':checkpoint_rows,
    'fresh_audit_sha256':digest((fresh/'logs/EnsembleAudit.log').read_bytes()),
    'fresh_verification_sha256':digest((fresh/'verification.json').read_bytes()),
    'registry_sha256':digest((fresh/'source-manifest.json').read_bytes()),
    'driver_sha256':verification['workflow_sha256'],
    'unsafe_implementation_axioms':len(verification['unsafe_implementation_constants']),
    'unsafe_implementation_definitions':len(verification['unsafe_implementation_definitions'])}
(root/'POSTCHECK.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['source_closure','all_export_axioms','original_checkpoint_files']},indent=2))
