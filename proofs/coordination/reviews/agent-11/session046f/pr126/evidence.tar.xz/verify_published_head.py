from pathlib import Path
import json,hashlib,subprocess,os
O=Path('/workspace/scratch/046f9285a650/review126');r=json.loads((O/'remote-head-readback.json').read_text());c=r['compare'];f=r['file'];H='d24a13d87f6673dbd9b92f0086ef65ef8b733cfb';N='4fb13bd524092d19e4b3e1c5e06d66bd0b95307c';P='proofs/contributions/agent-7/odd-nooverflow-fibers-20261016/integration/Agent11PublicationManifestErratum.json'
assert c['base']==H and c['head']==N and c['status']=='ahead' and c['ahead_by']==1 and c['behind_by']==0 and c['total_commits']==1 and c['merge_base_commit']['sha']==H
assert len(c['files'])==1 and c['files'][0]['filename']==P and c['files'][0]['status']=='added' and c['files'][0]['deletions']==0
b=f['content'].encode();assert b==(O/'reviewed-erratum.json').read_bytes();assert len(b)==3677 and hashlib.sha256(b).hexdigest()=='ef418004bcc005ab43625decc5490719f9c7847be4e58eea9bfe793bf9c99689';assert f['sha']==hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()=='f0c6b073536380b640613d95d531f4fede2f72c7'
result={'verdict':'PASS','reviewed_exact_head':N,'reviewed_original_head':H,'repository':'taco-jpg/p196-algorithm','remote_comparison':'ahead by exactly one commit; complete diff contains exactly one added file and no deletion or modification','added_path':P,'added_bytes':len(b),'added_sha256':hashlib.sha256(b).hexdigest(),'added_git_blob':f['sha'],'all_original_paths_preserved':True,'review_scope':'Complete original 102-path evidence-only PR contribution plus the exact one-file additive repair; 103 changed paths total','blocking_findings_remaining':[],'original_head_finding_retained':'Original H has stale combined-stage-list metadata; it remains unedited and is corrected by the pinned additive erratum.','mathematical_source_or_accepted_build_change':False,'new_lean_execution':False,'review_affiliation':'Reviewer Agent11/review126 independent of Agent7 source; same Agent11 team as parent author of metadata erratum','api_evidence_file':'remote-head-readback.json'}
env={**os.environ,'GIT_NO_LAZY_FETCH':'1'};repo='/workspace/scratch/046f9285a650/repo';q=subprocess.run(['git','cat-file','-t',N],cwd=repo,env=env,capture_output=True,text=True)
if q.returncode==0:
 def g(*a):return subprocess.check_output(['git',*a],cwd=repo,env=env)
 assert g('show','-s','--format=%P',N).decode().strip()==H
 assert g('diff','--name-status','--no-renames',H,N).decode()==f'A\t{P}\n'
 assert g('rev-parse',N+':'+P).decode().strip()==f['sha']
 result['local_git_crosscheck']={'passed':True,'parent':H,'tree':g('rev-parse',N+'^{tree}').decode().strip(),'exact_one_path_delta':True}
else:result['local_git_crosscheck']={'performed':False,'reason':'New commit not yet hydrated in the shared read-only partial clone. Independent exact-head GitHub compare and file readback establish the one-file delta.'}
(O/'exact-head-review.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result,indent=2))
