from pathlib import Path
import json,hashlib
O=Path('/workspace/scratch/046f9285a650/review126');D=json.loads((O/'audit-results.json').read_text());C=json.loads((O/'changed-paths.json').read_text());E=json.loads((O/'erratum-review.json').read_text());P='proofs/contributions/agent-7/odd-nooverflow-fibers-20261016'
for r in C:
 b=(O/'head'/r['path']).read_bytes();r['head_git_blob']=hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
 if r['base_sha256']:
  b=(O/'base'/r['path']).read_bytes();r['base_git_blob']=hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
 else:r['base_git_blob']=None
(O/'changed-paths.json').write_text(json.dumps(C,indent=2)+'\n')
text='''# PR 126 independent preservation and evidence audit

Reviewer: Agent 11 `/root/review126`, session `046f9285a650`. This reviewer did not author the Agent 7 contribution and performed no source edits, remote writes, Lean executions, or nested delegation. Parent Agent 11 `/root` authored the proposed additive erratum; the reviewer and that repair author are in the same Agent 11 collaboration tree. This receipt is an independent inspection of retained evidence and a separate-agent review of the concrete repair, not an external peer review or a new proof execution.

## Exact subjects and verdict

- PR: https://github.com/taco-jpg/p196-algorithm/pull/126
- Reviewed original head H: `d24a13d87f6673dbd9b92f0086ef65ef8b733cfb`.
- Current-main baseline B supplied for this review: `5ff4f607535587d572fbc9e95ba9501d1fbe5fc5`.
- PR merge base M: `46364ddda5a9d8b4f86a7777eb6d566cb7761845`.
- Independently inspected prospective combined tree T: `f416eaad1f053e7b4f0000379a1a418612e644ad`.
- Original H verdict: **CHANGES REQUIRED**, solely for the stale combined-stage-list identity/count in the new final publication manifest.
- H plus only the exact reviewed additive erratum verdict: **PASS for the evidence-only scope**. The repair is 3,677 bytes, SHA-256 `ef418004bcc005ab43625decc5490719f9c7847be4e58eea9bfe793bf9c99689`, Git blob `f0c6b073536380b640613d95d531f4fede2f72c7`. This is a concrete local-patch verdict; it does not approve an unseen remote commit. A published new head must be checked to add only those bytes before exact-head approval.

The repository AGENTS.md and proofs/PUBLICATION_POLICY.md were read. Their preservation, actual-evidence labeling, immutable historical evidence, and single-writer rules governed this review. No main-writer role is claimed. An unrelated new Lean build would not establish the requested historical identities and was intentionally not performed.

## Complete change and preservation scope

The PR contribution is M..H, not the direct B..H tree difference. Main advanced after M with unrelated accepted work. Treating files present only in later B as deletions by this PR would be incorrect. M..H has exactly 102 changed paths: 99 additions, three modifications, zero deletions, all under the Agent 7 odd-nooverflow package. B..T has exactly the same 102 changed paths and exactly the H blobs at those paths. No current-main path disappears in T and no path outside this package changes. B has 15,643 tracked files, H has 14,066, and the combined tree has 15,742.

The three modified paths are README.md, actual-dev/PUBLICATION.json, and dependencies/SOURCE_PINS.json. README mathematics is unchanged: the substantive additions record completed historical execution and accurately disclose the same-team reviewer/author affiliation. The dependency pin changes only the erroneous historical source locator. The publication manifest keeps all 30 earlier retained-file records and all 51 earlier omitted-file byte identities; it expands explanatory metadata and adds the completed review evidence. Earlier versions of these three documents remain recoverable in M and the original PR history. Of the package's 256 preexisting files, 253 are completely unchanged; none is deleted.

All 15 registered Lean source modules, the frozen PROJECT_REGISTRY.json, retained verifier, and proofs/ACCEPTED_BUILD.json have identical blobs across M, H, B, and T. The accepted-build catalogue blob is `90221ac6053b5584602fed24eb93f7984359dff5`. No accepted source, claim endpoint, root, theorem implementation, verifier, or accepted-build entry changes. Added Lean files are historical reviewer fixtures or generated audit programs inside evidence directories; they are not new accepted project modules.

The complete changed-path byte/SHA-256/Git-blob inventory is in changed-paths.json and reproduced at the end of this receipt. Every changed file's complete H bytes are retained under head/, and all three modified predecessors under base/. diff.patch retains the entire PR delta, including substantive logs and checker sources. These files are not replaced by this narrative or by hash-only summaries.

## Source-tree equivalence and historical provenance

The original execution commit was independently inspected read-only in `/workspace/scratch/aaafdd394dd6/agent7-run-renewal`, rather than relying only on the new SOURCE_EQUIVALENCE.json assertion. Its raw Git commit object was saved as original-source-commit.txt and its object hash independently recomputed as `af9ddce989030508e9fc2895f2f44fbbfcf2aed9`. That commit's tree is `0a06724e30e971e00a260cee8ec0732b9c4fba2e`, exactly the published M commit's complete tree. Thus this is complete source-tree identity, not merely identity of selected Lean files. All 15 registered sources plus registry and verifier were also read directly from that original commit and matched to H byte-for-byte. The shared partial review clone does not contain the original local commit; this limitation was resolved by independently reading the actual original object database, not by assuming the new mapping.

Every one of the six dependency historical commit/path/blob/SHA-256 pairs was resolved and checked. Five Agent 9 sources resolve at commit `7be455c03d777e5e0ca1d44bea4d1330e3f764c7`; four are in the registered closure and the stored SharpMaximum is correctly outside it. The corrected Agent 8 path at commit `2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5` is `proofs/contributions/2026-10-15-agent8-complementary-bulk/PeriodObstructions.lean`. It actually resolves to blob `a89dda20e9a9b3452f7d0272b4fbd28f7d6ce119` and SHA-256 `83102a949036799a929ba72d74ce9d76bc2a11cb3adf61e0bc06b6013b22991a`. The earlier archive-prefixed locator was wrong for that historical commit. This change fixes metadata and does not change imported source bytes.

## Manifest and retention checks

Every retained-file record in both affected publication manifests matched actual stored length and SHA-256: 100 in actual-dev/PUBLICATION.json and 25 in verification/PUBLICATION.json. Their 167 omitted-file records comprise 82 byte-identical source snapshots and 85 reproducible compiler objects. All 82 source-snapshot identities match retained canonical sources; every compiler-object record points to a retained or reconstructible source with matching hash. Historical object-byte hashes are retained claims of original execution/cleanup, not hashes newly recomputed from deleted objects.

The canonical FILES.json has 33 entries: 18 retained originals and 15 byte-identical source snapshots accounted for by the omission manifest. All lengths and hashes match their retained bytes or exact canonical replacements. No generated audit source, compiler/audit log, or original verification report was substituted by an explanatory summary. The 256-entry cleanup receipt enumerates distinct .olean files only; its 15 canonical objects total 6,983,952 bytes and match the canonical omission records. Runtime installations and these reproducible objects fall within the publication policy's infrastructure exception. The receipt does not claim that a fresh build was performed after cleanup.

As an additional inherited-evidence check, all 177 retained-file records in the eleven other, unchanged package publication manifests were independently verified against their stored files. Every one matched. This distinguishes preexisting history from the new manifest defect: no missing older retained-file object, changed historical byte identity, or newly omitted substantive log was found. The old OddWords shell/log-reader caveat remains expressly documented; no failed or incomplete old execution was relabeled successful by this PR.

The failed canonical-review startup is retained as the exact earlier runner plus a narrative diagnostic explaining its wrong repository ancestor. The runner differs from the successful runner only at PACKAGE.parents[4] versus PACKAGE.parents[3]. The diagnostic is not presented as an original Python traceback or failed Lean log; the error happened before Lean started. The successful follow-up is separately identified as attempt-002.

## Actual retained executions, complete logs, and checker review

All new semantic reports, JSON reports, command manifests, runner sources, three reviewer fixture sources, four generated audit sources, 62 compiler/audit logs, publication helpers, and cleanup records were inspected. Repeated small compiler logs were compared by full-byte identity; each distinct log was read. The four large audit logs were parsed completely, including wrapped multi-line axiom lists. parsed-complete-audits.json retains every parsed theorem/axiom record and every explicit public audit result. The complete original raw logs remain under head/.

| Historical run | Successful recorded commands | Public checks/audits | Module-origin theorem constants |
|---|---:|---:|---:|
| canonical reviewer attempt-002 | 11 | 122 | 285 |
| sharp reviewer attempt-001 | 16 | 188 | 431 |
| final full reviewer final-001 | 19 | 214 | 468 |
| parent canonical verifier canonical-001 | 16 | 115 | 450 |

For all four runs, each recorded successful exit status, complete log hash, original source hash, generated audit endpoint list, uniqueness/count check, and allowed-axiom set agrees with the retained evidence. The final review's 468 theorem constants comprise the exact 450 project constants plus 18 finite reviewer fixtures; its 214 explicit audits comprise 196 public project declarations plus those fixtures. These are audit metadata, not claims of hundreds of independent major mathematical results.

The canonical original report hash is `73b2589136626623121f50bafff87986b89e6bbf2b08399503edcb1422d76e64`. The final separate review report hash is `2132ab2176dec34039ca22da1f461e5136d318a54e632154ac1458bd340b6d9d`. Both match the quoted reports. The scoped registry hash is `ca9d1fa657f6fc786fa14ed0df2456333280ee8a5eb1a58cadeebb902ff16926`; its 15 modules and 115 new-module public endpoints are unchanged. The final launcher pins the exact registry, builder, runner, and reports an exit code of zero with unchanged runner/registry.

The generated audit programs enumerate theorem constants by their imported module origin and call Lean.collectAxioms, rejecting nonapproved theorem axioms and safe custom axioms. All complete parsed theorem dependencies lie within propext, Classical.choice, and Quot.sound. The canonical audit separately records 13 compiler-generated unsafe implementation constants; they are not concealed or counted as theorem assumptions. The four-class finite certificate's retained audit reports no axioms. No successful audit contains sorryAx, Lean.ofReduceBool, a custom-axiom rejection, or a proof-error diagnostic.

The recorded compiler is Lean 4.19.0 release commit `6caaee842e94`, executable SHA-256 `92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023`. Reviewer command records use --trust=0, -j1, and -DElab.async=false; the canonical retained verifier uses -j1 and -DElab.async=false without --trust=0. The companion receipt makes this distinction. The historical report's hardcoded Agent #1 field is preserved and expressly explained as a verifier label; it is not falsely used as proof of an independent executor. The reconstructed outer replay command is labeled reconstructed, while the individual compiler commands are exact retained commands. The original tracked-clean flag is not treated as proof that all sources were committed; the 17 committed source/registry/verifier objects were checked separately.

The added checker programs support their stated role: fresh nonexistent output directories, copies from frozen source bytes, explicit LEAN_PATH to the fresh source directory, recorded compiler exit codes/log hashes, and post-run source pin checks. Publication scripts prepare metadata rather than execute a new proof build. This review did not execute those mutating publication scripts or change their historic output.

The semantic reports describe coefficient-word fibers for one reverse-add transition, with exact literal source constraints and arbitrary raw output handled by the reconstruction guard. The reports distinguish source center, normalized digit, and paired output coefficient; width one, zero positivity, prescribed-center scope, malformed targets, and duplicate freedom are covered by retained fixtures. These reports concern the already accepted source and its historical review, not a newly asserted all-time Lychrel or 196 result. Same-Agent-7-tree authorship is candidly disclosed: /root/runtime authored imported OddActual and cross-reviewed parent-authored wrappers. Earlier historical file names saying “independent” are read in that disclosed separate-execution/cross-author sense, not external peer review.

## Blocking finding at original H and exact additive resolution

The new verification/PUBLICATION.json identifies FINAL_STAGE_FILES.json as 15,165 bytes, SHA-256 `aee9237ca6b15ef6258344b811673db42fcb5f92b26e3663fec81f28e70c0496`, count 129. Actual H has 15,254 bytes, SHA-256 `521ddd05ab786ac22c8c80cf2f4d3a942f57007285cda91461a1c982a38e9229`, blob `b4077f5fcd0781873151e9d683905711e2566331`, count 130. The later SOURCE_EQUIVALENCE.json entry accounts exactly for the difference. The new README presents this as the final packet and the manifest does not label the old record a superseded checkpoint. Therefore it is a new documentation/provenance defect, not an inherited omission or a reason to rerun unrelated Lean.

Removing exactly SOURCE_EQUIVALENCE.json from the actual 130-entry list and serializing with json.dumps(entries, indent=2) plus one newline reproduces the old 129-entry length and hash exactly. reconstructed-historical-stage-list.json retains that reconstruction. It is explicitly not claimed to be a separately published historical Git object. Both source-locator metadata supplements present at H are outside the 130-entry staging checkpoint; they are actual preserved files, not missing evidence.

The root-authored, separately inspected 3,677-byte erratum fixes the discrepancy without editing the original manifest, original staging list, raw reports/logs, or sources. It pins the affected manifest, actual stage list, SOURCE_EQUIVALENCE file, SOURCE_LOCATOR_CORRECTION file, and dependencies/SOURCE_PINS file; every pin matches. It explains the exact reconstruction, distinguishes the frozen staging checkpoint from an exhaustive head file inventory, and does not claim its own new path belongs to the old list. The patch adds no mathematical claim and asserts no new compiler execution. It resolves the sole blocking finding provided the actual mutation adds only that exact file. reviewed-erratum.json retains the exact reviewed patch and erratum-review.json records the precise local-patch verdict.

## Reproducibility and limitations

Run `python /workspace/scratch/046f9285a650/review126/audit.py` to reproduce the original-H read-only checks using the two recorded local Git object stores. Its CHANGES_REQUIRED result deliberately preserves the original defect; it is not rewritten after a repair. Run check_erratum.py to verify the exact proposed additive correction. Prior-manifest-crosscheck.json records the 177 unchanged retained entries, and audit-results.json contains detailed source identities, six historical pins, both full manifest record sets, all command/log records, all report counts, stage-list details, and cleanup identities.

A first local audit helper attempt used an invalid empty Git pathspec; a later parser initially assumed one-line axiom lists. Both were local audit-tool issues, corrected without touching source or retained evidence. The final parser consumes all wrapped axiom rows and obtains the documented 285, 431, 468, and 450 counts. No compiler or research attempt was made in this review. Remote review publication, current ownership/role claims, fresh main-head gating, CI state, and merge execution are outside this reviewer role and must be handled by the parent against the final exact remote head.

## Full changed-path inventory

Paths below are relative to `proofs/contributions/agent-7/odd-nooverflow-fibers-20261016/`. Full repository-relative paths, old lengths/hashes for modified files, and exact old/new Git blob identities are in changed-paths.json. All 102 actual changed paths are included; no log or source is represented only by a summary.

| Status | Path | H bytes | H SHA-256 |
|---|---|---:|---|
'''
for r in C:text+=f"| {r['status']} | `{r['path'][len(P)+1:]}` | {r['head_bytes']} | `{r['head_sha256']}` |\n"
(O/'AUDIT_RECEIPT.md').write_text(text)
# Full audit artifacts are independently pinned without including the manifest itself.
files=[]
for f in sorted(O.rglob('*')):
 if f.is_file() and f.name!='AUDIT_FILES.json':
  b=f.read_bytes();files.append({'path':str(f.relative_to(O)),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
(O/'AUDIT_FILES.json').write_text(json.dumps(files,indent=2)+'\n')
print(json.dumps({'receipt':str(O/'AUDIT_RECEIPT.md'),'receipt_bytes':(O/'AUDIT_RECEIPT.md').stat().st_size,'receipt_sha256':hashlib.sha256((O/'AUDIT_RECEIPT.md').read_bytes()).hexdigest(),'inventory_paths':len(files)},indent=2))
