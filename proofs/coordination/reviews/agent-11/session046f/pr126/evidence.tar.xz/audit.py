#!/usr/bin/env python3
"""Read-only PR126 evidence audit. Never invokes a proof build or modifies repositories."""
import os, pathlib, subprocess, json, hashlib, re, collections
OUT=pathlib.Path('/workspace/scratch/046f9285a650/review126')
REPO=pathlib.Path('/workspace/scratch/046f9285a650/repo')
ORIGINAL=pathlib.Path('/workspace/scratch/aaafdd394dd6/agent7-run-renewal')
P='proofs/contributions/agent-7/odd-nooverflow-fibers-20261016'
PKG=OUT/'head'/P
B='5ff4f607535587d572fbc9e95ba9501d1fbe5fc5';H='d24a13d87f6673dbd9b92f0086ef65ef8b733cfb';M='46364ddda5a9d8b4f86a7777eb6d566cb7761845';T='f416eaad1f053e7b4f0000379a1a418612e644ad';L='af9ddce989030508e9fc2895f2f44fbbfcf2aed9'
results={};errors=[]
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args,repo=REPO):return subprocess.check_output(['git',*args],cwd=repo,env={**os.environ,'GIT_NO_LAZY_FETCH':'1'},stderr=subprocess.PIPE)
def readj(p):return json.loads(p.read_text())
def check(ok, message, details=None):
 if not ok:errors.append({'message':message,'details':details})
 return bool(ok)
def rec(p):
 b=p.read_bytes();return {'bytes':len(b),'sha256':sha(b),'git_blob':hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()}
def tree(ref, prefix=''):
 d={}
 for raw in git('ls-tree','-r','-z',ref,*(['--',prefix] if prefix else [])).split(b'\0'):
  if raw:
   meta,p=raw.decode().split('\t');mode,typ,obj=meta.split();d[p]={'mode':mode,'type':typ,'git_blob':obj}
 return d
full={x:tree(x) for x in [B,H,M,T]}
changed={p for p in set(full[M])|set(full[H]) if full[M].get(p)!=full[H].get(p)}
merged={p for p in set(full[B])|set(full[T]) if full[B].get(p)!=full[T].get(p)}
check(len(changed)==102 and merged==changed,'Expected exactly same 102 PR and merged-tree changed paths')
check(all(p.startswith(P+'/') for p in changed),'Scope paths restricted to package')
check(all(p in full[H] for p in full[M]),'PR deletes no historical file')
check(all(p in full[T] for p in full[B]),'Merge deletes no current-main file')
check(all(full[T].get(p)==full[H].get(p) for p in changed),'Merge changes exactly head bytes')
check(full[B]['proofs/ACCEPTED_BUILD.json']==full[T]['proofs/ACCEPTED_BUILD.json']==full[H]['proofs/ACCEPTED_BUILD.json']==full[M]['proofs/ACCEPTED_BUILD.json'],'Accepted-build catalogue unchanged')
results['scope']={'base':B,'head':H,'merge_base':M,'prospective_merge_tree':T,'changed_paths':len(changed),'merged_delta_paths':len(merged),'added':len(set(full[H])-set(full[M])),'modified':len(changed&set(full[M])),'deleted':len(set(full[M])-set(full[H])),'base_tree_entries':len(full[B]),'head_tree_entries':len(full[H]),'merged_tree_entries':len(full[T]),'prior_package_files':len(tree(M,P)),'prior_package_files_modified':[p for p in changed if p in full[M]],'accepted_build_git_blob':full[B]['proofs/ACCEPTED_BUILD.json']['git_blob']}
# Verify original and published complete source tree using their actual read-only object databases.
original_commit=git('cat-file','commit',L,repo=ORIGINAL);original_tree=git('rev-parse',L+'^{tree}',repo=ORIGINAL).decode().strip();published_tree=git('rev-parse',M+'^{tree}').decode().strip()
check(original_tree==published_tree=='0a06724e30e971e00a260cee8ec0732b9c4fba2e','Original/published complete tree equivalence')
(OUT/'original-source-commit.txt').write_bytes(original_commit)
results['source_tree_equivalence']={'original_repository':str(ORIGINAL),'original_commit':L,'original_commit_object_sha1':hashlib.sha1(f'commit {len(original_commit)}\0'.encode()+original_commit).hexdigest(),'published_commit':M,'original_tree':original_tree,'published_tree':published_tree,'complete_tree_identity':original_tree==published_tree}
registry=readj(PKG/'PROJECT_REGISTRY.json');spec=registry['projects']['agent7-odd-nooverflow-fibers'];mods=spec['modules'];endpoints=[e for c in registry['claims'] for e in c['endpoints']]
protected=[]
for name,r in mods.items():
 data=(OUT/'head'/r['path']).read_bytes();d=rec(OUT/'head'/r['path']);equal={x:full[x][r['path']]['git_blob'] for x in full}
 check(d['sha256']==r['sha256'] and d['git_blob']==r['git_blob'] and len(set(equal.values()))==1,'Protected registered source identity '+name)
 check(git('show',L+':'+r['path'],repo=ORIGINAL)==data,'Original execution commit source '+name)
 protected.append({'module':name,'path':r['path'],**d,'tree_blobs':equal})
for p in [P+'/PROJECT_REGISTRY.json','proofs/verify_project__214bf7673efe116b.py']:
 data=(OUT/'head'/p).read_bytes();check(git('show',L+':'+p,repo=ORIGINAL)==data,'Original execution commit metadata '+p);check(len({full[x][p]['git_blob'] for x in full})==1,'Protected metadata unchanged '+p);protected.append({'path':p,**rec(OUT/'head'/p)})
results['protected_sources_registry_verifier']=protected
check(len(mods)==15 and len(endpoints)==115 and sha((PKG/'PROJECT_REGISTRY.json').read_bytes())=='ca9d1fa657f6fc786fa14ed0df2456333280ee8a5eb1a58cadeebb902ff16926','Registry exact scope')
pins=[]
for r in readj(PKG/'dependencies/SOURCE_PINS.json'):
 obj=git('rev-parse',r['source_commit']+':'+r['source_path']).decode().strip();b=git('show',r['source_commit']+':'+r['source_path']);check(obj==r['git_blob'] and sha(b)==r['sha256'] and b==(PKG/'dependencies'/r['file']).read_bytes(),'Historical locator/dependency identity '+r['file']);pins.append({**r,'actual_blob':obj,'actual_bytes':len(b),'actual_sha256':sha(b),'verified':True})
results['historical_pins']=pins
# All inventories retained in PR, and manifest omissions, are independently checked.
manifest_results=[]
for fn in ['actual-dev/PUBLICATION.json','verification/PUBLICATION.json']:
 d=readj(PKG/fn);mr={'path':fn,'retained':[],'omitted':[]}
 for r in d['retained_files']:
  actual=rec(PKG/r['path']);ok=actual['bytes']==r['bytes'] and actual['sha256']==r['sha256'];check(ok,'Manifest retained identity '+fn+' '+r['path']);mr['retained'].append({'path':r['path'],**actual,'matches':ok})
 for r in d['omitted_reproducible_files']:
  if 'canonical_source' in r:
   target=PKG/r['canonical_source'];actual=rec(target);ok=actual['bytes']==r['bytes'] and actual['sha256']==r['sha256']==r['canonical_source_sha256'];check(ok,'Omitted duplicate identity '+r['path']);basis='Retained canonical source byte identity'
  else:
   source=PKG/r['source_snapshot'];dmap={q['path']:q for q in d['retained_files']+d['omitted_reproducible_files']};sr=dmap.get(r['source_snapshot']);actualsha=sha(source.read_bytes()) if source.exists() else sr.get('sha256') if sr else None;ok=actualsha==r['source_sha256'];check(ok,'Omitted compiler-object source pin '+r['path']);basis='Source pinned; compiled-object hash is historical evidence, not replayed'
  mr['omitted'].append({'path':r['path'],'bytes':r['bytes'],'sha256':r['sha256'],'basis':basis,'source_check':ok})
 manifest_results.append(mr)
old=readj(OUT/'base'/P/'actual-dev/PUBLICATION.json');new=readj(PKG/'actual-dev/PUBLICATION.json')
for key in ['retained_files','omitted_reproducible_files']:
 current={r['path']:r for r in new[key]}
 for r in old[key]:check(r['path'] in current and r['bytes']==current[r['path']]['bytes'] and r['sha256']==current[r['path']]['sha256'],'Prior publication manifest identity preserved '+r['path'])
results['manifest_records']=manifest_results
stage=[]
for fn in ['actual-dev/STAGE_FILES.json','FINAL_STAGE_FILES.json']:
 d=readj(PKG/fn);check(len(d)==len(set(d)) and all((OUT/'head'/p).is_file() for p in d),'Stage path validity '+fn);stage.append({'path':fn,**rec(PKG/fn),'count':len(d),'missing_paths':sorted(changed-set(d))})
results['stage_lists']=stage
pub=readj(PKG/'verification/PUBLICATION.json')
for key in ['status_document','combined_stage_list']:
 r=pub[key];actual=rec(PKG/r['path']);check(r['bytes']==actual['bytes'] and r['sha256']==actual['sha256'],'Publication '+key+' identity',{'recorded':r,'actual':actual})
check(pub['combined_stage_count']==len(readj(PKG/'FINAL_STAGE_FILES.json')),'Publication combined_stage_count',{'recorded':pub['combined_stage_count'],'actual':len(readj(PKG/'FINAL_STAGE_FILES.json'))})
# Verify report commands, source records, generated audits and every log's parsed content.
report_runs=[];parsed_audits=[];ALLOWED={'propext','Classical.choice','Quot.sound'}
run_paths=['actual-dev/review-canonical/attempt-002','actual-dev/review-sharp/attempt-001','actual-dev/review-sharp/final-001','verification/canonical-001']
for run in run_paths:
 path=PKG/run;report=readj(path/'verification.json');canonical=run.startswith('verification/')
 details=report['projects']['agent7-odd-nooverflow-fibers'] if canonical else report
 cmds=details['commands']; sources=details['sources'] if canonical else details['source_records'];root=path/'agent7-odd-nooverflow-fibers' if canonical else path
 logs=[]
 for c in cmds:
  log=path/c['log'] if canonical else root/'logs'/(c['module']+'.log');actual=rec(log);check(c['exit_code']==0 and c['log_sha256']==actual['sha256'],'Successful command/log '+str(log.relative_to(PKG)));logs.append({'path':str(log.relative_to(PKG)),**actual,'command':c})
 for name,r in sources.items():
  if name in mods:src=OUT/'head'/mods[name]['path']
  elif name=='ReviewCanonical':src=PKG/'actual-dev/review-canonical/ReviewCanonical.lean'
  else:src=PKG/'actual-dev/review-sharp'/(name+'.lean')
  check(sha(src.read_bytes())==r['sha256'],'Recorded source hash '+run+' '+name)
  if 'git_blob' in r:check(rec(src)['git_blob']==r['git_blob'],'Recorded source blob '+run+' '+name)
  if 'build_sha256' in r:check(r['build_sha256']==r['sha256'],'Canonical source snapshot pin '+name)
 auditname='ProjectAudit' if canonical else 'PublicAudit';audit=(root/'source'/(auditname+'.lean')).read_text();log=(root/'logs'/(auditname+'.log')).read_text()
 rows=re.findall(r'^AUDIT_THEOREM (\S+) (\S+)\s*:\s*(\[[^\]]*\])$',log,re.M);rows=[{'module':m,'theorem':n,'axioms':[x.strip() for x in axs[1:-1].split(',') if x.strip()]} for m,n,axs in rows];n=details['theorem_count'] if canonical else report['module_origin_theorem_count']
 check(len(rows)==len({x['theorem'] for x in rows})==n,'Exhaustive module audit count '+run)
 check(all(set(x['axioms'])<=ALLOWED and x['module'] in sources for x in rows),'Module audit axiom scope '+run)
 check(len(re.findall(r'^FULL_MODULE_AUDIT theorems='+str(n)+r'(?: union=.*)?$',log,re.M))==1,'Audit summary '+run)
 check(not re.search(r'(?:sorryAx|Lean\.ofReduceBool|CUSTOM_AXIOM|DISALLOWED_AXIOMS|error:)',log),'Audit rejection markers absent '+run)
 printed=re.findall(r"^'([^']+)' (?:depends on axioms: \[([^\]]*)\]|does not depend on any axioms)$",log,re.M)
 if canonical:check(re.findall(r'^#check (\S+)$',audit,re.M)==endpoints==details['endpoints'],'Canonical public endpoint audit list')
 else:
  public=[v for name in report['build_order'] for v in sources[name]['public_theorems']]
  check(re.findall(r'^#print axioms (\S+)$',audit,re.M)==public,'Reviewer explicit audit source endpoint list '+run)
  check(len(printed)==report['public_theorem_count']==len(public) and {n for n,a in printed}==set(public),'Reviewer explicit audit output count '+run)
  check(all(set(a.split(', ') if a else [])<=ALLOWED for n,a in printed),'Reviewer explicit axiom policy '+run)
 parsed_audits.append({'run':run,'rows':rows,'explicit_public_prints':[{'theorem':n,'axioms':a.split(', ') if a else []} for n,a in printed]})
 report_runs.append({'run':run,'report':rec(path/'verification.json'),'status':report['status'],'source_records':len(sources),'commands':logs,'public_endpoint_checks':len(endpoints) if canonical else report['public_theorem_count'],'module_origin_count':len(rows),'module_origin_counts':dict(collections.Counter(x['module'] for x in rows)),'generated_audit_source':rec(root/'source'/(auditname+'.lean'))})
results['execution_records']=report_runs
(OUT/'parsed-complete-audits.json').write_text(json.dumps(parsed_audits,indent=2)+'\n')
# Canonical original inventory includes reconstructible duplicate sources.
inv=readj(PKG/'verification/canonical-001/FILES.json');omitted={r['path']:r for r in pub['omitted_reproducible_files']};inventory=[]
for name,r in inv.items():
 path=PKG/'verification/canonical-001'/name;key=str(path.relative_to(PKG))
 actual=rec(path) if path.exists() else {k:omitted[key][k] for k in ['bytes','sha256']}
 check(actual['bytes']==r['bytes'] and actual['sha256']==r['sha256'],'Canonical FILES identity '+name);inventory.append({'path':name,'retained':path.exists(),'actual':actual})
results['canonical_files_inventory']=inventory
commands=readj(PKG/'verification/CANONICAL_COMMANDS.json');canreport=readj(PKG/'verification/canonical-001/verification.json');check(commands['compiler_commands']==canreport['projects']['agent7-odd-nooverflow-fibers']['commands'],'Companion exact compiler commands')
# Cleanup preserves source pins and only records reproducible objects.
cleanup=readj(PKG/'verification/cleanup/COMPILED_OBJECT_CLEANUP.json');removed=cleanup['removed'];check(len(removed)==256 and len({r['path'] for r in removed})==256 and all(r['path'].endswith('.olean') for r in removed),'Cleanup is exactly 256 distinct compiler objects')
cm=[r for r in removed if r['path'].startswith(P+'/verification/canonical-001/')];check(len(cm)==15 and sum(r['bytes'] for r in cm)==6983952,'Canonical cleanup object count and bytes')
for r in cm:
 o=omitted[r['path'][len(P)+1:]];check(o['sha256']==r['sha256'] and o['bytes']==r['bytes'],'Cleanup omitted-object identity '+r['path'])
results['cleanup']={'count':len(removed),'canonical_count':len(cm),'canonical_bytes':sum(r['bytes'] for r in cm),'receipt':rec(PKG/'verification/cleanup/COMPILED_OBJECT_CLEANUP.json'),'all_suffixes':sorted({pathlib.Path(r['path']).suffix for r in removed})}
# Report-level semantic hashes and freeze launcher.
for fn in ['actual-dev/review-canonical/REVIEW.json','actual-dev/review-sharp/REVIEW.json','actual-dev/review-sharp/FINAL_REVIEW.json']:
 d=readj(PKG/fn);v=d['verification'];rp=v['path'] if isinstance(v,dict) else v;expected=v['sha256'] if isinstance(v,dict) else d['verification_sha256'];check(sha((PKG/rp).read_bytes())==expected,'Semantic report exact execution hash '+fn)
launch=readj(PKG/'actual-dev/review-sharp/final-001/LAUNCH.json')
for k,fn in [('registry_sha256','PROJECT_REGISTRY.json'),('builder_sha256','actual-dev/review-canonical/build_review.py'),('runner_sha256','actual-dev/review-sharp/run_final_review.py')]:check(sha((PKG/fn).read_bytes())==launch[k],'Launch source identity '+fn)
check(launch['exit_code']==0 and launch['runner_and_registry_unchanged'],'Final fresh launch success and pins')
# Store complete path-level inventories and outcomes; never edits source manifests.
results['findings']=errors;results['verdict']='CHANGES_REQUIRED' if errors else 'PASS';(OUT/'audit-results.json').write_text(json.dumps(results,indent=2)+'\n')
print(json.dumps({'verdict':results['verdict'],'findings':errors,'scope':results['scope'],'tree_equivalence':results['source_tree_equivalence'],'reports':[{'run':x['run'],'commands':len(x['commands']),'module_origin_count':x['module_origin_count']} for x in report_runs]},indent=2))
