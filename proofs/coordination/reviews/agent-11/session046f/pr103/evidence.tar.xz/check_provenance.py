"""Check historical source pins and retained scout rows, with no Lean execution."""
import difflib, hashlib, json, os, pathlib, runpy, subprocess
R=pathlib.Path('/dev/shm/p196-agent11-046f/review103');S=R/'source';E=R/'evidence'
P=S/'proofs/contributions/agent-100/third-gate-boundary-20261016';C=P/'verification/checkpoint01'
H='6b2a8c7ca89eb513c8832dd4cd995c69d953deb8'
env=dict(os.environ,GIT_OBJECT_DIRECTORY=str(R/'objects'),GIT_ALTERNATE_OBJECT_DIRECTORIES='/dev/shm/p196-agent11-046f/objects:/workspace/scratch/046f9285a650/repo/.git/objects',GIT_OPTIONAL_LOCKS='0')
def sha(b):return hashlib.sha256(b).hexdigest()
def git(*args):
 p=subprocess.run(['git','-C','/workspace/scratch/046f9285a650/repo',*args],env=env,capture_output=True)
 assert p.returncode==0,(args,p.stderr)
 return p.stdout
def obj(p):return json.loads(p.read_text())
reg=obj(C/'registry.json');mods=reg['projects']['third-gate-boundary']['modules'];pub=obj(C/'publication-provenance.json')
checks=[]
for module,pin in mods.items():
 commit=pub['published_source_commit'] if module.startswith('Agent100ThirdGate') else pub['source_base_at_build_start']
 b=git('show',commit+':'+pin['path'])
 assert sha(b)==pin['sha256'] and git('rev-parse',commit+':'+pin['path']).decode().strip()==pin['git_blob']
 checks.append({'commit':commit,'path':pin['path'],'blob':pin['git_blob'],'bytes':len(b),'sha256':sha(b),'recovery':'git show '+commit+':'+pin['path']})
for pin in obj(R/'archive/inherited-harness/dependencies/source-pins.json'):
 archived_path='proofs/archive/source-trees/2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5/'+pin['original']
 b=git('show',H+':'+archived_path); assert sha(b)==pin['sha256']
 assert git('rev-parse',H+':'+archived_path).decode().strip()==pin['blob']
 checks.append({'commit':H,'path':archived_path,'historical_original_path_label':pin['original'],'blob':pin['blob'],'bytes':len(b),'sha256':sha(b),'recovery':'git show '+H+':'+archived_path})
helper=S/'proofs/contributions/agent-100/groupII-overlap-20261016/controls/groupII_controls.py'
f=runpy.run_path(str(helper),run_name='static_scout_validation')
scout=obj(P/'controls/time6_scout.json');observed=[]
for row in scout['rows']:
 r=row['r'];na,aa=f['integer_trajectory'](f['component'](r,1,1,6),6);nq,qq=f['integer_trajectory'](f['phi'](f['component'](r,1,1,6)),6)
 actual={'r':r,'component_widths':[len(x) for x in aa],'whole_widths':[len(x) for x in qq],
  'component_prefix_t4_t5_t6':[x[:4] for x in aa[4:]],'whole_prefix_t4_t5_t6':[x[:4] for x in qq[4:]],
  'component_palindrome_flags':[f['palindromic'](x) for x in na],'whole_palindrome_flags':[f['palindromic'](x) for x in nq],
  'time6_full_difference':f['sparse_difference'](qq[6],f['phi'](aa[6]))}
 assert actual==row;observed.append(actual)
diffs=[]
for a,b in [('boundary/attempt01.lean','boundary/attempt02.lean'),('boundary/controls-attempt01.lean','boundary/controls-attempt02.lean')]:
 diffs += list(difflib.unified_diff((P/'development'/a).read_text().splitlines(True),(P/'development'/b).read_text().splitlines(True),fromfile=a,tofile=b))
(E/'development-repair-diff.txt').write_text(''.join(diffs))
(E/'historical-source-recovery-map.json').write_text(json.dumps(checks,indent=2)+'\n')
archive=obj(C/'evidence-manifest.json'); archive_path=str((C/'evidence.tar.xz').relative_to(S)); archive_blob=git('rev-parse',H+':'+archive_path).decode().strip()
recovery=[]
for member,pin in archive['files'].items():
 recovery.append({'commit':H,'archive_path':archive_path,'archive_blob':archive_blob,'archive_sha256':archive['sha256'],'archive_bytes':archive['bytes'],'member':member,**pin,'recovery':'git show '+H+':'+archive_path+' | tar -xOJf - '+member})
(E/'archive-member-recovery-map.json').write_text(json.dumps(recovery,indent=2)+'\n')
out={'status':'PASS','historical_source_checks':checks,'scout_status':'PASS_FINITE_RECORDED_ROWS_ONLY','scout_rows':observed,'scout_additions':12*len(observed),'development_changes':'Failed Boundary tactics replaced by congrArg and redundant omega removed; Controls add an explicit Fin L admissibility bridge and bounded canonical-digit checks. Successful snapshots match accepted files exactly.','new_lean_execution':'NOT_RUN'}
(E/'provenance-result.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
