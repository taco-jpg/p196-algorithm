import hashlib, json, os, pathlib, subprocess, tarfile
R = pathlib.Path('/dev/shm/p196-agent11-046f/review103')
S = R / 'source'
P = S / 'proofs/contributions/agent-100/third-gate-boundary-20261016'
C = P / 'verification/checkpoint01'
H = '6b2a8c7ca89eb513c8832dd4cd995c69d953deb8'
env = dict(os.environ, GIT_OBJECT_DIRECTORY=str(R / 'objects'),
 GIT_ALTERNATE_OBJECT_DIRECTORIES='/dev/shm/p196-agent11-046f/objects:/workspace/scratch/046f9285a650/repo/.git/objects', GIT_OPTIONAL_LOCKS='0')
def sha(b): return hashlib.sha256(b).hexdigest()
def git(*args):
 p = subprocess.run(['git','-C','/workspace/scratch/046f9285a650/repo',*args],env=env,capture_output=True)
 assert p.returncode == 0, (args,p.stderr)
 return p.stdout
m = json.loads((C/'evidence-manifest.json').read_text())
raw = (C/'evidence.tar.xz').read_bytes()
assert len(raw)==m['bytes'] and sha(raw)==m['sha256']
members=[]
with tarfile.open(C/'evidence.tar.xz','r:xz') as t:
 for member in t.getmembers():
  assert member.isfile() and not pathlib.Path(member.name).is_absolute() and '..' not in pathlib.Path(member.name).parts
  b=t.extractfile(member).read(); pin=m['files'][member.name]
  assert len(b)==pin['bytes'] and sha(b)==pin['sha256'],member.name
  target=R/'archive'/member.name; target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(b)
  members.append(member.name)
assert set(members)==set(m['files']) and len(members)==m['member_count']
reg=json.loads((C/'registry.json').read_text())
mods=reg['projects']['third-gate-boundary']['modules']
recovery=[]
extra=['proofs/verify_project__214bf7673efe116b.py',
 'proofs/contributions/agent-100/groupII-overlap-20261016/verification/dependencies/replay.py',
 'proofs/contributions/agent-100/groupII-overlap-20261016/verification/dependencies/source-pins.json',
 'proofs/contributions/agent-100/groupII-overlap-20261016/verification/dependencies/registry.json',
 'proofs/contributions/agent-100/groupII-overlap-20261016/verification/checkpoint02/registry.json']
for path in sorted(set([x['path'] for x in mods.values()]+extra)):
 b=git('show',H+':'+path); dest=S/path; dest.parent.mkdir(parents=True,exist_ok=True); dest.write_bytes(b)
 recovery.append({'commit':H,'path':path,'blob':git('rev-parse',H+':'+path).decode().strip(),'bytes':len(b),'sha256':sha(b),'recovery':'git show '+H+':'+path})
for name,pin in mods.items():
 b=(S/pin['path']).read_bytes()
 assert sha(b)==pin['sha256'] and hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()==pin['git_blob'],name
 assert b==(R/'archive/build/third-gate-boundary/source'/f'{name}.lean').read_bytes(),name
(R/'evidence/closure-recovery-map.json').write_text(json.dumps(recovery,indent=2)+'\n')
(R/'evidence/archive-static-check.json').write_text(json.dumps({'status':'PASS','archive':m['archive'],'archive_sha256':sha(raw),'members':members,'module_count':len(mods),'all_registry_and_archived_module_bytes_match_head':True},indent=2)+'\n')
print(json.dumps({'status':'PASS','members':members,'module_names':list(mods)},indent=2))
