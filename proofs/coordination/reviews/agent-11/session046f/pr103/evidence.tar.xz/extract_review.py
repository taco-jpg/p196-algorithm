import hashlib, json, os, pathlib, subprocess

ROOT = pathlib.Path('/dev/shm/p196-agent11-046f/review103')
REPO = '/workspace/scratch/046f9285a650/repo'
HEAD = '6b2a8c7ca89eb513c8832dd4cd995c69d953deb8'
BASE = '2bc42391c63b744951f27fde11af8c7d7958077f'
ENV = dict(os.environ, GIT_OBJECT_DIRECTORY=str(ROOT / 'objects'),
    GIT_ALTERNATE_OBJECT_DIRECTORIES='/dev/shm/p196-agent11-046f/objects:' + REPO + '/.git/objects',
    GIT_OPTIONAL_LOCKS='0', PYTHONDONTWRITEBYTECODE='1')
records = []

def git(*args):
    p = subprocess.run(['git', '-C', REPO, *args], env=ENV, capture_output=True)
    records.append({'argv': ['git', '-C', REPO, *args], 'exit_code': p.returncode,
                    'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(),
                    'stderr': p.stderr.decode(errors='replace')})
    if p.returncode:
        raise RuntimeError(records[-1])
    return p.stdout

merge_base = git('merge-base', BASE, HEAD).decode().strip()
paths = git('diff', '--name-only', BASE + '...' + HEAD).decode().splitlines()
paths += ['AGENTS.md', 'proofs/PUBLICATION_POLICY.md']
inventory = []
for path in paths:
    data = git('show', HEAD + ':' + path)
    target = ROOT / 'source' / path
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(data)
    inventory.append({'commit': HEAD, 'path': path,
        'blob': git('rev-parse', HEAD + ':' + path).decode().strip(),
        'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest(),
        'recovery': 'git show ' + HEAD + ':' + path})
(ROOT / 'evidence' / 'full.diff').write_bytes(git('diff', '--binary', BASE + '...' + HEAD))
(ROOT / 'evidence' / 'source-recovery-map.json').write_text(json.dumps(inventory, indent=2) + '\n')
(ROOT / 'evidence' / 'extraction-receipt.json').write_text(json.dumps({'head': HEAD,
    'base': BASE, 'merge_base': merge_base, 'changed_paths': len(paths)-2,
    'commands': records}, indent=2) + '\n')
print(json.dumps({'head': HEAD, 'base': BASE, 'merge_base': merge_base, 'changed_paths': len(paths)-2}))
