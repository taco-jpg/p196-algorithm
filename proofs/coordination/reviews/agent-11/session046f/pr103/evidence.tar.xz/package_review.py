"""Package new review artifacts; recover original research from immutable Git pins."""
import hashlib, io, json, pathlib, tarfile
R=pathlib.Path('/dev/shm/p196-agent11-046f/review103')
def sha(b):return hashlib.sha256(b).hexdigest()
def obj(p):return json.loads(p.read_text())
maps=['source-recovery-map.json','closure-recovery-map.json','diagnostic-dependency-recovery.json']
pins={}
for name in maps:
 for rec in obj(R/'evidence'/name):pins[rec['path']]=rec
for p in (R/'source').rglob('*'):
 if p.is_file():
  pin=pins[str(p.relative_to(R/'source'))];b=p.read_bytes()
  assert len(b)==pin['bytes'] and sha(b)==pin['sha256']
archivepins={r['member']:r for r in obj(R/'evidence/archive-member-recovery-map.json')}
for p in (R/'archive').rglob('*'):
 if p.is_file():
  pin=archivepins[str(p.relative_to(R/'archive'))];b=p.read_bytes()
  assert len(b)==pin['bytes'] and sha(b)==pin['sha256']
diff=(R/'evidence/full.diff').read_bytes()
excluded={'source/':{'classification':'Already published exact Git byte duplicates','recovery_maps':maps},
 'archive/':{'classification':'Already published verified archive-member duplicates','recovery_map':'archive-member-recovery-map.json'},
 'objects/':{'classification':'Reproducible Git object infrastructure; no new object written'},
 'evidence/full.diff':{'classification':'Reproducible exact-head binary diff of already published content','bytes':len(diff),'sha256':sha(diff),'recovery':'git -C REPO diff --binary 2bc42391c63b744951f27fde11af8c7d7958077f...6b2a8c7ca89eb513c8832dd4cd995c69d953deb8'}}
(R/'evidence/package-exclusions.json').write_text(json.dumps(excluded,indent=2)+'\n')
paths=[R/'REVIEW.md',*sorted(R.glob('*.py')),*sorted(p for p in (R/'evidence').rglob('*') if p.is_file() and p.name!='full.diff')]
entries={str(p.relative_to(R)):p.read_bytes() for p in paths}
archive=R/'publish-evidence.tar.xz'
with tarfile.open(archive,'w:xz') as t:
 for name,b in sorted(entries.items()):
  member=tarfile.TarInfo(name);member.size=len(b);member.mode=0o644;member.mtime=0
  t.addfile(member,io.BytesIO(b))
with tarfile.open(archive,'r:xz') as t:
 assert {m.name for m in t.getmembers()}==set(entries)
 for m in t.getmembers():assert m.isfile() and t.extractfile(m).read()==entries[m.name]
manifest={'reviewer':'Agent #11 session046f independent nonauthor review103','head':'6b2a8c7ca89eb513c8832dd4cd995c69d953deb8','status':'NO_REVIEW_BLOCKER_FOUND','fresh_lean':'NOT_RUN','archive':'publish-evidence.tar.xz','bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'member_count':len(entries),'members':{n:{'bytes':len(b),'sha256':sha(b)} for n,b in sorted(entries.items())},'exclusions':excluded,'package_roundtrip':'PASS','commands':[{'command':'PYTHONDONTWRITEBYTECODE=1 python package_review.py','exit_status':'NORMAL_COMPLETION','effect':'Local evidence packaging and byte-preserving readback only'}]}
(R/'package.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:manifest[k] for k in ['status','fresh_lean','archive','bytes','sha256','member_count','package_roundtrip']},indent=2))
