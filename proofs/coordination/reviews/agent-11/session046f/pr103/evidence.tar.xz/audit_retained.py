"""Read-only retained-evidence audit. Never invokes Lean or the replay main."""
import ast, collections, hashlib, json, lzma, os, pathlib, re, runpy, subprocess
R = pathlib.Path('/dev/shm/p196-agent11-046f/review103')
S = R/'source'; A=R/'archive'; E=R/'evidence'
P=S/'proofs/contributions/agent-100/third-gate-boundary-20261016'; C=P/'verification/checkpoint01'
H='6b2a8c7ca89eb513c8832dd4cd995c69d953deb8'
def sha(b): return hashlib.sha256(b).hexdigest()
def obj(p): return json.loads(p.read_text())
def checkpin(p,pin):
 b=p.read_bytes(); assert len(b)==pin['bytes'] and sha(b)==pin['sha256'],str(p)
 return b
env=dict(os.environ,GIT_OBJECT_DIRECTORY=str(R/'objects'),GIT_ALTERNATE_OBJECT_DIRECTORIES='/dev/shm/p196-agent11-046f/objects:/workspace/scratch/046f9285a650/repo/.git/objects',GIT_OPTIONAL_LOCKS='0')
def git(*args):
 p=subprocess.run(['git','-C','/workspace/scratch/046f9285a650/repo',*args],env=env,capture_output=True)
 assert p.returncode==0,(args,p.stderr)
 return p.stdout
reg=obj(C/'registry.json'); project=reg['projects']['third-gate-boundary']; mods=project['modules']
report=obj(A/'build/verification.json'); run=report['projects']['third-gate-boundary']; receipt=obj(A/'build/agent100-replay-invocation.json'); result=obj(C/'result.json')
assert report['status']==run['status']==result['status']=='PASS'
assert report['mathematical_proof_check'] and not report['repository_wide_pass'] and not report['catalogue_complete']
assert receipt['check_only'] is False and receipt['exit_code']==0
assert sha((A/'build/verification.json').read_bytes())==receipt['verification_sha256']==result['verification_report_sha256']
assert sha((A/'build/agent100-replay-invocation.json').read_bytes())==result['invocation_receipt_sha256']
assert sha((C/'registry.json').read_bytes())==report['registry_sha256']==receipt['registry_sha256']==result['registry_sha256']
assert not any(x.startswith('--check-only') for x in receipt['command'])
assert report['compiler']==result['compiler'] and '4.19.0' in report['compiler']['version']
for path,pin in obj(A/'build/FILES.json').items(): checkpin(A/'build'/path,pin)
for p in (A/'harness').iterdir():
 target=S/'proofs/verify_project__214bf7673efe116b.py' if p.name=='upstream-verifier.py' else C/p.name
 assert p.read_bytes()==target.read_bytes(),str(p)
for p in (A/'inherited-harness').rglob('*'):
 if p.is_file():
  target=S/'proofs/contributions/agent-100/groupII-overlap-20261016/verification'/p.relative_to(A/'inherited-harness')
  assert p.read_bytes()==target.read_bytes(),str(p)
assert sha((A/'harness/upstream-verifier.py').read_bytes())==receipt['pinned_verifier_sha256']
assert sha((A/'inherited-harness/dependencies/replay.py').read_bytes())==receipt['replay_sha256']
assert sha((A/'inherited-harness/dependencies/source-pins.json').read_bytes())==receipt['dependency_pins_sha256']
mask=runpy.run_path(str(A/'harness/upstream-verifier.py'),run_name='retained_static_inspection')['code_only']
seen=set(); order=[]
def visit(n):
 if n in seen or n not in mods:return
 seen.add(n)
 for d in mods[n]['imports']:visit(d)
 order.append(n)
for root in project['roots']:visit(root)
assert seen==set(mods) and order==run['build_order']
all_new=[]; signature_counts={}; new_inventory=obj(C/'statement-inventory.json')['modules']
for n,pin in mods.items():
 b=(S/pin['path']).read_bytes(); code=mask(b.decode())
 assert not pin.get('adapter') and run['sources'][n]['adapter'] is None
 assert run['sources'][n]['sha256']==run['sources'][n]['build_sha256']==pin['sha256']==sha(b)
 assert [d for line in re.findall(r'^\s*import\s+([^\n]+)',code,re.M) for d in line.split()]==pin['imports']
 assert not re.search(r'\b(sorry|admit|axiom|sorryAx|native_decide|ofReduceBool|skipKernelTC)\b',code),n
 if n in new_inventory:
  text=b.decode(); namespace=re.findall(r'^namespace (\S+)\s*$',text,re.M)
  assert len(namespace)==1
  named=[]
  for m in re.finditer(r'^theorem\s+(\w+)\b([\s\S]*?)\s*:=',text,re.M):
   name=namespace[0]+'.'+m.group(1); signature=m.group(0).rsplit(':=',1)[0].rstrip()
   named.append({'name':name,'signature_source':signature,'signature_sha256':sha(signature.encode())})
  assert named==new_inventory[n]['statements']
  assert [x['name'] for x in named]==re.findall(r'^#print axioms (\S+)\s*$',text,re.M)
  all_new += [x['name'] for x in named]; signature_counts[n]=len(named)
assert [x['label'] for x in run['commands']]==order+['ProjectAudit']
for cmd in run['commands']:
 n=cmd['label']; expected=[receipt['command'][receipt['command'].index('--lean')+1],'-j1','-DElab.async=false']
 if n!='ProjectAudit':expected += ['-o',n+'.olean']
 expected += [n+'.lean']; assert cmd['argv']==expected and cmd['exit_code']==0
 b=(A/'build'/cmd['log']).read_bytes(); assert sha(b)==cmd['log_sha256']
 assert not re.search(r'error:|sorryAx|CUSTOM_AXIOM|DISALLOWED_AXIOMS',b.decode()),n
audit=(A/'build/third-gate-boundary/logs/ProjectAudit.log').read_text()
raw_entries=re.findall(r'^AUDIT_THEOREM (\S+) (\S+) : \[([^\]]*)\]$',audit,re.M)
assert len(raw_entries)==audit.count('AUDIT_THEOREM ')
axioms={}; allowed={'propext','Classical.choice','Quot.sound'}
for module,name,raw in raw_entries:
 axs=[x.strip() for x in raw.split(',') if x.strip()]
 assert name not in axioms and module in mods and set(axs)<=allowed
 axioms[name]={'module':module,'axioms':axs}
total=re.findall(r'^FULL_MODULE_AUDIT theorems=(\d+) union=\[([^\]]*)\]$',audit,re.M)
assert len(total)==1 and int(total[0][0])==len(axioms)==run['theorem_count']==result['theorem_constants_audited']
unsafe=re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$',audit,re.M)
assert list(map(list,unsafe))==run['unsafe_implementation_axioms']==result['unsafe_implementation_axioms']
assert not ({n for _,n in unsafe}&{a for x in axioms.values() for a in x['axioms']})
names=[n for c in reg['claims'] for n in c['endpoints']]
assert len(names)==len(set(names)) and set(names)<=set(axioms) and names==run['endpoints']
assert {n:axioms[n] for n in all_new}==obj(C/'named-endpoint-axioms.json')
assert {n:axioms[n] for n in names if n not in all_new}==obj(C/'inherited-endpoint-axioms.json')
for n in new_inventory:
 log=(A/'build/third-gate-boundary/logs'/f'{n}.log').read_text()
 printed={m[0]:[a.strip() for a in m[1].split(',') if a.strip()] for m in re.findall(r"^'([^']+)' depends on axioms: \[([^\]]*)\]$",log,re.M)}
 printed.update({name:[] for name in re.findall(r"^'([^']+)' does not depend on any axioms$",log,re.M)})
 assert set(printed)=={x for x in all_new if axioms[x]['module']==n}
 assert all(set(ax)==set(axioms[name]['axioms']) for name,ax in printed.items())
for rec in obj(C/'history-exclusions.json')['files']:
 b=checkpin(S/rec['path'],rec)
 assert b==(A/'history-excluded'/pathlib.Path(rec['path']).relative_to(P.relative_to(S))).read_bytes()
for source,snapshot in [('Agent100ThirdGateBoundary','boundary/attempt02.lean'),('Agent100ThirdGateControls','boundary/controls-attempt02.lean'),('Agent100ThirdGateNumeric','numeric/attempt01.lean')]:
 assert (S/'proofs'/f'{source}.lean').read_bytes()==(P/'development'/snapshot).read_bytes()
index=obj(P/'controls/artifact-index.json')
for rec in index['files']:checkpin(P/'controls'/rec['name'],rec)
parsed=[]
for path in P.rglob('*'):
 if path.suffix=='.json':obj(path);parsed.append(str(path.relative_to(P)))
 if path.suffix=='.py':ast.parse(path.read_text(),filename=str(path))
summary=obj(P/'controls/two-column-summary.json'); xz=obj(P/'controls/two-column-xz.json')
assert sha((P/'controls/two-column-cases.jsonl.xz').read_bytes())==xz['stored_sha256']
digest=hashlib.sha256(); decoded_bytes=0; count=0; additions=0; groups=collections.Counter(); examples={}
with lzma.open(P/'controls/two-column-cases.jsonl.xz','rb') as f:
 for line in f:
  digest.update(line); decoded_bytes+=len(line); row=json.loads(line);count+=1
  key=(row['family'],row['width'],row['z'],row['second']);groups[key]+=1;examples.setdefault(key,row)
  ns=row['integers']; words=row['words']; carries=row['carries']; additions+=len(ns)-1
  assert len(words)==len(ns)==len(carries)+1 and words[0][0] in (7,16)
  assert len(words[0])==row['width'] and words[0][1]==row['second']
  for i,n in enumerate(ns):
   digits=list(map(int,str(n)[::-1])); assert [a+b for a,b in zip(digits,digits[::-1])]==words[i]
   if i:
    assert n==ns[i-1]+int(str(ns[i-1])[::-1])
    cs=carries[i-1]; assert cs[0]==0 and len(cs)==len(words[i-1])+1
    assert all(cs[j+1]==(v+cs[j])//10 for j,v in enumerate(words[i-1]))
  if row['family'].startswith('sixteen'):
   low=row['family']=='sixteen_low'; assert words[1][:2]==[7,(7 if low else 14)+row['z']]
   assert words[2][0]==(14 if low else 15) and list(map(len,words))==[row['width'],row['width']+1,row['width']+1]
  else: assert words[1][0]==(14 if row['family']=='seven_low' else 15) and len(words[1])==row['width']
assert decoded_bytes==xz['decoded_bytes']==summary['trace']['decoded_bytes'] and digest.hexdigest()==xz['decoded_sha256']==summary['trace']['decoded_sha256']
assert count==summary['cases'] and additions==summary['ordinary_additions']
assert all(groups[(g['family'],g['width'],g['z'],g['second'])]==g['count'] for g in summary['group_counts'])
assert all(examples[(r['family'],r['width'],r['z'],r['second'])]==r for r in summary['representatives'])
assert {k:v for k,v in summary.items() if k in ['status','cases','ordinary_additions','empty_groups','source_sha256']}=={k:v for k,v in obj(P/'controls/two-column-controls.log').items() if k!='trace'}
assert (P/'controls/time6-scout.log').read_bytes()==(P/'controls/time6_scout.json').read_bytes()
assert (P/'controls/two-column-examples.log').read_bytes()==(P/'controls/two-column-boundary-examples.json').read_bytes()
assert (P/'controls/two-column-compression.log').read_bytes()==(P/'controls/two-column-xz.json').read_bytes()
extra=[]
helper='proofs/contributions/agent-100/groupII-overlap-20261016/controls/groupII_controls.py'
b=git('show',H+':'+helper); assert sha(b)=='50e73312a3a89a8f90a7d8fc6a40b3280724c764c5e433a2a10734ead2f28f31'
dest=S/helper;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(b)
extra.append({'commit':H,'path':helper,'blob':git('rev-parse',H+':'+helper).decode().strip(),'bytes':len(b),'sha256':sha(b),'recovery':'git show '+H+':'+helper})
(E/'diagnostic-dependency-recovery.json').write_text(json.dumps(extra,indent=2)+'\n')
(E/'reparsed-full-axioms.json').write_text(json.dumps(axioms,indent=2)+'\n')
out={'status':'PASS','new_lean_execution':'NOT_RUN','historical_executor':receipt['executor'],'historical_compiler':report['compiler'],'exact_commands':run['commands'],'root_closure':order,'new_export_counts':signature_counts,'all_named_endpoints':len(names),'full_raw_audit_count':len(axioms),'full_axiom_union':sorted({a for x in axioms.values() for a in x['axioms']}),'unsafe_implementation_symbols':unsafe,'retained_history_files':len(obj(C/'history-exclusions.json')['files']),'diagnostic_trace':{'rows':count,'ordinary_additions':additions,'decoded_bytes':decoded_bytes,'decoded_sha256':digest.hexdigest()},'parsed_json_files':parsed,'no_current_acceptance_blocker_found':True}
(E/'retained-audit-result.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
