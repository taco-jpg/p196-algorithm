#!/usr/bin/env python3
"""Independently verify inherited closure and exact audit-driver generation."""
import ast
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

repo = Path(sys.argv[1])
out = Path(sys.argv[2])
out.mkdir(exist_ok=False)
head = 'c440e01ee4375384317cc2e428b7c43e8a04ecdf'
base = '5d3b027df045eb017a8e37d3826b10105a587e9b'
root = 'proofs/contributions/agent-1/periodic-zero-escape-20261016/review/'
def read(path, commit=head):
    return subprocess.check_output(['git', '-C', str(repo), 'show', commit + ':' + path])
manifest = json.loads(read(root + 'final-source-identity.json'))['sources']
new = {'Agent1PeriodicZeroPrefix', 'Agent1PeriodicZeroInterfaceMass', 'Agent1PeriodicZeroEscape'}
inherited = []
for e in manifest:
    if e['module'] not in new:
        inherited.append({'module': e['module'], 'path': e['path'],
                          'unchanged_from_base': read(e['path']) == read(e['path'], base)})
driver = read(root + 'replay.py').decode()
tree = ast.parse(driver)
template = None
for node in tree.body:
    if isinstance(node, ast.Assign) and any(isinstance(t, ast.Name) and t.id == 'audit' for t in node.targets):
        template = ast.literal_eval(node.value.func.value)
assert template is not None
selected = ', '.join(json.dumps(e['module']) for e in manifest)
generated = template.replace('SELECTED', selected)
for e in manifest:
    mod = e['module']
    if not mod.startswith('Agent1'): continue
    ns = 'Agent1.Periodic' if mod.startswith('Agent1Periodic') else 'Agent1.RepeatedBlock'
    for name in re.findall(r'^theorem\s+(\w+)', read(e['path']).decode(), re.M):
        generated += '\n#check ' + ns + '.' + name + '\n'
matches = generated.encode() == read(root + 'clean-001/ReviewAudit.lean')
report = {'head': head, 'base': base, 'inherited_modules': inherited,
          'inherited_count': len(inherited), 'new_count': len(new),
          'retained_audit_exactly_reconstructed_from_driver_and_source': matches,
          'audit_source_sha256': hashlib.sha256(generated.encode()).hexdigest(),
          'fresh_lean_here': 'NOT_RUN'}
report['status'] = 'PASS' if len(inherited) == 23 and all(x['unchanged_from_base'] for x in inherited) and matches else 'FAIL'
(out / 'results.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
sys.exit(0 if report['status'] == 'PASS' else 1)
