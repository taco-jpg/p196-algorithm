#!/usr/bin/env python3
"""Read-only PR141 source/evidence audit. Does not invoke Lean or mutate Git."""
import argparse
import collections
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

HEAD = 'c440e01ee4375384317cc2e428b7c43e8a04ecdf'
BASE = '5d3b027df045eb017a8e37d3826b10105a587e9b'
SOURCE = '6145e2aa53861bdf6c7a820dd8ee78da9abc014f'
CONTRIB = 'proofs/contributions/agent-1/periodic-zero-escape-20261016'
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}
ap = argparse.ArgumentParser()
ap.add_argument('--repo', type=Path, required=True)
ap.add_argument('--out', type=Path, required=True)
a = ap.parse_args()
a.out.mkdir(parents=True, exist_ok=False)
checks, failures, recovery = [], [], {}
def check(name, ok, detail=None):
    checks.append({'check': name, 'pass': bool(ok), 'detail': detail})
    if not ok:
        failures.append(name)
def git(*args):
    return subprocess.check_output(['git', '-C', str(a.repo), *args])
def sha(raw):
    return hashlib.sha256(raw).hexdigest()
def read(path, commit=HEAD):
    data = git('show', commit + ':' + path)
    recovery[commit + ':' + path] = {'commit': commit, 'path': path,
        'bytes': len(data), 'sha256': sha(data),
        'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()}
    return data
def obj(path):
    return json.loads(read(path))
def dump(name, data):
    (a.out / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')
def code_only(src):
    """Remove nested Lean block/line comments and strings, preserving newlines."""
    out, i, depth = [], 0, 0
    while i < len(src):
        if depth:
            if src.startswith('/-', i): depth += 1; i += 2
            elif src.startswith('-/', i): depth -= 1; i += 2
            else: out.append('\n' if src[i] == '\n' else ' '); i += 1
        elif src.startswith('/-', i): depth = 1; i += 2
        elif src.startswith('--', i):
            j = src.find('\n', i); i = len(src) if j < 0 else j
        elif src[i] == '"':
            i += 1
            while i < len(src) and src[i] != '"':
                if src[i] == '\\': i += 1
                i += 1
            i += 1; out.append(' ')
        else: out.append(src[i]); i += 1
    assert depth == 0
    return ''.join(out)

read('AGENTS.md'); read('proofs/PUBLICATION_POLICY.md')
diff = git('diff', '--name-status', BASE, HEAD).decode().splitlines()
check('complete_contribution_diff', len(diff) == 181 and all(x.startswith('A\t') for x in diff), len(diff))
for line in diff: read(line.split('\t', 1)[1])
registry = obj('proofs/Agent1PeriodicZeroEscape.registry.json')
project = registry['projects']['agent1-periodic-zero-escape']
pins = project['modules']
identity = obj(CONTRIB + '/review/final-source-identity.json')
manifest = identity['sources']
check('registry_pin', sha(read(identity['registry_path'])) == identity['registry_sha256'])
check('registry_source_baseline', registry['source_baseline'] == BASE)
check('manifest_modules_exact', set(pins) == {e['module'] for e in manifest} and len(pins) == 26)
check('manifest_original_source_commit', identity['source_commit'] == SOURCE)
sources, imports, topo, named = {}, {}, set(), []
lexical_findings = []
for e in manifest:
    mod, path = e['module'], e['path']
    raw = read(path)
    sources[mod] = raw.decode()
    check('source_pin:' + mod, sha(raw) == e['sha256'] and e == {'module': mod, **pins[mod]})
    check('original_compiled_commit:' + mod, raw == read(path, SOURCE))
    check('source_blob:' + mod, recovery[HEAD + ':' + path]['git_blob'] == e['git_blob'])
    check('compiled_source_snapshot:' + mod, raw == read(CONTRIB + '/review/clean-001/compiled-sources/' + mod + '.lean'))
    check('parent_source_snapshot:' + mod, raw == read(CONTRIB + '/verification/parent-clean-001/agent1-periodic-zero-escape/source/' + mod + '.lean'))
    code = code_only(sources[mod])
    imports[mod] = re.findall(r'^import\s+(\S+)\s*$', code, re.M)
    check('actual_imports:' + mod, imports[mod] == e['imports'])
    check('topological_compile_order:' + mod, all(dep in topo or dep in {'Std', 'Init', 'Lean'} for dep in imports[mod]))
    topo.add(mod)
    for hit in re.finditer(r'\b(?:sorry|admit|sorryAx|axiom|native_decide|unsafe|extern|implemented_by|partial)\b|Lean\.ofReduceBool|Lean\.ofReduceNat|\b(?:run_elab|run_tac|run_cmd)\b', code):
        lexical_findings.append({'module': mod, 'token': hit.group(), 'line': code[:hit.start()].count('\n')+1})
    if mod.startswith('Agent1'):
        ns = 'Agent1.Periodic' if mod.startswith('Agent1Periodic') else 'Agent1.RepeatedBlock'
        named += [(mod, ns + '.' + name) for name in re.findall(r'^theorem\s+(\w+)', code, re.M)]
check('closure_lexical_forbidden_shortcuts', not lexical_findings, lexical_findings)
visited = set()
def visit(mod):
    if mod in {'Std', 'Lean', 'Init'}: return
    if mod in visited: return
    visited.add(mod)
    for dep in imports[mod]: visit(dep)
for root in project['roots']: visit(root)
check('root_actual_closure_complete', visited == set(pins) and 'Agent1PeriodicZeroCycle' not in visited)

review = CONTRIB + '/review'
clean = review + '/clean-001'
results = obj(clean + '/results.json')
compiler = obj(clean + '/compiler.json')
check('recorded_compiler', compiler['sha256'] == '92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023' and '4.19.0' in compiler['version'] and '6caaee842e94' in compiler['version'])
check('exact_27_commands', [e['module'] for e in results] == [e['module'] for e in manifest] + ['ReviewAudit'])
for e in results:
    mod = e['module']
    expected = [compiler['path'], '--trust=0', '-j1', '-DElab.async=false']
    if mod != 'ReviewAudit': expected += ['-o', mod + '.olean']
    expected += [mod + '.lean']
    log = read(clean + '/' + mod + '.log')
    check('retained_command:' + mod, e['command'] == expected and e['exit_code'] == 0 and e['seconds'] >= 0)
    check('retained_log_hash:' + mod, sha(log) == e['log_sha256'])
    check('no_compile_error:' + mod, not re.search(r'\berror:|sorryAx|Lean\.ofReduceBool|CUSTOM_AXIOM|DISALLOWED_|MODULE_NOT_AUDITED', log.decode()))
log = read(clean + '/ReviewAudit.log').decode()
audit_src = read(clean + '/ReviewAudit.lean').decode()
selected = json.loads(re.search(r'let selected : List String := (\[[^\n]+\])', audit_src).group(1))
check('audit_selected_exact_closure', selected == [e['module'] for e in manifest])
rows = []
for kind, mod, name, axiomtext in re.findall(r'^(AUDIT_THEOREM|AUDIT_SAFE_DEFINITION|AUDIT_SAFE_OPAQUE) (\S+) (.+?) : \[([^\]]*)\]', log, re.M):
    axs = [x.strip() for x in axiomtext.split(',') if x.strip()]
    rows.append({'kind': kind, 'module': mod, 'name': name, 'axioms': axs})
check('raw_audit_records_all_parse', len(rows) == len(re.findall(r'^AUDIT_(?:THEOREM|SAFE_DEFINITION|SAFE_OPAQUE) ', log, re.M)))
check('raw_audit_unique_names', len({r['name'] for r in rows}) == len(rows))
check('raw_audit_no_forbidden_axioms', all(set(r['axioms']) <= ALLOWED and r['module'] in pins for r in rows))
theorems = [r for r in rows if r['kind'] == 'AUDIT_THEOREM']
safe = [r for r in rows if r['kind'] != 'AUDIT_THEOREM']
check('1462_theorem_raw_records', len(theorems) == 1462)
check('241_safe_definition_raw_records', len(safe) == 241)
check('all_26_origins_present', set(r['module'] for r in theorems) == set(pins))
check('theorem_union_exact', set(x for r in theorems for x in r['axioms']) == ALLOWED)
check('safe_definition_union_exact', set(x for r in safe for x in r['axioms']) == {'propext'})
check('no_unsafe_opaque_or_custom_axiom', not re.search(r'^UNSAFE_OPAQUE|^CUSTOM_AXIOM', log, re.M))
nonsafe = re.findall(r'^NONSAFE_DEFINITION (\S+) (.+)$', log, re.M)
unsafe_axioms = re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (.+)$', log, re.M)
cs = [(m, n) for m, n in nonsafe if re.search(r'\._cstage[12](?:\.|$)', n)]
rec = [(m, n) for m, n in nonsafe if n.endswith('._unsafe_rec')]
safe_names = {(r['module'], r['name']) for r in safe}
check('nonsafe_inventory', len(nonsafe) == 976 and len(cs) == 945 and len(rec) == 31 and len(cs) + len(rec) == len(nonsafe))
check('unsafe_rec_safe_bases_audited', all((m, n[:-len('._unsafe_rec')]) in safe_names for m, n in rec))
check('implementation_axiom_inventory', len(unsafe_axioms) == 14 and collections.Counter(m for m, n in unsafe_axioms) == {'LychrelDigitSums': 13, 'Agent1PeriodicZeroState': 1})
check('implementation_axioms_absent_from_logic', not ({n for m, n in unsafe_axioms} & {x for r in rows for x in r['axioms']}))
checks_in_src = re.findall(r'^#check (.+)$', audit_src, re.M)
check('111_named_types_requested', len(named) == 111 and checks_in_src == [n for m, n in named])
type_blocks = re.findall(r'^(Agent1\.[^\n]+(?:\n[ \t]+[^\n]+)*)', log, re.M)
check('111_named_types_printed', len(type_blocks) == 111 and [x.split()[0] for x in type_blocks] == checks_in_src)
for mod, name in named:
    module_log = read(clean + '/' + mod + '.log').decode()
    escaped = re.escape(name)
    ax = re.search("'" + escaped + "' depends on axioms: \\[([^\\]]*)\\]", module_log, re.S)
    empty = "'" + name + "' does not depend on any axioms" in module_log
    check('named_axioms:' + name, empty or (ax is not None and {s.strip() for s in ax.group(1).split(',') if s.strip()} <= ALLOWED))
    check('named_full_audit:' + name, any(r['name'] == name and r['module'] == mod for r in theorems))
(a.out / 'named-types.txt').write_text('\n\n'.join(type_blocks) + '\n')
check('driver_copies_identical', read(review + '/replay.py') == read(clean + '/replay.py'))
check('identity_copies_identical', read(review + '/final-source-identity.json') == read(clean + '/final-source-identity.json'))

def manifest_check(base, entries, label):
    for entry in entries:
        raw = read(base + '/' + entry['path'])
        check(label + ':' + entry['path'], len(raw) == entry['bytes'] and sha(raw) == entry['sha256'])
files = obj(review + '/FILES.json')
check('review_manifest_count', files['file_count'] == len(files['files']) == 91)
manifest_check(review, files['files'], 'review_manifest')
parent = CONTRIB + '/verification/parent-clean-001'
manifest_check(parent, obj(parent + '/PACKAGE-FILES.json'), 'parent_package_manifest')
original_parent_manifest = obj(parent + '/FILES.json')
historical_manifest = []
for path, pin in original_parent_manifest.items():
    raw = read(parent + '/' + path)
    historical_manifest.append({'path': path, 'matches': sha(raw) == pin['sha256'] and len(raw) == pin['bytes'], 'recorded': pin, 'actual': {'bytes': len(raw), 'sha256': sha(raw)}})
dump('parent-original-manifest-check.json', historical_manifest)
for receipt, field in [('review/final-review-receipt.json', 'files'), ('prefix-author/frozen-receipt.json', 'evidence_hashes')]:
    j = obj(CONTRIB + '/' + receipt)
    for path, h in j[field].items():
        check('receipt:' + receipt + ':' + path, sha(read(CONTRIB + '/' + receipt.rsplit('/', 1)[0] + '/' + path)) == h)
author_receipts = []
for sub, module in [('mass-author', 'Agent1PeriodicZeroInterfaceMass'), ('prefix-author', 'Agent1PeriodicZeroPrefix'), ('root-author', 'Agent1PeriodicZeroEscape')]:
    check('author_source_snapshot:' + module, read(CONTRIB + '/' + sub + '/attempt-001/' + module + '.lean').decode() == sources[module])
    f = 'receipt.json' if sub == 'mass-author' else 'result.json'
    j = obj(CONTRIB + '/' + sub + '/attempt-001/' + f)
    check('author_increment:' + module, j['exit_code'] == 0 and '--trust=0' in j['command'] and j['source_sha256'] == pins[module]['sha256'])
    author_receipts.append({'module': module, 'fresh_dependency_build': False, 'exit_code': j['exit_code'], 'command': j['command']})

summary = {'review_head': HEAD, 'stacked_base': BASE, 'original_mathematical_source': SOURCE,
    'status': 'PASS' if not failures else 'FAIL', 'fresh_lean_here': 'NOT_RUN',
    'fresh_lean_here_reason': 'Parent reports normal launch unavailable and escalation rejected; no retry or workaround attempted.',
    'evidence_executor': 'Agent #1 specialist /root/research_status, separate original execution in prior session; not this reviewer.',
    'retained_lean_commands': len(results), 'retained_lean_seconds': sum(x['seconds'] for x in results),
    'compiler_record': compiler, 'theorems': len(theorems), 'safe_definitions': len(safe),
    'named_types': len(type_blocks), 'source_modules': len(pins), 'source_forbidden_hits': lexical_findings,
    'theorems_by_module': dict(sorted(collections.Counter(x['module'] for x in theorems).items())),
    'safe_definitions_by_module': dict(sorted(collections.Counter(x['module'] for x in safe).items())),
    'nonsafe_definitions': len(nonsafe), 'cstage_helpers': len(cs), 'unsafe_rec_helpers': len(rec),
    'unsafe_implementation_axioms': unsafe_axioms, 'unsafe_opaques': 0,
    'author_increments': author_receipts, 'historical_parent_manifest_mismatches': [x for x in historical_manifest if not x['matches']],
    'checks': len(checks), 'failures': failures}
dump('audit-results.json', summary)
dump('checks.json', checks)
dump('source-recovery-map.json', {'repository': 'https://github.com/taco-jpg/p196-algorithm',
    'recovery': 'git show COMMIT:PATH > OUTPUT; verify bytes and SHA-256 using each entry.',
    'duplicates_not_republished': 'All source/evidence bytes already exist at the exact preserved Git commits; only this review and checks are new.',
    'entries': list(recovery.values())})
print(json.dumps(summary, indent=2, ensure_ascii=False))
sys.exit(0 if not failures else 1)
