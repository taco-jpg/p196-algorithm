#!/usr/bin/env python3
"""Read-only PR139 provenance review. Rechecks retained evidence; never runs Lean."""
from pathlib import Path
import ast, collections, hashlib, json, re, subprocess, sys

ROOT = Path(__file__).resolve().parent
REPO = ROOT.parent / 'repo'
SNAP = ROOT / 'snapshot'
OUT = ROOT / 'checks'
OUT.mkdir(exist_ok=True)
HEAD = '5d3b027df045eb017a8e37d3826b10105a587e9b'
BASE = '776f491e13287c3b2148d2dba73cd308590d459a'
MATH = 'fc17722becfd671e349aeae21501d0fd5867dfb0'
PREFIX = 'proofs/contributions/agent-1/periodic-zero-cycle-20261016'
CONTRIB = SNAP / PREFIX
REVIEW = CONTRIB / 'review'
CLEAN = REVIEW / 'clean-001'
sha = lambda b: hashlib.sha256(b).hexdigest()
blob = lambda b: hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
read = lambda p: json.loads(p.read_text())
def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)
def write(name, data):
    (OUT/name).write_text(json.dumps(data, indent=2, sort_keys=True)+'\n')
checks=[]
def check(label, value, detail=None):
    checks.append({'check':label,'pass':bool(value),'detail':detail})
def uncomment(text):
    # Lean nested comments and strings are skipped; preserve line breaks.
    out=[]; i=0; depth=0; quoted=False
    while i<len(text):
        a=text[i:i+2]
        if depth:
            if a=='/-': depth+=1;i+=2
            elif a=='-/': depth-=1;i+=2
            else:
                out.append('\n' if text[i]=='\n' else ' ');i+=1
        elif quoted:
            if text[i]=='\\':out.extend('  ');i+=2
            elif text[i]=='"':quoted=False;out.append(' ');i+=1
            else:out.append('\n' if text[i]=='\n' else ' ');i+=1
        elif a=='/-':depth=1;out.extend('  ');i+=2
        elif a=='--':
            j=text.find('\n',i);j=len(text) if j<0 else j
            out.extend(' '*(j-i));i=j
        elif text[i]=='"':quoted=True;out.append(' ');i+=1
        else:out.append(text[i]);i+=1
    return ''.join(out)

tree={}
for line in git('ls-tree','-r',HEAD).decode().splitlines():
    meta,path=line.split('\t',1);mode,kind,oid=meta.split()
    tree[path]=(oid,mode)
snapshot=[]
for p in sorted(SNAP.rglob('*')):
    if p.is_file():
        rel=p.relative_to(SNAP).as_posix();b=p.read_bytes()
        snapshot.append({'path':rel,'bytes':len(b),'sha256':sha(b),'git_blob':blob(b)})
        check('exact_snapshot:'+rel,rel in tree and blob(b)==tree[rel][0])
write('snapshot-recovery.json',{'commit':HEAD,'meaning':'Already Git-published exact duplicates; omitted from compact publication bundle.','recovery_command':'git show '+HEAD+':<path> > <destination>','files':snapshot})

diff=git('diff','--name-status',BASE,HEAD).decode()
(OUT/'true-contribution-name-status.txt').write_text(diff)
(OUT/'true-contribution.patch').write_bytes(git('diff','--no-ext-diff',BASE,HEAD))
changes=[]
for line in diff.splitlines():
    status,path=line.split('\t',1)
    changes.append({'status':status,'path':path,'git_blob':tree.get(path,(None,None))[0]})
write('true-contribution.json',{'head':HEAD,'stack_parent_pr129':BASE,'count':len(changes),'changes':changes})
registry_path='proofs/Agent1PeriodicZeroCycle.registry.json'
reg=read(SNAP/registry_path)
manifest=read(REVIEW/'final-source-identity.json')
modules=reg['projects']['agent1-periodic-zero-cycle']['modules']
sources=manifest['sources']
check('registry_sha256',sha((SNAP/registry_path).read_bytes())==manifest['registry_sha256'])
check('registry_source_set',set(modules)=={r['module'] for r in sources} and len(modules)==24)
check('registry_ROOT',reg['projects']['agent1-periodic-zero-cycle']['roots']==['Agent1PeriodicZeroCycle'])
source_rows=[]; public=[]; actual={}; seen=set(); forbidden=[]
for row in sources:
    m=row['module'];p=SNAP/row['path'];data=p.read_bytes();text=data.decode();code=uncomment(text)
    imports=re.findall(r'^\s*import\s+([^\n]+)',code,re.M)
    imports=[a for line in imports for a in line.split()]
    actual[m]=imports
    check('module_registry:'+m,modules[m]=={k:row[k] for k in ['path','sha256','git_blob','imports']})
    check('module_source:'+m,sha(data)==row['sha256'] and blob(data)==row['git_blob'])
    check('module_imports:'+m,imports==row['imports'])
    check('topological_order:'+m,all(x in seen or x in ['Std','Lean','Init'] for x in imports))
    seen.add(m)
    check('compiled_snapshot:'+m,(CLEAN/'compiled-sources'/f'{m}.lean').read_bytes()==data)
    check('mathematical_commit_source:'+m,git('rev-parse',f'{MATH}:{row["path"]}').decode().strip()==row['git_blob'])
    pat=r'\b(?:sorry|admit|sorryAx|native_decide|axiom|unsafe|partial|implemented_by|extern)\b|Lean\.ofReduceBool|\bofReduceBool\b|\btrustCompiler\b'
    stripped=re.sub(r'^\s*#print\s+axioms\s+[^\n]*','',code,flags=re.M)
    hits=[{'line':stripped.count('\n',0,q.start())+1,'token':q.group(0)} for q in re.finditer(pat,stripped)]
    forbidden.extend({'module':m,**h} for h in hits)
    if m.startswith('Agent1'):
        ns='Agent1.Periodic' if m.startswith('Agent1Periodic') else 'Agent1.RepeatedBlock'
        exports=[ns+'.'+n for n in re.findall(r'^theorem\s+(\w+)',code,re.M)]
        public.extend(exports)
        for n in exports:
            log=(CLEAN/f'{m}.log').read_text()
            check('source_public_axiom_print:'+n,bool(re.search(re.escape("'"+n+"'")+r' (?:depends on axioms:|does not depend on any axioms)',log)))
    else:exports=[]
    source_rows.append({'module':m,'path':row['path'],'sha256':sha(data),'git_blob':blob(data),'imports':imports,'public_theorems':exports,'code_forbidden_hits':hits})
closure=set()
def visit(m):
    if m in closure:return
    closure.add(m)
    for d in actual[m]:
        if d not in ['Std','Lean','Init']:visit(d)
visit('Agent1PeriodicZeroCycle')
check('full_actual_import_closure',closure==set(modules))
check('code_forbidden_scan',not forbidden,forbidden)
write('source-closure.json',{'sources':source_rows,'actual_root_closure':sorted(closure),'forbidden_hits':forbidden})

results=read(CLEAN/'results.json');verification=read(CLEAN/'verification.json')
compiler=read(CLEAN/'compiler.json')
check('historical_compiler',compiler['sha256']=='92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023' and '4.19.0' in compiler['version'] and '6caaee842e94' in compiler['version'])
check('historical_command_order',[r['module'] for r in results]==[r['module'] for r in sources]+['ReviewAudit'])
commands=[]
for r in results:
    m=r['module'];expected=[compiler['path'],'--trust=0','-j1','-DElab.async=false']
    if m!='ReviewAudit':expected+=['-o',m+'.olean']
    expected+=[m+'.lean']
    log=(CLEAN/f'{m}.log').read_bytes()
    check('historical_command:'+m,r['command']==expected and r['exit_code']==0 and sha(log)==r['log_sha256'])
    check('historical_log_no_error:'+m,not re.search(r'(^|\n).*\berror:|sorryAx|Lean\.ofReduceBool',log.decode()))
    commands.append({'module':m,'command':r['command'],'command_json_sha256':sha(json.dumps(r['command'],separators=(',',':')).encode()),'log_sha256':sha(log),'exit_code':r['exit_code']})
write('historical-command-checks.json',{'classification':'Revalidated original independent historical execution; not a new execution.','compiler':compiler,'fresh_lean_this_review':'NOT_RUN','commands':commands})
driver=(REVIEW/'replay.py').read_text();driver_copy=(CLEAN/'replay.py').read_text()
check('executed_driver_identical',driver==driver_copy)
archive=read(CLEAN/'source-archive-receipt.json')
check('executed_driver_sha256',sha(driver.encode())==archive['executed_driver_sha256'])
check('fresh_build_and_no_project_object_reuse', 'build.mkdir(parents=True, exist_ok=False)' in driver and 'evidence.mkdir(parents=True, exist_ok=False)' in driver and 'LEAN_PATH=str(build)' in driver and '.olean' not in driver.split('def run(')[0])
for row in sources:
    check('original_source_copy_only:'+row['module'],'(build / (entry[\'module\'] + \'.lean\')).write_bytes(data)' in driver)

tree_ast=ast.parse(driver)
audit_assign=next(n for n in tree_ast.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='audit' for t in n.targets))
audit_template=ast.literal_eval(audit_assign.value.func.value)
audit=audit_template.replace('SELECTED',', '.join(json.dumps(r['module']) for r in sources))
for n in public:audit+='\n#check '+n+'\n'
check('generated_audit_source',audit==(CLEAN/'ReviewAudit.lean').read_text())
log=(CLEAN/'ReviewAudit.log').read_text()
allowed={'propext','Classical.choice','Quot.sound'}
def axrows(prefix):
    return [{'module':m,'name':n,'axioms':[a.strip() for a in axs.split(',') if a.strip()]} for m,n,axs in re.findall(r'^'+prefix+r' (\S+) (\S+) : \[([^\]]*)\]',log,re.M)]
thms=axrows('AUDIT_THEOREM');defs=axrows('AUDIT_SAFE_DEFINITION')+axrows('AUDIT_SAFE_OPAQUE')
check('all_1446_theorem_rows',len(thms)==1446 and len({r['name'] for r in thms})==1446)
check('all_241_safe_definition_rows',len(defs)==241 and len({r['name'] for r in defs})==241)
check('all_rows_standard_axioms',all(set(r['axioms'])<=allowed for r in thms+defs))
check('theorem_axiom_union',set(a for r in thms for a in r['axioms'])==allowed)
check('safe_definition_axiom_union',set(a for r in defs for a in r['axioms'])=={'propext'})
check('all_module_origins_covered',set(r['module'] for r in thms)==set(modules))
check('no_audit_error_rows',not re.search(r'^(?:CUSTOM_AXIOM|DISALLOWED_|MODULE_NOT_AUDITED)',log,re.M))
checks_in_audit=re.findall(r'^#check (\S+)$',audit,re.M)
type_names=re.findall(r'^(Agent1\.\S+) \(',log,re.M)
check('all_108_named_types',len(public)==108 and set(public)==set(type_names) and len(type_names)==108 and checks_in_audit==public and verification['audited_named_exports']==public)
thm_map={r['name']:r for r in thms}
check('named_types_all_are_audited_theorems',set(public)<=set(thm_map))
nonsafe=re.findall(r'^NONSAFE_DEFINITION (\S+) (\S+)$',log,re.M)
unsafe_ax=re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$',log,re.M)
unsafe_opaque=re.findall(r'^UNSAFE_OPAQUE (\S+) (\S+)$',log,re.M)
cstage=[r for r in nonsafe if re.search(r'\._cstage[12](?:\.|$)',r[1])]
urec=[r for r in nonsafe if r[1].endswith('._unsafe_rec')]
safe_names={(r['module'],r['name']) for r in defs}
check('implementation_inventory_counts',len(nonsafe)==976 and len(cstage)==945 and len(urec)==31 and len(unsafe_ax)==14 and not unsafe_opaque)
check('unsafe_rec_safe_bases',all((m,n[:-len('._unsafe_rec')]) in safe_names for m,n in urec))
check('unsafe_axiom_not_proof_dependency',not ({n for _,n in unsafe_ax}&set(a for r in thms+defs for a in r['axioms'])))
inv=read(CLEAN/'implementation-inventory.json')
check('retained_inventory_agreement',inv['nonsafe_count']==len(nonsafe) and inv['unsafe_axioms']==[list(x) for x in unsafe_ax] and inv['unsafe_opaques']==[])
for key,value in [('theorems_audited',1446),('safe_definitions_audited',241),('trust',0),('source_modules',24)]:check('retained_summary:'+key,verification[key]==value)
write('historical-audit-recheck.json',{'classification':'Parsed and validated every retained original audit row, not freshly kernel-checked.','theorem_rows':len(thms),'safe_definition_rows':len(defs),'named_public_types':len(type_names),'source_origin_counts':dict(collections.Counter(r['module'] for r in thms)),'theorem_axiom_union':sorted(allowed),'safe_definition_axiom_union':['propext'],'nonsafe_count':len(nonsafe),'cstage_count':len(cstage),'unsafe_rec_count':len(urec),'unsafe_implementation_axioms':[list(x) for x in unsafe_ax],'unsafe_opaques':unsafe_opaque,'named_type_axioms':[{**thm_map[n]} for n in public]})

inventories=[]
for invpath in [REVIEW/'FILES.json',CONTRIB/'verification/parent-clean-001/FILES.json',CONTRIB/'zero-period-author/FILES.json']:
    obj=read(invpath);rows=obj if isinstance(obj,list) else obj['files'];base=invpath.parent
    bad=[];listed=set()
    for row in rows:
        rel=row['path'];listed.add(rel);p=base/rel
        if not p.exists():bad.append({'path':rel,'problem':'missing'})
        elif sha(p.read_bytes())!=row['sha256'] or len(p.read_bytes())!=row['bytes']:bad.append({'path':rel,'problem':'hash_or_size_mismatch','actual_sha256':sha(p.read_bytes()),'actual_bytes':len(p.read_bytes())})
    actual_files={p.relative_to(base).as_posix() for p in base.rglob('*') if p.is_file() and p!=invpath}
    unlisted=sorted(actual_files-listed);extra=sorted(listed-actual_files)
    inventories.append({'manifest':invpath.relative_to(SNAP).as_posix(),'rows':len(rows),'bad':bad,'unlisted':unlisted,'extra':extra})
    check('inventory_bytes:'+invpath.relative_to(CONTRIB).as_posix(),not bad,bad)
    check('inventory_coverage:'+invpath.relative_to(CONTRIB).as_posix(),not unlisted and not extra,{'unlisted':unlisted,'extra':extra})
receipt=read(REVIEW/'final-review-receipt.json')
receipt_bad=[]
for rel,h in receipt['files'].items():
    if sha((REVIEW/rel).read_bytes())!=h:receipt_bad.append(rel)
check('final_review_receipt_hashes',not receipt_bad,receipt_bad)
write('inventory-recheck.json',{'inventories':inventories,'final_receipt_hash_mismatches':receipt_bad,'historical_initial_self_reference_manifest':'Retained as explicitly superseded packaging evidence; not asserted valid.'})
write('checks.json',{'head':HEAD,'fresh_lean_this_review':'NOT_RUN','checks':checks,'check_count':len(checks),'failures':[c for c in checks if not c['pass']]})
summary={'head':HEAD,'status':'PASS' if all(c['pass'] for c in checks) else 'FINDINGS','check_count':len(checks),'failed_checks':[c for c in checks if not c['pass']],'fresh_lean_this_review':'NOT_RUN','snapshot_count':len(snapshot),'true_changed_paths':len(changes),'source_modules':len(modules),'historical_commands':len(results),'historical_theorem_rows':len(thms),'historical_safe_def_rows':len(defs),'historical_named_types':len(type_names)}
write('summary.json',summary)
print(json.dumps(summary,indent=2))
sys.exit(0 if summary['status']=='PASS' else 1)
