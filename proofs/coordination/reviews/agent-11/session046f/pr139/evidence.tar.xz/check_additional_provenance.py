#!/usr/bin/env python3
"""Check supplemental author/parent receipts and classify retained hash references."""
from pathlib import Path
import collections, hashlib, json, re, sys
ROOT=Path(__file__).resolve().parent
SNAP=ROOT/'snapshot'
C=SNAP/'proofs/contributions/agent-1/periodic-zero-cycle-20261016'
OUT=ROOT/'checks'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
read=lambda p:json.loads(p.read_text())
checks=[]
def check(name,passed,detail=None):checks.append({'check':name,'pass':bool(passed),'detail':detail})
hashes=collections.defaultdict(list)
for p in SNAP.rglob('*'):
    if p.is_file():hashes[sha(p)].append(p.relative_to(SNAP).as_posix())
refs=[]
def walk(x,path,source):
    if isinstance(x,dict):
        for k,v in x.items():walk(v,path+'/'+k,source)
    elif isinstance(x,list):
        for i,v in enumerate(x):walk(v,path+'/'+str(i),source)
    elif isinstance(x,str) and re.fullmatch('[0-9a-f]{64}',x):
        refs.append({'receipt':source,'json_path':path,'sha256':x,'matching_retained_paths':hashes[x]})
for p in C.rglob('*.json'):walk(read(p),'',p.relative_to(SNAP).as_posix())
missing={}
for r in refs:
    if r['matching_retained_paths']:continue
    path=r['json_path']
    if 'object_sha256' in path or path.endswith('/.olean'):
        kind='Reproducible compiled object; excluded by publication policy; author increment reuse only.'
    elif '/compiler/files/' in path or r['sha256']=='92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023':
        kind='Official compiler/runtime infrastructure; historical identity retained; not freshly executed.'
    else:kind='UNEXPLAINED'
    missing.setdefault(r['sha256'],{'classification':kind,'references':[]})['references'].append({'receipt':r['receipt'],'json_path':path})
check('all_unretained_hashes_are_infrastructure',all(x['classification']!='UNEXPLAINED' for x in missing.values()))
parent=C/'verification/parent-clean-001'
canonical=read(parent/'canonical-original-FILES.json')
for rel,row in canonical.items():
    p=parent/rel
    check('original_parent_inventory:'+rel,p.exists() and sha(p)==row['sha256'] and p.stat().st_size==row['bytes'])
initial=read(parent/'packaging-initial-self-reference.json')
selfrow=next(r for r in initial if r['path']=='FILES.json')
check('original_self_reference_recovery',sha(parent/'canonical-original-FILES.json')==selfrow['sha256'] and (parent/'canonical-original-FILES.json').stat().st_size==selfrow['bytes'])
check('corrected_current_manifest_omits_self',all(r['path']!='FILES.json' for r in read(parent/'FILES.json')))
pv=read(parent/'verification.json')['projects']['agent1-periodic-zero-cycle']
for r in pv['commands']:
    check('separate_parent_command_log:'+r['label'],r['exit_code']==0 and sha(parent/r['log'])==r['log_sha256'])
check('parent_commands_not_mislabelled_strict',all('--trust=0' not in r['argv'] for r in pv['commands']))
for name,row in pv['sources'].items():
    check('parent_source:'+name,sha(parent/'agent1-periodic-zero-cycle/source'/f'{name}.lean')==row['sha256']==row['build_sha256'])
for rel in ['state-author/frozen-receipt.json','zero-mass-author/frozen-receipt.json']:
    p=C/rel;obj=read(p)
    for section in ['evidence_hashes','files']:
        if isinstance(obj.get(section),dict):
            for target,h in obj[section].items():
                if isinstance(h,str) and re.fullmatch('[0-9a-f]{64}',h):
                    q=p.parent/target
                    check('author_receipt:'+rel+':'+target,q.exists() and sha(q)==h)
for label in ['001','002']:
    p=C/'review'/('finite-controls-attempt-'+label)
    obj=read(p/('failure.json' if label=='001' else 'run.json'))
    check('original_diagnostic_script:'+label,sha(p/'finite-controls.py')==obj['script_sha256'])
check('passing_diagnostic_copy_unchanged',sha(C/'review/finite-controls.py')==sha(C/'review/finite-controls-attempt-002/finite-controls.py'))
check('fresh_diagnostic_output_matches_original',(ROOT/'diagnostic-attempt-001/stdout.log').read_bytes()==(C/'review/finite-controls-attempt-002/stdout.log').read_bytes())
reg=read(SNAP/'proofs/Agent1PeriodicZeroCycle.registry.json')['projects']['agent1-periodic-zero-cycle']['modules']
copies=[]
for p in C.rglob('*.lean'):
    if p.stem in reg:
        copies.append(p.relative_to(SNAP).as_posix())
        check('retained_canonical_module_copy:'+p.relative_to(C).as_posix(),sha(p)==reg[p.stem]['sha256'])
out={'status':'PASS' if all(x['pass'] for x in checks) else 'FINDINGS','fresh_lean_this_review':'NOT_RUN','sha256_reference_count':len(refs),'unretained_unique_hashes':len(missing),'unretained_hash_classifications':missing,'canonical_module_copies':len(copies),'checks':checks,'failed_checks':[x for x in checks if not x['pass']]}
(OUT/'additional-provenance.json').write_text(json.dumps(out,indent=2,sort_keys=True)+'\n')
print(json.dumps({k:v for k,v in out.items() if k not in ['checks','unretained_hash_classifications']},indent=2))
sys.exit(0 if out['status']=='PASS' else 1)
