#!/usr/bin/env python3
"""Package new evidence losslessly; map previously published input duplicates."""
from pathlib import Path
import gzip,hashlib,json,shutil
ROOT=Path(__file__).resolve().parent
OUT=ROOT/'publish-evidence'
OUT.mkdir(exist_ok=False)
sha=lambda b:hashlib.sha256(b).hexdigest()
inventory=[]
for p in sorted(ROOT.rglob('*')):
    if not p.is_file() or OUT in p.parents:continue
    rel=p.relative_to(ROOT).as_posix()
    if rel=='checks/true-contribution.patch':continue
    raw=p.read_bytes()
    compressed=len(raw)>20000 and p.suffix in ['.json','.txt']
    name=rel+'.gz' if compressed else rel
    stored=gzip.compress(raw,mtime=0) if compressed else raw
    dest=OUT/name;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(stored)
    assert (gzip.decompress(dest.read_bytes()) if compressed else dest.read_bytes())==raw
    inventory.append({'original_path':rel,'original_bytes':len(raw),'original_sha256':sha(raw),'stored_path':name,'stored_bytes':len(stored),'stored_sha256':sha(stored),'compression':'gzip' if compressed else 'none','recovery_command':f'gzip -dc {name} > {rel}' if compressed else f'cp {name} <destination>'})
patch=ROOT/'checks/true-contribution.patch';raw=patch.read_bytes()
duplicates={'classification':'Exact already-Git-published input duplicates, not new research outputs.','snapshot_mapping':'checks/snapshot-recovery.json.gz','snapshot_recovery':'Decompress mapping, then git show <commit>:<path> > <destination>; verify every original byte count/SHA-256 and Git blob.','derived_diff':{'original_path':'checks/true-contribution.patch','bytes':len(raw),'sha256':sha(raw),'recovery_command':'git diff --no-ext-diff 776f491e13287c3b2148d2dba73cd308590d459a 5d3b027df045eb017a8e37d3826b10105a587e9b > checks/true-contribution.patch'}}
data=(json.dumps(duplicates,indent=2)+'\n').encode();(OUT/'DUPLICATE_RECOVERY.json').write_bytes(data)
inventory.append({'original_path':'DUPLICATE_RECOVERY.json','original_bytes':len(data),'original_sha256':sha(data),'stored_path':'DUPLICATE_RECOVERY.json','stored_bytes':len(data),'stored_sha256':sha(data),'compression':'none','recovery_command':'cp DUPLICATE_RECOVERY.json <destination>'})
record={'scope':'Complete new PR139 review evidence; INVENTORY.json intentionally excludes itself. All gzip items are byte-for-byte recoverable.','reviewed_head':'5d3b027df045eb017a8e37d3826b10105a587e9b','fresh_lean_this_review':'NOT_RUN','file_count_excluding_this_inventory':len(inventory),'stored_bytes_excluding_this_inventory':sum(r['stored_bytes'] for r in inventory),'files':inventory}
(OUT/'INVENTORY.json').write_text(json.dumps(record,indent=2)+'\n')
actual={p.relative_to(OUT).as_posix() for p in OUT.rglob('*') if p.is_file()}
assert actual=={r['stored_path'] for r in inventory}|{'INVENTORY.json'}
print(json.dumps({'status':'PASS','file_count_including_inventory':len(actual),'stored_bytes':sum(p.stat().st_size for p in OUT.rglob('*') if p.is_file()),'inventory_sha256':sha((OUT/'INVENTORY.json').read_bytes()),'new_files_preserved':True},indent=2))
