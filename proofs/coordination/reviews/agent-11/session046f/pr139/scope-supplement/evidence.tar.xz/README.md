# PR139 supplemental scope-check preservation

This directory preserves the already executed 109-check scope review and its complete English addendum. It was assembled afterward in the root-authorized memory filesystem because the workspace filesystem had reported ENOSPC. No successful check was rerun during this preservation step. No Lean command was run, and the original report was not modified.

`scope_checker.py` is the exact Python heredoc body recovered from the executed tool-call input. `executed-tool-call.json` preserves that command and its working directory. It is not a newly executed file invocation.

`combined-output.observed.log` transcribes the complete, untruncated `exec_command.output` text returned for that command, including its final newline. `tool-result.observed.json` preserves the returned result fields. The original tool returned a single combined output channel, not separately captured stdout and stderr. Therefore separately byte-authenticated raw stdout and raw stderr cannot be recovered; no empty stderr file has been invented. The recovered combined output contains the JSON printed by the script and no visible stderr diagnostic. The actual tool-reported exit code was 0, and the JSON reports 109 checks with no failures.

The individual in-memory `checks` array was not printed or saved by the original script. It is unavailable as an original execution artifact. The complete executed script and its emitted aggregate result are preserved; no retroactive per-check execution log has been manufactured.

`SOURCE_RECOVERY.json` is derived solely from the 16-file inventory in the recovered output. It records the exact Git commit, path, byte count, SHA-256, Git blob, and recovery command for each already-published original file. It does not claim a new source retrieval or a new check run. `SCOPE_ADDENDUM.md` is the full English addendum already delivered to root.

`PRESERVATION_RECEIPT.json` distinguishes actual execution metadata from this later transcript-preservation step. `FILES.json` inventories this directory and excludes itself to avoid self-reference.
