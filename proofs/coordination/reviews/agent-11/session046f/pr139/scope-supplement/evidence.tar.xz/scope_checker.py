from pathlib import Path
import subprocess,json,hashlib,re,collections
repo=Path('/workspace/scratch/046f9285a650/repo');review=Path('/workspace/scratch/046f9285a650/review139');H='5d3b027df045eb017a8e37d3826b10105a587e9b';A='c74c9d1ca1fef5463738abac348a5d12eaab4a01';B='776f491e13287c3b2148d2dba73cd308590d459a';P='proofs/contributions/agent-1/periodic-realizability-20261016/';author=P+'author/'
def git(*args):return subprocess.check_output(['git',*args],cwd=repo)
def raw(p,c=H):return git('show',c+':'+p)
def obj(p):return json.loads(raw(p))
def sha(b):return hashlib.sha256(b).hexdigest()
checks=[]
def ck(name,value):checks.append({'check':name,'pass':bool(value)})
allp=set(git('diff','--name-only',A,H).decode().splitlines());later=set(git('diff','--name-only',B,H).decode().splitlines());foundation=set(git('diff','--name-only',A,B).decode().splitlines());prior={r['path']:r for r in json.loads((review/'checks/snapshot-recovery.json').read_text())['files']};extra=allp-later
ck('commit776_parent_is_c74',git('rev-parse',B+'^').decode().strip()==A)
ck('exact_path_counts',len(allp)==254 and len(later)==221 and len(foundation)==34 and len(extra)==33)
ck('single_overlap_readme',foundation&later=={'proofs/contributions/agent-1/periodic-zero-cycle-20261016/README.md'})
foundationreg=obj('proofs/Agent1PeriodicZeroFoundation.registry.json')['projects']['agent1-periodic-zero-foundation'];fullreg=obj('proofs/Agent1PeriodicZeroCycle.registry.json')['projects']['agent1-periodic-zero-cycle'];mods=foundationreg['modules']
ck('foundation19_registry_is_exact_subset',len(mods)==19 and all(fullreg['modules'][k]==v for k,v in mods.items()))
visited=set()
def visit(n):
 if n in visited:return
 visited.add(n)
 for d in mods[n]['imports']:
  if d not in {'Std','Lean','Init'}:visit(d)
for n in foundationreg['roots']:visit(n)
ck('foundation_actual_root_closure',visited==set(mods))
for n,v in mods.items():
 b=raw(v['path']);ck('foundation_source_hash:'+n,sha(b)==v['sha256']);ck('foundation_source_blob:'+n,git('rev-parse',H+':'+v['path']).decode().strip()==v['git_blob']);ck('foundation_imports:'+n,re.findall(r'^import\s+(\S+)',b.decode(),re.M)==v['imports'])
paths=git('ls-tree','-r','--name-only',H,'--',P).decode().splitlines();inventory=[]
for p in paths:
 b=raw(p);inventory.append({'path':p,'bytes':len(b),'sha256':sha(b),'git_blob':git('rev-parse',H+':'+p).decode().strip()});ck('author_path_unchanged_776_to_H:'+p,raw(p,B)==b)
ck('exact_16_previous_path_omissions',len(paths)==16 and set(paths)==(extra-set(prior)))
frozen=obj(author+'frozen-receipt.json')
for p,h in frozen['evidence_hashes'].items():ck('author_frozen_evidence:'+p,sha(raw(author+p))==h)
canonical=raw('proofs/Agent1PeriodicRealizability.lean')
ck('accepted_attempt002_equals_final_canonical',raw(author+'attempt-002/Agent1PeriodicRealizability.lean')==canonical)
ck('failed_attempt001_different_from_accepted',raw(author+'attempt-001/Agent1PeriodicRealizability.lean')!=canonical)
for number,expected_exit in [('001',1),('002',0)]:
 result=obj(author+'attempt-'+number+'/result.json');code=raw(author+'attempt-'+number+'/Agent1PeriodicRealizability.lean');log=raw(author+'attempt-'+number+'/build.log').decode();cmd=result['command'];ck('attempt'+number+'_source_receipt',sha(code)==result['source_sha256']);ck('attempt'+number+'_strict_command_exit',cmd==['/workspace/p196-tools/lean-4.19.0-linux/bin/lean','--trust=0','-j1','-DElab.async=false','-o','Agent1PeriodicRealizability.olean','Agent1PeriodicRealizability.lean'] and result['exit_code']==expected_exit);ck('attempt'+number+'_correct_failure_classification',('sorryAx' in log and 'error:' in log) if expected_exit else ('sorryAx' not in log and 'error:' not in log))
audit_result=obj(author+'audit-001/result.json');audit=raw(author+'audit-001/RealizabilityAudit.lean');alog=raw(author+'audit-001/build.log').decode();ck('author_audit_source_hash',sha(audit)==audit_result['audit_source_sha256']);ck('author_audit_strict_success',audit_result['exit_code']==0 and audit_result['command']==['/workspace/p196-tools/lean-4.19.0-linux/bin/lean','--trust=0','-j1','-DElab.async=false','RealizabilityAudit.lean']);arows=re.findall(r'^AUDIT_SAFE_CONSTANT (\S+) theorem=(\w+) : \[([^\]]*)\]',alog,re.M);ck('author5_audit_rows',len(arows)==5 and all(t=='true' and {a.strip() for a in axs.split(',')}=={'propext','Quot.sound'} for _,t,axs in arows))
reused=obj(author+'reused-dependencies.json')['modules'];ck('17_reused_dependencies',len(reused)==17 and all(m['source_sha256']==mods[m['module']]['sha256'] and m['git_blob']==mods[m['module']]['git_blob'] for m in reused))
compiler=obj(author+'compiler.json');ck('historical_compiler_identity',compiler['sha256']=='92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023' and '4.19.0' in compiler['version'])
prior_audit=json.loads((review/'checks/historical-audit-recheck.json').read_text());names={x['name'] for x in prior_audit['named_type_axioms']};source=json.loads((review/'checks/source-closure.json').read_text())['sources'];covered=[]
for m in ['Agent1PeriodicRealizability','Agent1PeriodicZeroPeriod']:
 row=next(x for x in source if x['module']==m);ck('already_audited_source:'+m,row['sha256']==mods[m]['sha256'] and not row['code_forbidden_hits']);ck('already_audited_named_types:'+m,set(row['public_theorems'])<=names);covered.append({'module':m,'sha256':row['sha256'],'public_theorems':row['public_theorems'],'all_module_theorem_rows':prior_audit['source_origin_counts'][m]})
record={'status':'PASS' if all(x['pass'] for x in checks) else 'FAIL','head':H,'actual_pr129_head_supplied_by_root':A,'foundation_checkpoint_not_pr129_head':B,'actual_pr139_paths':len(allp),'actual_pr139_new_modules':7,'actual_pr139_new_public_theorems':30,'foundation_step_paths':len(foundation),'additional_distinct_paths_vs_old221':len(extra),'prior_extra_path_coverage':len(extra&set(prior)),'newly_reviewed_author_paths':len(paths),'check_count':len(checks),'failed_checks':[x for x in checks if not x['pass']],'fresh_lean_this_review':'NOT_RUN','historical_failed_author_attempt001_preserved':True,'covered_foundation_modules':covered,'foundation_registry_sha256':sha(raw('proofs/Agent1PeriodicZeroFoundation.registry.json')),'new_author_inventory':inventory}
print(json.dumps(record,indent=2))
