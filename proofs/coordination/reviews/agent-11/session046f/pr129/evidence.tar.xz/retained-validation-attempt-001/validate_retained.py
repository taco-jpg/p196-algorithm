#!/usr/bin/env python3
"""Read-only PR129 Git/source/log validation. Does not invoke Lean."""
import argparse, collections, hashlib, json, pathlib, re, subprocess

p=argparse.ArgumentParser()
p.add_argument('--repo',type=pathlib.Path,required=True)
p.add_argument('--root',type=pathlib.Path,required=True)
p.add_argument('--output',type=pathlib.Path,required=True)
a=p.parse_args()
H='c74c9d1ca1fef5463738abac348a5d12eaab4a01'
M='1ee9123344dbe17e9bda224ff8af5b1cbb2b64e4'
S='c75036b527dc4faa98ec1f1de5d85338749b9c96'
V='ae4e1f09a0bb75f1fa9a0eebabcefd0c362fc72a'
sha=lambda b:hashlib.sha256(b).hexdigest()
def git(*args): return subprocess.check_output(['git',*args],cwd=a.repo)
def blob(commit,path): return git('show',commit+':'+path)
def load(path): return json.loads((a.root/path).read_text())
checks=[]
def check(name,ok,detail=None):
    checks.append({'name':name,'pass':bool(ok),'detail':detail})

reg=load('proofs/Agent1PeriodicSafety.registry.json')
mods=reg['projects']['agent1-periodic-safety']['modules']
base='proofs/contributions/agent-1/periodic-safety-20261016/'
sources=load(base+'review/clean-001/sources.json')
results=load(base+'review/clean-001/results.json')
report=load(base+'review/clean-001/verification.json')
audit=(a.root/base/'review/clean-001/ReviewAudit.log').read_text()
audit_src=(a.root/base/'review/clean-001/ReviewAudit.lean').read_text()
mb=git('merge-base',M,H).decode().strip()
diff=[line.split('\t') for line in git('diff','--name-status',mb,H).decode().splitlines()]
delta=[line.split('\t') for line in git('diff','--name-status',V,H).decode().splitlines()]
check('merge-base',mb=='95a17ceeaba51b7d2c14645401df5159a3d483d1',mb)
check('all full-diff changes are additive',all(x[0]=='A' for x in diff),len(diff))
check('all PR129-only changes are additive',all(x[0]=='A' for x in delta),len(delta))
check('registry has complete 21-module closure',len(mods)==21 and all(i=='Std' or i in mods for e in mods.values() for i in e['imports']))
check('review manifest equals registry',sources==[{'module':n,**v} for n,v in mods.items()])
source_rows=[]
new_public=[]
all_agent1_public=[]

def strip_comments(text):
    # Nested Lean block comments and line comments; retain strings (no relevant
    # executable keyword strings occur in the pinned mathematical sources).
    out=[];i=0;depth=0
    while i<len(text):
        if text.startswith('/-',i): depth+=1;i+=2;continue
        if depth and text.startswith('-/',i): depth-=1;i+=2;continue
        if depth: i+=1;continue
        if text.startswith('--',i):
            j=text.find('\n',i);i=len(text) if j<0 else j;continue
        out.append(text[i]);i+=1
    return ''.join(out)

for name,e in mods.items():
    data=blob(H,e['path']);txt=data.decode();code=strip_comments(txt)
    check(name+' pinned source',sha(data)==e['sha256'] and git('rev-parse',H+':'+e['path']).decode().strip()==e['git_blob'])
    check(name+' source snapshot identity',(a.root/e['path']).read_bytes()==data and blob(S,e['path'])==data)
    parsed_imports=re.findall(r'^import\s+(\S+)',code,re.M)
    check(name+' imports',parsed_imports==e['imports'],parsed_imports)
    forbidden=re.findall(r'\b(?:sorry|admit|sorryAx|native_decide|axiom|unsafe|extern)\b|Lean\.ofReduceBool|implemented_by',code)
    check(name+' source has no forbidden proof mechanism',not forbidden,forbidden)
    snap=a.root/base/'parent/clean-001/agent1-periodic-safety/source'/f'{name}.lean'
    check(name+' canonical verifier copied exact source',snap.read_bytes()==data)
    if name.startswith('Agent1'):
        check(name+' independent review copied exact source',(a.root/base/'review/clean-001'/f'{name}.lean').read_bytes()==data)
        ns='Agent1.Periodic.SafetyBoundary' if name=='Agent1PeriodicSafetyBoundary' else 'Agent1.Periodic' if name.startswith('Agent1Periodic') else 'Agent1.RepeatedBlock'
        publics=[ns+'.'+t for t in re.findall(r'^theorem\s+(\w+)',code,re.M)]
        all_agent1_public+=publics
        if name.startswith('Agent1PeriodicSafety'):new_public+=publics
        modlog=(a.root/base/'review/clean-001'/f'{name}.log').read_text()
        for t in publics:
            check(t+' type and axiom output',('#check '+t+'\n') in audit_src and (t+' ') in audit and (("'"+t+"' depends on axioms:") in modlog or ("'"+t+"' does not depend on any axioms") in modlog))
    proc=subprocess.run(['git','cat-file','-e',M+':'+e['path']],cwd=a.repo,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
    main_status='absent' if proc.returncode else ('identical' if blob(M,e['path'])==data else 'different')
    if not name.startswith('Agent1PeriodicSafety'):
        check(name+' inherited from validity head unchanged',blob(V,e['path'])==data)
    source_rows.append({'module':name,**e,'main1ee912_status':main_status})

check('exact new public theorem count',len(new_public)==16,new_public)
check('all 94 named Agent1 exports included',len(all_agent1_public)==94 and report['audited_named_exports']==all_agent1_public)
check('22 independent commands in exact order',[r['module'] for r in results]==list(mods)+['ReviewAudit'])
for r in results:
    log=(a.root/base/'review/clean-001'/(r['module']+'.log')).read_bytes()
    expected=[report['compiler']['path'],'--trust=0','-j1','-DElab.async=false']
    if r['module']!='ReviewAudit':expected+=['-o',r['module']+'.olean']
    expected+=[r['module']+'.lean']
    check(r['module']+' original complete log/command/exit',r['command']==expected and r['exit_code']==0 and sha(log)==r['log_sha256'] and not re.search(rb'\berror:|sorryAx|Lean\.ofReduceBool',log))

allowed={'propext','Classical.choice','Quot.sound'}
theorems=re.findall(r'^AUDIT_THEOREM (\S+) (\S+) : \[([^\]]*)\]$',audit,re.M)
axioms=set()
for mod,name,axs in theorems:
    al=set(filter(None,axs.split(', ')));axioms|=al
    check('axioms '+name,mod in mods and al<=allowed,sorted(al))
check('complete original theorem audit',len(theorems)==1396 and len({n for _,n,_ in theorems})==1396 and {m for m,_,_ in theorems}==set(mods) and axioms==allowed)
check('original audit source selects all modules and rejects nonstandard theorem axioms',all('"'+m+'"' in audit_src for m in mods) and 'Lean.collectAxioms name' in audit_src and 'DISALLOWED_AXIOMS' in audit_src and 'CUSTOM_AXIOM' in audit_src)
check('safePeriodic original axiom output',"'Agent1.Periodic.safePeriodic' does not depend on any axioms" in audit)
check('original audit summary agrees',report['status']=='PASS' and report['source_modules']==21 and report['trust']==0 and report['theorems_audited']==1396 and set(report['axiom_union'])==axioms)

parent=load(base+'parent/clean-001/verification.json');project=parent['projects']['agent1-periodic-safety']
check('canonical historical verifier status',parent['status']=='PASS' and project['status']=='PASS' and parent['source_tree_clean'] is False)
for r in project['commands']:
    log=(a.root/base/'parent/clean-001'/r['log']).read_bytes()
    check('canonical '+r['label']+' log/exit',r['exit_code']==0 and sha(log)==r['log_sha256'])
check('canonical 21-module source identities',set(project['sources'])==set(mods) and all(project['sources'][n]['sha256']==e['sha256']==project['sources'][n]['build_sha256'] and project['sources'][n]['adapter'] is None for n,e in mods.items()))

manifest_rows=[]
for family in ['periodic-block-strip-20261016','periodic-validity-20261016','periodic-safety-20261016']:
    b='proofs/contributions/agent-1/'+family+'/'
    ev=load(b+'EVIDENCE.json');entries=ev['files']
    for path,e in entries.items():
        d=(a.root/path).read_bytes()
        check('evidence manifest '+path,len(d)==e['bytes'] and sha(d)==e['sha256'])
    retained={str(q.relative_to(a.root)) for q in (a.root/b).rglob('*') if q.is_file()}
    uncovered=sorted(retained-set(entries)-{b+'EVIDENCE.json'})
    check(family+' manifest coverage',not uncovered,uncovered)
    fl=load(b+'parent/clean-001/FILES.json')
    for path,e in fl.items():
        d=(a.root/b/'parent/clean-001'/path).read_bytes()
        check('parent file manifest '+b+path,len(d)==e['bytes'] and sha(d)==e['sha256'])
    manifest_rows.append({'family':family,'evidence_files':len(entries),'parent_files':len(fl),'uncovered':uncovered})

failures=[]
for path in (a.root/base).rglob('*.json'):
    obj=json.loads(path.read_text())
    if isinstance(obj,dict) and isinstance(obj.get('exit_code'),int) and obj['exit_code']!=0:
        failures.append({'path':str(path.relative_to(a.root)),'exit_code':obj['exit_code'],'source_sha256':obj.get('source_sha256'),'command':obj.get('command')})
check('substantive failed safety attempts retained',len(failures)>=5,failures)
classification=load(base+'review/clean-001/postcheck-001-failed-classification.json')
check('original failed classification retained',bool(classification),classification.get('status'))

# Original copies need not be republished: exact Git object + byte identity
# and recovery commands make every inspected artifact recoverable.
recover=[]
for path in sorted(a.root.rglob('*')):
    if path.is_file():
        rel=str(path.relative_to(a.root));d=path.read_bytes()
        check('Git duplicate identity '+rel,d==blob(H,rel))
        recover.append({'local_path':str(path),'repository_path':rel,'commit':H,'bytes':len(d),'sha256':sha(d),'git_blob':git('rev-parse',H+':'+rel).decode().strip(),'recovery_command':'git show '+H+':'+rel+' > RECOVERED_FILE','publication':'already-published exact Git duplicate'})

out={'status':'PASS' if all(c['pass'] for c in checks) else 'FAIL','reviewer':'Agent #11 integration reviewer /root/review129; new Python/source evidence only','head':H,'mathematical_source':S,'main_reference':M,'merge_base':mb,'fresh_lean_execution':'NOT_RUN: standard Lean application launch unavailable; escalation already auto-rejected; neither retried nor bypassed','historical_executor':'Agent #1 research_status and original parent verifier; not this reviewer','full_diff_files':len(diff),'new_only_files':len(delta),'modules':source_rows,'new_public_theorems':new_public,'historical_theorem_count':len(theorems),'historical_axiom_union':sorted(axioms),'manifest_summary':manifest_rows,'preserved_original_failures':failures,'checks':checks}
a.output.mkdir(parents=True,exist_ok=True)
(a.output/'retained-validation.json').write_text(json.dumps(out,indent=2)+'\n')
(a.output/'duplicate-recovery.json').write_text(json.dumps(recover,indent=2)+'\n')
print(json.dumps({k:out[k] for k in ['status','head','full_diff_files','new_only_files','fresh_lean_execution','historical_theorem_count','historical_axiom_union','manifest_summary']},indent=2))
print(json.dumps({'checks':len(checks),'failed_checks':[c for c in checks if not c['pass']]},indent=2))
raise SystemExit(0 if out['status']=='PASS' else 1)
