#!/usr/bin/env python3
"""Static source/receipt checks and comparison of freshly executed diagnostics."""
import hashlib, importlib.util, json, pathlib, sys
sys.dont_write_bytecode=True
r=pathlib.Path(__file__).resolve().parent.parent
h=r/'head'; b=h/'proofs/contributions/agent-1/periodic-safety-20261016'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
load=lambda p:json.loads(p.read_text())
checks=[]
def check(n,p,d=None):checks.append({'name':n,'pass':bool(p),'detail':d})
regpath=h/'proofs/Agent1PeriodicSafety.registry.json';reg=load(regpath)
project=reg['projects']['agent1-periodic-safety'];mods=project['modules']
seen=set()
def visit(n):
    if n not in mods or n in seen:return
    seen.add(n)
    for d in mods[n]['imports']:visit(d)
for n in project['roots']:visit(n)
check('all modules reachable from exact two roots',seen==set(mods))
check('canonical registry SHA equals pinned registry',load(b/'parent/clean-001/verification.json')['registry_sha256']==sha(regpath))
spec=importlib.util.spec_from_file_location('pinned_verifier',h/'proofs/verify_project__214bf7673efe116b.py')
v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
for n,e in mods.items():
    code=v.code_only((h/e['path']).read_text())
    check(n+' no kernel bypass source',not any(t in code for t in ['skipKernelTC','implemented_by','@[extern','unsafe def','unsafe theorem','run_cmd','elab ']))
for f in sorted(b.glob('*-author/attempt-*/*.json')):
    x=load(f)
    if not isinstance(x,dict) or 'command' not in x or 'source_sha256' not in x:continue
    srcs=list(f.parent.glob('*.lean'))
    check(str(f.relative_to(h))+' source hash',len(srcs)==1 and sha(srcs[0])==x['source_sha256'])
    if 'log_sha256' in x:
        check(str(f.relative_to(h))+' log hash',sha(f.parent/'compile.log')==x['log_sha256'])
new=load(r/'publish-evidence/diagnostics-attempt-001/stdout.log')
old=load(b/'review/diagnostics-001/stdout.json')
new.pop('python');old.pop('python')
check('new diagnostic result equals original except Python version',new==old)
check('48 positive expansion checks, 10 stripping controls, 2 boundaries',new['positive_expansion_checks']==48 and new['strip_case_count']==10 and 'zero_exponent_boundary' in new and 'unsafe_target_boundary' in new)
out={'status':'PASS' if all(c['pass'] for c in checks) else 'FAIL','checks':checks,'fresh_lean_execution':'NOT_RUN'}
print(json.dumps(out,indent=2))
raise SystemExit(0 if out['status']=='PASS' else 1)
