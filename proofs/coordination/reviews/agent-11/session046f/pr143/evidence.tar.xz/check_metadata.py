"""Complete secondary publication checks, without running retained code or Lean."""
import ast,difflib,hashlib,json,pathlib,re
R=pathlib.Path('/dev/shm/p196-agent11-046f/review143'); E=R/'publish-evidence'; S=R/'snapshot'
C=S/'proofs/contributions/agent-1/periodic-phase-catalog-20261016'; P=C/'verification/parent-clean-001'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
readj=lambda p:json.loads(p.read_text())
result={}
manifest=readj(P/'FILES.json')
for path,v in manifest.items():
    p=P/path; assert len(p.read_bytes())==v['bytes'] and sha(p)==v['sha256'],path
result['canonical_original_manifest']={'entries':len(manifest),'status':'PASS'}
v=readj(P/'verification.json'); project=v['projects']['agent1-periodic-phase-catalog']
assert v['source_tree_clean'] is False and not v['repository_wide_pass'] and v['status']=='PASS'
for r in project['commands']:
    assert r['exit_code']==0 and sha(P/r['log'])==r['log_sha256'],r['label']
    assert r['argv'][1:3]==['-j1','-DElab.async=false'] and '--trust=0' not in r['argv']
assert len(project['commands'])==21
result['canonical_retained_gate']={'commands':21,'explicit_trust_zero':False,'source_tree_clean':False,'source_commit':v['source_commit'],'registry_hash_valid':sha(S/'proofs/Agent1PeriodicPhaseCatalog.registry.json')==v['registry_sha256']}
assert result['canonical_retained_gate']['registry_hash_valid']
author=[]
for kind,dirs,name,receipt,logname in [
    ('phase-author',['attempt-001'],'Agent1PeriodicPhase','run.json','compile.log'),
    ('nines-author',['attempt-001'],'Agent1PeriodicNines','result.json','build.log'),
    ('root-author',['attempt-001','attempt-002'],'Agent1PeriodicPhaseCatalog','result.json','stdout.log')]:
    for d in dirs:
        p=C/kind/d; r=readj(p/receipt); assert r['exit_code']==0
        assert r['source_sha256']==sha(p/(name+'.lean'))
        assert r['command'][1:4]==['--trust=0','-j1','-DElab.async=false']
        if 'log_sha256' in r: assert sha(p/logname)==r['log_sha256']
        author.append({'receipt':str((p/receipt).relative_to(C)),'exit':0,'source_sha256':r['source_sha256'],'log_sha256':sha(p/logname)})
for d,expected in [('audit-001',1),('audit-002',0)]:
    p=C/'phase-author'/d; r=readj(p/'run.json')
    assert r['exit_code']==expected and r['audit_source_sha256']==sha(p/'PhaseAudit.lean') and r['audit_log_sha256']==sha(p/'PhaseAudit.log')
    assert r['command'][1:4]==['--trust=0','-j1','-DElab.async=false']
    author.append({'receipt':str((p/'run.json').relative_to(C)),'exit':expected,'audit_sha256':sha(p/'PhaseAudit.lean'),'log_sha256':sha(p/'PhaseAudit.log')})
n=C/'nines-author/audit-001'; nr=readj(n/'result.json')
assert nr['exit_code']==0 and nr['audit_source_sha256']==sha(n/'NinesAudit.lean')
author.append({'receipt':str((n/'result.json').relative_to(C)),'exit':0,'audit_sha256':sha(n/'NinesAudit.lean'),'log_sha256':sha(n/'build.log')})
result['author_attempts']=author
diffs={}
for label,p,q in [
    ('catalog-strengthening',C/'root-author/attempt-001/Agent1PeriodicPhaseCatalog.lean',C/'root-author/attempt-002/Agent1PeriodicPhaseCatalog.lean'),
    ('phase-audit-classification',C/'phase-author/audit-001/PhaseAudit.lean',C/'phase-author/audit-002/PhaseAudit.lean'),
    ('phase-driver-classification',C/'phase-author/audit-001/audit-driver.py',C/'phase-author/audit-002/audit-driver.py')]:
    diff=''.join(difflib.unified_diff(p.read_text().splitlines(True),q.read_text().splitlines(True),fromfile=str(p.relative_to(C)),tofile=str(q.relative_to(C))))
    (E/(label+'.diff')).write_text(diff); diffs[label]=len(diff)
result['historical_diffs']=diffs
# Every changed Python source parses; it is reviewed as archived instrumentation, not executed.
scripts=[]
for p in C.rglob('*.py'):
    ast.parse(p.read_text());scripts.append(dict(path=str(p.relative_to(C)),sha256=sha(p),bytes=p.stat().st_size))
result['all_python_sources']=scripts
result['status']='PASS'
(E/'metadata-checks.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
