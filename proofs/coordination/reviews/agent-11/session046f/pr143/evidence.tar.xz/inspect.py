import hashlib,json,os,pathlib,re,subprocess
ROOT=pathlib.Path('/dev/shm/p196-agent11-046f/review143')
OUT=ROOT/'publish-evidence'
H='d299c930273adccb1d1ef8288c23c8c9ce8aeace'
B='c440e01ee4375384317cc2e428b7c43e8a04ecdf'
ENV=dict(os.environ,GIT_OBJECT_DIRECTORY=str(ROOT/'objects'),GIT_ALTERNATE_OBJECT_DIRECTORIES='/dev/shm/p196-agent11-046f/objects:/workspace/scratch/046f9285a650/repo/.git/objects',PYTHONDONTWRITEBYTECODE='1')
commands=[]
def git(*args):
    cmd=['git','-C','/workspace/scratch/046f9285a650/repo',*args]
    r=subprocess.run(cmd,env=ENV,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    commands.append({'command':cmd,'exit':r.returncode,'stdout_bytes':len(r.stdout),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr':r.stderr.decode()})
    if r.returncode: raise RuntimeError(commands[-1])
    return r.stdout
def main():
    delta=git('diff','--name-status',B,H).decode()
    (OUT/'full-delta.txt').write_text(delta)
    paths=[line.split('\t')[1] for line in delta.splitlines()]
    assert len(paths)==182 and all(line.startswith('A\t') for line in delta.splitlines())
    extras=['AGENTS.md','proofs/PUBLICATION_POLICY.md','proofs/ACCEPTED_BUILD.json','proofs/verify_project.py']
    recovery=[]
    def extract(path):
        if path in {x['path'] for x in recovery}: return
        data=git('show',H+':'+path)
        target=ROOT/'snapshot'/path
        target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(data)
        recovery.append({'commit':H,'path':path,'blob':git('rev-parse',H+':'+path).decode().strip(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'recovery_command':['git','show',H+':'+path]})
    for path in paths+extras: extract(path)
    registry=json.loads((ROOT/'snapshot/proofs/Agent1PeriodicPhaseCatalog.registry.json').read_text())
    (OUT/'registry-shape.json').write_text(json.dumps(registry,indent=2)+'\n')
    # Resolve local imports from the exact retained source map, avoiding a repository-wide census.
    for file in list((ROOT/'snapshot').rglob('sources.json')):
        (OUT/'sources-map-shape.json').write_text(file.read_text())
    (OUT/'recovery-map.json').write_text(json.dumps(recovery,indent=2)+'\n')
    print(json.dumps({'head':H,'base':B,'added_paths':len(paths),'extracted_paths':len(recovery),'bytes':sum(x['bytes'] for x in recovery)}))
try: main()
finally: (OUT/'git-command-receipts.json').write_text(json.dumps(commands,indent=2)+'\n')
