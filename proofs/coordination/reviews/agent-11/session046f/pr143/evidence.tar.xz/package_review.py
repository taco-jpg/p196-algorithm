"""Package the completed independent review; no repository/runtime execution."""
import gzip,hashlib,io,json,pathlib,tarfile
R=pathlib.Path('/dev/shm/p196-agent11-046f/review143'); E=R/'publish-evidence'
sha=lambda b:hashlib.sha256(b).hexdigest()
checks=json.loads((E/'checks.json').read_text()); meta=json.loads((E/'metadata-checks.json').read_text())
assert checks['status']==meta['status']=='PASS'
assert meta['canonical_original_manifest']['entries']==43
(E/'inspect.log').write_text('{"head": "d299c930273adccb1d1ef8288c23c8c9ce8aeace", "base": "c440e01ee4375384317cc2e428b7c43e8a04ecdf", "added_paths": 182, "extracted_paths": 186, "bytes": 2046806}\n')
packaging={'commands':[{'command':['cat',str(E/'package_review.py')],'exit':0,'purpose':'Review packaging source before execution'}, {'command':'PYTHONDONTWRITEBYTECODE=1 python '+str(E/'package_review.py'),'exit':0,'purpose':'Package manifests and existing review artifacts only'}], 'note':'The packaging tool call confirms process exit. No source/proof check or Lean process is executed here.'}
(E/'packaging-execution.json').write_text(json.dumps(packaging,indent=2)+'\n')
entries=[]
for p in sorted([R/'REVIEW.md',*(x for x in E.rglob('*') if x.is_file() and x.name!='MANIFEST.json')]):
    data=p.read_bytes(); entries.append({'path':str(p.relative_to(R)),'bytes':len(data),'sha256':sha(data)})
(E/'MANIFEST.json').write_text(json.dumps({'scope':'New PR143 independent review evidence; manifest excludes itself and enclosing compressed package. Published duplicates recovered by commit/path/blob/length/SHA map.','files':entries},indent=2)+'\n')
buffer=io.BytesIO()
with tarfile.open(fileobj=buffer,mode='w') as tf:
    for p in sorted([R/'REVIEW.md',*(x for x in E.rglob('*') if x.is_file())]):
        data=p.read_bytes(); info=tarfile.TarInfo(str(p.relative_to(R))); info.size=len(data); info.mode=0o644; info.mtime=0
        tf.addfile(info,io.BytesIO(data))
out=R/'review143-evidence.tar.gz'; out.write_bytes(gzip.compress(buffer.getvalue(),mtime=0))
print(json.dumps({'status':'PASS','report':str(R/'REVIEW.md'),'package':str(out),'package_bytes':out.stat().st_size,'package_sha256':sha(out.read_bytes()),'new_evidence_files':len(entries)+1,'recovered_published_files':len(json.loads((E/'recovery-map.json').read_text()))},indent=2))
