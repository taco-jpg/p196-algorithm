"""Independent read-only exact-source and retained-evidence checks; no Lean execution."""
import ast,collections,gzip,hashlib,itertools,json,os,pathlib,re,subprocess,traceback
R=pathlib.Path('/dev/shm/p196-agent11-046f/review143'); E=R/'publish-evidence'; S=R/'snapshot'
C=S/'proofs/contributions/agent-1/periodic-phase-catalog-20261016'; V=C/'review/clean-001'
H='d299c930273adccb1d1ef8288c23c8c9ce8aeace'; B='c440e01ee4375384317cc2e428b7c43e8a04ecdf'
env=dict(os.environ,GIT_OBJECT_DIRECTORY=str(R/'objects'),GIT_ALTERNATE_OBJECT_DIRECTORIES='/dev/shm/p196-agent11-046f/objects:/workspace/scratch/046f9285a650/repo/.git/objects',PYTHONDONTWRITEBYTECODE='1')
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
receipts=[]; recovery=json.loads((E/'recovery-map.json').read_text()); checks={}
def git(*args):
    cmd=['git','-C','/workspace/scratch/046f9285a650/repo',*args]
    p=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    receipts.append(dict(command=cmd,exit=p.returncode,stdout_bytes=len(p.stdout),stdout_sha256=sha(p.stdout),stderr=p.stderr.decode()))
    assert p.returncode==0,receipts[-1]
    return p.stdout
def extract(path):
    target=S/path
    if target.exists():return target.read_bytes()
    data=git('show',H+':'+path); target.parent.mkdir(parents=True,exist_ok=True); target.write_bytes(data)
    recovery.append(dict(commit=H,path=path,blob=blob(data),bytes=len(data),sha256=sha(data),recovery_command=['git','show',H+':'+path]))
    return data
def readj(path): return json.loads(path.read_text())
def main():
    reg=readj(S/'proofs/Agent1PeriodicPhaseCatalog.registry.json')
    modules=reg['projects']['agent1-periodic-phase-catalog']['modules']; imports={}; sources={}
    for name,v in modules.items():
        data=extract(v['path']); sources[name]=data.decode()
        assert sha(data)==v['sha256'] and blob(data)==v['git_blob'],name
        actual=re.findall(r'^import\s+(\S+)\s*$',data.decode(),re.M); imports[name]=actual
        assert actual==v['imports'],(name,actual,v['imports'])
        assert data==(V/'compiled-sources'/f'{name}.lean').read_bytes(),name
        assert data==(C/'verification/parent-clean-001/agent1-periodic-phase-catalog/source'/f'{name}.lean').read_bytes(),name
    reached=set()
    def walk(n):
        if n=='Std':return
        assert n in modules,n
        if n in reached:return
        reached.add(n)
        for dep in imports[n]:walk(dep)
    walk('Agent1PeriodicPhaseCatalog'); assert reached==set(modules) and len(reached)==20
    for name in set(modules)-{'Agent1PeriodicPhase','Agent1PeriodicNines','Agent1PeriodicPhaseCatalog'}:
        assert git('show',B+':'+modules[name]['path']).decode()==sources[name],name
    checks['closure']={'modules':len(modules),'actual_imports':imports,'all_registry_and_both_compiled_snapshots_match':True,'inherited_sources_identical_to_parent':17}
    retained=readj(V/'results.json'); assert len(retained)==21
    order=[]
    for row in retained:
        name=row['module']; cmd=row['command']; log=(V/(name+'.log')).read_bytes()
        assert row['exit_code']==0 and sha(log)==row['log_sha256'],name
        assert cmd[:4]==['/workspace/p196-tools/lean-4.19.0-linux/bin/lean','--trust=0','-j1','-DElab.async=false'],cmd
        assert cmd[4:]==(['-o',name+'.olean',name+'.lean'] if name!='ReviewAudit' else [name+'.lean'])
        if name!='ReviewAudit':
            assert all(x=='Std' or x in order for x in imports[name]),name
            order.append(name)
    assert set(order)==set(modules)
    # Read every raw audit line; multiline transitive axiom lists are parsed fully.
    log=(V/'ReviewAudit.log').read_text()
    pattern=r'^(AUDIT_THEOREM|AUDIT_SAFE_DEFINITION|AUDIT_SAFE_OPAQUE) (\S+) (\S+) : \[([^\]]*)\]'
    rows=re.findall(pattern,log,re.M); allowed={'propext','Quot.sound','Classical.choice'}
    th=[]; defs=[]; union=set(); du=set()
    for kind,mod,name,axtext in rows:
        axs={x.strip() for x in axtext.split(',') if x.strip()}
        assert axs<=allowed,(mod,name,axs)
        (th if kind=='AUDIT_THEOREM' else defs).append((mod,name,sorted(axs)))
        (union if kind=='AUDIT_THEOREM' else du).update(axs)
    assert len(th)==1407 and len(defs)==247 and union==allowed and du=={'propext'}
    assert {x[0] for x in th}==set(modules)
    assert len(set((x[0],x[1]) for x in th))==len(th)
    assert not re.search(r'^(?:CUSTOM_AXIOM|DISALLOWED_\w+|UNSAFE_OPAQUE|MODULE_NOT_AUDITED)',log,re.M)
    unsafe=re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$',log,re.M)
    nonsafe=re.findall(r'^NONSAFE_DEFINITION (\S+) (\S+)$',log,re.M)
    inventory=readj(V/'implementation-inventory.json')
    assert len(unsafe)==20 and len(nonsafe)==1515
    assert inventory['status']=='PASS' and inventory['nonsafe_count']==1515 and inventory['cstage_helpers']==1487 and inventory['unsafe_rec_helpers']==28
    assert set(map(tuple,inventory['unsafe_axioms']))==set(unsafe)
    safe={(x[0],x[1]) for x in defs}
    for item in inventory['unsafe_rec_base_checks']:
        assert item['safe_base_audited'] and (item['module'],item['safe_base']) in safe
    audit_src=(V/'ReviewAudit.lean').read_text()
    named=re.findall(r'^#check (\S+)$',audit_src,re.M); assert len(named)==95
    # Verify every named public theorem is present in the origin scan and its own module's printed axioms.
    pub=[]
    for mod,src in sources.items():
        if not mod.startswith('Agent1'):continue
        namespace='Agent1.Periodic' if mod.startswith('Agent1Periodic') else 'Agent1.RepeatedBlock'
        for n in re.findall(r'^theorem\s+(\w+)',src,re.M):
            full=namespace+'.'+n; pub.append(full)
            assert (mod,full) in {(x[0],x[1]) for x in th}
            assert "'"+full+"' " in (V/(mod+'.log')).read_text()
    assert set(pub)==set(named)
    checks['retained_independent_gate']={'original_executor':'Agent #1 nonauthor specialist /root/research_status','commands':21,'explicit_trust':0,'all_command_vectors_exits_log_hashes_validated':True,'theorems':len(th),'safe_definitions':len(defs),'named_interfaces':len(named),'theorem_axioms':sorted(union),'safe_definition_axioms':sorted(du),'nonsafe_implementations':len(nonsafe),'unsafe_implementation_axioms':len(unsafe),'per_module_theorems':dict(collections.Counter(x[0] for x in th))}
    # Full metadata parse, manifest reconciliation, and publication receipt hashes.
    json_files=list(C.rglob('*.json'))
    parsed={str(p.relative_to(C)):readj(p) for p in json_files}
    manifest_records=[]
    for rel,obj in parsed.items():
        if pathlib.Path(rel).name not in {'FILES.json','PACKAGE-FILES.json'}:continue
        root=(C/rel).parent
        # Original canonical FILES uses its original run-root layout, retained separately from PACKAGE-FILES.
        if rel=='verification/parent-clean-001/FILES.json':continue
        entries=obj['files'] if isinstance(obj,dict) else obj
        for entry in entries:
            p=root/entry['path']; data=p.read_bytes()
            assert len(data)==entry.get('bytes',entry.get('size')) and sha(data)==entry['sha256'],str(p)
        manifest_records.append({'path':rel,'entries':len(entries),'status':'PASS'})
    receipt=readj(C/'review/final-review-receipt.json')
    for rel,expected in receipt['artifacts'].items(): assert sha((C/'review'/rel).read_bytes())==expected,rel
    checks['manifests']={'json_files_parsed':len(parsed),'validated_manifests':manifest_records,'final_receipt_artifact_hashes':len(receipt['artifacts'])}
    fail=parsed['phase-author/audit-001/run.json']; assert fail['status']=='FAIL' and fail['exit_code']==1
    assert sha((C/'phase-author/audit-001/PhaseAudit.lean').read_bytes())==fail['audit_source_sha256']
    assert sha((C/'phase-author/audit-001/PhaseAudit.log').read_bytes())==fail['audit_log_sha256']
    checks['historical_failure']={'path':'phase-author/audit-001','exit':1,'source_and_log_hashes_validated':True,'preserved_in_full_delta':True}
    # Obtain the exact original compressed graph and generator, without executing its searches.
    replay_tree=ast.parse((C/'catalog-review/replay.py').read_text())
    arch=next(ast.literal_eval(n.value) for n in replay_tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='ARCHIVE' for t in n.targets))
    provenance=parsed['catalog-review/run-001/provenance.json']
    for item in provenance:
        data=extract(item['path']); assert sha(data)==item['sha256'] and blob(data)==item['git_blob'] and len(data)==item['bytes']
    compressed=extract(arch+'bulk_phase_graph.json.gz'); payload=gzip.decompress(compressed)
    assert payload==(C/'catalog-review/run-001/original-payload.json').read_bytes()
    graph=json.loads(payload); catalog=sources['Agent1PeriodicPhaseCatalog']
    phases=ast.literal_eval(re.search(r'^def phaseCatalog : List Word := (\[.*?^\])',catalog,re.M|re.S)[1]); edges=[]
    eb=re.search(r'^def phaseEdges : List PhaseEdge := \[\n(.*?)^\]',catalog,re.M|re.S)[1]
    for line in eb.splitlines():
        m=re.fullmatch(r'\s*⟨(\[[0-9, ]+\]), ([01]), (none|some \(([01]),([01])\)), (\[[0-9, ]+\])⟩,?',line); assert m,line
        e=dict(source=ast.literal_eval(m[1]),clock=int(m[2]),target=ast.literal_eval(m[6]))
        if m[3]!='none':e.update(left_carry=int(m[4]),right_carry=int(m[5]))
        edges.append(e)
    assert phases==[r['source'] for r in graph['graph']]
    assert edges==[dict(source=r['source'],**e) for r in graph['graph'] for e in r['edges']]
    assert phases==parsed['catalog-review/run-001/phases.json'] and edges==parsed['catalog-review/run-001/labelled-edges.json']
    assert len(phases)==len(set(map(tuple,phases)))==59 and len(edges)==124
    checks['catalog_identity']={'phases':59,'ordered_complete_labels':124,'compressed_source_sha256':sha(compressed),'decoded_bytes':len(payload),'decoded_sha256':sha(payload),'archive_unchanged':True}
    # Independent direct finite control: original full carry scan and literal raw slices.
    # Empty, threshold, neutral, and reversed mixed interfaces exercise actual (dependent) carries.
    Bs=[[],[0],[8],[9],[10],[18],[9,10],[10,9]]; Hs=[[],[0],[9],[10],[18]]
    def scan(w,c=0):
        ds=[]
        for q in w:ds.append((q+c)%10); c=(q+c)//10
        return ds,c
    def phase(w,g):
        u=scan(w,scan(w)[1])[0]; rev=w[::-1]; v=scan(rev,scan(rev)[1])[0]
        return [a+b for a,b in zip(u,v[:g][::-1]+v[g:][::-1])]
    records=[]
    for w,b,h in itertools.product(phases,Bs,Hs):
        digits,g=scan(b+w*3+h+w[::-1]*3+b[::-1]); normalized=digits+([g] if g else [])
        paired=[x+y for x,y in zip(normalized,normalized[::-1])]; actual=paired[len(b)+4:len(b)+8]
        a=scan(b)[1]; right=scan(h,scan(w,a)[1])[1]
        expected=[18-9*(a+right)]*4 if w==[9]*4 else phase(w,g)
        edge=dict(source=w,clock=g,target=actual)
        if w==[9]*4:edge.update(left_carry=a,right_carry=right)
        assert actual==expected and edge in edges,(b,h,w,g,a,right,actual,expected)
        records.append(dict(B=b,H=h,period=w,clock=g,left_entry=a,right_entry=right,raw_period=actual,status='PASS'))
    raw=(json.dumps(records,separators=(',',':'))+'\n').encode(); stored=gzip.compress(raw,mtime=0)
    (E/'finite-boundary-controls.json.gz').write_bytes(stored)
    checks['fresh_finite_controls']={'status':'PASS','cases':len(records),'scope':'Only the 59 catalog phases and 8 exterior by 5 center boundary controls; no reachability or all-time claim','raw_bytes':len(raw),'raw_sha256':sha(raw),'stored_bytes':len(stored),'stored_sha256':sha(stored),'recover':'gzip -dc finite-boundary-controls.json.gz > finite-boundary-controls.json'}
    # Verify all 182 added paths byte-for-byte still correspond to extraction; classify repeated material.
    delta=(E/'full-delta.txt').read_text().splitlines(); content_groups=collections.defaultdict(list)
    for line in delta:
        kind,path=line.split('\t'); assert kind=='A'; d=(S/path).read_bytes(); d.decode()
        content_groups[sha(d)].append(path)
    checks['full_delta']={'added_paths':len(delta),'unique_byte_contents':len(content_groups),'all_utf8_decoded':True,'content_groups':dict(content_groups)}
    checks['fresh_lean']='NOT_RUN: root reports prior launch failure and rejected escalation; no retry or bypass performed by this reviewer.'
    checks['status']='PASS'
try:
    main()
except Exception:
    checks['status']='FAIL'; checks['traceback']=traceback.format_exc(); raise
finally:
    (E/'checks.json').write_text(json.dumps(checks,indent=2)+'\n')
    (E/'evidence-git-command-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
    (E/'recovery-map.json').write_text(json.dumps(recovery,indent=2)+'\n')
    print(json.dumps({k:v for k,v in checks.items() if k!='full_delta'},indent=2))
