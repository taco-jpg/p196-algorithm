"""Read-only exact-source and retained evidence audit; does not invoke Lean."""
import ast,hashlib,importlib.util,json,os,pathlib,re,subprocess,sys,traceback
R=pathlib.Path('/dev/shm/p196-agent11-046f/review130'); S=R/'source';O=R/'publish-evidence';P='proofs/contributions/agent-3/three-layer-prefix-20261016';D=S/P
H='8a67ea8204757cc4f80bf5f576e2cc8024bea97b'; B='fa3921e58556250b1a6efd30af603fb65a9d9fbc';M='89287c9d3eb7dd801c2b1a59eff03140d47d24ec';I='e423f12c0bb7881fabd2ece40c9f68076a2dc97e'
env=dict(os.environ,GIT_OBJECT_DIRECTORY=str(R/'objects'),GIT_ALTERNATE_OBJECT_DIRECTORIES='/dev/shm/p196-agent11-046f/objects:/workspace/scratch/046f9285a650/repo/.git/objects',GIT_NO_LAZY_FETCH='1')
report={'status':'RUNNING','scope':'Fresh Python static/provenance audit of exact committed bytes and retained raw Lean evidence. Fresh Lean NOT_RUN.','head':H,'main':B,'merge_base':M,'pr91_integration':I,'checks':[],'git_commands':[]}
def load(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def ck(label,condition,detail=None):
 report['checks'].append({'label':label,'pass':bool(condition),'detail':detail});assert condition,label

def git(*args,accepted=(0,)):
 cmd=['git','-C','/workspace/scratch/046f9285a650/repo',*args];r=subprocess.run(cmd,env=env,capture_output=True);report['git_commands'].append({'argv':cmd,'exit_code':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace')});ck('git command '+str(args),r.returncode in accepted);return r.stdout.decode().strip()
def identity(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
try:
 # Importing inspected driver only defines helpers; its main guard is not entered.
 spec=importlib.util.spec_from_file_location('retained_verifier',D/'verification/verify.py');v=importlib.util.module_from_spec(spec);spec.loader.exec_module(v)
 m=load(D/'verification/source-pins.json'); c=load(D/'verification/evidence/verification.json'); n=load(D/'review/verification.json')
 ck('source manifests identical',(D/'verification/source-pins.json').read_bytes()==(D/'verification/evidence/source-pins.json').read_bytes())
 ck('canonical manifest exact',sha(D/'verification/source-pins.json')==c['manifest_sha256']);ck('canonical verifier exact',sha(D/'verification/verify.py')==c['verifier_sha256'])
 ck('both original runs pass',c['status']==n['status']=='PASS');ck('both original runs use same runtime',c['environment']['lean_sha256']==n['lean_sha256']==m['recorded_linux_x86_64_lean_sha256'])
 ck('runtime release exact',c['environment']['lean_version']==n['lean_version']=='Lean (version 4.19.0, x86_64-unknown-linux-gnu, commit 6caaee842e94, Release)')
 ck('PR91 integration ancestor of main',git('merge-base',I,B)==I)
 ck('actual merge base',git('merge-base',H,B)==M)
 seen={'Std'}; new=[];decls=[];source_closure=[]
 for x in m['modules']:
  f=S/x['source'];data=f.read_bytes();code=v.code_only(data.decode());ck(x['module']+' bytes',sha(f)==x['sha256'] and identity(data)==x['git_blob']);v.source_scan(code)
  imports=v.imports_of(code);ck(x['module']+' import closure',imports==x['imports'] and set(imports)<=seen);seen.add(x['module'])
  origin=x.get('original_source',x['source']);b=git('rev-parse',x['source_commit']+':'+origin);ck(x['module']+' original Git provenance',b==x['git_blob'])
  cs=next(z for z in c['source_records'] if z['module']==x['module']);ns=next(z for z in n['sources'] if z['module']==x['module'])
  ck(x['module']+' exact-source execution',cs['sha256']==ns['sha256']==x['sha256'] and cs['bytes']==ns['bytes']==len(data) and cs['copy_sha256']==x['sha256'] and cs['imports']==ns['imports']==imports)
  if x['role']=='contribution':
   declarations=v.source_declarations(code);ds=[{k:y[k] for k in ('name','kind','private')} for y in declarations];ck(x['module']+' all explicit declarations',ds==x['explicit_declarations']);decls.extend({'module':x['module'],**y} for y in declarations)
  if x['generation']=='three_layer_prefix' if 'generation' in x else False:new.append(x['module'])
  source_closure.append({'module':x['module'],'path':x['source'],'head':H,'bytes':len(data),'sha256':x['sha256'],'blob':x['git_blob'],'original_commit':x['source_commit'],'original_path':origin,'imports':imports})
 ck('complete closure count',len(source_closure)==27 and len(new)==4 and len(decls)==231)
 (O/'source-closure.json').write_text(json.dumps(source_closure,indent=2)+'\n')
 # Parse every byte of every raw compile and axiom log and compare exact command hashes.
 command_evidence=[]
 for label,r,folder,key in [('canonical',c,D/'verification/evidence','log_sha256'),('independent',n,D/'review','output_sha256')]:
  builds=[]
  for command in r['commands']:
   log=folder/'logs'/pathlib.Path(command['log']).name; output=log.read_text();ck(label+' command '+command['label'],command['exit_code']==0 and sha(log)==command[key]);ck(label+' no diagnostic failure '+command['label'],not re.search(r'\b(?:error|warning):|declaration uses.*sorry|\bsorryAx\b|\bLean\.ofReduceBool\b',output))
   argv=command['argv'];
   if any(a.endswith('.lean') for a in argv):ck(label+' strict flag '+command['label'],'--trust=0' in argv)
   if '-o' in argv:builds.append(pathlib.Path(argv[-1]).stem)
   v.parse_axiom_records(output)
   command_evidence.append({'original_run':label,**command,'committed_log':str(log.relative_to(S)),'actual_log_bytes':log.stat().st_size,'actual_log_sha256':sha(log)})
  ck(label+' full27 build coverage',set(builds)==set(x['module'] for x in m['modules']) and len(builds)==27)
 ck('original command counts',len(c['commands'])==31 and len(n['commands'])==29)
 (O/'original-commands-and-log-identities.json').write_text(json.dumps(command_evidence,indent=2)+'\n')
 # Independently parse full owner inventories and full raw transitive audits.
 def inventory(raw,tag):
  rows=re.findall(r'(?m)^'+tag+r' (\S+) (\S+) (\S+) (true|false) (true|false) (true|false)\s*$',raw)
  return sorted([dict(module=a,name=b,user_name=d,private=e=='true',unsafe=f=='true',partial=g=='true') for a,b,d,e,f,g in rows],key=lambda x:(x['module'],x['name']))
 ci=inventory((D/'verification/evidence/logs/ExportInventory.log').read_text(),'P196_AUDIT_DECL'); ni=inventory((D/'review/logs/28-compiled-ownership-axioms.log').read_text(),'INDEPENDENT_DECL')
 ca=v.parse_axiom_records((D/'verification/evidence/logs/AllExportedAxioms.log').read_text()); na=v.parse_axiom_records((D/'review/logs/28-compiled-ownership-axioms.log').read_text())
 ck('raw inventories equal',ci==ni and len(ci)==620 and len({x['name'] for x in ci})==620)
 ck('stored canonical inventory exact',ci==c['audit']['compiled_inventory']);stored_ni=[dict(module=x['owner'],**{k:v for k,v in x.items() if k!='owner'}) for x in load(D/'review/compiled-declarations.json')];ck('stored independent inventory exact',ni==stored_ni)
 safe={x['name'] for x in ci if not x['unsafe'] and not x['partial']};ck('complete transitive safe audit',set(ca)==set(na)==safe and ca==na and len(safe)==373)
 ck('stored full audits equal raw',ca==c['audit']['records'] and na==load(D/'review/axiom-dependencies.json'))
 ck('permitted foundation axioms only',set().union(*(set(x) for x in ca.values()))=={'Classical.choice','Quot.sound','propext'})
 explicit=[]
 for d in decls:
  xs=[x for x in ci if x['module']==d['module'] and x['user_name']==d['name'] and x['private']==d['private']];ck('explicit safe coverage '+d['name'],len(xs)==1 and xs[0]['name'] in safe);explicit.append({**d,'compiled_name':xs[0]['name'],'axioms':ca[xs[0]['name']]})
 ck('private helper coverage',sum(x['private'] for x in explicit)==3)
 ck('contribution owner coverage',{x['module'] for x in ci}=={x['module'] for x in m['modules'] if x['role']=='contribution'})
 ck('canonical diagnostics exact',sha(D/'verification/evidence/ExportInventory.lean')==c['audit']['inventory_source_sha256'] and sha(D/'verification/evidence/AllExportedAxioms.lean')==c['audit']['audit_source_sha256'])
 report['audit_summary']={'compiled':len(ci),'logical':len(safe),'explicit':len(explicit),'private':sum(x['private'] for x in explicit),'implementation':len(ci)-len(safe),'new_explicit':sum(x['module'] in new for x in explicit),'new_safe':sum(x['module'] in new and x['name'] in safe for x in ci),'axioms':sorted(set().union(*(set(x) for x in ca.values())))}
 (O/'explicit-declaration-coverage.json').write_text(json.dumps(explicit,indent=2)+'\n')
 # Check all retained package indexes and raw file bytes without trusting summary counts.
 manifests=[]
 for rel,base in [('verification/evidence/artifact-index.json',D/'verification/evidence'),('review/evidence-manifest.json',D/'review'),('verification/package-index.json',D)]:
  j=load(D/rel)
  for x in j['files']:
   f=base/x['path'];ck('index '+rel+' '+x['path'],f.stat().st_size==x['bytes'] and sha(f)==x['sha256'])
  manifests.append({'path':P+'/'+rel,'entries':len(j['files']),'status':'PASS'})
 report['manifest_validation']=manifests
 # Driver reuse comparison, not a newly executed inherited guard suite.
 old=S/'proofs/contributions/agent-3/two-history-20261016/verification/verify.py'; cur=D/'verification/verify.py'
 expected=old.read_text().replace('two-history proof','three-layer proof').replace('"P196.Agent3.TwoHistory"}', '"P196.Agent3.TwoHistory", "P196.Agent3.ThreeLayer"}')
 ck('only advertised driver adaptation',expected==cur.read_text())
 provenance=load(D/'verification/development/verifier-provenance.json')
 for x in provenance['guard_suite']['retained_original_files']:
  f=D/'verification'/x['retained'];original=git('rev-parse',x['source_commit']+':'+x['source']);ck('inherited guard exact '+x['retained'],sha(f)==x['sha256'] and identity(f.read_bytes())==original)
 # Historical generator and data are preserved evidence, not part of the Lean theorem.
 histories=[]
 for x in m['historical_sources']:
  f=S/x['source'];blob=git('rev-parse',H+':'+x['archive_path']);ck('historical preserved '+x['source'],sha(f)==x['sha256'] and identity(f.read_bytes())==blob==x['git_blob'] and f.stat().st_size==x['bytes']);histories.append({'retained_path':x['source'],'archive_commit':H,'archive_path':x['archive_path'],'blob':blob,'bytes':x['bytes'],'sha256':x['sha256']})
 (O/'historical-recovery-map.json').write_text(json.dumps(histories,indent=2)+'\n')
 # Every changed file is readable text; parsed JSON/AST/log snapshots are retained in recovery map.
 changed=(O/'changed-paths.txt').read_text().splitlines();kind={};attempts=[]
 for p in changed:
  f=S/p;txt=f.read_text();suffix=f.suffix;kind[suffix]=kind.get(suffix,0)+1
  if suffix=='.json':load(f)
  if suffix=='.py':ast.parse(txt)
  if 'attempt-' in p and suffix=='.json':attempts.append({'path':p,'record':load(f)})
 ck('only contribution additions',len(changed)==145 and all(p.startswith(P+'/') for p in changed));report['changed_file_types']=kind;report['all_changed_files_read_and_json_python_parsed']=True
 report['retained_original_attempts']=attempts
 report['original_environment']=c['environment'];report['original_execution_intervals']={label:{k:r[k] for k in ['started_utc','finished_utc','invocation']} for label,r in [('canonical',c),('independent',n)]}
 report['status']='PASS'
except Exception as e:
 report['status']='FAIL';report['error']=str(e);report['traceback']=traceback.format_exc();print(report['traceback'])
finally:
 (O/'retained-audit.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'status':report['status'],'checks':len(report['checks']),'audit':report.get('audit_summary'),'error':report.get('error')}));sys.exit(0 if report['status']=='PASS' else 1)
