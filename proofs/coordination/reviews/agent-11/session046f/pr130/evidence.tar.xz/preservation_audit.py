"""Validate retained source-attempt snapshots and audit records without Lean."""
import pathlib,json,hashlib,difflib
R=pathlib.Path('/dev/shm/p196-agent11-046f/review130');D=R/'source/proofs/contributions/agent-3/three-layer-prefix-20261016';O=R/'publish-evidence'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
records=[]
for folder,module in [('dead-prefix','DeadPrefix'),('actual-depth','ActualDepth'),('family','SharpHistoryFamily'),('aggregate','SharpHistoryTheorem')]:
 for f in sorted((D/'development'/folder).glob('attempt-*.json')):
  j=json.loads(f.read_text());base=f.with_suffix('');snapshot=pathlib.Path(str(base)+'.lean.txt');log=base.with_suffix('.log');assert snapshot.exists() and log.exists()
  expected=j.get('source_sha256',j.get('source_hash'));assert sha(snapshot)==expected,(str(f),expected)
  command=j.get('compile',j);ec=command['exit_code'];lh=command.get('log_sha256');assert lh is None or sha(log)==lh
  if ec:assert 'error:' in log.read_text()
  records.append({'record':str(f.relative_to(D)),'snapshot':str(snapshot.relative_to(D)),'snapshot_sha256':sha(snapshot),'log':str(log.relative_to(D)),'log_sha256':sha(log),'exit_code':ec,'final_source_identical':snapshot.read_bytes()==(D/(module+'.lean')).read_bytes(),'record_data':j})
  diff=''.join(difflib.unified_diff(snapshot.read_text().splitlines(keepends=True),(D/(module+'.lean')).read_text().splitlines(keepends=True),fromfile=str(snapshot.relative_to(D)),tofile=module+'.lean'))
  if diff:(O/(folder+'-'+f.stem+'-to-final.diff')).write_text(diff)
assert len(records)==6
assert sum(r['exit_code']!=0 for r in records)==2
for folder in ['dead-prefix','actual-depth','family','aggregate']:
 j=json.loads((D/'development'/folder/'verification.json').read_text());log=D/'development'/folder/'axiom-audit.log'
 expected=j.get('audit_log_sha256',j.get('audit',{}).get('log_sha256'))
 assert expected is None or expected==sha(log)
obj=json.loads((D/'development/resources/reproducible-object-cleanup.json').read_text());dup=json.loads((D/'development/resources/duplicate-download-cleanup.json').read_text())
result={'status':'PASS','scope':'Six retained author snapshots and raw compilation logs; two expected failures and four final-source successes; no proof execution by current reviewer.','attempts':records,'preflight':json.loads((D/'development/actual-depth/dependency-preflight-001.json').read_text()),'packaging':json.loads((D/'verification/development/packaging-attempts.json').read_text()),'resource_cleanup':obj,'duplicate_download_cleanup':dup}
(O/'preservation-audit.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({'status':'PASS','source_attempts':len(records),'failed_attempts':2,'successful_final_source_attempts':sum(r['final_source_identical'] for r in records)}))
