import os,subprocess,json,hashlib,pathlib
root=pathlib.Path('/dev/shm/p196-agent11-046f/review130'); out=root/'publish-evidence';src=root/'source'
H='8a67ea8204757cc4f80bf5f576e2cc8024bea97b'; B='fa3921e58556250b1a6efd30af603fb65a9d9fbc'; M='89287c9d3eb7dd801c2b1a59eff03140d47d24ec'
env=dict(os.environ,GIT_OBJECT_DIRECTORY=str(root/'objects'),GIT_ALTERNATE_OBJECT_DIRECTORIES='/dev/shm/p196-agent11-046f/objects:/workspace/scratch/046f9285a650/repo/.git/objects',GIT_NO_LAZY_FETCH='1')
commands=[]
def git(*args):
 cmd=['git','-C','/workspace/scratch/046f9285a650/repo',*args];r=subprocess.run(cmd,env=env,capture_output=True);commands.append({'argv':cmd,'exit':r.returncode,'stdout_bytes':len(r.stdout),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr':r.stderr.decode(errors='replace')});assert r.returncode==0,commands[-1];return r.stdout
paths=git('diff','--name-only',M,H).decode().splitlines(); (out/'full.diff').write_bytes(git('diff','--binary',M,H));(out/'changed-paths.txt').write_text('\n'.join(paths)+'\n')
paths+=['AGENTS.md','proofs/PUBLICATION_POLICY.md'];maps=[]
for p in paths:
 data=git('show',H+':'+p);dst=src/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data);blob=git('rev-parse',H+':'+p).decode().strip();maps.append({'commit':H,'path':p,'blob':blob,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
(out/'recovery-map.json').write_text(json.dumps(maps,indent=2)+'\n');(out/'collection-commands.json').write_text(json.dumps(commands,indent=2)+'\n');print(json.dumps({'files':len(maps),'bytes':sum(m['bytes'] for m in maps)}))
