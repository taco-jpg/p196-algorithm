import os,subprocess,json,hashlib,pathlib
root=pathlib.Path('/dev/shm/p196-agent11-046f/review130');out=root/'publish-evidence';src=root/'source';prefix='proofs/contributions/agent-3/three-layer-prefix-20261016';H='8a67ea8204757cc4f80bf5f576e2cc8024bea97b';B='fa3921e58556250b1a6efd30af603fb65a9d9fbc';M='89287c9d3eb7dd801c2b1a59eff03140d47d24ec';I='e423f12c0bb7881fabd2ece40c9f68076a2dc97e'
env=dict(os.environ,GIT_OBJECT_DIRECTORY=str(root/'objects'),GIT_ALTERNATE_OBJECT_DIRECTORIES='/dev/shm/p196-agent11-046f/objects:/workspace/scratch/046f9285a650/repo/.git/objects',GIT_NO_LAZY_FETCH='1');commands=[]
def git(*args):
 cmd=['git','-C','/workspace/scratch/046f9285a650/repo',*args];r=subprocess.run(cmd,env=env,capture_output=True);commands.append({'argv':cmd,'exit':r.returncode,'stdout_bytes':len(r.stdout),'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stderr':r.stderr.decode(errors='replace')});assert r.returncode==0,commands[-1];return r.stdout
manifest=json.loads((src/prefix/'verification/source-pins.json').read_text());maps=json.loads((out/'recovery-map.json').read_text());match=[]
extra=['proofs/contributions/agent-3/two-history-20261016/dependencies/agent9/SOURCE_PINS.json','proofs/contributions/agent-3/two-history-20261016/verification/verify.py','proofs/README.md','proofs/REPRODUCE.md']
for p in [r['source'] for r in manifest['modules']]+extra:
 data=git('show',H+':'+p);dst=src/p;dst.parent.mkdir(parents=True,exist_ok=True);dst.write_bytes(data);blob=git('rev-parse',H+':'+p).decode().strip()
 if not any(m['path']==p for m in maps): maps.append({'commit':H,'path':p,'blob':blob,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
 if '/three-layer-prefix-' not in p:
  identities={c:git('rev-parse',c+':'+p).decode().strip() for c in [M,B,I]};match.append({'path':p,'head_blob':blob,'comparison_blobs':identities,'all_identical':all(x==blob for x in identities.values())})
(out/'recovery-map.json').write_text(json.dumps(maps,indent=2)+'\n');(out/'dependency-source-match.json').write_text(json.dumps(match,indent=2)+'\n');(out/'dependency-collection-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
print(json.dumps({'modules':len(manifest['modules']),'comparison_count':len(match),'nonidentical':[m['path'] for m in match if not m['all_identical']]}))
