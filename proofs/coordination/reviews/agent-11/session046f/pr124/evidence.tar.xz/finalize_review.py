#!/usr/bin/env python3
"""Inventory this review; do not execute proof tools or alter source snapshots."""
from pathlib import Path
import hashlib
import json

root = Path(__file__).resolve().parent
rows = []
for path in sorted(root.rglob('*')):
    if not path.is_file() or '__pycache__' in path.parts:
        continue
    relative = str(path.relative_to(root))
    if relative in {'FILES.json', 'SHA256SUMS'}:
        continue
    data = path.read_bytes()
    rows.append({'path': relative, 'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()})
(root / 'FILES.json').write_text(json.dumps(rows, indent=2) + '\n')
inventory = root / 'FILES.json'
checks = rows + [{'path': 'FILES.json', 'sha256': hashlib.sha256(inventory.read_bytes()).hexdigest()}]
(root / 'SHA256SUMS').write_text(''.join(f"{row['sha256']}  {row['path']}\n" for row in checks))
print(json.dumps({'files_in_inventory': len(rows), 'bytes_in_inventory': sum(row['bytes'] for row in rows),
                  'FILES_sha256': hashlib.sha256(inventory.read_bytes()).hexdigest(),
                  'SHA256SUMS_sha256': hashlib.sha256((root / 'SHA256SUMS').read_bytes()).hexdigest()}, indent=2))
