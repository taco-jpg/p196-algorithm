#!/usr/bin/env python3
"""Read-only verification of exact-source retained PR124 evidence; no Lean execution."""
from pathlib import Path
import collections
import hashlib
import importlib.util
import json
import re

ROOT = Path(__file__).resolve().parent
SNAP = ROOT / 'snapshot'
BASE = SNAP / 'proofs/contributions/agent-102/all-parameter-decisions-20261016'
OUT = ROOT / 'retained-audit'
OUT.mkdir(exist_ok=False)
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
read = lambda p: json.loads(p.read_text())
checks = []

def pin(base, name, expected, size=None):
    target = base / name
    assert target.is_relative_to(SNAP), target
    assert sha(target) == expected, (target, expected, sha(target))
    if size is not None:
        assert target.stat().st_size == size, target
    checks.append({'path': str(target.relative_to(SNAP)), 'sha256': expected})

registry = read(SNAP / 'proofs/Agent102AllParameters.registry.json')
modules = registry['projects']['agent102-all-parameter-decisions']['modules']
allowed = set(registry['toolchain']['allowed_axioms'])
assert allowed == {'propext', 'Classical.choice', 'Quot.sound'}
spec = importlib.util.spec_from_file_location('inspected_verifier', SNAP / 'proofs/verify_project__214bf7673efe116b.py')
verifier = importlib.util.module_from_spec(spec)
spec.loader.exec_module(verifier)
source_declarations = []
for name, entry in modules.items():
    pin(SNAP, entry['path'], entry['sha256'])
    path = SNAP / entry['path']
    data = path.read_bytes()
    assert hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest() == entry['git_blob']
    code = verifier.code_only(data.decode())
    assert re.findall(r'^import (\S+)$', code, re.M) == entry['imports']
    assert not re.search(r'\b(sorry|admit|sorryAx|axiom|unsafe|extern|native_decide|ofReduceBool|skipKernelTC|implemented_by)\b', code)
    stack = []
    for line in code.splitlines():
        if match := re.match(r'^namespace (\S+)$', line):
            stack.append(match[1])
        elif re.match(r'^end(?:\s+\S+)?$', line):
            if stack: stack.pop()
        elif match := re.match(r'^(?:@\[[^\]]*\]\s*)?(theorem|def|structure) (\S+)', line):
            source_declarations.append({'module': name, 'kind': match[1], 'name': '.'.join(stack + [match[2]])})

# Check every retained checksum-file row and structured file inventory.
for file in sorted(BASE.rglob('SHA256SUMS*')):
    for line in file.read_text().splitlines():
        match = re.fullmatch(r'([0-9a-f]{64})  (.+)', line)
        assert match, (file, line)
        pin(file.parent, match[2], match[1])
for file, key in [('root-author/ARCHIVE.json', 'retained'), ('word-author/ARCHIVE_MANIFEST.json', 'copied_files'), ('independent-semantic/REVIEW_INDEX.json', 'files')]:
    p = BASE / file
    for row in read(p)[key]: pin(p.parent, row['path'], row['sha256'], row['bytes'])
for row in read(BASE / 'runtime-independent/COPY_ORIGINS.json'):
    pin(BASE / 'runtime-independent', row['path'], row['sha256'], row['bytes'])
for name, row in read(BASE / 'exact-published-source/FILES.json').items():
    pin(BASE / 'exact-published-source', name, row['sha256'], row['bytes'])
for file in sorted(BASE.rglob('SOURCE_PINS.json')):
    for name, row in read(file).items(): pin(file.parent / 'source', name, row['sha256'], row['bytes'])
for name, value in read(BASE / 'word-author/final-001/manifest.json')['files_sha256'].items():
    pin(BASE / 'word-author/final-001', name, value)

runtime = BASE / 'runtime-independent/attempts/attempt-002'
exact = BASE / 'exact-published-source'
for module, entry in modules.items():
    for directory in [runtime / 'source', exact / 'agent102-all-parameter-decisions/source']:
        pin(directory, module + '.lean', entry['sha256'])
assert read(BASE / 'complete-literal/Agent102AllParameters.registry.json') == registry
assert (BASE / 'complete-literal/Agent102AllParameters.registry.json').read_bytes() == (SNAP / 'proofs/Agent102AllParameters.registry.json').read_bytes()
commands = read(runtime / 'verification.json')
assert len(commands) == 13
assert {row['module'] for row in commands} == set(modules) | {'LiteralAudit', 'ModuleOriginAudit', 'ExecutableDependencyAudit'}
for row in commands:
    assert row['returncode'] == 0
    assert row['command'][1:4] == ['--trust=0', '-j1', '-DElab.async=false']
    assert row['LEAN_PATH'] == '.'
    assert 'error:' not in (runtime / 'logs' / (row['module'] + '.log')).read_text()
environment = read(runtime / 'environment.json')
assert environment['preexisting_olean_used'] is False
assert environment['version'] == 'Lean (version 4.19.0, x86_64-unknown-linux-gnu, commit 6caaee842e94, Release)'
assert environment['lean_sha256'] == '92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023'

def origins(path):
    text = path.read_text()
    pattern = re.compile(r'^AUDIT_THEOREM (\S+) (\S+) : \[([^\]]*)\]', re.M)
    rows = [{'module': m, 'name': n, 'axioms': [a.strip() for a in axs.split(',') if a.strip()]} for m, n, axs in pattern.findall(text)]
    assert len(rows) == len({r['name'] for r in rows}) == 297
    for row in rows: assert set(row['axioms']) <= allowed, row
    unsafe = re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$', text, re.M)
    assert len(unsafe) == 7
    assert not re.search(r'CUSTOM_AXIOM|DISALLOWED_AXIOMS|sorryAx|error:', text)
    assert re.search(r'^FULL_MODULE_AUDIT theorems=297 union=\[Classical.choice, Quot.sound, propext\]$', text, re.M)
    return rows, unsafe

origin_rows, unsafe = origins(runtime / 'logs/ModuleOriginAudit.log')
exact_rows, exact_unsafe = origins(exact / 'agent102-all-parameter-decisions/logs/ProjectAudit.log')
assert sorted(origin_rows, key=lambda r: r['name']) == sorted(exact_rows, key=lambda r: r['name'])
assert sorted(unsafe) == sorted(exact_unsafe)
assert dict(collections.Counter(r['module'] for r in origin_rows)) == read(BASE / 'runtime-independent/MODULE_ORIGIN_COUNTS.json')
literal_pattern = re.compile(r"^'([^']+)' (?:depends on axioms:\s*\[([^\]]*)\]|(does not depend on any axioms))\s*$", re.M)
def literals(path):
    text = path.read_text()
    rows = [{'name': m[1], 'axioms': [] if m[3] else [a.strip() for a in m[2].split(',') if a.strip()]} for m in literal_pattern.finditer(text)]
    assert not literal_pattern.sub('', text).strip(), path
    assert len(rows) == len({r['name'] for r in rows})
    for row in rows: assert set(row['axioms']) <= allowed, row
    return rows

literal_rows = literals(BASE / 'complete-literal/run/LiteralAudit.log')
endpoints = registry['claims'][0]['endpoints'] + registry['literal_audit_extra_endpoints']
theorem_names = {r['name'] for r in source_declarations if r['kind'] == 'theorem'}
literal_commands = re.findall(r'^#print axioms (\S+)$', (BASE / 'complete-literal/LiteralAudit.lean').read_text(), re.M)
assert len(literal_rows) == len(theorem_names) == len(endpoints) == 146
assert set(endpoints) == theorem_names == set(r['name'] for r in literal_rows)
assert literal_commands == [r['name'] for r in literal_rows]
assert sum(not r['axioms'] for r in literal_rows) == 18
assert literal_rows == [{k: r[k] for k in ['name', 'axioms']} for r in read(BASE / 'complete-literal/run/PARSED_AXIOMS.json')]
new_rows = literals(runtime / 'logs/LiteralAudit.log')
assert len(new_rows) == 48 and sum(not r['axioms'] for r in new_rows) == 13
assert new_rows == read(BASE / 'runtime-independent/NEW_THEOREMS.json')
all_origin_map = {r['name']: r['axioms'] for r in origin_rows}
for row in literal_rows: assert set(row['axioms']) == set(all_origin_map[row['name']])
safe_two = literals(BASE / 'word-author/final-001/LiteralAudit.log')
assert len(safe_two) == 6
assert [r for r in safe_two if r['name'] in ['Agent102.compressedEqual', 'Agent102.equalAt']] == [
    {'name': 'Agent102.compressedEqual', 'axioms': []}, {'name': 'Agent102.equalAt', 'axioms': []}]

entry_log = (runtime / 'logs/ExecutableDependencyAudit.log').read_text()
entry_rows = re.findall(r'^EXECUTABLE_DEPENDENCY_CHECK (\S+) project_constants=(\d+) forbidden=0$', entry_log, re.M)
assert len(entry_rows) == len(set(r[0] for r in entry_rows)) == 10
assert not re.search(r'FORBIDDEN_EXECUTABLE_DEP|error:', entry_log)
assert 'BUILTIN_EXECUTABLE_DEP Agent102.allEqual List.range' in entry_log
assert 'BUILTIN_EXECUTABLE_DEP Agent102.someEqual List.range' in entry_log
exact_report = read(exact / 'verification.json')
assert exact_report['registry_sha256'] == sha(SNAP / 'proofs/Agent102AllParameters.registry.json')
assert exact_report['status'] == 'PASS' and exact_report['source_tree_clean'] is True
assert exact_report['repository_wide_pass'] is False and exact_report['catalogue_complete'] is False
assert exact_report['source_commit'] == '15d2e9cc9a6ed0ad68096b2c547c72f140087fb6'
project = exact_report['projects']['agent102-all-parameter-decisions']
assert len(project['commands']) == 11
for row in project['commands']:
    assert row['exit_code'] == 0
    pin(exact, row['log'], row['log_sha256'])

# Check original failed attempts remain distinguishable and their repairs are minimal.
history = []
for label, file in [('word', 'word-author/attempt-001/Agent102RunDecision.log'), ('root', 'root-author/attempt-001/Agent102AffineAllParameters.log'), ('controls', 'runtime-independent/attempts/attempt-001/logs/Agent102AllParameterControls.log')]:
    p = BASE / file
    text = p.read_text()
    assert 'error:' in text
    history.append({'group': label, 'path': str(p.relative_to(SNAP)), 'sha256': sha(p), 'errors': text.count('error:'), 'contains_recovery_sorryAx': 'sorryAx' in text})
old = (BASE / 'root-author/attempt-001/Agent102AffineAllParameters.lean').read_text()
new = (SNAP / 'proofs/Agent102AffineAllParameters.lean').read_text()
assert old.replace('Bool.not_eq_true]', "Bool.not_eq_true']") == new
old = (BASE / 'runtime-independent/attempts/attempt-001/source/Agent102AllParameterControls.lean').read_text()
new = (SNAP / 'proofs/Agent102AllParameterControls.lean').read_text()
assert new.replace('\n-- 压缩布尔项的内核归约需要比默认值更深的递归栈。\nset_option maxRecDepth 8192\n', '') == old

summary = {'status': 'PASS_RETAINED_EVIDENCE_CONSISTENCY_ONLY', 'lean_executed_by_this_script': False,
 'source_modules': len(modules), 'historical_clean_commands': len(commands), 'historical_origin_theorems': len(origin_rows),
 'historical_literal_theorems': len(literal_rows), 'explicit_axiom_free_theorems': 18, 'unsafe_generated_implementation_placeholders': unsafe,
 'explicit_safe_definitions_with_actual_literal_axiom_output': ['Agent102.compressedEqual', 'Agent102.equalAt'],
 'general_safe_definition_axiom_census_available': False, 'executable_dependency_entries': len(entry_rows),
 'checked_hash_rows': len(checks), 'checked_distinct_retained_paths': len({r['path'] for r in checks}),
 'standard_axiom_union': sorted({a for r in origin_rows for a in r['axioms']}),
 'origin_counts': dict(sorted(collections.Counter(r['module'] for r in origin_rows).items())),
 'historical_failed_attempts_preserved': history}
for name, data in [('RESULT.json', summary), ('checked-hashes.json', checks), ('origin-axioms.json', origin_rows), ('literal-axioms.json', literal_rows), ('source-declarations.json', source_declarations), ('historical-commands.json', commands)]:
    (OUT / name).write_text(json.dumps(data, indent=2) + '\n')
print(json.dumps(summary, indent=2))
