# Command provenance

This ledger distinguishes commands this reviewer actually executed from commands merely read in retained evidence. Shell read-only inspection (`cat`, `rg`, `ls`, `file`, and Python JSON/text inspection) did not execute the mathematical drivers. All filesystem writes by this reviewer were confined to `/workspace/scratch/046f9285a650/review124`.

## Fresh Git/source review operations

Working repository for the following read-only operations: `/workspace/scratch/046f9285a650/repo`.

```bash
git show 5ff4f607535587d572fbc9e95ba9501d1fbe5fc5:AGENTS.md
git show 5ff4f607535587d572fbc9e95ba9501d1fbe5fc5:proofs/PUBLICATION_POLICY.md
git diff --name-status 5ff4f607535587d572fbc9e95ba9501d1fbe5fc5...9361e8a8d13c731a4004b08957f4cd543b3ae38f
git diff --no-ext-diff 5ff4f607535587d572fbc9e95ba9501d1fbe5fc5...9361e8a8d13c731a4004b08957f4cd543b3ae38f
```

The name-status and diff bytes are retained as `changed-files.tsv` and `complete-pr.diff`. Python extraction issued `git show H:PATH` for every changed path, policy file, verifier file and module in the exact registry. The combination comparison issued `git show T:PATH` and `git show H:PATH` for every one of the 202 paths in `combined-byte-audit.json`, asserting byte equality. The source/blob comparison used `git rev-parse B:PATH` and `git rev-parse H:PATH`; its complete results are in `source-pins.json` and `verifier-policy-pins.json`. No checkout, index write, commit, ref write, merge or remote mutation was performed by this reviewer. Early repository listing was truncated and was not used as evidence of file coverage; the saved full name-status list was used instead.

An initial probe of `H:proofs/lean-toolchain` returned “path does not exist”; no such file was assumed or substituted. Toolchain identity comes from the actual registry and retained runtime records.

## Fresh Lean attempt

Only the following compiler invocation was attempted under default execution, initially after a successful `ls -l` of the binary:

```text
/workspace/scratch/8b5152316f75/runtime-agent1/toolchain/lean-4.19.0-linux/bin/lean --version
```

Result: exit 1, `error: failed to locate application`. The same argv was requested once with `sandbox_permissions=require_escalated`; the tool rejected the request before running it. Exact rejection text and the absence of a proof-build command are recorded in `LOCAL_EXECUTION.json`. No further compiler invocation occurred.

## Fresh evidence consistency execution

```bash
python /workspace/scratch/046f9285a650/review124/audit_retained.py > /workspace/scratch/046f9285a650/review124/retained-audit-execution.log 2>&1
```

The script completed with the explicit JSON result `PASS_RETAINED_EVIDENCE_CONSISTENCY_ONLY`. It creates its output directory with `exist_ok=False`, asserts every checked condition, and imports only the already inspected verifier module to use its comment/string masker; the verifier's `main` is not called. No Lean or historical author driver is invoked. This is the only new executed review script that performs source/evidence validation. Inline Python was also used for source extraction, byte/blob/hash comparison, complete-log parsing checks, metadata inspection, review coverage generation and runtime-file hashing; their products are retained and do not constitute additional mathematical tests.

## Historical commands, not rerun here

`retained-audit/historical-commands.json` contains all 13 original specialist clean-build command rows verbatim as JSON data, including argv, cwd, `LEAN_PATH`, returncode and duration. The original full evidence at H includes root-author and word-author command receipts and the complete-literal incremental invocation. Their original operator attribution is retained in `REVIEW.md`. No historical `.olean` was loaded, reused or newly checked by this reviewer.

## Artifact inventory generation

```bash
python /workspace/scratch/046f9285a650/review124/finalize_review.py
```

This operation hashes the retained review files, excludes reproducible `__pycache__`, and writes only `FILES.json` and `SHA256SUMS` inside this review directory. It does not invoke Lean, Git mutations or network calls.
