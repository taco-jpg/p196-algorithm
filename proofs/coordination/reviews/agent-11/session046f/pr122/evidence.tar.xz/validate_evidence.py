#!/usr/bin/env python3
"""Read-only PR122 source/evidence validation; never launches Lean or writes Git."""
import collections
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
import traceback

REPO = Path('/workspace/scratch/046f9285a650/repo')
ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'publish-evidence'
SNAP = ROOT / 'snapshot'
H = 'ae4e1f09a0bb75f1fa9a0eebabcefd0c362fc72a'
SOURCE = 'd1392154bcd67996045fa4779c23985ab87455cd'
BASE = 'bf4ff749000a6995e1755e37b59988ef362bae16'
MAIN = '1ee9123344dbe17e9bda224ff8af5b1cbb2b64e4'
PREFIX = 'proofs/contributions/agent-1/periodic-validity-20261016/'
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}
PINS = {}
sha = lambda b: hashlib.sha256(b).hexdigest()

def git(*args, check=True):
    return subprocess.run(['git', '-C', str(REPO), *args], check=check,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)

def read(path, commit=H):
    data = git('show', commit + ':' + path).stdout
    blob = git('rev-parse', commit + ':' + path).stdout.decode().strip()
    PINS[commit + ':' + path] = dict(commit=commit, path=path, bytes=len(data),
                                    sha256=sha(data), git_blob=blob,
                                    recovery_argv=['git', 'show', commit + ':' + path])
    return data

def obj(path, commit=H):
    return json.loads(read(path, commit))

def check(condition, message):
    if not condition:
        raise AssertionError(message)

def code_only(text):
    out, i, depth, string = [], 0, 0, False
    while i < len(text):
        pair = text[i:i+2]
        if depth:
            if pair == '/-': depth += 1; out.extend('  '); i += 2
            elif pair == '-/': depth -= 1; out.extend('  '); i += 2
            else: out.append('\n' if text[i] == '\n' else ' '); i += 1
        elif string:
            if text[i] == '\\': out.extend('  '); i += 2
            else: string = text[i] != '"'; out.append('\n' if text[i] == '\n' else ' '); i += 1
        elif pair == '/-': depth = 1; out.extend('  '); i += 2
        elif pair == '--':
            end = text.find('\n', i); end = len(text) if end < 0 else end
            out.extend(' ' * (end-i)); i = end
        elif text[i] == '"': string = True; out.append(' '); i += 1
        else: out.append(text[i]); i += 1
    check(not depth and not string, 'unterminated comment/string')
    return ''.join(out)

def audit(path, modules):
    log = read(path).decode()
    entries = re.findall(r'^AUDIT_THEOREM (\S+) (\S+) : \[([^\]]*)\]', log, re.M)
    summaries = re.findall(r'^FULL_MODULE_AUDIT theorems=(\d+) union=\[([^\]]*)\]', log, re.M)
    check(len(summaries) == 1, 'audit summary missing/duplicate')
    check(len(entries) == int(summaries[0][0]) == 1367, 'audit count mismatch')
    check(len({name for _, name, _ in entries}) == len(entries), 'duplicate theorem')
    check({m for m, _, _ in entries} == set(modules), 'module coverage mismatch')
    union = set()
    for module, name, raw in entries:
        axs = {x.strip() for x in raw.split(',') if x.strip()}
        check(axs <= ALLOWED, 'unsupported theorem axiom: ' + name)
        union |= axs
    check(union == ALLOWED == {x.strip() for x in summaries[0][1].split(',')}, 'axiom union')
    check(not re.search(r'^(?:CUSTOM_AXIOM|DISALLOWED_AXIOMS|MODULE_NOT_AUDITED)', log, re.M), 'audit rejection')
    unsafe = re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$', log, re.M)
    check(len(unsafe) == 13, 'unexpected unsafe implementation metadata')
    return dict(theorem_count=len(entries), theorem_counts_by_module=dict(collections.Counter(m for m,_,_ in entries)),
                axiom_union=sorted(union), unsafe_implementation_axioms=unsafe), entries

def main():
    OUT.mkdir(exist_ok=True)
    reg = obj('proofs/Agent1PeriodicValidity.registry.json')
    check(reg['source_baseline'] == BASE and not reg['catalogue_complete'], 'registry scope')
    check(set(reg['toolchain']['allowed_axioms']) == ALLOWED, 'registry axioms')
    spec = reg['projects']['agent1-periodic-validity']
    modules = spec['modules']
    check(len(modules) == 17 and spec['roots'] == ['Agent1PeriodicValidity'], 'registry roots/size')
    pinned = obj(PREFIX + 'review/final-source-identity.json')['sources']
    check(pinned == obj(PREFIX + 'review/clean-001/sources.json'), 'review manifests differ')
    check({e['module']: {k:v for k,v in e.items() if k != 'module'} for e in pinned} == modules, 'registry manifest mismatch')
    source_scan, current = {}, {}
    for module, rec in modules.items():
        data = read(rec['path'])
        check(sha(data) == rec['sha256'], module + ' SHA256 mismatch')
        check(PINS[H + ':' + rec['path']]['git_blob'] == rec['git_blob'], module + ' Git blob mismatch')
        check(read(rec['path'], SOURCE) == data, module + ' mathematical source commit drift')
        if module not in {'Agent1PeriodicParity','Agent1PeriodicPositivity','Agent1PeriodicValidity'}:
            check(read(rec['path'], BASE) == data, module + ' prerequisite changed')
        check(read(PREFIX + 'parent/clean-001/agent1-periodic-validity/source/' + module + '.lean') == data,
              module + ' canonical frozen source mismatch')
        if module.startswith('Agent1'):
            check(read(PREFIX + 'review/clean-001/' + module + '.lean') == data, module + ' reviewer source mismatch')
        code = code_only(data.decode())
        imports = [dep for line in re.findall(r'^\s*import\s+([^\n]+)', code, re.M) for dep in line.split()]
        check(imports == rec['imports'], module + ' imports mismatch')
        check(all(dep in modules or dep in {'Std','Init','Lean'} for dep in imports), module + ' foreign import')
        forbidden = re.findall(r'\b(?:sorry|admit|sorryAx|axiom|native_decide|ofReduceBool|skipKernelTC|extern|implemented_by|unsafe)\b', code)
        check(not forbidden, module + ' forbidden source token: ' + str(forbidden))
        source_scan[module] = dict(imports=imports, forbidden_tokens=forbidden,
                                  public_theorems=re.findall(r'^theorem\s+(\w+)', code, re.M),
                                  private_theorems=re.findall(r'^private\s+theorem\s+(\w+)', code, re.M))
        dest = SNAP / rec['path']; dest.parent.mkdir(parents=True, exist_ok=True); dest.write_bytes(data)
        old = git('cat-file', '-e', MAIN + ':' + rec['path'], check=False)
        current[module] = ('IDENTICAL' if read(rec['path'], MAIN) == data else 'DIFFERENT') if old.returncode == 0 else 'ABSENT'
    seen = set()
    def visit(m):
        if m in seen: return
        seen.add(m)
        for d in modules[m]['imports']:
            if d in modules: visit(d)
    visit('Agent1PeriodicValidity')
    check(seen == set(modules), 'registry is not full and exact root closure')
    results = obj(PREFIX + 'review/clean-001/results.json')
    check([r['module'] for r in results] == [*modules, 'ReviewAudit'], 'review compile order')
    for r in results:
        check(r['exit_code'] == 0, 'review nonzero exit')
        check(all(x in r['command'] for x in ['--trust=0','-j1','-DElab.async=false']), 'review trust flags')
        check(sha(read(PREFIX + 'review/clean-001/' + r['module'] + '.log')) == r['log_sha256'], 'review log hash')
    review_audit, review_entries = audit(PREFIX + 'review/clean-001/ReviewAudit.log', modules)
    parent = obj(PREFIX + 'parent/clean-001/verification.json')
    parent_project = parent['projects']['agent1-periodic-validity']
    check(parent['status'] == 'PASS' and parent_project['status'] == 'PASS', 'parent failure')
    check(parent['source_commit'] == BASE, 'unexpected parent source metadata')
    check(parent['registry_sha256'] == sha(read('proofs/Agent1PeriodicValidity.registry.json')), 'parent registry pin')
    for r in parent_project['commands']:
        check(r['exit_code'] == 0, 'parent nonzero exit')
        check(sha(read(PREFIX + 'parent/clean-001/' + r['log'])) == r['log_sha256'], 'parent log hash')
    parent_audit, parent_entries = audit(PREFIX + 'parent/clean-001/agent1-periodic-validity/logs/ProjectAudit.log', modules)
    check(review_entries == parent_entries, 'independent theorem audit differs from canonical audit')
    endpoints = [x for c in reg['claims'] for x in c['endpoints']]
    audited_names = {name for _,name,_ in review_entries}
    check(all(e in audited_names for e in endpoints), 'endpoint missing')
    new_public = []
    for m in ['Agent1PeriodicParity','Agent1PeriodicPositivity','Agent1PeriodicValidity']:
        for name in source_scan[m]['public_theorems']:
            full = 'Agent1.Periodic.' + name
            check(full in audited_names, 'new public theorem absent: ' + full)
            new_public.append(full)
    check(len(new_public) == 11, 'new public theorem count')
    check(any('outside_append_periods' in n for n in audited_names), 'private helper not audited')
    manifest_results = []
    for path, commit, prefix in [
        (PREFIX + 'EVIDENCE.json', H, ''),
        (PREFIX + 'CHECKPOINT001.json', SOURCE, ''),
        (PREFIX + 'parent/clean-001/FILES.json', H, PREFIX + 'parent/clean-001/'),
    ]:
        manifest = obj(path, commit)
        records = manifest.get('files', manifest)
        for rel, rec in records.items():
            b = read(prefix + rel, commit)
            check(sha(b) == rec['sha256'] and len(b) == rec['bytes'], 'manifest mismatch: ' + rel)
        manifest_results.append(dict(path=path, commit=commit, entries=len(records), status='PASS'))
    # Enumerate the complete contribution delta, including retained failed attempts.
    diff = git('diff', '--name-status', BASE, H).stdout.decode()
    check(all(line.startswith('A\t') for line in diff.splitlines()), 'non-additive contribution delta')
    for line in diff.splitlines(): read(line.split('\t', 1)[1])
    (OUT / 'contribution-diff.txt').write_text(diff)
    failure = obj(PREFIX + 'positive-author/attempt-001/run.json')
    check(failure['exit_code'] == 1, 'retained author failure missing')
    check(sha(read(PREFIX + 'positive-author/attempt-001/compile.log')) == failure['log_sha256'], 'author failure log')
    for p in ['AGENTS.md','proofs/PUBLICATION_POLICY.md','proofs/verify_project.py',
              'proofs/verify_project__214bf7673efe116b.py','proofs/periodic_word_quotient__8404d0a63dd1fa13.py']:
        read(p)
    for p in [PREFIX + 'review/replay.py', PREFIX + 'review/clean-001/ReviewAudit.lean',
              PREFIX + 'parent/clean-001/agent1-periodic-validity/source/ProjectAudit.lean']:
        read(p)
    compiler = obj(PREFIX + 'review/clean-001/compiler.json')
    check(compiler['sha256'] == '92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023', 'compiler hash')
    check('4.19.0' in compiler['version'] and '6caaee842e94' in compiler['version'], 'compiler version')
    return dict(status='PASS_RETAINED_EVIDENCE_IDENTITY_AND_SOURCE_CHECK', head=H, source_commit=SOURCE,
                prerequisite_head=BASE, main_compared=MAIN, module_count=len(modules),
                new_public_theorems=new_public, registry_endpoint_count=len(endpoints),
                source_scan=source_scan, root_closure_exact=True, current_main_modules=current,
                original_independent_commands=len(results), original_independent_trust=0,
                original_parent_commands=len(parent_project['commands']),
                original_parent_explicit_trust_flag=False, parent_prior_head_metadata_resolved_by_exact_source_bytes=True,
                original_review_audit=review_audit, original_parent_audit=parent_audit,
                compiler=compiler, manifests=manifest_results, contribution_files=len(diff.splitlines()),
                retained_failed_author_attempt=failure,
                fresh_lean='NOT_RUN', fresh_lean_reason='Known standard runtime failed to locate application; prior escalation rejected; no retry or bypass.',
                scope='Source identity and retained original audit validation, not a new Lean build or external peer review.')

if __name__ == '__main__':
    try:
        report = main()
        (OUT / 'validation.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps({k:report[k] for k in ['status','head','module_count','original_independent_commands','contribution_files','fresh_lean']}, indent=2))
    except Exception:
        OUT.mkdir(exist_ok=True)
        (OUT / 'validation-failure.txt').write_text(traceback.format_exc())
        raise
    finally:
        OUT.mkdir(exist_ok=True)
        (OUT / 'SOURCE_RECOVERY.json').write_text(json.dumps(dict(repository='https://github.com/taco-jpg/p196-algorithm',
            reason='Immutable original duplicates are referenced exactly rather than republished as a copied repository.',
            recovery='Each recovery_argv emits exact original bytes; redirect to the stated path in a separate reconstruction directory and verify SHA256.',
            files=list(PINS.values())), indent=2) + '\n')
