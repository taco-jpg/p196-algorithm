#!/usr/bin/env python3
"""Preserve only new review work; inventory originals by immutable recovery pins."""
import hashlib
import json
from pathlib import Path
import shutil

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'publish-evidence'
OLD = ROOT / 'snapshot/proofs/contributions/agent-1/periodic-validity-20261016'
sha = lambda b: hashlib.sha256(b).hexdigest()
fresh = json.loads((OUT/'diagnostics.stdout.json').read_text())
prior = json.loads((OLD/'review/diagnostics-001/stdout.json').read_text())
assert {k:v for k,v in fresh.items() if k != 'python'} == {k:v for k,v in prior.items() if k != 'python'}
old_runtime = json.loads((OLD/'parent/clean-001/verification.json').read_text())['compiler']['files']
old_by_name = {Path(p).name:h for p,h in old_runtime.items()}
new_runtime = {}
for line in (OUT/'runtime-readonly-hashes.log').read_text().splitlines():
    digest, path = line.split(maxsplit=1)
    assert old_by_name[Path(path).name] == digest
    new_runtime[path] = digest
for name in ['validate_evidence.py','check_current_combo.py','package_inventory.py']:
    shutil.copyfile(ROOT/name, OUT/name)
(OUT/'packaging-checks.json').write_text(json.dumps(dict(
    status='PASS', new_diagnostic_result='MATCH_ORIGINAL_EXCEPT_PYTHON_VERSION',
    read_only_runtime_identity='FIVE_FILES_MATCH_ORIGINAL_PARENT_INVENTORY'),indent=2)+'\n')
receipt = dict(
    status='QUALIFIED_ACCEPT_NO_SOURCE_BLOCKER',
    reviewed_head='ae4e1f09a0bb75f1fa9a0eebabcefd0c362fc72a',
    observed_main='61ac3b85eb3049805ae25260dbd628f007187e59',
    source_and_original_meaning_review='PASS',
    exact_source_and_retained_evidence_validation='PASS',
    current_main_prerequisite_identity='PASS_14_OF_14',
    new_finite_diagnostics='PASS_16_VALID_10_INVALID_48_TRANSITIONS',
    new_diagnostic_results_match_original_except_python_version=True,
    runtime_readonly_hashes_match_original_parent_inventory=True,
    original_independent_lean=dict(trust=0, modules=17, commands=18, all_exit_codes=0, theorem_audit_rows=1367,
        axiom_union=['propext','Classical.choice','Quot.sound'], unsafe_compiler_metadata_entries=13,
        unsupported_theorem_dependencies=0),
    fresh_lean='NOT_RUN',
    new_lean_commands=0,
    new_lean_source_modules_compiled=0,
    fresh_lean_reason='Known standard-launch failure and previously rejected escalation; no rerun or bypass.',
    new_escalations_or_bypasses=0,
    original_failed_author_attempt_preserved=True,
    new_operational_failures_preserved=True,
    mathematical_source_authorship=False,
    external_peer_review=False,
    registry_catalogue_complete=False,
    source_repair_requested=False,
    final_current_main_gate_owner='root',
    forbidden_promotions=['safe-state closure','successor exponent at least three','ordinary-integer realization',
                          'infinite palindrome avoidance','decimal Lychrel existence','196 proof'])
(OUT/'REVIEW_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
entries = []
for p in sorted(OUT.iterdir()):
    if p.is_file() and p.name != 'ARTIFACT_INVENTORY.json':
        data = p.read_bytes()
        entries.append(dict(path=p.name, bytes=len(data), sha256=sha(data)))
(OUT/'ARTIFACT_INVENTORY.json').write_text(json.dumps(dict(
    status='COMPLETE_NEW_REVIEW_WORK', files=entries,
    inventory_self='Excluded from self-hash; publication Git supplies exact identity.',
    original_duplicates='Referenced by exact Git pins and recovery commands in SOURCE_RECOVERY.json and CURRENT_MAIN_SOURCE_RECOVERY.json.',
    excluded_infrastructure=['duplicate snapshot/ checkout','runtime installation','compiled objects','caches']),indent=2)+'\n')
print(json.dumps(dict(status='PASS',new_artifacts_excluding_inventory=len(entries),
                     bytes_excluding_inventory=sum(e['bytes'] for e in entries),
                     diagnostic_comparison='MATCH_EXCEPT_PYTHON_VERSION',runtime_identity='FIVE_FILES_MATCH'),indent=2))
