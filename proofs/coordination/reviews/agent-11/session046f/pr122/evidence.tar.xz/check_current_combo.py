#!/usr/bin/env python3
"""Read-only exact-source identity test against the observed post-PR111 main."""
import hashlib
import json
from pathlib import Path
import subprocess

REPO = '/workspace/scratch/046f9285a650/repo'
OUT = Path(__file__).resolve().parent / 'publish-evidence'
H = 'ae4e1f09a0bb75f1fa9a0eebabcefd0c362fc72a'
BASE = 'bf4ff749000a6995e1755e37b59988ef362bae16'
MAIN = '61ac3b85eb3049805ae25260dbd628f007187e59'

def git(*args, check=True):
    return subprocess.run(['git', '-C', REPO, *args], check=check,
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE)

def present(commit, path):
    return git('cat-file', '-e', commit + ':' + path, check=False).returncode == 0

def data(commit, path):
    return git('show', commit + ':' + path).stdout

reg = json.loads(data(H, 'proofs/Agent1PeriodicValidity.registry.json'))
modules = reg['projects']['agent1-periodic-validity']['modules']
rows, pins = [], []
new = {'Agent1PeriodicParity','Agent1PeriodicPositivity','Agent1PeriodicValidity'}
for module, rec in modules.items():
    expected = data(H, rec['path'])
    exists = present(MAIN, rec['path'])
    if module in new:
        assert not exists, 'new module already exists: ' + module
        row = dict(module=module, path=rec['path'], status='SUPPLIED_BY_EXACT_H')
    else:
        assert exists and data(MAIN, rec['path']) == expected, 'prerequisite differs: ' + module
        row = dict(module=module, path=rec['path'], status='CURRENT_MAIN_IDENTICAL')
        pins.append(dict(commit=MAIN, path=rec['path'], bytes=len(expected),
                         sha256=hashlib.sha256(expected).hexdigest(),
                         git_blob=git('rev-parse', MAIN+':'+rec['path']).stdout.decode().strip(),
                         recovery_argv=['git','show',MAIN+':'+rec['path']]))
    rows.append(row)
delta = git('diff','--name-only',BASE,H).stdout.decode().splitlines()
collisions = [p for p in delta if present(MAIN,p)]
assert not collisions, collisions
report = dict(status='PASS_SOURCE_COMBO_ONLY', reviewed_head=H, prerequisite_head=BASE,
              observed_main=MAIN, current_main_prerequisites_identical=14, new_source_modules=3,
              contribution_paths=len(delta), contribution_path_collisions=collisions,
              modules=rows, fresh_lean='NOT_RUN',
              qualification='Exact H supplies the three new modules on the byte-identical 14-module prerequisite closure. Root owns subsequent current-main refresh, mergeability and final merge gate; this is not a new Lean execution.')
(OUT/'current-combo.json').write_text(json.dumps(report,indent=2)+'\n')
(OUT/'CURRENT_MAIN_SOURCE_RECOVERY.json').write_text(json.dumps(dict(files=pins),indent=2)+'\n')
print(json.dumps({k:report[k] for k in ['status','reviewed_head','observed_main','current_main_prerequisites_identical','new_source_modules','contribution_path_collisions','fresh_lean']},indent=2))
