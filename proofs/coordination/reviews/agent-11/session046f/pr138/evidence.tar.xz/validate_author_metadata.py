"""Check all retained author receipts and record exact development-source deltas."""
import difflib, hashlib, json, pathlib
ROOT=pathlib.Path('/dev/shm/p196-agent11-046f/review138')
SRC=ROOT/'source'; B=SRC/'proofs/contributions/agent-100/groupII-rebase-20261016'
def read(p):return json.loads(p.read_text())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
checks=[]
for rec in read(B/'development/algebra/evidence-manifest.json')['files']:
    p=SRC/rec['path'];assert p.stat().st_size==rec['bytes'] and sha(p)==rec['sha256'];checks.append(rec['path'])
for name,exit_code in [('attempt01',1),('attempt02',0),('definition-audit',0)]:
    rec=read(B/f'development/algebra/{name}.json')
    assert rec['exit_code']==exit_code
    assert sha(B/f'development/algebra/{name}.lean')==rec['source_sha256']
    assert sha(B/f'development/algebra/{name}.log')==rec['log_sha256']
for rec in read(B/'development/profiles/author-execution.json')['sequence']:
    for kind in ['source','log']:
        if kind in rec:
            pin=rec[kind];assert sha(SRC/'proofs'/pin['path'])==pin['sha256']
    for pin in rec.get('files',[]):assert sha(SRC/'proofs'/pin['path'])==pin['sha256']
    assert rec['exit_code']==(1 if rec['name']=='positions-attempt01' else 0)
numeric=read(B/'development/numeric/attempt01/receipt.json')
assert numeric['exit_code']==0
assert sha(B/'development/numeric/attempt01/Agent100GroupIIRebaseNumeric.lean')==numeric['source_sha256']
assert sha(B/'development/numeric/attempt01/compile.log')==numeric['log_sha256']
for module,path in [('Algebra','development/algebra/attempt02.lean'),('Algebra','development/algebra/attempt02/Agent100GroupIIRebaseAlgebra.lean'),('Profiles','development/profiles/full-attempt01/Agent100GroupIIRebaseProfiles.lean'),('Numeric','development/numeric/attempt01/Agent100GroupIIRebaseNumeric.lean')]:
    assert (B/path).read_bytes()==(SRC/f'proofs/Agent100GroupIIRebase{module}.lean').read_bytes()
diffs=[]
for rel in ['development/algebra/attempt01.lean','development/profiles/positions-attempt01/Agent100GroupIIRebaseProfiles.lean','development/profiles/positions-attempt02/Agent100GroupIIRebaseProfiles.lean']:
    target='Agent100GroupIIRebaseAlgebra.lean' if 'algebra' in rel else 'Agent100GroupIIRebaseProfiles.lean'
    diffs.extend(difflib.unified_diff((B/rel).read_text().splitlines(True),(SRC/'proofs'/target).read_text().splitlines(True),fromfile=rel,tofile=target))
(ROOT/'evidence/development-source-deltas.diff').write_text(''.join(diffs))
parsed=[]
for path in B.rglob('*.json'):
    read(path);parsed.append(str(path.relative_to(B)))
result={'status':'PASS_AUTHOR_METADATA_INTEGRITY','executor':'Agent #11 / session046f / review138','all_json_documents_parsed':parsed,'algebra_manifest_verified':checks,'successful_author_snapshots_equal_exact_head':True,'author_failures_retained_and_excluded':[{'source':'development/algebra/attempt01.lean','exit_code':1,'diagnosis':'Incomplete zero-boundary simplification, nonexistent Nat.cast_add, and pointwise rewrite beneath shiftOne; repaired with simp and a funext equality in attempt02.'},{'source':'development/profiles/positions-attempt01/Agent100GroupIIRebaseProfiles.lean','exit_code':1,'diagnosis':'Ambiguous componentDoubleCarry; qualified GroupIIOverflow.componentDoubleCarry in positions-attempt02.'}],'failed_error_recovery_sorryAx_not_accepted':True}
(ROOT/'evidence/author-metadata-validation.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
