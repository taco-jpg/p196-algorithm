import hashlib, json, os, pathlib, re, subprocess
ROOT = pathlib.Path('/dev/shm/p196-agent11-046f/review138')
REPO = '/workspace/scratch/046f9285a650/repo'
H = '40670be3636e4ee7e3158e0d1577d26472a4a2a0'
B = '686cac2696e4e4e059c1b9d6a313f5519f6f4176'
os.environ['GIT_OBJECT_DIRECTORY'] = str(ROOT/'objects')
os.environ['GIT_ALTERNATE_OBJECT_DIRECTORIES'] = '/dev/shm/p196-agent11-046f/objects:'+REPO+'/.git/objects'
def git(*args):
    return subprocess.check_output(['git','-C',REPO,*args])
records = {}
def extract(path):
    if path in records: return (ROOT/'source'/path).read_bytes()
    data = git('show',H+':'+path)
    p=ROOT/'source'/path; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(data)
    records[path]={'commit':H,'path':path,'blob':git('rev-parse',H+':'+path).decode().strip(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
    return data
paths = git('diff','--name-only','--no-renames',B,H).decode().splitlines()
for p in paths: extract(p)
for p in ['AGENTS.md','proofs/PUBLICATION_POLICY.md','proofs/ACCEPTED_BUILD.json','proofs/verify_project.py']:
    extract(p)
reg=json.loads(extract('proofs/contributions/agent-100/groupII-rebase-20261016/verification/reviewer-registry.json'))
modules=reg['projects']['groupii-rebase']['modules']
closure=[]
for name,meta in modules.items():
    p=meta['path']; closure.append(p); data=extract(p)
    assert records[p]['sha256']==meta['sha256'],name
    assert records[p]['blob']==meta['git_blob'],name
    imports=re.findall(r'^import\s+(\S+)',data.decode(),re.M)
    assert imports==meta['imports'],(name,imports)
    assert all(i in modules or i in ['Std','Lean','Init'] for i in imports),(name,imports)
(ROOT/'evidence/source-recovery-map.json').write_text(json.dumps({'head':H,'base':B,'delta_paths':paths,'closure':closure,'files':list(records.values())},indent=2)+'\n')
print(json.dumps({'delta_files':len(paths),'source_closure_count':len(closure),'closure':closure,'extracted_files':len(records)},indent=2))
