"""Bounded, read-only validation of exact-head retained PR138 evidence. No Lean invocation."""
import collections, hashlib, io, json, lzma, os, pathlib, re, subprocess, tarfile
ROOT=pathlib.Path('/dev/shm/p196-agent11-046f/review138')
BASE=ROOT/'source/proofs/contributions/agent-100/groupII-rebase-20261016'
OUT=ROOT/'evidence'; ARCH=ROOT/'decoded'
H='40670be3636e4ee7e3158e0d1577d26472a4a2a0'
M='bc178ab8735e9503ab25b325e5a8dc82bf1f1e37'
P125='71fa669acdff9ee203ef28d7db7e31e2f9b5b4af'
REPO='/workspace/scratch/046f9285a650/repo'
os.environ['GIT_OBJECT_DIRECTORY']=str(ROOT/'objects')
os.environ['GIT_ALTERNATE_OBJECT_DIRECTORIES']='/dev/shm/p196-agent11-046f/objects:'+REPO+'/.git/objects'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
def git(*a):return subprocess.check_output(['git','-C',REPO,*a])
def check(data,rec):
    assert len(data)==rec['bytes'],rec
    assert sha(data)==rec['sha256'],rec
manifest=read(BASE/'verification/reviewer-evidence-archive-manifest.json')
compressed=(BASE/'verification/reviewer-complete-evidence.tar.xz').read_bytes()
assert len(compressed)==manifest['stored_bytes'] and sha(compressed)==manifest['stored_sha256']
decoded=lzma.decompress(compressed)
assert len(decoded)==manifest['decoded_tar_bytes'] and sha(decoded)==manifest['decoded_tar_sha256']
members={r['path']:r for r in manifest['members']}
with tarfile.open(fileobj=io.BytesIO(decoded),mode='r:') as tar:
    assert len(tar.getmembers())==len(members)==66
    assert {m.name for m in tar.getmembers()}==set(members)
    for member in tar.getmembers():
        assert member.isfile() and not pathlib.PurePosixPath(member.name).is_absolute() and '..' not in pathlib.PurePosixPath(member.name).parts
        data=tar.extractfile(member).read();check(data,members[member.name])
        if (BASE/member.name).is_file(): assert (BASE/member.name).read_bytes()==data,member.name
        path=ARCH/member.name;path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(data)
run=ARCH/'verification/reviewer-independent01'
reg=read(BASE/'verification/reviewer-registry.json');mods=reg['projects']['groupii-rebase']['modules']
report=read(run/'verification.json');proj=report['projects']['groupii-rebase']
invocation=read(run/'independent-invocation.json')
assert report['status']=='PASS' and proj['status']=='PASS'
assert invocation['exit_code']==0 and invocation['prior_author_oleans_used'] is False
assert invocation['executor']=='Agent #100 scope_audit independent reviewer'
assert sha((run/'verification.json').read_bytes())==invocation['verification_sha256']
assert sha((BASE/'verification/reviewer-registry.json').read_bytes())==report['registry_sha256']==invocation['registry_sha256']
assert report['source_commit']==invocation['source_commit']=='686cac2696e4e4e059c1b9d6a313f5519f6f4176'
pinrows=[]
for module,meta in mods.items():
    snapshot=(run/'groupii-rebase/source'/f'{module}.lean').read_bytes()
    current=(ROOT/'source'/meta['path']).read_bytes()
    assert current==snapshot==git('show',M+':'+meta['path'])
    assert sha(current)==meta['sha256']
    assert hashlib.sha1(f'blob {len(current)}\0'.encode()+current).hexdigest()==meta['git_blob']
    assert re.findall(r'^import\s+(\S+)',current.decode(),re.M)==meta['imports']
    assert proj['sources'][module]['sha256']==proj['sources'][module]['build_sha256']==meta['sha256']
    assert proj['sources'][module]['adapter'] is None
    if 'Rebase' not in module: assert git('show',P125+':'+meta['path'])==current
    pinrows.append({'module':module,'path':meta['path'],'git_blob':meta['git_blob'],'bytes':len(current),'sha256':meta['sha256'],'imports':meta['imports'],'reviewed_commit':H,'retained_math_commit':M})
files=read(run/'FILES.json')
for name,record in files.items():check((run/name).read_bytes(),record)
assert len(proj['commands'])==22 and len(proj['build_order'])==21
for command in proj['commands']:
    assert command['exit_code']==0 and command['elapsed_seconds']>=0
    assert '--trust=0' not in command['argv']
    assert sha((run/command['log']).read_bytes())==command['log_sha256']
    assert ': error:' not in (run/command['log']).read_text()
strict=read(BASE/'verification/reviewer-strict01/strict-import-verification.json')
strictlog=(BASE/'verification/reviewer-strict01/ProjectAudit-trust0.log').read_bytes()
assert strict['exit_code']==0 and strict['explicit_trust_level']==0
assert strict['argv'][1:]==['--trust=0','-j1','-DElab.async=false','ProjectAudit.lean']
assert strict['not_a_second_fresh21_source_build'] is True
assert strict['prior_fresh_local_modules']==21 and strict['all_source_and_fresh_olean_posthashes_unchanged'] is True
assert sha(strictlog)==strict['log_sha256']
assert strict['official_lean_sha256']==list(report['compiler']['files'].values())[0]
canonical=(run/'groupii-rebase/logs/ProjectAudit.log').read_bytes()
assert canonical==strictlog
allowed={'propext','Classical.choice','Quot.sound'}
def parse(text):
    ledger={}
    pattern=r'^AUDIT_THEOREM\s+(\S+)\s+(\S+)\s*:\s*\[([^\]]*)\]'
    for match in re.finditer(pattern,text,re.M):
        origin,name,body=match.groups();axioms=[v.strip() for v in body.split(',') if v.strip()]
        assert name not in ledger and set(axioms)<=allowed and len(axioms)==len(set(axioms))
        ledger[name]={'module':origin,'axioms':axioms}
    return ledger
ledger=parse(canonical.decode());stored=read(BASE/'verification/reviewer-complete-axiom-ledger.json')
assert len(ledger)==2661==proj['theorem_count']
assert ledger==stored['full_module_origin_ledger']==strict['full_module_origin_ledger']
assert set(a for r in ledger.values() for a in r['axioms'])==allowed
assert re.findall(r'^FULL_MODULE_AUDIT theorems=(\d+) union=',canonical.decode(),re.M)==['2661']
unsafe=re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$',canonical.decode(),re.M)
assert len(unsafe)==14 and set(unsafe)=={tuple(x) for x in proj['unsafe_implementation_axioms']}
printed={}
for module in mods:
    raw=(run/'groupii-rebase/logs'/f'{module}.log').read_text()
    for name,body in re.findall(r"^'([^']+)'\s+depends on axioms:\s*\[([^\]]*)\]",raw,re.M):
        printed[name]=set(x.strip() for x in body.split(',') if x.strip())
    for name in re.findall(r"^'([^']+)'\s+does not depend on any axioms",raw,re.M):printed[name]=set()
exports=[e for c in reg['claims'] for e in c['endpoints']]
assert len(exports)==22 and len(set(exports))==22
for name in exports:
    assert printed[name]==set(ledger[name]['axioms'])==set(stored['new_explicit_exports'][name]['printed_axioms'])
assert sum(len(printed[n])==2 for n in exports)==14 and sum(len(printed[n])==3 for n in exports)==8
assert sum('Rebase' in r['module'] for r in ledger.values())==85
# Recompute each retained bounded ordinary-number trajectory directly, without importing its generator.
def pair(n):
    d=[int(x) for x in str(n)[::-1]];return [a+b for a,b in zip(d,d[::-1])]
def overlap(w):return [w[0]]+[a+b for a,b in zip(w,w[1:])]+[w[-1]]
controls_bytes=lzma.decompress((BASE/'controls/reviewer-ordinary-controls.json.xz').read_bytes())
assert controls_bytes==(ARCH/'controls/reviewer-ordinary-controls.json').read_bytes()
cm=read(BASE/'controls/reviewer-controls-manifest.json')
assert sha(controls_bytes)==cm['raw_json_sha256'] and len(controls_bytes)==cm['raw_json_bytes']
controls=json.loads(controls_bytes); rows=controls['rows'];assert len(rows)==105
checked_additions=0
for row in rows:
    r,p,u,v=[row[k] for k in ('r','p','u','v')]
    assert r in (1,2,7) and 5<=p<=9 and 5<=u<=8 and 5<=v<=6 and u+v<=13
    for variant in row['variants']:
        for prefix in ('component','whole'):
            nums=[int(n) for n in variant[prefix+'_numbers_t0_t1_t2']]
            assert all(nums[i+1]==nums[i]+int(str(nums[i])[::-1]) for i in (0,1));checked_additions+=2
            assert [pair(n) for n in nums]==variant[prefix+'_pair_words_t0_t1_t2']
        a2=variant['component_pair_words_t0_t1_t2'][2];q2=variant['whole_pair_words_t0_t1_t2'][2]
        assert len(a2)==2*r+7 and len(q2)==2*r+8
        delta=[1 if i in (r+1,r+5) else -1 if i in (r+2,r+4) else 0 for i in range(len(a2))]
        c=[a+b for a,b in zip(a2,delta)]
        assert c==variant['rebased_int_before_toNat']==variant['rebased_nat_after_toNat']
        assert min(c)>=0 and max(c)<=18 and c==c[::-1] and c[len(c)//2]%2==0 and c[0]>0
        assert overlap(c)==q2 and c[r+1]-a2[r+1]==1
        for witness in variant['rebased_positive_canonical_realizations']:assert int(witness)>0 and pair(int(witness))==c
assert checked_additions==840
author=read(BASE/'controls/author-compression.json')
author_bytes=lzma.decompress((BASE/author['archive']['path']).read_bytes())
assert author_bytes==(BASE/author['original']['path']).read_bytes();check(author_bytes,author['original'])
author_rows=[json.loads(line) for line in author_bytes.splitlines()];assert len(author_rows)==490
for row in author_rows:
    assert row['passed'] and all(row['checks'].values())
    assert [a+b for a,b in zip(row['A2'],row['Delta'])]==row['CInt'] and overlap(row['CInt'])==row['Q2']
    assert min(row['CInt'])>=0 and max(row['CInt'])<=18
source_scan={}
def remove_comments(text):
    result=[]; i=0; depth=0
    while i<len(text):
        if text.startswith('/-',i):depth+=1;i+=2
        elif depth and text.startswith('-/',i):depth-=1;i+=2
        elif depth:i+=1
        elif text.startswith('--',i):
            end=text.find('\n',i);i=len(text) if end<0 else end
        else:result.append(text[i]);i+=1
    assert depth==0
    return ''.join(result)
for module,meta in mods.items():
    text=remove_comments((ROOT/'source'/meta['path']).read_text())
    # Nested Lean comments may describe exclusions; remove them before this supplementary scan.
    bad=[line for line in text.splitlines() if re.match(r'^\s*(axiom\s|.*:=\s*(sorry|admit)\b|.*\b(native_decide|sorryAx|Lean\.ofReduceBool)\b)',line)]
    assert not bad,(module,bad)
    source_scan[module]={'bad_executable_lines':bad}
summary={'status':'PASS_RETAINED_EVIDENCE_VALIDATION','executor':'Agent #11 / session046f / independent review138 subagent','reviewed_head':H,'original_branch_base':'686cac2696e4e4e059c1b9d6a313f5519f6f4176','actual_pr125_head':P125,'complete_math_source_commit':M,'archive_members_verified':66,'all_exact_head_sources_equal_retained_snapshots_and_math_commit':True,'source_modules':21,'new_explicit_exports':22,'retained_canonical_commands':22,'retained_canonical_command_exits':[x['exit_code'] for x in proj['commands']],'retained_canonical_explicit_trust0':False,'retained_strict_import_audit_exit':0,'retained_strict_import_trust':0,'retained_executor':invocation['executor'],'full_module_theorems':2661,'new_module_theorems':85,'actual_axioms':sorted(allowed),'new_export_two_axiom_count':14,'new_export_three_axiom_count':8,'unsafe_implementation_symbols_separately_reported':14,'ordinary_rows_recomputed':105,'ordinary_additions_recomputed':checked_additions,'author_rows_integrity_checked':490,'fresh_lean':'NOT_RUN','fresh_lean_reason':'Root reported ordinary launch failure and auto-review rejection; no retry, escalation, alternate execution, or outsourcing attempted by this reviewer.','source_scan':source_scan}
(OUT/'retained-validation.json').write_text(json.dumps(summary,indent=2)+'\n')
(OUT/'canonical-source-pins.json').write_text(json.dumps({'reviewed_head':H,'complete_math_source_commit':M,'original_branch_base':summary['original_branch_base'],'actual_pr125_head':P125,'registry_path':'proofs/contributions/agent-100/groupII-rebase-20261016/verification/reviewer-registry.json','registry_sha256':report['registry_sha256'],'compiler':report['compiler'],'modules':pinrows},indent=2)+'\n')
print(json.dumps({k:v for k,v in summary.items() if k!='source_scan'},indent=2))
