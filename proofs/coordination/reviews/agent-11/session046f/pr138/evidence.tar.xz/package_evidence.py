"""Package new review records; map original duplicate evidence to immutable recovery coordinates."""
import hashlib,json,os,pathlib,shutil,subprocess
ROOT=pathlib.Path('/dev/shm/p196-agent11-046f/review138')
PUB=ROOT/'publish-evidence'; PUB.mkdir(exist_ok=True)
REPO='/workspace/scratch/046f9285a650/repo'
H='40670be3636e4ee7e3158e0d1577d26472a4a2a0'
os.environ['GIT_OBJECT_DIRECTORY']=str(ROOT/'objects')
os.environ['GIT_ALTERNATE_OBJECT_DIRECTORIES']='/dev/shm/p196-agent11-046f/objects:'+REPO+'/.git/objects'
def sha(b):return hashlib.sha256(b).hexdigest()
def blob(b):return hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
original=[]
for p in sorted((ROOT/'source').rglob('*')):
    if not p.is_file():continue
    rel=str(p.relative_to(ROOT/'source'));data=p.read_bytes()
    expected=subprocess.check_output(['git','-C',REPO,'rev-parse',H+':'+rel],text=True).strip()
    assert blob(data)==expected
    original.append({'repository':'taco-jpg/p196-algorithm','commit':H,'path':rel,'blob':expected,'bytes':len(data),'sha256':sha(data),'recovery_command':f'git show {H}:{rel} > RECOVERED_FILE'})
archive_path='proofs/contributions/agent-100/groupII-rebase-20261016/verification/reviewer-complete-evidence.tar.xz'
archive_record=next(r for r in original if r['path']==archive_path)
decoded=[]
for p in sorted((ROOT/'decoded').rglob('*')):
    if p.is_file():
        data=p.read_bytes();rel=str(p.relative_to(ROOT/'decoded'))
        decoded.append({'archive_commit':H,'archive_path':archive_path,'archive_blob':archive_record['blob'],'member':rel,'bytes':len(data),'sha256':sha(data),'recovery_command':f'git show {H}:{archive_path} | tar -xOJf - {rel} > RECOVERED_FILE'})
source=pathlib.Path('/dev/shm/p196-agent11-046f/review125')
provenance=json.loads((source/'lean419-source-provenance.json').read_text())
name_map={'src/Lean/Environment.lean':'Environment.lean','src/util/shell.cpp':'shell.cpp','src/kernel/type_checker.cpp':'type_checker.cpp','src/Lean/Elab/Frontend.lean':'Frontend.lean','src/Lean/Language/Lean.lean':'LanguageLean.lean','src/kernel/environment.cpp':'environment.cpp','src/kernel/environment.h':'environment.h','src/Lean/Elab/Import.lean':'Import.lean','src/Lean/AddDecl.lean':'AddDecl.lean'}
official=[]
for rec in provenance:
    data=(source/('lean419-'+name_map[rec['path']])).read_bytes()
    assert blob(data)==rec['blob']
    official.append({**rec,'bytes':len(data),'sha256':sha(data),'independently_checked_git_blob':True,'original_retrieval_owner':'Agent #11 review125; current reviewer independently read relevant source sections and checked blob identities'})
(ROOT/'evidence/original-recovery-map.json').write_text(json.dumps({'repository_originals':original,'archive_members':decoded,'official_lean_sources':official,'excluded_duplicates':'Original source, raw logs, all data, and archives remain immutable at the listed commits. Recovery mappings replace duplicate copies in this compact review package. No substantive original evidence is deleted.','excluded_infrastructure':'Git objects, extracted duplicate trees, temporary decoded copies, runtime/build/cache artifacts are reproducible infrastructure and are not republished.'},indent=2)+'\n')
for filename in ['REVIEW.md','ERRATUM_REVIEW.md','extract.py','validate_retained.py','validate_author_metadata.py','package_evidence.py']:
    shutil.copyfile(ROOT/filename,PUB/filename)
dest=PUB/'evidence';dest.mkdir(exist_ok=True)
for p in sorted((ROOT/'evidence').iterdir()):
    if p.is_file():shutil.copyfile(p,dest/p.name)
summary={'status':'PACKAGED','directory':str(PUB),'original_recovery_records':len(original),'archive_member_recovery_records':len(decoded),'official_source_records':len(official),'fresh_lean':'NOT_RUN','erratum_candidate_sha256':'a516f682dc643f68647224d4ba2b9a31016c12b246197b30787a3cd60acbb350'}
summary_text=json.dumps(summary,indent=2)+'\n'
(ROOT/'evidence/package.log').write_text(summary_text)
(PUB/'evidence/package.log').write_text(summary_text)
records=[]
for p in sorted(PUB.rglob('*')):
    if p.is_file() and p.name!='FILES.json':
        data=p.read_bytes();records.append({'path':str(p.relative_to(PUB)),'bytes':len(data),'sha256':sha(data)})
(PUB/'FILES.json').write_text(json.dumps({'status':'PACKAGED','executor':'Agent #11 / session046f / independent review138','files':records,'file_count_excluding_this_manifest':len(records),'file_content_bytes_excluding_this_manifest':sum(x['bytes'] for x in records)},indent=2)+'\n')
print(summary_text,end='')
