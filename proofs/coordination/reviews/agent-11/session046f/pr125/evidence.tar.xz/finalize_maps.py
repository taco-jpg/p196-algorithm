import pathlib,json,hashlib,re
R=pathlib.Path('/dev/shm/p196-agent11-046f/review125');C='proofs/contributions/agent-100/groupII-overflow-sharpness-20261016'
prov=json.loads((R/'lean419-source-provenance.json').read_text()); names=['Environment.lean','shell.cpp','type_checker.cpp','Frontend.lean','LanguageLean.lean','environment.cpp','environment.h','Import.lean','AddDecl.lean']
for rec,local in zip(prov,names):
 p=R/('lean419-'+local);raw=p.read_bytes()
 def blob(b):return hashlib.sha1(f'blob {len(b)}\0'.encode()+b).hexdigest()
 # apply_patch may add a trailing empty line; retain exactly the connector source bytes.
 while blob(raw)!=rec['blob'] and raw.endswith(b'\n'):raw=raw[:-1]
 assert blob(raw)==rec['blob'],str(p);p.write_bytes(raw);rec.update(local=p.name,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest())
(R/'lean419-source-provenance.json').write_text(json.dumps(prov,indent=2)+'\n')
recovery=json.loads((R/'recovery-map.json').read_text());index={x['path']:x for x in recovery};archives=json.loads((R/'archive-verification.json').read_text());members=[]
for ar in archives:
 outer=index[C+'/verification/'+ar['archive']]
 for member in ar['members']:
  members.append({'commit':outer['commit'],'archive_path':outer['path'],'archive_blob':outer['blob'],'archive_bytes':outer['bytes'],'archive_sha256':outer['sha256'],'member_path':member['member'],'member_bytes':member['bytes'],'member_sha256':member['sha256'],'recovery':'xz -dc ARCHIVE | tar -xOf - MEMBER','published_duplicate_equal':member['published_equal']})
(R/'archive-recovery-map.json').write_text(json.dumps(members,indent=2)+'\n')
rows=[]
for p in (R/'source'/C).rglob('*'):
 if p.is_file() and p.suffix in ('.md','.json','.py'):
  for n,line in enumerate(p.read_text().splitlines(),1):
   if re.search(r'type.?check|TYPECHECK',line):rows.append({'path':str(p.relative_to(R/'source')),'line':n,'text':line})
(R/'affected-trust0-labels.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'status':'PASS','official_sources_exact_blobs':len(prov),'archive_member_recovery_rows':len(members),'overstrong_label_occurrences':len(rows)}))
