import hashlib
import io
import json
import lzma
from pathlib import Path
import tarfile

ROOT = Path('/dev/shm/p196-agent11-046f/review125')
HEAD = '29b572f5231805b9db4a31f7cec6c0a5ab6435ea'
old_package = json.loads((ROOT / 'package.json').read_text())
for row in old_package['files']:
    raw = (ROOT / row['path']).read_bytes()
    assert len(raw) == row['bytes']
    assert hashlib.sha256(raw).hexdigest() == row['sha256'], row['path']
old_archive = (ROOT / 'publish-evidence.tar.xz').read_bytes()
assert len(old_archive) == old_package['bytes']
assert hashlib.sha256(old_archive).hexdigest() == old_package['sha256']

excluded = {
    'publish-evidence.tar.xz', 'publish-evidence-final.tar.xz',
    'package-final.json', 'package_final_evidence.out',
    'full-diff.patch', 'lean419-main.cpp'
}
files = [p for p in sorted(ROOT.iterdir()) if p.is_file() and p.name not in excluded]
rows = [{'path': p.name, 'bytes': p.stat().st_size, 'sha256': hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
manifest = {
    'head': HEAD,
    'final_review': 'FINAL_REVIEW.md',
    'final_receipt': 'final-receipt.json',
    'original_report_and_receipt_preserved': True,
    'original_package_checkpoint': {k: old_package[k] for k in ['bytes', 'sha256', 'head']},
    'files': rows,
    'published_duplicates': 'source/ and archives/ recover through recovery-map.json and archive-recovery-map.json; the correction recovers through final-head-check.json.new_file',
    'excluded_infrastructure': ['objects/'],
    'excluded_full_diff_recovery': 'git diff --binary d591ce6d0cbf2bceab219fe915b1cebcc16a5879 71fa669acdff9ee203ef28d7db7e31e2f9b5b4af',
    'packaging_output': 'package_final_evidence.out is a separately retained outer receipt; it is excluded to avoid self-reference.'
}
buf = io.BytesIO()
with tarfile.open(fileobj=buf, mode='w', format=tarfile.USTAR_FORMAT) as archive:
    for p in files:
        raw = p.read_bytes()
        info = tarfile.TarInfo(p.name)
        info.size = len(raw)
        info.mode = 0o644
        info.mtime = 0
        archive.addfile(info, io.BytesIO(raw))
    raw = (json.dumps(manifest, indent=2) + '\n').encode()
    info = tarfile.TarInfo('MANIFEST.json')
    info.size = len(raw)
    info.mode = 0o644
    info.mtime = 0
    archive.addfile(info, io.BytesIO(raw))
decoded = buf.getvalue()
packed = lzma.compress(decoded, preset=6)
out = ROOT / 'publish-evidence-final.tar.xz'
out.write_bytes(packed)
assert lzma.decompress(packed) == decoded
with tarfile.open(fileobj=io.BytesIO(decoded)) as archive:
    assert len(archive.getmembers()) == len(files) + 1
    for p in files:
        assert archive.extractfile(p.name).read() == p.read_bytes()
package = {
    'path': str(out), 'bytes': len(packed), 'sha256': hashlib.sha256(packed).hexdigest(),
    'decoded_tar_bytes': len(decoded), 'decoded_tar_sha256': hashlib.sha256(decoded).hexdigest(),
    'members': len(files) + 1, 'head': HEAD, 'review_path': 'FINAL_REVIEW.md',
    'receipt_path': 'final-receipt.json', 'files': rows,
    'all_original_package_files_unchanged': True, 'verified_lossless': True
}
(ROOT / 'package-final.json').write_text(json.dumps(package, indent=2) + '\n')
print(json.dumps({k: v for k, v in package.items() if k != 'files'}, indent=2))
