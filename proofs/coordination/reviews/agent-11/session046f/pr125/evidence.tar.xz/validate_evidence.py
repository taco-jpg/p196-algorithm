import pathlib,json,hashlib,re,lzma,tarfile,io,ast
R=pathlib.Path('/dev/shm/p196-agent11-046f/review125'); S=R/'source'; C=S/'proofs/contributions/agent-100/groupII-overflow-sharpness-20261016';V=C/'verification'; A=R/'archives/independent01-complete-evidence';RUN=A/'verification/independent01';P='groupii-overflow'
def sha(b):return hashlib.sha256(b).hexdigest()
def read(p):return json.loads(p.read_text())
reg=read(V/'registry.json'); report=read(RUN/'verification.json'); ledger=read(V/'complete-axiom-ledger.json'); strict=read(V/'strict01/strict-import-verification.json');pub=read(C/'PUBLICATION.json'); result={}
assert report==read(V/'independent01/verification.json')
assert report['status']=='PASS' and not report['repository_wide_pass']
assert sha((V/'registry.json').read_bytes())==report['registry_sha256']==strict['registry_sha256']==ledger['registry_sha256']
records=reg['projects'][P]['modules']; roots=reg['projects'][P]['roots'];closure=[]
def visit(m):
 if m in closure:return
 for d in records[m]['imports']:
  if d in records:visit(d)
  else:assert d=='Std'
 closure.append(m)
for root in roots:visit(root)
assert set(closure)==set(records) and len(closure)==18
source_rows=[]
for m,rec in records.items():
 raw=(S/rec['path']).read_bytes(); snap=(RUN/P/'source'/(m+'.lean')).read_bytes()
 assert raw==snap and sha(raw)==rec['sha256'] and hashlib.sha1(f'blob {len(raw)}\0'.encode()+raw).hexdigest()==rec['git_blob']
 imports=re.findall(r'^import (\S+)\s*$',raw.decode(),re.M); assert imports==rec['imports']
 assert rec['sha256']==report['projects'][P]['sources'][m]['build_sha256']
 source_rows.append({'module':m,**rec,'bytes':len(raw),'archive_source_equal':True})
assert report['projects'][P]['build_order']==closure
commands=report['projects'][P]['commands'];assert len(commands)==19
for cmd in commands:
 assert cmd['exit_code']==0 and '--trust=0' not in cmd['argv']
 raw=(RUN/cmd['log']).read_bytes(); assert sha(raw)==cmd['log_sha256']
 assert not re.search(r'(^|\n).*\berror:',raw.decode())
assert [c['label'] for c in commands]==closure+['ProjectAudit']
assert '--trust=0' in strict['argv'] and strict['exit_code']==0 and strict['prior_fresh_local_modules']==18
assert strict['cwd']==strict['LEAN_PATH'] and strict['cwd'].endswith('/independent01/'+P+'/source')
strictlog=(V/'strict01/ProjectAudit-trust0.log').read_bytes();canonlog=(RUN/P/'logs/ProjectAudit.log').read_bytes();assert strictlog==canonlog and sha(strictlog)==strict['log_sha256']
for path,h in strict['snapshots_before'].items():
 rel=path.split('/independent01/')[1]
 if rel.endswith('.olean'):continue
 assert sha((RUN/rel).read_bytes())==h
# Independent complete-list parsing; never import the original parser.
def audit(text):
 out={}
 for m in re.finditer(r'^AUDIT_THEOREM\s+(\S+)\s+(\S+)\s*:\s*\[([^\]]*)\]',text,re.M):
  mod,name,alist=m.groups();assert name not in out;axs=[v.strip() for v in alist.split(',') if v.strip()];assert len(axs)==len(set(axs));out[name]={'module':mod,'axioms':axs}
 return out
parsed=audit(canonlog.decode()); strictparsed=audit(strictlog.decode());assert len(parsed)==2576 and parsed==strictparsed==ledger['full_module_origin_ledger']==strict['full_module_origin_ledger']
allowed={'propext','Classical.choice','Quot.sound'};assert {a for x in parsed.values() for a in x['axioms']}==allowed
unsafe=re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$',canonlog.decode(),re.M);assert len(unsafe)==14 and [list(x) for x in unsafe]==report['projects'][P]['unsafe_implementation_axioms']
assert not ({x[1] for x in unsafe}&{a for x in parsed.values() for a in x['axioms']})
endpoints=[e for c in reg['claims'] for e in c['endpoints']];assert len(set(endpoints))==52
printed={}
for m in records:
 text=(RUN/P/'logs'/(m+'.log')).read_text()
 for ma in re.finditer(r"^'([^']+)'\s+depends on axioms:\s*\[([^\]]*)\]",text,re.M):printed[ma[1]]=[x.strip() for x in ma[2].split(',') if x.strip()]
 for ma in re.finditer(r"^'([^']+)'\s+does not depend on any axioms",text,re.M):printed[ma[1]]=[]
for n in endpoints:
 assert set(printed[n])==set(parsed[n]['axioms'])==set(ledger['new_explicit_exports'][n]['printed_axioms'])
assert sum('Classical.choice' in printed[n] for n in endpoints)==1
for n in ('Agent100.GroupII.returnedComponent_core_table','Agent100.GroupII.returnedComponent_not_same_shape'):assert set(printed[n])==allowed
manifest=read(RUN/'FILES.json')
for path,rec in manifest.items():
 raw=(RUN/path).read_bytes();assert len(raw)==rec['bytes'] and sha(raw)==rec['sha256']
# All publication file references with a SHA must agree with exact H.
def walk(obj):
 if isinstance(obj,dict):
  if 'path' in obj and 'sha256' in obj:
   p=C/obj['path'];assert p.exists() and sha(p.read_bytes())==obj['sha256'],str(p)
  for val in obj.values():walk(val)
 elif isinstance(obj,list):
  for val in obj:walk(val)
# source_files use repository-relative paths rather than contribution-relative paths.
pubcopy=dict(pub);pubcopy.pop('source_files');walk(pubcopy)
for m,rec in pub['source_files'].items():assert sha((S/rec['path']).read_bytes())==rec['sha256']
controls=C/'controls'; comp=read(controls/'compression-manifest.json'); controls_result=[]
for rec in comp['artifacts']:
 raw=(controls/rec['path']).read_bytes();assert len(raw)==rec['stored_bytes'] and sha(raw)==rec['stored_sha256'];dec=lzma.decompress(raw)
 if 'decoded_bytes' in rec:
  assert len(dec)==rec['decoded_bytes'] and sha(dec)==rec['decoded_sha256'];scout=json.loads(dec);assert len(scout['rows'])==scout['cases']==420
  for row in scout['rows']:
   r,p,u,v=[row[k] for k in ['r','p','u','v']]; assert r in scout['spacers'] and p in scout['p_values'] and [u,v] in scout['cores']
   for nk,wk in [('component_integers','component_words'),('whole_integers','whole_words')]:
    ns=row[nk];ws=row[wk];assert len(ns)==len(ws)==3
    for n,w in zip(ns,ws):
     ds=[int(x) for x in str(n)[::-1]];assert n>0 and w==[a+b for a,b in zip(ds,ds[::-1])]
    assert all(ns[j+1]==ns[j]+int(str(ns[j])[::-1]) for j in range(2))
   aa=row['component_words'];qq=row['whole_words'];overlap=[x+y for x,y in zip(aa[2]+[0],[0]+aa[2])];diff=[[i,a-b] for i,(a,b) in enumerate(zip(qq[2],overlap)) if a!=b]
   assert diff==row['second_pair_defect']==[[r+1,1],[r+3,-1],[r+4,-1],[r+6,1]]
   assert [len(w) for w in aa]==[2*r+6,2*r+6,2*r+7] and [len(w) for w in qq]==[2*r+7,2*r+7,2*r+8]
  controls_result.append({'path':rec['path'],'bytes':len(dec),'case_rows_reconciled':420,'experiment_rerun':False})
 else:
  assert len(dec)==rec['decoded_tar_bytes'] and sha(dec)==rec['decoded_tar_sha256']
  with tarfile.open(fileobj=io.BytesIO(dec)) as t:
   assert set(t.getnames())=={m['path'] for m in rec['members']}
   for m in rec['members']:
    b=t.extractfile(m['path']).read();assert len(b)==m['bytes'] and sha(b)==m['sha256'];json.loads(b)
  controls_result.append({'path':rec['path'],'members':len(rec['members']),'passed':True})
# Retained author attempts, including failures and unexecuted candidates, are data only.
dev=[]
for path in sorted((C/'development').rglob('*')):
 if path.is_file():
  b=path.read_bytes();entry={'path':str(path.relative_to(C)),'bytes':len(b),'sha256':sha(b)}
  if path.suffix=='.json':entry['record']=json.loads(b)
  elif path.suffix=='.log':entry['full_log']=b.decode()
  elif path.suffix=='.lean':entry['source_read']=True
  dev.append(entry)
(R/'development-review.json').write_text(json.dumps(dev,indent=2)+'\n')
for path in C.rglob('*.py'):ast.parse(path.read_text())
result={'status':'PASS_RETAINED_BYTES_AND_RAW_LEDGER_RECONCILIATION','head':'71fa669acdff9ee203ef28d7db7e31e2f9b5b4af','fresh_lean':'NOT_RUN','original_executor':'Agent #100 scope_audit independent child','source_records':source_rows,'canonical_commands':commands,'canonical_default_trust_max':True,'canonical_fresh_source_build_count':1,'strict_additional_command':strict['argv'],'strict_elapsed_seconds':round(strict['finished_at_epoch']-strict['started_at_epoch'],3),'strict_is_second_source_build':False,'strict_rechecks_imported_proofs':'NOT_ESTABLISHED_BY_AUDIT_SOURCE; see independent Lean4.19 source finding','raw_theorem_rows':len(parsed),'public_endpoints':len(endpoints),'unsafe_implementation_entries':len(unsafe),'axiom_union':sorted(allowed),'controls':controls_result,'development_records':len(dev),'new_reproduce_end_to_end':'NOT_RUN'}
(R/'validation.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ('source_records','canonical_commands')}))
