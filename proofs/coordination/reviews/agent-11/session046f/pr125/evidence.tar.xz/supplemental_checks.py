import json,pathlib,hashlib,re,importlib.util,subprocess,os
R=pathlib.Path('/dev/shm/p196-agent11-046f/review125');S=R/'source';C=S/'proofs/contributions/agent-100/groupII-overflow-sharpness-20261016';V=C/'verification'
env=dict(os.environ,GIT_OBJECT_DIRECTORY=str(R/'objects'),GIT_ALTERNATE_OBJECT_DIRECTORIES='/dev/shm/p196-agent11-046f/objects:/workspace/scratch/046f9285a650/repo/.git/objects')
def git(*args):return subprocess.check_output(['git','-C','/workspace/scratch/046f9285a650/repo',*args],env=env).decode().strip()
loader=importlib.util.spec_from_file_location('inspected_verifier',S/'proofs/verify_project__214bf7673efe116b.py');verifier=importlib.util.module_from_spec(loader);loader.loader.exec_module(verifier)
reg=json.loads((V/'registry.json').read_text()); findings=[]
for mod,rec in reg['projects']['groupii-overflow']['modules'].items():
 raw=(S/rec['path']).read_bytes();code=verifier.code_only(raw.decode())
 forbidden=re.findall(r"(?<![\w'])\b(?:sorry|admit|axiom|sorryAx|native_decide|ofReduceBool|skipKernelTC)\b(?![\w'])",code);assert not forbidden
 assert git('rev-parse','686cac2696e4e4e059c1b9d6a313f5519f6f4176:'+rec['path'])==rec['git_blob']
 meta=[(i,line) for i,line in enumerate(code.splitlines(),1) if re.search(r'\b(?:run_cmd|unsafe|extern|implemented_by|elab|macro|initialize)\b',line)]
 findings.append({'module':mod,'forbidden_tokens':forbidden,'meta_source_lines':meta,'complete_publication_blob_equal':True})
pins=json.loads((C/'dependencies/agent8-dependency-pins.json').read_text());
for mod,rec in pins['modules'].items():assert git('rev-parse',pins['source_commit']+':'+rec['path'])==rec['git_blob']
assert hashlib.sha256((S/'proofs/contributions/agent-100/groupII-overlap-20261016/controls/groupII_controls.py').read_bytes()).hexdigest()=='50e73312a3a89a8f90a7d8fc6a40b3280724c764c5e433a2a10734ead2f28f31'
# Compare all archived historical proof/source pin claims to exact source identities.
post=json.loads((V/'post-build-source-identity.json').read_text())
# Preserve the original complex report; exact H/source snapshots already directly compared.
result={'status':'PASS','source_scan':findings,'complete_source_commit':'686cac2696e4e4e059c1b9d6a313f5519f6f4176','agent8_source_commit':pins['source_commit'],'agent8_all_six_blobs_equal':True,'scout_helper_pin_equal':True,'fresh_lean':'NOT_RUN'}
(R/'supplemental-checks.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps(result))
