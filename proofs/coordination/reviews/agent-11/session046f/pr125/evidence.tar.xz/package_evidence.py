import pathlib,json,hashlib,tarfile,lzma,io
R=pathlib.Path('/dev/shm/p196-agent11-046f/review125')
exclude={'package.json','publish-evidence.tar.xz','full-diff.patch','lean419-main.cpp'}
files=[p for p in sorted(R.iterdir()) if p.is_file() and p.name not in exclude]
rows=[{'path':p.name,'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in files]
manifest={'head':'71fa669acdff9ee203ef28d7db7e31e2f9b5b4af','files':rows,'excluded_published_duplicates':'source/ and archives/ recover through recovery-map.json and archive-recovery-map.json; full diff recover through git diff --binary d591ce6d0cbf2bceab219fe915b1cebcc16a5879 71fa669acdff9ee203ef28d7db7e31e2f9b5b4af','excluded_infrastructure':['objects/']}
buf=io.BytesIO()
with tarfile.open(fileobj=buf,mode='w',format=tarfile.USTAR_FORMAT) as t:
 for p in files:
  raw=p.read_bytes();info=tarfile.TarInfo(p.name);info.size=len(raw);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(raw))
 raw=(json.dumps(manifest,indent=2)+'\n').encode();info=tarfile.TarInfo('MANIFEST.json');info.size=len(raw);info.mode=0o644;info.mtime=0;t.addfile(info,io.BytesIO(raw))
dec=buf.getvalue();packed=lzma.compress(dec,preset=6);out=R/'publish-evidence.tar.xz';out.write_bytes(packed)
assert lzma.decompress(packed)==dec
with tarfile.open(fileobj=io.BytesIO(dec)) as t:
 for p in files:assert t.extractfile(p.name).read()==p.read_bytes()
package={'path':str(out),'bytes':len(packed),'sha256':hashlib.sha256(packed).hexdigest(),'decoded_tar_bytes':len(dec),'decoded_tar_sha256':hashlib.sha256(dec).hexdigest(),'members':len(files)+1,'head':manifest['head'],'review_path':'REVIEW.md','receipt_path':'receipt.json','files':rows,'verified_lossless':True}
(R/'package.json').write_text(json.dumps(package,indent=2)+'\n');print(json.dumps({k:v for k,v in package.items() if k!='files'}))
