import os, subprocess, pathlib, json, hashlib
R=pathlib.Path('/dev/shm/p196-agent11-046f/review125'); H='71fa669acdff9ee203ef28d7db7e31e2f9b5b4af'; B='2bc42391c63b744951f27fde11af8c7d7958077f'
env=dict(os.environ,GIT_OBJECT_DIRECTORY=str(R/'objects'),GIT_ALTERNATE_OBJECT_DIRECTORIES='/dev/shm/p196-agent11-046f/objects:/workspace/scratch/046f9285a650/repo/.git/objects',PYTHONDONTWRITEBYTECODE='1')
def git(*args):
 p=subprocess.run(['git','-C','/workspace/scratch/046f9285a650/repo',*args],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 with (R/'commands.jsonl').open('a') as f:f.write(json.dumps({'cmd':['git',*args],'exit':p.returncode,'stderr':p.stderr.decode(errors='replace')})+'\n')
 if p.returncode:raise RuntimeError(p.stderr.decode())
 return p.stdout
base=git('merge-base',H,B).decode().strip();(R/'base.txt').write_text(base+'\n')
names=git('diff','--name-status',base,H);(R/'changed-paths.tsv').write_bytes(names)
paths=[s.split('\t')[-1] for s in names.decode().splitlines() if not s.startswith('D\t')]
tree=git('ls-tree','-r','--name-only',H).decode().splitlines()
paths += [p for p in tree if p.endswith('AGENTS.md') or p.endswith('PUBLICATION_POLICY.md')]
rows=[]
for p in sorted(set(paths)):
 data=git('show',H+':'+p);out=R/'source'/p;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
 rows.append({'commit':H,'path':p,'blob':git('rev-parse',H+':'+p).decode().strip(),'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'local':str(out.relative_to(R))})
(R/'recovery-map.json').write_text(json.dumps(rows,indent=2)+'\n')
(R/'full-diff.patch').write_bytes(git('diff','--binary',base,H))
print(json.dumps({'head':H,'base':base,'changed':len(names.decode().splitlines()),'recovered':len(rows)}));print(names.decode())
