import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path('/dev/shm/p196-agent11-046f/review125')
REPO = '/workspace/scratch/046f9285a650/repo'
OLD = '71fa669acdff9ee203ef28d7db7e31e2f9b5b4af'
NEW = '29b572f5231805b9db4a31f7cec6c0a5ab6435ea'
PATH = 'proofs/contributions/agent-100/groupII-overflow-sharpness-20261016/integration/Agent11Lean419VerificationErratum.md'
EXPECTED_BLOB = '24e22ab225d72eca71bfb19db041da5960d3a362'
EXPECTED_SHA = 'a516f682dc643f68647224d4ba2b9a31016c12b246197b30787a3cd60acbb350'
env = dict(os.environ)
env.update(GIT_OBJECT_DIRECTORY=str(ROOT / 'objects'), GIT_ALTERNATE_OBJECT_DIRECTORIES='/dev/shm/p196-agent11-046f/objects:/workspace/scratch/046f9285a650/repo/.git/objects', GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1')

def git(*args):
    return subprocess.check_output(['git', '-C', REPO, *args], env=env)

def tree(commit):
    raw = git('ls-tree', '-r', '-z', commit)
    entries = {}
    for row in raw.split(b'\x00'):
        if row:
            info, path = row.split(b'\t', 1)
            mode, kind, oid = info.decode().split()
            entries[path.decode()] = {'mode': mode, 'type': kind, 'oid': oid}
    return raw, entries

old_raw, old = tree(OLD)
new_raw, new = tree(NEW)
parents = git('show', '-s', '--format=%P', NEW).decode().strip().split()
assert parents == [OLD], parents
added = sorted(set(new) - set(old))
removed = sorted(set(old) - set(new))
changed = sorted(p for p in old if p in new and old[p] != new[p])
assert added == [PATH], added
assert removed == [], removed
assert changed == [], changed
assert new[PATH] == {'mode': '100644', 'type': 'blob', 'oid': EXPECTED_BLOB}, new[PATH]

response = json.loads((ROOT / 'final-blob-response.json').read_text())
assert response.get('isError') is False
remote = response['structuredContent']['content'].encode()
candidate = Path('/dev/shm/p196-agent11-046f/integration/Agent11Lean419VerificationErratum.md').read_bytes()
assert remote == candidate
assert len(remote) == 7365
assert hashlib.sha256(remote).hexdigest() == EXPECTED_SHA
blob = hashlib.sha1(b'blob ' + str(len(remote)).encode() + b'\x00' + remote).hexdigest()
assert blob == EXPECTED_BLOB

diff = git('diff', '--no-renames', '--raw', OLD, NEW).decode()
record = {
    'status': 'PASS_EXACT_ADDITIVE_CORRECTION_ALL_PREEXISTING_TREE_ENTRIES_IDENTICAL',
    'previous_head': OLD, 'head': NEW, 'parents': parents,
    'previous_tree': git('rev-parse', OLD + '^{tree}').decode().strip(),
    'final_tree': git('rev-parse', NEW + '^{tree}').decode().strip(),
    'previous_recursive_entries': len(old), 'final_recursive_entries': len(new),
    'old_ls_tree_sha256': hashlib.sha256(old_raw).hexdigest(),
    'new_ls_tree_sha256': hashlib.sha256(new_raw).hexdigest(),
    'added': added, 'removed': removed, 'changed': changed,
    'new_file': {'commit': NEW, 'path': PATH, 'blob': blob, 'bytes': len(remote), 'sha256': EXPECTED_SHA, 'candidate_byte_equal': True, 'recovery': 'git show ' + NEW + ':' + PATH},
    'git_raw_diff': diff,
    'fresh_lean': 'NOT_RUN',
    'previous_review_reused': 'All pre-existing modes, object types, and object identities are unchanged; the source closure, registry, runtime pins, build logs, and archives therefore remain exactly the reviewed bytes.'
}
(ROOT / 'final-head-check.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
