import os,subprocess,pathlib,json,hashlib,lzma,tarfile,io
R=pathlib.Path('/dev/shm/p196-agent11-046f/review125'); H='71fa669acdff9ee203ef28d7db7e31e2f9b5b4af'; C='proofs/contributions/agent-100/groupII-overflow-sharpness-20261016'; S=R/'source'; V=S/C/'verification'
env=dict(os.environ,GIT_OBJECT_DIRECTORY=str(R/'objects'),GIT_ALTERNATE_OBJECT_DIRECTORIES='/dev/shm/p196-agent11-046f/objects:/workspace/scratch/046f9285a650/repo/.git/objects',PYTHONDONTWRITEBYTECODE='1')
git=['git','-C','/workspace/scratch/046f9285a650/repo']
reg=json.loads((V/'registry.json').read_text()); paths=[v['path'] for v in reg['projects']['groupii-overflow']['modules'].values()]+['proofs/verify_project__214bf7673efe116b.py','proofs/ACCEPTED_BUILD.json','proofs/contributions/agent-100/groupII-overlap-20261016/controls/groupII_controls.py']
tree=subprocess.check_output(git+['ls-tree','-r',H,'--',*paths],env=env).decode().splitlines(); ids=[s.split()[2] for s in tree]
check=subprocess.check_output(git+['cat-file','--batch-check=%(objectname) %(objecttype)'],input=('\n'.join(ids)+'\n').encode(),env=dict(env,GIT_NO_LAZY_FETCH='1')).decode(); missing=[s.split()[0] for s in check.splitlines() if s.endswith(' missing')]
if missing:
 p=subprocess.run(git+['fetch','--no-write-fetch-head','--no-tags','origin',*missing],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT); (R/'closure-fetch.log').write_bytes(p.stdout); assert p.returncode==0
maps=json.loads((R/'recovery-map.json').read_text()); seen={x['path'] for x in maps}
for p in paths:
 raw=subprocess.check_output(git+['show',H+':'+p],env=env); out=S/p;out.parent.mkdir(exist_ok=True,parents=True);out.write_bytes(raw)
 blob=subprocess.check_output(git+['rev-parse',H+':'+p],env=env).decode().strip()
 if p not in seen:maps.append(dict(commit=H,path=p,blob=blob,bytes=len(raw),sha256=hashlib.sha256(raw).hexdigest(),local=str(out.relative_to(R))))
(R/'recovery-map.json').write_text(json.dumps(maps,indent=2)+'\n')
results=[]
for name,manifest in [('independent01-complete-evidence.tar.xz','independent01-archive-manifest.json'),('strict01-evidence-amendment.tar.xz','strict01-evidence-amendment-manifest.json')]:
 m=json.loads((V/manifest).read_text());raw=(V/name).read_bytes();decoded=lzma.decompress(raw)
 assert len(raw)==m['stored_bytes'] and hashlib.sha256(raw).hexdigest()==m['stored_sha256']
 assert len(decoded)==m['decoded_tar_bytes'] and hashlib.sha256(decoded).hexdigest()==m['decoded_tar_sha256']
 dest=R/'archives'/name.removesuffix('.tar.xz'); expected={x['path']:x for x in m['files']}; rows=[]
 with tarfile.open(fileobj=io.BytesIO(decoded)) as t:
  ms=t.getmembers(); assert len(ms)==m['members'] and {x.name for x in ms}==set(expected)
  for member in ms:
   assert member.isfile() and not pathlib.PurePosixPath(member.name).is_absolute() and '..' not in pathlib.PurePosixPath(member.name).parts
   data=t.extractfile(member).read();rec=expected[member.name];assert len(data)==rec['bytes'] and hashlib.sha256(data).hexdigest()==rec['sha256'];out=dest/member.name;out.parent.mkdir(parents=True,exist_ok=True);out.write_bytes(data)
   published=S/C/member.name;rows.append({'member':member.name,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'published_duplicate':published.exists(),'published_equal':published.read_bytes()==data if published.exists() else None})
 results.append({'archive':name,'compressed_sha256':hashlib.sha256(raw).hexdigest(),'members':rows,'passed':True})
(R/'archive-verification.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({'closure_files':len(paths),'archives':[(x['archive'],len(x['members'])) for x in results],'status':'PASS'}))
