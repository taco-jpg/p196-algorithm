import os,subprocess,pathlib,json
r=pathlib.Path('/dev/shm/p196-agent11-046f/review125'); h='71fa669acdff9ee203ef28d7db7e31e2f9b5b4af'
env=dict(os.environ,GIT_OBJECT_DIRECTORY=str(r/'objects'),GIT_ALTERNATE_OBJECT_DIRECTORIES='/dev/shm/p196-agent11-046f/objects:/workspace/scratch/046f9285a650/repo/.git/objects')
p=['git','-C','/workspace/scratch/046f9285a650/repo']
paths=[s.split('\t')[-1] for s in (r/'changed-paths.tsv').read_text().splitlines()]
tree=subprocess.check_output(p+['ls-tree','-r',h,'--',*paths],env=env).decode().splitlines()
ids=[s.split()[2] for s in tree]
check=subprocess.check_output(p+['-c','extensions.partialClone=','cat-file','--batch-check=%(objectname) %(objecttype)'],input=('\n'.join(ids)+'\n').encode(),env=dict(env,GIT_NO_LAZY_FETCH='1')).decode()
missing=[s.split()[0] for s in check.splitlines() if s.endswith(' missing')]
print('missing',len(missing),flush=True)
if missing:
 c=p+['fetch','--no-write-fetch-head','--no-tags','origin',*missing]
 z=subprocess.run(c,env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (r/'bulk-fetch.log').write_bytes(z.stdout);print('exit',z.returncode,flush=True)
