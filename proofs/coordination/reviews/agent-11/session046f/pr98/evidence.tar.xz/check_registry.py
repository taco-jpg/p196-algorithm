from pathlib import Path
import os,subprocess,json,hashlib
R=Path('/dev/shm/p196-agent11-046f/review98');H='6ee27fa2c3d62fc00deca9ceb2e35f29f4a851e9'
e=os.environ.copy();e['GIT_OBJECT_DIRECTORY']=str(R/'objects');e['GIT_ALTERNATE_OBJECT_DIRECTORIES']='/dev/shm/p196-agent11-046f/objects:/workspace/scratch/046f9285a650/repo/.git/objects'
def git(*a):return subprocess.check_output(['git','-C','/workspace/scratch/046f9285a650/repo',*a],env=e)
rows=[]
def read(path,save=False):
 b=git('show',H+':'+path);rows.append({'commit':H,'path':path,'blob':git('rev-parse',H+':'+path).decode().strip(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
 if save:
  p=R/'source'/path;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
 return b
for p in ['proofs/verify_project.py','proofs/replay_original_layout.py','proofs/archive/source-trees/2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5/proofs/verify_project.py']:read(p,True)
mapping=json.loads(read('proofs/SOURCE_MAP.json'));m=mapping['paths']['proofs/ACCEPTED_BUILD.json'];path=m.get('current') or m['preserved'];reg=json.loads(read(path,True))
new=[k for k in mapping['paths'] if 'Agent108Window' in k or 'window-weights-b31b8818' in k]
found=[(p,n) for p,s in reg['projects'].items() for n in s['modules'] if n.startswith('Agent108Window')]
assert not new and not found
result={'status':'PASS_SCOPED_REGISTRY_DISCLOSURE','head':H,'replay_base':mapping['base'],'registry_path':path,'registry_projects':list(reg['projects']),'registry_catalogue_complete':reg['catalogue_complete'],'new_package_in_replay_source_map':new,'new_package_in_default_registry':found,'scope':'The explicitly pinned 17-module check.py is the executable package entrypoint; no default/core or repository-wide acceptance is inferred.'}
(R/'registry-result.json').write_text(json.dumps(result,indent=2)+'\n');(R/'registry-recovery-map.json').write_text(json.dumps(rows,indent=2)+'\n');print(json.dumps(result,indent=2))
