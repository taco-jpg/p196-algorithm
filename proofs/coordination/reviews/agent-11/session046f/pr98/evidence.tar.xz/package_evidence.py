"""Assemble compact review evidence without duplicating published source trees."""
from pathlib import Path
import hashlib,json,shutil
R=Path(__file__).resolve().parent;out=R/'publish-evidence';out.mkdir(exist_ok=True)
for p in sorted(R.iterdir()):
 if p.is_file():shutil.copyfile(p,out/p.name)
manifest={p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(out.iterdir()) if p.is_file() and p.name not in ['FILES.json','package-receipt.json']}
(out/'FILES.json').write_text(json.dumps(manifest,indent=2)+'\n')
receipt={'status':'READY_FOR_ROOT_PUBLICATION','files':len(manifest)+2,'payload_bytes_before_manifest_receipt':sum(r['bytes'] for r in manifest.values()),'omitted':'Published source tree, isolated Git object cache, and reproducible infrastructure; exact original evidence recovery maps included.','path':str(out)}
(out/'package-receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps(receipt,indent=2))
