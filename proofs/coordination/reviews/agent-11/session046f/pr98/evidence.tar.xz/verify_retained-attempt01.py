"""Review exact published PR98 source and retained evidence without launching Lean."""
from pathlib import Path
import collections,hashlib,importlib.util,json,os,re,subprocess
R=Path('/dev/shm/p196-agent11-046f/review98'); S=R/'source'; P=S/'proofs/contributions/agent-108/window-weights-b31b8818'; E=P/'review/final-package-fresh17-001'
H='6ee27fa2c3d62fc00deca9ceb2e35f29f4a851e9'
def sha(b):return hashlib.sha256(b).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2)+'\n')
spec=importlib.util.spec_from_file_location('reviewed_checker',P/'check.py'); c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
pins=c.load_pins(P/'source-pins.json'); data,records=c.verify_sources(pins,S); declarations=[d for r in records for d in r['source_declarations']]
receipt=json.loads((E/'verification.json').read_bytes()); audit=json.loads((E/'axiom-audit.json').read_bytes()); previous=json.loads((P/'review/final-package-readback-001/readback-result.json').read_bytes())
assert receipt['status']=='PASS' and receipt['pass'] and len(receipt['commands'])==38
assert receipt['fresh_build_initially_empty'] and not receipt['project_olean_reuse'] and receipt['mathlib_and_toolchain_oleans_reused']
assert receipt['all_sources_unchanged_after'] and receipt['package_files_unchanged_after'] and receipt['mathlib_manifest_unchanged_after']
assert receipt['build_order']==pins['build_order']
assert sha((E/'verification.json').read_bytes())=='0ebb8d421e13c88365a6fdae255d56f41191d7ee9a72901b6d63b73fa284ea74'
assert sha((E/'verification.json').read_bytes())==previous['receipt_sha256']
assert sha((E/'axiom-audit.json').read_bytes())==previous['audit_json_sha256']
for name,h in receipt['package_sha256'].items():assert sha((P/name).read_bytes())==sha((E/'inputs'/name).read_bytes())==h
for row in records:assert data[row['module']]==(E/'sources'/(row['module']+'.lean')).read_bytes()
assert records==receipt['source_records']
bylabel={x['label']:x for x in receipt['commands']}; assert len(bylabel)==38
oldroot=Path(receipt['evidence_root']); command_rows=[]
for cmd in receipt['commands']:
 assert cmd['exit_code']==0
 row=dict(cmd)
 for key in ['stdout_log','stderr_log']:
  p=E/cmd[key]; b=p.read_bytes(); h=sha(b)
  assert h==previous['raw_command_log_sha256'][cmd[key]]
  row[key+'_sha256']=h; row[key+'_bytes']=len(b)
  if key=='stderr_log':assert not b
 command_rows.append(row)
compile_commands=[x for x in receipt['commands'] if x['label'].startswith('compile-')]
assert [x['label'][8:] for x in compile_commands]==pins['build_order']
for cmd in compile_commands+[bylabel['audit-module-origins']]:
 module=cmd['label'][8:] if cmd['label'].startswith('compile-') else 'WindowPackageAxioms'
 assert cmd['argv']==[receipt['lean']['binary'],'--trust=0','-j1','-DElab.async=false','-o',str(oldroot/'build'/(module+'.olean')),module+'.lean']
 assert cmd['cwd']==str(oldroot/'sources')
assert (E/bylabel['lean-version']['stdout_log']).read_text().strip()==receipt['lean']['version_output']=='Lean (version 4.19.0, x86_64-unknown-linux-gnu, commit 6caaee842e94, Release)'
for name,commit in [('mathlib',pins['mathlib']['commit'])]+[(r['name'],r['rev']) for r in pins['mathlib']['dependencies']]:
 assert (E/bylabel[name+'-head']['stdout_log']).read_text().strip()==commit
 assert not (E/bylabel[name+'-tracked-status']['stdout_log']).read_bytes()
assert (E/bylabel['repository-head']['stdout_log']).read_text().strip()==receipt['repository_head']=='de75fed1de4d477644f22ee5ca35291df2bafa4f'
assert sha((E/'inputs/mathlib-lake-manifest.json').read_bytes())==pins['mathlib']['lake_manifest_sha256']
assert sha((E/'inputs/mathlib-lean-toolchain').read_bytes())==pins['mathlib']['lean_toolchain_sha256']
manifest=json.loads((E/'inputs/mathlib-lake-manifest.json').read_text()); mp={r['name']:r for r in manifest['packages']}
assert len(mp)==8
for pin in pins['mathlib']['dependencies']:assert mp[pin['name']]['rev']==pin['rev'] and mp[pin['name']]['url']==pin['url']
assert receipt['lean_environment']['LEAN_PATH'].split(':')==[str(oldroot/'build'),str(Path(receipt['mathlib']['root'])/'.lake/build/lib/lean')]+[x['library'] for x in receipt['dependency_cache_directories'] if x['present']]
assert {x['package'] for x in receipt['dependency_cache_directories']}=={x['name'] for x in pins['mathlib']['dependencies']}
assert {x['module'] for x in receipt['compiled_oleans']}==set(pins['build_order'])
for x in receipt['compiled_oleans']:assert previous['project_object_pins_rechecked'][x['module']]=={'sha256':x['sha256'],'bytes':x['size_bytes']}
# No object, Lean runtime or external cache is executed/read as freshly validated here.
assert c.make_audit_source(pins['build_order']).encode()==(E/'sources/WindowPackageAxioms.lean').read_bytes()==(P/'review/package-inspection/final-static-01/GeneratedAudit.lean').read_bytes()
assert sha((E/'sources/WindowPackageAxioms.lean').read_bytes())==receipt['audit_source_sha256']
raw=(E/'logs/38-audit-module-origins.stdout.log').read_text(); assert sha(raw.encode())==previous['raw_audit_sha256']
# Independent strict stream parser: all raw rows, including private/generated safe definitions.
meta={}; reports={}; active=None; body=[]
for line in raw.splitlines():
 if line.startswith('METADATA|'):
  assert active is None
  _,module,name,kind,unsafe,partial=line.split('|');assert name not in meta
  assert module in pins['build_order'] and unsafe in ['true','false'] and partial in ['true','false']
  meta[name]={'module':module,'declaration':name,'kind':kind,'unsafe':unsafe=='true','partial':partial=='true'}
 elif line.startswith('AUDIT_BEGIN|'):
  assert active is None;active=line.partition('|')[2];assert active not in reports;body=[]
 elif line.startswith('AUDIT_END|'):
  assert active==line.partition('|')[2]
  text='\n'.join(body).strip();m=re.fullmatch(r"'([^']+)' (does not depend on any axioms|depends on axioms: \[([^]]*)\])",text,re.S);assert m and m[1]==active
  ax=[] if m[3] is None else [x.strip() for x in m[3].split(',') if x.strip()]
  assert set(ax)<={'propext','Classical.choice','Quot.sound'}
  reports[active]={'printed_name':active,'axioms':ax};active=None
 elif active is not None:body.append(line)
 else:assert not line.strip(),repr(line)
assert active is None
safe={n for n,r in meta.items() if not r['unsafe'] and not r['partial']}
assert set(reports)==safe and len(meta)==2536 and len(safe)==1583
assert {r['declaration']:r for r in audit['origin_metadata']}==meta
assert {r['declaration']:r for r in audit['safe_axiom_reports']}=={n:{**meta[n],**reports[n]} for n in safe}
reparsed=c.parse_audit(raw,set(pins['build_order']),declarations);assert reparsed==audit and reparsed['pass']
assert len(declarations)==578 and sum(x['kind']=='theorem' for x in meta.values() if not x['unsafe'] and not x['partial'])==1367
# Inspect every retained raw axiom row, including narrower historical audits and source-internal reports.
log_rows=[]; log_axioms=[]; diagnostic_logs=[]
for p in sorted(P.rglob('*.log')):
 b=p.read_bytes();t=b.decode(); rel=str(p.relative_to(S));log_rows.append({'path':rel,'bytes':len(b),'sha256':sha(b)})
 for m in re.finditer(r"^'([^']+)' (does not depend on any axioms|depends on axioms: \[([^]]*)\])",t,re.M):
  ax=[] if m[3] is None else [x.strip() for x in m[3].split(',') if x.strip()]
  log_axioms.append({'path':rel,'line':t.count('\n',0,m.start())+1,'name':m[1],'axioms':ax})
  assert set(ax)<={'propext','Classical.choice','Quot.sound'},(rel,m[1],ax)
 if any(z in t.lower() for z in ['error:','unsolved goals','failed to locate','traceback']):diagnostic_logs.append({'path':rel,'sha256':sha(b),'contents':t})
# Inventory historical nonzero/unfinished command records rather than upgrading them to PASS.
failures=[]; json_files=0
for p in sorted(P.rglob('*.json')):
 x=json.loads(p.read_text());json_files+=1
 def walk(y,where):
  if isinstance(y,dict):
   if 'exit_code' in y and y['exit_code'] not in [0,None]:failures.append({'path':str(p.relative_to(S)),'json_location':where,'record':y})
   for k,z in y.items():walk(z,where+'/'+k)
  elif isinstance(y,list):
   for i,z in enumerate(y):walk(z,where+'/'+str(i))
 walk(x,'')
# Check forbidden proof shortcuts lexically after nested comments/strings are masked.
for module,b in data.items():
 clean=c.mask_lean_comments_and_strings(b.decode())
 assert not re.search(r'\b(sorry|admit|sorryAx|native_decide|ofReduceBool)\b|^\s*(axiom|unsafe|partial)\s',clean,re.M),module
# Independent Git provenance checks, isolated object storage only.
env=os.environ.copy();env['GIT_OBJECT_DIRECTORY']=str(R/'objects');env['GIT_ALTERNATE_OBJECT_DIRECTORIES']='/dev/shm/p196-agent11-046f/objects:/workspace/scratch/046f9285a650/repo/.git/objects'
def git(*args):return subprocess.check_output(['git','-C','/workspace/scratch/046f9285a650/repo',*args],env=env)
provenance=[]
for pin in pins['sources']:
 refs=[(H,pin['repo_path'])]
 if pin['role']=='original_dependency':refs += [(pin['original_commit'],pin['original_repo_path']),(pin['retained_path_verified_at'],pin['repo_path'])]
 else:refs += [('de75fed1de4d477644f22ee5ca35291df2bafa4f',pin['repo_path'])]
 for commit,path in refs:
  b=git('show',commit+':'+path);assert b==data[pin['module']]
  blob=git('rev-parse',commit+':'+path).decode().strip();assert blob==pin['git_blob']
  provenance.append({'module':pin['module'],'commit':commit,'path':path,'blob':blob,'bytes':len(b),'sha256':sha(b)})
dump(R/'historical-commands-verified.json',command_rows);dump(R/'all-retained-log-identities.json',log_rows);dump(R/'historical-diagnostics.json',diagnostic_logs);dump(R/'historical-nonzero-records.json',failures);dump(R/'source-provenance.json',provenance)
counts=collections.Counter(r['kind'] for n,r in meta.items() if n in safe)
result={'status':'PASS','fresh_lean':'NOT_RUN','source_head':H,'source_modules':len(data),'source_explicit_declarations':len(declarations),'closure_exact':True,'retained_commands':len(command_rows),'strict_lean_command_vectors':18,'source_provenance_links':len(provenance),'origin_constants':len(meta),'safe_nonpartial_constants':len(safe),'safe_kind_counts':dict(counts),'unsafe':sum(r['unsafe'] for r in meta.values()),'partial':sum(r['partial'] for r in meta.values()),'axiom_union':sorted({a for r in reports.values() for a in r['axioms']}),'all_retained_log_files_read':len(log_rows),'all_retained_axiom_rows_checked':len(log_axioms),'historical_nonzero_records':len(failures),'historical_diagnostic_logs':len(diagnostic_logs),'all_retained_json_read':json_files,'receipt_sha256':sha((E/'verification.json').read_bytes()),'raw_audit_sha256':sha(raw.encode()),'readback_receipt_sha256':sha((P/'review/final-package-readback-001/readback-result.json').read_bytes()),'limitations':['No new Lean process or proof compilation.','Existing independent historical readback validated project object and runtime bytes at execution; this review does not freshly validate omitted compiled objects.','Lean, Mathlib and dependency compiled caches remain external trusted prerequisites.','Current main combination and platform gates belong to root.']}
dump(R/'verification-result.json',result);print(json.dumps(result,indent=2))
