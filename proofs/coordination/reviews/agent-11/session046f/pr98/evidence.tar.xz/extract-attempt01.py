from pathlib import Path
import subprocess,os,json,hashlib
R=Path('/dev/shm/p196-agent11-046f/review98'); H='6ee27fa2c3d62fc00deca9ceb2e35f29f4a851e9'
e=os.environ.copy();e['GIT_OBJECT_DIRECTORY']=str(R/'objects');e['GIT_ALTERNATE_OBJECT_DIRECTORIES']='/dev/shm/p196-agent11-046f/objects:/workspace/scratch/046f9285a650/repo/.git/objects'
def git(*a):return subprocess.check_output(['git','-C','/workspace/scratch/046f9285a650/repo',*a],env=e)
paths=git('diff','--name-only',H+'~5',H).decode().splitlines()+['AGENTS.md','proofs/PUBLICATION_POLICY.md','proofs/FOLDED_WEIGHT_OBSTRUCTION.md']
pins=json.loads(git('show',H+':proofs/contributions/agent-108/window-weights-b31b8818/source-pins.json'))
R.joinpath('pins-preview.json').write_text(json.dumps(pins,indent=2))
rows=[]
for p in paths:
 b=git('show',H+':'+p);f=R/'source'/p;f.parent.mkdir(parents=True,exist_ok=True);f.write_bytes(b)
 rows.append({'commit':H,'path':p,'blob':git('rev-parse',H+':'+p).decode().strip(),'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
R.joinpath('recovery-map.json').write_text(json.dumps(rows,indent=2)+'\n')
print(json.dumps({'extracted_files':len(rows),'bytes':sum(x['bytes'] for x in rows)}))
