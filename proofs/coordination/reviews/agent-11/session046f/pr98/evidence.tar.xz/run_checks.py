"""Capture exact commands and exits for the final non-Lean review checks."""
from pathlib import Path
import datetime,hashlib,json,os,subprocess,sys
R=Path(__file__).resolve().parent
commands=[['python3',str(R/'verify_retained.py')],['python3',str(R/'check_registry.py')],['python3',str(R/'source/proofs/contributions/agent-108/window-weights-b31b8818/check.py'),'--repo-root',str(R/'source'),'--check-inputs']]
env=os.environ.copy();env['PYTHONDONTWRITEBYTECODE']='1';results=[]
for i,cmd in enumerate(commands,1):
 start=datetime.datetime.now(datetime.timezone.utc).isoformat();p=subprocess.run(cmd,capture_output=True,env=env)
 so=R/f'fresh-{i:02d}.stdout.log';se=R/f'fresh-{i:02d}.stderr.log';so.write_bytes(p.stdout);se.write_bytes(p.stderr)
 row={'argv':cmd,'cwd':str(Path.cwd()),'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'stdout_log':so.name,'stderr_log':se.name,'stdout_sha256':hashlib.sha256(p.stdout).hexdigest(),'stderr_sha256':hashlib.sha256(p.stderr).hexdigest()};results.append(row)
 print(json.dumps({'check':i,'exit_code':p.returncode}),flush=True)
 if p.returncode:break
result={'fresh_lean':'NOT_RUN','status':'PASS' if len(results)==3 and all(x['exit_code']==0 for x in results) else 'FAIL','commands':results}
(R/'fresh-command-receipt.json').write_text(json.dumps(result,indent=2)+'\n')
sys.exit(0 if result['status']=='PASS' else 1)
