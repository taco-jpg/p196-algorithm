"""Construct and validate an integration tree using temporary Git objects."""
import argparse,hashlib,json,os,subprocess
from pathlib import Path
p=argparse.ArgumentParser()
for name in ('base','head','registry','label'):p.add_argument('--'+name,required=True)
p.add_argument('--source-manifest',action='store_true')
a=p.parse_args()
root=Path('/workspace/scratch/046f9285a650')
out=Path('/dev/shm/p196-agent11-046f')
env=dict(os.environ,GIT_OBJECT_DIRECTORY=str(out/'objects'),GIT_ALTERNATE_OBJECT_DIRECTORIES=':'.join([str(root/'repo/.git/objects')]+[str(out/f'review{n}/objects') for n in (98,130,143,103,125,138) if (out/f'review{n}/objects').is_dir()]))
runs=[]
def run(cmd):
 r=subprocess.run(cmd,env=env,capture_output=True,text=True)
 runs.append({'command':cmd,'exit_code':r.returncode,'stdout':r.stdout,'stderr':r.stderr})
 (out/(a.label+'-driver-receipt.json')).write_text(json.dumps({'base':a.base,'head':a.head,'runs':runs},indent=2)+'\n')
 if r.returncode:raise RuntimeError(json.dumps(runs[-1]))
 return r.stdout.strip()
git=['git','-C',str(root/'repo')]
run(git+['-c','gc.auto=0','-c','maintenance.auto=false','fetch','--no-write-fetch-head','origin',a.base])
tree=run(git+['merge-tree','--write-tree',a.base,a.head])
run(['python',str(root/'integration/check_combination.py'),'--repo',str(root/'repo'),'--base',a.base,'--head',a.head,'--tree',tree,'--output',str(out/(a.label+'-combination.json'))])
validator=out/'check_source_manifest_combination.py' if a.source_manifest else root/'integration/check_registry_combination.py'
run(['python',str(validator),'--repo',str(root/'repo'),'--head',a.head,'--tree',tree,'--registry',a.registry,'--output',str(out/(a.label+'-registry.json'))])
print(json.dumps({'status':'PASS','base':a.base,'head':a.head,'tree':tree,'label':a.label,'runs':len(runs)}))
