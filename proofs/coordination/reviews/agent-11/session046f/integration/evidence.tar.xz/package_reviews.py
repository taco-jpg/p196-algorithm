"""Preserve review artifacts, omitting only exact recoverable Git duplicates."""
from pathlib import Path
import hashlib, io, json, subprocess, tarfile
root=Path('/workspace/scratch/046f9285a650')
repo=root/'repo'
cases={111:('bf4ff749000a6995e1755e37b59988ef362bae16','frozen'),124:('9361e8a8d13c731a4004b08957f4cd543b3ae38f','snapshot')}
for number,(head,snapshot) in cases.items():
    directory=root/f'review{number}'
    original={}
    for row in subprocess.check_output(['git','-C',str(repo),'ls-tree','-rz',head]).split(b'\0'):
        if row:
            metadata,path=row.split(b'\t',1)
            original[path.decode()]=metadata.decode().split()[-1]
    files={}; omitted=[]
    for f in sorted(directory.rglob('*')):
        if not f.is_file() or '__pycache__' in f.parts or f.suffix in {'.gz','.xz','.olean','.ilean'}:
            continue
        rel=f.relative_to(directory).as_posix(); data=f.read_bytes()
        blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        gitpath=rel.removeprefix(snapshot+'/') if rel.startswith(snapshot+'/') else None
        if gitpath and original.get(gitpath)==blob:
            omitted.append({'review_path':rel,'source_commit':head,'source_path':gitpath,'git_blob':blob,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()})
        else:
            files[rel]=data
    mapping={'reason':'Only byte-identical already-published Git snapshots are omitted; all new substantive review artifacts and actual failures remain. Original inventory keeps its original meaning.','recovery':'For each entry, git show SOURCE_COMMIT:SOURCE_PATH > REVIEW_PATH. Validate Git blob, bytes and SHA256 before use.','omitted_duplicate_git_files':omitted}
    files['PUBLISHED_SOURCE_RECOVERY.json']=(json.dumps(mapping,indent=2)+'\n').encode()
    inventory={p:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for p,b in files.items()}
    files['PACKAGE_INVENTORY.json']=(json.dumps(inventory,indent=2)+'\n').encode()
    output=root/'integration'/f'pr{number}-review-evidence.tar.xz'
    with tarfile.open(output,'w:xz') as archive:
        for path,data in files.items():
            item=tarfile.TarInfo(path);item.size=len(data);item.mode=0o644;item.mtime=0
            archive.addfile(item,io.BytesIO(data))
    with tarfile.open(output,'r:xz') as archive:
        actual={x.name:archive.extractfile(x).read() for x in archive.getmembers()}
    assert actual==files
    receipt={'pr':number,'head':head,'archive':output.name,'archive_bytes':output.stat().st_size,'archive_sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'retained_files':len(files),'omitted_exact_git_duplicates':len(omitted),'roundtrip':'PASS','recovery':'tar -xJf '+output.name+'; consult PUBLISHED_SOURCE_RECOVERY.json for exact Git duplicates.','files':inventory}
    (root/'integration'/f'pr{number}-package.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print(json.dumps({k:v for k,v in receipt.items() if k!='files'}))
