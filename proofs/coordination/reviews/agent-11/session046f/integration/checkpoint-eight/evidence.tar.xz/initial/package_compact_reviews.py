"""Package complete compact reviewer artifacts with lossless round-trip checks."""
import argparse
import hashlib
import io
import json
from pathlib import Path
import tarfile

p = argparse.ArgumentParser()
p.add_argument('numbers', type=int, nargs='+')
a = p.parse_args()
root = Path(__file__).resolve().parent.parent
for number in a.numbers:
    source = root / f'review{number}' / 'publish-evidence'
    files = {f.relative_to(source).as_posix(): f.read_bytes()
             for f in sorted(source.rglob('*')) if f.is_file()}
    assert files and 'REVIEW.md' in files
    output = root / 'integration' / f'pr{number}-review-evidence.tar.xz'
    with tarfile.open(output, 'w:xz') as archive:
        for name, data in files.items():
            item = tarfile.TarInfo(name)
            item.size, item.mode, item.mtime = len(data), 0o644, 0
            archive.addfile(item, io.BytesIO(data))
    with tarfile.open(output, 'r:xz') as archive:
        recovered = {x.name: archive.extractfile(x).read() for x in archive.getmembers()}
    assert recovered == files
    data = output.read_bytes()
    receipt = {
        'pr': number, 'archive': output.name, 'bytes': len(data),
        'sha256': hashlib.sha256(data).hexdigest(),
        'git_blob': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(),
        'roundtrip': 'PASS', 'retained_files': len(files),
        'scope': 'Every file from the independent reviewer compact publication directory. Exact original-source duplicates are recoverable through the enclosed immutable maps.',
        'recovery': 'tar -xJf ' + output.name,
        'files': {name: {'bytes': len(data), 'sha256': hashlib.sha256(data).hexdigest()}
                  for name, data in files.items()}
    }
    (root / 'integration' / f'pr{number}-package.json').write_text(json.dumps(receipt, indent=2) + '\n')
    print(json.dumps({k: v for k, v in receipt.items() if k != 'files'}))
