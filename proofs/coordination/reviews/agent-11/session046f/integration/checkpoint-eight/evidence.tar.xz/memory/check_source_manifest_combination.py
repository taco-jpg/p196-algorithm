"""Check canonical source-manifest pins in an intended integration tree."""
import argparse,hashlib,json,subprocess
from pathlib import Path
p=argparse.ArgumentParser()
for n in ('repo','head','tree','registry','output'):p.add_argument('--'+n,required=True)
a=p.parse_args()
def read(ref,path):return subprocess.check_output(['git','-C',a.repo,'show',ref+':'+path])
raw=read(a.head,a.registry);assert raw==read(a.tree,a.registry)
j=json.loads(raw)
rows=j['sources'] if 'sources' in j else j['modules']
assert isinstance(rows,list) and rows
checks=[]
for row in rows:
 path=row.get('repo_path',row.get('source'))
 assert path and row['module']
 data=read(a.tree,path);assert data==read(a.head,path)
 sha=hashlib.sha256(data).hexdigest()
 blob=hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
 assert sha==row['sha256'] and blob==row['git_blob']
 if 'size_bytes' in row:assert len(data)==row['size_bytes']
 checks.append({'module':row['module'],'path':path,'bytes':len(data),'sha256':sha,'git_blob':blob})
out={'status':'PASS','scope':'Exact canonical source-manifest identity in combined tree; no Lean execution.','head':a.head,'tree':a.tree,'manifest':a.registry,'manifest_sha256':hashlib.sha256(raw).hexdigest(),'modules':checks}
Path(a.output).write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps({'status':'PASS','head':a.head,'tree':a.tree,'modules':len(checks)}))
