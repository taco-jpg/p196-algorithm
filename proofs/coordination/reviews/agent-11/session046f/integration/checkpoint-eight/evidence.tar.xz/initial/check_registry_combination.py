"""Verify every exact registry source pin in the intended combined Git tree."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess

p = argparse.ArgumentParser()
p.add_argument('--repo', required=True)
p.add_argument('--head', required=True)
p.add_argument('--tree', required=True)
p.add_argument('--registry', required=True)
p.add_argument('--output', required=True)
a = p.parse_args()
def read(ref, path):
    return subprocess.check_output(['git', '-C', a.repo, 'show', ref + ':' + path])
registry_bytes = read(a.head, a.registry)
assert registry_bytes == read(a.tree, a.registry)
registry = json.loads(registry_bytes)
checks = []
for project in registry['projects'].values():
    for name, entry in project['modules'].items():
        source = read(a.tree, entry['path'])
        digest = hashlib.sha256(source).hexdigest()
        blob = hashlib.sha1(b'blob ' + str(len(source)).encode() + b'\0' + source).hexdigest()
        assert source == read(a.head, entry['path'])
        assert digest == entry['sha256']
        assert blob == entry['git_blob']
        checks.append({'module': name, 'path': entry['path'], 'sha256': digest, 'git_blob': blob})
receipt = {'status': 'PASS', 'scope': 'Exact registry and source identities; not a fresh Lean execution.',
           'head': a.head, 'combined_tree': a.tree, 'registry': a.registry,
           'registry_sha256': hashlib.sha256(registry_bytes).hexdigest(), 'modules': checks}
Path(a.output).write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({'status': 'PASS', 'head': a.head, 'tree': a.tree, 'modules': len(checks)}))
