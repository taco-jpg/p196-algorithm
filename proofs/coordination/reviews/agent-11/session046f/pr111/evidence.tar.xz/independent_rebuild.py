#!/usr/bin/env python3
"""Agent #11 session046f9285a650 independent frozen PR111 scoped replay."""
from pathlib import Path
import subprocess,json,hashlib,os,re,time,importlib.util,traceback
ROOT=Path(__file__).resolve().parent
REPO=ROOT.parent/'repo'
H='bf4ff749000a6995e1755e37b59988ef362bae16'
B='5ff4f607535587d572fbc9e95ba9501d1fbe5fc5'
TREE='480cf6baefa41e32c0a57dc6b45dd980dc86df78'
LEAN=Path('/workspace/scratch/8b5152316f75/runtime-agent1/toolchain/lean-4.19.0-linux/bin/lean')
OUT=ROOT/'fresh-001'
OUT.mkdir(exist_ok=False)
SRC=OUT/'source';SRC.mkdir();LOGS=OUT/'logs';LOGS.mkdir()
sha=lambda d:hashlib.sha256(d).hexdigest()
report={'reviewer':'Agent #11 session046f9285a650 /root/review111','H':H,'B':B,'combined_tree':TREE,'scope':'14-module exact closure; no repository-wide assertion','status':'RUNNING','commands':[],'sources':{}}
def save(): (OUT/'verification.json').write_text(json.dumps(report,indent=2)+'\n')
def git(*a):return subprocess.check_output(['git','-C',str(REPO),*a])
def run(label,argv,cwd=SRC,env=None):
 t=time.monotonic();p=subprocess.run(argv,cwd=cwd,env=env,capture_output=True,timeout=1800);data=p.stdout+p.stderr;(LOGS/(label+'.log')).write_bytes(data)
 report['commands'].append({'label':label,'argv':argv,'cwd':str(cwd),'env':env,'exit_code':p.returncode,'elapsed_seconds':round(time.monotonic()-t,6),'log_sha256':sha(data)});save();print(label,p.returncode,flush=True)
 if p.returncode:raise RuntimeError('Failed '+label)
 return data.decode()
try:
 regpath=ROOT/'frozen/proofs/Agent1PeriodicQuotient.registry.json';reg=json.loads(regpath.read_text());modules=reg['projects']['agent1-periodic-quotient']['modules']
 version=run('version',[str(LEAN),'--version']);assert 'version 4.19.0' in version and 'commit 6caaee842e94' in version
 runtime=Path(run('prefix',[str(LEAN),'--print-prefix']).strip())
 report['runtime']={'version':version.strip(),'root':str(runtime),'files':{str(p):sha(p.read_bytes()) for p in [LEAN,*sorted((runtime/'lib/lean').glob('*.so'))]}}
 report['registry_sha256']=sha(regpath.read_bytes())
 checker=ROOT/'frozen/proofs/verify_project__214bf7673efe116b.py'
 spec=importlib.util.spec_from_file_location('inspected_checker',checker);c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
 for name,rec in modules.items():
  data=(ROOT/'frozen'/rec['path']).read_bytes();assert sha(data)==rec['sha256'];assert sha(git('show',H+':'+rec['path']))==rec['sha256'];assert git('hash-object','--stdin') if False else True
  assert hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()==rec['git_blob'];assert git('rev-parse',TREE+':'+rec['path']).decode().strip()==rec['git_blob']
  code=c.code_only(data.decode());assert not re.search(r"(?<![\w'])\b(?:sorry|admit|axiom|sorryAx|native_decide|ofReduceBool|skipKernelTC)\b(?![\w'])",code)
  imports=[d for line in re.findall(r'^\s*import\s+([^\n]+)',code,re.M) for d in line.split()];assert imports==rec['imports']
  assert all(d in modules or d in ['Std','Lean','Init'] for d in imports)
  (SRC/(name+'.lean')).write_bytes(data);report['sources'][name]=rec
 for path in ['proofs/Agent1PeriodicQuotient.registry.json','proofs/verify_project__214bf7673efe116b.py']:
  assert git('rev-parse',H+':'+path)==git('rev-parse',TREE+':'+path)
 order=[]
 def visit(n):
  if n not in modules or n in order:return
  for d in modules[n]['imports']:visit(d)
  order.append(n)
 visit('Agent1PeriodicQuotient');assert set(order)==set(modules);report['build_order']=order
 assert not list(SRC.glob('*.olean'))
 env={'PATH':str(LEAN.parent)+':/usr/bin:/bin','LANG':'C.UTF-8','LEAN_PATH':str(SRC)}
 report['initial_olean_count']=0;save()
 for n in order:run(n,[str(LEAN),'--trust=0','-j1','-DElab.async=false','-o',n+'.olean',n+'.lean'],env=env)
 audit='import Agent1PeriodicQuotient\nimport Lean\nopen Lean Elab Command\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\n'
 audit+='\n'.join('#check '+e for cl in reg['claims'] for e in cl['endpoints'])+'\n'
 audit+='run_cmd do\n  let env ← getEnv\n  let selected : List String := '+json.dumps(order)+'''
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut counts : List (String × Nat) := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        let kind := match info with
          | .axiomInfo _ => "axiom"
          | .defnInfo _ => "definition"
          | .thmInfo _ => "theorem"
          | .opaqueInfo _ => "opaque"
          | .quotInfo _ => "quotient"
          | .inductInfo _ => "inductive"
          | .ctorInfo _ => "constructor"
          | .recInfo _ => "recursor"
        let unsafeDecl := info.isUnsafe
        logInfo m!"DECLARATION {mod} {kind} {name} unsafe={unsafeDecl}"
        if unsafeDecl then
          logInfo m!"UNSAFE_IMPLEMENTATION {mod} {kind} {name}"
        else
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          if kind == "axiom" then throwError m!"CUSTOM_AXIOM {mod} {name}"
          if axl.any (fun ax => !(allowed.contains ax)) then throwError m!"DISALLOWED_AXIOMS {mod} {name} : {axl}"
          logInfo m!"AUDIT_SAFE {mod} {kind} {name} : {axl}"
        let old := (counts.find? (fun kv => kv.1 == kind)).map Prod.snd |>.getD 0
        counts := (kind, old + 1) :: counts.filter (fun kv => kv.1 != kind)
  logInfo m!"COMPLETE_DECLARATION_COUNTS {counts}"
'''
 (SRC/'IndependentAudit.lean').write_text(audit)
 text=run('IndependentAudit',[str(LEAN),'--trust=0','-j1','-DElab.async=false','IndependentAudit.lean'],env=env)
 declarations=re.findall(r'^DECLARATION (\S+) (\S+) (\S+) unsafe=(\S+)$',text,re.M)
 audited=re.findall(r'^AUDIT_SAFE (\S+) (\S+) (\S+) : (.*)$',text,re.M)
 unsafe=re.findall(r'^UNSAFE_IMPLEMENTATION (\S+) (\S+) (\S+)$',text,re.M)
 assert len({d[2] for d in declarations})==len(declarations)
 assert len(audited)+len(unsafe)==len(declarations)
 assert {d[2] for d in declarations if d[3]=='false'}=={d[2] for d in audited}
 from collections import Counter
 report['declaration_counts']=dict(Counter(d[1] for d in declarations));report['safe_counts']=dict(Counter(d[1] for d in audited));report['unsafe_implementation_declarations']=unsafe
 report['per_module_counts']={n:dict(Counter(d[1] for d in audited if d[0]==n)) for n in order}
 (OUT/'declarations.json').write_text(json.dumps({'all':declarations,'safe_audited':audited,'unsafe_implementation':unsafe},indent=2)+'\n')
 for n,r in modules.items():assert sha((SRC/(n+'.lean')).read_bytes())==r['sha256']
 for p,h in report['runtime']['files'].items():assert sha(Path(p).read_bytes())==h
 report['status']='PASS';save()
except Exception as e:
 report['status']='FAIL';report['error']=str(e);(OUT/'failure.txt').write_text(traceback.format_exc());save();raise
finally:
 files={str(p.relative_to(OUT)):{'bytes':p.stat().st_size,'sha256':sha(p.read_bytes())} for p in sorted(OUT.rglob('*')) if p.is_file() and p.suffix!='.olean' and p.name!='FILES.json'}
 (OUT/'FILES.json').write_text(json.dumps(files,indent=2)+'\n')
