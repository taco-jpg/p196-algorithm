#!/usr/bin/env python3
"""Read-only source/evidence integrity audit by Agent #11 session046f9285a650."""
from pathlib import Path
import subprocess,json,hashlib,re,collections,importlib.util
R=Path(__file__).resolve().parent;F=R/'frozen';G=R.parent/'repo';H='bf4ff749000a6995e1755e37b59988ef362bae16';B='5ff4f607535587d572fbc9e95ba9501d1fbe5fc5';T='480cf6baefa41e32c0a57dc6b45dd980dc86df78';P=F/'proofs/contributions/agent-1/periodic-block-strip-20261016';sha=lambda d:hashlib.sha256(d).hexdigest()
def git(*a):return subprocess.check_output(['git','-C',str(G),*a])
reg=json.loads((F/'proofs/Agent1PeriodicQuotient.registry.json').read_text());modules=reg['projects']['agent1-periodic-quotient']['modules']
cs=importlib.util.spec_from_file_location('inspected_checker',F/'proofs/verify_project__214bf7673efe116b.py');c=importlib.util.module_from_spec(cs);cs.loader.exec_module(c)
report={'reviewer':'Agent #11 session046f9285a650 /root/review111','H':H,'B':B,'combined_tree':T,'status':'PASS','checks':{},'limitations':['No fresh Lean execution: supplied runtime --version exited 1 (failed to locate application).','All retained Lean build/audit execution is attributed to Agent #1 specialist research_status, not this reviewer.','A new exhaustive environment census was drafted but not executed.']}
changes=git('diff','--name-status',B+'...'+H).decode().splitlines();assert len(changes)==159;assert all(x.startswith('A\t') for x in changes);report['checks']['changed_paths']={'count':len(changes),'all_additions':True}
paths=[x[2:] for x in changes]
for p in paths:assert (F/p).read_bytes()==git('show',H+':'+p)
closure=[]
for n,r in modules.items():
 d=(F/r['path']).read_bytes();assert sha(d)==r['sha256'];assert hashlib.sha1(f'blob {len(d)}\0'.encode()+d).hexdigest()==r['git_blob'];assert git('rev-parse',T+':'+r['path']).decode().strip()==r['git_blob']
 assert (P/'parent/clean-001/agent1-periodic-quotient/source'/f'{n}.lean').read_bytes()==d
 if n.startswith('Agent1'):assert (P/'review/clean-001'/f'{n}.lean').read_bytes()==d
 code=c.code_only(d.decode());found=re.findall(r"(?<![\w'])\b(?:sorry|admit|axiom|sorryAx|native_decide|ofReduceBool|skipKernelTC)\b(?![\w'])",code);assert not found,(n,found)
 imp=[a for line in re.findall(r'^\s*import\s+([^\n]+)',code,re.M) for a in line.split()];assert imp==r['imports'];assert all(x in modules or x=='Std' for x in imp)
 closure.append(dict(module=n,**r,combined_blob=git('rev-parse',T+':'+r['path']).decode().strip()))
report['checks']['source_closure']=closure
for p in ['proofs/Agent1PeriodicQuotient.registry.json','proofs/verify_project__214bf7673efe116b.py']:
 assert git('rev-parse',H+':'+p)==git('rev-parse',T+':'+p)
report['checks']['combined_registry_and_checker_identical']=True
manifest=json.loads((P/'EVIDENCE.json').read_text());errors=[]
for p,m in manifest['files'].items():
 d=(F/p).read_bytes()
 if sha(d)!=m['sha256'] or len(d)!=m['bytes']:errors.append(p)
assert not errors,errors
listed=set(manifest['files']);unlisted=[p for p in paths if p.startswith('proofs/contributions/') and p not in listed]
report['checks']['evidence_manifest']={'entries':len(listed),'all_bytes_sha256_match':True,'unlisted_changed_contribution_paths':unlisted}
ind=json.loads((P/'review/clean-001/results.json').read_text());assert len(ind)==15
for x in ind:
 assert x['exit_code']==0
 assert all(a in x['command'] for a in ['--trust=0','-j1','-DElab.async=false'])
 assert sha((P/'review/clean-001'/f"{x['module']}.log").read_bytes())==x['log_sha256']
report['checks']['reused_commands']={'count':len(ind),'all_success':True,'all_strict_flags':True,'all_log_hashes_match':True}
logs=(P/'review/clean-001/ReviewAudit.log').read_text();rows=re.findall(r'^AUDIT_THEOREM (\S+) (\S+) : \[([^\]]*)\]',logs,re.M);assert len(rows)==1343;assert len({x[1] for x in rows})==1343;assert {x[0] for x in rows}==set(modules)
allowed={'propext','Classical.choice','Quot.sound'};union=set()
for m,n,ax in rows:
 axs=set(ax.split(', ')) if ax else set();assert axs<=allowed,(n,axs);union|=axs
assert union==allowed
assert 'FULL_MODULE_AUDIT theorems=1343 union=[Classical.choice, Quot.sound, propext]' in logs
unsafe=re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$',logs,re.M)
report['checks']['reused_transitive_theorem_audit']={'count':1343,'per_module':dict(collections.Counter(x[0] for x in rows)),'axiom_union':sorted(union),'unsafe_implementation_axioms':unsafe,'note':'Unsafe implementation axioms are logged separately; none occurs in any audited theorem transitive axiom set.'}
newmods=['Agent1PeriodicOuterStrip','Agent1PeriodicCenterStrip','Agent1PeriodicQuotient'];decls=[];names={x[1] for x in rows}
witness={
'stripPeriodSuffixAux':'stripPeriodSuffixAux_spec','stripPeriodSuffix':'stripPeriodSuffix_spec',
'stripPeriodMiddle':'stripPeriodMiddle_wrap','stripPeriodCenterAux':'stripPeriodCenterAux_decomposition','stripPeriodCenter':'stripPeriodCenter_decomposition',
'quotientOuter':'quotient_step_bounded','quotientCenter':'quotient_step_bounded','outerPeriods':'quotient_step_bounded','centerPeriods':'quotient_step_bounded','exponentDelta':'quotient_width_balance'}
for m in newmods:
 code=c.code_only((F/modules[m]['path']).read_text());assert not re.search(r'\b(?:unsafe|partial|extern|implemented_by|opaque|axiom)\b',code)
 for k,n in re.findall(r'^(def|theorem)\s+(\w+)',code,re.M):
  full='Agent1.Periodic.'+n;w=full if k=='theorem' else 'Agent1.Periodic.'+witness[n];assert w in names
  if k=='def':assert re.search(r'\b'+n+r'\b',code[code.index('theorem '+witness[n]):])
  decls.append({'module':m,'kind':k,'name':full,'retained_audit_witness':w,'coverage':'direct theorem audit' if k=='theorem' else 'safe transparent definition explicitly present in audited theorem type; source body inspected'})
assert collections.Counter(x['kind'] for x in decls)=={'def':10,'theorem':26}
report['checks']['new_public_declarations']=decls
original=F/'proofs/periodic_word_quotient__8404d0a63dd1fa13.py';assert sha(original.read_bytes())=='122fcd390283f956f97d21327ec6cb9d4ae193e9bd3ab1b155bb65e1e61c2425'
report['checks']['original_algorithm_sha256']=sha(original.read_bytes())
rr=P/'review/final-review-receipt.json';receipt=json.loads(rr.read_text());receipt_map={'replay.py':P/'review/replay.py','final-source-identity.json':P/'review/final-source-identity.json','final-semantic-review.md':P/'review/final-semantic-review.md','verification.json':P/'review/clean-001/verification.json'}
for n,h in receipt['files'].items():assert sha(receipt_map[n].read_bytes())==h
review_sources=json.loads((P/'review/final-source-identity.json').read_text())['sources'];assert len(review_sources)==14
for e in review_sources:
 for key in ['path','sha256','git_blob','imports']:assert e[key]==modules[e['module']][key]
report['checks']['review_receipt_and_manifest_match']=True
runtime=Path('/workspace/scratch/8b5152316f75/runtime-agent1/toolchain/lean-4.19.0-linux');binary=sha((runtime/'bin/lean').read_bytes());assert binary=='92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023'
parent=json.loads((P/'parent/clean-001/verification.json').read_text());compiler=parent['compiler'];comparisons=[]
for path,h in compiler['files'].items():
 q=runtime/('bin/lean' if Path(path).name=='lean' else 'lib/lean/'+Path(path).name);actual=sha(q.read_bytes());assert actual==h;comparisons.append({'basename':q.name,'sha256':actual})
report['checks']['runtime_hashes_match_parent_record']=comparisons
report['checks']['runtime_version_evidence']={'current_execution':'FAILED before build','retained_review_version':json.loads((P/'review/clean-001/compiler.json').read_text())['version'],'binary_sha256':binary,'note':'Retained independent reviewer pins binary and version; parent retained report additionally hashes shared libraries, verified against the supplied read-only runtime.'}
(R/'static-evidence-audit.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':'PASS','changed_paths':159,'closure':len(closure),'evidence_entries':len(listed),'unlisted':unlisted,'reused_theorems':len(rows),'new_declarations':len(decls),'runtime_hash_comparisons':len(comparisons)},indent=2))
