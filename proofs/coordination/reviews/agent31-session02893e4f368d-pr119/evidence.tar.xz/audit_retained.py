import pathlib,json,hashlib,re,collections,importlib.util,sys
p=pathlib.Path(__file__).parent;a=p/'archive';v=json.loads((a/'verification-clean-001/verification.json').read_text());s=json.loads((p/'SOURCES.json').read_text());reg=json.loads((p/'BUILD_REGISTRY.json').read_text());mods=reg['projects']['agent103-residual-five-fibers']['modules']
sh=lambda b:hashlib.sha256(b).hexdigest()
gb=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
# The imported checker has been read; importing defines pure helpers and does not call guarded main().
sys.dont_write_bytecode=True
spec=importlib.util.spec_from_file_location('inspected_checker',p/'check.py');c=importlib.util.module_from_spec(spec);spec.loader.exec_module(c)
assert sh((p/'SOURCES.json').read_bytes())==v['manifest_sha256']
assert sh((p/'check.py').read_bytes())==v['driver_sha256']
for n in ['SOURCES.json','BUILD_REGISTRY.json','FILES.json','UNSAFE_IMPLEMENTATIONS.json','check.py','REPRODUCE.md','non-author-final-review.json','non-author-final-review.md']:
 assert (p/n).read_bytes()==(a/n).read_bytes(),n
# Every actual log and execution record, plus every non-object nested manifest entry.
command_summary=[]
for x in v['commands']:
 data=(a/'verification-clean-001'/x['log']).read_bytes()
 assert sh(data)==x['log_sha256'] and x['exit_code']==0
 if x['label'] not in ('version','prefix'):
  assert x['argv'][1:4]==['--trust=0','-j1','-DElab.async=false']
  assert x['environment']['LEAN_PATH']==x['cwd']
  assert set(x['environment'])=={'PATH','LANG','TZ','LEAN_PATH'}
 assert not re.search(r'\berror:',data.decode())
 if x['label'] in s['new_modules']: assert not re.search(r'\bwarning:',data.decode())
 command_summary.append({'label':x['label'],'exit_code':x['exit_code'],'bytes':len(data),'sha256':sh(data),'argv':x['argv'],'environment':x['environment']})
nested_indexes=0
for index_path in a.glob('*/FILES.json'):
 for n,r in json.loads(index_path.read_text()).items():
  data=(index_path.parent/n).read_bytes()
  assert len(data)==r['bytes'] and sh(data)==r['sha256']
  nested_indexes+=1
full_log=(a/'verification-clean-001/logs/AuditAllContributionModules.log').read_text()
# Independently reconstruct every raw record; assert there are no unrecognized nonempty lines.
def read_audit(text):
 pattern=re.compile(r"^AUDIT_THEOREM (\S+) ([^\n]+)\n'([^\n]+)' (?:does not depend on any axioms|depends on axioms:\s*\[([^\]]*)\])$",re.M)
 entries={}
 consumed=[]
 for m in pattern.finditer(text):
  module,name,printed,ax=m.groups(); assert name==printed and name not in entries
  axioms=[] if ax is None else sorted(x.strip() for x in ax.split(',') if x.strip())
  assert set(axioms)<={'propext','Classical.choice','Quot.sound'}
  entries[name]={'module':module,'axioms':axioms};consumed.append(m.span())
 unsafe=re.findall(r'^UNSAFE_IMPL (\S+) ([^\n]+)$',text,re.M)
 complete=re.findall(r'^AUDIT_COMPLETE ([0-9]+)$',text,re.M)
 assert len(complete)==1 and int(complete[0])==len(entries)
 residual=pattern.sub('',text);residual=re.sub(r'^UNSAFE_IMPL [^\n]+$|^AUDIT_COMPLETE [0-9]+$','',residual,flags=re.M)
 assert not residual.strip(),repr(residual[:400])
 return entries,unsafe
entries,unsafe=read_audit(full_log)
assert entries==v['theorems'] and len(entries)==1812 and len(unsafe)==33
assert [list(x) for x in unsafe]==v['unsafe_implementation_constants']
assert collections.Counter(x['module'] for x in entries.values())=={k:n for k,n in v['module_theorem_counts'].items() if n}
prior=json.loads((a/'dependency-audit-001/verification.json').read_text())
pe,pu=read_audit((a/'dependency-audit-001/audit.log').read_text())
assert pe==prior['theorems'] and len(pe)==1701
assert {n:r for n,r in entries.items() if r['module'] in s['dependencies']}==pe
assert len(pu)==30 and set(pu)<=set(unsafe)
# Original identity, normalized compiled identity, import graph and full forwarder body.
source_summary={}
for name,r in {**s['dependencies'],**s['new_modules']}.items():
 original=(a/'verification-clean-001/originals'/f'{name}.lean').read_bytes()
 compiled=(a/'verification-clean-001/snapshot'/f'{name}.lean').read_bytes()
 assert sh(original)==r['sha256']
 assert gb(original)==r.get('git_blob',r.get('git_blob_of_bytes'))
 assert sh(compiled)==v['sources'][name]['compiled_sha256']==mods[name]['sha256']
 assert gb(compiled)==mods[name]['git_blob']
 assert c.imports_of(compiled)==r['imports']==mods[name]['imports']
 if 'adapter' in r:
  ar=r['adapter'];prefix=ar['excluded_exact_prefix_utf8'].encode();assert original.startswith(prefix)
  body=original[len(prefix):];container=(a/'verification-clean-001/originals'/f"{ar['container_module']}.lean").read_bytes()
  at=container.find(body);assert at>=0 and container.find(body,at+1)<0
  assert len(body.splitlines(keepends=True))==4444 and container[:at].count(b'\n')+1==11
  assert compiled==b'import LychrelDigitSums\n' and sh(body)=='c457c36664c186ce10f38d492460fe67f5318c7edf14ff9b930b00b7f67f3402'
 else: assert original==compiled
 staged=a/'registry-check-only-001/agent103-residual-five-fibers/source'/f'{name}.lean'
 assert staged.read_bytes()==compiled
 source_summary[name]={'path':mods[name]['path'],'original_sha256':sh(original),'compiled_sha256':sh(compiled),'git_blob':gb(compiled),'imports':r['imports'],'source_pin_commit':r.get('commit'),'source_pin_path':r.get('path')}
order=[];active=set()
def visit(name):
 if name in order:return
 assert name not in active
 if name not in mods: assert name in ('Std','Lean','Init');return
 active.add(name)
 for dep in mods[name]['imports']:visit(dep)
 active.remove(name);order.append(name)
visit('ResidualFiveFilteredConclusion');assert order==v['build_order'] and set(order)==set(mods)
audit=(a/'verification-clean-001/snapshot/AuditAllContributionModules.lean').read_bytes()
assert sh(audit)==v['audit_source_sha256'] and audit.decode()==c.audit_source(order)
endpoints=[]
for claim in reg['claims']:
 for name in claim['endpoints']:
  assert entries[name]['module']==claim['module'];endpoints.append(name)
review_summary=[]
for f in (a/'reviews').glob('*.review.json'):
 r=json.loads(f.read_text());assert r['reviewer']!=r['author'] and r['reviewer']=='/root/runtime'
 assert r['source_sha256']==s['new_modules'][r['module']]['sha256'] and r['semantic_status']=='PASS'
 assert r['compiled_module_theorem_count']==v['module_theorem_counts'][r['module']] and not r['findings']
 review_summary.append({'module':r['module'],'author':r['author'],'reviewer':r['reviewer'],'source_sha256':r['source_sha256']})
assert len(review_summary)==7
result={'status':'PASS_RETAINED_RECORD_BINDING','new_lean_execution':'NOT_RUN','archive_member_count':143,'nested_index_entries_verified':nested_indexes,'all_raw_audit_records_reconstructed':True,'theorem_count':len(entries),'inherited_theorems_exactly_preserved':len(pe),'new_module_theorems':len(entries)-len(pe),'unsafe_axiomInfo_isUnsafe_entries':len(unsafe),'unsafe_inherited':len(pu),'unsafe_new':len(unsafe)-len(pu),'all_axioms':sorted(set(z for e in entries.values() for z in e['axioms'])),'build_order':order,'commands':command_summary,'sources':source_summary,'independent_reviews':review_summary,'registry_endpoints':endpoints,'compiler_identity':v['lean'],'fresh_build_started_utc':v['started_utc'],'fresh_build_finished_utc':v['finished_utc']}
(p/'raw-record-binding.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:x for k,x in result.items() if k not in ['sources','commands','compiler_identity']},indent=2))
