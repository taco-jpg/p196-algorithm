#!/usr/bin/env python3
"""Read-only binding checks for reuse of existing PR164 documentation reviews."""
import base64
import csv
import hashlib
import io
import json
import os
from pathlib import Path
import subprocess

OUT = Path(__file__).resolve().parent
REPO = '/workspace/scratch/7efd48098de6/agent1-repo'
H = 'fa2683e489acc7c85e08764450550f7e463041da'
B = '74a1c3922eb7af438fe40b23d2105ad07556e3f5'
PIN = '10a173cb635fa8d03e357f454232816fc3e77609'
P = 'proofs/contributions/agent-61/documentation-20261016/'
A = f'proofs/archive/documentation/agent-61/{PIN}/'
raw = json.loads((OUT / 'retrieved-evidence.json').read_text())
env = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
transcript = []

def git(*args):
    cmd = ['git', '-C', REPO, *args]
    r = subprocess.run(cmd, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    transcript.append({'argv': cmd, 'environment_overrides': {'GIT_NO_LAZY_FETCH':'1', 'GIT_OPTIONAL_LOCKS':'0'}, 'exit_code': r.returncode, 'stdout': r.stdout.decode(errors='replace'), 'stderr': r.stderr.decode(errors='replace')})
    if r.returncode:
        raise RuntimeError(r.stderr.decode(errors='replace'))
    return r.stdout

def data(name):
    r = raw['files'][name]
    assert r['status'] == 'fulfilled' and not r['value']['isError']
    return r['value']['structuredContent']['content'].encode()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()

def entries(ref, paths):
    # Exact paths keep traversal away from unrelated missing promisor subtrees.
    result = {}
    for record in git('ls-tree', '-r', '-t', '-z', ref, '--', *paths).split(b'\0'):
        if not record:
            continue
        meta, path = record.decode().split('\t', 1)
        mode, kind, oid = meta.split()
        result[path] = {'mode':mode, 'kind':kind, 'oid':oid}
    return result

result = {'source_head':H, 'tested_base':B, 'documentation_source_pin':PIN,
          'repository':REPO, 'checks': {}, 'limitations': [
              'No Lean execution, historical replay, publication generator, source edits, Git writes, or remote publication.',
              'New byte reads cover retrieved metadata/reports; complete 53-file byte accounting is reused from the retained independent review and rebound to H through Git blob identities.',
              'Full integration simulation, live PR/head/base checks, platform requirements, and serialized target-write ownership are parent responsibilities.'
          ]}
try:
    inv = json.loads(data('FILES.json'))
    assert inv['file_count']==len(inv['files'])==53
    assert inv['stored_bytes']==sum(x['bytes'] for x in inv['files'])==6046325
    rows = {x['path']: x for x in inv['files']}
    assert len(rows)==53 and list(rows)==sorted(rows)
    manifest = ''.join(f"{x['sha256']}  {x['path']}\n" for x in inv['files']).encode()
    assert manifest == data('MANIFEST.sha256')
    assert sha(data('FILES.json'))=='d6ece44746da8e71ef4aef0415f180273b9d3e5a511a0ec11cc4be0937190d77'
    assert sha(data('MANIFEST.sha256'))=='b259127f869b8b08455dc6a5bdbe146507d0763bdcaaacf2d401e78dc067dbc8'
    all_head = entries(H, [P.rstrip('/'), A.rstrip('/'), 'proofs/FINDINGS.md', 'proofs/CONSOLIDATION.md', 'proofs/SOURCE_MAP.json'])
    selected = {p:v for p,v in all_head.items() if v['kind']=='blob' and p not in inv['self_exclusions']}
    assert set(selected)==set(rows)
    for p,r in rows.items():
        assert selected[p]=={'mode':r['mode'],'kind':'blob','oid':r['git_blob']}, p
    result['checks']['inventory']={'status':'PASS','selected_paths':53,'stored_bytes_from_hash_bound_inventory':6046325,'publication_files_including_self_excluded_metadata':55,'all_selected_blob_modes_match_H':True,'manifest_projection_matches':True}
    read_bytes=[]
    for name,record in raw['files'].items():
        b=data(name)
        path=P+name
        reported=record['value']['structuredContent']['sha']
        assert blob(b)==reported==all_head[path]['oid'],path
        if path in rows:
            r=rows[path]
            assert len(b)==r['bytes'] and sha(b)==r['sha256'],path
        read_bytes.append({'path':path,'bytes':len(b),'sha256':sha(b),'git_blob':blob(b)})
    result['checks']['retrieved_bytes']={'status':'PASS','file_count':len(read_bytes),'files':read_bytes}
    reviews=raw['reviews']['structuredContent']['reviews']
    relayed=[]
    for r in reviews:
        encoded=r['id'].split('_',1)[1]
        decoded=base64.urlsafe_b64decode(encoded+'='*((-len(encoded))%4))
        review_id=int.from_bytes(decoded[-8:],'big')
        relayed.append({'graph_id':r['id'],'decoded_database_id':review_id,'state':r['state'],'author':r['author']['login'],'submitted_at':r['submitted_at'],'body_sha256':sha(r['body'].encode())})
    assert [r['decoded_database_id'] for r in relayed]==[5555035942,5555118265]
    final=reviews[1]['body'].split('## Complete final accounting report, relayed unchanged\n\n',1)[1]
    assert sha(final.encode())=='29c058ae06628d9cd716aa86667ecbb5529d566a89b21d5636b74a0b334df0d9'
    assert H in reviews[1]['body']
    result['checks']['formal_review_relays']={'status':'PASS','reviews':relayed,'exact_final_report_sha256':sha(final.encode()),'note':'Attribution relay by sodium-qed; underlying independent AI-agent inspection is distinct from account-level approval.'}
    tsv=data('audit/statement/final-source-refresh-identities.tsv')
    assert sha(tsv)=='2bef091a56fad45234dd14ca9145cc9e3969c2b93585c633d11ef27e735e0fce'
    detail=list(csv.DictReader(io.StringIO(tsv.decode()),delimiter='\t'))
    assert len(detail)==len({r['path'] for r in detail})==382
    refs={ref:entries(ref,[r['path'] for r in detail]) for ref in [PIN,B,H]}
    for r in detail:
        p=r['path']
        assert r['unchanged']=='true' and r['checkpoint_oid']==r['observed_main_oid']
        expected={'mode':r['mode'],'kind':r['type'],'oid':r['checkpoint_oid']}
        assert refs[PIN][p]==refs[B][p]==expected,p
        if p not in ['proofs/FINDINGS.md','proofs/CONSOLIDATION.md','proofs/SOURCE_MAP.json']:
            assert refs[H][p]==expected,p
    result['checks']['source_refresh']={'status':'PASS','selected_paths':382,'blobs':sum(r['type']=='blob' for r in detail),'trees':sum(r['type']=='tree' for r in detail),'all_match_at_pin_and_B':True,'all_379_unedited_selections_match_H':True,'expected_candidate_changes':['proofs/FINDINGS.md','proofs/CONSOLIDATION.md','proofs/SOURCE_MAP.json']}
    prior=entries('3404261e09881003b8110bc64623031c00dda2a2',[P+'audit',P+'review',P+'checks'])
    prior_files={p:v for p,v in prior.items() if v['kind']=='blob'}
    assert len(prior_files)==20
    assert all(all_head[p]==v for p,v in prior_files.items())
    result['checks']['prior_evidence_preserved']={'status':'PASS','unchanged_prior_audit_review_check_files':20}
    changes = [line.split('\t', 1) for line in git('diff', '--no-renames', '--name-status', PIN, H).decode().splitlines()]
    expected_paths = set(rows) | set(inv['self_exclusions'])
    assert {p for _,p in changes} == expected_paths
    assert len(changes)==55
    assert {p for status,p in changes if status=='M'} == {'proofs/FINDINGS.md','proofs/CONSOLIDATION.md','proofs/SOURCE_MAP.json'}
    assert all(status in ['A','M'] for status,p in changes)
    result['checks']['source_scope']={'status':'PASS','changed_paths':55,'modified_existing_paths':3,'added_paths':52,'no_mathematical_source_or_public_verifier_change':True,'changes':changes}
    for n,expected in [('HANDOFF.md','60f42d98043077da325fd7dfcc2f5211a4423a1800d87d6cf994b5902a12acad'),('REVIEWS.md','835a67a7565674d9561e0cb268be2164affff56ecb11a1784bc297ee15c7ba58'),('generate_inventory.py','a33f4c22f9334f512ae971589d8b2a1771b75014ea3d7679d1ab8fc353f296ab')]:
        assert sha(data(n))==expected
    result['status']='PASS_RETAINED_REVIEW_REUSE'
except Exception as e:
    result['status']='INCOMPLETE_OR_FAILED'
    result['error']=repr(e)
finally:
    (OUT/'validation-commands.json').write_text(json.dumps(transcript,indent=2)+'\n')
    (OUT/'validation-results.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps({'status':result['status'],'checks':{k:{kk:vv for kk,vv in v.items() if kk not in ['files','reviews']} for k,v in result['checks'].items()},'error':result.get('error')},indent=2))
if result['status']!='PASS_RETAINED_REVIEW_REUSE':
    raise SystemExit(1)
