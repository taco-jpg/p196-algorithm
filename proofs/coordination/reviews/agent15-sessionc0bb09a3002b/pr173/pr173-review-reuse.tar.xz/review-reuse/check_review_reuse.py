#!/usr/bin/env python3
"""Read-only source and retained-review consistency checks; never invokes Lean."""
from pathlib import Path
import collections
import hashlib
import json
import os
import re
import subprocess

OUT = Path(__file__).resolve().parent
R = OUT / 'retrieved/review'
REPO = '/workspace/scratch/c0bb09a3002b/agent15-repo'
H = 'fa8cf9024c8aaa8c97a6426b004a7869c12ed887'
S = '54e1e58b320dfdbe8dc7d2a3ca9e141df9b8ffe2'
B = 'b8c17a5204ae56ad1fc99d8f9932ca9f57b6ac80'
P = 'proofs/contributions/agent-1/periodic-nine-center-20261017/'
REG = 'proofs/Agent1PeriodicNinesCenter.registry.json'
REG_SHA = 'd76263fe94ddaa93ea5ae364e39c8d3577faa6f6cc7c8b8422428b73b2c4a813'
ALLOWED = {'Classical.choice', 'Quot.sound', 'propext'}
env = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
commands = []
sha = lambda data: hashlib.sha256(data).hexdigest()
blob = lambda data: hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def readj(name):
    return json.loads((R / name).read_text())

def git(*args):
    argv = ['git', '-C', REPO, *args]
    result = subprocess.run(argv, env=env, capture_output=True, text=True)
    commands.append({'argv': argv, 'exit_code': result.returncode, 'stdout': result.stdout, 'stderr': result.stderr})
    assert result.returncode == 0, commands[-1]
    return result.stdout

def tree(commit, paths):
    result = {}
    for line in git('ls-tree', '-r', commit, *paths).splitlines():
        meta, path = line.split('\t'); mode, kind, oid = meta.split()
        result[path] = {'mode': mode, 'kind': kind, 'sha': oid}
    return result

def mask(source):
    result, i, depth = [], 0, 0
    while i < len(source):
        if depth:
            if source.startswith('/-', i): depth += 1; result.extend('  '); i += 2
            elif source.startswith('-/', i): depth -= 1; result.extend('  '); i += 2
            else: result.append('\n' if source[i] == '\n' else ' '); i += 1
        elif source.startswith('/-', i): depth = 1; result.extend('  '); i += 2
        elif source.startswith('--', i):
            end = source.find('\n', i); end = len(source) if end < 0 else end
            result.extend(' ' * (end-i)); i = end
        elif source[i] == '"':
            result.append(' '); i += 1
            while i < len(source):
                c = source[i]; result.append('\n' if c == '\n' else ' '); i += 1
                if c == '\\' and i < len(source): result.append(' '); i += 1
                elif c == '"': break
            else: raise AssertionError('Unterminated source string')
        else: result.append(source[i]); i += 1
    assert depth == 0
    return ''.join(result)

manifest = readj('FILES.json')
assert len(manifest) == 85
head = tree(H, [P + 'review', REG])
assert set(head) == {P + 'review/' + name for name in manifest} | {P + 'review/FILES.json', REG}
evidence_hashes = []
for name in [*manifest, 'FILES.json']:
    raw = (R / name).read_bytes(); meta = head[P + 'review/' + name]
    assert blob(raw) == meta['sha'] and meta['kind'] == 'blob'
    if name != 'FILES.json': assert {'bytes': len(raw), 'sha256': sha(raw)} == manifest[name], name
    evidence_hashes.append({'path': name, 'bytes': len(raw), 'git_blob': blob(raw), 'sha256': sha(raw)})
assert sha((R / 'FILES.json').read_bytes()) == '81067f45bf1f1cf0eb981d3a4629e4f42345b7935abcd970e394039d0c0982ee'
assert sha((R / 'semantic-review.md').read_bytes()) == '335c4c6c56879143a49721e6ef68d1462fba13079ab11583c9e9f01da2fbc116'
assert sha((R / 'frozen-receipt.json').read_bytes()) == '41f97d5be22b0e8f9efb957113bc9b8460b23e95931c8a8b42eb87acd470d6fb'
assert sha((R / 'clean-001/ReviewAudit.log').read_bytes()) == 'e9962b505538a1b14d081f1034b2dea19b1e13bd1a456b336298bbf46ecf750e'

registry_raw = (OUT / 'retrieved/registry.json').read_bytes()
assert sha(registry_raw) == REG_SHA and blob(registry_raw) == head[REG]['sha']
registry = json.loads(registry_raw); project = registry['projects']['agent1-periodic-nine-center']; modules = project['modules']
identity = readj('resumed-source-identity.json'); sources = identity['sources']
assert identity['source_commit'] == S and identity['registry_sha256'] == REG_SHA
assert len(sources) == len(modules) == 17 and project['roots'] == ['Agent1PeriodicNinesCenter']
assert readj('clean-001/sources.json') == sources
assert (R/'clean-001/final-source-identity.json').read_bytes() == (R/'resumed-source-identity.json').read_bytes()
paths = [REG] + [x['path'] for x in sources]
source_tree = tree(S, paths); head_sources = tree(H, paths); base_sources = tree(B, paths)
assert source_tree == head_sources and len(head_sources) == 18
assert [x for x in git('cat-file','-p',H).split('\n\n')[0].splitlines() if x.startswith('parent ')] == ['parent ' + S]
source_parents = [x[7:] for x in git('cat-file','-p',S).split('\n\n')[0].splitlines() if x.startswith('parent ')]
assert source_parents == ['c42dd0b6accedd27424a9511f8c06b651d21779e']
assert [x for x in git('cat-file','-p',source_parents[0]).split('\n\n')[0].splitlines() if x.startswith('parent ')] == ['parent ' + B]
delta = [x.split('\t') for x in git('diff','--name-status',S,H).splitlines()]
assert all(x[-1].startswith(P) for x in delta)
full_delta = [x.split('\t') for x in git('diff','--name-status',B,H).splitlines()]
assert all(x[0] == 'A' for x in full_delta)
imports = {}; public_declarations = []; scanned = []
for src in sources:
    mod = src['module']; path = src['path']; info = modules[mod]
    assert {k:src[k] for k in ['path','sha256','git_blob','imports']} == info
    raw = (R/'clean-001/compiled-sources'/(mod+'.lean')).read_bytes()
    assert sha(raw) == src['sha256'] and blob(raw) == src['git_blob'] == head_sources[path]['sha']
    if mod not in identity['new_modules']: assert base_sources[path] == head_sources[path]
    code = mask(raw.decode()); actual_imports = re.findall(r'^import\s+(\S+)', code, re.M)
    assert actual_imports == src['imports'], mod
    imports[mod] = actual_imports
    hits = re.findall(r'\b(?:sorry|admit|sorryAx|native_decide|axiom|implemented_by|extern|unsafe|ofReduceBool|trustCompiler)\b',code)
    assert not hits, (mod,hits)
    scanned.append(mod)
    if mod in identity['new_modules']:
        names = re.findall(r'^theorem\s+(\w+)',code,re.M)
        public_declarations += ['Agent1.Periodic.'+name for name in names]
        assert not re.findall(r'^(?:noncomputable\s+)?(?:def|abbrev|structure|inductive)\s+',code,re.M)
seen = set()
def visit(mod):
    if mod == 'Std' or mod in seen: return
    assert mod in modules; seen.add(mod)
    for dep in imports[mod]: visit(dep)
visit('Agent1PeriodicNinesCenter'); assert seen == set(modules)
assert public_declarations == identity['new_module_theorems'] == registry['claims'][0]['endpoints']

receipt = readj('frozen-receipt.json'); results = readj('clean-001/results.json')
verification = readj('clean-001/verification.json'); inventory = readj('clean-001/implementation-inventory.json')
prep = readj('resumed-preparation.json'); execution = readj('execution-receipt.json')
assert receipt['status'] == 'INDEPENDENT_REVIEW_PASS' and receipt['source_commit'] == S and receipt['registry_sha256'] == REG_SHA
assert receipt['authored_any_math'] is False and prep['authored_any_math'] is False
assert receipt['prior_preparer_authored_some_dependencies'] and prep['prior_preparer_authored_some_dependencies']
assert receipt['failed_or_interrupted_reviewer_lean_runs'] == [] and receipt['external_project_objects_reused'] is False
assert prep['fresh_build_existed_before_run'] is False and execution['exit_code'] == 0
for name,expected in prep['existing_files_sha256'].items(): assert sha((R/name).read_bytes()) == expected
for name,expected in receipt['review_evidence'].items(): assert sha((R/name).read_bytes()) == expected
assert (R/'clean-001/replay.py').read_bytes() == (R/'replay_resumed.py').read_bytes()
compiler = readj('clean-001/compiler.json'); limits = readj('clean-001/resource-limits.json')
assert compiler == verification['compiler']
assert compiler['sha256'] == '92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023'
assert compiler['version'] == 'Lean (version 4.19.0, x86_64-unknown-linux-gnu, commit 6caaee842e94, Release)'
assert limits['address_space_mib_per_child'] == 8192 and limits['timeout_seconds_per_command'] == 600
assert len(results) == 18 and [x['module'] for x in results] == [x['module'] for x in sources] + ['ReviewAudit']
warnings = []
for index,result in enumerate(results):
    mod = result['module']; argv = [compiler['path'],'--trust=0','-j1','-DElab.async=false']
    if mod != 'ReviewAudit': argv += ['-o',mod+'.olean']
    argv += [mod+'.lean']
    assert result['command'] == argv and result['exit_code'] == 0 and result['timed_out'] is False
    assert result['resource_limits'] == limits
    raw = (R/'clean-001'/(mod+'.log')).read_bytes(); assert sha(raw) == result['log_sha256']
    text = raw.decode(); assert not re.search(r'error:|sorryAx|Lean\.ofReduceBool|REVIEW_COMMAND_TIMEOUT', text)
    warnings += re.findall(r'^.*warning:.*$',text,re.M)
    for dep in imports.get(mod,[]):
        if dep != 'Std': assert [x['module'] for x in results].index(dep) < index

audit = (R/'clean-001/ReviewAudit.log').read_text(); audit_source = (R/'clean-001/ReviewAudit.lean').read_text()
theorems = re.findall(r'^AUDIT_THEOREM (\S+) (\S+) : \[([^\]]*)\]$',audit,re.M)
defs = re.findall(r'^AUDIT_SAFE_(?:DEFINITION|OPAQUE) (\S+) (\S+) : \[([^\]]*)\]$',audit,re.M)
assert len(theorems) == len(set((m,n) for m,n,_ in theorems)) == 1372
assert len(defs) == len(set((m,n) for m,n,_ in defs)) == 227
def union(rows):
    u=set()
    for mod,name,axes in rows:
        assert mod in modules
        values=set(x.strip() for x in axes.split(',') if x.strip());assert values <= ALLOWED
        u.update(values)
    return u
assert union(theorems) == ALLOWED == set(verification['axiom_union'])
assert union(defs) == {'propext'} == set(verification['safe_definition_axiom_union'])
assert set(m for m,_,_ in theorems) == set(modules)
assert verification['theorems_audited'] == len(theorems) and verification['safe_definitions_audited'] == len(defs)
assert 'FULL_MODULE_AUDIT theorems=1372' in audit and 'FULL_DEFINITION_AUDIT definitions=227' in audit
nonsafe = re.findall(r'^NONSAFE_DEFINITION (\S+) (\S+)$',audit,re.M)
implementation_axioms = re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$',audit,re.M)
unsafe_opaques = re.findall(r'^UNSAFE_OPAQUE (\S+) (\S+)$',audit,re.M)
assert len(nonsafe) == 944 == inventory['nonsafe_count'] and len(implementation_axioms) == 13
assert [list(x) for x in nonsafe] == verification['nonsafe_definitions_inventoried']
assert [list(x) for x in implementation_axioms] == inventory['unsafe_axioms'] == verification['unsafe_implementation_axioms_inventoried']
assert unsafe_opaques == inventory['unsafe_opaques'] == [] and inventory['unclassified_nonsafe'] == []
cstage = [x for x in nonsafe if re.search(r'\._cstage[12](?:\.|$)',x[1])]
unsafe_rec = [x for x in nonsafe if x[1].endswith('._unsafe_rec')]
assert len(cstage) == inventory['cstage_helpers'] == 916 and len(unsafe_rec) == inventory['unsafe_rec_helpers'] == 28
assert len(cstage)+len(unsafe_rec)==len(nonsafe)
safe_names = {(m,n) for m,n,_ in defs}
assert all((m,n[:-len('._unsafe_rec')]) in safe_names for m,n in unsafe_rec)
assert all(x['safe_base_audited'] for x in inventory['unsafe_rec_base_checks'])
new_counts = collections.Counter(m for m,_,_ in theorems if m in identity['new_modules'])
assert dict(new_counts) == {'Agent1PeriodicCenterWrap':6,'Agent1PeriodicNinesCenter':12}
assert not [x for x in defs+nonsafe if x[0] in identity['new_modules']]
assert not re.search(r'^CUSTOM_AXIOM|^DISALLOWED_|^MODULE_NOT_AUDITED',audit,re.M)
checks = re.findall(r'^#check (\S+)',audit_source,re.M)
assert len(checks) == 74 and checks == verification['audited_named_exports']
assert all(re.search(r'^'+re.escape(name)+r'(?: |\s*:)',audit,re.M) for name in checks)
assert re.findall(r'^#print axioms (\S+)',audit_source,re.M) == public_declarations
literal = {}
for name in public_declarations:
    match=re.search(r"^'"+re.escape(name)+r"' depends on axioms: \[([^\]]*)\]$",audit,re.M)
    assert match; values=[x.strip() for x in match[1].split(',')];assert set(values)<=ALLOWED;literal[name]=values

review=json.loads((OUT/'formal-review.json').read_text())
assert review['id']==5555589858 and review['commit_id']==H and review['state']=='COMMENTED'
assert S in review['body'] and REG_SHA in review['body'] and 'center_review_resume' in review['body']
parent_context=json.loads((OUT/'parent-context.json').read_text());context_tree=json.loads((OUT/'head-tree.json').read_text())
for path,item in parent_context.items():assert blob(item['content'].encode())==item['sha']==context_tree[path]['sha']
parent_result=json.loads(parent_context[P+'parent-verification/parent-result-addendum.json']['content'])
assert parent_result['explicit_trust_zero'] is False and parent_result['safe_definition_audit_claimed_here'] is False
assert 'historical pending wording is retained' in parent_context[P+'README.md']['content']

output={'status':'PASS_EXISTING_INDEPENDENT_REVIEW_REUSABLE','source_head':H,'reviewed_mathematical_source':S,'branch_dependency_base':B,
 'registry_sha256':REG_SHA,'manifest_entries_verified':85,'manifest_file_verified_separately':True,
 'complete_source_closure_unchanged':True,'closure_modules':17,'import_closure_exact':True,'source_scan_modules':scanned,
 'review_identity':{k:review[k] for k in ['id','state','commit_id','url','submitted_at','posted_account']},
 'retained_lean_commands':results,'theorem_audit_records':len(theorems),'safe_definition_audit_records':len(defs),
 'theorem_axiom_union':sorted(union(theorems)),'safe_definition_axiom_union':sorted(union(defs)),
 'new_module_theorem_counts':dict(new_counts),'public_axiom_outputs':literal,'public_types_confirmed':74,
 'runtime_inventory':{'nonsafe':944,'cstage':916,'unsafe_rec':28,'implementation_axioms':13,'unsafe_opaques':0,'unclassified':0},
 'retained_warnings':warnings,'evidence_hashes':evidence_hashes,'source_identity':sources,
 'source_to_head_delta':delta,'branch_base_to_head_delta':full_delta,'commands':commands,
 'new_lean_runs':'NOT_RUN','new_mathematical_review':'NOT_REQUIRED_OR_CLAIMED','parent_run_explicit_trust_zero':False,
 'integration_coverage':'Only pinned PR173 source at its PR172 branch base; no main integration certification or delivery ownership accepted'}
(OUT/'check-result.json').write_text(json.dumps(output,indent=2)+'\n')
print(json.dumps({k:output[k] for k in ['status','source_head','manifest_entries_verified','closure_modules','theorem_audit_records','safe_definition_audit_records','new_module_theorem_counts','runtime_inventory','retained_warnings','new_lean_runs']},indent=2))
