#!/usr/bin/env python3
"""Validate the actual local merge-tree results without running Lean or moving refs."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
GIT_DIR = Path('/workspace/scratch/c0bb09a3002b/agent15-integration.git')
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0', GIT_TERMINAL_PROMPT='0')
IDS = {
    'B': '74a1c3922eb7af438fe40b23d2105ad07556e3f5',
    'C': 'ebcaf723d61f9513c8bae30440d02ba4a46343b4',
    'R': '946c69edf3d2e6a87f5516db1fd0091eae29e663',
    'F': '84a65f296625e16851b4a369e27ffca43aaea40c',
    'S': '24cbcc99754cadb2d9ce4ba448e3a91171b9f4f0',
    'H': '502d3f5ea2e516f7cf4342854e1ec865f188d4f3',
    'TF': '322953ea665a99e35446c63741a74aa6e7bdaae9',
    'TH': '9277ee7615c0127c90247cb2c533f649fda9d6f1',
}
OUT = ROOT / 'integration-validation'
OUT.mkdir(exist_ok=True)
COMMANDS = []
CHECKS = []


def write_json(name, obj):
    (OUT / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')


def run(args, name):
    argv = ['git', '--git-dir=' + str(GIT_DIR), *args]
    proc = subprocess.run(argv, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    stdout_path = OUT / (name + '.stdout')
    stderr_path = OUT / (name + '.stderr')
    stdout_path.write_bytes(proc.stdout)
    stderr_path.write_bytes(proc.stderr)
    COMMANDS.append({
        'argv': argv, 'exit_code': proc.returncode,
        'stdout_path': stdout_path.relative_to(ROOT).as_posix(),
        'stdout_bytes': len(proc.stdout), 'stdout_sha256': hashlib.sha256(proc.stdout).hexdigest(),
        'stderr_path': stderr_path.relative_to(ROOT).as_posix(),
        'stderr_bytes': len(proc.stderr), 'stderr_sha256': hashlib.sha256(proc.stderr).hexdigest(),
    })
    write_json('commands.json', COMMANDS)
    if proc.returncode:
        raise RuntimeError(f'{name} exited {proc.returncode}: {proc.stderr.decode(errors="replace")}')
    return proc.stdout


def check(label, condition, details=None):
    CHECKS.append({'check': label, 'pass': bool(condition), 'details': details})
    write_json('checks.json', CHECKS)
    if not condition:
        raise AssertionError(label)


def inventory(label):
    data = run(['ls-tree', '-r', '-z', '--full-tree', IDS[label]], label + '-tree')
    entries = {}
    for line in data.split(b'\0'):
        if not line:
            continue
        header, path_bytes = line.split(b'\t', 1)
        mode, kind, sha = header.decode().split()
        path = path_bytes.decode('utf-8')
        if path in entries:
            raise AssertionError('Duplicate tree path: ' + path)
        entries[path] = {'mode': mode, 'type': kind, 'sha': sha}
    return entries


def delta(before, after):
    return [
        {'path': path, 'before': before.get(path), 'after': after.get(path),
         'status': 'A' if path not in before else 'D' if path not in after else 'M'}
        for path in sorted(set(before) | set(after)) if before.get(path) != after.get(path)
    ]


def main():
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    trees = {name: inventory(name) for name in IDS}
    commit_headers = {}
    for label in ('B', 'C', 'R', 'F', 'S', 'H'):
        data = run(['cat-file', 'commit', IDS[label]], label + '-commit')
        header = data.split(b'\n\n', 1)[0].decode()
        commit_headers[label] = {
            'tree': next(line[5:] for line in header.splitlines() if line.startswith('tree ')),
            'parents': [line[7:] for line in header.splitlines() if line.startswith('parent ')],
        }
    check('Foundation has exact ordered Clock and Core parents', commit_headers['F']['parents'] == [IDS['C'], IDS['R']])
    check('Mathematical source parent is the combined foundation', commit_headers['S']['parents'] == [IDS['F']])
    check('Published source parent is the mathematical source', commit_headers['H']['parents'] == [IDS['S']])
    check('Main tree is the previously recorded actual main tree', commit_headers['B']['tree'] == 'ba552a911841c2f2654cb4481c92e559e42d2a9b')
    initial = json.loads((ROOT / 'initial-combination-commands.json').read_text())
    for commit_label, tree_label in [('F', 'TF'), ('H', 'TH')]:
        hits = [row for row in initial if row['argv'][-4:] == ['merge-tree', '--write-tree', IDS['B'], IDS[commit_label]]]
        check(f'Actual recorded merge-tree B+{commit_label} produced {tree_label} without conflict', len(hits) == 1 and hits[0]['exit_code'] == 0 and hits[0]['stdout'].strip() == IDS[tree_label] and not hits[0]['stderr'])

    ch = delta(trees['C'], trees['H'])
    cf = delta(trees['C'], trees['F'])
    fh = delta(trees['F'], trees['H'])
    sh = delta(trees['S'], trees['H'])
    check('Current stacked PR has exactly 699 additions only', len(ch) == 699 and all(x['status'] == 'A' for x in ch))
    check('Foundation adds exactly 403 inherited Core paths over Clock', len(cf) == 403 and all(x['status'] == 'A' for x in cf))
    check('Every inherited Core addition has the exact Core identity', all(trees['R'].get(x['path']) == x['after'] for x in cf))
    check('Own change over the combined foundation is exactly 296 additions', len(fh) == 296 and all(x['status'] == 'A' for x in fh))
    check('All 699 additions are regular nonexecutable Git blobs', all(x['after']['mode'] == '100644' and x['after']['type'] == 'blob' for x in ch))
    check('Inherited and own additions exactly partition the full PR', {x['path'] for x in ch} == {x['path'] for x in cf} | {x['path'] for x in fh} and not ({x['path'] for x in cf} & {x['path'] for x in fh}))
    prefix = 'proofs/contributions/agent-1/periodic-return-upper-gap-20261017/'
    check('Published evidence amendment changes only this contribution evidence', len(sh) == 225 and all(x['path'].startswith(prefix) for x in sh))
    for name, data in [('clock-to-head.json', ch), ('clock-to-foundation.json', cf), ('foundation-to-head.json', fh), ('source-to-head.json', sh)]:
        write_json(name, data)

    candidate_counts = {}
    for source_label, target_label in [('F', 'TF'), ('H', 'TH')]:
        differences = delta(trees['B'], trees[target_label])
        source_only = {p: v for p, v in trees[source_label].items() if p not in trees['B']}
        check(f'{target_label} preserves every actual main entry including mode and type', all(trees[target_label].get(p) == v for p, v in trees['B'].items()), {'main_entries': len(trees['B'])})
        check(f'{target_label} contains exactly the source additions to main', len(differences) == len(source_only) and all(x['status'] == 'A' and source_only.get(x['path']) == x['after'] for x in differences))
        check(f'{target_label} preserves all source addition identities', all(trees[target_label].get(p) == v for p, v in source_only.items()))
        write_json('main-to-' + target_label + '.json', differences)
        candidate_counts[target_label] = {'total_entries': len(trees[target_label]), 'preserved_main_entries': len(trees['B']), 'additions': len(differences), 'modifications': 0, 'deletions': 0}
    combined_delta = delta(trees['TF'], trees['TH'])
    check('Upper addition over current-main foundation equals the exact 296-path source delta', combined_delta == fh)
    write_json('combined-foundation-to-upper.json', combined_delta)

    registry_path = 'proofs/Agent1PeriodicReturnUpper.registry.json'
    registry_blob = '0c6650738bed8f70c7cbf374c435e0bef902ba96'
    registry_bytes = (ROOT / 'review-reuse' / 'blobs' / registry_blob).read_bytes()
    registry_sha256 = hashlib.sha256(registry_bytes).hexdigest()
    actual_git = hashlib.sha1(b'blob ' + str(len(registry_bytes)).encode() + b'\0' + registry_bytes).hexdigest()
    check('Registry acquired byte sequence matches exact Git blob and SHA256', actual_git == registry_blob and registry_sha256 == '9045d97fc4f687d1e9c7eb38c6d4002afaeb488bae7cc8ab524ac2e6bd819d1c')
    registry = json.loads(registry_bytes)
    project = registry['projects']['agent1-periodic-return-upper-gap']
    modules = project['modules']
    check('The separate accepted scope has exactly 41 modules and the intended root', len(modules) == 41 and project['roots'] == ['Agent1PeriodicReturnUpper'])
    new_modules = {'Agent1PeriodicInitialIncoming', 'Agent1PeriodicReturnUpper'}
    source_bindings = []
    for name, spec in sorted(modules.items()):
        path = spec['path']
        expected = {'mode': '100644', 'type': 'blob', 'sha': spec['git_blob']}
        check('Unchanged mathematical input in S/H/TH: ' + name, all(trees[k].get(path) == expected for k in ('S', 'H', 'TH')))
        if name in new_modules:
            check('New module absent from F/TF: ' + name, all(path not in trees[k] for k in ('F', 'TF')))
        else:
            check('Inherited module unchanged in F/TF: ' + name, all(trees[k].get(path) == expected for k in ('F', 'TF')))
        source_bytes = (ROOT / 'review-reuse' / 'blobs' / spec['git_blob']).read_bytes()
        check('Exact source bytes match both pinned hashes: ' + name, hashlib.sha256(source_bytes).hexdigest() == spec['sha256'] and hashlib.sha1(b'blob ' + str(len(source_bytes)).encode() + b'\0' + source_bytes).hexdigest() == spec['git_blob'])
        source_bindings.append({'module': name, 'path': path, 'sha256': spec['sha256'], 'git_blob': spec['git_blob'], 'mode': '100644', 'bytes': len(source_bytes), 'new': name in new_modules, 'identical_in': ['S', 'H', 'TH'] + ([] if name in new_modules else ['F', 'TF'])})
    check('Registry unchanged across reviewed source, published head and combination', all(trees[k].get(registry_path) == {'mode': '100644', 'type': 'blob', 'sha': registry_blob} for k in ('S', 'H', 'TH')))
    root_new = [x['path'] for x in fh if not x['path'].startswith(prefix)]
    check('Own non-evidence additions are precisely two sources and their separate registry', set(root_new) == {'proofs/' + n + '.lean' for n in new_modules} | {registry_path})
    write_json('source-bindings.json', source_bindings)
    write_json('commit-identities.json', commit_headers)
    result = {
        'status': 'PASS_CURRENT_MAIN_COMBINATION', 'started_at': started,
        'completed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'identities': IDS, 'commit_headers': commit_headers,
        'checks_passed': len(CHECKS), 'check_failures': 0,
        'full_pr': {'additions': 699, 'modifications': 0, 'deletions': 0, 'inherited_core_additions': 403, 'own_additions': 296},
        'candidate_counts': candidate_counts,
        'mathematical_binding': {'unchanged_modules': 41, 'inherited_modules': 39, 'new_modules': 2, 'registry_blob': registry_blob, 'registry_sha256': registry_sha256},
        'logical_evidence_reuse': 'All mathematical source bytes and separate registry remain identical. Reuse the qualified original strict fresh41 execution and independent review; no fresh Lean run was executed.',
        'scope_limit': 'TF and TH are actual local hypothetical merge-tree objects against recorded main B. They are not actual main commits, do not establish integration of PR150/PR154, do not retarget PR167, and do not authorize taking the active main-writer role. Rebind the actual target after prerequisite integration.',
        'publication_obligation': 'The future integrator must maintain required publication inventories and summaries under PUBLICATION_POLICY.md. Existing main files were all preserved by these proof-package combinations.',
        'remote_mutations': False, 'new_lean_run': False, 'actual_merge': False,
    }
    write_json('result.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    try:
        main()
    except BaseException as exc:
        write_json('failure.json', {'type': type(exc).__name__, 'error': str(exc), 'checks_completed': len(CHECKS), 'commands_completed': len(COMMANDS)})
        raise
