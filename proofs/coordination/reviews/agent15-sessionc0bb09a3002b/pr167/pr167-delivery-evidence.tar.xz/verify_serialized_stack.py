#!/usr/bin/env python3
"""Compose actual Git trees for the full prerequisite sequence; never move a ref."""
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
OUT = ROOT / 'serialized-stack'
OUT.mkdir(exist_ok=True)
GIT = ['git', '--git-dir=/workspace/scratch/c0bb09a3002b/agent15-integration.git']
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0', GIT_TERMINAL_PROMPT='0',
           GIT_AUTHOR_NAME='Agent15 local hypothetical integration',
           GIT_AUTHOR_EMAIL='agent15-local-validation@example.invalid',
           GIT_COMMITTER_NAME='Agent15 local hypothetical integration',
           GIT_COMMITTER_EMAIL='agent15-local-validation@example.invalid',
           GIT_AUTHOR_DATE='2026-10-17T06:00:00Z', GIT_COMMITTER_DATE='2026-10-17T06:00:00Z')
B = '74a1c3922eb7af438fe40b23d2105ad07556e3f5'
STAGES = [
    (146, '159ed83569f5cc4d058557c2b24b28839552b75a', 293),
    (147, 'e77289c5f58a3238f53c0f3c6951a73515c5d7d2', 327),
    (150, '946c69edf3d2e6a87f5516db1fd0091eae29e663', 403),
    (154, 'ebcaf723d61f9513c8bae30440d02ba4a46343b4', 193),
    (167, '502d3f5ea2e516f7cf4342854e1ec865f188d4f3', 296),
]
COMMANDS = []
CHECKS = []


def save(name, data):
    (OUT / name).write_text(json.dumps(data, indent=2) + '\n')


def run(args, label, stdin=None):
    proc = subprocess.run(GIT + args, env=ENV, input=stdin, capture_output=True)
    (OUT / (label + '.stdout')).write_bytes(proc.stdout)
    (OUT / (label + '.stderr')).write_bytes(proc.stderr)
    COMMANDS.append({'argv': GIT + args, 'stdin_utf8': None if stdin is None else stdin.decode(),
                     'exit_code': proc.returncode, 'stdout_path': label + '.stdout',
                     'stdout_sha256': hashlib.sha256(proc.stdout).hexdigest(),
                     'stdout_bytes': len(proc.stdout), 'stderr_path': label + '.stderr',
                     'stderr_sha256': hashlib.sha256(proc.stderr).hexdigest(), 'stderr_bytes': len(proc.stderr)})
    save('commands.json', COMMANDS)
    if proc.returncode:
        raise RuntimeError(f'{label}: exit {proc.returncode}: ' + proc.stderr.decode(errors='replace'))
    return proc.stdout


def check(label, condition, details=None):
    CHECKS.append({'check': label, 'pass': bool(condition), 'details': details})
    save('checks.json', CHECKS)
    if not condition:
        raise AssertionError(label)


def tree(rev, label):
    data = run(['ls-tree', '-r', '-z', '--full-tree', rev], label)
    rows = {}
    for line in data.split(b'\0'):
        if line:
            h, p = line.split(b'\t', 1)
            mode, kind, sha = h.decode().split()
            rows[p.decode()] = {'mode': mode, 'type': kind, 'sha': sha}
    return rows


def delta(a, b):
    return [{'path': p, 'before': a.get(p), 'after': b.get(p),
             'status': 'A' if p not in a else 'D' if p not in b else 'M'}
            for p in sorted(set(a) | set(b)) if a.get(p) != b.get(p)]


def main():
    started = datetime.datetime.now(datetime.timezone.utc).isoformat()
    current_commit = B
    original = tree(B, 'main-tree')
    current_tree = original
    results = []
    stage_trees = {}
    for pr, head, expected_additions in STAGES:
        tree_sha = run(['merge-tree', '--write-tree', current_commit, head], f'pr{pr}-merge-tree').decode().strip()
        check(f'PR{pr} merge-tree returned a single clean tree SHA', len(tree_sha) == 40 and all(c in '0123456789abcdef' for c in tree_sha))
        combined = tree(tree_sha, f'pr{pr}-combined-tree')
        changes = delta(current_tree, combined)
        check(f'PR{pr} preserves every previous-stage entry', all(combined.get(p) == v for p, v in current_tree.items()), {'entries': len(current_tree)})
        check(f'PR{pr} has exactly its expected additive increment', len(changes) == expected_additions and all(x['status'] == 'A' for x in changes), {'actual': len(changes), 'expected': expected_additions})
        source = tree(head, f'pr{pr}-source-tree')
        check(f'PR{pr} adds exact regular source blobs only', all(x['after'] == source.get(x['path']) and x['after']['mode'] == '100644' and x['after']['type'] == 'blob' for x in changes))
        check(f'PR{pr} preserves every original main entry', all(combined.get(p) == v for p, v in original.items()))
        message = (f'LOCAL HYPOTHETICAL ONLY: PR{pr} after ordered prerequisite validation\n\n'
                   'Generated solely for read-only delivery-tree analysis; no remote or local ref is moved.\n').encode()
        candidate = run(['commit-tree', tree_sha, '-p', current_commit, '-p', head], f'pr{pr}-local-candidate', message).decode().strip()
        raw = run(['cat-file', 'commit', candidate], f'pr{pr}-candidate-object').decode()
        headers = raw.split('\n\n', 1)[0].splitlines()
        parents = [line[7:] for line in headers if line.startswith('parent ')]
        check(f'PR{pr} local candidate has the exact tree and ordered parents', parents == [current_commit, head] and 'tree ' + tree_sha in headers)
        save(f'pr{pr}-delta.json', changes)
        results.append({'pr': pr, 'head': head, 'previous_local_candidate_or_actual_main': current_commit,
                        'tree': tree_sha, 'local_hypothetical_candidate': candidate, 'ordered_parents': parents,
                        'previous_entries_preserved': len(current_tree), 'added_entries': len(changes),
                        'total_entries': len(combined), 'modifications': 0, 'deletions': 0})
        stage_trees[pr] = combined
        current_commit, current_tree = candidate, combined

    check('The final complete stack adds exactly 1512 entries to main', len(current_tree) == len(original) + 1512)
    own_delta = json.loads((ROOT / 'integration-validation' / 'foundation-to-head.json').read_text())
    check('Final PR167 increment is exactly its frozen 296-path own delta', delta(stage_trees[154], stage_trees[167]) == own_delta)
    bindings = json.loads((ROOT / 'integration-validation' / 'source-bindings.json').read_text())
    for row in bindings:
        expected = {'mode': row['mode'], 'type': 'blob', 'sha': row['git_blob']}
        check('Final stack retains reviewed mathematical source ' + row['module'], current_tree.get(row['path']) == expected)
        if not row['new']:
            check('Foundation stack retains inherited reviewed input ' + row['module'], stage_trees[154].get(row['path']) == expected)
    registry = 'proofs/Agent1PeriodicReturnUpper.registry.json'
    check('Final stack retains the frozen Upper registry', current_tree.get(registry) == {'mode': '100644', 'type': 'blob', 'sha': '0c6650738bed8f70c7cbf374c435e0bef902ba96'})
    bare_source_combination = tree('9277ee7615c0127c90247cb2c533f649fda9d6f1', 'historical-source-only-combination')
    later_evidence = delta(bare_source_combination, current_tree)
    check('Later prerequisite evidence does not change selected mathematical inputs', not ({x['path'] for x in later_evidence} & ({x['path'] for x in bindings} | {registry})))
    check('Full stack never deletes an entry from source-only combination', all(x['status'] != 'D' for x in later_evidence))
    save('later-prerequisite-evidence.json', later_evidence)
    save('main-to-final-stack.json', delta(original, current_tree))
    result = {
        'status': 'PASS_ORDERED_PREREQUISITE_COMBINATION', 'started_at': started,
        'completed_at': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'actual_main': B, 'stage_order': [pr for pr, _, _ in STAGES], 'stages': results,
        'final_tree': results[-1]['tree'], 'main_entries_preserved': len(original),
        'total_additions_to_main': 1512, 'total_entries': len(current_tree),
        'own_pr167_increment': 296, 'source_modules_unchanged': 41,
        'additional_prerequisite_evidence_vs_source_only': {
            'paths': len(later_evidence), 'additions': sum(x['status'] == 'A' for x in later_evidence),
            'modifications': sum(x['status'] == 'M' for x in later_evidence), 'deletions': 0,
        },
        'checks_passed': len(CHECKS), 'check_failures': 0,
        'local_candidate_identity': 'All commit-tree objects are deterministic local hypothetical candidates, with clearly labelled synthetic local author metadata. None was pushed or referenced by a branch. Actual future merge commit identities will differ.',
        'scope': 'These stages preserve final published prerequisite evidence and prove the stated conditional tree composition against recorded B. They do not certify prerequisite delivery gates, merge any PR, retarget a PR, update cumulative publication indexes, or acquire the main-writer role.',
        'next_required_action': 'Existing owners complete actual146/147/150/154 integration under acknowledged main ownership. Rebind the actual target, confirm source and evidence preservation, meet live platform/publication obligations, then perform an ordinary exact-head guarded PR167 merge and actual remote target/parent/tree/postcheck readback.',
        'fresh_lean_run': False, 'source_edit': False, 'remote_mutation': False, 'ref_update': False, 'actual_merge': False,
    }
    save('result.json', result)
    print(json.dumps(result, indent=2))


if __name__ == '__main__':
    try:
        main()
    except BaseException as exc:
        save('failure.json', {'type': type(exc).__name__, 'error': str(exc), 'commands_completed': len(COMMANDS), 'checks_completed': len(CHECKS)})
        raise
