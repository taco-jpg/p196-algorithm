#!/usr/bin/env python3
"""Acquire exact locally available blobs without fetching or writing Git state."""
import hashlib,json,os,subprocess
from pathlib import Path
OUT=Path(__file__).resolve().parent
H='502d3f5ea2e516f7cf4342854e1ec865f188d4f3'
REPO='/workspace/scratch/c0bb09a3002b/agent15-repo'
P='proofs/contributions/agent-1/periodic-return-upper-gap-20261017/'
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
logs=[]
blobs=OUT/'blobs';blobs.mkdir(exist_ok=True)
def oid(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def put(o,b):
    assert oid(b)==o,(o,oid(b))
    f=blobs/o
    if f.exists():assert f.read_bytes()==b
    else:f.write_bytes(b)
def git(*args):
    r=subprocess.run(['git','-C',REPO,*args],env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    logs.append({'args':list(args),'exit_code':r.returncode,'stdout_sha256':hashlib.sha256(r.stdout).hexdigest(),'stdout_bytes':len(r.stdout),'stderr':r.stderr.decode()})
    return r
initial=json.loads((OUT/'connector-records-001.json').read_text())
empty=[]
for item in initial['files']:
    s=item['result']['value']['structuredContent'];b=s['content'].encode()
    if not b and s['sha']!=oid(b):empty.append({'path':item['path'],'reported_blob':s['sha'],'outcome':'EMPTY_CONTENT_NOT_ACCEPTED'})
    else:put(s['sha'],b)
for item in json.loads((OUT/'connector-large-blobs.json').read_text()):put(item['oid'],item['content'].encode())
def initial_data(path):
    return next(x['result']['value']['structuredContent']['content'] for x in initial['files'] if x['path']==path)
paths={x['path'] for x in initial['files']}
for manifest in ['review/FILES.json','verification/parent-clean-001/PACKAGE-FILES.json']:
    base=P+manifest.rsplit('/',1)[0]+'/'
    paths.update(base+x for x in json.loads(initial_data(P+manifest)))
identity=json.loads(initial_data(P+'review/final-source-identity.json'))
paths.update(x['path'] for x in identity['sources'])
paths.update(['proofs/Agent1PeriodicReturnCore.registry.json','proofs/Agent1PeriodicReturnClock.registry.json','proofs/verify_project__214bf7673efe116b.py'])
# Preserve and inspect the explicitly discussed author attempts and core/clock reports.
package_paths=initial['git_initial'][1]['value']['output'].splitlines()
paths.update(x for x in package_paths if '/upper-author/' in x and not x.endswith(('.gz','.xz','.zip')))
for sub in ['periodic-return-core-20261016','periodic-return-clock-20261016']:
    pref='proofs/contributions/agent-1/'+sub+'/'
    for f in ['README.md','review/semantic-review.md']:paths.add(pref+f)
r=git('ls-tree','-r','-z',H,'--',*sorted(paths));assert r.returncode==0
tree={}
for record in r.stdout.split(b'\0'):
    if not record:continue
    meta,p=record.decode().split('\t',1);mode,kind,o=meta.split();tree[p]={'mode':mode,'kind':kind,'oid':o}
missing_paths=sorted(paths-set(tree))
needed={v['oid']:[] for v in tree.values()}
for p,v in tree.items():needed[v['oid']].append(p)
missing=[]
for o,ps in needed.items():
    if (blobs/o).exists():continue
    r=git('show',H+':'+ps[0])
    if r.returncode==0:put(o,r.stdout)
    else:missing.append({'oid':o,'paths':ps})
(OUT/'head-paths.json').write_text(json.dumps(tree,indent=2)+'\n')
(OUT/'acquisition-commands-001.json').write_text(json.dumps(logs,indent=2)+'\n')
(OUT/'acquisition-missing.json').write_text(json.dumps({'missing':missing,'missing_paths':missing_paths,'empty_connector_content':empty},indent=2)+'\n')
print(json.dumps({'selected_paths':len(tree),'unique_blobs':len(needed),'missing_unique_blobs':len(missing),'missing_paths':missing_paths,'empty_connector_content':empty},indent=2))
