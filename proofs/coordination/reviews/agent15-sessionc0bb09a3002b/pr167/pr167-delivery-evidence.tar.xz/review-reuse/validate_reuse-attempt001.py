#!/usr/bin/env python3
"""Lightweight evidence binding and audit-log validation; never invokes Lean."""
import base64,collections,hashlib,json,os,re,subprocess,traceback
from pathlib import Path
O=Path(__file__).resolve().parent
H='502d3f5ea2e516f7cf4342854e1ec865f188d4f3'
S='24cbcc99754cadb2d9ce4ba448e3a91171b9f4f0'
F='84a65f296625e16851b4a369e27ffca43aaea40c'
CORE='946c69edf3d2e6a87f5516db1fd0091eae29e663'
CLOCK='ebcaf723d61f9513c8bae30440d02ba4a46343b4'
P='proofs/contributions/agent-1/periodic-return-upper-gap-20261017/'
R=P+'review/';C=R+'clean-001/';Q=P+'verification/parent-clean-001/'
REPO='/workspace/scratch/c0bb09a3002b/agent15-repo'
T=json.loads((O/'head-paths.json').read_text())
env=dict(os.environ,GIT_NO_LAZY_FETCH='1',GIT_OPTIONAL_LOCKS='0')
run=f'{1+len(list(O.glob("validation-results-*.json"))):03}'
commands=[];report={'status':'RUNNING','H':H,'mathematical_source':S,'combined_foundation':F,'checks':{},'new_lean_execution':'NOT_RUN'}
def sha(b):return hashlib.sha256(b).hexdigest()
def oid(b):return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
def data(p):return (O/'blobs'/T[p]['oid']).read_bytes()
def text(p):return data(p).decode()
def j(p):return json.loads(data(p))
def git(*args):
    cmd=['git','-C',REPO,*args];r=subprocess.run(cmd,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
    commands.append({'argv':cmd,'exit_code':r.returncode,'stdout':r.stdout.decode(errors='replace'),'stderr':r.stderr.decode(errors='replace')})
    assert r.returncode==0,('GIT_READ_FAILED',args,r.stderr.decode())
    return r.stdout
def tree(ref,paths):
    out={}
    for rec in git('ls-tree','-r','-z',ref,'--',*paths).split(b'\0'):
        if rec:
            meta,path=rec.decode().split('\t',1);mode,kind,o=meta.split();out[path]={'mode':mode,'kind':kind,'oid':o}
    return out
def mask(src):
    out=[];i=0;depth=0
    while i<len(src):
        if src.startswith('/-',i):depth+=1;out.extend('  ');i+=2
        elif depth and src.startswith('-/',i):depth-=1;out.extend('  ');i+=2
        elif depth:out.append('\n' if src[i]=='\n' else ' ');i+=1
        elif src.startswith('--',i):
            e=src.find('\n',i);e=len(src) if e<0 else e;out.extend(' '*(e-i));i=e
        elif src[i]=='"':
            out.append(' ');i+=1
            while i<len(src):
                c=src[i];out.append('\n' if c=='\n' else ' ');i+=1
                if c=='\\' and i<len(src):out.append(' ');i+=1
                elif c=='"':break
        else:out.append(src[i]);i+=1
    assert depth==0
    return ''.join(out)
def axes(s):return sorted(x.strip() for x in s.split(',') if x.strip())
try:
    for p,v in T.items():assert oid(data(p))==v['oid'] and v['mode']=='100644' and v['kind']=='blob',p
    report['checks']['acquired_bytes']={'paths':len(T),'unique_blobs':len({x['oid'] for x in T.values()}),'all_canonical_git_blob_hashes_match':True}
    manifests={}
    for path,count in [(R+'FILES.json',144),(Q+'FILES.json',85),(Q+'PACKAGE-FILES.json',88)]:
        m=j(path);prefix=path.rsplit('/',1)[0]+'/'
        assert len(m)==count
        for relative,record in m.items():
            b=data(prefix+relative)
            assert len(b)==record['bytes'] and sha(b)==record['sha256'],(path,relative)
        manifests[path]={'entries':len(m),'stored_bytes':sum(r['bytes'] for r in m.values()),'sha256':sha(data(path)),'all_actual_bytes_verified':True}
    actual_review=tree(H,[R.rstrip('/')]);actual_parent=tree(H,[Q.rstrip('/')])
    assert set(actual_review)=={R+p for p in j(R+'FILES.json')}|{R+'FILES.json'}
    assert set(actual_parent)=={Q+p for p in j(Q+'PACKAGE-FILES.json')}|{Q+'PACKAGE-FILES.json'}
    assert set(j(Q+'PACKAGE-FILES.json'))-set(j(Q+'FILES.json'))=={'FILES.json','canonical-checker.py','source-identity-receipt.json'}
    assert all(j(Q+'PACKAGE-FILES.json')[p]==r for p,r in j(Q+'FILES.json').items())
    assert not any(p.endswith(('.olean','.ilean','.o','.so','.a')) for p in [*actual_review,*actual_parent])
    report['checks']['manifests']={'records':manifests,'actual_review_paths':len(actual_review),'actual_parent_paths':len(actual_parent),'no_unmanifested_text_files':True,'runtime_objects_excluded':True}
    regs={name:j('proofs/'+name+'.registry.json') for name in ['Agent1PeriodicReturnUpper','Agent1PeriodicReturnCore','Agent1PeriodicReturnClock']}
    projects={n:next(iter(x['projects'].values())) for n,x in regs.items()}
    mods=projects['Agent1PeriodicReturnUpper']['modules'];core=projects['Agent1PeriodicReturnCore']['modules'];clock=projects['Agent1PeriodicReturnClock']['modules']
    assert len(mods)==41 and len(core)==38 and len(clock)==21
    assert all(core[n]==clock[n] for n in set(core)&set(clock))
    union=core|clock;assert len(union)==39
    assert set(mods)-set(union)=={'Agent1PeriodicInitialIncoming','Agent1PeriodicReturnUpper'}
    assert all(mods[n]==r for n,r in union.items())
    identity=j(R+'final-source-identity.json');source_order=identity['sources']
    assert identity['source_commit']==S and len(source_order)==41
    assert {r['module']:{k:v for k,v in r.items() if k!='module'} for r in source_order}==mods
    assert sha(data('proofs/Agent1PeriodicReturnUpper.registry.json'))==identity['registry_sha256']=='9045d97fc4f687d1e9c7eb38c6d4002afaeb488bae7cc8ab524ac2e6bd819d1c'
    assert regs['Agent1PeriodicReturnUpper']['source_baseline']==F
    for pin in regs['Agent1PeriodicReturnUpper']['source_pin_origins']:assert sha(data(pin['path']))==pin['sha256']
    sourcepaths=[r['path'] for r in source_order]+['proofs/Agent1PeriodicReturnUpper.registry.json']
    st=tree(S,sourcepaths);ht=tree(H,sourcepaths);assert st==ht and set(ht)==set(sourcepaths)
    ft=tree(F,[r['path'] for r in union.values()]+['proofs/Agent1PeriodicReturnCore.registry.json','proofs/Agent1PeriodicReturnClock.registry.json'])
    for p,v in ft.items():assert v==T[p],p
    for ref,modulemap,regname in [(CORE,core,'Agent1PeriodicReturnCore'),(CLOCK,clock,'Agent1PeriodicReturnClock')]:
        e=tree(ref,[r['path'] for r in modulemap.values()]+['proofs/'+regname+'.registry.json'])
        assert len(e)==len(modulemap)+1 and all(v==T[p] for p,v in e.items())
    imports={};exports=[];seen=set();source_checks=[]
    for r in source_order:
        n=r['module'];b=data(r['path']);code=mask(b.decode())
        assert sha(b)==r['sha256'] and oid(b)==r['git_blob'],n
        assert b==data(C+'compiled-sources/'+n+'.lean')==data(Q+'agent1-periodic-return-upper-gap/source/'+n+'.lean'),n
        literal=[token for line in re.findall(r'^\s*import\s+([^\n]+)',code,re.M) for token in line.split()]
        assert literal==r['imports'],(n,literal,r['imports'])
        imports[n]=literal
        assert all(x in seen or x in ['Std','Lean','Init'] for x in literal),(n,literal)
        seen.add(n)
        hits=re.findall(r'\b(?:sorry|admit|sorryAx|native_decide|axiom|implemented_by|extern|unsafe|ofReduceBool|trustCompiler)\b',code)
        assert not hits,(n,hits)
        source_checks.append({'module':n,'path':r['path'],'sha256':sha(b),'git_blob':oid(b),'imports':literal,'H_equals_source_commit':True,'specialist_and_parent_compiled_snapshots_equal':True})
        if n.startswith('Agent1'):
            namespace='Agent1.Periodic' if n.startswith('Agent1Periodic') else 'Agent1.RepeatedBlock'
            exports.extend((n,namespace+'.'+name) for name in re.findall(r'^theorem\s+(\w+)',code,re.M))
    visited=set()
    def visit(n):
        if n in ['Std','Lean','Init'] or n in visited:return
        assert n in imports;visited.add(n)
        for x in imports[n]:visit(x)
    for root in projects['Agent1PeriodicReturnUpper']['roots']:visit(root)
    assert visited==set(mods)
    delta=git('diff','--name-only','--no-renames',S,H).decode().splitlines()
    assert all(p.startswith(P) for p in delta)
    report['checks']['source_closure']={'module_count':41,'core':38,'clock':21,'intersection':20,'union':39,'new_modules':identity['new_modules'],'all_42_source_and_registry_objects_unchanged_from_S_to_H':True,'39_prior_source_bytes_and_registries_match_foundation_and_pr150_pr154':True,'literal_import_dfs_complete':True,'topological_order_valid':True,'forbidden_source_tokens':[],'source_to_head_changed_paths':delta,'sources':source_checks}
    results=j(C+'results.json');assert len(results)==42
    compiler=j(C+'compiler.json');limits=j(C+'resource-limits.json')
    assert compiler['sha256']=='92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023'
    assert compiler['version']=='Lean (version 4.19.0, x86_64-unknown-linux-gnu, commit 6caaee842e94, Release)'
    assert limits=={'address_space_mib_per_child':8192,'timeout_seconds_per_command':600,'lean_stack_kib':'compiler default'}
    assert [r['module'] for r in results]==[r['module'] for r in source_order]+['ReviewAudit']
    for r in results:
        n=r['module'];expected=[compiler['path'],'--trust=0','-j1','-DElab.async=false']+([] if n=='ReviewAudit' else ['-o',n+'.olean'])+[n+'.lean']
        assert r['command']==expected and r['exit_code']==0 and not r['timed_out'] and r['resource_limits']==limits,n
        assert sha(data(C+n+'.log'))==r['log_sha256'],n
    receipt=j(R+'final-review-receipt.json')
    assert data(R+'replay.py')==data(C+'replay.py')
    assert sha(data(R+'replay.py'))==receipt['executed_driver_sha256']=='3abb9f3ca2b8c7053eea6edc4be1f1a92f7b02d59a3eb85a0a0e5cc9d942665a'
    assert sha(data(C+'verification.json'))==receipt['verification_sha256']
    assert sha(data(R+'semantic-review.md'))==receipt['semantic_review_sha256']
    report['checks']['retained_execution']={'commands':42,'source_compilations':41,'audit_commands':1,'exit_zero':42,'timed_out':0,'explicit_trust_zero':42,'compiler':compiler,'limits':limits,'total_recorded_seconds':sum(r['seconds'] for r in results),'driver_sha256':receipt['executed_driver_sha256'],'all_command_log_hashes_verified':True,'fresh_build_mechanism':'Driver creates nonexistent build/evidence directories, copies hash-pinned source, and sets LEAN_PATH only to the fresh build; inspected, not rerun.'}
    log=text(C+'ReviewAudit.log');allowed={'Classical.choice','Quot.sound','propext'}
    theorem=re.findall(r'^AUDIT_THEOREM (\S+) (\S+) : \[([^\]]*)\]$',log,re.M)
    safe=re.findall(r'^AUDIT_SAFE_(?:DEFINITION|OPAQUE) (\S+) (\S+) : \[([^\]]*)\]$',log,re.M)
    assert len(theorem)==len({(m,n) for m,n,_ in theorem})==1980
    assert len(safe)==len({(m,n) for m,n,_ in safe})==566
    assert {m for m,n,a in theorem}==set(mods)
    assert all(set(axes(a))<=allowed for m,n,a in theorem+safe)
    axunion={x for m,n,a in theorem for x in axes(a)};sunion={x for m,n,a in safe for x in axes(a)}
    assert axunion==allowed and sunion=={'Quot.sound','propext'}
    assert not re.search(r'CUSTOM_AXIOM|DISALLOWED_(?:AXIOMS|DEFINITION_AXIOMS|OPAQUE_AXIOMS)|MODULE_NOT_AUDITED|sorryAx|Lean\.ofReduceBool|error:|REVIEW_COMMAND_TIMEOUT',log)
    nonsafe=re.findall(r'^NONSAFE_DEFINITION (\S+) (\S+)$',log,re.M)
    unsafeax=re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$',log,re.M)
    opaque=re.findall(r'^UNSAFE_OPAQUE (\S+) (\S+)$',log,re.M)
    assert len(nonsafe)==len(set(nonsafe))==12146 and len(unsafeax)==len(set(unsafeax))==32 and not opaque
    cstage=[(m,n) for m,n in nonsafe if re.search(r'\._cstage[12](?:\.|$)',n)]
    recursion=[(m,n) for m,n in nonsafe if n.endswith('._unsafe_rec')]
    assert len(cstage)==12111 and len(recursion)==35 and set(nonsafe)==set(cstage)|set(recursion)
    safenames={(m,n) for m,n,a in safe}
    assert all((m,n[:-len('._unsafe_rec')]) in safenames for m,n in recursion)
    verify=j(C+'verification.json');audit_summary=j(R+'audit-summary.json');inventory=j(C+'implementation-inventory.json')
    assert verify['theorems_audited']==1980 and verify['safe_definitions_audited']==566
    assert sorted(verify['axiom_union'])==sorted(axunion) and sorted(verify['safe_definition_axiom_union'])==sorted(sunion)
    assert verify['nonsafe_definitions_inventoried']==[list(x) for x in nonsafe]
    assert verify['unsafe_implementation_axioms_inventoried']==[list(x) for x in unsafeax]
    assert inventory['status']=='PASS' and inventory['nonsafe_count']==12146 and inventory['cstage_helpers']==12111 and inventory['unsafe_rec_helpers']==35 and not inventory['unclassified_nonsafe'] and not inventory['unsafe_opaques']
    counts={m:{'theorems':sum(x[0]==m for x in theorem),'safe_definitions':sum(x[0]==m for x in safe)} for m in mods}
    assert counts==audit_summary['per_module']
    fullsummary=re.search(r'^FULL_MODULE_AUDIT theorems=(\d+) union=\[([^\]]*)\]$',log,re.M)
    defsummary=re.search(r'^FULL_DEFINITION_AUDIT definitions=(\d+) union=\[([^\]]*)\]$',log,re.M)
    assert int(fullsummary[1])==1980 and set(axes(fullsummary[2]))==axunion
    assert int(defsummary[1])==566 and set(axes(defsummary[2]))==sunion
    checks=re.findall(r'^#check (\S+)$',text(C+'ReviewAudit.lean'),re.M)
    assert len(exports)==len(set(exports))==len(checks)==172 and checks==[name for mod,name in exports]
    assert verify['audited_named_exports']==checks
    headers=list(re.finditer(r'^(Agent1\.\S+)(?=\s|\n)',log,re.M))
    assert [m[1] for m in headers]==checks
    interfaces=[]
    for i,((mod,name),m) in enumerate(zip(exports,headers)):
        typ=log[m.start():headers[i+1].start() if i+1<len(headers) else len(log)].rstrip()
        printed=re.search("'"+re.escape(name)+"' (?:depends on axioms:\\s*\\[([^\\]]*)\\]|does not depend on any axioms)",text(C+mod+'.log'))
        assert printed,name
        ax=axes(printed[1] or '')
        assert set(ax)<=allowed and (mod,name) in {(m,n) for m,n,a in theorem}
        interfaces.append({'module':mod,'name':name,'printed_type':typ,'source_axioms':ax})
    assert sum(m in identity['new_modules'] for m,n in exports)==5
    (O/f'public-interfaces-{run}.json').write_text(json.dumps(interfaces,ensure_ascii=False,indent=2)+'\n')
    report['checks']['full_audit_log']={'theorem_constants':1980,'safe_definitions_and_opaques':566,'theorem_axiom_union':sorted(axunion),'safe_axiom_union':sorted(sunion),'module_counts':counts,'named_public_types_and_source_axiom_prints':172,'new_public_types':5,'prior_public_types':167,'unsafe_implementation_axioms_separate':32,'nonsafe_generated_definitions_separate':12146,'cstage_helpers':12111,'unsafe_recursion_helpers_with_audited_safe_bases':35,'unsafe_opaques':0,'unclassified_implementations':0,'every_row_parsed_and_checked':True}
    parent=j(Q+'verification.json');pp=parent['projects']['agent1-periodic-return-upper-gap']
    assert parent['status']=='PASS' and parent['source_commit']==S and parent['source_tree_clean'] is True
    assert not parent['repository_wide_pass'] and not parent['catalogue_complete']
    assert len(pp['commands'])==42 and all(r['exit_code']==0 for r in pp['commands'])
    assert all('--trust=0' not in r['argv'] for r in pp['commands'])
    for r in pp['commands']:assert sha(data(Q+r['log']))==r['log_sha256']
    for name,r in pp['sources'].items():assert r['sha256']==r['build_sha256']==mods[name]['sha256']
    assert data(Q+'canonical-checker.py')==data('proofs/verify_project__214bf7673efe116b.py')
    parent_receipt=j(Q+'source-identity-receipt.json')
    assert sha(data(Q+'verification.json'))==parent_receipt['original_report_sha256']
    assert sha(data(Q+'FILES.json'))==parent_receipt['original_files_sha256']
    assert sha(data(Q+'source-identity-receipt.json'))==receipt['parent_packaging_receipt_sha256']
    assert sha(data(Q+'PACKAGE-FILES.json'))==receipt['parent_package_manifest_sha256']
    report['checks']['separate_parent_execution']={'commands_exit_zero':42,'source_tree_clean_original':True,'explicit_trust_zero_commands':0,'all_source_and_log_hashes_match':True,'original_report_and_FILES_preserved':True,'canonical_checker_exact':True}
    attempts=[]
    for number,code in [(1,1),(2,0),(3,0)]:
        pref=P+f'upper-author/attempt-{number:03}/';r=j(pref+'result.json');b=data(pref+'Agent1PeriodicReturnUpper.lean')
        assert r['exit_code']==code and sha(b)==r['source_sha256'] and r['dependency_objects_reused'] and not r['fresh_full_closure']
        attempts.append({'attempt':number,'exit_code':code,'source_sha256':sha(b),'dependency_objects_reused':True,'public_theorems':re.findall(r'^theorem\s+(\w+)',mask(b.decode()),re.M)})
    assert "error: unknown constant 'Nat.cast_zero'" in text(P+'upper-author/attempt-001/compile.log')
    assert len(attempts[1]['public_theorems'])==1 and len(attempts[2]['public_theorems'])==3
    assert data(P+'upper-author/attempt-003/Agent1PeriodicReturnUpper.lean')==data('proofs/Agent1PeriodicReturnUpper.lean')
    report['checks']['preserved_author_attempts']=attempts
    original=json.loads((O/'connector-records-001.json').read_text())
    reviews=original['reviews']['value']['structuredContent']['reviews'];assert len(reviews)==1
    rv=reviews[0];encoded=rv['id'].split('_',1)[1];rid=int.from_bytes(base64.urlsafe_b64decode(encoded+'='*((-len(encoded))%4))[-8:],'big')
    assert rid==5555257249 and H in rv['body'] and rv['state']=='COMMENTED'
    report['checks']['formal_review']={'id':rid,'state':rv['state'],'submitted_at':rv['submitted_at'],'account':rv['author']['login'],'body_sha256':sha(rv['body'].encode()),'exact_H_named':True,'nonauthor_specialist':'/root/research_status','independent_account_approval':False}
    report['status']='PASS_RETAINED_REVIEW_REUSE'
except Exception as e:
    report['status']='INCOMPLETE_OR_FAILED';report['error']=repr(e);report['traceback']=traceback.format_exc()
finally:
    (O/f'validation-commands-{run}.json').write_text(json.dumps(commands,indent=2)+'\n')
    (O/f'validation-results-{run}.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({'run':run,'status':report['status'],'completed_checks':list(report['checks']),'error':report.get('error'),'traceback':report.get('traceback')},indent=2))
if report['status']!='PASS_RETAINED_REVIEW_REUSE':raise SystemExit(1)
