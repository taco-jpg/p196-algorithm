#!/usr/bin/env python3
"""Read-only PR147 dependency metadata and evidence preservation checks. No Lean."""
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/c0bb09a3002b/agent15-repo')
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
M = '8f9249c855418eaadf9bb68bd645948d15777b5b'
E = 'e77289c5f58a3238f53c0f3c6951a73515c5d7d2'
P = '159ed83569f5cc4d058557c2b24b28839552b75a'
PM = '6be2aa2273e97ecf15445429827b02feb9bb83c0'
R = '946c69edf3d2e6a87f5516db1fd0091eae29e663'
C = 'ebcaf723d61f9513c8bae30440d02ba4a46343b4'
F = '84a65f296625e16851b4a369e27ffca43aaea40c'
H = '502d3f5ea2e516f7cf4342854e1ec865f188d4f3'
B = '74a1c3922eb7af438fe40b23d2105ad07556e3f5'
PREFIX = 'proofs/contributions/agent-1/periodic-width-projection-20261016/'
commands = []
checks = []
(ROOT / 'commands').mkdir(exist_ok=True)

def save(name, obj):
    (ROOT / name).write_text(json.dumps(obj, indent=2, ensure_ascii=False) + '\n')

def check(name, passed, detail=None):
    checks.append(dict(name=name, passed=bool(passed), detail=detail))
    assert passed, (name, detail)

def git(*args):
    argv = ['git', '-C', str(REPO), *args]
    p = subprocess.run(argv, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    n = len(commands) + 1
    out = f'commands/{n:02d}.stdout'
    err = f'commands/{n:02d}.stderr'
    (ROOT / out).write_bytes(p.stdout)
    (ROOT / err).write_bytes(p.stderr)
    commands.append(dict(argv=argv, environment={'GIT_NO_LAZY_FETCH':'1','GIT_OPTIONAL_LOCKS':'0'}, exit_code=p.returncode, stdout=out, stderr=err, stdout_sha256=hashlib.sha256(p.stdout).hexdigest(), stderr_sha256=hashlib.sha256(p.stderr).hexdigest()))
    save('actual-commands.json', commands)
    if p.returncode:
        raise RuntimeError(f'Command {n} failed: {p.stderr.decode(errors="replace")}')
    return p.stdout

def tree(commit):
    entries = {}
    for record in git('ls-tree', '-r', '-z', commit).split(b'\0'):
        if not record:
            continue
        meta, path = record.split(b'\t', 1)
        mode, kind, oid = meta.decode().split()
        entries[path.decode()] = dict(mode=mode, kind=kind, oid=oid)
    return entries

def delta(a, b):
    return [dict(path=p, status='A' if p not in a else 'D' if p not in b else 'M', old=a.get(p), new=b.get(p)) for p in sorted(a.keys() | b.keys()) if a.get(p) != b.get(p)]

try:
    observations = json.loads((ROOT / 'remote-observations.json').read_text())
    check('direct_ref147_and_PR147_head_equal_final_evidence_commit', observations['refs']['ref147']['object']['sha'] == observations['prs']['147']['head']['sha'] == E)
    check('direct_ref146_and_PR146_head_equal_final_evidence_commit', observations['refs']['ref146']['object']['sha'] == observations['prs']['146']['head']['sha'] == P)
    check('direct_main_ref', observations['refs']['refmain']['object']['sha'] == B)
    check('PR150_head_and_nested_base_observation', observations['prs']['150']['head']['sha'] == R and observations['prs']['150']['base']['sha'] == M)
    check('PR154_head_and_nested_base_observation', observations['prs']['154']['head']['sha'] == C and observations['prs']['154']['base']['sha'] == E)
    headers = {commit: git('cat-file', '-p', commit).decode() for commit in (M, E, P, R, C, F, H)}
    save('commit-headers.json', headers)
    check('final_PR147_commit_direct_parent_is_mathematical_source', [line[7:] for line in headers[E].splitlines() if line.startswith('parent ')] == [M])
    check('PR150_actual_common_ancestor_with_final_PR147_is_M', git('merge-base', E, R).decode().strip() == M)
    check('PR154_actual_common_ancestor_with_final_PR147_is_M_despite_API_base_E', git('merge-base', E, C).decode().strip() == M)
    check('PR167_foundation_parents_clock_then_core', [line[7:] for line in headers[F].splitlines() if line.startswith('parent ')] == [C, R])
    mt, et = tree(M), tree(E)
    changes = delta(mt, et)
    save('PR147-final-evidence-177-paths.json', changes)
    counts = dict(collections.Counter(c['status'] for c in changes))
    check('PR147_forward_delta_is_176_additions_and_one_modification', counts == {'M':1, 'A':176}, counts)
    check('all_PR147_final_changes_confined_to_contribution_evidence_directory', all(c['path'].startswith(PREFIX) for c in changes))
    check('sole_modified_path_is_contribution_README', [c['path'] for c in changes if c['status'] == 'M'] == [PREFIX + 'README.md'])
    check('all_original_tree_paths_retained', mt.keys() <= et.keys(), {'original_paths':len(mt), 'final_paths':len(et)})
    changed_originals = [p for p in mt if mt[p] != et[p]]
    check('all_original_blobs_and_modes_except_README_exactly_preserved', changed_originals == [PREFIX + 'README.md'], {'unchanged_original_paths':len(mt)-len(changed_originals)})
    check('mathematical_source_registry_build_configuration_unchanged', all(mt.get(p) == et.get(p) for p in mt.keys() | et.keys() if not p.startswith(PREFIX)))
    for label, commit in [('original',M), ('final',E)]:
        content = git('show', f'{commit}:{PREFIX}README.md')
        (ROOT / f'PR147-{label}-README.md').write_bytes(content)
    pt, pmt = tree(P), tree(PM)
    pd = delta(pmt, pt)
    save('PR146-final-evidence-paths.json', pd)
    check('parent146_final_evidence_has_163_changed_paths', len(pd) == 163, dict(collections.Counter(c['status'] for c in pd)))
    check('parent146_original_tree_paths_retained', pmt.keys() <= pt.keys())
    check('parent146_final_changes_and_PR147_327_additions_disjoint', set(c['path'] for c in pd).isdisjoint(set(c['path'] for c in delta(pmt, et))))
    child_delta = delta(pmt, et)
    save('PR147-original-base-327-paths.json', child_delta)
    check('PR147_delta_from_actual_original_parent_is_327_additions', len(child_delta)==327 and all(c['status']=='A' for c in child_delta))
    reviews = observations['reviews147']
    check('both_existing_source_specific_reviews_tied_to_exact_E', {r['id'] for r in reviews} == {5554812356,5554912801} and all(r['commit_id']==E and r['state']=='COMMENTED' for r in reviews))
    timeline = observations['timeline150']
    comments = [t for t in timeline if t.get('id') == 6230296177 and t['event']=='commented']
    check('Agent10_qualification_comment_timestamp_equals_PR150_updated_at', len(comments)==1 and comments[0]['created_at']==observations['prs']['150']['updated_at'])
    check('retrieved_PR150_timeline_has_no_base_ref_change_event', len(timeline)<100 and all('base_ref' not in t['event'] for t in timeline), {'events':len(timeline)})
    expected_owner_blobs = {'owner146':'4e42e682b5bae6415941845c7ef254758b8d824c','owner147':'2867a0ba9c43dee18aa3f910f33e73042666c28c','owner150':'4c7da43c2c12b7345ee3a127dd3453826e7c139d'}
    for label, expected in expected_owner_blobs.items():
        data = observations['task_records'][label].encode()
        actual = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        check(label+'_retrieved_content_matches_original_git_blob', actual==expected, actual)
        owner = json.loads(data)
        check(label+'_source_head_matches_live_PR', owner['source_head']==observations['prs'][label[5:]]['head']['sha'])
    result = dict(status='PASS_DEPENDENCY_METADATA_RESOLVED', checked_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(), check_count=len(checks), passed=sum(c['passed'] for c in checks), checks=checks, command_count=len(commands), fresh_Lean='NOT_RUN', combined_tree='NOT_CONSTRUCTED_BY_THIS_SUBAGENT', remote_mutations='NONE')
except Exception as error:
    result = dict(status='FAILED', error=repr(error), checks=checks, command_count=len(commands))
    save('check-result.json', result)
    raise
save('check-result.json', result)
print(json.dumps({k:v for k,v in result.items() if k!='checks'}, indent=2))
