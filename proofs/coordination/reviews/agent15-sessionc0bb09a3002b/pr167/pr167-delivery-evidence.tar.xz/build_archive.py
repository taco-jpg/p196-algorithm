#!/usr/bin/env python3
"""Losslessly package the complete delivery evidence and verify every member."""
from pathlib import Path
import datetime
import hashlib
import json
import tarfile

ROOT = Path(__file__).resolve().parent
DEST = Path('/workspace/scratch/c0bb09a3002b/agent15-publish/pr167')
DEST.mkdir(parents=True, exist_ok=True)
ARCHIVE = DEST / 'pr167-delivery-evidence.tar.xz'
EXCLUDED = {'dependency-refresh-evidence.tar.gz'}


def sha256_file(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        for block in iter(lambda: f.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


files = sorted(p for p in ROOT.rglob('*') if p.is_file() and p.relative_to(ROOT).as_posix() not in EXCLUDED)
assert not ARCHIVE.exists(), 'Refuse to overwrite a previous archive.'
records = []
for path in files:
    assert not path.is_symlink(), 'No symlink may enter the evidence archive.'
    rel = path.relative_to(ROOT).as_posix()
    data = path.read_bytes()
    records.append({'original_path': rel, 'original_bytes': len(data),
                    'original_sha256': hashlib.sha256(data).hexdigest(),
                    'original_mode': oct(path.stat().st_mode & 0o777),
                    'git_blob_for_exact_bytes': hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest(),
                    'stored_path': 'pr167-delivery-evidence.tar.xz', 'archive_member': rel})

with tarfile.open(ARCHIVE, 'w:xz', preset=6) as archive:
    for path in files:
        info = archive.gettarinfo(str(path), arcname=path.relative_to(ROOT).as_posix())
        info.uid = info.gid = 0
        info.uname = info.gname = ''
        info.mtime = 0
        with path.open('rb') as f:
            archive.addfile(info, f)

with tarfile.open(ARCHIVE, 'r:xz') as archive:
    members = archive.getmembers()
    assert [m.name for m in members] == [r['archive_member'] for r in records]
    for member, row in zip(members, records):
        assert member.isfile()
        data = archive.extractfile(member).read()
        assert len(data) == row['original_bytes']
        assert hashlib.sha256(data).hexdigest() == row['original_sha256']
        assert data == (ROOT / row['original_path']).read_bytes()

archive_bytes = ARCHIVE.read_bytes()
compressed_sha = hashlib.sha256(archive_bytes).hexdigest()
compressed_git = hashlib.sha1(b'blob ' + str(len(archive_bytes)).encode() + b'\0' + archive_bytes).hexdigest()
exclusions = []
for rel in sorted(EXCLUDED):
    path = ROOT / rel
    exclusions.append({'path': rel, 'bytes': path.stat().st_size, 'sha256': sha256_file(path),
                       'reason': 'Redundant intermediate transport archive of dependency-refresh/. Every original member and its manifest is retained directly in the complete archive; no substantive source, report, command or failure is excluded.'})
result = {
    'schema_version': 1, 'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'PASS_LOSSLESS_ARCHIVE_ROUNDTRIP',
    'archive': {'path': ARCHIVE.name, 'format': 'tar.xz', 'xz_preset': 6,
                'bytes': len(archive_bytes), 'sha256': compressed_sha, 'git_blob': compressed_git},
    'original_file_count': len(records), 'original_byte_sum': sum(r['original_bytes'] for r in records),
    'all_members_compared_with_original_bytes': True,
    'recovery_command': 'mkdir pr167-recovered && tar -xJf pr167-delivery-evidence.tar.xz -C pr167-recovered',
    'archive_identity_command': f"printf '%s  %s\\n' '{compressed_sha}' '{ARCHIVE.name}' | sha256sum -c -",
    'verification': 'After extraction, compare every listed original_path byte count and SHA-256 with this manifest. All members were compared byte-for-byte with the originals before publication.',
    'tar_metadata': 'Original file modes retained; uid/gid zero, empty user/group names, mtime zero for deterministic packing. The complete original file bytes are unchanged.',
    'scope': 'Complete Agent15 PR167 delivery evidence, including all699 source-PR additions, exact selected source blobs, full raw outputs and failed/successful checks. This is not an actual main release or a new Lean execution.',
    'exclusions': exclusions + [
        {'category': 'Local Git object caches and synthetic local candidate commits', 'reason': 'Reproducible infrastructure outside the evidence root; exact original commit/tree identities, actual commands and full tree outputs retained.'},
        {'category': 'Runtime installations, compiled objects, transient upload buffers and Python caches', 'reason': 'Reproducible infrastructure; source/toolchain pins, original substantive logs and complete evidence are retained.'},
        {'category': 'ARCHIVE.json and later publication/dispatch receipts', 'reason': 'Published separately to avoid a self-referential archive identity. Later actions are not backdated into the archived observations.'}
    ],
    'files': records,
}
(DEST / 'ARCHIVE.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'files'}, indent=2))
