#!/usr/bin/env python3
"""Read-only PR167 package checks. No imported package code, Lean, or Git mutation."""
from pathlib import Path
import ast
from collections import Counter, defaultdict
import datetime
import hashlib
import json
import platform
import re

HERE = Path(__file__).resolve().parent
SNAP = HERE / 'head-delta'
UPPER = 'proofs/contributions/agent-1/periodic-return-upper-gap-20261017/'
CORE = 'proofs/contributions/agent-1/periodic-return-core-20261016/'
read_json = lambda p: json.loads(p.read_text())
sha = lambda b: hashlib.sha256(b).hexdigest()
blob = lambda b: hashlib.sha1(b'blob ' + str(len(b)).encode() + b'\0' + b).hexdigest()
manifest = read_json(HERE / 'final-snapshot-manifest.json')
delta = read_json(HERE / 'delta.json')
pin_data = read_json(HERE / 'pinned-trees.json')
trees = pin_data['trees']
errors = []
checks = []
def check(name, ok, detail=None):
    row = {'check': name, 'status': 'PASS' if ok else 'FAIL'}
    if detail is not None: row['detail'] = detail
    checks.append(row)
    if not ok: errors.append(row)
def save(name, value):
    (HERE / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + '\n')

indexed = {r['path']: r for r in manifest}
data_by_oid = {}
for r in manifest:
    path = SNAP / r['path']
    data = path.read_bytes()
    actual = {'git_oid': blob(data), 'sha256': sha(data), 'bytes': len(data)}
    check('snapshot_identity:' + r['path'], all(r[k] == v for k, v in actual.items()), actual)
    data_by_oid[actual['git_oid']] = data
actual_paths = {str(p.relative_to(SNAP)) for p in SNAP.rglob('*') if p.is_file()}
check('snapshot_exact_699_paths', actual_paths == set(indexed) and len(indexed) == 699)
computed_delta = {p for p in set(trees['head']) | set(trees['pr_base'])
                  if trees['head'].get(p) != trees['pr_base'].get(p)}
check('delta_complete_against_exact_trees', computed_delta == set(indexed) == {r['path'] for r in delta})
check('only_additions', all(r['status'] == 'added' and r['before'] is None for r in delta))
check('all_regular_nonexecutable_blobs', all(trees['head'][p]['mode'] == '100644' and trees['head'][p]['type'] == 'blob' for p in indexed))
inherited = [r for r in delta if r['classification'] == 'inherited_from_combined_foundation']
own = [r for r in delta if r['classification'] != 'inherited_from_combined_foundation']
check('inherited_403_side_core_and_foundation_exact', len(inherited) == 403 and all(
    r['after'] == trees['side_core'].get(r['path']) == trees['combined_foundation'].get(r['path']) for r in inherited))
check('own_296_new_to_foundation', len(own) == 296 and all(r['path'] not in trees['combined_foundation'] for r in own))
roots = [r['path'] for r in own if not r['path'].startswith(UPPER)]
expected_roots = ['proofs/Agent1PeriodicInitialIncoming.lean', 'proofs/Agent1PeriodicReturnUpper.lean', 'proofs/Agent1PeriodicReturnUpper.registry.json']
check('only_three_own_root_files', sorted(roots) == expected_roots, roots)
check('own_root_files_frozen_at_mathematical_source', all(trees['head'][p] == trees['mathematical_source'].get(p) for p in expected_roots))
check('all_699_inside_two_packages_and_eight_root_files', all(
    p.startswith((UPPER, CORE)) or (p.startswith('proofs/') and p.count('/') == 1)
    for p in indexed))

groups = defaultdict(list)
for r in manifest:
    p = r['path']
    if p.startswith(UPPER): group = 'own/' + p[len(UPPER):].split('/')[0]
    elif p.startswith(CORE): group = 'inherited/' + p[len(CORE):].split('/')[0]
    else: group = ('inherited' if r['classification'].startswith('inherited') else 'own') + '/root-files'
    groups[group].append(r)
save('group-inventory.json', {k: {'files': len(v), 'bytes': sum(r['bytes'] for r in v),
    'paths': [r['path'] for r in v]} for k, v in sorted(groups.items())})

# Structural source-pin check only: use already recovered exact blobs, not a new proof run.
registry = read_json(SNAP / expected_roots[-1])
project = registry['projects']['agent1-periodic-return-upper-gap']
module_rows = []
for name, pin in project['modules'].items():
    tree_entry = trees['head'].get(pin['path'])
    raw = data_by_oid.get(pin['git_blob'])
    item = {'module': name, 'path': pin['path'], 'git_blob': pin['git_blob'],
        'head_tree_matches': tree_entry is not None and tree_entry['git_oid'] == pin['git_blob'],
        'recovered_bytes_match_sha256': raw is not None and sha(raw) == pin['sha256'],
        'mathematical_source_tree_unchanged': tree_entry == trees['mathematical_source'].get(pin['path'])}
    if raw is not None:
        imports = []
        for s in re.findall(r'^\s*import\s+([^\n]+)', raw.decode(), re.M):
            imports.extend(s.split('--')[0].split())
        item['actual_imports'] = imports
        item['recorded_imports_match'] = imports == pin['imports']
    module_rows.append(item)
check('registry_exact_41_source_pins', len(module_rows) == 41 and all(
    r['head_tree_matches'] and r['recovered_bytes_match_sha256'] and r['mathematical_source_tree_unchanged']
    and r.get('recorded_imports_match') for r in module_rows))
visited, visiting, order = set(), set(), []
def visit(name):
    if name in ('Init', 'Std', 'Lean') or name in visited: return
    if name in visiting or name not in project['modules']: raise ValueError('Cyclic or missing import: ' + name)
    visiting.add(name)
    for dep in project['modules'][name]['imports']: visit(dep)
    visiting.remove(name); visited.add(name); order.append(name)
for root in project['roots']: visit(root)
check('registry_complete_acyclic_root_closure', len(visited) == 41 and visited == set(project['modules']), order)
check('registry_ordinary_axiom_allowlist', registry['toolchain']['allowed_axioms'] == ['propext', 'Classical.choice', 'Quot.sound'])
check('registry_frozen_scoped_not_default_catalogue', registry['catalogue_complete'] is False and registry['accepted_global_registry_modified'] is False)
save('registry-structural-check.json', {'sources': module_rows, 'topological_order': order,
    'roots': project['roots'], 'source_baseline': registry['source_baseline'],
    'qualification': 'Byte identities and imports only; no Lean execution or axiom replay.'})

# Validate author publication manifests. Independent-review 144/85/88 validation is delegated.
author_manifests = []
for rel in [UPPER + 'incoming-author/FILES.json', UPPER + 'upper-author/manifest.json']:
    mp = SNAP / rel
    val = read_json(mp)
    entries = val if mp.name == 'FILES.json' else {r['path']: r for r in val['files']}
    failures = []
    for relp, spec in entries.items():
        p = mp.parent / relp
        if not p.is_file(): failures.append({'path': relp, 'error': 'missing'}); continue
        raw = p.read_bytes()
        if sha(raw) != spec['sha256'] or len(raw) != spec['bytes']:
            failures.append({'path': relp, 'error': 'identity mismatch'})
    present = {str(p.relative_to(mp.parent)) for p in mp.parent.rglob('*') if p.is_file()}
    coverage_ok = present == set(entries) | {mp.name}
    row = {'path': rel, 'entries': len(entries), 'failures': failures,
        'complete_own_directory_except_self': coverage_ok}
    author_manifests.append(row)
    check('author_manifest:' + rel, not failures and coverage_ok, {'entries': len(entries)})
save('author-manifest-checks.json', author_manifests)

sha_manifests = []
for p in sorted(SNAP.rglob('*.sha256')):
    result = {'path': str(p.relative_to(SNAP)), 'matching_present': [], 'omitted_runtime_objects': [], 'failures': []}
    for line in p.read_text().splitlines():
        expected, relp = line.split('  ', 1)
        target = p.parent / relp
        if target.is_file():
            if sha(target.read_bytes()) != expected: result['failures'].append({'path': relp, 'reason': 'hash mismatch'})
            else: result['matching_present'].append(relp)
        elif target.suffix in ('.olean', '.ilean'):
            result['omitted_runtime_objects'].append({'path': relp, 'sha256': expected})
        else: result['failures'].append({'path': relp, 'reason': 'missing substantive item'})
    sha_manifests.append(result)
    check('historical_hash_manifest:' + str(p.relative_to(SNAP)), not result['failures'],
          {'matching_present': len(result['matching_present']), 'runtime_objects_omitted': len(result['omitted_runtime_objects'])})
save('historical-hash-manifests.json', sha_manifests)

# Parse scripts without importing, executing, compiling, or making Python bytecode.
script_groups = defaultdict(list)
for r in manifest:
    if r['path'].endswith('.py'): script_groups[r['git_oid']].append(r)
scripts = []
def dotted(n):
    if isinstance(n, ast.Name): return n.id
    if isinstance(n, ast.Attribute): return dotted(n.value) + '.' + n.attr
    return '<expression>'
for oid, records in sorted(script_groups.items()):
    raw = data_by_oid[oid]
    tree = ast.parse(raw.decode(), filename=records[0]['path'])
    imports = []
    calls = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import): imports.extend(a.name for a in node.names)
        if isinstance(node, ast.ImportFrom): imports.append(node.module)
        if isinstance(node, ast.Call):
            name = dotted(node.func)
            if (name.startswith(('subprocess.', 'shutil.', 'os.', 'resource.')) or
                name.endswith(('.write_text', '.write_bytes', '.mkdir', '.open', '.unlink', '.kill', '.terminate')) or
                name in ('exec', 'eval', 'compile', '__import__')):
                calls.append({'line': node.lineno, 'call': name, 'expression': ast.unparse(node)})
    shell_true = [n.lineno for n in ast.walk(tree) if isinstance(n, ast.Call) and any(
        kw.arg == 'shell' and isinstance(kw.value, ast.Constant) and kw.value.value is True for kw in n.keywords)]
    network_imports = [i for i in imports if i and i.split('.')[0] in ('socket', 'requests', 'urllib', 'http', 'httpx', 'ftplib', 'paramiko')]
    scripts.append({'git_oid': oid, 'sha256': sha(raw), 'bytes': len(raw),
        'paths': [r['path'] for r in records], 'imports': sorted(set(imports)),
        'notable_calls': calls, 'shell_true_lines': shell_true, 'network_imports': network_imports,
        'syntax': 'PASS', 'execution_performed': False})
check('all_added_python_parse_without_execution', len(scripts) == 21 and sum(len(s['paths']) for s in scripts) == 32)
check('no_shell_true_or_network_imports_in_added_scripts', not any(s['shell_true_lines'] or s['network_imports'] for s in scripts))
save('script-static-inventory.json', scripts)

# Preserve recorded failures as failures; inspect original records, do not rerun them.
failure_records = []
parsed_json = 0
def walk_failures(obj, path, pointer=''):
    if isinstance(obj, dict):
        for key, val in obj.items():
            if key in ('exit_code', 'returncode', 'return_code') and isinstance(val, int) and val != 0:
                failure_records.append({'path': path, 'json_pointer': pointer + '/' + key, 'value': val})
            elif key in ('status', 'result') and isinstance(val, str) and val in ('FAIL', 'FAILED', 'TIMEOUT', 'UNKNOWN'):
                failure_records.append({'path': path, 'json_pointer': pointer + '/' + key, 'value': val})
            walk_failures(val, path, pointer + '/' + key)
    elif isinstance(obj, list):
        for i, val in enumerate(obj): walk_failures(val, path, pointer + '/' + str(i))
for r in manifest:
    if r['path'].endswith('.json'):
        parsed_json += 1
        walk_failures(read_json(SNAP / r['path']), r['path'])
check('all_added_json_parse', parsed_json == 124)
save('retained-negative-records.json', failure_records)
first = read_json(SNAP / UPPER / 'upper-author/attempt-001/result.json')
last = read_json(SNAP / UPPER / 'upper-author/attempt-003/result.json')
first_log = (SNAP / UPPER / 'upper-author/attempt-001/compile.log').read_text()
check('failed_upper_attempt_preserved', first['exit_code'] == 1 and 'Nat.cast_zero' in first_log)
check('final_upper_author_exact_frozen_source', last['exit_code'] == 0 and last['source_sha256'] == indexed['proofs/Agent1PeriodicReturnUpper.lean']['sha256'] and last['fresh_full_closure'] is False)
author_commands = []
for rel in ['incoming-author/attempt-001/command.json', 'incoming-author/audit-001/command.json',
            'upper-author/attempt-001/commands.json', 'upper-author/attempt-002/commands.json', 'upper-author/attempt-003/commands.json']:
    value = read_json(SNAP / UPPER / rel)
    rows = value if isinstance(value, list) else [value]
    for row in rows:
        cmd = row['command']
        author_commands.append({'path': UPPER + rel, 'command': cmd,
            'strict_flags_present': all(f in cmd for f in ('--trust=0', '-j1', '-DElab.async=false')),
            'compiler_sha256': row['compiler_sha256'], 'exit_code': row.get('exit_code')})
check('all_seven_recorded_author_commands_have_strict_flags', len(author_commands) == 7 and all(r['strict_flags_present'] for r in author_commands))
save('author-command-flags.json', author_commands)

# Main policies are read from the pinned current-main commit and must match their Git entries.
policy_rows = []
for p in sorted((HERE / 'main-policy').rglob('*')):
    if not p.is_file(): continue
    rel = str(p.relative_to(HERE / 'main-policy')); raw = p.read_bytes()
    policy_rows.append({'path': rel, 'git_oid': blob(raw), 'sha256': sha(raw),
        'matches_pinned_main': trees['observed_main'][rel]['git_oid'] == blob(raw),
        'unchanged_between_pr_base_and_head': trees['pr_base'].get(rel) == trees['head'].get(rel)})
check('main_policy_content_identity', bool(policy_rows) and all(r['matches_pinned_main'] for r in policy_rows))
checker_oid = trees['observed_main']['proofs/verify_project__214bf7673efe116b.py']['git_oid']
check('packaged_canonical_checker_is_existing_main_checker', checker_oid == trees['head'][UPPER + 'verification/parent-clean-001/canonical-checker.py']['git_oid'])
save('main-policy-identities.json', policy_rows)

stats = {'status': 'PASS_STATIC_PACKAGE_CHECKS' if not errors else 'FAIL_STATIC_PACKAGE_CHECKS',
    'checked_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'python_version': platform.python_version(), 'pins': pin_data['pins'],
    'file_count': len(manifest), 'total_bytes': sum(r['bytes'] for r in manifest),
    'unique_blobs': len(data_by_oid), 'inherited_file_count': len(inherited), 'own_file_count': len(own),
    'suffix_counts': dict(Counter(Path(r['path']).suffix for r in manifest)),
    'python_path_count': sum(len(s['paths']) for s in scripts), 'python_distinct_blob_count': len(scripts),
    'author_manifest_entries': sum(r['entries'] for r in author_manifests),
    'sha256_manifest_count': len(sha_manifests),
    'sha256_manifest_present_entries': sum(len(r['matching_present']) for r in sha_manifests),
    'sha256_manifest_runtime_omissions': sum(len(r['omitted_runtime_objects']) for r in sha_manifests),
    'recorded_negative_entries': len(failure_records), 'check_count': len(checks), 'failures': errors,
    'lean_executed': False, 'package_script_executed': False, 'repository_mutated': False,
    'remote_writes_performed': False,
    'delegated_exclusions': ['independent review 144-entry manifest', 'original parent 85-entry manifest',
        'parent package 88-entry manifest', 'complete strict fresh audit qualification', 'actual intended integration tree', 'platform merge state']}
save('lightweight-checks.json', checks)
save('check-results.json', stats)
print(json.dumps(stats, indent=2))
raise SystemExit(1 if errors else 0)
