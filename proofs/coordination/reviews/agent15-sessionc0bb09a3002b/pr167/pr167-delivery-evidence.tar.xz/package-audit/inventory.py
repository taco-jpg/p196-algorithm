#!/usr/bin/env python3
"""Read immutable Git objects without lazy fetching or modifying the source repository."""
import collections
import datetime
import hashlib
import json
import os
from pathlib import Path
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/c0bb09a3002b/agent15-repo')
PINS = {
    'head': '502d3f5ea2e516f7cf4342854e1ec865f188d4f3',
    'pr_base': 'ebcaf723d61f9513c8bae30440d02ba4a46343b4',
    'side_core': '946c69edf3d2e6a87f5516db1fd0091eae29e663',
    'mathematical_source': '24cbcc99754cadb2d9ce4ba448e3a91171b9f4f0',
    'combined_foundation': '84a65f296625e16851b4a369e27ffca43aaea40c',
    'observed_main': '74a1c3922eb7af438fe40b23d2105ad07556e3f5',
}
ENV = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0', GIT_TERMINAL_PROMPT='0')
COMMANDS = []

def git(*args):
    command = ['git', '-C', str(REPO), *args]
    result = subprocess.run(command, env=ENV, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    COMMANDS.append({'argv': command, 'exit_code': result.returncode,
                     'stdout_sha256': hashlib.sha256(result.stdout).hexdigest(),
                     'stderr': result.stderr.decode(errors='replace')})
    if result.returncode:
        raise RuntimeError(result.stderr.decode(errors='replace'))
    return result.stdout

def tree(rev):
    result = {}
    for row in git('ls-tree', '-rz', '--full-tree', rev).split(b'\0'):
        if not row:
            continue
        meta, path = row.split(b'\t', 1)
        mode, typ, oid = meta.decode().split()
        result[path.decode()] = {'mode': mode, 'type': typ, 'git_oid': oid}
    return result

def save(name, data):
    (ROOT / name).write_text(json.dumps(data, indent=2, ensure_ascii=False) + '\n')

def main():
    trees = {name: tree(rev) for name, rev in PINS.items()}
    h, base, core, foundation = (trees[n] for n in ('head', 'pr_base', 'side_core', 'combined_foundation'))
    changed = []
    for path in sorted(set(base) | set(h)):
        if base.get(path) == h.get(path):
            continue
        item = {'path': path, 'status': 'added' if path not in base else 'deleted' if path not in h else 'modified',
                'before': base.get(path), 'after': h.get(path)}
        item['classification'] = ('inherited_from_combined_foundation' if h.get(path) == foundation.get(path)
                                  else 'new_at_or_after_mathematical_source')
        item['matches_side_core'] = h.get(path) == core.get(path) and path in h
        changed.append(item)
    save('delta.json', changed)
    save('pinned-trees.json', {'pins': PINS, 'trees': trees})
    added = [x for x in changed if x['status'] == 'added']
    oids = list(dict.fromkeys(x['after']['git_oid'] for x in added))
    result = subprocess.run(['git', '-C', str(REPO), 'cat-file', '--batch-check'], input=('\n'.join(oids)+'\n').encode(),
                            stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=ENV)
    COMMANDS.append({'argv':['git','-C',str(REPO),'cat-file','--batch-check'], 'exit_code':result.returncode,
                     'requested_unique_oids':len(oids), 'stderr':result.stderr.decode(errors='replace')})
    checks = {row.split()[0]: row.split()[1:] for row in result.stdout.decode().splitlines()}
    missing = [oid for oid in oids if checks.get(oid, ['missing'])[0] == 'missing']
    save('local-object-availability.json', {'unique_blob_count':len(oids), 'missing_oids':missing, 'objects':checks})
    snapshot = ROOT / 'head-delta'
    snapshot.mkdir(exist_ok=True)
    extraction = []
    for item in added:
        oid = item['after']['git_oid']
        if oid in missing:
            extraction.append({'path':item['path'], 'status':'LOCAL_OBJECT_UNAVAILABLE', 'git_oid':oid})
            continue
        data = git('cat-file', 'blob', oid)
        actual = hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
        if actual != oid:
            raise AssertionError((item['path'], actual, oid))
        destination = snapshot / item['path']
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        extraction.append({'path':item['path'], 'status':'EXACT_GIT_BLOB', 'git_oid':oid,
                           'sha256':hashlib.sha256(data).hexdigest(), 'bytes':len(data), 'mode':item['after']['mode']})
    save('extraction.json', extraction)
    summary = {
        'time_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(), 'pins':PINS,
        'status_counts':dict(collections.Counter(x['status'] for x in changed)),
        'classification_counts':dict(collections.Counter(x['classification'] for x in changed)),
        'side_core_matching_paths':sum(x['matches_side_core'] for x in changed),
        'mode_counts':dict(collections.Counter(x['after']['mode'] for x in added)),
        'missing_local_blob_count':len(missing), 'extracted_paths':sum(x['status']=='EXACT_GIT_BLOB' for x in extraction),
        'extracted_bytes':sum(x.get('bytes',0) for x in extraction),
        'executables':[x['path'] for x in added if x['after']['mode']=='100755' or x['path'].endswith(('.py','.sh','.bash','.js','.mjs','.lean.in'))],
        'no_network_fetch':True, 'source_repository_read_only':True, 'no_lean_execution':True,
    }
    save('inventory-summary.json', summary)
    save('commands.json', COMMANDS)
    print(json.dumps(summary, indent=2))

if __name__ == '__main__':
    main()
