# Failures, exclusions, and limitations preserved by this audit

The package audit command completed with exit 0 and no failed static checks. It did not execute Lean or any recovered script.

## Initial local object gaps

The parent checkout is partial. Initial unavailable blob observations and failed local object reads remain in commands.json, local-object-availability.json, and extraction.json. Those observations were resolved by read-only connector retrieval and verified sibling-cache reuse. They are not missing committed-source findings. The final snapshot contains all 699 entries and matches every H blob.

## Historical failures retained verbatim

retained-negative-records.json records nine nonzero-exit observations referring to six historical events. The original source, command and log files remain under head-delta:

- Core ReturnCore author attempts 001 and 002: exit 1.
- Core ZeroPath audit 001: exit -11; audit 002: exit 1.
- UpperGap author attempt 001: exit 1, unknown Nat.cast_zero.
- UpperGap publication whitespace diagnostic: exit 2, terminal blank lines in two reviewer script snapshots.

Repeated manifest references to the same failed execution do not create additional experiments. Later successes do not overwrite these failures.

## Intentionally omitted infrastructure

The seven historical SHA-256 manifests name four omitted .olean files; every present text entry matches its recorded hash. The upper-author runtime-objects.json additionally inventories two successful Upper .olean files. Generated runtime objects are excluded, not substantive source or log omissions. The source, command, compiler, hashes, resource caps and outputs needed to interpret the runs are retained.

## Scope limitations

Independent-review 144/85/88 manifest/audit qualification is assigned to the sibling specialist. Parent handles the actual intended-combination and platform state. This report only establishes package structure, exact bytes, static script behavior, source/import wiring and the inspected policy boundary. It does not establish proof correctness from static parsing, grant main authority, or certify future invocation of historical hardcoded scripts.

