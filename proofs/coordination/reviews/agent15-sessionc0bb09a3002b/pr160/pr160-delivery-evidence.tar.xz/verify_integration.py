#!/usr/bin/env python3
"""Verify the immutable PR160 test merge and unchanged historical selections."""
from pathlib import Path
import hashlib
import json
import os
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/c0bb09a3002b/agent15-repo')
H = 'fdbfb3b96fc699e45df55bcdf75c79c65dc52e83'
B = '74a1c3922eb7af438fe40b23d2105ad07556e3f5'
P = '116efc60f8d3a29bac4fcf5cdcaf2bbdcdceb3de'
M = 'f087e8d3f69ecc3b8ce972b2212301c54268ca6f'
T = '4123ca2ba0be99d36bf88cf0ccb6afe3f84bdee2'
H164 = 'fa2683e489acc7c85e08764450550f7e463041da'
ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0', GIT_NO_LAZY_FETCH='1', GIT_TERMINAL_PROMPT='0')
COMMANDS = []

def run(argv):
    p = subprocess.run(argv, env=ENV, capture_output=True)
    COMMANDS.append({'argv': argv, 'exit_code': p.returncode,
                     'stdout_bytes': len(p.stdout),
                     'stdout_sha256': hashlib.sha256(p.stdout).hexdigest(),
                     'stderr': p.stderr.decode('utf-8', errors='replace')})
    if p.returncode:
        raise RuntimeError(COMMANDS[-1])
    return p.stdout

def git(*args):
    return run(['git', '-C', str(REPO), *args])

def tree(ref):
    data = {}
    for row in git('ls-tree', '-r', '-z', '--full-tree', ref).split(b'\0'):
        if not row:
            continue
        left, path = row.split(b'\t', 1)
        mode, typ, oid = left.decode().split()
        data[path.decode()] = (mode, typ, oid)
    return data

def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

def selected(info):
    return info.get('current') or info['preserved']

def main():
    trees = {ref: tree(ref) for ref in [P, B, H, T]}
    old, base, head, merged = (trees[x] for x in [P, B, H, T])
    commit = git('cat-file', 'commit', M).decode()
    parents = re.findall(r'^parent ([0-9a-f]{40})$', commit, re.M)
    assert parents == [B, H]
    assert commit.startswith('tree ' + T + '\n')
    changed = {p for p in old.keys() | head.keys() if old.get(p) != head.get(p)}
    modified = sorted(p for p in changed if p in old and p in head)
    added = sorted(p for p in changed if p not in old)
    deleted = sorted(p for p in changed if p not in head)
    assert modified == ['proofs/REPORTS.md', 'proofs/SOURCE_MAP.json']
    assert len(changed) == 25 and len(added) == 23 and not deleted
    allowed_prefixes = ('proofs/contributions/agent-63/report-index-links-20261016/',
                        'proofs/archive/documentation/agent-63/10a173cb635fa8d03e357f454232816fc3e77609/')
    assert all(p.startswith(allowed_prefixes) for p in added)
    assert all(merged.get(p) == entry for p, entry in base.items() if p not in modified)
    assert all(merged.get(p) == head[p] for p in changed)
    assert set(merged) - set(base) == set(added)
    assert not (set(base) - set(merged))
    actual_delta = sorted(p for p in base.keys() | merged.keys() if base.get(p) != merged.get(p))
    assert actual_delta == sorted(changed)

    original_map_path = REPO / 'proofs/archive/documentation/agent-63/10a173cb635fa8d03e357f454232816fc3e77609/SOURCE_MAP.json'
    original_map_bytes = original_map_path.read_bytes()
    new_map_bytes = (REPO / 'proofs/SOURCE_MAP.json').read_bytes()
    assert blob(original_map_bytes) == base['proofs/SOURCE_MAP.json'][2] == old['proofs/SOURCE_MAP.json'][2]
    assert blob(new_map_bytes) == head['proofs/SOURCE_MAP.json'][2] == merged['proofs/SOURCE_MAP.json'][2]
    expected = original_map_bytes.replace(b'"current": "proofs/REPORTS.md"', b'"current": null')
    assert expected == new_map_bytes
    before, after = json.loads(original_map_bytes), json.loads(new_map_bytes)
    assert before['base'] == after['base'] == '2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5'
    assert before.keys() == after.keys()
    assert before['paths'].keys() == after['paths'].keys()
    assert len(before['paths']) == 9161
    changes = []
    selected_identities = []
    for path, old_info in before['paths'].items():
        new_info = after['paths'][path]
        if old_info != new_info:
            changes.append(path)
        prev = base[selected(old_info)]
        next_entry = merged[selected(new_info)]
        assert prev == next_entry
        assert prev == (old_info['mode'], 'blob', old_info['oid'])
        assert new_info['oid'] == old_info['oid'] and new_info['mode'] == old_info['mode']
        assert new_info['sha256'] == old_info['sha256']
        selected_identities.append({'original_path': path, 'before': selected(old_info),
                                   'after': selected(new_info), 'mode': prev[0], 'git_blob': prev[2]})
    assert changes == ['proofs/REPORTS.md']

    # This secondary dry run addresses the concrete shared-file overlap with PR164.
    other_map = ROOT.parent / 'pr164/source/head/proofs/SOURCE_MAP.json'
    assert blob(other_map.read_bytes()) == git('rev-parse', H164 + ':proofs/SOURCE_MAP.json').decode().strip()
    merged_map = run(['git', 'merge-file', '-p', str(REPO / 'proofs/SOURCE_MAP.json'),
                      str(original_map_path), str(other_map)])
    combined = json.loads(merged_map)
    all_three = ['proofs/REPORTS.md', 'proofs/FINDINGS.md', 'proofs/CONSOLIDATION.md']
    expected_three = original_map_bytes
    for path in all_three:
        expected_three = expected_three.replace(('"current": "' + path + '"').encode(), b'"current": null')
    assert merged_map == expected_three
    assert all(combined['paths'][path]['current'] is None for path in all_three)
    for path, info in before['paths'].items():
        if path not in all_three:
            assert combined['paths'][path] == info

    result = {
        'status': 'PASS_EXACT_CURRENT_BASE_COMBINATION', 'source_head': H, 'base': B,
        'publication_parent': P, 'platform_test_merge_commit': M, 'combined_tree': T,
        'test_merge_ordered_parents': parents, 'actual_merge': False,
        'head_delta': {'changed': len(changed), 'modified': modified, 'added': added, 'deleted': deleted},
        'preservation': {'base_file_entries': len(base), 'unchanged_base_file_entries': len(base)-len(modified),
                         'new_entries': len(added), 'deleted_entries': 0,
                         'all_other_base_modes_types_and_blobs_unchanged': True,
                         'all_changed_paths_equal_reviewed_head': True},
        'replay': {'entries': len(selected_identities), 'changed_selectors': changes,
                   'all_effective_git_blob_and_mode_identities_unchanged': True,
                   'only_exact_REPORTS_current_to_null_byte_replacement': True,
                   'full_replay_executed': False},
        'pr164_overlap': {'head': H164, 'operation': 'git merge-file -p on the two source maps and their exact original',
                          'exit_code': 0, 'preserved_null_selectors': all_three,
                          'all_other_map_bytes_unchanged': True,
                          'merged_map_sha256': hashlib.sha256(merged_map).hexdigest(),
                          'merged_map_git_blob': blob(merged_map), 'actual_source_or_target_write': False},
        'fresh_lean_build': 'NOT_RUN; no mathematical or public verification-source mutation',
        'checks_reused': 'Existing exact-source documentation and synthetic-wrapper evidence assessed separately',
        'remaining_gate': 'Refresh live head/base/actual platform gates and obtain acknowledged target-write slot or writer execution.'
    }
    (ROOT / 'integration-validation.json').write_text(json.dumps(result, indent=2) + '\n')
    (ROOT / 'effective-replay-identities.json').write_text(json.dumps(selected_identities, indent=2) + '\n')
    print(json.dumps(result, indent=2))

try:
    main()
finally:
    (ROOT / 'integration-commands.json').write_text(json.dumps(COMMANDS, indent=2) + '\n')
