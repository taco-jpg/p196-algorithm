#!/usr/bin/env python3
"""Read-only review applicability assertions; does not execute repository code."""
import hashlib
import json
import os
from pathlib import Path
import posixpath
import re
import subprocess

ROOT = Path(__file__).resolve().parent
REPO = Path('/workspace/scratch/c0bb09a3002b/agent15-repo')
P = '116efc60f8d3a29bac4fcf5cdcaf2bbdcdceb3de'
H1 = '74b34f5b0c495506ebf1e6cf95f0f7e5c016ab70'
H = 'fdbfb3b96fc699e45df55bcdf75c79c65dc52e83'
E = 'proofs/contributions/agent-63/report-index-links-20261016/'
ARCHIVE = 'proofs/archive/documentation/agent-63/10a173cb635fa8d03e357f454232816fc3e77609/'
BASELINE = '2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5'
env = dict(os.environ, GIT_NO_LAZY_FETCH='1', GIT_OPTIONAL_LOCKS='0')
commands = []

def git(*args):
    command = ['git', '-C', str(REPO), *args]
    result = subprocess.run(command, env=env, capture_output=True, text=True)
    commands.append({'argv': command, 'returncode': result.returncode,
                     'stdout': result.stdout, 'stderr': result.stderr})
    assert result.returncode == 0, commands[-1]
    return result.stdout

def tree(commit, paths):
    rows = git('ls-tree', '-r', commit, *paths)
    result = {}
    for row in rows.splitlines():
        meta, path = row.split('\t')
        mode, kind, sha = meta.split()
        result[path] = {'mode': mode, 'kind': kind, 'sha': sha}
    return result

def blob(data):
    return hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()

data = json.loads((ROOT / 'retrieved-inputs.json').read_text())
assert data['head'] == H
files = {x['path']: x for x in data['files']}
extras = {x['sha']: x['content'] for x in data['extra_blobs']}
scope = tree(H, [E, ARCHIVE, 'proofs/REPORTS.md', 'proofs/SOURCE_MAP.json', 'proofs/replay_original_layout.py'])
assert len(files) == 21
verified = []
for item in [*data['files'], *data['extra_blobs']]:
    raw = item['content'].encode('utf-8')
    assert blob(raw) == item['sha'], item.get('path', item['sha'])
    if 'path' in item:
        assert scope[item['path']] == {'mode': '100644', 'kind': 'blob', 'sha': item['sha']}
    verified.append({'path_or_blob': item.get('path', item['sha']), 'bytes': len(raw),
                     'git_blob': blob(raw), 'sha256': hashlib.sha256(raw).hexdigest()})

final_delta = [line.split('\t') for line in git('diff', '--name-status', H1, H).splitlines()]
followup = ['FOLLOWUP.md', 'INDEPENDENT_REVIEW.md', 'NAVIGATION_AUDIT.md',
            'REPRODUCTION_AUDIT.md', 'coordination-handoffs.json', 'followup-queue.json',
            'remote-publication.json']
assert sorted(final_delta) == sorted([['A', E + name] for name in followup])
all_delta = [line.split('\t') for line in git('diff', '--name-status', P, H).splitlines()]
assert len(all_delta) == 25
assert sorted(path for status, path in all_delta if status == 'M') == ['proofs/REPORTS.md', 'proofs/SOURCE_MAP.json']
assert all(status == 'A' and (path.startswith(E) or path.startswith(ARCHIVE))
           for status, path in all_delta if status != 'M')
head_headers = git('cat-file', '-p', H).split('\n\n', 1)[0].splitlines()
first_headers = git('cat-file', '-p', H1).split('\n\n', 1)[0].splitlines()
assert [x for x in head_headers if x.startswith('parent ')] == ['parent ' + H1]
assert [x for x in first_headers if x.startswith('parent ')] == ['parent ' + P]
assert head_headers[0] == 'tree 52cb6e5a7f7ff914316cccf65ce3aaac675c3893'
assert first_headers[0] == 'tree ebf6478926ccffbf5557acd99d8d884edfe56f4b'

originals = tree(P, ['proofs/REPORTS.md', 'proofs/SOURCE_MAP.json', 'proofs/replay_original_layout.py'])
snapshot = tree('10a173cb635fa8d03e357f454232816fc3e77609', ['proofs/REPORTS.md', 'proofs/SOURCE_MAP.json', 'proofs/replay_original_layout.py'])
assert originals == snapshot
for name in ['REPORTS.md', 'SOURCE_MAP.json']:
    assert scope[ARCHIVE + name] == originals['proofs/' + name]
assert scope['proofs/replay_original_layout.py'] == originals['proofs/replay_original_layout.py']

first, second = data['reviews']
assert first['id'] == 5555042253 and first['commit_id'] == H1 and first['state'] == 'COMMENTED'
assert second['id'] == 5555078732 and second['commit_id'] == H and second['state'] == 'COMMENTED'
report = files[E + 'INDEPENDENT_REVIEW.md']['content']
assert first['body'].split('\n\n', 1)[1] == report
assert hashlib.sha256(report.encode()).hexdigest() == '5b8c05c4d92653dbe3be126deb80b1820c8afb8da50224bb45f977a0ce72613d'
for review in data['reviews']:
    assert 'genuine nonauthor' in review['body']
    assert 'same service account' in review['body']
    assert 'PASS_NARROW_DOCUMENTATION_REVIEW' in review['body']
for name in followup:
    assert name in second['body'] and files[E + name]['sha'] in second['body']

before = extras['3e13b819c649f2aee759ee2db9458c5dc4303759']
after = extras['61911f5cf90510560e6d8eea870be2ca9a126b4f']
start = after.index('<!-- AGENT63 HISTORICAL LINK REPAIR 20261016 -->')
end = after.index('<!-- END AGENT63 HISTORICAL LINK REPAIR -->', start) + len('<!-- END AGENT63 HISTORICAL LINK REPAIR -->')
assert after[end:end+2] == '\n\n'
without_note = after[:start] + after[end+2:]
link = re.compile(r'\]\(([^)]+)\)')
prefix = 'https://github.com/taco-jpg/p196-algorithm/blob/' + BASELINE + '/proofs/'
reconstructed = link.sub(lambda m: '](' + (m[1][len(prefix):] if m[1].startswith(prefix) else m[1]) + ')', without_note)
assert reconstructed == before
prior_links = link.findall(before)
next_links = link.findall(without_note)
targets = json.loads(files[E + 'link-targets.json']['content'])
assert len(prior_links) == len(set(prior_links)) == len(next_links) == len(targets) == 356
assert sum(a != b for a, b in zip(prior_links, next_links)) == 355
assert next_links[0] == prior_links[0] == 'CONSOLIDATION.md'
for old, new, row in zip(prior_links, next_links, targets):
    assert row['original_target'] == old and row['new_target'] == new
    assert row['baseline_path'] == 'proofs/' + old
    assert row['preserved_path'] == 'proofs/archive/source-trees/' + BASELINE + '/proofs/' + old
    assert row['mode'] == '100644'
    assert re.fullmatch('[0-9a-f]{40}', row['git_blob'])
    assert re.fullmatch('[0-9a-f]{64}', row['sha256_from_source_map'])
    assert type(row['bytes']) is int and row['bytes'] > 0
    assert new == (old if old == 'CONSOLIDATION.md' else prefix + old)

validation = json.loads(files[E + 'validation.json']['content'])
fixtures = json.loads(files[E + 'wrapper-fixtures.json']['content'])
assert validation['status'] == 'PASS' and validation['publication_base'] == P
assert validation['original_relative_links'] == 356 and validation['changed_destinations'] == 355
assert validation['changed_mapping_entries'] == ['proofs/REPORTS.md']
assert [f['actual_returncode'] for f in fixtures] == [0, 2, 0, 2]
for fixture, summary in zip(fixtures, validation['synthetic_wrapper_cases']):
    assert all(fixture[k] == value for k, value in summary.items())
    assert fixture['scope'] == 'SYNTHETIC_WRAPPER_FIXTURE'
    assert fixture['expected_returncode'] == fixture['actual_returncode']
    assert fixture['wrapper_git_blob'] == '4745990a5477a4b6a5c537b368bf78d214ce2622'
    assert all(setup['returncode'] == 0 for setup in fixture['setup_commands'])
    stdout = files[E + fixture['stdout_path']]['content']
    stderr = files[E + fixture['stderr_path']]['content']
    marker = 'REQUESTED_CHECK_RAN_WITH_ORIGINAL_REPORT_BYTES'
    assert (marker in stdout) == fixture['requested_check_ran'] == (fixture['actual_returncode'] == 0)
    if fixture['actual_returncode'] == 2:
        assert stdout == ''
        assert 'Source changed; results for an old hash cannot be applied' in stderr

publication = json.loads(files[E + 'remote-publication.json']['content'])
first_delta = [line.split('\t') for line in git('diff', '--name-status', P, H1).splitlines()]
assert len(first_delta) == len(publication['paths']) == 18
assert {row['path'] for row in publication['paths']} == {row[1] for row in first_delta}
for row in publication['paths']:
    assert scope[row['path']]['sha'] == row['remote_blob']
    assert scope[row['path']]['mode'] == row['mode']
queue = json.loads(files[E + 'followup-queue.json']['content'])
assert len(queue['obligations']) == 6
followup_links = [x for x in link.findall(files[E + 'FOLLOWUP.md']['content']) if '://' not in x]
assert len(followup_links) == 7
assert all(posixpath.normpath(E + target) in files for target in followup_links)

output = {
    'status': 'PASS_REVIEW_EVIDENCE_REUSABLE', 'source_head': H,
    'source_parent': P, 'first_reviewed_head': H1,
    'reviews': [{k: r[k] for k in ['id', 'url', 'state', 'commit_id', 'submitted_at', 'posted_account']} for r in data['reviews']],
    'changed_paths_from_publication_parent': all_delta,
    'final_evidence_only_followup': final_delta,
    'original_archive_matches_original_blob_and_mode': True,
    'report_exact_reconstruction': True, 'original_targets': len(targets),
    'pinned_replacements': 355, 'exact_review_body_preserved': True,
    'evidence_file_hashes_checked': len(files), 'source_blobs_checked': len(extras),
    'verified_bytes': verified,
    'retained_fixture_exits_consistent': [0, 2, 0, 2],
    'source_validator_execution_this_review': 'NOT_RUN',
    'synthetic_wrapper_execution_this_review': 'NOT_RUN',
    'lean_execution': 'NOT_RUN_NOT_APPLICABLE_TO_THIS_DOCUMENTATION_REUSE_REVIEW',
    'combined_tree_and_platform_checks': 'DELEGATED_TO_PARENT_NOT_CERTIFIED_HERE',
    'commands': commands,
}
(ROOT / 'check-result.json').write_text(json.dumps(output, indent=2) + '\n')
print(json.dumps({key: output[key] for key in ['status', 'source_head', 'original_targets', 'pinned_replacements', 'evidence_file_hashes_checked', 'source_blobs_checked', 'retained_fixture_exits_consistent']}, indent=2))
