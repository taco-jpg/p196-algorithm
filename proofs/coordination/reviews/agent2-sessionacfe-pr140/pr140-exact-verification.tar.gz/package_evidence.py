#!/usr/bin/env python3
"""Create a deterministic, completely verified publication bundle."""
from pathlib import Path
import base64
import gzip
import hashlib
import io
import json
import tarfile

root = Path(__file__).resolve().parent
destination = root / 'publication'
destination.mkdir(exist_ok=False)
required = ['README.md', 'AUDIT_DESIGN_REVIEW.md', 'EXECUTED_EVIDENCE_REVIEW.md',
            'run_exact_verification.py', 'check_source_tree_binding.py',
            'source-tree-binding.json', 'optimization-guard-check.json',
            'package_evidence.py']
paths = [root / name for name in required]
for directory in ['source', 'preparation-001', 'run-001']:
    paths += [p for p in (root / directory).rglob('*')
              if p.is_file() and p.suffix not in {'.olean', '.pyc'}]
paths = sorted(set(paths))
for path in paths:
    assert path.is_file() and not path.is_symlink()
members = {str(p.relative_to(root)): p.read_bytes() for p in paths}
manifest = {
    'source_head': '1c1bff874c915d90d2820090e028b40002145375',
    'evidence_owner': 'Agent #2/sessionacfe54025bfc',
    'format': 'tar+gzip',
    'exclusions': ['Compiled .olean files', 'Python .pyc caches', 'Installed compiler/runtime'],
    'exclusion_reason': 'Regenerable infrastructure; all sources, scripts and substantive logs retained.',
    'files': {n: {'bytes': len(b), 'sha256': hashlib.sha256(b).hexdigest()}
              for n, b in members.items()},
}
raw = io.BytesIO()
with tarfile.open(fileobj=raw, mode='w') as tar:
    for name, body in members.items():
        info = tarfile.TarInfo(name)
        info.size = len(body)
        info.mtime = 0
        info.mode = 0o644
        info.uid = info.gid = 0
        tar.addfile(info, io.BytesIO(body))
archive = gzip.compress(raw.getvalue(), compresslevel=9, mtime=0)
with tarfile.open(fileobj=io.BytesIO(archive), mode='r:gz') as tar:
    extracted = {}
    for info in tar.getmembers():
        assert info.isfile() and info.name in members
        extracted[info.name] = tar.extractfile(info).read()
    assert extracted == members
name = 'pr140-exact-verification.tar.gz'
(destination / name).write_bytes(archive)
manifest.update({'archive': name, 'archive_bytes': len(archive),
                 'archive_sha256': hashlib.sha256(archive).hexdigest(),
                 'archive_git_blob': hashlib.sha1(f'blob {len(archive)}\0'.encode() + archive).hexdigest(),
                 'member_count': len(members),
                 'uncompressed_file_bytes': sum(map(len, members.values())),
                 'all_members_reopened_and_verified': True})
(destination / 'MANIFEST.json').write_text(json.dumps(manifest, indent=2) + '\n')
(destination / 'archive.base64').write_text(base64.b64encode(archive).decode())
for name in ['README.md', 'AUDIT_DESIGN_REVIEW.md', 'EXECUTED_EVIDENCE_REVIEW.md',
             'run_exact_verification.py', 'source-tree-binding.json']:
    (destination / name).write_bytes((root / name).read_bytes())
(destination / 'verification.json').write_bytes((root / 'run-001/verification.json').read_bytes())
print(json.dumps({k: manifest[k] for k in ['archive_bytes', 'archive_sha256',
      'archive_git_blob', 'member_count', 'uncompressed_file_bytes',
      'all_members_reopened_and_verified']}, indent=2))
