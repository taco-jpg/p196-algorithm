#!/usr/bin/env python3
"""Bind the retrieved verification inputs to exact H/B Git tree entries.

Uses another session's existing object database read-only, with lazy fetching
and optional Git writes disabled. It never mutates that object database.
"""
import hashlib
import json
from pathlib import Path
import subprocess

root = Path(__file__).resolve().parent
source = root / 'source'
head = '1c1bff874c915d90d2820090e028b40002145375'
base = '74a1c3922eb7af438fe40b23d2105ad07556e3f5'
database = '/workspace/scratch/7efd48098de6/agent1-repo/.git'
registry = json.loads((source / 'proofs/Agent102ParameterSets.registry.json').read_text())
modules = registry['projects']['agent102-affine-parameter-intervals']['modules']
paths = sorted(str(p.relative_to(source)) for p in source.rglob('*') if p.is_file() and p.suffix != '.pyc')
env = {'PATH': '/usr/local/bin:/usr/bin:/bin', 'GIT_NO_LAZY_FETCH': '1',
       'GIT_CONFIG_NOSYSTEM': '1', 'GIT_CONFIG_GLOBAL': '/dev/null'}
report = {'source_head': head, 'observed_base': base, 'git_database_read_only': database,
          'commands': [], 'files': {}, 'base_modules': {}, 'status': 'RUNNING'}
for ref in [head, base]:
    argv = ['git', '--no-optional-locks', '--git-dir=' + database,
            '-c', 'core.fsmonitor=false', 'ls-tree', '-r', '-z', ref, '--'] + paths
    result = subprocess.run(argv, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    report['commands'].append({'argv': argv, 'environment': env,
                              'exit_code': result.returncode, 'stderr': result.stderr.decode()})
    if result.returncode:
        raise RuntimeError(result.stderr.decode())
    entries = {}
    for row in result.stdout.split(b'\0'):
        if not row:
            continue
        metadata, path = row.split(b'\t', 1)
        mode, kind, sha = metadata.decode().split()
        entries[path.decode()] = {'mode': mode, 'type': kind, 'git_blob': sha}
    if ref == head:
        assert set(entries) == set(paths)
        for path, entry in entries.items():
            body = (source / path).read_bytes()
            actual = hashlib.sha1(f'blob {len(body)}\0'.encode() + body).hexdigest()
            assert entry['mode'] == '100644' and entry['type'] == 'blob'
            assert actual == entry['git_blob'], path
            report['files'][path] = {**entry, 'bytes': len(body),
                                    'sha256': hashlib.sha256(body).hexdigest(), 'matches_head': True}
    else:
        for name, record in modules.items():
            entry = entries.get(record['path'])
            if entry:
                assert entry['git_blob'] == record['git_blob'], name
                report['base_modules'][name] = 'PRESENT_IDENTICAL'
            else:
                report['base_modules'][name] = 'ABSENT_ADDITIVE_INPUT'
report['status'] = 'PASS'
report['scope'] = 'Exact selected-source Git tree binding and thirteen-module base compatibility; not a full combined-tree construction.'
output = root / 'source-tree-binding.json'
if output.exists():
    raise FileExistsError(output)
output.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'status': report['status'], 'head_bound_files': len(report['files']),
                  'base_modules': report['base_modules']}, indent=2))
