#!/usr/bin/env python3
"""Validate exact-head evidence inventories without altering historical files."""
import pathlib,json,hashlib,re,subprocess
root=pathlib.Path(__file__).resolve().parent
pkg=root/'exact-head-package'
sha=lambda b:hashlib.sha256(b).hexdigest()
results=[]
def check(label,base,records):
 count=0;total=0
 for rel,row in records.items():
  path=pathlib.PurePosixPath(rel)
  assert not path.is_absolute() and '..' not in path.parts
  data=(base/rel).read_bytes();assert len(data)==row['bytes'] and sha(data)==row['sha256'],(label,rel)
  if 'git_blob' in row:assert hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest()==row['git_blob'],(label,rel)
  count+=1;total+=len(data)
 results.append({'manifest':label,'verified_files':count,'verified_bytes':total})
m=json.loads((pkg/'development/controls/MANIFEST.json').read_text());check('development/controls/MANIFEST.json',pkg/'development/controls',{r['path']:r for r in m})
for name in ['FILES.json','REPLAY_FILES.json']:
 p=pkg/'verification/canonical-published-937c33b'/name;check(str(p.relative_to(pkg)),p.parent,json.loads(p.read_text()))
p=pkg/'verification/independent/COPY_MANIFEST.json';m=json.loads(p.read_text());check(str(p.relative_to(pkg)),p.parent,{r['relative_path']:r for r in m['entries']});assert len(m['entries'])==m['selected_file_count']==140;assert sum(r['bytes'] for r in m['entries'])==m['selected_file_bytes'];assert len(m['excluded'])==m['excluded_compiled_file_count']==37
for row in m['excluded']:
 assert pathlib.PurePosixPath(row['relative_path']).suffix in {'.olean','.ilean','.o','.so','.a'}
registry=json.loads((pkg/'certificate.registry.json').read_text());modules=registry['projects']['agent6-certificate-coordinate-audit']['modules'];snapshots=[]
for p in pkg.rglob('*.lean'):
 if p.stem in modules:
  data=p.read_bytes();rec=modules[p.stem];assert sha(data)==rec['sha256'],str(p)
  snapshots.append({'path':str(p.relative_to(pkg)),'module':p.stem,'sha256':sha(data)})
identity=json.loads((root/'SOURCE_IDENTITY.json').read_text())
assert len(identity['modules'])==20
for n,rec in modules.items():assert rec['sha256']==identity['modules'][n]['sha256'] and rec['git_blob']==identity['modules'][n]['git_blob']
prior=json.loads((pkg/'verification/independent/final/build/compilation.json').read_text());assert len(prior['objects'])==20
for command in prior['commands']:
 assert command['exit_code']==0
 if command['label'] in modules:assert all(f in command['argv'] for f in ['--trust=0','-j1','-DElab.async=false'])
current=json.loads((root/'EXACT_HEAD_PACKAGE_INVENTORY.json').read_text());assert current['status']=='PASS' and len(current['files'])==234 and not current['errors']
result={'status':'PASS','head':current['exact_head'],'package_files':234,'package_payload_bytes':current['payload_bytes'],'manifests':results,'subordinate_entry_checks':sum(r['verified_files'] for r in results),'unchanged_selected_mathematical_snapshots':snapshots,'historical_compiled_objects_explicitly_excluded':37,'historical_compiled_object_hashes':m['excluded'],'original_prior_strict_twenty_module_run_flags_verified':True,'prior_results_not_reused_for_new_gate':True,'prior_receipt_correction_scope':'Earlier Agent116 broader 1991-theorem receipt parser; retained as attributed historical correction, not freshly replayed by this review.'}
(root/'EVIDENCE_AUDIT.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['unchanged_selected_mathematical_snapshots','historical_compiled_object_hashes']},indent=2))
