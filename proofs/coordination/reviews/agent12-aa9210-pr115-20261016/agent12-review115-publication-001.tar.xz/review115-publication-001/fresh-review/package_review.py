#!/usr/bin/env python3
"""Package all substantive review evidence, with explicit object exclusions."""
import pathlib,json,hashlib,tarfile
root=pathlib.Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
retained={};omitted={}
for p in sorted(root.rglob('*')):
 if not p.is_file() or p.name=='DELIVERY_MANIFEST.json':continue
 assert not p.is_symlink()
 rel=str(p.relative_to(root));data=p.read_bytes();row={'bytes':len(data),'sha256':sha(data)}
 if p.suffix in {'.olean','.ilean','.o'} or '__pycache__' in p.parts:omitted[rel]={**row,'reason':'Reproducible compiler output; exact source, command, log, and original object inventory retained.'}
 else:retained[rel]=row
assert len(omitted)==20
manifest={'status':'COMPLETE_SUBSTANTIVE_REVIEW_EVIDENCE','exact_head':'dca30e76474569a276c2e58bbd6ee0b96c554ecc','files':retained,'file_count':len(retained),'payload_bytes':sum(r['bytes'] for r in retained.values()),'omitted_reproducible_objects':omitted,'exclusion_policy':'Only twenty freshly generated .olean files omitted. All source/evidence, actual commands, raw logs, prior evidence, source snapshots, and genuine review incidents retained.'}
(root/'DELIVERY_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
archive=root.parent/'agent12-review115-evidence.tar.xz'
with tarfile.open(archive,'w:xz') as tf:
 for rel in list(retained)+['DELIVERY_MANIFEST.json']:tf.add(root/rel,arcname=rel,recursive=False)
with tarfile.open(archive,'r:xz') as tf:
 members=tf.getmembers();assert len(members)==len(retained)+1;seen=set()
 for member in members:
  assert member.isfile() and member.name not in seen and not pathlib.PurePosixPath(member.name).is_absolute() and '..' not in pathlib.PurePosixPath(member.name).parts
  seen.add(member.name);data=tf.extractfile(member).read()
  if member.name in retained:assert len(data)==retained[member.name]['bytes'] and sha(data)==retained[member.name]['sha256']
  else:assert member.name=='DELIVERY_MANIFEST.json' and data==(root/member.name).read_bytes()
summary={'status':'PASS','archive':str(archive),'archive_bytes':archive.stat().st_size,'archive_sha256':sha(archive.read_bytes()),'retained_files_including_manifest':len(retained)+1,'retained_payload_bytes_excluding_manifest':manifest['payload_bytes'],'omitted_compiled_objects':len(omitted),'roundtrip':'PASS_ALL_FILE_BYTES_AND_HASHES','manifest':str(root/'DELIVERY_MANIFEST.json'),'manifest_sha256':sha((root/'DELIVERY_MANIFEST.json').read_bytes()),'receipt':str(root/'RECEIPT.json'),'receipt_sha256':sha((root/'RECEIPT.json').read_bytes()),'semantic_review':str(root/'SEMANTIC_REVIEW.md'),'semantic_review_sha256':sha((root/'SEMANTIC_REVIEW.md').read_bytes())}
(root.parent/'agent12-review115-delivery.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))
