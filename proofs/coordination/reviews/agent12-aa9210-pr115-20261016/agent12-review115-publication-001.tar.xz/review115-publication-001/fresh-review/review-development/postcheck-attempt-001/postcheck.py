#!/usr/bin/env python3
"""Independent exact-head receipt and complete-audit cross-check."""
import pathlib,json,hashlib,subprocess,re
r=pathlib.Path(__file__).resolve().parent;p=r/'exact-head-package';f=r/'fresh-full-001';repo=pathlib.Path('/workspace/scratch/aa9210d02a75/agent12-pr115');rel='proofs/contributions/agent-6/certificate-coordinate-audit-20261016/'
sha=lambda b:hashlib.sha256(b).hexdigest()
c=json.loads((f/'build/compilation.json').read_text());a=json.loads((f/'audit/verification.json').read_text());identity=json.loads((r/'SOURCE_IDENTITY.json').read_text());registry=json.loads((p/'certificate.registry.json').read_text());modules=registry['projects']['agent6-certificate-coordinate-audit']['modules'];deps=json.loads((p/'DEPENDENCIES.json').read_text())
assert c['status']=='COMPILED_PENDING_INDEPENDENT_AXIOM_AUDIT' and a['status']=='PASS'
assert c['source_unchanged_before_after'] and c['compiler_unchanged_before_after'] and a['source_objects_compiler_unchanged_before_after']
assert c['fresh_project_objects'] and not c['reused_dependency_objects'] and len(c['objects'])==20
commands=c['commands']+a['commands']
for row in commands:
 assert row['exit_code']==0
 if row['label'] in modules or row['label'] in ['ExplicitExports','ModuleAudit']:
  assert all(flag in row['argv'] for flag in ['--trust=0','-j1','-DElab.async=false'])
new_public=[n for claim in registry['claims'] for n in claim['endpoints']]
assert len(new_public)==len(set(new_public))==29
explicit=json.loads((f/'audit/explicit-axioms.json').read_text());full=json.loads((f/'audit/full-module-axioms.json').read_text());names={row['name'] for row in full}
assert len(explicit)==383 and len(names)==len(full)==979
assert set(new_public)<=names and set(new_public)<=set(explicit)
assert a['explicit_public_theorem_count']==276 and a['new_public_theorem_exports']==29
assert a['all_theorem_constants_audited']==713 and a['safe_definitions_axiom_audited']==266 and a['safe_opaque_constants_audited']==0
assert len(a['theorem_constant_counts_by_module'])==20 and all(v>0 for v in a['theorem_constant_counts_by_module'].values())
assert a['axiom_union']==['Classical.choice','Quot.sound','propext'] and a['multiline_print_parser_agrees_with_structured_lean_records']
assert len(a['unsafe_implementation_axioms'])==11 and a['unsafe_implementation_definition_count']==455
metadata={}
for filename in ['certificate.registry.json','DEPENDENCIES.json']:
 data=(p/filename).read_bytes();blob=hashlib.sha1(f'blob {len(data)}\0'.encode()+data).hexdigest();refs={}
 for commit in [identity['exact_head'],identity['source_freeze']]:
  b=subprocess.check_output(['git','rev-parse',commit+':'+rel+filename],cwd=repo,text=True).strip();assert b==blob;refs[commit]=b
 metadata[filename]={'git_blob':blob,'sha256':sha(data),'commit_matches':refs}
assert metadata['certificate.registry.json']['sha256']==deps['registry']['sha256']
status=subprocess.check_output(['git','diff','--name-status','fa3921e58556250b1a6efd30af603fb65a9d9fbc',identity['exact_head'],'--',rel],cwd=repo,text=True);(r/'complete-package-diff-name-status.txt').write_text(status);assert len(status.splitlines())==234 and all(line.startswith('A\t'+rel) for line in status.splitlines())
with (r/'complete-package-additions.diff').open('wb') as out:
 for line in status.splitlines():
  path=line.split('\t',1)[1];data=subprocess.run(['git','diff','--no-index','--','/dev/null',str(p/path.removeprefix(rel))],stdout=subprocess.PIPE,check=False);assert data.returncode==1;out.write(data.stdout)
result={'status':'PASS','exact_head':identity['exact_head'],'module_count':20,'theorems':713,'safe_definitions':266,'safe_opaque':0,'full_constant_census':1470,'closure_public_theorem_exports':276,'explicit_named_declarations':383,'new_public_theorem_exports':29,'literal_new_export_axioms':{n:explicit[n] for n in new_public},'metadata_identity':metadata,'source_closure':identity['modules'],'new_module_safe_definitions':sum(a['safe_definition_counts_by_module'][n] for n in a['new_modules']),'new_module_theorem_constants':sum(a['theorem_constant_counts_by_module'][n] for n in a['new_modules']),'strict_command_count':sum(row['label'] in modules or row['label'] in ['ExplicitExports','ModuleAudit'] for row in commands),'all_commands_exit_zero':True,'package_added_file_count':234,'allowed_axioms':a['axiom_union'],'original_replay_preserved_sha256':sha((p/'replay.py').read_bytes()),'separate_new_strict_drivers':['compile_strict.py','audit_strict.py'],'fresh_compilation_sha256':sha((f/'build/compilation.json').read_bytes()),'fresh_audit_receipt_sha256':sha((f/'audit/verification.json').read_bytes()),'fresh_full_audit_log_sha256':sha((f/'audit/logs/ModuleAudit.log').read_bytes()),'fresh_named_audit_log_sha256':sha((f/'audit/logs/ExplicitExports.log').read_bytes())}
(r/'POSTCHECK.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['literal_new_export_axioms','metadata_identity','source_closure']},indent=2))
