#!/usr/bin/env python3
"""Read-only public Git postmerge audit of PR115; no ref/source/remote writes."""
from pathlib import Path
from datetime import datetime,timezone
import json,hashlib,subprocess,os,traceback
ROOT=Path(__file__).resolve().parent
REVIEW=ROOT.parent.parent/'review115'
REPO='/workspace/scratch/aa9210d02a75/p196-agent12'
ENV=os.environ.copy();ENV.update(GIT_OBJECT_DIRECTORY='/dev/shm/p196-agent12-aa9210d02a75/git-objects',GIT_ALTERNATE_OBJECT_DIRECTORIES=REPO+'/.git/objects',GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1',GIT_TERMINAL_PROMPT='0')
H='dca30e76474569a276c2e58bbd6ee0b96c554ecc';M='44dba3a08c46f90a2e9d60a96289466c6cf006cc';B='d00135526e27396fda95cdb00e809737b301cdbc'
PREFIX='proofs/contributions/agent-6/certificate-coordinate-audit-20261016/'
CMDS=[]
def sha(d):return hashlib.sha256(d).hexdigest()
def blob(d):return hashlib.sha1(b'blob '+str(len(d)).encode()+b'\0'+d).hexdigest()
def dump(n,x):(ROOT/n).write_text(json.dumps(x,indent=2)+'\n')
def git(label,*args,allowed=(0,)):
 cmd=['git','-c','maintenance.auto=false','-c','gc.auto=0','-C',REPO,*args]
 r=subprocess.run(cmd,env=ENV,capture_output=True);n=f'{len(CMDS):03d}-{label}';(ROOT/'logs'/f'{n}.stdout').write_bytes(r.stdout);(ROOT/'logs'/f'{n}.stderr').write_bytes(r.stderr)
 CMDS.append({'label':label,'argv':cmd,'exit_code':r.returncode,'stdout':f'logs/{n}.stdout','stderr':f'logs/{n}.stderr','stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)})
 dump('commands.json',CMDS)
 assert r.returncode in allowed,(label,r.returncode,r.stderr.decode(errors='replace'))
 return r

def tree(label,ref):
 t={}
 for row in git(label,'ls-tree','-r','-z',ref).stdout.split(b'\0'):
  if row:
   info,p=row.split(b'\t',1);mode,kind,oid=info.decode().split();t[p.decode()]={'mode':mode,'type':kind,'git_blob':oid}
 return t

def main():
 (ROOT/'logs').mkdir(exist_ok=False)
 pr=json.loads((ROOT/'api/pr115.json').read_text());mj=json.loads((ROOT/'api/merge-commit.json').read_text());cj=json.loads((ROOT/'api/current-main-commit.json').read_text());ref=json.loads((ROOT/'api/current-main-ref.json').read_text());C=ref['object']['sha']
 assert pr['merged'] and pr['state']=='closed' and pr['head']['sha']==H and pr['merge_commit_sha']==M
 assert pr['merged_at']=='2026-10-16T23:10:43Z' and mj['sha']==M and cj['sha']==C
 parents=[x['sha'] for x in mj['parents']];assert len(parents)==2 and parents[1]==H;P=parents[0]
 # Fetch by immutable SHA, only if missing; --no-write-fetch-head avoids ref files.
 present=git('current-main-object-presence','cat-file','-e',C+'^{commit}',allowed=(0,1,128))
 if present.returncode:
  git('public-exact-current-main-fetch','fetch','--filter=blob:none','--no-tags','--no-write-fetch-head','https://github.com/taco-jpg/p196-algorithm.git',C)
 raw=git('actual-merge-commit','cat-file','commit',M).stdout
 actualparents=[x[7:].decode() for x in raw.split(b'\n') if x.startswith(b'parent ')]
 actualtree=raw.split(b'\n',1)[0].decode().split()[1]
 assert actualparents==parents and actualtree==mj['tree']['sha']
 currenttree=git('current-root-tree','rev-parse',C+'^{tree}').stdout.decode().strip();assert currenttree==cj['tree']['sha']
 for label,a,z in [('actual-merge-in-current',M,C),('source-head-in-current',H,C),('fixed-base-in-current',B,C)]:git(label,'merge-base','--is-ancestor',a,z)
 actualcombination=git('recompute-actual-merge-tree','merge-tree','--write-tree',P,H).stdout.decode().splitlines()[0];assert actualcombination==actualtree
 ts={name:tree(name+'-tree',ref) for name,ref in [('first_parent',P),('head',H),('merge',M),('current_main',C)]}
 pt,ht,mt,ct=[ts[x] for x in ['first_parent','head','merge','current_main']]
 dump('COMPLETE_TREE_INVENTORIES.json',ts)
 changed=[p for p in pt if pt[p]!=mt.get(p)];assert not changed,changed
 added=sorted(set(mt)-set(pt));pkg=sorted(p for p in ht if p.startswith(PREFIX));assert set(added)==set(pkg) and len(pkg)==234
 assert all(ht[p]==mt[p]==ct[p] for p in pkg)
 package_items=json.loads((REVIEW/'EXACT_HEAD_PACKAGE_INVENTORY.json').read_text())['files'];assert {x['repository_path'] for x in package_items}==set(pkg)
 package_bindings=[]
 for x in package_items:
  data=(REVIEW/'exact-head-package'/x['path']).read_bytes();p=x['repository_path']
  assert len(data)==x['bytes'] and sha(data)==x['sha256'] and blob(data)==ht[p]['git_blob']
  package_bindings.append({**x,'merge_entry':mt[p],'current_main_entry':ct[p]})
 dump('PACKAGE_BINDINGS.json',package_bindings)
 receipt=json.loads((REVIEW/'RECEIPT.json').read_text());bindings=[]
 for module,x in receipt['source_closure'].items():
  p=x['path'];data=(REVIEW/'fresh-full-001/source'/f'{module}.lean').read_bytes()
  assert len(data)==x['bytes'] and sha(data)==x['sha256'] and blob(data)==x['git_blob']
  assert ht[p]==mt[p]==ct[p] and ht[p]['git_blob']==x['git_blob']
  if not p.startswith(PREFIX):assert pt[p]==ht[p]
  bindings.append({'module':module,**x,'first_parent_entry':pt.get(p),'head_entry':ht[p],'merge_entry':mt[p],'current_main_entry':ct[p],'fresh_compiled_snapshot':'fresh-full-001/source/'+module+'.lean'})
 assert len(bindings)==20;dump('SOURCE_BINDINGS.json',bindings)
 vp='proofs/verify_project__214bf7673efe116b.py';v=(REVIEW/'pinned-parser/verify_project__214bf7673efe116b.py').read_bytes();assert pt[vp]==ht[vp]==mt[vp]==ct[vp] and blob(v)==ht[vp]['git_blob']
 meta=[]
 for n in ['certificate.registry.json','DEPENDENCIES.json','PUBLICATION.json','replay.py']:
  p=PREFIX+n;data=(REVIEW/'exact-head-package'/n).read_bytes();assert blob(data)==ht[p]['git_blob'] and ht[p]==mt[p]==ct[p]
  meta.append({'path':p,'bytes':len(data),'sha256':sha(data),'head_entry':ht[p],'merge_entry':mt[p],'current_main_entry':ct[p]})
 meta.append({'path':vp,'bytes':len(v),'sha256':sha(v),'head_entry':ht[vp],'merge_entry':mt[vp],'current_main_entry':ct[vp]});dump('VERIFIER_METADATA_BINDINGS.json',meta)
 dump('ACTUAL_MERGE_ADDITIONS.json',added)
 record={'schema_version':1,'status':'PASS_POSTMERGE_INDEPENDENT_SOURCE_EVIDENCE_BINDING','checked_utc':datetime.now(timezone.utc).isoformat(),'repository':'taco-jpg/p196-algorithm','pull_request':115,'exact_head':H,'actual_merge_commit':M,'actual_merge_ordered_parents':parents,'actual_merge_tree':actualtree,'recomputed_first_parent_plus_head_tree':actualcombination,'merged_at':pr['merged_at'],'api_pr_state':pr['state'],'api_merged':pr['merged'],'api_merged_by':pr['merged_by']['login'],'merge_attribution':'Already merged by another workflow before this independent fresh review completed. This reviewer and Agent #12 do not claim to have performed this merge.','first_parent_tracked_entries':len(pt),'merge_tracked_entries':len(mt),'actual_merge_effective_additions':len(added),'all_first_parent_entries_preserved':True,'all_actual_additions_owned_and_identical_to_head':True,'observed_current_main':C,'observed_current_main_tree':currenttree,'current_main_tracked_entries':len(ct),'current_main_observed_at':json.loads((ROOT/'api/current-main-ref.tool-result.json').read_text())['at'],'merge_ancestor_of_observed_current_main':True,'head_ancestor_of_observed_current_main':True,'fixed_combination_base':B,'fixed_base_ancestor_of_observed_current_main':True,'package_files_bound_at_head_merge_current_main':234,'fresh_compiled_source_closure_bound_at_head_merge_current_main':20,'registry_original_replay_and_verifier_bound':True,'new_lean_run_in_postmerge_audit':False,'independent_fresh_replay':'The separately sealed review contains a genuine full strict 20-module build and exhaustive audit. Postmerge checks reuse that evidence only through exact source and verifier byte identity.','remote_mutations':False,'source_mutations':False,'git_ref_mutations':False,'publication_uploaded':False,'api_verification_signature':'GitHub signature verification metadata preserved as read; no independent PGP verification is claimed.','helper_sha256':sha(Path(__file__).read_bytes())}
 dump('POSTMERGE_IDENTITY.json',record)
 print(json.dumps(record,indent=2))
if __name__=='__main__':
 try:main()
 except BaseException:
  (ROOT/'failure-traceback.log').write_text(traceback.format_exc());raise
