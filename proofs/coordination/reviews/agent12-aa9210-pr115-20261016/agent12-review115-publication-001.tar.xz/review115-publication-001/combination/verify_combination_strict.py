#!/usr/bin/env python3
"""Independent complete-tree PR115 binding check; no source, ref or remote writes.

Git's merge-tree writes only new immutable objects into the expressly designated
memory-backed object directory. This check does not compile Lean again: it binds
all combined source bytes to the separately sealed fresh strict kernel replay.
"""
from pathlib import Path
import os,sys,json,hashlib,subprocess,traceback
from datetime import datetime,timezone
OUT=Path(__file__).resolve().parent
REVIEW=OUT.parent
REPO=Path('/workspace/scratch/aa9210d02a75/p196-agent12')
B='d00135526e27396fda95cdb00e809737b301cdbc'
H='dca30e76474569a276c2e58bbd6ee0b96c554ecc'
PREFIX='proofs/contributions/agent-6/certificate-coordinate-audit-20261016/'
ARCHIVE=REVIEW.parent/'agent12-review115-evidence.tar.xz'
EXPECTED_ARCHIVE='093b6c5f70442710dcf7ec512a86dfc7787c983039b764d49fd0bf1d32d2c569'
ENV=os.environ.copy()
ENV.update(GIT_OBJECT_DIRECTORY='/dev/shm/p196-agent12-aa9210d02a75/git-objects',GIT_ALTERNATE_OBJECT_DIRECTORIES=str(REPO/'.git/objects'),GIT_OPTIONAL_LOCKS='0',GIT_NO_LAZY_FETCH='1')
COMMANDS=[]
def sha(data): return hashlib.sha256(data).hexdigest()
def blob(data): return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def dump(name,obj): (OUT/name).write_text(json.dumps(obj,indent=2)+'\n')
def git(label,*parts):
    cmd=['git','-C',str(REPO),*parts]
    r=subprocess.run(cmd,env=ENV,capture_output=True)
    name=f'{len(COMMANDS):03d}-{label}'
    (OUT/'logs'/f'{name}.stdout').write_bytes(r.stdout)
    (OUT/'logs'/f'{name}.stderr').write_bytes(r.stderr)
    COMMANDS.append({'argv':cmd,'exit_code':r.returncode,'stdout':f'logs/{name}.stdout','stderr':f'logs/{name}.stderr','stdout_sha256':sha(r.stdout),'stderr_sha256':sha(r.stderr)})
    dump('commands.json',COMMANDS)
    if r.returncode: raise RuntimeError(f'{label}: exit {r.returncode}: {r.stderr.decode(errors="replace")}')
    return r.stdout

def tree(label,ref):
    t={}
    for row in git(label,'ls-tree','-r','-z',ref).split(b'\0'):
        if not row: continue
        info,path=row.split(b'\t',1);mode,kind,oid=info.decode().split();p=path.decode()
        assert p not in t
        t[p]={'mode':mode,'type':kind,'git_blob':oid}
    return t

def main():
    assert sha(ARCHIVE.read_bytes())==EXPECTED_ARCHIVE
    receipt=json.loads((REVIEW/'RECEIPT.json').read_text())
    assert receipt['exact_head']==H
    A=git('merge-base','merge-base',B,H).decode().strip()
    T=git('merge-tree','merge-tree','--write-tree',B,H).decode().splitlines()[0]
    BT=git('base-root-tree','rev-parse',B+'^{tree}').decode().strip()
    ts={k:tree(k+'-tree',v) for k,v in [('base',B),('head',H),('ancestor',A),('combined',T)]}
    bt,ht,at,ct=(ts[x] for x in ['base','head','ancestor','combined'])
    dump('COMPLETE_TREE_INVENTORIES.json',ts)
    removed=sorted(set(bt)-set(ct))
    changed=sorted(p for p in set(bt)&set(ct) if bt[p]!=ct[p])
    effective=sorted(p for p in set(bt)|set(ct) if bt.get(p)!=ct.get(p))
    submitted=sorted(p for p in set(at)|set(ht) if at.get(p)!=ht.get(p))
    package_paths=sorted(p for p in ht if p.startswith(PREFIX))
    package_mismatch=sorted(p for p in package_paths if ht[p]!=ct.get(p))
    unexpected=sorted(p for p in effective if not p.startswith(PREFIX))
    undeclared=sorted(p for p in ct if p not in bt and p not in ht)
    inherited_submitted=[p for p in submitted if not p.startswith(PREFIX)]
    inherited_mismatch=[p for p in inherited_submitted if not(ht.get(p)==bt.get(p)==ct.get(p))]
    assert not removed and not changed,(removed,changed)
    assert not unexpected and not undeclared,(unexpected,undeclared)
    assert not package_mismatch,package_mismatch
    assert not inherited_mismatch,inherited_mismatch
    assert set(effective)==set(package_paths)-set(bt)
    assert len(package_paths)==234
    dump('effective-paths.json',effective)
    dump('submitted-paths.json',submitted)
    dump('already-integrated-submitted-outside-package.json',inherited_submitted)
    # No unexamined blob fetching is required: recompute Git's content-addressed
    # blob identity directly from each exact snapshot and require matching mode,
    # kind and identity in every relevant tree; also retain SHA256 and full bytes.
    pkg=json.loads((REVIEW/'EXACT_HEAD_PACKAGE_INVENTORY.json').read_text())
    assert pkg['status']=='PASS' and {x['repository_path'] for x in pkg['files']}==set(package_paths)
    pkg_bind=[]
    for item in pkg['files']:
        p=item['repository_path'];data=(REVIEW/'exact-head-package'/item['path']).read_bytes()
        assert len(data)==item['bytes'] and sha(data)==item['sha256'] and blob(data)==item['git_blob']==ht[p]['git_blob']==ct[p]['git_blob']
        assert ct[p]['type']=='blob' and ct[p]['mode'] in {'100644','100755'}
        pkg_bind.append(dict(item,base_entry=bt.get(p),head_entry=ht[p],combined_entry=ct[p]))
    dump('PACKAGE_BINDINGS.json',pkg_bind)
    compile_record=json.loads((REVIEW/'fresh-full-001/build/compilation.json').read_text())
    compile_modules={x['module']:x for x in compile_record['modules']}
    bindings=[]
    (OUT/'source-snapshots').mkdir(exist_ok=False)
    assert len(receipt['source_closure'])==len(compile_modules)==20
    for module,item in receipt['source_closure'].items():
        p=item['path'];s=REVIEW/'fresh-full-001/source'/f'{module}.lean';data=s.read_bytes()
        assert ht[p]==ct[p] and ht[p]['type']=='blob'
        assert blob(data)==item['git_blob']==ct[p]['git_blob']
        assert sha(data)==item['sha256']==compile_modules[module]['sha256']==compile_record['source_hashes_before'][module]==compile_record['source_hashes_after'][module]
        assert len(data)==item['bytes']
        if not p.startswith(PREFIX): assert bt[p]==ct[p]
        (OUT/'source-snapshots'/f'{module}.lean').write_bytes(data)
        bindings.append({'module':module,**item,'fresh_compiled_snapshot':str(s),'base_entry':bt.get(p),'head_entry':ht[p],'combined_entry':ct[p],'exact_byte_identity_method':'Recomputed Git blob SHA1 and SHA256 from the fresh compiler input snapshot; tree object identities and modes/types checked.'})
    dump('SOURCE_BINDINGS.json',bindings)
    verifier_path='proofs/verify_project__214bf7673efe116b.py'
    verifier_data=(REVIEW/'pinned-parser/verify_project__214bf7673efe116b.py').read_bytes()
    assert bt[verifier_path]==ht[verifier_path]==ct[verifier_path]
    assert blob(verifier_data)==ct[verifier_path]['git_blob']
    assert sha(verifier_data)==compile_record['source_parser']['sha256']=='c047ff1ff1fe12b2c2094ca5f36af871b1c6faf89db593a102f9c2f7d48cc98a'
    (OUT/'source-snapshots/verify_project__214bf7673efe116b.py').write_bytes(verifier_data)
    metadata=[]
    for name in ['certificate.registry.json','DEPENDENCIES.json','PUBLICATION.json','replay.py']:
        p=PREFIX+name;data=(REVIEW/'exact-head-package'/name).read_bytes()
        assert ht[p]==ct[p] and blob(data)==ct[p]['git_blob']
        (OUT/'source-snapshots'/name).write_bytes(data)
        metadata.append({'path':p,'bytes':len(data),'sha256':sha(data),'head_entry':ht[p],'base_entry':bt.get(p),'combined_entry':ct[p]})
    metadata.append({'path':verifier_path,'bytes':len(verifier_data),'sha256':sha(verifier_data),'head_entry':ht[verifier_path],'base_entry':bt[verifier_path],'combined_entry':ct[verifier_path]})
    dump('VERIFIER_METADATA_BINDINGS.json',metadata)
    evidence_bindings=[]
    for name in ['RECEIPT.json','SEMANTIC_REVIEW.md','compile_strict.py','audit_strict.py','fresh-full-001/build/compilation.json','fresh-full-001/audit/verification.json']:
        data=(REVIEW/name).read_bytes()
        evidence_bindings.append({'sealed_review_path':name,'bytes':len(data),'sha256':sha(data)})
    assert evidence_bindings[0]['sha256']=='f11c4c161da4fd7f6f1640cd0ad5ddbd9bd692de543294a05d438a4a4cd5602e'
    assert evidence_bindings[1]['sha256']=='64e85658e0e4beae978eb13f8d40504d74a3ff649052910c5dff502b5bda1f42'
    for name,key in [('compile_strict.py','strict_compile_driver_sha256'),('audit_strict.py','strict_audit_driver_sha256')]:
        assert sha((REVIEW/name).read_bytes())==receipt[key]
    dump('SEALED_REVIEW_BINDINGS.json',evidence_bindings)
    assert sha(ARCHIVE.read_bytes())==EXPECTED_ARCHIVE
    already=A==H
    if already: assert T==BT and not effective and bt==ct
    result={'schema_version':1,'status':'PASS_ALREADY_CONTAINED_IDENTITY_COMBINATION' if already else 'PASS_ADDITIVE_COMBINATION','checked_utc':datetime.now(timezone.utc).isoformat(),'reviewer':'Agent #12 independent nonauthor reviewer /root/review123','repository':str(REPO),'pull_request':115,'base':B,'head':H,'merge_base':A,'combined_tree':T,'base_tree':BT,'base_entry_count':len(bt),'combined_entry_count':len(ct),'effective_path_count':len(effective),'submitted_since_merge_base_path_count':len(submitted),'owned_package_path_count':len(package_paths),'all_base_entries_unchanged':True,'no_deletions':True,'no_undeclared_additions':True,'owned_package_identical_to_head':True,'new_contribution_count':len(effective),'all_20_sources_equal_fresh_strict_snapshots':True,'inherited_source_count':17,'new_source_count_in_pr':3,'registry_original_replay_and_verifier_equal_sealed_inputs':True,'inherited_pr90_history_not_counted_as_new':True,'sealed_review_archive':str(ARCHIVE),'sealed_review_archive_sha256':EXPECTED_ARCHIVE,'sealed_archive_unchanged':True,'fresh_lean_execution_in_supplement':False,'evidence_reuse':'Exact-byte identity binds the combined closure to the already-completed fresh strict 20-module build and exhaustive audit in the sealed review. No second Lean run is claimed.','source_ref_or_remote_mutations':False,'local_git_object_write':'merge-tree --write-tree only; memory-backed object directory specified in environment','git_environment_overrides':{k:ENV[k] for k in ['GIT_OBJECT_DIRECTORY','GIT_ALTERNATE_OBJECT_DIRECTORIES','GIT_OPTIONAL_LOCKS','GIT_NO_LAZY_FETCH']},'helper_sha256':sha(Path(__file__).read_bytes()),'all_command_exits_zero':all(x['exit_code']==0 for x in COMMANDS),'scope_limitation':'Fixed supplied base only; the integration owner must check the actual final base if it changes.'}
    dump('COMBINATION_RECEIPT.json',result)
    (OUT/'COMBINATION_REVIEW.md').write_text(f'''# PR115 fixed-base combination review\n\n**PASS: already contained, identity combination.**\n\n- Base B: `{B}`\n- Exact source head H: `{H}`\n- Merge base: `{A}` (equal to H)\n- Combined tree T: `{T}` (equal to B's tree)\n\nH is already an ancestor of the supplied B. Both B and T contain {len(bt)} tracked entries. The effective delta is exactly **zero paths**. This supplement records no new contribution and does not misclassify the previously integrated PR90 dependency history.\n\nEvery current-base entry is preserved with the same path, mode, kind and Git object identity. There are no deletions, changes to existing entries, or undeclared additions. All 234 files of the owned package are identical to exact H and to their previously preserved byte snapshots.\n\nAll 20 mathematical source files in T are bound to the exact inputs of the completed fresh strict 20-module compilation, using recomputed Git blob identifiers, SHA256 and sizes. The 17 inherited sources are also unchanged in B. The scoped registry, dependency/publication records, original replay.py, and pinned repository verifier/parser match the original reviewed bytes. Separate strict-driver hashes bind the existing full kernel build and exhaustive audit; this supplement makes no claim to an additional Lean run.\n\nThe original sealed evidence archive remains unchanged at SHA256 `{EXPECTED_ARCHIVE}`. Its PASS review covers 713 theorem constants, 266 safe definitions, zero opaque declarations, 276 closure public theorems, 383 named declarations, 29 new public theorems and all 1,470 origin constants. The original replay's nonexplicit trust setting for canonical compilation remains accurately distinguished from that strict replay.\n\n`SOURCE_BINDINGS.json` lists every module, original repository path, blob, SHA256, fresh compiled snapshot and B/H/T entries. `PACKAGE_BINDINGS.json` covers all 234 package paths. Complete raw Git outputs, full tree inventories, the exact verification helper, metadata snapshots and hash bindings are retained. No source, Git ref or remote mutation was performed. Git wrote only immutable merge-tree objects to the explicitly authorized memory-backed object directory.\n\nThis conclusion applies to the supplied fixed B. The integration owner remains responsible for any later actual-base refresh.\n''')
    print(json.dumps(result,indent=2))

if __name__=='__main__':
    try: main()
    except BaseException:
        (OUT/'failure-traceback.log').write_text(traceback.format_exc())
        raise
