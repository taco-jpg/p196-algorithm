#!/usr/bin/env python3
from pathlib import Path,PurePosixPath
import hashlib,json,tarfile
ROOT=Path(__file__).resolve().parent
DEST=ROOT.parent.parent/'agent12-review115-combination-d0013552.tar.xz'
def sha(data):return hashlib.sha256(data).hexdigest()
receipt=json.loads((ROOT/'COMBINATION_RECEIPT.json').read_text())
assert receipt['status']=='PASS_ALREADY_CONTAINED_IDENTITY_COMBINATION'
assert not (ROOT/'helper.stderr.log').read_bytes()
(ROOT/'HELPER_EXECUTION.json').write_text(json.dumps({'argv':['python',str(ROOT/'verify_combination_strict.py')],'exit_code':0,'stdout':'helper.stdout.log','stderr':'helper.stderr.log','all_internal_git_commands_exit_zero':True},indent=2)+'\n')
entries=[]
for p in sorted(ROOT.rglob('*')):
 if p.is_file() and p.name!='DELIVERY_MANIFEST.json':
  assert not p.is_symlink();d=p.read_bytes();entries.append({'path':p.relative_to(ROOT).as_posix(),'bytes':len(d),'sha256':sha(d)})
manifest={'schema_version':1,'status':'PASS','base':receipt['base'],'head':receipt['head'],'combined_tree':receipt['combined_tree'],'retained_files':entries,'omissions':[]}
mp=ROOT/'DELIVERY_MANIFEST.json';mp.write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(DEST,'w:xz',preset=6) as tf:
 for e in entries:tf.add(ROOT/e['path'],arcname='review115-current-main-combination-001/'+e['path'],recursive=False)
 tf.add(mp,arcname='review115-current-main-combination-001/DELIVERY_MANIFEST.json',recursive=False)
expected={e['path']:e for e in entries};expected['DELIVERY_MANIFEST.json']={'bytes':mp.stat().st_size,'sha256':sha(mp.read_bytes())}
seen=set()
with tarfile.open(DEST,'r:xz') as tf:
 for m in tf:
  p=PurePosixPath(m.name);assert m.isfile() and not p.is_absolute() and '..' not in p.parts and p.parts[0]=='review115-current-main-combination-001'
  rel=PurePosixPath(*p.parts[1:]).as_posix();assert rel not in seen and rel in expected;seen.add(rel)
  d=tf.extractfile(m).read();assert len(d)==expected[rel]['bytes'] and sha(d)==expected[rel]['sha256']
assert seen==set(expected)
assert sha((ROOT.parent.parent/'agent12-review115-evidence.tar.xz').read_bytes())==receipt['sealed_review_archive_sha256']
delivery={'status':'PASS','base':receipt['base'],'head':receipt['head'],'combined_tree':receipt['combined_tree'],'base_entry_count':receipt['base_entry_count'],'effective_path_count':receipt['effective_path_count'],'all_source_and_verifier_bindings_pass':True,'archive':str(DEST),'archive_bytes':DEST.stat().st_size,'archive_sha256':sha(DEST.read_bytes()),'retained_files':len(seen),'roundtrip':'PASS_ALL_BYTES_AND_HASHES','manifest':str(mp),'manifest_sha256':sha(mp.read_bytes()),'receipt':str(ROOT/'COMBINATION_RECEIPT.json'),'receipt_sha256':sha((ROOT/'COMBINATION_RECEIPT.json').read_bytes()),'helper':str(ROOT/'verify_combination_strict.py'),'helper_sha256':sha((ROOT/'verify_combination_strict.py').read_bytes()),'sealed_original_archive_unchanged':True}
(ROOT.parent.parent/'agent12-review115-combination-d0013552-delivery.json').write_text(json.dumps(delivery,indent=2)+'\n')
print(json.dumps(delivery,indent=2))
