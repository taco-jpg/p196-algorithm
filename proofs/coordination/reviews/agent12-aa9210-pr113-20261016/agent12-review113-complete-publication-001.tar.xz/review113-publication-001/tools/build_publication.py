#!/usr/bin/env python3
"""Build the complete PR113 evidence publication without mutating earlier sealed evidence."""
import hashlib,json,os,shutil,subprocess,tarfile
from datetime import datetime,timezone
from pathlib import Path,PurePosixPath
P=Path('/dev/shm/p196-agent12-aa9210d02a75/review113-publication-001')
R=P.parent/'review113';C=R/'current-main-combination-002'
SEALED=[('agent12-review113-evidence.tar.xz','79c54d861e734b7c305fecb3eb8bfdd5b2b2a94cd4469d6c30df43f8437a7ef9'),
 ('agent12-review113-current-main-combination-001.tar.xz','36227d80766574c7d1090f7ee25746bca73da2e2ebc9ebd211331e06638fa318')]
def sha(data):return hashlib.sha256(data).hexdigest()
def blob(data):return hashlib.sha1(b'blob '+str(len(data)).encode()+b'\0'+data).hexdigest()
def put(name,obj):(P/name).write_text(json.dumps(obj,indent=2,ensure_ascii=False)+'\n')
def identity(path):
 data=path.read_bytes();return {'bytes':len(data),'sha256':sha(data),'git_blob_sha1':blob(data)}
assert not (P/'MANIFEST.json').exists(),'Publication already built; refusing overwrite'
for name,expected in SEALED:assert sha((P.parent/name).read_bytes())==expected
c=json.loads((C/'receipt.json').read_text());fresh=json.loads((R/'fresh-complete-001/verification.json').read_text())
assert c['status']=='PASS_EXACT_ADDITIVE_COMBINATION_WITH_FRESH_AUDIT_BINDING'
assert c['base']=='160ea9e84016f8f98625fcfd0d879536a0dd5799'
assert c['fresh_verification_sha256']==sha((R/'fresh-complete-001/verification.json').read_bytes())
api=json.loads((P/'api/current-main-001.json').read_text())
assert json.loads(api['result']['structuredContent']['content'])['object']['sha']==c['base']
for src,name in [(R/'SEMANTIC_REVIEW.md','SEMANTIC_REVIEW.md'),(R/'REVIEW_RECEIPT.json','REVIEW_RECEIPT.json'),
 (R/'AUDIT_REPAIR.json','AUDIT_REPAIR.json'),(C/'receipt.json','COMBINATION_RECEIPT.json'),(C/'closure-binding.json','CLOSURE_BINDING.json'),
 (R/'source-provenance.json','SOURCE_PROVENANCE.json')]:shutil.copyfile(src,P/name)
old_inherited=json.loads((C/'preserved-inherited-head-paths.json').read_text())
changed_old=[x for x in old_inherited if not x['head_equals_base']]
combo_report=f'''# PR113 refreshed-current-main combination review

**{c['status']}**

Independent reviewer: Agent #12 `/root/review109` (a separate agent review, not a separate GitHub account).

The read-only GitHub main-ref API observation at {api['retrieved_at']} fixed B to `{c['base']}`. The exact reviewed head is `{c['head']}`. The clean temporary merge tree is `{c['combined_tree']}`. No main ref, other ref, worktree, or remote object was changed by this reviewer. No merge commit was created.

The explicit ancestor check returned 1, the expected negative Boolean result. H is not contained in B. The two merge bases remain `{c['merge_bases'][0]}` and `{c['merge_bases'][1]}`. Ownership is defined by the genuine dependency merge `{c['genuine_dependency_merge']}` to H, not by an arbitrarily selected merge base.

The complete recursive tree comparison preserves all **{c['base_entry_count']}** current-main entries with identical mode, type and object. The combined tree has **{c['combined_entry_count']}** entries. Effective additions are exactly the **65** reviewed paths: four mathematical modules, one registry, and 60 package files. No existing path changes, deletions, unexpected additions, or incoming/H mismatches occurred. The complete binary/full-index effective patch equals the genuine owned submitted patch byte for byte.

All {len(old_inherited)} nonowned historical H paths already occur in main and retain the current-main version. {len(changed_old)} have historical H contents different from current main; those current-main updates are preserved:

'''+''.join('- `'+x['path']+'`\n' for x in changed_old)+f'''
All nine registry sources, module mappings, imports, three roots, and 38 public exports match the independently fresh compiled/audited snapshots. The five inherited proof modules remain identical to H and the fresh inputs; four owned modules are the only new source files. Registry SHA256 is `{c['registry_sha256']}`. Canonical verifier SHA256 is `{c['canonical_verifier_sha256']}` and its B/H/T bytes are identical.

This permits reuse of the successful explicit `--trust=0 -j1 -DElab.async=false` nine-module replay and exhaustive origin audit: 1,042 theorem constants, 164 safe definitions/opaques, 38 literal public exports, accepted union `{c['fresh_axiom_union']}`. Complete source, driver, audit-source, command and log hashes were checked. No Lean was rerun solely for byte-identical inputs. The original verifier's explicit-trust and safe-definition gaps remain documented in `AUDIT_REPAIR.json`; the stronger result belongs to the independent supplemental audit.

Fresh receipt SHA256: `{c['fresh_verification_sha256']}`. Full closure-binding SHA256: `{c['closure_binding_sha256']}`.

The first fixed-base combination remains preserved as historical evidence: B `d00135526e27396fda95cdb00e809737b301cdbc`, T `f05d65a2a227c9e36de043a2df42e3e4734d4293`. This second observation does not overwrite or reinterpret that earlier receipt.

Acceptance applies only to the exact B/H/T above. Parent must refresh main immediately before any final integration decision. This is neither an actual merge nor a repository-wide proof replay. Mathematical scope remains the finite, conditional one-step results described in the full semantic review; no all-time or 196 result is inferred.
'''
(C/'COMBINATION_REVIEW.md').write_text(combo_report);(P/'COMBINATION_REVIEW.md').write_text(combo_report)
summary={k:fresh[k] for k in ['status','source_commit','project','reviewer','trust_level','preexisting_project_object_count',
 'registry_sha256','auditor_driver_sha256','auditor_support_sha256','audit_source_sha256','theorem_count','safe_definition_count',
 'theorems_by_module','safe_definitions_by_module','new_module_theorem_count','new_module_safe_definition_count','axiom_union_literal',
 'all_selected_sources_unchanged','registry_unchanged','compiler_snapshot_unchanged']}
summary.update(public_exports=len(fresh['endpoints']),closure_modules=len(fresh['sources']),unsafe_implementation_axiom_count=len(fresh['unsafe_implementation_axioms']),unsafe_implementation_definition_count=len(fresh['unsafe_implementation_definitions']),
 original_full_receipt_sha256=sha((R/'fresh-complete-001/verification.json').read_bytes()),not_a_new_run=True)
put('FRESH_AUDIT_SUMMARY.json',summary)
helper_command=['python3',str(P/'tools/verify_combination113.py'),'--review-root',str(R),'--repo','/workspace/scratch/aa9210d02a75/p196-agent12','--base',c['base'],'--output',str(C),'--object-directory',str(P.parent/'git-objects'),'--alternate-object-directory','/workspace/scratch/aa9210d02a75/p196-agent12/.git/objects']
put('REUSABLE_HELPER.json',{'executed_invocation':helper_command,'helper_sha256':identity(P/'tools/verify_combination113.py')['sha256'],
 'reuse':'Replace --base with the final freshly observed full main SHA and --output with a new absent directory. The helper fetches only that exact commit without writing FETCH_HEAD or refs, handles all merge bases, and either checks all 65 owned additions or an already-ancestor identity combination. Partial/non-ancestral preexisting owned paths stop for explicit review.',
 'no_remote_mutations':True,'no_ref_mutations':True})
# Inventory every regular task file. No substantive file type is excluded.
roots=[('review113',R),('preparation-scratch',Path('/workspace/scratch/aa9210d02a75/agent12-review113')),
 ('selected-source-scratch',Path('/workspace/scratch/aa9210d02a75/agent12-pr113'))]
inputs=[]
for label,root in roots:
 for path in sorted(root.rglob('*')):
  assert not path.is_symlink(),'Unexpected symbolic link: '+str(path)
  if path.is_file():inputs.append((label+'/'+str(path.relative_to(root)),path))
for name,_ in SEALED:inputs.append(('sealed/'+name,P.parent/name))
inputs.append(('sealed/agent12-review113-current-main-combination-001.archive.json',P.parent/'agent12-review113-current-main-combination-001.archive.json'))
known={}
# Small directly publishable files can also satisfy an exact original-file mapping.
for path in sorted(P.rglob('*')):
 if path.is_file():
  data=path.read_bytes();key=sha(data)
  if key in known:assert (P/known[key]).read_bytes()==data
  else:known[key]=str(path.relative_to(P))
logical=[];compiled=[];duplicates=[];input_snapshots=[]
for logical_path,path in inputs:
 data=path.read_bytes();s=sha(data);record={'logical_path':logical_path,'source_path':str(path),'bytes':len(data),'sha256':s,'git_blob_sha1':blob(data)}
 if logical_path.startswith('review113/fresh-complete-001/build/') and path.suffix=='.olean':
  compiled.append({**record,'reason':'Freshly generated Lean compiled object; reproducible from retained exact sources, runtime identity, driver, commands and logs. No author project objects were accepted.'});continue
 if s in known:
  stored=known[s];assert (P/stored).read_bytes()==data,'SHA256 collision or source race'
  duplicates.append({'logical_path':logical_path,'stored_as':stored,'bytes':len(data),'sha256':s,'reason':'Only this extra physical copy is omitted; exact byte equality was checked and the logical path remains restorable.'})
 else:
  stored='objects/sha256/'+s[:2]+'/'+s;p=P/stored;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(data);known[s]=stored
 logical.append({**record,'stored_as':stored});input_snapshots.append((path,s,len(data)))
assert len(compiled)==9,'Unexpected compiled-object exclusion count'
put('LOSSLESS_INDEX.json',{'schema_version':1,'description':'Every retained original logical file is recoverable exactly from stored_as. Exact duplicates share physical storage; no historical name or content is lost. Generated publication files are listed separately in MANIFEST.json.',
 'input_roots':[{'logical_prefix':l,'source_root':str(r)} for l,r in roots],
 'file_count':len(logical),'total_logical_bytes':sum(x['bytes'] for x in logical),'files':logical})
put('EXCLUSIONS.json',{'schema_version':1,'policy':'Only identified freshly generated Lean compiled objects are substantively excluded. Exact duplicates omit only redundant physical copies and remain losslessly restorable via LOSSLESS_INDEX.json. No source, failure, log, receipt, helper or original sealed archive is excluded.',
 'compiled_objects':compiled,'exact_duplicate_physical_copies':duplicates,'other_exclusions':[]})
put('SEALED_INPUTS.json',{'original_sealed_archives':[{'logical_path':'sealed/'+n,**identity(P.parent/n),'unchanged_before_packaging':True} for n,_ in SEALED],
 'parent_reported_existing_upload':{'archive':'agent12-review113-evidence.tar.xz','git_blob_sha1':'de88fa249d191933442f74bbbfc45c09a4c3c5cc','local_bytes_independently_match_that_git_blob':blob((P.parent/'agent12-review113-evidence.tar.xz').read_bytes())=='de88fa249d191933442f74bbbfc45c09a4c3c5cc','remote_upload_not_performed_by_this_reviewer':True}})
put('PUBLICATION_RECEIPT.json',{'schema_version':1,'status':'COMPLETE_LOSSLESS_PUBLICATION_INPUTS_PREPARED','prepared_at':datetime.now(timezone.utc).isoformat(),
 'reviewer':'Agent #12 /root/review109; separate independent agent, not a separate account',
 'head':c['head'],'latest_checked_base':c['base'],'latest_checked_combined_tree':c['combined_tree'],
 'exact_source_acceptance':'ACCEPT_EXACT_SOURCE_WITH_COMPLETED_INDEPENDENT_AUDIT',
 'latest_combination_status':c['status'],'fresh_modules':9,'fresh_theorems':1042,'fresh_safe_definitions_or_opaques':164,'public_exports':38,
 'preserved_current_main_entries':c['base_entry_count'],'effective_owned_additions':65,
 'source_and_closure_bytes_match_fresh_replay':True,'fresh_verification_sha256':c['fresh_verification_sha256'],
 'closure_binding_sha256':c['closure_binding_sha256'],'registry_sha256':c['registry_sha256'],'canonical_verifier_sha256':c['canonical_verifier_sha256'],
 'retained_original_logical_files':len(logical),'compiled_object_exclusions':len(compiled),'exact_duplicate_physical_copy_exclusions':len(duplicates),
 'remote_mutations':False,'uploads_performed':False,'actual_merge_performed':False,
 'limitations':['Acceptance binds only each recorded fixed base/head/tree. Refresh main before integration.','Original compiler archive is unavailable; executable/runtime provenance limits are accurately retained.','The original canonical verifier does not itself provide the supplemental explicit-trust and safe-definition coverage.','This is not an all-time 196 or repository-wide proof result.']})
readme=f'''# PR113 complete independent review and current-main combination publication

## Publication scope and outcome

This is the complete lossless publication package prepared by Agent #12 `/root/review109` for exact PR113 head `{c['head']}` in `taco-jpg/p196-algorithm`. It combines the previously sealed independent fresh semantic/source/evidence review, its complete strict Lean replay, both fixed-main combination checks, all retained setup material, all substantive helper versions and command logs, historical author failures, original contribution inputs, and the two prior sealed archives themselves. The independent reviewer is a separate agent, not a separate GitHub account.

Exact source verdict: **ACCEPT_EXACT_SOURCE_WITH_COMPLETED_INDEPENDENT_AUDIT**.

Latest fixed combination verdict: **{c['status']}**.

| Checkpoint | Base | Combined tree |
|---|---|---|
| Combination 001 | `d00135526e27396fda95cdb00e809737b301cdbc` | `f05d65a2a227c9e36de043a2df42e3e4734d4293` |
| Combination 002 | `{c['base']}` | `{c['combined_tree']}` |

The second base was observed through the read-only GitHub main-ref API at {api['retrieved_at']}. At that fixed base, all **18,150** original main entries remain identical and exactly **65** reviewed paths are added, producing **18,215** entries. There are no deletions, modifications to existing paths, unexpected additions or source mismatches. H is not an ancestor of either checked base. Both actual merge bases are retained; ownership uses the exact delta after the genuine inherited dependency merge. Current-main historical documentation updates are preserved.

No remote mutation, blob upload, review/comment publication, main claim, ref update or actual merge was performed by this reviewer. Parent owns final publication and integration. A later main tip requires a fresh fixed-base combination check.

## Mathematical review and completed fresh verification

The four new modules prove finite one-step results for ordinary decimal reverse-add: necessary conditions on unequal canonical predecessor widths; at most two finite pair-sum profiles; explicit cross-width witnesses; and an exact positive canonical palindrome-target predecessor characterization. The profile bound is not a bound of two integer predecessors. Palindrome-target image existence is equivalent to even target width or even center digit. The first-hit-one construction requires width at least two. No infinite-time, density, optimality or 196 conclusion is inferred. `SEMANTIC_REVIEW.md` preserves the complete proof-contract review and all qualifications.

The affected closure contains nine modules. The independent fresh run used official Lean 4.19.0, explicit `--trust=0 -j1 -DElab.async=false`, a clean project build, and no incoming author project objects. All nine modules and the exhaustive audit exited successfully. The audit checks **1,042 module-origin theorem constants**, **164 safe definitions/opaques**, and **38 literal public exports**, with accepted axiom union `[Classical.choice, Quot.sound, propext]`. New modules contribute 86 theorem constants and one safe definition. Unsafe implementation declarations were separately inventoried and are not accepted safe dependencies.

The original canonical verifier omits explicit `--trust=0` and its origin audit skips safe definitions/opaques. Historical PASS records accurately described their narrower checks. `AUDIT_REPAIR.json` preserves the precise gap and the separately attributed audit-only repair. No mathematical source, theorem statement, registry or historical result was edited to obtain acceptance. Original author failures are retained with their original error and `sorryAx` output, distinct from the successful final dependency chain.

The nine source bytes, registry mappings, imports, roots, public exports and unchanged canonical verifier in both combination trees are identical to the fresh compiled snapshots. Complete prior command flags and log/driver/audit-source hashes were rebound. No redundant Lean run was performed for byte-identical combination inputs. The runtime executable and runtime objects were checked as recorded; the originally downloaded compiler archive is unavailable, so no new archive provenance verification is claimed.

## Small directly publishable files

- `SEMANTIC_REVIEW.md`: complete independent English mathematical and evidence review.
- `REVIEW_RECEIPT.json`: unchanged original exact-source acceptance receipt.
- `AUDIT_REPAIR.json`: unchanged audit-only repair account.
- `FRESH_AUDIT_SUMMARY.json`: compact derived fresh-run counts and hashes; the complete original receipt is retained losslessly.
- `COMBINATION_REVIEW.md`, `COMBINATION_RECEIPT.json`, `CLOSURE_BINDING.json`: latest fixed-main result and all nine exact source mappings.
- `SOURCE_PROVENANCE.json`: original source identity checks.
- `PUBLICATION_RECEIPT.json`, `SEALED_INPUTS.json`, `REUSABLE_HELPER.json`: package status, original archive identities, and exact executed reusable-helper invocation.
- `README.md`, `MANIFEST.json`, `LOSSLESS_INDEX.json`, `EXCLUSIONS.json`: publication and recovery specification.

The original already-uploaded fresh-review archive has local Git blob identity `de88fa249d191933442f74bbbfc45c09a4c3c5cc`; this was independently recomputed from its unchanged bytes. That parent-reported upload is not a publication performed by this reviewer. The new complete package can be published as one archive; it contains those original archive bytes as well.

## Lossless layout and precise exclusions

Every substantive input file has a complete entry in `LOSSLESS_INDEX.json`: original logical path, original source location, byte count, SHA256, Git blob SHA1 and the physical `stored_as` location. A content-addressed `objects/sha256/` store avoids repeating identical bytes. Exact duplicates were compared byte for byte before sharing storage. Thus an omitted duplicate physical copy does **not** omit its logical path or content; it is recoverable in full. Small direct files may also serve as exact stored copies.

The retained index covers **{len(logical)} original logical files**. The only substantive exclusions are **nine freshly generated `.olean` compiler objects**, individually identified with hashes in `EXCLUSIONS.json`. They can be regenerated from the retained source, runtime identity, exact drivers and commands. **{len(duplicates)} exact duplicate physical copies** share stored bytes. No other exclusions are permitted or used. All failure logs, empty logs, original manifests, preparation helpers, both original sealed archives and every current-main combination record remain recoverable.

The logical prefixes are `review113/`, `preparation-scratch/`, `selected-source-scratch/`, and `sealed/`. The first contains both `current-main-combination-001/` and `current-main-combination-002/`, each with its complete inventories, patches, command stdout/stderr, binding records and helper evidence. The sealed archives retain their own historical self-contained manifests and layouts unchanged. Their historical receipts are not rewritten to refer to the later base.

`MANIFEST.json` lists every physical archive file except itself (to avoid a recursive self-hash). The separately emitted `ARCHIVE.json` records the final archive bytes, SHA256 and Git blob SHA1, and successful round-trip and lossless-index validation. This envelope is directly publishable beside the archive; it cannot be embedded in the archive whose hash it names.

## Verification and recovery

Safely extract the archive into an empty directory; archive members are regular files with no traversal, absolute paths, symlinks or duplicate names. Then verify physical files and all original logical records:

```sh
python3 tools/restore_evidence.py --package .
```

To reconstruct all retained original logical files into a new empty destination:

```sh
python3 tools/restore_evidence.py --package . --output /absolute/path/to/new-restored-evidence
```

The restore tool checks every manifest digest and every logical mapping before copying, requires an absent output directory, and rejects unsafe paths. Compiled objects intentionally remain absent. The final archive builder also opens the completed archive and compares every decompressed member byte for byte to the publication staging file, then resolves every logical input from those archived bytes and compares it to its untouched original input.

## Reusing the exact combination checker for a final base

The executed parameterized helper is `tools/verify_combination113.py`, SHA256 `{c['helper_sha256']}`. Its fixed reviewed head and 65-path scope cannot be silently replaced through arguments. `tools/helper-adaptation.diff` preserves the changes from the first executed fixed-base helper; the original helper itself is retained in combination 001.

Use the invocation in `REUSABLE_HELPER.json`, replacing only `--base` with the freshly observed full main SHA and `--output` with a new absent evidence directory. The helper uses read-only fetch with `--no-write-fetch-head --no-tags`, an isolated object directory and a read-only alternate, all merge bases, full main-entry preservation, exact owned path checks, source/verifier/registry identity and fresh-audit log binding. If H is already an ancestor, it requires a zero-change identity combination and all 65 owned paths still matching H. Partial or unexplained preexisting ownership stops for review. It does not update refs or merge anything.
'''
(P/'README.md').write_text(readme)
# Validate immutable sources again after inventorying.
for path,s,n in input_snapshots:
 data=path.read_bytes();assert len(data)==n and sha(data)==s,'Input changed during publication: '+str(path)
for name,expected in SEALED:assert sha((P.parent/name).read_bytes())==expected
# Deterministic content inventory of all physical members; manifest excludes itself.
physical=[]
for path in sorted(P.rglob('*')):
 if path.is_file():physical.append({'path':str(path.relative_to(P)),**identity(path)})
put('MANIFEST.json',{'schema_version':1,'description':'Complete physical publication manifest, excluding only itself to avoid recursive hashing. Every original logical input is also mapped in LOSSLESS_INDEX.json. Archive envelope is external.','files':physical})
archive=P.parent/'agent12-review113-complete-publication-001.tar.xz'
assert not archive.exists(),'Refusing to overwrite final archive'
with tarfile.open(archive,'w:xz',preset=6) as tf:
 for path in sorted(P.rglob('*')):
  if path.is_file():tf.add(path,arcname=str(Path(P.name)/path.relative_to(P)),recursive=False)
archived={}
with tarfile.open(archive,'r:xz') as tf:
 for member in tf.getmembers():
  name=PurePosixPath(member.name)
  assert member.isfile() and not name.is_absolute() and '..' not in name.parts
  relative=str(name.relative_to(P.name));assert relative not in archived
  data=tf.extractfile(member).read();assert data==(P/relative).read_bytes(),'Archive round-trip mismatch: '+relative
  archived[relative]=data
assert len(archived)==len(physical)+1
for item in logical:
 data=archived[item['stored_as']]
 assert len(data)==item['bytes'] and sha(data)==item['sha256'] and blob(data)==item['git_blob_sha1']
 assert data==Path(item['source_path']).read_bytes(),'Lossless original-byte mismatch'
for name,expected in SEALED:assert sha((P.parent/name).read_bytes())==expected
argv=['python3',str(P/'tools/restore_evidence.py'),'--package',str(P)]
verified=subprocess.run(argv,capture_output=True,text=True)
assert verified.returncode==0,(verified.stdout,verified.stderr)
info={'schema_version':1,'status':'PASS_COMPLETE_ARCHIVE_ROUNDTRIP_AND_LOSSLESS_ORIGINAL_BINDING','archive':str(archive),**identity(archive),
 'archive_physical_files':len(archived),'physical_manifest_sha256':sha((P/'MANIFEST.json').read_bytes()),
 'lossless_index_sha256':sha((P/'LOSSLESS_INDEX.json').read_bytes()),'retained_original_logical_files':len(logical),
 'retained_logical_bytes':sum(x['bytes'] for x in logical),'compiled_object_exclusions':len(compiled),
 'exact_duplicate_physical_copy_exclusions':len(duplicates),'other_exclusions':[],
 'all_archive_members_roundtrip_identical':True,'all_logical_files_match_original_bytes':True,'sealed_inputs_unchanged':True,
 'base':c['base'],'head':c['head'],'combined_tree':c['combined_tree'],
 'validation_command':argv,'validation_exit_code':verified.returncode,'validation_stdout':verified.stdout,'validation_stderr':verified.stderr,
 'remote_mutations':False,'uploads_performed':False,'actual_merge_performed':False,
 'direct_files':[{'path':name,**identity(P/name)} for name in ['README.md','SEMANTIC_REVIEW.md','REVIEW_RECEIPT.json','AUDIT_REPAIR.json','FRESH_AUDIT_SUMMARY.json','COMBINATION_REVIEW.md','COMBINATION_RECEIPT.json','CLOSURE_BINDING.json','SOURCE_PROVENANCE.json','PUBLICATION_RECEIPT.json','SEALED_INPUTS.json','REUSABLE_HELPER.json','MANIFEST.json']]}
# External final hash envelope is intentionally outside the immutable archive staging tree.
envelope=P.parent/'agent12-review113-complete-publication-001.ARCHIVE.json'
envelope.write_text(json.dumps(info,indent=2)+'\n')
print(json.dumps({k:info[k] for k in ['status','archive','bytes','sha256','git_blob_sha1','archive_physical_files','retained_original_logical_files','compiled_object_exclusions','exact_duplicate_physical_copy_exclusions','base','head','combined_tree']},indent=2))
print('ARCHIVE_ENVELOPE',envelope)
