#!/usr/bin/env python3
"""Audit real API tree identities, the exact B+H combination, and workflow filters."""
import json, hashlib, pathlib, re, collections, yaml
ROOT=pathlib.Path(__file__).resolve().parent
RAW=ROOT/'raw'
PROJECT=ROOT.parent.parent
def read(name): return json.loads((RAW/(name+'.json')).read_text())
def write(name,data): (ROOT/name).write_text(json.dumps(data,indent=2)+'\n')
def identity(e): return (e['mode'],e['type'],e['sha'])
def blob_sha(content):
    return hashlib.sha1(b'blob '+str(len(content)).encode()+b'\0'+content).hexdigest()
def tree_sha(entries):
    entries=sorted(entries,key=lambda e:(e['path']+('/' if e['type']=='tree' else '')).encode())
    b=b''.join(e['mode'].lstrip('0').encode()+b' '+e['path'].encode()+b'\0'+bytes.fromhex(e['sha']) for e in entries)
    return hashlib.sha1(b'tree '+str(len(b)).encode()+b'\0'+b).hexdigest()
trees={}
for p in RAW.glob('tree-*.json'):
    d=json.loads(p.read_text());assert d['truncated'] is False
    assert d['sha']==p.stem[5:]
    trees[d['sha']]=d
new_root='31cf2179a0eb3f86e94b2c890c3ee45374205985'
tree_identities=[]
for sha,d in trees.items():
    if sha==new_root: continue
    actual=tree_sha(d['tree'])
    assert actual==sha,(sha,actual)
    tree_identities.append({'sha':sha,'direct_entries':len(d['tree']),'computed_sha':actual})
# Verify each actual tree represented by the one recursive added-subtree response.
recursive=trees[new_root]
for directory,expected in [('',new_root)]+[(e['path'],e['sha']) for e in recursive['tree'] if e['type']=='tree']:
    prefix=directory+'/' if directory else ''
    entries=[dict(e,path=e['path'][len(prefix):]) for e in recursive['tree']
             if e['path'].startswith(prefix) and '/' not in e['path'][len(prefix):]]
    assert tree_sha(entries)==expected,(directory,expected,tree_sha(entries))
    tree_identities.append({'sha':expected,'directory_under_new_root':directory,'direct_entries':len(entries),'computed_sha':tree_sha(entries)})
commits={x:read('commit-'+x) for x in ['B','H','M','pin']}
B,H,M=(commits[x]['sha'] for x in ['B','H','M'])
assert [x['sha'] for x in commits['M']['parents']]==[B,H]
pr=read('pr-163.initial')
assert pr['head']['sha']==H and pr['base']['sha']==B
assert pr['merge_commit_sha']==M and pr['merged'] is False and pr['state']=='open' and pr['draft'] is False
assert read('main-ref')['object']['sha']==B
equal=[];changed_trees=[];added=[];deleted=[];modified=[]
def expand(sha,prefix):
    if sha==new_root:
        return [dict(e,path=prefix+'/'+e['path']) for e in trees[sha]['tree'] if e['type']!='tree']
    return [dict(e,path=prefix+'/'+e['path']) for e in trees[sha]['tree'] if e['type']!='tree']+[
        y for e in trees[sha]['tree'] if e['type']=='tree' for y in expand(e['sha'],prefix+'/'+e['path'])]
def compare(a,b,prefix=''):
    aa={x['path']:x for x in trees[a]['tree']}
    bb={x['path']:x for x in trees[b]['tree']}
    changed_trees.append({'path':prefix or '/', 'B_tree':a,'M_tree':b,'B_direct_entries':len(aa),'M_direct_entries':len(bb)})
    for p in sorted(set(aa)|set(bb)):
        path=prefix+'/'+p if prefix else p
        x,y=aa.get(p),bb.get(p)
        if x is None:
            added.extend(expand(y['sha'],path) if y['type']=='tree' else [dict(y,path=path)])
        elif y is None: deleted.append(dict(x,path=path))
        elif identity(x)==identity(y): equal.append(dict(x,path=path))
        elif x['type']==y['type']=='tree' and x['mode']==y['mode']: compare(x['sha'],y['sha'],path)
        else: modified.append({'path':path,'B':x,'M':y})
compare(commits['B']['tree']['sha'],commits['M']['tree']['sha'])
assert not deleted and not modified
files=json.loads((PROJECT/'api-files.json').read_text())
assert files['head']==H and len(files['files'])==46
expected={x['filename']:x for x in files['files']}
assert len(added)==46 and {x['path'] for x in added}==set(expected)
added.sort(key=lambda x:x['path'])
Hproofs=trees[trees[commits['H']['tree']['sha']]['tree'][4]['sha']]
# Use named lookup, independent of response ordering.
Hroot={e['path']:e for e in trees[commits['H']['tree']['sha']]['tree']}
Hproofs={e['path']:e for e in trees[Hroot['proofs']['sha']]['tree']}
Hcontrib={e['path']:e for e in trees[Hproofs['contributions']['sha']]['tree']}
assert Hcontrib['agent-65']['sha']==new_root and Hcontrib['agent-65']['mode']=='040000'
Hadded={('proofs/contributions/agent-65/'+e['path']):e for e in recursive['tree'] if e['type']=='blob'}
Hadded['proofs/SOURCE_MAP_GUIDE.md']=Hproofs['SOURCE_MAP_GUIDE.md']
addition_validation=[]
for e in added:
    path=e['path'];f=expected[path];content=(PROJECT/'source'/path).read_bytes()
    assert f['status']=='added' and f['deletions']==0
    assert e['type']=='blob' and e['mode']=='100644'
    assert e['sha']==f['sha']==blob_sha(content)
    assert identity(e)==identity(Hadded[path])
    addition_validation.append({'path':path,'mode':e['mode'],'blob':e['sha'],'bytes':len(content),'sha256':hashlib.sha256(content).hexdigest(),'H_equals_M':True,'absent_from_B':True})
write('additions.json',addition_validation)
write('preserved-frontier.json',equal)
write('verified-tree-identities.json',tree_identities)
write('traversed-tree-pairs.json',changed_trees)
pins=json.loads((ROOT/'source-pins.json').read_text())
assert all(len({identity(p[k]) for k in ['S','B','H','M']})==1 for p in pins)
# Report only the inspected top-level snapshot delta; this is not a full S->B audit.
Sproof={x['path']:x for x in trees['737615f8bff1aeb39f512e9b0c736f6bb0dbba08']['tree']}
Bproof={x['path']:x for x in trees['29f9c383f132740ba33ed6dd8356eece96a481eb']['tree']}
snapshot_delta={'scope':'proofs direct entries only; differing contributions subtree not expanded',
 'added':[dict(Bproof[p]) for p in sorted(Bproof.keys()-Sproof.keys())],
 'deleted':[dict(Sproof[p]) for p in sorted(Sproof.keys()-Bproof.keys())],
 'changed':[{'path':p,'S':Sproof[p],'B':Bproof[p]} for p in sorted(Sproof.keys()&Bproof.keys()) if identity(Sproof[p])!=identity(Bproof[p])]}
write('snapshot-to-B.direct-delta.json',snapshot_delta)
# BaseLoader retains the YAML key "on" and parses every workflow without execution.
def match(pattern,path):
    out='';i=0
    while i<len(pattern):
        c=pattern[i]
        if c=='*':
            if i+1<len(pattern) and pattern[i+1]=='*': out+='.*';i+=2;continue
            out+='[^/]*'
        elif c=='?': out+='[^/]'
        else: out+=re.escape(c)
        i+=1
    return re.fullmatch(out,path) is not None
workflow_tree=trees['891a794df4125917ab9be61de95288f47d527bfa']
workflow_results=[]
for e in workflow_tree['tree']:
    r=read('workflow-'+e['path'])
    text=r['structuredContent']['content'];content=text.encode()
    assert blob_sha(content)==e['sha']
    dest=ROOT/'workflows'/e['path'];dest.parent.mkdir(exist_ok=True);dest.write_bytes(content)
    parsed=yaml.load(text,Loader=yaml.BaseLoader);events=parsed['on']
    assert isinstance(events,dict)
    event_results={}
    for event,config in events.items():
        config=config or {}
        if event not in ['push','pull_request']:
            event_results[event]={'state':'NOT_INVOKED','reason':'Manual trigger only' if event=='workflow_dispatch' else 'Other trigger'}
            continue
        assert not any(k in config for k in ['paths-ignore','branches-ignore'])
        paths=config.get('paths',[])
        assert paths and all(not p.startswith('!') and '[' not in p for p in paths)
        matches={p:[q for q in expected if match(p,q)] for p in paths}
        matches={p:q for p,q in matches.items() if q}
        branch=config.get('branches',[])
        source_branch=pr['head']['ref'] if event=='push' else pr['base']['ref']
        event_results[event]={'paths':paths,'matched_changed_paths':matches,'branches':branch,'branch_matches':not branch or any(match(p,source_branch) for p in branch),'state':'NOT_APPLICABLE' if not matches else 'PATH_MATCH'}
        assert not matches,(e['path'],event,matches)
    workflow_results.append({'path':'.github/workflows/'+e['path'],'blob':e['sha'],'sha256':hashlib.sha256(content).hexdigest(),'events':event_results})
assert len(workflow_results)==39
write('workflow-applicability.json',workflow_results)
summary={
 'status':'PASS_COMBINATION_IDENTITY_AND_PRESERVATION',
 'source_head':H,'base':B,'proposed_test_merge':M,
 'trees':{x:commits[x]['tree']['sha'] for x in ['B','H','M','pin']},
 'ordered_merge_parents':[B,H],
 'integrated':False,'merge_attempted':False,'handoff_accepted':False,
 'added_blobs':len(added),'modified_existing_blobs':len(modified),'deleted_existing_entries':len(deleted),
 'preserved_frontier_entries':len(equal),'preserved_frontier_blobs':sum(e['type']=='blob' for e in equal),'preserved_frontier_subtrees':sum(e['type']=='tree' for e in equal),
 'preserved_frontier_count_note':'Disjoint preservation frontier: each equal subtree counted once without counting or individually reading descendants.',
 'tree_pairs_descended':len(changed_trees),'verified_real_tree_hashes':len(tree_identities),
 'source_pin_equalities':len(pins),'workflow_files_hashed_and_inspected':len(workflow_results),
 'workflow_event_counts':dict(collections.Counter(k for w in workflow_results for k in w['events'])),
 'matching_pull_request_or_push_path_filters':0,
 'head_legacy_status':{'state':read('status-H')['state'],'contexts':read('status-H')['total_count'],'interpretation':'NOT_RUN; empty contexts do not constitute a failed test'},
 'head_check_runs':[{'id':x['id'],'name':x['name'],'status':x['status'],'conclusion':x['conclusion'],'app':x['app']['slug']} for x in read('checks-H')['check_runs']],
 'head_check_suites':[{'id':x['id'],'app':x['app']['slug'],'status':x['status'],'conclusion':x['conclusion'],'latest_check_runs_count':x['latest_check_runs_count']} for x in read('suites-H')['check_suites']],
 'head_workflow_runs':read('workflow-runs-H')['total_count'],'merge_workflow_runs':read('workflow-runs-M')['total_count'],
 'main_protected':read('branch-main')['protected'],'main_reported_required_status_checks':read('branch-main')['protection']['required_status_checks'],
 'visible_rulesets':read('rulesets'),'protection_admin_read':'403_LIMITED_VISIBILITY','effective_rules_endpoint':'CONNECTOR_NOT_SUPPORTED',
 'unresolved_review_threads':len(read('review-threads')['structuredContent']['review_threads']),
 'reviews':[{'id':x['id'],'state':x['state'],'author':x['author']['login']} for x in read('reviews')['structuredContent']['reviews']],
 'limitations':['No fresh Lean build executed or claimed.','External pending suites remain QUEUED, not PASSED.','GitGuardian success covers secrets detection only.','No main-write slot held by this inspector.','All mutable gates require final refresh by the authorized main writer.']
}
write('validation.json',summary)
final_pr=read('pr-163.final')
final_main=read('main-ref.final')
assert (final_pr['head']['sha'],final_pr['base']['sha'],final_pr['merge_commit_sha'])==(H,B,M)
assert final_main['object']['sha']==B and final_pr['merged'] is False and final_pr['state']=='open'
summary['final_refresh']={'head':H,'base':B,'test_merge':M,'main':B,'merged':False,'state':final_pr['state'],'draft':final_pr['draft'],'mergeable':final_pr['mergeable']}
summary['merge_check_runs']=read('checks-M')['total_count']
summary['merge_check_suites']=read('suites-M')['total_count']
summary['merge_legacy_status']={'state':read('status-M')['state'],'contexts':read('status-M')['total_count'],'interpretation':'NOT_RUN'}
write('validation.json',summary)
print(json.dumps({k:summary[k] for k in ['status','added_blobs','preserved_frontier_entries','preserved_frontier_blobs','preserved_frontier_subtrees','tree_pairs_descended','verified_real_tree_hashes','workflow_files_hashed_and_inspected','workflow_event_counts','matching_pull_request_or_push_path_filters']},indent=2))

