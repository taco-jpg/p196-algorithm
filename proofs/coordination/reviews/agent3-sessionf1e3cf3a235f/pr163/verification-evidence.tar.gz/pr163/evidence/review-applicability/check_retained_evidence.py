#!/usr/bin/env python3
"""Read-only consistency checks of the exact materialized PR163 added files.

This reviewer-authored program does not execute/import contribution scripts,
fetch source blobs, rerun historical commands, compile Lean, or mutate source.
Its sole writes are new reviewer evidence within its own evidence directory.
"""
from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import platform
import re
import sys

HERE = Path(__file__).resolve().parent
PR = HERE.parent.parent
SOURCE = PR / "source"
PACKAGE = "proofs/contributions/agent-65/source-map-guide-20261016/"
H = "b5448228f38b925f9924030b2fafd12e13ea8fc3"
B = "74a1c3922eb7af438fe40b23d2105ad07556e3f5"
GUIDE_HASH = "1b66a639da024562d317f8f550e3c2c0250b412ea5f46c6678a6824b2387c101"
checks, errors, json_members = [], [], []

def require(name, ok, detail=None):
    entry = {"check": name, "pass": bool(ok)}
    if detail is not None:
        entry["detail"] = detail
    checks.append(entry)
    if not ok:
        errors.append(entry)

def digest(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()

def read(relative):
    return (SOURCE / relative).read_bytes()

def parse(relative):
    duplicates = []
    def pairs(values):
        out = {}
        for key, value in values:
            if key in out:
                duplicates.append(key)
            out[key] = value
        return out
    obj = json.loads(read(relative), object_pairs_hook=pairs)
    require("JSON duplicate keys: " + relative, not duplicates, duplicates)
    return obj

api = json.loads((PR / "api-files.json").read_bytes())
require("API inventory exact H and B", api["head"] == H and api["base"] == B)
files = api["files"]
require("Exactly 46 complete added files", len(files) == 46 and all(x["status"] == "added" and x["deletions"] == 0 for x in files))
inventory = []
for entry in files:
    path = entry["filename"]
    data = read(path)
    item = {"path": path, "bytes": len(data), "sha256": digest(data),
            "git_blob_sha1": blob(data), "api_blob_sha1": entry["sha"],
            "api_status": entry["status"]}
    inventory.append(item)
    require("Exact API blob: " + path, item["git_blob_sha1"] == entry["sha"])
    if path.endswith(".json"):
        parse(path)
        json_members.append(path)
require("Materialized path set equals API path set", {str(x.relative_to(SOURCE)) for x in SOURCE.rglob("*") if x.is_file()} == {x["filename"] for x in files})
require("Guide exact reviewed SHA-256", digest(read("proofs/SOURCE_MAP_GUIDE.md")) == GUIDE_HASH)
require("No changed workflow/build/formal source paths", all(x["filename"] == "proofs/SOURCE_MAP_GUIDE.md" or x["filename"].startswith(PACKAGE) for x in files))

manifests = ["EVIDENCE_MANIFEST.json", "command-validation/ARTIFACTS.json",
             "command-validation/ARTIFACTS.partial.json", "mapping-audit/AUDIT_ARTIFACTS.json",
             "mapping-audit/INCREMENT_MANIFEST.json"]
manifest_sets = {}
for suffix in manifests:
    obj = parse(PACKAGE + suffix)
    entries = obj.get("entries", obj.get("files"))
    manifest_sets[suffix] = {x["path"] for x in entries}
    require("No repeated manifest paths: " + suffix, len(entries) == len(manifest_sets[suffix]))
    for entry in entries:
        data = read(entry["path"])
        ok = len(data) == entry["bytes"] and digest(data) == entry["sha256"]
        if "git_blob_sha1" in entry:
            ok = ok and blob(data) == entry["git_blob_sha1"]
        if "mode" in entry:
            ok = ok and entry["mode"] == "100644"
        require("Manifest content: " + suffix + " -> " + entry["path"], ok)
first = manifest_sets["EVIDENCE_MANIFEST.json"] | {PACKAGE + "EVIDENCE_MANIFEST.json"}
second = manifest_sets["mapping-audit/INCREMENT_MANIFEST.json"] | {PACKAGE + "mapping-audit/INCREMENT_MANIFEST.json"}
require("30 first and 16 second increment members partition all additions", len(first) == 30 and len(second) == 16 and not first.intersection(second) and first | second == {x["filename"] for x in files})

receipt = parse(PACKAGE + "mapping-audit/FIRST_PUBLICATION_RECEIPT.json")
remote_files = receipt["complete_remote_readback"]["files"]
require("First-publication receipt exact membership", {x["path"] for x in remote_files} == first and len(remote_files) == 30)
for entry in remote_files:
    data = read(entry["path"])
    require("First-publication content unchanged: " + entry["path"], blob(data) == entry["sha"] and digest(data) == entry["sha256"])
require("Validation target supplied", PACKAGE + "VALIDATION.md" in first and digest(read(PACKAGE + "VALIDATION.md")) == "cf26da634f559aed5154da4be49f3fafc1791a36f3fb4e65b0f0a1ce42fe41db")

guide_blocks = re.findall(r"```sh\n(.*?)```", read("proofs/SOURCE_MAP_GUIDE.md").decode(), re.S)
require("Six guide shell blocks", len(guide_blocks) == 6)
for index, block in enumerate(guide_blocks, 1):
    require("Retained shell input equals guide block " + str(index), read(PACKAGE + "command-validation/shell-block-" + str(index) + ".sh") == block.encode())
require("Retained Python stdin equals guide heredoc", read(PACKAGE + "command-validation/lookup.stdin.py") == guide_blocks[0].split("\n", 1)[1].rsplit("PY\n", 1)[0].encode())
receipts = parse(PACKAGE + "command-validation/receipts.json")
for item in receipts["commands"]:
    for stream in ["stdout", "stderr"]:
        data = read(PACKAGE + "command-validation/" + item[stream + "_file"])
        require("Command receipt stream: " + item[stream + "_file"], digest(data) == item[stream + "_sha256"] and (stream not in item or data == item[stream].encode()) and (stream + "_bytes" not in item or len(data) == item[stream + "_bytes"]))
    require("Retained command exit zero: " + " ".join(item["argv"]), item["exit_code"] == 0)

result = parse(PACKAGE + "mapping-audit/run-001/result.json")
stdout = json.loads(read(PACKAGE + "mapping-audit/audit.stdout.txt"))
metadata = parse(PACKAGE + "mapping-audit/run-001/run-metadata.json")
execution = parse(PACKAGE + "mapping-audit/execution-receipt.json")
for field in ["status", "issue_count", "issue_categories", "counts", "scope", "not_claimed"]:
    require("Audit stdout/result agreement: " + field, stdout[field] == result[field])
require("Audit result bounded PASS", result["status"] == "PASS" and result["issue_count"] == 0 and result["issues"] == [] and result["counts"]["map_entries"] == 9161)
require("Author script identity matches run metadata", digest(read(PACKAGE + "mapping-audit/audit_mapping_metadata.py")) == metadata["script"]["sha256"])
require("All nine historical Git commands succeeded", len(metadata["git_commands"]) == 9 and all(x["exit_code"] == 0 and x["stderr_bytes"] == 0 and x["stderr"] == "" for x in metadata["git_commands"]))
for stream in ["stdout", "stderr"]:
    item = execution[stream]
    data = read(item["path"])
    require("Author captured stream identity: " + stream, len(data) == item["bytes"] and digest(data) == item["sha256"])
require("Author execution status agrees", execution["exit_code"] == metadata["exit_code"] == 0)
review = read(PACKAGE + "mapping-audit/INDEPENDENT_METADATA_REVIEW.md").decode()
independent = json.loads(re.findall(r"```json\n(.*?)```", review, re.S)[0])
require("Independent reviewer result PASS", independent["status"] == "PASS" and independent["map_entries"] == 9161 and independent["metadata_mismatches"] == [] and independent["duplicate_json_keys"] == [])
require("Independent output agrees with author counts", independent["baseline_entries"] == result["counts"]["baseline_entries"] and independent["snapshot_entries"] == result["counts"]["current_entries"] and independent["selection_counts"] == result["counts"]["selection_counts"])
for command, key in zip(independent["commands"], ["snapshot_tree", "baseline_tree", "source_map"]):
    pin = result["immutable_inputs"][key]
    require("Independent reviewer exact input: " + key, command["stdout_bytes"] == pin["bytes"] and command["stdout_sha256"] == pin["sha256"] and command["exit_code"] == 0 and command["stderr"] == "")
failure = parse(PACKAGE + "mapping-audit/preparation-failure-original.json")
require("Preserved preparation failure exact decoded output", len(failure["output"].encode()) == 842 and digest(failure["output"].encode()) == "bbe7aead41e917e167c269fa146453d7e2d159b258188edf49ec232c167796d9" and failure["exit_code"] == 1)

trailing = []
for item in inventory:
    for line_no, line in enumerate(read(item["path"]).decode().splitlines(), 1):
        if line.rstrip(" \t") != line:
            trailing.append({"path": item["path"], "line": line_no, "suffix": line[len(line.rstrip(" \t")):]})
expected = {(PACKAGE + "scouts/DOCUMENTATION_GAPS.md", 138), (PACKAGE + "scouts/REPRODUCTION_AUDIT.md", 9), (PACKAGE + "scouts/REPRODUCTION_AUDIT.md", 10)}
require("Only three preserved Markdown hard-break whitespace exceptions", {(x["path"], x["line"]) for x in trailing} == expected and all(x["suffix"] == "  " for x in trailing))

remote = json.loads((HERE / "remote-source-reads.json").read_bytes())
formal = json.loads(remote["formal_review_5555057805"]["structuredContent"]["content"])
require("Formal review is exact-head attributed COMMENTED", formal["id"] == 5555057805 and formal["state"] == "COMMENTED" and formal["commit_id"] == H and "Author's attributed final review handoff" in formal["body"])
pins = parse(PACKAGE + "command-validation/source-pins.json")["sources"]
for wrapper in remote["wrappers"]:
    obj = wrapper["value"]["structuredContent"]
    data = obj["content"].encode()
    pin = next(x for x in pins if x["blob_oid"] == obj["sha"])
    require("Pinned remote wrapper content: " + pin["path"], blob(data) == pin["blob_oid"] and digest(data) == pin["sha256"])

log = {"reviewer": "/root/review_applicability", "agent": 3, "session": "f1e3cf3a235f",
       "head": H, "base": B, "time_utc": datetime.now(timezone.utc).isoformat(),
       "python": sys.version, "platform": platform.platform(),
       "argv": sys.argv, "cwd": str(Path.cwd()),
       "source_inventory": inventory, "json_files_parsed": json_members,
       "checks": checks, "errors": errors, "trailing_whitespace": trailing,
       "status": "PASS" if not errors else "FAIL",
       "scope": "Exact PR-package byte identity and retained-evidence consistency. No historical author/reviewer process or Lean build rerun."}
(HERE / "checks.json").write_text(json.dumps(log, indent=2) + "\n")
print(json.dumps({"status": log["status"], "checks": len(checks), "errors": errors, "source_files": len(inventory), "total_source_bytes": sum(x["bytes"] for x in inventory), "json_files": len(json_members), "whitespace_exceptions": trailing}, indent=2))
raise SystemExit(0 if not errors else 1)
