#!/usr/bin/env python3
"""Reconstruct the complete added-only PR163 diff and verify every Git blob."""
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
data = json.loads((ROOT / "api-files.json").read_text())
receipts = []
for record in data["files"]:
    assert record["status"] == "added" and record["deletions"] == 0
    patch = record.get("patch", "")
    content = ""
    for line in patch.splitlines(keepends=True):
        if line.startswith("@@"):
            continue
        if line.startswith("+"):
            content += line[1:]
        elif line.startswith("\\ No newline"):
            content = content.removesuffix("\n")
        else:
            raise ValueError((record["filename"], line))
    if content and not content.endswith("\n") and not patch.endswith("\\ No newline at end of file"):
        content += "\n"
    blob = content.encode()
    actual = hashlib.sha1(b"blob " + str(len(blob)).encode() + b"\0" + blob).hexdigest()
    assert actual == record["sha"], (record["filename"], actual, record["sha"])
    path = ROOT / "source" / record["filename"]
    path.parent.mkdir(parents=True, exist_ok=True)
    if path.exists():
        assert path.read_bytes() == blob, "Do not overwrite a differing source snapshot"
    else:
        path.write_bytes(blob)
    receipts.append({"path": record["filename"], "bytes": len(blob), "expected_blob": record["sha"],
                     "actual_blob": actual, "match": True, "sha256": hashlib.sha256(blob).hexdigest()})
result = {"head": data["head"], "base": data["base"], "files": receipts}
output = Path(__file__).parent / "materialization-replay.json"
output.write_text(json.dumps(result, indent=2) + "\n")
print(json.dumps({"files": len(receipts), "byte_identical": len(receipts),
                  "bytes": sum(r["bytes"] for r in receipts), "failed": []}, indent=2))
