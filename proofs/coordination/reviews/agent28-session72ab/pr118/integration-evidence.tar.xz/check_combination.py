from pathlib import Path
import os, subprocess, json, hashlib, sys
from datetime import datetime, timezone
started=datetime.now(timezone.utc).isoformat()
root=Path('/dev/shm/p196-agent28-session72ab3fa8c99b')
alt=root/'objects.git/objects/info/alternates'
path=str(root/'base.git/objects')
if path not in alt.read_text().splitlines():
 with alt.open('a') as f:f.write(path+'\n')
env=os.environ.copy();env['GIT_NO_LAZY_FETCH']='1';env['GIT_TERMINAL_PROMPT']='0'
g=root/'objects.git';h='90c639b8a782a9a832bc19f6a6978196e91a3d78';b=sys.argv[1];a=sys.argv[2]
def git(*args,check=True):
 r=subprocess.run(['git','--git-dir',str(g),*args],capture_output=True,env=env)
 if check and r.returncode:raise RuntimeError(r.stderr.decode())
 return r
def tree(ref):
 d={}
 for row in git('ls-tree','-r','-z',ref).stdout.split(bytes([0])):
  if row:
   meta,path=row.split(b'\t',1);mode,kind,sha=meta.decode().split();d[path.decode()]={'mode':mode,'type':kind,'sha':sha}
 return d
A,B,H=tree(a),tree(b),tree(h)
changes={p:e for p,e in H.items() if A.get(p)!=e}
deleted=[p for p in A if p not in H]
assert not deleted
assert all(p not in A for p in changes)
conflicts={p:{'base':B[p],'head':e} for p,e in changes.items() if p in B and B[p]!=e}
assert not conflicts,conflicts
r=git('merge-tree','--write-tree','--merge-base='+a,b,h,check=False)
dest=root/'pr118'
(dest/('merge-tree-'+b[:8]+'.log')).write_bytes(r.stdout+r.stderr)
assert r.returncode==0,r.stderr.decode()
t=r.stdout.decode().splitlines()[0];T=tree(t)
expected=dict(B);expected.update(changes)
assert T==expected
reg=json.loads((dest/'head/proofs/Agent107Transducer.registry.json').read_text())
pins=[]
for name,m in reg['projects']['agent107-folded-transducer']['modules'].items():
 path=m['path'];assert T[path]['sha']==m['git_blob'];pins.append({'module':name,'path':path,'blob':T[path]['sha'],'matched':True})
preserved=all(T.get(p)==e for p,e in B.items())
assert preserved
workflow_H={p:e for p,e in H.items() if p.startswith('.github/workflows/')}
workflow_T={p:e for p,e in T.items() if p.startswith('.github/workflows/')}
changed_workflows={p:e for p,e in workflow_T.items() if workflow_H.get(p)!=e}
critical_paths=['AGENTS.md','proofs/verify_project__214bf7673efe116b.py']
critical={p:{'head':H.get(p),'combined':T.get(p),'unchanged':H.get(p)==T.get(p)} for p in critical_paths}
assert all(e['unchanged'] for e in critical.values())
rec={'started_at':started,'finished_at':datetime.now(timezone.utc).isoformat(),'command':['python3','-B',str(dest/'check_combination.py'),b,a],'git_version':git('--version').stdout.decode().strip(),'merge_tree_exit_code':r.returncode,'workflow_count':len(workflow_T),'workflow_changes_since_reviewed_head':changed_workflows,'critical_context':critical,'status':'PASS','source_head':h,'base':b,'merge_base':a,'combined_tree':t,'base_entry_count':len(B),'head_delta_entries':len(changes),'combined_entry_count':len(T),'all_base_entries_preserved':preserved,'scope_only_additions':True,'exact_expected_union':True,'registered_modules':pins,'fresh_lean':'NOT_RUN','verification_reuse_basis':'The complete registered source closure is byte-identical to the independently reviewed and previously executed source. Only disjoint source/evidence additions enter this combination.'}
(dest/('COMBINATION-'+b[:8]+'.json')).write_text(json.dumps(rec,indent=2)+'\n')
(dest/'CURRENT_COMBINATION.json').write_text(json.dumps(rec,indent=2)+'\n')
print(json.dumps({k:v for k,v in rec.items() if k!='registered_modules'}))
