#!/usr/bin/env python3
"""Independent PR136 retained-evidence audit: reads data; never runs Lean/Git/archive code.
Usage: python verify_retained.py [snapshot-root]
Writes its JSON receipt beside this script. No extraction or external processes.
"""
import collections, hashlib, json, re, sys, tarfile
from pathlib import Path, PurePosixPath
ROOT=Path(sys.argv[1]) if len(sys.argv)>1 else Path('/dev/shm/p196-agent27-session54abc2dc44d0-20261016/pr136-source')
PREFIX='proofs/contributions/agent-101/all-width-inverse-maximum-20261016/'
CP=PREFIX+'archives/final-independent-canonical/'
PRJ='agent101-all-width-maximum'
AP=ROOT/(PREFIX+'archives/final-independent.tar.gz')
sha=lambda b:hashlib.sha256(b).hexdigest()
blob=lambda b:hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
CHECKS=[]
def ck(test,label):
    if not test: raise AssertionError(label)
    CHECKS.append(label)
def jget(path):return json.loads(DATA[path])
def txt(path):return DATA[path].decode()
def pins(data,row,label):
    ck(len(data)==row['bytes'] and sha(data)==row['sha256'],'bytes+SHA256: '+label)
    if 'git_blob' in row:ck(blob(data)==row['git_blob'],'Gitblob: '+label)
def mask(s):
    # Retain newlines; handle nested block comments, line comments and escaped strings.
    out=[];i=0;depth=0;string=False
    while i<len(s):
        c=s[i]; pair=s[i:i+2]
        if depth:
            if pair=='/-':depth+=1;out.extend('  ');i+=2;continue
            if pair=='-/':depth-=1;out.extend('  ');i+=2;continue
            out.append('\n' if c=='\n' else ' ');i+=1;continue
        if string:
            if c=='\\':out.extend('  ');i+=2;continue
            if c=='"':string=False
            out.append('\n' if c=='\n' else ' ');i+=1;continue
        if pair=='/-':depth=1;out.extend('  ');i+=2;continue
        if pair=='--':
            e=s.find('\n',i)
            if e<0:e=len(s)
            out.extend(' '*(e-i));i=e;continue
        if c=='"':string=True;out.append(' ');i+=1;continue
        out.append(c);i+=1
    ck(not depth and not string,'Lexically closed Lean input')
    return ''.join(out)
MANIFEST=json.loads((ROOT/(PREFIX+'archives/final-independent-manifest.json')).read_bytes())
archive_bytes=AP.read_bytes();pins(archive_bytes,MANIFEST['archive'],'archive')
ck(blob(archive_bytes)=='dfee86d48d285862c19fedddd34d8151ddfb7022','Archive exact H Git blob')
ck(sha(archive_bytes)=='9fa2ace5f285fdda99b405d6ce25fae768c88a658c208c86d41f4b44ac6f0f79','Expected archive SHA256')
DATA={}; members=[]
with tarfile.open(AP,'r:gz') as archive:
    for m in archive:
        p=PurePosixPath(m.name)
        ck(m.isfile() and not p.is_absolute() and '..' not in p.parts and str(p)==m.name,'Safe regular archive member: '+m.name)
        ck(m.name not in DATA,'Unique archive member: '+m.name)
        ck(m.mode==0o644 and m.uid==m.gid==m.mtime==0 and not m.uname and not m.gname,'Normalized archive metadata: '+m.name)
        ck(not any(c in MANIFEST['excluded_policy']['directory_components'] for c in p.parts),'No excluded directory: '+m.name)
        ck(not m.name.endswith(tuple(MANIFEST['excluded_policy']['filename_endings'])),'No compiler object/cache: '+m.name)
        DATA[m.name]=archive.extractfile(m).read();members.append(m.name)
ck(members==sorted(members),'Sorted archive members')
manifest_map={x['path']:x for x in MANIFEST['members']}
ck(len(manifest_map)==len(MANIFEST['members'])==len(DATA)==MANIFEST['archive']['member_count']==124,'Exact 124-member manifest coverage')
ck(set(manifest_map)==set(DATA),'Manifest and payload exact member sets')
ck(sum(map(len,DATA.values()))==MANIFEST['archive']['uncompressed_file_bytes']==1858429,'Exact uncompressed payload size')
for p,row in manifest_map.items():pins(DATA[p],row,p)
ck(dict(collections.Counter(x['group'] for x in MANIFEST['members']))==MANIFEST['groups'],'Manifest group counts')
local_comparisons=[]
for p,b in DATA.items():
    local=ROOT/p
    if local.is_file():
        ck(local.read_bytes()==b,'Current H snapshot equals archive member: '+p);local_comparisons.append(p)
for row in MANIFEST['sidecar_helpers']:
    p=PREFIX+'archives/'+row['filename'];pins((ROOT/p).read_bytes(),row,p);ck(DATA[p]==(ROOT/p).read_bytes(),'Helper archive and sidecar identity: '+p)
INDEX=jget(PREFIX+'reviews/final-retained-evidence.json')
for section,pref in [('review_files',''),('canonical_files',CP)]:
    for row in INDEX[section]:pins(DATA[pref+row['path']],row,pref+row['path'])
ck(len(INDEX['review_files'])==INDEX['review_file_count']==54,'54 frozen review files')
ck(len(INDEX['canonical_files'])==INDEX['canonical_non_object_file_count']==38,'38 frozen nonobject canonical files')
ck(sum(x['bytes'] for x in INDEX['review_files'])==INDEX['review_bytes']==879748,'Frozen review-byte count')
ck(sum(x['bytes'] for x in INDEX['canonical_files'])==INDEX['canonical_non_object_bytes']==516234,'Frozen canonical-byte count')
ck({p for p in DATA if p.startswith(PREFIX+'reviews/')}=={x['path'] for x in INDEX['review_files']}|{PREFIX+'reviews/final-retained-evidence.json'},'Complete review directory coverage')
ck({p for p in DATA if p.startswith(CP)}=={CP+x['path'] for x in INDEX['canonical_files']},'Complete canonical directory coverage')
for field in ['final_receipt','semantic_review']:pins(DATA[INDEX[field]['path']],INDEX[field],field)
FILES=jget(CP+'FILES.json')
ck(len(FILES)==37 and 'FILES.json' not in FILES and not any(p.endswith('.olean') for p in FILES),'Original FILES has37 entries; excludes itself and .olean')
for p,row in FILES.items():pins(DATA[CP+p],row,CP+p)
ck(set(FILES)|{'FILES.json'}=={x['path'] for x in INDEX['canonical_files']},'Original FILES covers all canonical nonobjects except itself')
for a,b in [('FILES.json','final-canonical-FILES.json'),('verification.json','final-canonical-verification.json')]:ck(DATA[CP+a]==DATA[PREFIX+'reviews/'+b],'Canonical/report byte identity: '+a)
REG=jget('proofs/Agent101AllWidthMaximum.registry.json'); SPEC=REG['projects'][PRJ]
REPORT=jget(PREFIX+'reviews/final-verification.json'); CANON=jget(CP+'verification.json'); PR=CANON['projects'][PRJ]
READ=jget(PREFIX+'reviews/final-source-readback.json'); MODS=SPEC['modules']; ORDER=PR['build_order']
ck(sha(DATA['proofs/Agent101AllWidthMaximum.registry.json'])==REPORT['registry_sha256']==CANON['registry_sha256']==MANIFEST['registry_sha256']=='496908a7d53c6a09b7a82dfae3c5e10339ef699072e5c97c0e591dc4e2c2cfcc','Registry pin linkage')
ck(CANON['source_commit']==READ['published_commit']==REPORT['published_commit']==MANIFEST['source_commit']=='0a746261de31531b3ed1dc3d754cd3093753ff56','Historical published source commit linkage')
ck(READ['math_commit']==REPORT['math_commit']=='0fcbe9973659f178e9c834c68d45f660241d6fbd','Mathematical source commit linkage')
ck(len(MODS)==len(ORDER)==len(set(ORDER))==17 and set(ORDER)==set(MODS),'Exact17 selected modules and build order')
SOURCES=[]
for name,row in MODS.items():
    b=DATA[row['path']];ck(sha(b)==row['sha256'] and blob(b)==row['git_blob'],'Published source pins: '+name)
    cp=CP+PRJ+'/source/'+name.replace('.','/')+'.lean';ck(DATA[cp]==b,'Canonical source exact published bytes: '+name)
    rec=PR['sources'][name];ck(rec['path']==row['path'] and rec['sha256']==rec['build_sha256']==sha(b) and rec['adapter'] is None,'Canonical source identity without adapter: '+name)
    code=mask(b.decode());imports=[x for line in re.findall(r'^\s*import\s+([^\n]+)',code,re.M) for x in line.split()]
    ck(imports==row['imports']==rec['imports'],'Import identities: '+name)
    ck(all(d in MODS or d.split('.')[0] in {'Init','Std','Lean'} for d in imports),'Closed registered/std imports: '+name)
    ck(all(d not in MODS or ORDER.index(d)<ORDER.index(name) for d in imports),'Topological order: '+name)
    forbidden=re.findall(r"(?<![\w'])\b(?:sorry|admit|axiom|sorryAx|native_decide|ofReduceBool|skipKernelTC)\b(?![\w'])",code)
    ck(not forbidden,'No forbidden proof/source token: '+name)
    SOURCES.append({'module':name,'path':row['path'],'bytes':len(b),'sha256':sha(b),'git_blob':blob(b),'imports':imports})
seen=set()
def visit(n):
    if n in seen or n not in MODS:return
    seen.add(n)
    for d in MODS[n]['imports']:visit(d)
for n in SPEC['roots']:visit(n)
ck(seen==set(MODS),'All17 modules are reachable from root')
for row in READ['sources']+READ['metadata']:pins(DATA[row['path']],row,'Historical readback '+row['path'])
ck(len(READ['sources'])==17 and len(READ['metadata'])==8,'Readback17sources8metadata')
ck(all(r['returncode']==0 for r in READ['git_commands']),'All47 final Git readback commands succeeded')
ck(READ['metadata_checker']['returncode']==0,'Final metadata checker exit0')
ck(sha(DATA['proofs/verify_project__214bf7673efe116b.py'])==READ['verifier_sha256']==REPORT['canonical_verifier_sha256']=='c047ff1ff1fe12b2c2094ca5f36af871b1c6faf89db593a102f9c2f7d48cc98a','Original verifier pin')
exports=jget(PREFIX+'PUBLIC_EXPORTS.json'); ex=[{'module':m,**d} for m,info in exports['modules'].items() for d in info['public_declarations']]
ck(len(ex)==len({d['name'] for d in ex})==41 and collections.Counter(x['kind'] for x in ex)=={'theorem':36,'def':5},'41public36theorem5def metadata')
ck([d['name'] for d in ex]==PR['endpoints'],'Public endpoints exactly match canonical endpoints')
ck(DATA[PREFIX+'reviews/final-public-exports.json']==DATA[PREFIX+'PUBLIC_EXPORTS.json'],'Public metadata frozen identity')
ck(DATA[PREFIX+'reviews/final-registry.json']==DATA['proofs/Agent101AllWidthMaximum.registry.json'],'Registry frozen identity')
RUN=jget(PREFIX+'reviews/final-canonical-command.json'); AUDITCMDS=jget(PREFIX+'reviews/final-audit-commands.json')
ck(RUN['returncode']==0 and RUN['output_absent_before_run'] and '--check-only' not in RUN['command'],'Canonical fresh actual build invocation successful')
ck(sha(DATA[RUN['log']])==RUN['log_sha256'],'Canonical command log hash')
ck(len(PR['commands'])==18,'18canonical Lean commands')
compiler=PR['commands'][0]['argv'][0]
for i,c in enumerate(PR['commands']):
    label=ORDER[i] if i<17 else 'ProjectAudit'; expected=[compiler,'-j1','-DElab.async=false']+(['-o',label+'.olean',label+'.lean'] if i<17 else ['ProjectAudit.lean'])
    ck(c['label']==label and c['argv']==expected and c['exit_code']==0,'Exact default-trust canonical command and exit0: '+label)
    log=DATA[CP+c['log']];ck(sha(log)==c['log_sha256'],'Canonical raw log pin: '+label)
    ck(log==DATA[PREFIX+'reviews/final-build-logs/'+label+'.log'],'Raw log duplicate identity: '+label)
    ck(not re.search(r'(^|\n).*\berror:|sorryAx|ofReduceBool',log.decode()),'No error/unsupported axiom in canonical log: '+label)
ck(RUN['command'][3]==compiler,'Single compiler path between wrapper and module commands')
ck(AUDITCMDS==REPORT['audit_commands'] and len(AUDITCMDS)==3,'Three explicit audit commands retained exactly')
for c in AUDITCMDS:
    ck(c['command']==[compiler,'--trust=0','-j1','-DElab.async=false',c['source']] and c['returncode']==0,'Explicit trust0 audit command exit0: '+c['label'])
    ck(c['cwd']==c['LEAN_PATH']==REPORT['canonical_output_directory']+'/'+PRJ+'/source','Same fresh canonical closure reused: '+c['label'])
    source=PREFIX+'reviews/final-'+c['label'].removesuffix('-trust0')+'.lean'
    ck(sha(DATA[source])==c['source_sha256'] and sha(DATA[c['log']])==c['log_sha256'],'Audit source+rawlog identity: '+c['label'])
    ck(not re.search(r'(^|\n).*\berror:|sorryAx|ofReduceBool|DISALLOWED_AXIOMS|CUSTOM_AXIOM',txt(c['log'])),'No forbidden audit diagnostics: '+c['label'])
ck(DATA[PREFIX+'reviews/final-ProjectAudit.lean']==DATA[CP+PRJ+'/source/ProjectAudit.lean'],'Unchanged original ProjectAudit source')
ck(DATA[PREFIX+'reviews/final-ProjectAudit-trust0.log']==DATA[CP+PRJ+'/logs/ProjectAudit.log'],'Default and trust0 theorem audit raw logs identical')
allowed={'propext','Classical.choice','Quot.sound'}
def axset(s):return {x.strip() for x in s.strip().strip('[]').split(',') if x.strip()}
THEOREMS=re.findall(r'^AUDIT_THEOREM (\S+) (\S+) : (\[[^\]]*\])$',txt(PREFIX+'reviews/final-ProjectAudit-trust0.log'),re.M)
ck(len(THEOREMS)==len({x[1] for x in THEOREMS})==1305,'1305unique raw theorem records')
for m,n,axs in THEOREMS:ck(m in MODS and axset(axs)<=allowed,'Raw theorem axiom allowlist: '+n)
UNION=set().union(*(axset(a) for _,_,a in THEOREMS));COUNTS=dict(sorted(collections.Counter(m for m,_,_ in THEOREMS).items()))
ck(UNION==allowed==set(REPORT['theorem_axiom_union']) and COUNTS==REPORT['theorems_by_origin_module'],'Raw theorem unions/counts independently recomputed')
ck(re.findall(r'^FULL_MODULE_AUDIT theorems=(\d+) union=(.*)$',txt(PREFIX+'reviews/final-ProjectAudit-trust0.log'),re.M)==[('1305','[Classical.choice, Quot.sound, propext]')],'Exactly one accurate full theorem summary')
def printed(path):
    s=txt(path); rows=re.findall(r"^'(.+)' (depends on axioms: \[[^\]]*\]|does not depend on any axioms)$",s,re.M)
    result={}
    for n,a in rows:
        ck(n not in result,'Unique printed axiom declaration: '+n);result[n]=axset(a[a.index('['):]) if '[' in a else set();ck(result[n]<=allowed,'Printed axiom allowlist: '+n)
    return result
PUB=printed(PREFIX+'reviews/final-PublicAudit-trust0.log');safe=re.findall(r'^PUBLIC_SAFE (\S+) (\S+) (\S+)$',txt(PREFIX+'reviews/final-PublicAudit-trust0.log'),re.M)
ck(len(PUB)==len(safe)==41 and set(PUB)=={d['name'] for d in ex},'Raw public print coverage exact41')
ck(set(safe)=={(d['module'],d['kind'],d['name']) for d in ex},'Raw public origin/kind/safety match metadata')
ck(set().union(*PUB.values())==allowed,'Raw public axiom union')
ck(re.findall(r'^PUBLIC_COUNT (\d+)$',txt(PREFIX+'reviews/final-PublicAudit-trust0.log'),re.M)==['41'],'Raw public count marker')
DL=txt(PREFIX+'reviews/final-CompiledDefinitionsAudit-trust0.log');DEFS=re.findall(r'^COMPILED_(DEFINITION|OPAQUE) (\S+) (\S+)$',DL,re.M);UNSAFE=re.findall(r'^UNSAFE_COMPILER_IMPLEMENTATION (\S+) (\S+)$',DL,re.M);DP=printed(PREFIX+'reviews/final-CompiledDefinitionsAudit-trust0.log');INV=jget(PREFIX+'reviews/final-compiled-definition-inventory.json')
ck(len(DEFS)==len(DP)==len({x[2] for x in DEFS})==225 and all(k=='DEFINITION' and m in MODS for k,m,n in DEFS),'Raw225safe definitions and zero opaques')
ck(set(DP)=={n for _,_,n in DEFS},'Every safe definition has full axiom print')
ck(set().union(*DP.values())=={'propext'},'Raw safe definition axiom union')
ck(re.findall(r'^SAFE_DEFINITION_CENSUS definitions=(\d+) opaques=(\d+)$',DL,re.M)==[('225','0')],'Raw safe definition census')
ck(len(UNSAFE)==len(set(UNSAFE))==931 and all(m in MODS for m,n in UNSAFE),'Raw931unsafe implementation declarations')
ck(not ({n for _,n in UNSAFE}&(set(PUB)|set(DP)|{n for _,n,_ in THEOREMS})),'Unsafe implementations separate from safe/public/theorem inventories')
ck(INV['safe']==[{'kind':k,'module':m,'name':n} for k,m,n in DEFS] and INV['unsafe_implementation']==[{'module':m,'name':n} for m,n in UNSAFE],'Full definition inventory exactly equals raw log')
UNSAFEAX=re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$',txt(PREFIX+'reviews/final-ProjectAudit-trust0.log'),re.M)
ck(len(UNSAFEAX)==len(set(UNSAFEAX))==30 and set(UNSAFEAX)<=set(UNSAFE),'30implementation axioms contained in931unsafe inventory')
ck([list(x) for x in UNSAFEAX]==PR['unsafe_implementation_axioms']==REPORT['unsafe_implementation_axioms_from_original_audit'],'Exact implementation axiom list match')
for d in ex:
    if d['kind']=='def':ck(d['name'] in DP,'Public def covered by safe census: '+d['name'])
    else:ck((d['module'],d['name']) in {(m,n) for m,n,_ in THEOREMS},'Public theorem covered by full census: '+d['name'])
FAIL=jget(PREFIX+'reviews/final-source-readback-attempt-001.json');ck(FAIL['status']=='FAIL' and FAIL['git_commands'][-1]['returncode']==128 and FAIL['git_commands'][-1]['command']==['git','show','0fcbe9973659f178e9c834c68d45f660241d6fbd:proofs/Agent105WidthSupport9df76b.lean'],'Preserved initial Git object availability failure')
ck(DATA[PREFIX+'reviews/final-source-readback-attempt-001.py']==DATA[PREFIX+'reviews/final-source-readback.py'],'Unmodified readback retry script')
HYD=json.loads((ROOT/(PREFIX+'verification/source-object-hydration.json')).read_bytes());ck(len(HYD['records'])==HYD['objects']==25,'Hydration25exactobjects')
for row in HYD['records']:pins(DATA[row['path']],row,'Hydration '+row['path'])
for row in jget(PREFIX+'reviews/final-pre-review-snapshot-check.json')['checks']:
    b=DATA[PREFIX+'reviews/'+row['snapshot']];ck(sha(b)==row['sha256']==MODS[row['module']]['sha256'],'Pre-review snapshot exact final source: '+row['module'])
VAL=json.loads((ROOT/(PREFIX+'archives/final-independent-validation.json')).read_bytes());ck(sha((ROOT/(PREFIX+'archives/final-independent-manifest.json')).read_bytes())==VAL['manifest_sha256'],'Original validation manifest pin')
ck(len(VAL['comparisons'])==124 and {x['path'] for x in VAL['comparisons']}==set(DATA),'Original restore comparison coverage124')
for row in VAL['comparisons']:pins(DATA[row['path']],row,'Original restore '+row['path']);ck(row['restored_equals_original'],'Recorded exact restore: '+row['path'])
for row in VAL['commands']:ck(row['returncode']==0,'Recorded archival command exit0: '+row['label'])
ck(sha(DATA[PREFIX+'reviews/final-audits.py'])==REPORT['script_sha256'],'Final audit script pin')
ck(sha(DATA[PREFIX+'reviews/final-source-readback.py'])==READ['script_sha256'],'Readback script pin')
ck(sha(DATA[PREFIX+'reviews/final-canonical-run.py'])==RUN['script_sha256'],'Canonical runner script pin')
ck(sha(DATA[PREFIX+'reviews/final-retain-evidence.py'])==INDEX['script_sha256'],'Retain script pin')
ck(sha(DATA[REPORT['extra_compiled_auditor_original']])==REPORT['extra_compiled_auditor_original_sha256'] and DATA[REPORT['extra_compiled_auditor_original']]==DATA[PREFIX+'reviews/final-original-CompiledAudit.lean.txt'],'Prior original compiled auditor exact duplicate')
# Additional exact readback/log and explicit source-public inventory checks.
ck(len(READ['git_commands'])==47,'Exactly47historical Git readback commands')
for c in READ['git_commands']:
    a=c['command']
    if a[1]=='show':
        commit,path=a[2].split(':',1)
        ck(commit in {READ['math_commit'],READ['published_commit']},'Readback selected source commit')
        ck(c['stdout_bytes']==len(DATA[path]) and c['stdout_sha256']==sha(DATA[path]),'Git readback stdout pins: '+a[2])
ck(sha(DATA[READ['metadata_checker']['log']])==READ['metadata_checker']['log_sha256'],'Metadata checker raw log hash')
metadata_result=jget(READ['metadata_checker']['log'])
ck(metadata_result['status']=='METADATA_AND_SOURCE_IDENTITY_CHECK_ONLY' and not metadata_result['lean_invoked'] and not metadata_result['mathematical_proof_check'],'Identity result does not claim Lean proof')
source_exports=[]
for module,rec in exports['modules'].items():
    code=mask(txt(rec['path']))
    ns=re.findall(r'^namespace (\S+)\s*$',code,re.M)
    ck(len(ns)==1 and re.findall(r'^end (\S+)\s*$',code,re.M)==ns,'One explicit namespace for public scan: '+module)
    decls=re.findall(r'^(theorem|def) ([A-Za-z_][\w]*)\b',code,re.M)
    expected=[(d['kind'],d['name']) for d in rec['public_declarations']]
    actual=[(kind,ns[0]+'.'+name) for kind,name in decls]
    ck(actual==expected,'Complete explicit source public inventory: '+module)
    source_exports.extend((module,kind,name) for kind,name in actual)
ck(len(source_exports)==41,'Exactly41 explicit public source declarations')
ck(sha((ROOT/(PREFIX+'archives/final-independent-validation.log')).read_bytes())==VAL['validation_log_sha256'],'Archive original validation rawlog hash')
POLICIES={}
for p,expected in [('AGENTS.md','4b69aabcc41a39104452672da53216066fcaa4b830bd363080250d1bb1aaf2dc'),('proofs/PUBLICATION_POLICY.md','360b603be904354a5ec297ac5f38f2c7a7be9c282f3ea54b34a718e72b78877c')]:
    ck(sha((ROOT/p).read_bytes())==expected,'Read repository policy identity: '+p);POLICIES[p]=expected
RESULT={'status':'PASS_RETAINED_EVIDENCE_INTEGRITY_AND_CENSUS','reviewer':'/root/pr136_evidence','reviewed_head':'429b2c34f2eb27eeeadd15b83036c78181430c03','lean_invoked':False,'archive_code_executed':False,'git_invoked':False,'archive':{'path':PREFIX+'archives/final-independent.tar.gz','bytes':len(archive_bytes),'sha256':sha(archive_bytes),'git_blob':blob(archive_bytes),'member_count':len(DATA),'uncompressed_bytes':sum(map(len,DATA.values()))},'check_count':len(CHECKS),'checks':CHECKS,'current_snapshot_archive_member_comparisons':local_comparisons,'sources':SOURCES,'compiler_recorded':CANON['compiler'],'canonical_command_count':18,'canonical_explicit_trust_zero':False,'extra_explicit_trust_zero_commands':3,'raw_theorem_count':len(THEOREMS),'raw_theorem_counts_by_module':COUNTS,'raw_theorem_axiom_union':sorted(UNION),'raw_public_declaration_count':len(PUB),'raw_public_theorem_count':36,'raw_public_definition_count':5,'raw_safe_definition_count':len(DEFS),'raw_safe_opaque_count':0,'raw_safe_definition_axiom_union':['propext'],'raw_unsafe_implementation_count':len(UNSAFE),'raw_unsafe_implementation_axiom_count':len(UNSAFEAX),'limits':['Review validates retained source, scripts, logs and hashes; it does not create a new Lean execution.','Compiler hashes are retained historical pins; compiler binaries are deliberately outside archive and were not rehashed in this review.','Current H remote Git tree membership and source pins must be established by separate source review; local H comparisons here use the parent-provided snapshot.','Explicit trust0 audit commands import the fresh compiled closure; do not describe them as a second source rebuild or proof-body replay.'],'policy_sha256':POLICIES,'script_sha256':sha(Path(__file__).read_bytes())}
out=Path(__file__).with_name('verification.json');out.write_text(json.dumps(RESULT,indent=2)+'\n')
print(json.dumps({k:v for k,v in RESULT.items() if k not in {'checks','sources','current_snapshot_archive_member_comparisons','compiler_recorded','limits'}},indent=2))
