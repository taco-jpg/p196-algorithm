#!/usr/bin/env python3
"""Independent, non-executing validation of the PR109 compressed evidence."""
import hashlib, io, json, lzma, pathlib, shutil, tarfile
ROOT=pathlib.Path('/workspace/scratch/aa9210d02a75/agent12-review109')
PKG=pathlib.Path('/workspace/scratch/aa9210d02a75/agent12-pr109/proofs/contributions/agent-9/escape-factorial-bound-20261016')
def sha(data): return hashlib.sha256(data).hexdigest()
def verify_file(base,path,entry):
    p=base/path
    assert p.is_file() and not p.is_symlink(), str(p)
    data=p.read_bytes()
    assert len(data)==entry['bytes'] and sha(data)==entry['sha256'], str(p)
    return {'path':str(path),'bytes':len(data),'sha256':sha(data)}
report={'reviewer':'Agent #12 /root/review109','source_head':'18a82d9b5a2bd326751621e3e7a5458117561da7','checks':{},'status':'RUNNING'}
try:
    manifest=json.loads((PKG/'evidence/MANIFEST.json').read_text())
    data=(PKG/manifest['stored_path']).read_bytes()
    assert len(data)==manifest['stored_bytes'] and sha(data)==manifest['stored_sha256']
    raw=lzma.decompress(data)
    assert len(raw)==manifest['uncompressed_tar_bytes'] and sha(raw)==manifest['uncompressed_tar_sha256']
    report['checks']['archive']={'bytes':len(data),'sha256':sha(data),'tar_bytes':len(raw),'tar_sha256':sha(raw)}
    entries={x['original_path']:x for x in manifest['files']}
    assert len(entries)==len(manifest['files'])==manifest['original_files']
    dest=ROOT/'original-evidence';dest.mkdir(exist_ok=False)
    names=[]
    with tarfile.open(fileobj=io.BytesIO(raw)) as archive:
        for member in archive.getmembers():
            path=pathlib.PurePosixPath(member.name)
            assert not path.is_absolute() and '..' not in path.parts and member.name not in names
            assert member.isfile(), (member.name,member.type)
            assert member.name in entries
            payload=archive.extractfile(member).read()
            rec=entries[member.name]
            assert len(payload)==rec['bytes'] and sha(payload)==rec['sha256']
            output=dest/path;output.parent.mkdir(parents=True,exist_ok=True);output.write_bytes(payload)
            names.append(member.name)
    assert set(names)==set(entries)
    assert sum(v['bytes'] for v in entries.values())==manifest['original_payload_bytes']
    report['checks']['extracted_original_files']=[verify_file(dest,n,e) for n,e in entries.items()]
    report['checks']['tracked_duplicates']=[]
    for path in PKG.rglob('*'):
        if path.is_file() and 'evidence' not in path.relative_to(PKG).parts:
            rel=path.relative_to(PKG).as_posix()
            assert rel in entries and path.read_bytes()==(dest/rel).read_bytes(),rel
            report['checks']['tracked_duplicates'].append(rel)
    author=[]
    for line in (dest/'MANIFEST.sha256').read_text().splitlines():
        digest,relative=line.split(None,1);relative=relative.lstrip('*')
        assert sha((dest/relative).read_bytes())==digest,relative
        author.append(relative)
    report['checks']['author_manifest_files']=author
    for m in [dest/'review/runtime-audit/REVIEW_MANIFEST.json',dest/'review/runtime-audit/runs/full-001/EVIDENCE_FILES.json']:
        doc=json.loads(m.read_text()); rows=doc.get('files',doc)
        report['checks'][m.name]=[verify_file(m.parent,n,e) for n,e in rows.items()]
    report['status']='PASS'
except BaseException as error:
    report['status']='FAIL';report['error']=repr(error);raise
finally:
    (ROOT/'evidence-validation.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'status':report['status'],'files':len(names),'author_manifest':len(author),'tracked_duplicates':len(report['checks']['tracked_duplicates'])}))
