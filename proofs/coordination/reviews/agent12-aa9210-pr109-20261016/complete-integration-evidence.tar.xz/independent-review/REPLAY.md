# Reproduce the independent exact-source gate

Use an isolated checkout at PR109 head `18a82d9b5a2bd326751621e3e7a5458117561da7`, retaining the historical Git objects referenced by the registry. Use official Lean 4.19.0 release commit `6caaee842e94`. Runtime installation files and compiled project objects are reproducible infrastructure and are not included in this review packet.

```sh
python3 -B proofs/contributions/agent-9/escape-factorial-bound-20261016/review/runtime-audit/verify.py \
  --repo /absolute/path/to/isolated-checkout \
  --package-root /absolute/path/to/isolated-checkout/proofs/contributions/agent-9/escape-factorial-bound-20261016 \
  --manifest /absolute/path/to/isolated-checkout/proofs/contributions/agent-9/escape-factorial-bound-20261016/review/runtime-audit/source-registry.json \
  --lean /absolute/path/to/lean-4.19.0-linux/bin/lean \
  --output /absolute/path/to/absent-output-directory \
  --auditor 'Actual executing reviewer'
```

The exact invocation, command arguments, environments, exit codes, durations and hashes from this run are in `fresh-replay/verification.json`; full unabridged output is under `fresh-replay/logs/`. The source registry and all eleven mathematical source snapshots, plus the generated audit, are retained. The original authored audit support source was separately compiled against this fresh build; its command and log are in `authored-audit-replay/`. This supplemental audit is not described as a second full-closure replay.

`check-evidence.py` records the safe original-archive validation algorithm; its two source/output root constants can be adjusted for a relocated copy. `evidence-validation.json` records every independently checked original file identity. `original-evidence/` preserves all recovered author and historical reviewer bytes, including the failed attempt. `inputs/package/` preserves the exact directly tracked PR package and original compressed archive.

`FILES.json` inventories every retained review file except itself. It excludes only `fresh-replay/build/`, which holds locally regenerated Lean objects. The driver's own historical `fresh-replay/FILES.json` remains unmodified and therefore still lists build objects present at execution time; this review's top-level manifest and `RETENTION.json` describe the publication packet. No research source, compiler output, failed attempt or audit record is removed.
