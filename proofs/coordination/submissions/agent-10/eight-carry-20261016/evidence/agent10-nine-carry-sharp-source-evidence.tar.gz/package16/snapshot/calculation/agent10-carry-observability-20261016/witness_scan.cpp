#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <map>
#include <string>
#include <vector>

// Exact integer enumeration of all ordered admissible width-11 word pairs
// q-r = [1,-3,5,-6,6,-6,6,-6,5,-3,1].
// Reversing q/r also covers the negated difference without another scan.
// No arbitrary width, trajectory, or search cap is implicit: width is exactly
// 11 and the complete carry words at times 0 through 7 are compared.
using Word = std::vector<int>;

const Word witness{1,-3,5,-6,6,-6,6,-6,5,-3,1};
std::array<std::uint64_t, 9> survived{};
std::array<std::map<std::string,std::uint64_t>, 9> patterns;
std::array<std::vector<std::pair<Word,Word>>, 9> examples;

bool admissible(const Word& q) {
  if(q.empty() || q.front() == 0) return false;
  for(std::size_t i=0; i<q.size(); ++i) {
    if(q[i]<0 || q[i]>18 || q[i]!=q[q.size()-1-i]) return false;
    if(i==q.size()-1-i && q[i]%2 != 0) return false;
  }
  return true;
}

Word carries(const Word& q) {
  Word c(q.size()+1,0);
  for(std::size_t i=0; i<q.size(); ++i) c[i+1]=(q[i]+c[i])/10;
  return c;
}

Word next(const Word& q, const Word& c) {
  Word digits;
  for(std::size_t i=0; i<q.size(); ++i) digits.push_back((q[i]+c[i])%10);
  if(c.back()!=0) digits.push_back(c.back());
  Word result(digits.size());
  for(std::size_t i=0; i<digits.size(); ++i)
    result[i]=digits[i]+digits[digits.size()-1-i];
  assert(admissible(result));
  return result;
}

void inspect(const Word& r) {
  Word q(r.size());
  for(std::size_t i=0; i<r.size(); ++i) q[i]=r[i]+witness[i];
  assert(admissible(q) && admissible(r));
  ++survived[0];
  Word a=q, b=r;
  std::string pattern;
  for(int t=0; t<8; ++t) {
    Word ca=carries(a), cb=carries(b);
    if(ca!=cb) return;
    pattern.push_back(ca.back()==0?'N':'O');
    ++survived[t+1];
    ++patterns[t+1][pattern];
    if(examples[t+1].size()<3) examples[t+1].push_back({q,r});
    if(t!=7) { a=next(a,ca); b=next(b,cb); }
  }
}

void enumerate(Word& r,int i) {
  if(i==6) { inspect(r); return; }
  int lo=std::max(0,-witness[i]);
  int hi=std::min(18,18-witness[i]);
  if(i==0) lo=std::max({lo,1,1-witness[i]});
  for(int v=lo; v<=hi; ++v) {
    if(i==5 && v%2!=0) continue;
    r[i]=r[10-i]=v;
    enumerate(r,i+1);
  }
}

void print_word(const Word& q) {
  std::cout << '[';
  for(std::size_t i=0; i<q.size(); ++i) {
    if(i) std::cout << ',';
    std::cout << q[i];
  }
  std::cout << ']';
}

int main() {
  Word r(11);
  enumerate(r,0);
  assert(survived[0]==4504864);
  std::cout << "{\n  \"width\": 11,\n  \"complete_words_requested\": 8,\n  \"difference\": ";
  print_word(witness);
  std::cout << ",\n  \"candidate_count\": " << survived[0] << ",\n  \"survived_complete_words\": [";
  for(int i=0;i<=8;++i) { if(i)std::cout<<','; std::cout<<survived[i]; }
  std::cout << "],\n  \"history_patterns\": {";
  bool first=true;
  for(int i=1;i<=8;++i) for(const auto& [key,value]:patterns[i]) {
    if(!first) std::cout<<',';
    first=false;
    std::cout << "\n    \"" << key << "\": " << value;
  }
  std::cout << "\n  },\n  \"examples\": {";
  first=true;
  for(int i=1;i<=8;++i) {
    if(examples[i].empty()) continue;
    if(!first) std::cout<<',';
    first=false;
    std::cout << "\n    \"" << i << "\": [";
    bool first_example=true;
    for(const auto& [a,b]:examples[i]) {
      if(!first_example)std::cout<<',';
      first_example=false;
      std::cout << "{\"q\":"; print_word(a);
      std::cout << ",\"r\":"; print_word(b); std::cout << '}';
    }
    std::cout << ']';
  }
  std::cout << "\n  }\n}\n";
}
