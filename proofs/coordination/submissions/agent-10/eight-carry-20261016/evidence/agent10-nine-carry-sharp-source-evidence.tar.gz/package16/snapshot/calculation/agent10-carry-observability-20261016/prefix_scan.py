#!/usr/bin/env python3
"""Exact necessary-prefix experiment. Uses only Python integer arithmetic.

The two-column dynamics copy CarryObservability.next from the pinned
PrefixCarryBound source. A common control bit records the actual incoming
carry at width-2. The weak observation checks low carries at 1 and 2 and the
terminal overflow. The strong observation also checks the high carry at
width-1. Both are necessary for complete carry-word agreement.

An n-observation path checks observations at t=0,...,n-1. Its final transition
is computed but no condition is imposed on the resulting state.
"""

from functools import lru_cache
import json


def observation(state, bit):
    p, q = state
    low_first = p // 10
    low_second = (q + low_first) // 10
    high_inner = (q + bit) // 10
    overflow = (p + high_inner) // 10
    return low_first, low_second, high_inner, overflow


def next_state(state, bit):
    p, q = state
    a, b, u, h = observation(state, bit)
    if h == 0:
        result = (2*p + u - 10*a, 2*q + a + bit - 10*(b+u))
    else:
        result = (p - 10*a + 1, p+q+a+u - 10*(b+h))
    assert 1 <= result[0] <= 18 and 0 <= result[1] <= 18
    return result


def make_path_solver(strong):
    indices = (0, 1, 2, 3) if strong else (0, 1, 3)

    @lru_cache(None)
    def path(length, state, other):
        if length == 0:
            return ()
        for bit in (0, 1):
            left = observation(state, bit)
            right = observation(other, bit)
            if any(left[i] != right[i] for i in indices):
                continue
            tail = path(length-1, next_state(state, bit), next_state(other, bit))
            if tail is not None:
                return (bit,) + tail
        return None

    return path


def main():
    initial = [((p+1, q-3), (p, q)) for p in range(1, 18) for q in range(3, 19)]
    assert len(initial) == 272
    results = {}
    for strong in (False, True):
        path = make_path_solver(strong)
        by_length = {}
        for length in range(1, 9):
            survivors = [
                {"q_prefix": a, "r_prefix": b, "bits": path(length, a, b)}
                for a, b in initial if path(length, a, b) is not None
            ]
            by_length[length] = {
                "surviving_initial_pairs": len(survivors),
                "examples": survivors if length >= 6 else survivors[:1],
            }
        assert by_length[6]["surviving_initial_pairs"] > 0
        assert by_length[7]["surviving_initial_pairs"] == 0
        results["strong" if strong else "weak"] = by_length

    # Structural check: this prefix argument alone does not prove the universal
    # eight-word reconstruction claim. Equal exterior coefficients with second
    # coefficient difference 1 still admit abstract eight-observation paths.
    path = make_path_solver(True)
    interior = [((p, q+1), (p, q)) for p in range(1, 19) for q in range(18)]
    interior_survivors = [
        {"q_prefix": a, "r_prefix": b, "bits": path(8, a, b)}
        for a, b in interior if path(8, a, b) is not None
    ]
    assert len(interior_survivors) == 6
    print(json.dumps({
        "initial_prefix_pairs": len(initial),
        "prefix_difference": [1, -3],
        "carry_observation_times": "0 through n-1",
        "finite_scope": "all 272 valid ordered prefixes with difference (1,-3), every Boolean control path up to 8 observations",
        "results": results,
        "eight_observation_abstract_survivors_with_difference_0_1": interior_survivors,
    }, indent=2))


if __name__ == "__main__":
    main()
