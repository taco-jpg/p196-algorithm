#!/usr/bin/env python3
"""Non-author arithmetic replay and source/log consistency controls.

Run with python3 -B independent_controls.py. Reads only retained snapshots;
writes two small JSON control records beside this script. This is independent
computational corroboration, not a replacement for Lean kernel checking.
"""
from pathlib import Path
import ast
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "sources/Agent10SevenCarryCounterexample.lean"
LOG = ROOT / "evidence/Agent10SevenCarryCounterexample.build.log"
TRACE = ROOT / "evidence/author-integer-replay.json"
EXPECTED_SOURCE = "7cdc32bd5d0eff4174d1d35314ef544a7cf80532868ba38fe664cd063edb67f9"
EXPECTED_LOG = "e2497ea6b4f9539e885c04815c2efef8707153ee5a395a7a11fe2b3105f66739"
EXPECTED_TRACE = "66a13d1fc48a5eba76a1c45000a36f6fa6a5b624a83505249fac2ef5ff98deb6"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def decimal_state(n):
    """Derive columns from an ordinary integer, not from retained trace rows."""
    digits = [int(c) for c in str(n)[::-1]]
    columns = [a + b for a, b in zip(digits, reversed(digits))]
    carries, out_digits = [0], []
    for column in columns:
        total = column + carries[-1]
        carries.append(total // 10)
        out_digits.append(total % 10)
    if carries[-1]:
        out_digits.append(carries[-1])
    reversal = int(str(n)[::-1])
    next_n = n + reversal
    assert sum(d * 10**i for i, d in enumerate(out_digits)) == next_n
    assert len(carries) == len(digits) + 1
    return digits, columns, carries, reversal, next_n


def code_only(text):
    """Mask comments and strings while retaining source positions."""
    out, i, depth, string = [], 0, 0, False
    while i < len(text):
        pair = text[i:i+2]
        if depth:
            if pair == "/-":
                depth += 1; out.extend("  "); i += 2
            elif pair == "-/":
                depth -= 1; out.extend("  "); i += 2
            else:
                out.append("\n" if text[i] == "\n" else " "); i += 1
        elif string:
            if text[i] == "\\":
                out.extend("  "); i += 2
            else:
                string = text[i] != '"'
                out.append("\n" if text[i] == "\n" else " "); i += 1
        elif pair == "/-":
            depth = 1; out.extend("  "); i += 2
        elif pair == "--":
            end = text.find("\n", i)
            end = len(text) if end < 0 else end
            out.extend(" " * (end-i)); i = end
        elif text[i] == '"':
            string = True; out.append(" "); i += 1
        else:
            out.append(text[i]); i += 1
    assert not depth and not string
    return "".join(out)


def main():
    assert sha(SOURCE) == EXPECTED_SOURCE
    assert sha(LOG) == EXPECTED_LOG
    assert sha(TRACE) == EXPECTED_TRACE
    stored = json.loads(TRACE.read_text())
    n, m = 900000058163209, 900000082716109
    actual, widths, equal_times, palindromic = [], [], [], {"n": [], "m": []}
    for t in range(9):
        nd, q, nc, nr, nn = decimal_state(n)
        md, r, mc, mr, mn = decimal_state(m)
        row = {"time": t, "n": str(n), "m": str(m),
               "n_reversal": str(nr), "m_reversal": str(mr),
               "n_next": str(nn), "m_next": str(mn),
               "n_digits_little_endian": nd, "m_digits_little_endian": md,
               "q": q, "r": r, "q_carries": nc, "r_carries": mc,
               "complete_word_match": len(nd) == len(md) and nc == mc}
        assert row == stored["trajectory"][t], (t, row)
        assert len(nd) == len(md)
        widths.append(len(nd))
        if row["complete_word_match"]:
            equal_times.append(t)
        if n == nr:
            palindromic["n"].append(t)
        if m == mr:
            palindromic["m"].append(t)
        actual.append(row)
        n, m = nn, mn
    assert equal_times == list(range(7))
    assert stored["initial_integers"] == [actual[0]["n"], actual[0]["m"]]
    assert stored["initial_pair_words"] == {"q": actual[0]["q"], "r": actual[0]["r"]}
    delta = [a-b for a, b in zip(actual[0]["q"], actual[0]["r"])]
    assert delta == stored["initial_difference"]
    assert stored["matching_complete_words"] == 7
    assert stored["first_mismatch_time"] == 7
    first_indices = [i for i, (a, b) in enumerate(zip(actual[7]["q_carries"], actual[7]["r_carries"])) if a != b]
    assert first_indices[0] == 4
    assert [actual[7]["q_carries"][4], actual[7]["r_carries"][4]] == [1, 0]
    assert [actual[0]["q"][2], actual[0]["r"][2]] == [2, 1]
    assert 2 < widths[0] == 15

    source = SOURCE.read_text()
    right_rows, left_rows = re.search(
        r"private def rows .*?if b then (\[.*?\]) else (\[.*?\])\s*private def trace",
        source, re.S).groups()
    right_rows, left_rows = ast.literal_eval(right_rows), ast.literal_eval(left_rows)
    assert left_rows == [row["q"] for row in actual[:8]]
    assert right_rows == [row["r"] for row in actual[:8]]
    source_widths = ast.literal_eval(re.search(
        r"def traceWidth .*?\((\[[^\]]*\]) : List Nat\)", source, re.S).group(1))
    assert source_widths == widths[:8]
    for side, field in [("left", "n"), ("right", "m")]:
        digits = ast.literal_eval(re.search(
            rf"def {side}Digits .*?\((\[[^\]]*\]) : List Nat\)", source, re.S).group(1))
        assert digits == actual[0][field + "_digits_little_endian"]
    for rows in [left_rows, right_rows]:
        for t in range(7):
            carry, out_digits = 0, []
            for column in rows[t]:
                carry, digit = divmod(column + carry, 10)
                out_digits.append(digit)
            if carry:
                out_digits.append(carry)
            successor = [a+b for a, b in zip(out_digits, reversed(out_digits))]
            assert len(out_digits) == source_widths[t+1]
            assert successor == rows[t+1]

    controls = {
        "status": "PASS",
        "classification": "INDEPENDENT_INTEGER_ARITHMETIC_AND_SOURCE_LITERAL_CONTROL",
        "reviewer": "/root/lean_runtime",
        "source_sha256": EXPECTED_SOURCE,
        "retained_trace_sha256": EXPECTED_TRACE,
        "exact_trajectory_rows_matched": len(actual),
        "exact_trace_fields_matched": sum(len(row) for row in actual),
        "source_pair_rows_matched": 16,
        "source_initial_digit_values_matched": 30,
        "source_adjacent_transitions_matched": 14,
        "source_transition_active_coefficients_matched": 2 * sum(source_widths[1:]),
        "complete_observation_times_equal": equal_times,
        "matched_carry_positions_including_terminal": sum(widths[t]+1 for t in equal_times),
        "widths_t0_through_t8": widths,
        "initial_pair_sums_at_index2": [2, 1],
        "initial_pair_difference": delta,
        "next_integers": [actual[0]["n_next"], actual[0]["m_next"]],
        "first_separating_observation_time": 7,
        "first_separating_carry_index": 4,
        "all_mismatching_indices_at_time7": first_indices,
        "separating_values": [1, 0],
        "palindromic_times_among_checked_states": palindromic,
        "palindromes_at_time2": [actual[2]["n"], actual[2]["m"]],
        "numeric_trajectory": [{k: row[k] for k in ["time", "n", "m", "n_next", "m_next"]} for row in actual],
        "scope": "Unrestricted ordinary reverse-and-add iteration. Both trajectories reach a palindrome at time 2. This witness is neither a palindrome-free lower bound nor an eight-observation collision. Source certificates cover states 0 through 7; the independent arithmetic control additionally replays state 8."
    }
    save("independent-arithmetic.json", controls)

    code = code_only(source)
    forbidden = re.findall(r"(?<![\w'])\b(?:sorry|admit|axiom|sorryAx|native_decide|ofReduceBool|skipKernelTC|unsafe)\b(?![\w'])", code)
    assert not forbidden
    imports = re.findall(r"^import\s+(\S+)", code, re.M)
    assert imports == ["ActualCarryObservability"]
    declarations = []
    for match in re.finditer(r"^(private\s+)?theorem\s+(\w+)\b(.*?)(?=\s*:=)", code, re.M | re.S):
        full_statement = source[match.start():match.end()].strip()
        declarations.append({"name": match.group(2), "private": bool(match.group(1)), "declaration": full_statement})
    assert len(declarations) == 20
    assert sum(not d["private"] for d in declarations) == 14
    prints = re.findall(r"^#print axioms (\S+)\s*$", code, re.M)
    assert len(prints) == len(set(prints)) == 20
    assert set(prints) == {d["name"] for d in declarations}
    pattern = r"^'([^']+)' (?:(does not depend on any axioms)|depends on axioms:\s*\[([^\]]*)\])"
    records = []
    matched_spans = []
    for match in re.finditer(pattern, LOG.read_text(), re.M):
        axioms = [] if match.group(2) else [a.strip() for a in match.group(3).split(",") if a.strip()]
        records.append({"name": match.group(1), "short_name": match.group(1).rsplit(".", 1)[-1], "axioms": axioms})
        matched_spans.append(match.group(0))
    assert len(records) == len({r["name"] for r in records}) == 20
    assert {r["short_name"] for r in records} == set(prints)
    leftover = LOG.read_text()
    for span in matched_spans:
        leftover = leftover.replace(span, "", 1)
    assert not leftover.strip(), leftover
    union = sorted({a for record in records for a in record["axioms"]})
    assert union == ["Quot.sound", "propext"]
    author = json.loads((ROOT / "evidence/author-local-proof-receipt.json").read_text())
    expected_endpoints = {d["name"]: d["declaration"] for d in declarations if not d["private"]}
    assert {e["name"].rsplit(".", 1)[-1]: e["declaration"] for e in author["public_endpoints"]} == expected_endpoints
    audit = {
        "status": "PASS",
        "source_sha256": EXPECTED_SOURCE,
        "log_sha256": EXPECTED_LOG,
        "source_imports": imports,
        "forbidden_shortcut_tokens": forbidden,
        "explicit_source_theorems": len(declarations),
        "public_source_endpoints": len(expected_endpoints),
        "source_print_axioms_commands": len(prints),
        "complete_log_records": len(records),
        "wrapped_axiom_lists_parsed_through_closing_bracket": True,
        "axiom_free_named_theorems": sum(not record["axioms"] for record in records),
        "named_theorem_transitive_axiom_union": union,
        "declarations": declarations,
        "axiom_records": records,
        "limitation": "Covers every explicit theorem declaration in this source and its transitive #print axioms result. This is not an exhaustive environment-origin audit of generated auxiliary declarations, nor a separate Lean execution."
    }
    save("source-log-audit.json", audit)
    print(json.dumps({"status": "PASS", "trace_rows": len(actual), "source_rows": 16,
                      "source_transitions": 14, "complete_carry_positions": controls["matched_carry_positions_including_terminal"],
                      "explicit_theorems": len(declarations), "public_endpoints": len(expected_endpoints),
                      "axiom_free_named_theorems": audit["axiom_free_named_theorems"], "axiom_union": union}))


if __name__ == "__main__":
    main()
