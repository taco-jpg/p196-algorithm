#!/usr/bin/env python3
"""Verify the complete package16 inventory and exact retained bytes."""
from pathlib import Path
import hashlib
import json

HISTORY = 'history/agent10-carry-source-evidence-13.tar.gz'
HISTORY_SHA = '62707211104ecca8935afc26b815a773a71f18ea957906def79a59f9cdb4232a'
FORBIDDEN_SUFFIXES = {'.olean', '.ilean', '.pyc', '.o', '.so', '.a', '.dll', '.exe'}


def verify(root):
    root = Path(root).resolve()
    manifest = json.loads((root / 'FILES.json').read_text())
    expected = {x['path']: x for x in manifest['files']}
    assert len(expected) == len(manifest['files'])
    paths = list(root.rglob('*'))
    assert not any(p.is_symlink() for p in paths)
    actual = {p.relative_to(root).as_posix() for p in paths if p.is_file()}
    assert actual == set(expected) | {'FILES.json'}, (actual - set(expected), set(expected) - actual)
    assert HISTORY in expected
    for relative, record in expected.items():
        p = root / relative
        assert not Path(relative).is_absolute() and '..' not in Path(relative).parts
        data = p.read_bytes()
        assert len(data) == record['bytes'], relative
        assert hashlib.sha256(data).hexdigest() == record['sha256'], relative
        assert p.suffix not in FORBIDDEN_SUFFIXES, relative
        assert '__pycache__' not in p.parts and '.git' not in p.parts, relative
        if relative == HISTORY:
            assert record['sha256'] == HISTORY_SHA
        else:
            assert not data.startswith(b'\x7fELF') and b'\0' not in data, relative
            data.decode('utf-8')
            assert not relative.endswith(('.tar.gz', '.zip', '.gz')), relative
    return {'status': 'PASS', 'manifested_files': len(expected),
            'regular_files_including_manifest': len(actual),
            'manifest_sha256': hashlib.sha256((root / 'FILES.json').read_bytes()).hexdigest(),
            'history_archive_occurrences': sum(p == HISTORY for p in actual),
            'history_archive_sha256': HISTORY_SHA,
            'payload_bytes_including_manifest': sum((root / p).stat().st_size for p in actual)}


if __name__ == '__main__':
    print(json.dumps(verify(Path(__file__).resolve().parent.parent), indent=2))
