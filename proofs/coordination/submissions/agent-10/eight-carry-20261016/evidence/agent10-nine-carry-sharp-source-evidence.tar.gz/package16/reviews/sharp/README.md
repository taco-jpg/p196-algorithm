# Independent review: exact uniform nine-word threshold

**Result: PASS, with no blocking semantic issue found.**

This additive review concerns the parent-authored `Agent10NineCarrySharp.lean`,
frozen at SHA-256
`98e587d22229bdead323dc922b80760cdf79f3b27c14f3a1addaa4df2fb78266`.
The reviewer, `/root/eight_carry_semantics`, did not author or modify that module.
Earlier Agent #10 modules authored by this reviewer are outside this review's
authorship-independence claim.

## Exact result

For each natural observation count `K`, the module proves both equivalences:

- Uniform reconstruction of every active initial pair coefficient from the
  first `K` complete carry words holds if and only if `9 ≤ K`.
- Uniform reconstruction of the next ordinary reverse-and-add integer from the
  first `K` complete carry words holds if and only if `9 ≤ K`.

Both predicates require one common initial width. Every observation covers
indices `0` through the evolving width, including terminal overflow. The existing
`matched_widths` theorem shows why bounding observations by the left trajectory's
width suffices: equality of terminal carries inductively makes the widths agree.
The pair conclusion is restricted to `i < L`; values outside the active input
word are unrestricted. The numeric predicate uses canonical positive decimal
inputs and concludes equality of `Lychrel196.step`, not of the initial integers.

The upper bounds are direct restrictions to the first nine observations of the
unchanged `DifferenceObservability` theorems. For `K < 9`, the lower bounds
restrict the certified width-seventeen example's eight matching observations
to `t < K`. Natural-number arithmetic gives `K ≤ 8`, including the vacuous
observation case `K = 0`. The active discrepancy is at index `3 < 17`, and the
same canonical example has unequal next integers.

Iteration continues after palindromes. The lower-bound example first reaches
palindromes at time four, as explicitly certified in its source. These
equivalences concern the unrestricted iteration predicates written in the
module; they do not establish the same threshold for histories required to
avoid or stop at palindromes. They make no assertion about the orbit of 196.

## Evidence and limits

`review.json` records the semantic checks and their exact source evidence.
`reviewed-endpoint-types.json` retains the reviewed definitions and theorem
signatures. `input-verification.json` records the independently checked source,
import, compiler, and log identities; all nine named axiom reports were parsed.
Their union is exactly `propext`, `Classical.choice`, and `Quot.sound`.

The parent retained a successful direct `--trust=0 -j1 -DElab.async=false`
compilation. This reviewer inspected and verified that receipt and its log;
this review did not run another Lean build. Current `.olean` hashes are recorded
only as artifact identities. The parent's fresh sixteen-module closure audit
is a separate gate and is not asserted by this receipt.

The initial decimal values, index-three pair sums, and next integers were also
recomputed independently in a small arithmetic sanity check. The complete
eight-word counterexample's kernel proof and separate non-author trace review
remain the evidence for its full trajectory; no computational prefix filter is
used by the threshold module.

Run `python3 verify_inputs.py` to repeat the read-only identity, log, and initial
arithmetic checks while the recorded workspace paths remain available. The
script emits JSON and does not write files or invoke Lean. `FILES.json` hashes
every regular file in this review directory except itself.

All prior sources, builds, attempts, reviews, and the frozen thirteen-module
archive were preserved unchanged. This directory is a later, separate receipt
and is not part of the thirteen-module archive.
