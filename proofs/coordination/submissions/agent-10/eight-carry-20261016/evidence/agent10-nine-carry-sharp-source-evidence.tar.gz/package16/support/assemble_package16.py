#!/usr/bin/env python3
"""Assemble package16 from pinned source/evidence, without any proof rebuild.

Preflight performs read-only selection and writes a small inventory outside
the package. Final assembly additionally requires parent-supplied delivery,
patch-application, and publication inputs. Existing packets are never edited.
"""
from collections import Counter
from pathlib import Path
import argparse
import gzip
import hashlib
import io
import json
import runpy
import subprocess
import tarfile
import tempfile

ROOT = Path('/workspace/scratch/4b20b8469eb3')
REPO = ROOT / 'p196-algorithm'
OUT = ROOT / 'agent10-publication-final'
SUPPORT = Path(__file__).resolve().parent
PACKAGE = OUT / 'package16'
ARCHIVE = OUT / 'agent10-nine-carry-sharp-source-evidence.tar.gz'
TESTED = 'f156ea95f4f64609da218632820f71378c815411'
BASELINE = '4b4edf976b2c7a9ba1dad80636c0e21c66350325'
PROJECT = 'agent10-nine-carry-sharp'
REGISTRY = 'proofs/Agent10NineCarrySharp.registry.json'
VERIFIER = 'proofs/verify_project__214bf7673efe116b.py'
HISTORY = 'agent10-carry-source-evidence-13.tar.gz'
HISTORY_SHA = '62707211104ecca8935afc26b815a773a71f18ea957906def79a59f9cdb4232a'
TEXT_SUFFIXES = {'.lean', '.py', '.json', '.log', '.md', '.csv', '.txt',
                 '.patch', '.cpp', '.inc', '.c', '.sh', '.sha256', '.jsonl', '.out'}
PINS = {
    'agent10-eight/canonical-build-004/verification.json': 'a2c608c48f132f355e89b1889f22b6230342cbc20c6b03893ac07cb7dbb9f5d2',
    'agent10-eight/canonical-build-004/FILES.json': '5f14f7946617650c516848a0ff82889b3cc583f2685d4ad2bfefc0afc4452299',
    'agent10-eight/canonical-build-004-specialist-validation.json': '338d7bfad379503ada5d1630f502445cae06340781d46b20bd5acf324c5132ce',
    'agent10-count/validate_canonical_gate_004.py': '81c59a14fe7cfcc8823c674b755d5c070296d37db36017c480eb585073960eb4',
    'agent10-bridge/review-sevencounter/review.json': 'e8b9d6e0ed0541cc1c8d435a9e62f5ea3cfba7b1f9590071ff924f6991e8bfba',
    'agent10-bridge/review-eightcounter/review.json': 'd78e7589e3df159e609151783c68c3d3aa0316d60880eb8fdbce58e646114276',
    'agent10-semantic/review-nine-sharp-001/review.json': '3d21b82016a1523e9347de82973aef1738c5dec0142fa6003ee2cdbfb606ea8e',
    'agent10-semantic/seven_carry_proof_receipt.json': '84b897e2ebd41cae7d2ebb5a9d8e52192cce1f01d3a42a7565a2dac3e2bb1bfc',
    'agent10-count/eight-check-001/verification.json': 'a8d15217f76a963a09a6f5913f57959796181447895a17048fac0be765a62471',
    'agent10-publication-final/source-final-record.json': '46aa43ce060c96f6f5dcf6a79c764d766298123e2e8ac30617f780e05ebebbeb',
    'agent10-publication-final/source-final.patch': '07d37367968e357b81be79f5b1ed608f95671ca4981cf5349b8bd09fb935d226',
    'agent10-publication-final/final-patch-application.json': '13bc0c4bfe0597572ac577c45df645f6c2231b2bba7fc1f8bc116fafe10bacfe',
    'agent10-publication-final/calculation-copy-validation.json': '8cef9508a508cb1c40258b3f1e11505d79cdc9f51ce14775bf5d491210c40762',
    'agent10-calculation-delivery/DELIVERY_VALIDATION.json': 'd3e7754b726fb31049004cc67059e1369e15a1a1032c6c13808d2e6e194d63df',
}
ORIGINAL_FILES = {
    'AGENTS.md': '4b69aabcc41a39104452672da53216066fcaa4b830bd363080250d1bb1aaf2dc',
    VERIFIER: 'c047ff1ff1fe12b2c2094ca5f36af871b1c6faf89db593a102f9c2f7d48cc98a',
}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def json_bytes(value):
    return (json.dumps(value, indent=2, ensure_ascii=False) + '\n').encode()


def git_bytes(commit, path):
    return subprocess.check_output(['git', 'show', f'{commit}:{path}'], cwd=REPO)


def resolve(path):
    path = Path(path)
    return path if path.is_absolute() else ROOT / path


def load_inputs(path, final):
    if path.exists():
        config = json.loads(path.read_text())
    else:
        config = {}
    config.setdefault('final_delivery_commit', None)
    config.setdefault('source_record', 'agent10-publication-final/source-final-record.json')
    config.setdefault('source_patch', 'agent10-publication-final/source-final.patch')
    config.setdefault('patch_application', 'agent10-publication-final/final-patch-application.json')
    config.setdefault('final_report', 'proofs/Agent10NineCarrySharp.md')
    config.setdefault('publication_records', [
        'agent10-publication-final/publication-sharp-source-readback.json',
        'agent10-publication-final/archive13-published-readback.json'])
    config.setdefault('additional_delivery_records', [
        'agent10-publication-final/sharp-source-checkpoint.json'])
    config.setdefault('additional_source_paths', [])
    config.setdefault('additional_evidence_files', [])
    if final:
        assert config['final_delivery_commit'], 'Final documentation commit is required'
        assert config.get('parent_final_inputs_complete') is True, 'Parent final-input handoff is required'
        for key in ['source_record', 'source_patch', 'patch_application']:
            assert resolve(config[key]).is_file(), key
    return config


def select(config, final):
    entries, exclusions, validations = {}, [], {}

    def put(dest, data, category, origin, binary_history=False):
        dest = Path(dest).as_posix()
        assert not Path(dest).is_absolute() and '..' not in Path(dest).parts, dest
        assert dest not in entries, 'Duplicate destination: ' + dest
        assert Path(dest).suffix not in {'.olean', '.ilean', '.pyc', '.o', '.so', '.a', '.dll', '.exe'}, dest
        assert '__pycache__' not in Path(dest).parts and '.git' not in Path(dest).parts, dest
        if binary_history:
            assert dest == 'history/' + HISTORY and sha(data) == HISTORY_SHA
        else:
            assert not data.startswith(b'\x7fELF') and b'\0' not in data, dest
            data.decode('utf-8')
        entries[dest] = {'data': data, 'bytes': len(data), 'sha256': sha(data),
                         'category': category, 'origin': str(origin)}

    def add_file(path, dest, category, binary_history=False):
        path = Path(path)
        assert path.is_file() and not path.is_symlink(), path
        put(dest, path.read_bytes(), category, path, binary_history)

    def add_tree(path, dest, category):
        path = Path(path)
        assert path.is_dir(), path
        for p in sorted(path.rglob('*')):
            assert not p.is_symlink(), p
            if not p.is_file():
                continue
            if '__pycache__' in p.parts or p.suffix not in TEXT_SUFFIXES:
                exclusions.append({'path': str(p), 'reason': 'compiled artifact, cache, or unselected binary extension'})
                continue
            add_file(p, Path(dest) / p.relative_to(path), category)

    for rel, expected in PINS.items():
        assert sha((ROOT / rel).read_bytes()) == expected, rel
    history = OUT / HISTORY
    assert sha(history.read_bytes()) == HISTORY_SHA
    with tarfile.open(history) as tf:
        members = tf.getmembers()
        assert all(m.isfile() for m in members)
        assert all(not m.name.endswith(('.olean', '.ilean', '.pyc')) for m in members)
        assert all('__pycache__' not in m.name and '..' not in Path(m.name).parts for m in members)
        validations['historical_archive'] = {'sha256': HISTORY_SHA, 'bytes': history.stat().st_size,
                                             'regular_file_count': len(members), 'expanded_to_disk': False}
    add_file(history, 'history/' + HISTORY, 'unchanged-thirteen-module-archive-once', True)

    registry_data = git_bytes(TESTED, REGISTRY)
    registry = json.loads(registry_data)
    modules = registry['projects'][PROJECT]['modules']
    assert len(modules) == 16
    canonical = ROOT / 'agent10-eight/canonical-build-004'
    report = json.loads((canonical / 'verification.json').read_text())
    pr = report['projects'][PROJECT]
    assert report['source_commit'] == TESTED and report['status'] == pr['status'] == 'PASS'
    assert report['registry_sha256'] == sha(registry_data)
    assert len(pr['commands']) == 17 and all(c['exit_code'] == 0 for c in pr['commands'])
    assert pr['theorem_count'] == 1345 and len(pr['endpoints']) == 122
    canonical_manifest = json.loads((canonical / 'FILES.json').read_text())
    assert len(canonical_manifest) == 35
    for relative, expected in canonical_manifest.items():
        data = (canonical / relative).read_bytes()
        assert len(data) == expected['bytes'] and sha(data) == expected['sha256'], relative
    validations['canonical004_manifest'] = {'entries': 35, 'all_bytes_matched': True,
        'source_commit': TESTED, 'theorem_origins': 1345, 'public_endpoints': 122,
        'successful_commands': 17, 'verifier_inherited_agent_field': report['agent'],
        'actual_build_executor': 'Agent #10 parent /root', 'new_lean_execution': False}

    delivery = config['final_delivery_commit'] or TESTED
    final_record = None
    if final:
        final_record = json.loads(resolve(config['source_record']).read_text())
        assert final_record['source_baseline'] == BASELINE
        assert final_record['tested_proof_commit'] == TESTED
        assert final_record['local_delivery_commit'] == delivery
        assert final_record['all_changes_additive'] is True
        patch = resolve(config['source_patch']).read_bytes()
        assert sha(patch) == final_record['patch_sha256']
        assert len(patch) == final_record['patch_bytes']
        application = json.loads(resolve(config['patch_application']).read_text())
        assert application['status'] == 'PASS'
        assert application['patch_sha256'] == final_record['patch_sha256']
        assert application['local_delivery_commit'] == delivery
        assert application['tested_proof_commit'] == TESTED
        assert len(application['checks']) == 2
        added_paths = final_record['added_paths']
        assert len(added_paths) == len(set(added_paths)) == 112
        assert config['final_report'] in added_paths
        for run in application.get('checks', []):
            assert run['status'] == 'PASS' and run['all_changes_additive']
            assert {r['path'] for r in run['added_files']} == set(added_paths)
            assert len(run['verified_module_pins']) == 16
            for rec in run.get('added_files', []):
                data = git_bytes(delivery, rec['path'])
                assert sha(data) == rec['sha256'] and len(data) == rec['bytes']
        validations['final_patch'] = {'sha256': sha(patch), 'bytes': len(patch),
            'application_status': application['status'], 'added_paths': added_paths}
    else:
        added_paths = json.loads((OUT / 'patch-source.json').read_text())['added_paths']
    snapshot_paths = set(added_paths) | {r['path'] for r in modules.values()} | set(ORIGINAL_FILES) | {REGISTRY}
    snapshot_paths.update(config['additional_source_paths'])
    for path in sorted(snapshot_paths):
        data = git_bytes(delivery, path)
        category = 'delivery-source-documentation-or-calculation'
        if path in ORIGINAL_FILES:
            assert sha(data) == ORIGINAL_FILES[path]
            assert data == git_bytes(BASELINE, path) == git_bytes(TESTED, path)
            category = 'unchanged-original-verifier-or-repository-rules'
        put('snapshot/' + path, data, category, f'git:{delivery}:{path}')
    assert entries['snapshot/' + REGISTRY]['data'] == registry_data
    pinned_modules = []
    for name, pin in modules.items():
        data = entries['snapshot/' + pin['path']]['data']
        tested_data = git_bytes(TESTED, pin['path'])
        build_data = (canonical / PROJECT / 'source' / (name + '.lean')).read_bytes()
        assert data == tested_data == build_data
        assert sha(data) == pin['sha256'] == pr['sources'][name]['sha256']
        assert hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest() == pin['git_blob']
        if name in {'Lychrel196Research', 'PrefixCarryBound', 'ActualCarryObservability', 'DifferenceObservability'}:
            assert data == git_bytes(BASELINE, pin['path'])
        pinned_modules.append({'module': name, **pin, 'tested_delivery_and_build_bytes_equal': True})
    validations['kernel_modules'] = pinned_modules
    validations['original_unchanged_files'] = ORIGINAL_FILES
    validations['snapshot_file_count'] = len(snapshot_paths)
    if final:
        copied = json.loads((OUT / 'calculation-copy-validation.json').read_text())
        staged = json.loads((ROOT / 'agent10-calculation-delivery/DELIVERY_VALIDATION.json').read_text())
        assert copied['status'] == staged['status'] == 'PASS'
        assert copied['files_copied'] == staged['payload_file_count_including_manifest'] == 82
        target = copied['target']
        calc_manifest_bytes = entries['snapshot/' + target + '/FILES.json']['data']
        assert sha(calc_manifest_bytes) == copied['manifest_sha256'] == staged['manifest_sha256']
        calc_manifest = json.loads(calc_manifest_bytes)
        assert len(calc_manifest['files']) == 81
        calc_total = len(calc_manifest_bytes)
        for relative, rec in calc_manifest['files'].items():
            data = entries['snapshot/' + relative]['data']
            assert len(data) == rec['bytes'] and sha(data) == rec['sha256']
            stage_path = Path(staged['payload_directory']) / Path(relative).relative_to(target)
            assert data == stage_path.read_bytes()
            calc_total += len(data)
        assert calc_total == copied['bytes'] == staged['payload_total_bytes_including_manifest'] == 538405
        validations['final_calculation_copy'] = {'files_including_manifest': 82,
            'payload_entries_validated': 81, 'all_staged_committed_and_manifested_bytes_equal': True,
            'total_bytes': calc_total, 'manifest_sha256': sha(calc_manifest_bytes)}

    add_tree(canonical, 'canonical/canonical-build-004', 'fresh-sixteen-module-canonical-build-retained-evidence')
    add_file(ROOT / 'agent10-eight/canonical-build-004-specialist-validation.json',
             'validation/canonical-build-004-specialist-validation.json', 'internal-retained-output-validation')
    add_file(ROOT / 'agent10-count/validate_canonical_gate_004.py',
             'validation/validate_canonical_gate_004.py', 'unchanged-retained-output-validator-source')

    semantic = ROOT / 'agent10-semantic'
    for name in ['Agent10SevenCarryCounterexample.lean', 'Agent10SevenCarryCounterexample.build.log',
                 'seven_carry_proof_receipt.json', 'SEVEN_CARRY_CERTIFICATE.md']:
        add_file(semantic / name, 'microbuilds/seven/' + name, 'preserved-seven-local-kernel-build')
    add_tree(ROOT / 'agent10-count/eight-check-001', 'microbuilds/eight-check-001',
             'preserved-eight-local-kernel-build-and-module-audit')
    add_tree(ROOT / 'agent10-sharp/build-001', 'microbuilds/sharp-build-001',
             'preserved-sharp-local-kernel-build')
    add_tree(ROOT / 'agent10-bridge/review-sevencounter', 'reviews/seven', 'internal-non-author-seven-review')
    add_tree(ROOT / 'agent10-bridge/review-eightcounter', 'reviews/eight', 'internal-non-author-eight-review')
    add_tree(semantic / 'review-nine-sharp-001', 'reviews/sharp', 'internal-non-author-sharp-review')
    add_tree(semantic / 'twice-padded-width15-001', 'computations/width15',
             'preserved-width15-filtered-discovery-and-ordinary-replay')
    add_tree(ROOT / 'agent10-count/thrice-padded-width17-001', 'computations/width17',
             'preserved-width17-filtered-discovery-and-ordinary-replay')
    for rel in config['publication_records']:
        add_file(resolve(rel), Path('publication') / Path(rel).name, 'publication-readback-predating-final-archive')
    for rel in config['additional_delivery_records']:
        add_file(resolve(rel), Path('delivery') / Path(rel).name, 'delivery-checkpoint-and-transport-provenance')
    for item in config['additional_evidence_files']:
        add_file(resolve(item['source']), item['destination'], item['category'])
    if final:
        for key, name in [('source_patch', 'source-final.patch'),
                          ('source_record', 'source-final-record.json'),
                          ('patch_application', 'final-patch-application.json')]:
            add_file(resolve(config[key]), 'delivery/' + name, 'final-additive-patch-and-application-evidence')
    for name in ['assemble_package16.py', 'repack.py', 'verify_package.py', 'README.template.md']:
        add_file(SUPPORT / name, 'support/' + name, 'package-assembly-and-integrity-source-no-proof-rebuild')
    put('support/assembly-inputs.json', json_bytes(config), 'final-assembly-input-handoff', 'parent-supplied final input selection')
    readme = (SUPPORT / 'README.template.md').read_text()
    readme = readme.replace('@@DELIVERY_COMMIT@@', config['final_delivery_commit'] or 'PENDING_FINAL_HANDOFF')
    readme = readme.replace('@@PATCH_SHA256@@', final_record['patch_sha256'] if final else 'PENDING_FINAL_PATCH')
    readme = readme.replace('@@SNAPSHOT_COUNT@@', str(len(snapshot_paths)))
    put('README.md', readme.encode(), 'package-scope-and-source-reproduction-instructions', 'support/README.template.md')
    return entries, exclusions, validations


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--inputs', type=Path, default=OUT / 'assembly16-inputs.json')
    parser.add_argument('--assemble', action='store_true')
    parser.add_argument('--final-preflight', action='store_true')
    args = parser.parse_args()
    complete_inputs = args.assemble or args.final_preflight
    config = load_inputs(args.inputs, complete_inputs)
    entries, exclusions, validations = select(config, complete_inputs)
    total = sum(e['bytes'] for e in entries.values())
    conservative_peak = 3 * total + 2_000_000
    counts = Counter(e['category'] for e in entries.values())
    preflight = {'status': 'READY_TO_ASSEMBLE' if complete_inputs else 'PREFLIGHT_PASS_WAITING_FOR_FINAL_HANDOFF',
        'tested_commit': TESTED, 'final_delivery_commit': config['final_delivery_commit'],
        'selected_files_before_manifest_and_provenance': len(entries),
        'selected_payload_bytes': total, 'conservative_peak_new_disk_bytes': conservative_peak,
        'disk_planning_target_bytes': 15_000_000, 'planning_target_is_blocking_requirement': False,
        'category_counts': dict(sorted(counts.items())),
        'binary_cache_exclusions': exclusions, 'validations': validations,
        'pending_parent_inputs': [] if complete_inputs else ['final delivery commit', 'final source patch/record',
            'final patch-application receipt', 'final report and staged calculation commit', 'final publication selection'],
        'new_lean_execution': False, 'files': {p: {k: v for k, v in e.items() if k != 'data'} for p, e in sorted(entries.items())}}
    preflight_path = OUT / ('package16-final-preflight.json' if complete_inputs else 'package16-preflight.json')
    preflight_path.write_bytes(json_bytes(preflight))
    if not args.assemble:
        print(json.dumps({k: preflight[k] for k in ['status', 'selected_files_before_manifest_and_provenance',
            'selected_payload_bytes', 'conservative_peak_new_disk_bytes', 'pending_parent_inputs']}))
        return
    assert not PACKAGE.exists(), 'Refusing to overwrite existing package16'
    assert not ARCHIVE.exists(), 'Refusing to overwrite existing final archive'
    provenance = {'schema_version': 1, 'scope': 'final sixteen-module exact uniform nine-observation threshold source/evidence',
        'source_baseline': BASELINE, 'tested_proof_commit': TESTED,
        'final_delivery_commit': config['final_delivery_commit'], 'source_snapshot_files': validations['snapshot_file_count'],
        'validation': validations, 'preserved_input_pins': PINS, 'binary_cache_exclusions': exclusions,
        'new_lean_build_performed': False, 'new_patch_application_performed': False,
        'new_git_commit_created': False, 'reproduction_git_identity': 'A future disposable snapshot commit is synthetic and differs from the original tested commit.',
        'external_github_approval': False, 'file_origins': preflight['files']}
    entries['PROVENANCE.json'] = {'data': json_bytes(provenance)}
    for relative, item in sorted(entries.items()):
        p = PACKAGE / relative
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_bytes(item['data'])
    manifest = {'schema_version': 1, 'files': [
        {'path': p.relative_to(PACKAGE).as_posix(), 'bytes': p.stat().st_size, 'sha256': sha(p.read_bytes())}
        for p in sorted(PACKAGE.rglob('*')) if p.is_file()]}
    (PACKAGE / 'FILES.json').write_bytes(json_bytes(manifest))
    verify = runpy.run_path(str(SUPPORT / 'verify_package.py'))['verify']
    archive_bytes = runpy.run_path(str(SUPPORT / 'repack.py'))['archive_bytes']
    verified = verify(PACKAGE)
    data = archive_bytes(PACKAGE)
    assert archive_bytes(PACKAGE) == data, 'Deterministic repack mismatch'
    with tempfile.TemporaryDirectory(prefix='package16-extraction-check-', dir=OUT) as tmp:
        temp_root = Path(tmp)
        with tarfile.open(fileobj=io.BytesIO(data), mode='r:gz') as tf:
            names = []
            for member in tf.getmembers():
                name = Path(member.name)
                assert member.isfile() and not name.is_absolute() and '..' not in name.parts
                assert name.parts[0] == 'package16'
                assert member.name not in names
                names.append(member.name)
                p = temp_root / name
                p.parent.mkdir(parents=True, exist_ok=True)
                p.write_bytes(tf.extractfile(member).read())
            assert names == sorted(names, key=Path)
        extracted = verify(temp_root / 'package16')
        assert extracted == verified
        for p in PACKAGE.rglob('*'):
            if p.is_file():
                assert p.read_bytes() == (temp_root / 'package16' / p.relative_to(PACKAGE)).read_bytes()
        extraction_bytes = sum(p.stat().st_size for p in temp_root.rglob('*') if p.is_file())
    ARCHIVE.write_bytes(data)
    (OUT / (ARCHIVE.name + '.sha256')).write_text(sha(data) + '  ' + ARCHIVE.name + '\n')
    for rel, expected in PINS.items():
        assert sha((ROOT / rel).read_bytes()) == expected, rel
    assert sha((OUT / HISTORY).read_bytes()) == HISTORY_SHA
    receipt = {'schema_version': 1, 'status': 'PASS', 'assembler': '/root/lean_runtime',
        'archive': str(ARCHIVE), 'archive_sha256': sha(data), 'archive_bytes': len(data),
        **verified, 'tested_proof_commit': TESTED, 'final_delivery_commit': config['final_delivery_commit'],
        'archive_regular_file_count': len(manifest['files']) + 1,
        'deterministic_repack_byte_equality': True, 'extraction_inventory_and_every_file_byte_equality': True,
        'temporary_extraction_removed': True, 'package_and_archive_disk_bytes': verified['payload_bytes_including_manifest'] + len(data),
        'package_archive_and_temporary_extraction_peak_payload_bytes': verified['payload_bytes_including_manifest'] + len(data) + extraction_bytes,
        'prior_archive_and_review_pins_preserved': True, 'new_lean_build_performed': False,
        'new_git_commit_created': False, 'remote_actions_performed': False,
        'receipt_outside_archive_to_avoid_self_reference': True}
    (OUT / 'archive16-verification.json').write_bytes(json_bytes(receipt))
    print(json.dumps(receipt, indent=2))


if __name__ == '__main__':
    main()
