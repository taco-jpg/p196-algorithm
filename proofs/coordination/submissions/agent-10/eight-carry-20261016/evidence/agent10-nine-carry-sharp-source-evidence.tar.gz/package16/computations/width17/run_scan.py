#!/usr/bin/env python3
"""Compile and run the small-output exact filtered width-17 lift."""
from collections import Counter
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from replay_ordinary_integers import replay_pair

HERE = Path(__file__).resolve().parent
FIRST = HERE/'first_eight_collision.json'


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def announce_pair():
    pair = json.loads(FIRST.read_text())
    replay = replay_pair(pair,8)
    target = HERE/'first_eight_integer_replay.json'
    target.write_text(json.dumps(replay,indent=2)+'\n')
    print(json.dumps({
        'notice':'ACTUAL_EIGHT_WORD_MATCH_INDEPENDENTLY_REPLAYED',
        'initial_pair_words':pair, 'initial_integers':replay['initial_integers'],
        'next_integers':replay['next_integers'],
        'first_mismatch_time':replay['first_mismatch_time'],
        'first_mismatch_indices':replay['first_mismatch_indices'],
        'trace_path':str(target),'trace_sha256':sha(target),
    }),flush=True)


def run_record(label,command,output,watch_collision=False):
    started = time.monotonic()
    announced = False
    with (HERE/output).open('xb') as stdout,(HERE/(label+'.stderr.log')).open('xb') as stderr:
        child = subprocess.Popen(command,cwd=HERE,stdout=stdout,stderr=stderr)
        while True:
            pid,status,usage = os.wait4(child.pid,os.WNOHANG)
            if watch_collision and FIRST.exists() and not announced:
                # The C++ writer closes this tiny file before flushing its notice.
                # Wait for complete JSON if this poll overlaps that write.
                try:
                    announce_pair()
                    announced = True
                except json.JSONDecodeError:
                    pass
            if pid:
                child.returncode = os.waitstatus_to_exitcode(status)
                break
            time.sleep(0.05)
    if watch_collision and FIRST.exists() and not announced:
        announce_pair()
    record = {
        'command':command,'cwd':str(HERE),'exit_code':child.returncode,
        'elapsed_seconds':time.monotonic()-started,
        'user_cpu_seconds':usage.ru_utime,'system_cpu_seconds':usage.ru_stime,
        'peak_child_rss_kib':usage.ru_maxrss,
        'stdout':output,'stderr':label+'.stderr.log',
        'stdout_sha256':sha(HERE/output),'stderr_sha256':sha(HERE/(label+'.stderr.log')),
    }
    (HERE/(label+'.command.json')).write_text(json.dumps(record,indent=2)+'\n')
    assert child.returncode == 0, record
    return record


assert sha(HERE/'survivors-5.csv') == '3b310524a4436c062eb66926dea3e78e6d15af7e4b9564ff6478fad5abe2bf3a'
assert sha(HERE/'actual_simulator.inc') == 'e2bd06376e0f2309ec80e0a5ad3b1e5468e9f612fa72f3b79a4448205ac5f349'
compiler = subprocess.run(['/usr/bin/g++','--version'],capture_output=True,text=True,check=True)
(HERE/'compiler-version.txt').write_text(compiler.stdout)
compile_record = run_record('compile',['/usr/bin/g++','-std=c++17','-O3','-Wall','-Wextra','-Werror',
    'thrice_padded_witness_scan.cpp','-o','thrice_padded_witness_scan'],'compile.stdout.log')
scan_record = run_record('scan',['./thrice_padded_witness_scan','survivors-5.csv',str(FIRST)],
    'result.json',watch_collision=True)
result = json.loads((HERE/'result.json').read_text())
counts = result['survivors_after_prefix_filter_and_n_complete_words']
assert result['width'] == 17 and result['complete_words_requested'] == 8
assert result['full_domain_prefix_count'] == 1871424
assert result['filtered_prefix_count'] == 1326
assert result['extensions_per_filtered_prefix'] == 16562
assert result['full_admissible_domain_before_filter'] == 30994524288
assert len(counts) == 9 and counts[0] == 21961212
assert all(a >= b for a,b in zip(counts,counts[1:]))
assert result['filter_actual_inclusion_formalized_in_Lean'] is False
assert result['first_CSV_bit_path_restricts_actual_scan'] is False
pattern_counts = Counter()
for pattern,count in result['history_patterns'].items():
    assert set(pattern) <= {'N','O'}
    pattern_counts[len(pattern)] += count
for i in range(1,9):
    assert pattern_counts[i] == counts[i]
assert FIRST.exists() == bool(counts[8])
strongest = max(i for i,count in enumerate(counts) if count)
sample_replay = None
if strongest:
    sample = result['examples_by_matched_word_count'][str(strongest)][0]
    sample_replay = replay_pair(sample,strongest)
    if strongest < 8:
        assert sample_replay['first_mismatch_time'] == strongest
    (HERE/'strongest_sample_integer_replay.json').write_text(json.dumps(sample_replay,indent=2)+'\n')
v = os.statvfs(HERE)
receipt = {
    'status':'PASS', 'recorded_at_utc':datetime.now(timezone.utc).isoformat(),
    'executor':'Agent #10 specialist /root/formalization_scout',
    'classification':'exact exhaustive actual-word computation inside the complete computational five-prefix filter; no Lean theorem',
    'width':17,'observations':8,'prefix_filter_inclusion_formalized_in_Lean':False,
    'CSV_sample_bits_restrict_actual_trajectories':False,
    'simulator_reused_unchanged_sha256':sha(HERE/'actual_simulator.inc'),
    'filtered_prefixes':1326,'extensions_per_prefix':16562,
    'enumerated_completions':counts[0],
    'full_domain_count_before_filter':30994524288,
    'survivors_after_filter_and_0_to_8_words':counts,
    'eight_word_collisions_inside_filter':counts[8],
    'strongest_sample_initial_integers':sample_replay['initial_integers'] if sample_replay else None,
    'strongest_sample_first_separation':sample_replay['first_mismatch_time'] if sample_replay else None,
    'first_eight_match_replayed_immediately':FIRST.exists(),
    'commands':[compile_record,scan_record],
    'free_bytes_after_run':v.f_bfree*v.f_frsize,
    'unreserved_available_bytes_after_run':v.f_bavail*v.f_frsize,
    'scope':'All 21,961,212 symmetric center-even width-17 completions of the 1,326-prefix filter; computational full-family exclusion additionally uses correctness and completeness of the unformalized necessary projection. Any positive ordinary-integer replay is independently concrete.',
}
receipt['hashes'] = {p.name:{'sha256':sha(p),'bytes':p.stat().st_size}
    for p in sorted(HERE.iterdir()) if p.is_file()}
receipt['retained_top_level_artifact_bytes_before_receipt'] = sum(x['bytes'] for x in receipt['hashes'].values())
(HERE/'lift_verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['status','survivors_after_filter_and_0_to_8_words',
    'eight_word_collisions_inside_filter','strongest_sample_initial_integers',
    'strongest_sample_first_separation','retained_top_level_artifact_bytes_before_receipt']},indent=2),flush=True)
print('receipt_sha256='+sha(HERE/'lift_verification.json'),flush=True)
