#!/usr/bin/env python3
"""Stage and check the additive eight-carry certificate without source mutation."""
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import time

ROOT = Path('/workspace/scratch/4b20b8469eb3')
HERE = ROOT/'agent10-count'
SOURCE = HERE/'Agent10EightCarryCounterexample.lean'
OUT = HERE/'eight-check-001'
DEP = ROOT/'agent10-eight/canonical-build-003/agent10-two-pair-reconstruction/source'
LEAN = '/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean'
MODULE = 'Agent10EightCarryCounterexample'
OUT.mkdir(exist_ok=False)
(OUT/'source').mkdir()
(OUT/'logs').mkdir()


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


source_bytes = SOURCE.read_bytes()
shutil.copy2(SOURCE,OUT/'source'/SOURCE.name)
shutil.copy2(Path(__file__),OUT/Path(__file__).name)
trace = HERE/'thrice-padded-width17-001/first_eight_integer_replay.json'
shutil.copy2(trace,OUT/'integer-replay-input.json')
assert sha(trace) == 'b53c756862d5ad9d64fff1111ce2a29ef8265e8267c1111e5e9594a98aea73f6'
dep_pins = {p.name:sha(p) for name in ['Lychrel196Research','PrefixCarryBound','ActualCarryObservability']
            for p in [DEP/(name+'.lean'),DEP/(name+'.olean')]}
assert dep_pins['Lychrel196Research.lean'] == 'f8950d138fa4231b536059e2334d36b6496de3d25a806f4cf3925941aa05144c'
env = os.environ.copy()
env['LEAN_PATH'] = str(OUT/'source')+':'+str(DEP)
version = subprocess.run([LEAN,'--version'],capture_output=True,text=True,check=True,env=env)
(OUT/'lean-version.txt').write_text(version.stdout)
assert '4.19.0' in version.stdout


def run_lean(label):
    command = [LEAN,'--trust=0','-j1','-DElab.async=false','-o',label+'.olean',label+'.lean']
    started = time.monotonic()
    with (OUT/'logs'/(label+'.log')).open('xb') as log:
        child = subprocess.Popen(command,cwd=OUT/'source',env=env,stdout=log,stderr=subprocess.STDOUT)
        _,status,usage = os.wait4(child.pid,0)
        child.returncode = os.waitstatus_to_exitcode(status)
    rec = {'label':label,'command':command,'cwd':str(OUT/'source'),
        'LEAN_PATH':env['LEAN_PATH'],'exit_code':child.returncode,
        'elapsed_seconds':time.monotonic()-started,'user_cpu_seconds':usage.ru_utime,
        'system_cpu_seconds':usage.ru_stime,'peak_child_rss_kib':usage.ru_maxrss,
        'source_sha256':sha(OUT/'source'/(label+'.lean')),
        'log_sha256':sha(OUT/'logs'/(label+'.log'))}
    (OUT/(label+'.command.json')).write_text(json.dumps(rec,indent=2)+'\n')
    return rec


build = run_lean(MODULE)
base_receipt = {
    'executor':'Agent #10 specialist /root/formalization_scout',
    'source_path':str(SOURCE),'source_sha256':sha(SOURCE),
    'dependency_source_and_olean_origin':str(DEP),'dependency_pins':dep_pins,
    'commands':[build],'integer_replay_sha256':sha(trace),
}
if build['exit_code']:
    base_receipt['status']='FAIL'
    (OUT/'verification.json').write_text(json.dumps(base_receipt,indent=2)+'\n')
    print(json.dumps(base_receipt,indent=2),flush=True)
    raise SystemExit(build['exit_code'])

public = re.findall(r'^theorem (\S+)',source_bytes.decode(),re.M)
assert len(public)==16 and len(set(public))==16
endpoints = [MODULE+'.'+name for name in public]
previous_audit = (HERE/'six-check-003/source/SixCarryAudit.lean').read_text()
audit_body = previous_audit[previous_audit.index('run_cmd do'):].replace('Agent10SixCarryCounterexample',MODULE)
audit_source = 'import '+MODULE+'\nimport Lean\nopen Lean Elab Command\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\n\n'
audit_source += '\n'.join('#check '+endpoint for endpoint in endpoints)+'\n\n'+audit_body
(OUT/'source/EightCarryAudit.lean').write_text(audit_source)
audit_command = run_lean('EightCarryAudit')
base_receipt['commands'].append(audit_command)
if audit_command['exit_code']:
    base_receipt['status']='FAIL_AUDIT'
    (OUT/'verification.json').write_text(json.dumps(base_receipt,indent=2)+'\n')
    print(json.dumps(base_receipt,indent=2),flush=True)
    raise SystemExit(audit_command['exit_code'])

audit=(OUT/'logs/EightCarryAudit.log').read_text()
log=(OUT/'logs'/(MODULE+'.log')).read_text()
records=re.findall(r'^AUDIT_THEOREM (\S+) (\S+) :\s*(\[[^\]]*\])',audit,re.M)
headers=re.findall(r'^AUDIT_THEOREM (\S+) (\S+) :',audit,re.M)
summary=re.findall(r'^FULL_MODULE_AUDIT theorems=(\d+) union=(\[[^\]]*\])$',audit,re.M)
assert len(summary)==1
assert len(records)==len(headers)==int(summary[0][0])
assert len({name for _,name,_ in records})==len(records)
assert all(mod==MODULE for mod,_,_ in records)
parse_axioms=lambda s:sorted(x.strip() for x in s.strip()[1:-1].split(',') if x.strip())
by_name={name:parse_axioms(axs) for _,name,axs in records}
union=set().union(*(set(v) for v in by_name.values()))
assert union==set(parse_axioms(summary[0][1]))=={'propext','Quot.sound'}
assert not re.search(r'^(CUSTOM_AXIOM|DISALLOWED_AXIOMS|UNSAFE_IMPLEMENTATION_AXIOM)',audit,re.M)
assert not re.search(r'error:|declaration uses .sorry.|sorryAx|native_decide',log+audit)
positions=[]
audit_start=audit.index('AUDIT_THEOREM ')
for endpoint in endpoints:
    matches=list(re.finditer(r'^'+re.escape(endpoint)+r'(?=\s|:)',audit,re.M))
    assert len(matches)==1 and matches[0].start()<audit_start,endpoint
    positions.append(matches[0].start())
assert positions==sorted(positions)
endpoint_records=[]
for index,endpoint in enumerate(endpoints):
    end=positions[index+1] if index+1<len(positions) else audit_start
    type_output=audit[positions[index]:end].strip()
    printed=re.findall(r"^'"+re.escape(endpoint)+r"' (?:depends on axioms:\s*(\[[^\]]*\])|does not depend on any axioms)",log,re.M)
    assert len(printed)==1 and parse_axioms(printed[0] or '[]')==by_name[endpoint],endpoint
    assert source_bytes.decode().count('#print axioms '+endpoint.split('.')[-1]+'\n')==1
    endpoint_records.append({'name':endpoint,'axioms':by_name[endpoint],
        'type_output':type_output,'type_output_sha256':hashlib.sha256(type_output.encode()).hexdigest(),
        'type_log_line_1_based':audit.count('\n',0,positions[index])+1,
        'source_print_axioms_matches_exhaustive_audit':True})
types={r['name'].split('.')[-1]:' '.join(r['type_output'].split()) for r in endpoint_records}
assert 't < 8' in types['eight_complete_carries'] and 'i ≤' in types['eight_complete_carries']
assert 'leftColumns 17 t' in types['eight_complete_carries']
assert types['initial_pair_sums_differ'].endswith('leftColumns 3 = 6 ∧ Agent10EightCarryCounterexample.rightColumns 3 = 5')
assert '3 < 17' in types['initial_pair_difference_active']
assert 'leftColumns 17 8' in types['ninth_carry_differs'] and ').snd 4 = 1' in types['ninth_carry_differs']
assert 'rightColumns 17 8' in types['ninth_carry_differs'] and types['ninth_carry_differs'].endswith(').snd 4 = 0')
assert 't < 8' in types['first_separation_at_eight'] and '∃ i,' in types['first_separation_at_eight']
assert 't < 4' in types['first_palindromes_at_four'] and 'Palindrome' in types['first_palindromes_at_four']
for suffix in ['left_canonical','right_canonical','initial_pair_sums_differ','next_integer_values',
               'next_integers_differ','initial_pair_difference_active','palindrome_values_at_four','first_palindromes_at_four']:
    assert by_name[MODULE+'.'+suffix]==[],suffix
finite_names=['digit_bounds_fin','initial_trace_fin','trace_width_bound_fin','trace_steps_fin',
              'trace_carries_fin','palindrome_prefix_fin']
finite_records={}
for suffix in finite_names:
    names=[name for name in by_name if name.endswith('.'+suffix)]
    assert len(names)==1 and by_name[names[0]]==[],suffix
    finite_records[suffix]={'internal_name':names[0],'axioms':[]}
assert SOURCE.read_bytes()==source_bytes==(OUT/'source'/SOURCE.name).read_bytes()
receipt={**base_receipt,'status':'PASS','recorded_at_utc':datetime.now(timezone.utc).isoformat(),
    'lean_version':version.stdout.strip(),'module_theorem_count':len(records),
    'theorem_count_includes_generated_theorems':True,'module_axiom_union':sorted(union),
    'unsafe_generated_implementation_declarations':[],
    'public_endpoint_count':len(endpoints),'endpoint_records':endpoint_records,
    'all_public_endpoint_types_and_print_axioms_checked':True,
    'finite_kernel_certificates':finite_records,
    'scope':'Concrete failure of eight-word reconstruction for unrestricted continued reverse-and-add iteration; both inputs first reach palindromes at time four; no palindrome-avoidance or 196 claim.',
    'palindrome_first_time':4,
    'source_pattern_origin':str(ROOT/'agent10-semantic/Agent10SevenCarryCounterexample.lean'),
    'source_pattern_sha256':'7cdc32bd5d0eff4174d1d35314ef544a7cf80532868ba38fe664cd063edb67f9',
}
receipt['artifacts']={str(p.relative_to(OUT)):{'sha256':sha(p),'bytes':p.stat().st_size}
    for p in sorted(OUT.rglob('*')) if p.is_file()}
(OUT/'verification.json').write_text(json.dumps(receipt,indent=2)+'\n')
print(json.dumps({k:receipt[k] for k in ['status','source_sha256','module_theorem_count',
    'module_axiom_union','public_endpoint_count','palindrome_first_time']},indent=2),flush=True)
print('receipt='+str(OUT/'verification.json'),flush=True)
print('receipt_sha256='+sha(OUT/'verification.json'),flush=True)
