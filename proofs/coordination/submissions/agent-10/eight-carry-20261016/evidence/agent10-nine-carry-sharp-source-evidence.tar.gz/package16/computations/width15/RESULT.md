# Twice-padded width-fifteen witness: exact filtered lift scan

## Outcome

All **1,987,440** admissible symmetric, center-even completions of the
120 surviving four-coordinate prefixes were checked. None shared eight
complete actual carry words at observations `t=0,...,7`.

The initial ordered difference was exactly

```text
[0,0,1,-3,5,-6,6,-6,6,-6,5,-3,1,0,0].
```

Swapping the ordered words covers the negative sign. The width is exactly
fifteen. No arbitrary-width exclusion or global memory sharpness is claimed.

The exact survivor counts are conditional on the eight-observation prefix
filter already having been applied:

| Number of complete actual carry words additionally matched | Surviving word pairs |
|---:|---:|
| 0 | 1,987,440 |
| 1 | 172,200 |
| 2 | 62,784 |
| 3 | 49,776 |
| 4 | 27,370 |
| 5 | 15,024 |
| 6 | 4,910 |
| 7 | 126 |
| 8 | 0 |

The scan completed with exit code zero. Its measured wall time was
0.4603 seconds, with a child peak of 10,240 KiB under this invocation.

## Exhaustive domain and filter boundary

The full admissible ordered domain has

`18 * 19 * 18 * 16 * 14 * 13 * 13 * 7 = 1,631,290,752`

word pairs. The first four coordinates have 98,496 possibilities, with
oriented difference `(0,0,1,-3)`. The supplied exact four-prefix computation
retains 120 of them after eight abstract observations.

For each retained right-hand prefix, the scan enumerates every choice

```text
r4 = 0..13,
r5 = 6..18,
r6 = 0..12,
r7 in {6,8,10,12,14,16,18}.
```

Each choice is reflected to obtain the complete symmetric word; the left
word is the right word plus the prescribed difference. Thus every retained
prefix has exactly `14 * 13 * 13 * 7 = 16,562` completions. Assertions check
the count separately for each prefix, all coefficient ranges, symmetry,
nonzero exterior coefficient, and center parity.

The prefix graph uses one shared incoming bit at `L-4` and requires all
four low carries and all four reflected high carries—including the terminal
carry—to agree at each observation. The CSV contains only the first
compatible bit string as metadata. **That string is not used to restrict
the actual lift scan.** Each complete candidate follows its own actual
carry trajectory.

The four-prefix source, CSV, result, and verification receipt are copied
unchanged from the scout's `agent10-count/four-prefix-check-002` directory.
Their hashes were checked before the lift scan. The original source
enumerates every shared bit path, cross-checks its digit and arithmetic
updates, and validates its three-prefix mode against the previously checked
control counts.

The four-prefix actual-history inclusion has **not been formalized in
Lean**. Consequently, the directly checked statement is the absence of
eight-word collisions inside all 1,987,440 retained completions. Extending
that negative conclusion to the full width-fifteen domain uses the
correctness and completeness of the computational necessary-prefix
projection. The current Lean three-column inclusion does not by itself
certify this four-column filter.

## Actual simulator and reproducibility

`actual_simulator.inc` contains the byte-for-byte unchanged `admissible`,
`carries`, and `next_pairs` functions from the earlier
`agent10-semantic/padded_witness_scan.cpp`. Carry vectors include index zero
and the terminal carry. Equality compares the complete vectors, so differing
widths would also be detected. Each update calculates the actual decimal
sum digits, appends terminal overflow if present, and forms the next pair
word from those digits.

Run from this directory:

```bash
g++ -std=c++17 -O3 -Wall -Wextra -Werror twice_padded_witness_scan.cpp -o twice_padded_witness_scan
./twice_padded_witness_scan survivors-4.csv first_eight_collision.json > result.json
python replay_seven_word.py > seven_word_integer_replay.json
```

No first-eight-collision file is created for the recorded result. The full
search output is `result.json`; the exact command, source/input hashes,
exit code, elapsed time, and peak child RSS are in `scan.command.json`.
The additional receipt `lift_verification.json` hashes the source and all
retained inputs and outputs.

## Independent ordinary-integer control

One of the 126 seven-word survivors has canonical representatives

```text
n = 900000058163209
m = 900000082716109.
```

Its initial pair words are

```text
q = [18,0,2,3,6,1,8,10,8,1,6,3,2,0,18]
r = [18,0,1,6,1,7,2,16,2,7,1,6,1,0,18].
```

The independent Python replay constructs the ordinary integers, checks
their exact initial pair words, and repeatedly applies
`n + int(str(n)[::-1])`. Complete carries agree at times zero through six
and first differ at time seven. The overflow pattern across the seven
matching observations is `ONOOONN`.

`seven_word_integer_replay.json` retains all decimal integers, reversals,
next integers, decimal digit arrays, pair words, and complete carry arrays
at times zero through eight. Integer values are stored as strings to
preserve exactness in JSON consumers with fixed-precision numeric types.
`replay_seven_word.py` reproduces the trace.

This positive example is independently replayed computational evidence;
its existence does not depend on completeness of the negative-search
filter. No new Lean certificate or optimal universal observation bound is
claimed here.
