#!/usr/bin/env python3
"""Exact three-column necessary-graph comparison for difference (0,1,-3).

The incoming high bit is the actual carry at L-3. Low carries are calculated
from zero; high carries are calculated by reflection. Low/high observations
may overlap when L is 3 or 4; actual words then impose further equalities,
while the necessary graph intentionally includes every possible bit path.
"""
from functools import lru_cache
import json


def carries(state, bit):
    low = [0]
    for coefficient in state:
        low.append((coefficient+low[-1]) // 10)
    high = [0] * (len(state)+1)
    high[-1] = bit
    for i in range(len(state)-1, -1, -1):
        high[i] = (state[i]+high[i+1]) // 10
    return low, high


def next_state(state, bit):
    low, high = carries(state, bit)
    lower = [(coefficient+low[i]) % 10 for i, coefficient in enumerate(state)]
    upper = [(coefficient+high[i+1]) % 10 for i, coefficient in enumerate(state)]
    if high[0]:
        return tuple([lower[0]+1] + [lower[i]+upper[i-1] for i in range(1, len(state))])
    return tuple(a+b for a, b in zip(lower, upper))


def solver(high_observations):
    @lru_cache(None)
    def path(n, state, other):
        if n == 0:
            return ()
        for bit in (0, 1):
            low, high = carries(state, bit)
            low_other, high_other = carries(other, bit)
            if low != low_other or high[:high_observations] != high_other[:high_observations]:
                continue
            tail = path(n-1, next_state(state, bit), next_state(other, bit))
            if tail is not None:
                return (bit,) + tail
        return None
    return path


def main():
    starts = [((p, q+1, r-3), (p, q, r))
              for p in range(1, 19) for q in range(18) for r in range(3, 19)]
    assert len(starts) == 5184
    results = {}
    for high_observations, name in [(1, "terminal_only"), (2, "terminal_and_width_minus_1"),
                                    (3, "all_three_high_carries")]:
        path = solver(high_observations)
        counts = []
        examples = {}
        for n in range(1, 9):
            survivors = [(q, r, path(n, q, r)) for q, r in starts if path(n, q, r) is not None]
            counts.append(len(survivors))
            if n >= 7:
                examples[n] = [{"q": q, "r": r, "bits": bits} for q, r, bits in survivors]
        results[name] = {"counts_for_1_to_8_observations": counts, "examples": examples}
    assert results["terminal_only"]["counts_for_1_to_8_observations"][-1] == 13
    assert results["terminal_and_width_minus_1"]["counts_for_1_to_8_observations"][-1] == 0
    assert results["all_three_high_carries"]["counts_for_1_to_8_observations"][-2:] == [37, 0]
    print(json.dumps({
        "prefix_length": 3, "initial_prefix_count": len(starts),
        "initial_difference": [0, 1, -3],
        "low_carries_observed": [1, 2, 3],
        "incoming_shared_high_carry": "L-3",
        "high_order": ["L", "L-1", "L-2"],
        "scope": "all 5184 admissible first-three-coordinate pairs of the prescribed difference, every shared Boolean control path through eight observations",
        "classification": "exact finite computational evidence; independent Lean certificate supplied separately",
        "results": results,
    }, indent=2))


if __name__ == "__main__":
    main()
