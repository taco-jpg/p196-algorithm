#!/usr/bin/env python3
"""Independent ordinary-integer replay of an exhaustive-scan survivor."""
import json


def digits(n):
    return [int(d) for d in reversed(str(n))]


def pair_word(n):
    ds = digits(n)
    return [a+b for a, b in zip(ds, reversed(ds))]


def carry_word(q):
    c = [0]
    for coefficient in q:
        c.append((coefficient+c[-1]) // 10)
    return c


def realize(q):
    assert q == q[::-1] and q[0] > 0
    result = [0] * len(q)
    for i in range((len(q)+1)//2):
        j = len(q)-1-i
        if i == j:
            assert q[i] % 2 == 0
            result[i] = q[i] // 2
        else:
            result[i] = min(q[i], 9)
            result[j] = q[i]-result[i]
            if j == len(q)-1 and result[j] == 0:
                result[j] = 1
                result[i] -= 1
    assert all(0 <= d <= 9 for d in result) and result[-1] > 0
    n = sum(d * 10**i for i, d in enumerate(result))
    assert pair_word(n) == q
    return n


def step(n):
    return n + int(str(n)[::-1])


def main():
    q = [17,3,5,1,7,10,7,1,5,3,17]
    r = [16,6,0,7,1,16,1,7,0,6,16]
    expected_difference = [1,-3,5,-6,6,-6,6,-6,5,-3,1]
    assert [a-b for a,b in zip(q,r)] == expected_difference
    n, m = realize(q), realize(r)
    start = n, m
    trajectory = []
    for t in range(8):
        a, b = pair_word(n), pair_word(m)
        ca, cb = carry_word(a), carry_word(b)
        match = ca == cb
        if t < 6:
            assert match
        if t == 6:
            assert not match
        trajectory.append({
            "time": t, "n": n, "m": m,
            "q": a, "r": b,
            "q_carries": ca, "r_carries": cb,
            "complete_word_match": match,
        })
        n, m = step(n), step(m)
    print(json.dumps({
        "initial_integers": start,
        "initial_difference": expected_difference,
        "matching_complete_words": 6,
        "first_mismatch_time": 6,
        "trajectory": trajectory,
    }, indent=2))


if __name__ == "__main__":
    main()
