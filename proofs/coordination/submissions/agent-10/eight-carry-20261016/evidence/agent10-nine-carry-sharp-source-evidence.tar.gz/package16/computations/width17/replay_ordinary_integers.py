#!/usr/bin/env python3
"""Independent ordinary-integer realization and replay of a width-17 pair."""
import json
from itertools import zip_longest

DIFFERENCE = [0,0,0,1,-3,5,-6,6,-6,6,-6,5,-3,1,0,0,0]


def digits(n):
    return [int(d) for d in reversed(str(n))]


def pair_word(n):
    ds = digits(n)
    return [a+b for a, b in zip(ds, reversed(ds))]


def carry_word(q):
    c = [0]
    for coefficient in q:
        c.append((coefficient+c[-1])//10)
    return c


def realize(q):
    assert len(q) == 17 and q == q[::-1] and 0 < q[0] <= 18
    assert all(0 <= coefficient <= 18 for coefficient in q)
    ds = [0]*len(q)
    for i in range((len(q)+1)//2):
        j = len(q)-1-i
        if i == j:
            assert q[i] % 2 == 0
            ds[i] = q[i]//2
        else:
            ds[i] = min(q[i], 9)
            ds[j] = q[i]-ds[i]
            if j == len(q)-1 and ds[j] == 0:
                ds[j] = 1
                ds[i] -= 1
    assert all(0 <= d <= 9 for d in ds) and ds[-1] > 0
    n = sum(d*10**i for i,d in enumerate(ds))
    assert pair_word(n) == q and len(str(n)) == 17
    return n


def step(n):
    return n+int(str(n)[::-1])


def replay_pair(pair, at_least):
    q,r = pair['q'],pair['r']
    assert [a-b for a,b in zip(q,r)] == DIFFERENCE
    n,m = realize(q),realize(r)
    start_n,start_m = n,m
    assert n != m and step(n) != step(m)
    trace = []
    first_mismatch = None
    mismatch_indices = []
    for t in range(33):
        a,b = pair_word(n),pair_word(m)
        ca,cb = carry_word(a),carry_word(b)
        match = ca == cb
        if t < at_least:
            assert match, ('shorter agreement than claimed',t)
        if not match and first_mismatch is None:
            first_mismatch = t
            mismatch_indices = [i for i,(x,y) in enumerate(zip_longest(ca,cb)) if x != y]
        trace.append({
            'time':t, 'n':str(n), 'm':str(m),
            'n_width':len(str(n)), 'm_width':len(str(m)),
            'n_reversal':str(int(str(n)[::-1])), 'm_reversal':str(int(str(m)[::-1])),
            'n_next':str(step(n)), 'm_next':str(step(m)),
            'n_digits_little_endian':digits(n), 'm_digits_little_endian':digits(m),
            'q':a, 'r':b, 'q_carries':ca, 'r_carries':cb,
            'complete_word_match':match,
        })
        if first_mismatch is not None:
            break
        n,m = step(n),step(m)
    return {
        'classification':'independent ordinary-integer replay; no Lean certificate or all-time claim',
        'initial_integers':[str(start_n),str(start_m)],
        'initial_pair_words':{'q':q,'r':r},
        'initial_difference':DIFFERENCE,
        'initial_width':17,
        'next_integers':[str(step(start_n)),str(step(start_m))],
        'next_integers_differ':True,
        'at_least_matching_complete_words':at_least,
        'first_mismatch_time':first_mismatch,
        'first_mismatch_indices':mismatch_indices,
        'last_time_checked':trace[-1]['time'],
        'trajectory':trace,
    }


if __name__ == '__main__':
    import sys
    from pathlib import Path
    if len(sys.argv) != 3:
        raise SystemExit('usage: replay_ordinary_integers.py PAIR.json AT_LEAST_WORD_COUNT')
    pair = json.loads(Path(sys.argv[1]).read_text())
    print(json.dumps(replay_pair(pair,int(sys.argv[2])),indent=2))
