# Agent 10: exact nine-observation threshold — source and evidence

This packet preserves the sixteen-module `agent10-nine-carry-sharp` result,
the exact source used by the original canonical check, the final additive
source patch, complete retained checking evidence, and internal non-author
reviews. The final mathematical report is
`snapshot/proofs/Agent10NineCarrySharp.md`.

No Lean build, repository edit, remote write, or patch application was
performed to assemble this archive. Compiler binaries, compiled `.olean` and
`.ilean` files, scan executables, and caches are excluded.

## Result and precise domain

The final source proves both equivalences, for natural observation counts `K`:

```text
UniformPairReconstruction K ↔ 9 ≤ K
UniformNextIntegerReconstruction K ↔ 9 ≤ K
```

The first predicate ranges over admissible pair-coefficient words at one
shared positive initial width and concludes equality of every active initial
coefficient. The second ranges over canonical positive decimal inputs at one
shared initial width and concludes equality of their next ordinary integers.
Observations are complete carry words at the evolving widths, including each
terminal carry. Neither predicate concludes equality of the original input
integers or their individual digits.

The upper bound uses the unchanged nine-word theorem. The lower bound uses
the directly kernel-certified width-seventeen inputs
`90000000560706169` and `90000000806235169`. Their first eight complete carry
words agree, their active index-three coefficients are `6` and `5`, and their
next integers are `186160707060706178` and `186153261606235178`. The ninth
observation differs at carry index four. Both inputs first reach palindromes
at time four, as separately proved in the source. The ordinary iteration
continues after those palindromes. No palindrome-avoidance, Lychrel-input,
minimal-witness-width, or 196 claim follows.

The earlier seven-word witness is preserved separately. It first reaches
palindromes at time two and separates on its eighth observation. Earlier
conditional eight-word reconstruction and first-two-active-coefficient
results remain unchanged.

## Source and commit identity

| Role | Identity |
|---|---|
| Original source baseline | `4b4edf976b2c7a9ba1dad80636c0e21c66350325` |
| Original tested sixteen-module proof commit | `f156ea95f4f64609da218632820f71378c815411` |
| Final documentation/source delivery commit | `@@DELIVERY_COMMIT@@` |
| Final source patch SHA-256 | `@@PATCH_SHA256@@` |
| Earlier thirteen-module archive SHA-256 | `62707211104ecca8935afc26b815a773a71f18ea957906def79a59f9cdb4232a` |

`snapshot/` contains @@SNAPSHOT_COUNT@@ source, registry, documentation, and
calculation files. Its complete sixteen-module closure is pinned by
`proofs/Agent10NineCarrySharp.registry.json`. Every module was compared
byte-for-byte with the original tested commit and the retained canonical
build source. The four original dependencies, original verifier, and original
`AGENTS.md` also match the baseline exactly.

The final patch and its exact source/application receipts are under
`delivery/`. The receipts distinguish the tested proof commit, later delivery
commit, baseline, and checked target revisions. A successful patch-application
check is transport evidence; the canonical Lean build is the mathematical
checking evidence.

## Package layout and checking evidence

| Location | Contents |
|---|---|
| `snapshot/` | Small complete source snapshot, original verifier/rules, final report, staged calculation material |
| `canonical/canonical-build-004/` | Unmodified final report, all sixteen source modules, audit source, seventeen logs, original file manifest |
| `validation/` | Original retained-output validator004 source and its independently authored validation receipt |
| `microbuilds/` | Seven, Eight, and Sharp local proof sources, logs, command/verification receipts; compiled artifacts omitted |
| `reviews/seven/`, `reviews/eight/`, `reviews/sharp/` | Separate non-author semantic/source reviews and their small evidence records |
| `computations/width15/`, `computations/width17/` | Exact discovery/replay source and data with their original scope statements |
| `delivery/`, `publication/` | Final patch/application records and publication readbacks available before this archive was frozen |
| `history/agent10-carry-source-evidence-13.tar.gz` | The exact earlier archive, included once without expanding its files into this packet |
| `support/` | Assembly source, deterministic repacker, and complete package verifier |

Canonical build004, executed by the parent Agent #10, passed all sixteen
module compilations plus the project audit: seventeen successful commands,
1,345 unique theorem origins including generated helpers, and 122 public
endpoint types. The full transitive axiom union is `propext`,
`Classical.choice`, and `Quot.sound`. The canonical verifier's historical
`agent` field remains unchanged as `Agent #1`; the separate validation receipt
correctly records the actual build executor and evidence validator.

The new Seven, Eight, and Sharp modules contribute respectively 41, 48, and
12 audited theorem declarations. The Seven/Eight independent reviews and
Sharp's separate 28-check non-author review are preserved as originally
written, including any statement that the then-forthcoming whole-closure
gate was still separate. Build004 and validator004 supply that later evidence
without rewriting those earlier receipts.

The earlier thirteen-module archive is historical evidence with its own
scope. Its statements about later work being excluded describe that frozen
archive, not the present sixteen-module package. Likewise, computational
discovery filters retain their original qualifications: a filtered zero
count is not a universal exclusion. The direct Seven/Eight Lean certificates
do not depend on correctness or completeness of those filters.

All reviewers, proof authors, the canonical-build executor, and validation
specialist are internal collaborators. No external GitHub approval,
repository-wide completeness, or independent maintainer acceptance is
asserted.

## Reproduce the selected proof closure

Use the pinned official Lean 4.19.0 runtime identified by the retained build
records. No compiler is included. Python scripts use the standard library.

Work in a disposable copy of `snapshot/`; keep the immutable extracted packet
unchanged. The original verifier queries Git HEAD, so initialize a new Git
repository in that disposable snapshot before invoking it:

```bash
git init
git add .
git -c user.name='Source replay' -c user.email='source-replay@example.invalid' commit -m 'Initialize sixteen-module source replay snapshot'
git rev-parse HEAD
python3 -B proofs/verify_project__214bf7673efe116b.py --lean /absolute/path/to/lean-4.19.0/bin/lean --output /absolute/new/replay-output --registry proofs/Agent10NineCarrySharp.registry.json --project agent10-nine-carry-sharp
```

The output directory must not already exist. Explicitly selecting the project
preserves the scope of the unchanged verifier; this is not a repository-wide
census or acceptance claim.

**That new Git commit is a synthetic replay snapshot.** It is not the original
tested commit `f156ea95f4f64609da218632820f71378c815411` and must not be
reported as such. A new verification report will record the synthetic HEAD;
the original tested identity remains established by the retained report and
the sixteen exact module hashes/Git blob pins. This archive assembly did not
create a synthetic commit or run a new Lean proof check.

Alternatively, apply `delivery/source-final.patch` in a fresh checkout of
the baseline identified above, then run the same original verifier with the
explicit registry and project. The application receipts retain the exact
historical checks already performed; they are not silently rewritten for a
different checkout.

The preserved specialist scripts may retain historical absolute workspace
paths. The self-contained source-snapshot command above is the primary clean
reproduction method. `support/verify_package.py` and `support/repack.py` are
portable within the extracted packet.

## Integrity and deterministic archive reproduction

`FILES.json` lists every regular package file except itself, with size and
SHA-256. `PROVENANCE.json` records original input paths/commits, source pins,
categories, exclusions, and preservation checks. Run:

```bash
python3 -B support/verify_package.py
python3 -B support/repack.py /absolute/new/repacked-source-evidence.tar.gz
```

The archive uses lexicographic paths, fixed owner/mode metadata, zero tar
timestamps, and a gzip header with an empty filename and zero timestamp.
The separate archive verification receipt records the archive hash, complete
manifest hash, file count, sizes, deterministic-byte comparison, and successful
extraction followed by exact inventory/hash equality. It remains outside the
archive to avoid self-reference. Any publication readback of this final
archive itself must likewise be retained as a later external receipt.
