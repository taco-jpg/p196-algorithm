#!/usr/bin/env python3
"""Independent ordinary arithmetic and exact source-literal controls for Eight.

Run with python3 -B independent_controls.py. This computes from ordinary
integers, checks the retained finite rows, and writes two small JSON records.
It does not execute Lean or substitute for the kernel certificate.
"""
from pathlib import Path
import ast
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "sources/Agent10EightCarryCounterexample.lean"
TRACE = ROOT / "evidence/author-integer-replay.json"
EXPECTED_SOURCE = "5da46ec31d7641307a6d8c1a5f81bd3b8bdfb097a39b5afa73145e062683d739"
EXPECTED_TRACE = "b53c756862d5ad9d64fff1111ce2a29ef8265e8267c1111e5e9594a98aea73f6"


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def save(name, value):
    (ROOT / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def decimal_state(n):
    """Derive columns from an ordinary integer, not from retained trace rows."""
    digits = [int(c) for c in str(n)[::-1]]
    columns = [a + b for a, b in zip(digits, reversed(digits))]
    carries, out_digits = [0], []
    for column in columns:
        total = column + carries[-1]
        carries.append(total // 10)
        out_digits.append(total % 10)
    if carries[-1]:
        out_digits.append(carries[-1])
    reversal = int(str(n)[::-1])
    next_n = n + reversal
    assert sum(d * 10**i for i, d in enumerate(out_digits)) == next_n
    assert len(carries) == len(digits) + 1
    return digits, columns, carries, reversal, next_n


def code_only(text):
    """Mask comments and strings while retaining source positions."""
    out, i, depth, string = [], 0, 0, False
    while i < len(text):
        pair = text[i:i+2]
        if depth:
            if pair == "/-":
                depth += 1; out.extend("  "); i += 2
            elif pair == "-/":
                depth -= 1; out.extend("  "); i += 2
            else:
                out.append("\n" if text[i] == "\n" else " "); i += 1
        elif string:
            if text[i] == "\\":
                out.extend("  "); i += 2
            else:
                string = text[i] != '"'
                out.append("\n" if text[i] == "\n" else " "); i += 1
        elif pair == "/-":
            depth = 1; out.extend("  "); i += 2
        elif pair == "--":
            end = text.find("\n", i)
            end = len(text) if end < 0 else end
            out.extend(" " * (end-i)); i = end
        elif text[i] == '"':
            string = True; out.append(" "); i += 1
        else:
            out.append(text[i]); i += 1
    assert not depth and not string
    return "".join(out)


def main():
    assert sha(SOURCE) == EXPECTED_SOURCE
    assert sha(TRACE) == EXPECTED_TRACE
    stored = json.loads(TRACE.read_text())
    n, m = 90000000560706169, 90000000806235169
    actual, widths, equal_times, palindromic = [], [], [], {"n": [], "m": []}
    for t in range(9):
        nd, q, nc, nr, nn = decimal_state(n)
        md, r, mc, mr, mn = decimal_state(m)
        row = {"time": t, "n": str(n), "m": str(m),
               "n_width": len(nd), "m_width": len(md),
               "n_reversal": str(nr), "m_reversal": str(mr),
               "n_next": str(nn), "m_next": str(mn),
               "n_digits_little_endian": nd, "m_digits_little_endian": md,
               "q": q, "r": r, "q_carries": nc, "r_carries": mc,
               "complete_word_match": len(nd) == len(md) and nc == mc}
        assert row == stored["trajectory"][t], (t, row)
        assert len(nd) == len(md)
        widths.append(len(nd))
        if row["complete_word_match"]:
            equal_times.append(t)
        if n == nr:
            palindromic["n"].append(t)
        if m == mr:
            palindromic["m"].append(t)
        actual.append(row)
        n, m = nn, mn
    assert equal_times == list(range(8))
    assert palindromic == {"n": [4], "m": [4]}
    assert stored["initial_integers"] == [actual[0]["n"], actual[0]["m"]]
    assert stored["initial_pair_words"] == {"q": actual[0]["q"], "r": actual[0]["r"]}
    delta = [a-b for a, b in zip(actual[0]["q"], actual[0]["r"])]
    assert delta == stored["initial_difference"]
    assert stored["initial_width"] == widths[0] == 17
    assert stored["next_integers"] == [actual[0]["n_next"], actual[0]["m_next"]]
    assert stored["next_integers_differ"] is True
    assert stored["at_least_matching_complete_words"] == 8
    assert stored["first_mismatch_time"] == 8
    assert stored["last_time_checked"] == 8
    first_indices = [i for i, (a, b) in enumerate(zip(actual[8]["q_carries"], actual[8]["r_carries"])) if a != b]
    assert first_indices == stored["first_mismatch_indices"]
    assert first_indices[0] == 4
    assert [actual[8]["q_carries"][4], actual[8]["r_carries"][4]] == [1, 0]
    assert [actual[0]["q"][3], actual[0]["r"][3]] == [6, 5]
    assert 3 < widths[0]
    assert [actual[4]["n"], actual[4]["m"]] == ["16999899899899899961", "16989989999998998961"]

    source = SOURCE.read_text()
    right_rows, left_rows = re.search(
        r"private def rows .*?if b then (\[.*?\]) else (\[.*?\])\s*private def trace",
        source, re.S).groups()
    right_rows, left_rows = ast.literal_eval(right_rows), ast.literal_eval(left_rows)
    assert left_rows == [row["q"] for row in actual]
    assert right_rows == [row["r"] for row in actual]
    source_widths = ast.literal_eval(re.search(
        r"def traceWidth .*?\((\[[^\]]*\]) : List Nat\)", source, re.S).group(1))
    assert source_widths == widths
    for side, field in [("left", "n"), ("right", "m")]:
        digits = ast.literal_eval(re.search(
            rf"def {side}Digits .*?\((\[[^\]]*\]) : List Nat\)", source, re.S).group(1))
        assert digits == actual[0][field + "_digits_little_endian"]
    for rows in [left_rows, right_rows]:
        for t in range(8):
            carry, out_digits = 0, []
            for column in rows[t]:
                carry, digit = divmod(column + carry, 10)
                out_digits.append(digit)
            if carry:
                out_digits.append(carry)
            successor = [a+b for a, b in zip(out_digits, reversed(out_digits))]
            assert len(out_digits) == source_widths[t+1]
            assert successor == rows[t+1]

    controls = {
        "status": "PASS",
        "classification": "INDEPENDENT_INTEGER_ARITHMETIC_AND_SOURCE_LITERAL_CONTROL",
        "reviewer": "/root/lean_runtime",
        "source_sha256": EXPECTED_SOURCE,
        "retained_trace_sha256": EXPECTED_TRACE,
        "exact_trajectory_rows_matched": len(actual),
        "exact_trace_fields_matched": sum(len(row) for row in actual),
        "source_pair_rows_matched": 18,
        "source_initial_digit_values_matched": 34,
        "source_adjacent_transitions_matched": 16,
        "source_transition_active_coefficients_matched": 2 * sum(source_widths[1:]),
        "complete_observation_times_equal": equal_times,
        "matched_carry_positions_including_terminal": sum(widths[t]+1 for t in equal_times),
        "widths_t0_through_t8": widths,
        "initial_pair_sums_at_index3": [6, 5],
        "initial_pair_difference": delta,
        "next_integers": [actual[0]["n_next"], actual[0]["m_next"]],
        "first_separating_observation_time": 8,
        "first_separating_carry_index": 4,
        "all_mismatching_indices_at_time8": first_indices,
        "separating_values": [1, 0],
        "palindromic_times_among_checked_states": palindromic,
        "palindromes_at_time4": [actual[4]["n"], actual[4]["m"]],
        "numeric_trajectory": [{k: row[k] for k in ["time", "n", "m", "n_next", "m_next"]} for row in actual],
        "scope": "Unrestricted continued ordinary reverse-and-add iteration. Both trajectories first reach a palindrome at time 4. This proves a concrete eight-observation collision, not a palindrome-free lower bound or a nine-observation upper bound."
    }
    save("independent-arithmetic.json", controls)

    code = code_only(source)
    forbidden = re.findall(r"(?<![\w'])\b(?:sorry|admit|axiom|sorryAx|native_decide|ofReduceBool|skipKernelTC|unsafe)\b(?![\w'])", code)
    assert not forbidden
    imports = re.findall(r"^import\s+(\S+)", code, re.M)
    assert imports == ["ActualCarryObservability"]
    declarations = []
    for match in re.finditer(r"^(private\s+)?theorem\s+(\w+)\b(.*?)(?=\s*:=)", code, re.M | re.S):
        declarations.append({"name": match.group(2), "private": bool(match.group(1)),
                             "declaration": source[match.start():match.end()].strip()})
    assert len(declarations) == 23
    assert sum(not d["private"] for d in declarations) == 16
    prints = re.findall(r"^#print axioms (\S+)\s*$", code, re.M)
    assert len(prints) == len(set(prints)) == 23
    assert set(prints) == {d["name"] for d in declarations}
    save("source-controls.json", {"status": "PASS", "source_sha256": EXPECTED_SOURCE,
        "source_imports": imports, "forbidden_shortcut_tokens": forbidden,
        "explicit_source_theorems": len(declarations), "public_source_endpoints": 16,
        "source_print_axioms_commands": len(prints), "declarations": declarations})
    print(json.dumps({"status": "PASS", "trace_rows": len(actual), "source_rows": 18,
                      "source_transitions": 16, "complete_carry_positions": controls["matched_carry_positions_including_terminal"],
                      "explicit_theorems": len(declarations), "public_endpoints": 16,
                      "first_palindrome_time": 4}))


if __name__ == "__main__":
    main()

