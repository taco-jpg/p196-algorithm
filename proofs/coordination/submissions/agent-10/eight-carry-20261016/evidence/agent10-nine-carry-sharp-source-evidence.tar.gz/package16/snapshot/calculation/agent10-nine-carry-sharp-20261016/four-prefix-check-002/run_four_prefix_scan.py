#!/usr/bin/env python3
"""Preserve and validate a bounded exact exterior-prefix scan, without Lean."""
import csv
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import shutil
import subprocess
import time

ROOT = Path('/workspace/scratch/4b20b8469eb3')
HERE = ROOT / 'agent10-count'
OUT = HERE / 'four-prefix-check-002'
OUT.mkdir(exist_ok=False)


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def run_record(name, command, stdout_name):
    command = [str(x) for x in command]
    started = time.time()
    with (OUT / stdout_name).open('wb') as out, (OUT / (name + '.stderr.log')).open('wb') as err:
        process = subprocess.Popen(command, stdout=out, stderr=err)
        _, wait_status, usage = os.wait4(process.pid, 0)
        process.returncode = os.waitstatus_to_exitcode(wait_status)
    (OUT / (name + '.resources.log')).write_text(json.dumps({
        'user_cpu_seconds': usage.ru_utime, 'system_cpu_seconds': usage.ru_stime,
        'maximum_resident_kib': usage.ru_maxrss,
        'minor_page_faults': usage.ru_minflt, 'major_page_faults': usage.ru_majflt,
        'voluntary_context_switches': usage.ru_nvcsw,
        'involuntary_context_switches': usage.ru_nivcsw,
    }, indent=2) + '\n')
    rec = {'command': command, 'exit_code': process.returncode,
           'elapsed_seconds': time.time() - started, 'stdout': stdout_name,
           'stderr': name + '.stderr.log', 'resource_log': name + '.resources.log'}
    (OUT / (name + '.command.json')).write_text(json.dumps(rec, indent=2) + '\n')
    assert process.returncode == 0, rec
    return rec


for src in [HERE / 'four_prefix_scan.cpp', Path(__file__),
            ROOT / 'agent10-semantic/three_prefix_scan.py',
            ROOT / 'agent10-semantic/three_prefix_scan.json']:
    shutil.copy2(src, OUT / src.name)

compiler = subprocess.run(['/usr/bin/g++', '--version'], check=True, capture_output=True, text=True)
(OUT / 'compiler-version.txt').write_text(compiler.stdout)
records = [run_record('compile', ['/usr/bin/g++', '-std=c++17', '-O2', '-Wall', '-Wextra',
                                '-pedantic', OUT / 'four_prefix_scan.cpp',
                                '-o', OUT / 'four_prefix_scan'], 'compile.stdout.log')]
for k in [3, 4]:
    records.append(run_record(f'scan-{k}', [OUT / 'four_prefix_scan', str(k),
                                          OUT / f'survivors-{k}.csv'], f'result-{k}.json'))

reference = json.loads((OUT / 'three_prefix_scan.json').read_text())
control = json.loads((OUT / 'result-3.json').read_text())
expected = reference['results']['all_three_high_carries']['counts_for_1_to_8_observations']
assert control['surviving_starts_for_1_to_8_observations'] == expected

spec = importlib.util.spec_from_file_location('prefix_reference', OUT / 'three_prefix_scan.py')
reference_module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(reference_module)
result = json.loads((OUT / 'result-4.json').read_text())
assert result['initial_prefix_count'] == 98496
assert result['initial_difference'] == [0, 0, 1, -3]
assert result['shared_inner_carry'] == 'L-4'
assert result['low_carries_observed'] == [1, 2, 3, 4]
assert result['high_carries_observed'] == ['L', 'L-1', 'L-2', 'L-3']
csv_starts = 0
csv_paths = 0
with (OUT / 'survivors-4.csv').open(newline='') as handle:
    for row in csv.DictReader(handle):
        csv_starts += 1
        csv_paths += int(row['full_eight_bit_path_count'])
        assert len(row['first_bits_time_0_to_7']) == 8
        assert set(row['first_bits_time_0_to_7']) <= {'0', '1'}
assert csv_starts == result['surviving_starts_for_1_to_8_observations'][-1]
assert csv_paths == result['compatible_bit_paths_for_1_to_8_observations'][-1]
checked_frames = 0
for example in result['complete_path_examples']:
    assert len(example) == 8
    for t, frame in enumerate(example):
        assert frame['time'] == t
        for side in ['left', 'right']:
            state = frame[side]
            bit = frame['shared_inner_bit']
            low, high = reference_module.carries(state, bit)
            assert low == frame[f'low_{side}_with_zero']
            assert high == frame[f'high_{side}_with_inner_bit']
            assert list(reference_module.next_state(state, bit)) == frame[f'next_{side}']
            if t < 7:
                assert frame[f'next_{side}'] == example[t+1][side]
        assert frame['low_left_with_zero'] == frame['low_right_with_zero']
        assert frame['high_left_with_inner_bit'] == frame['high_right_with_inner_bit']
        assert frame['terminal_overflow'] == frame['high_left_with_inner_bit'][0]
        checked_frames += 1

foundation = ROOT / 'p196-algorithm/proofs/Lychrel196Research__c696e0ea3db39d92.lean'
assert sha(foundation) == 'f8950d138fa4231b536059e2334d36b6496de3d25a806f4cf3925941aa05144c'
receipt = {
    'status': 'PASS',
    'executor': 'Agent #10 specialist /root/formalization_scout',
    'classification': 'exact finite computational evidence; not a Lean certificate',
    'source': {'path': str(OUT / 'four_prefix_scan.cpp'), 'sha256': sha(OUT / 'four_prefix_scan.cpp')},
    'runner': {'path': str(OUT / 'run_four_prefix_scan.py'), 'sha256': sha(OUT / 'run_four_prefix_scan.py')},
    'foundation_reference': {'path': str(foundation), 'sha256': sha(foundation),
        'git_blob': 'c6c1f5441c54a36f2d82b3ef78dff1ccdbc5a506',
        'theorems': ['next_column_no_overflow', 'next_column_overflow_outer',
                     'next_column_overflow_interior']},
    'three_column_control_counts': expected,
    'four_column_counts': result['surviving_starts_for_1_to_8_observations'],
    'four_column_bit_path_counts': result['compatible_bit_paths_for_1_to_8_observations'],
    'retained_example_count': len(result['complete_path_examples']),
    'independently_replayed_example_frames': checked_frames,
    'survivor_csv_rows': csv_starts,
    'survivor_csv_path_sum': csv_paths,
    'commands': records,
    'scope': result['scope'],
    'interpretation': ('No starting pair in this necessary prefix graph survives eight observations.'
                       if csv_starts == 0 else
                       'Surviving prefix paths are necessary candidates only; omitted inner digits '
                       'must still realize the supplied carry sequence coherently in an actual word.'),
}
receipt['artifacts'] = {p.name: {'sha256': sha(p), 'bytes': p.stat().st_size}
                        for p in sorted(OUT.iterdir()) if p.is_file()}
(OUT / 'verification.json').write_text(json.dumps(receipt, indent=2) + '\n')
print(json.dumps({k: receipt[k] for k in ['status', 'four_column_counts',
    'four_column_bit_path_counts', 'retained_example_count',
    'independently_replayed_example_frames', 'interpretation']}, indent=2))
print('verification_sha256=' + sha(OUT / 'verification.json'))
