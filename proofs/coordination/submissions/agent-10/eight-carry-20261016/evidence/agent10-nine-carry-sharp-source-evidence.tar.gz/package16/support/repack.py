#!/usr/bin/env python3
"""Deterministically serialize package16; no proof build or source changes."""
from pathlib import Path
import gzip
import hashlib
import io
import json
import sys
import tarfile


def archive_bytes(root):
    root = Path(root).resolve()
    result = io.BytesIO()
    with gzip.GzipFile(filename='', mode='wb', fileobj=result, mtime=0, compresslevel=9) as gz:
        with tarfile.open(fileobj=gz, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for path in sorted(p for p in root.rglob('*') if p.is_file()):
                if path.is_symlink():
                    raise ValueError('Symlink in source packet')
                data = path.read_bytes()
                info = tarfile.TarInfo('package16/' + path.relative_to(root).as_posix())
                info.size = len(data)
                info.mtime = 0
                info.uid = info.gid = 0
                info.uname = info.gname = ''
                info.mode = 0o644
                tar.addfile(info, io.BytesIO(data))
    return result.getvalue()


if __name__ == '__main__':
    if len(sys.argv) != 2:
        raise SystemExit('usage: repack.py NEW_ARCHIVE_PATH')
    output = Path(sys.argv[1]).resolve()
    if output.exists():
        raise SystemExit('Refusing to overwrite an existing archive')
    root = Path(__file__).resolve().parent.parent
    if output.is_relative_to(root):
        raise SystemExit('Place the archive outside package16')
    data = archive_bytes(root)
    output.write_bytes(data)
    print(json.dumps({'archive': str(output), 'bytes': len(data),
                      'sha256': hashlib.sha256(data).hexdigest()}, indent=2))
