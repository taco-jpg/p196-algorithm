#!/usr/bin/env python3
"""Independent ordinary-integer replay of a width-15 seven-word survivor."""
import json


def digits(n):
    return [int(d) for d in reversed(str(n))]


def pair_word(n):
    ds = digits(n)
    return [a+b for a, b in zip(ds, reversed(ds))]


def carry_word(q):
    c = [0]
    for coefficient in q:
        c.append((coefficient+c[-1]) // 10)
    return c


def realize(q):
    assert q == q[::-1] and q[0] > 0
    result = [0] * len(q)
    for i in range((len(q)+1)//2):
        j = len(q)-1-i
        if i == j:
            assert q[i] % 2 == 0
            result[i] = q[i] // 2
        else:
            result[i] = min(q[i], 9)
            result[j] = q[i]-result[i]
            if j == len(q)-1 and result[j] == 0:
                result[j] = 1
                result[i] -= 1
    assert all(0 <= d <= 9 for d in result) and result[-1] > 0
    n = sum(d * 10**i for i, d in enumerate(result))
    assert pair_word(n) == q
    return n


def step(n):
    return n + int(str(n)[::-1])


def main():
    from pathlib import Path
    scan = json.loads(Path(__file__).with_name("result.json").read_text())
    sample = scan["examples_by_matched_word_count"]["7"][0]
    q, r = sample["q"], sample["r"]
    expected = [0,0,1,-3,5,-6,6,-6,6,-6,5,-3,1,0,0]
    assert [a-b for a,b in zip(q,r)] == expected
    n, m = realize(q), realize(r)
    assert len(str(n)) == len(str(m)) == 15
    start = n, m
    trajectory = []
    first_mismatch = None
    for t in range(9):
        a, b = pair_word(n), pair_word(m)
        ca, cb = carry_word(a), carry_word(b)
        match = ca == cb
        if not match and first_mismatch is None:
            first_mismatch = t
        if t < 7:
            assert match
        if t == 7:
            assert not match
        trajectory.append({
            "time": t, "n": str(n), "m": str(m),
            "n_reversal": str(int(str(n)[::-1])),
            "m_reversal": str(int(str(m)[::-1])),
            "n_next": str(step(n)), "m_next": str(step(m)),
            "n_digits_little_endian": digits(n),
            "m_digits_little_endian": digits(m),
            "q": a, "r": b,
            "q_carries": ca, "r_carries": cb,
            "complete_word_match": match,
        })
        n, m = step(n), step(m)
    assert first_mismatch == 7
    assert start[0] != start[1] and q != r
    print(json.dumps({
        "classification": "independent ordinary-integer replay of a concrete seven-word collision; no global memory sharpness claimed",
        "initial_integers": [str(n) for n in start],
        "initial_pair_words": {"q":q,"r":r},
        "initial_difference": expected,
        "matching_complete_words": 7,
        "first_mismatch_time": first_mismatch,
        "trajectory": trajectory,
    }, indent=2))


if __name__ == "__main__":
    main()
