#!/usr/bin/env python3
"""Read-only Lean log validation; writes one derived JSON audit record."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent


def sha_text(text):
    return hashlib.sha256(text.encode()).hexdigest()


def axiom_list(text):
    return sorted(a.strip() for a in text.split(",") if a.strip())


def main():
    receipt = json.loads((ROOT / "evidence/author-verification.json").read_text())
    source = json.loads((ROOT / "source-controls.json").read_text())
    module_log = (ROOT / "evidence/Agent10EightCarryCounterexample.log").read_text()
    audit_log = (ROOT / "evidence/EightCarryAudit.log").read_text()
    assert sha_text(module_log) == "c63ccbb205dd0694df6cc6d71d154b94b476b155cadf4aa9cd58d033ce3a1c0f"
    assert sha_text(audit_log) == "874992d4d85a5998bfecd6a6c941e08b47da64de8fda044185da733f2dd1956d"

    print_pattern = r"^'([^']+)' (?:(does not depend on any axioms)|depends on axioms:\s*\[([^\]]*)\])"
    printed = {}
    leftover = module_log
    for match in re.finditer(print_pattern, module_log, re.M):
        name = match.group(1)
        assert name not in printed
        printed[name] = [] if match.group(2) else axiom_list(match.group(3))
        leftover = leftover.replace(match.group(0), "", 1)
    assert not leftover.strip(), leftover
    assert len(printed) == 23
    assert {n.rsplit(".", 1)[-1] for n in printed} == {d["name"] for d in source["declarations"]}

    audit_pattern = r"^AUDIT_THEOREM (\S+) (\S+) : \[([^\]]*)\]"
    records = {}
    for match in re.finditer(audit_pattern, audit_log, re.M):
        assert match.group(1) == "Agent10EightCarryCounterexample"
        name = match.group(2)
        assert name not in records
        records[name] = axiom_list(match.group(3))
    assert len(records) == receipt["module_theorem_count"] == 48
    assert all(records[name] == axes for name, axes in printed.items())
    union = sorted({a for axes in records.values() for a in axes})
    assert union == receipt["module_axiom_union"] == ["Quot.sound", "propext"]
    summary = re.search(r"^FULL_MODULE_AUDIT theorems=(\d+) union=\[([^\]]*)\]", audit_log, re.M)
    assert summary and int(summary.group(1)) == len(records)
    assert axiom_list(summary.group(2)) == union
    trailing = audit_log[audit_log.index("AUDIT_THEOREM "):]
    trailing = re.sub(audit_pattern, "", trailing, flags=re.M)
    trailing = re.sub(r"^FULL_MODULE_AUDIT theorems=\d+ union=\[[^\]]*\]", "", trailing, flags=re.M)
    assert not trailing.strip(), trailing

    type_prefix = audit_log[:audit_log.index("AUDIT_THEOREM ")]
    markers = list(re.finditer(r"^Agent10EightCarryCounterexample\.(\w+)\b", type_prefix, re.M))
    endpoints = []
    source_public = {d["name"] for d in source["declarations"] if not d["private"]}
    assert {m.group(1) for m in markers} == source_public
    assert len(markers) == receipt["public_endpoint_count"] == 16
    expected_endpoints = {e["name"]: e for e in receipt["endpoint_records"]}
    for i, marker in enumerate(markers):
        name = "Agent10EightCarryCounterexample." + marker.group(1)
        stop = markers[i+1].start() if i+1 < len(markers) else len(type_prefix)
        block = type_prefix[marker.start():stop].strip()
        expected = expected_endpoints[name]
        assert block == expected["type_output"], name
        assert sha_text(block) == expected["type_output_sha256"], name
        line = type_prefix[:marker.start()].count("\n") + 1
        assert line == expected["type_log_line_1_based"], name
        assert records[name] == printed[name] == expected["axioms"]
        endpoints.append({"name": name, "type_output": block, "type_sha256": sha_text(block),
                          "axioms": records[name], "source_print_matches_origin_audit": True})
    for name, finite in receipt["finite_kernel_certificates"].items():
        assert records[finite["internal_name"]] == printed[finite["internal_name"]] == finite["axioms"] == []
    assert len(receipt["finite_kernel_certificates"]) == 6
    unsafe_records = re.findall(r"^UNSAFE_IMPLEMENTATION_AXIOM .*", audit_log, re.M)
    assert not unsafe_records

    result = {
        "status": "PASS", "reviewer": "/root/lean_runtime", "reviewer_executed_lean": False,
        "source_sha256": receipt["source_sha256"], "module_log_sha256": sha_text(module_log),
        "audit_log_sha256": sha_text(audit_log),
        "explicit_source_theorems": len(printed), "explicit_axiom_free_theorems": sum(not a for a in printed.values()),
        "all_explicit_source_prints_match_module_origin_audit": True,
        "module_origin_theorems_including_generated": len(records),
        "module_origin_axiom_free_theorems": sum(not a for a in records.values()),
        "module_origin_axiom_union": union, "unsafe_implementation_axiom_records": unsafe_records,
        "complete_wrapped_axiom_lists_parsed": True, "public_endpoint_count": len(endpoints),
        "finite_kernel_certificate_count": 6, "finite_kernel_certificate_axioms": [],
        "public_endpoints": endpoints,
        "module_origin_records": [{"name": n, "axioms": a} for n, a in sorted(records.items())],
        "audit_source_review": "The retained EightCarryAudit.lean selects declarations by imported module origin, applies Lean.collectAxioms to every theorem including generated helpers, rejects custom axioms and disallowed theorem axioms, and prints all sixteen public endpoint types. No unsafe implementation axiom was logged.",
        "limitation": "This validates retained outputs of the author's two successful Lean commands. The dependencies are reused pinned canonical-build-003 oleans; a fresh expanded whole-closure integration replay is separate."
    }
    (ROOT / "source-log-audit.json").write_text(json.dumps(result, indent=2, ensure_ascii=False) + "\n")
    print(json.dumps({k: result[k] for k in ["status", "explicit_source_theorems", "explicit_axiom_free_theorems", "module_origin_theorems_including_generated", "module_origin_axiom_free_theorems", "public_endpoint_count", "module_origin_axiom_union"]}))


if __name__ == "__main__":
    main()
