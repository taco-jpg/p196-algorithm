#!/usr/bin/env python3
"""Recheck the retained inputs to the independent NineCarrySharp review.

This script verifies identities and parses the parent's retained build output.
It does not run Lean or purport to replace the fresh full-closure kernel gate.
Run from any directory; the original workspace paths must still be available.
"""

from pathlib import Path
import hashlib
import json
import re


REVIEW = Path(__file__).resolve().parent
ROOT = Path('/workspace/scratch/4b20b8469eb3')
SHARP_SHA = '98e587d22229bdead323dc922b80760cdf79f3b27c14f3a1addaa4df2fb78266'
LOG_SHA = '9838435d63d76221838893e8e7781f692f361a844f9b9b2602f2c899dd7af06f'
EIGHT_SHA = '5da46ec31d7641307a6d8c1a5f81bd3b8bdfb097a39b5afa73145e062683d739'
DIFFERENCE_SHA = '60e724414ebd2bcbe590b0d61976147ef280eedfab6ff057d7cbdb7aeb0505d7'
EXPECTED_NAMES = [
    'pair_reconstruction_of_nine_le',
    'next_integer_reconstruction_of_nine_le',
    'not_pair_reconstruction_of_lt_nine',
    'not_next_integer_reconstruction_of_lt_nine',
    'uniform_pair_reconstruction_iff',
    'uniform_next_integer_reconstruction_iff',
    'eight_insufficient',
    'nine_sufficient',
    'nine_is_exact_uniform_threshold',
]
STANDARD = {'propext', 'Classical.choice', 'Quot.sound'}
TWO_AXIOM_NAMES = {
    'not_pair_reconstruction_of_lt_nine',
    'not_next_integer_reconstruction_of_lt_nine',
    'eight_insufficient',
}


def pin(path):
    path = Path(path)
    data = path.read_bytes()
    return {'path': str(path), 'bytes': len(data),
            'sha256': hashlib.sha256(data).hexdigest()}


def verify_pin(record):
    actual = pin(record['path'])
    assert actual['sha256'] == record['sha256'], (actual, record)
    assert actual['bytes'] == record['bytes'], (actual, record)
    return actual


receipt_path = ROOT / 'agent10-sharp/build-001/verification.json'
receipt = json.loads(receipt_path.read_text())
assert receipt['status'] == 'PASS' and receipt['returncode'] == 0
assert '--trust=0' in receipt['command']
assert '-j1' in receipt['command']
assert '-DElab.async=false' in receipt['command']
assert receipt['command'][0] == receipt['compiler']['path']
assert receipt['command'][-1] == receipt['source']['path']
verified = {key: verify_pin(receipt[key]) for key in ('source', 'compiler', 'log')}
assert verified['source']['sha256'] == SHARP_SHA
assert verified['log']['sha256'] == LOG_SHA
live_source = pin(ROOT / 'agent10-sharp/Agent10NineCarrySharp.lean')
assert live_source['sha256'] == SHARP_SHA
imports = [verify_pin(record) for record in receipt['import_source_pins']]
assert {Path(r['path']).name: r['sha256'] for r in imports} == {
    'Agent10EightCarryCounterexample.lean': EIGHT_SHA,
    'DifferenceObservability.lean': DIFFERENCE_SHA,
}

copied_records = []
for source_record in [verified['source'], *imports]:
    copied = pin(REVIEW / 'sources' / Path(source_record['path']).name)
    assert copied['sha256'] == source_record['sha256']
    copied_records.append(copied)
for source, name in [(receipt_path, 'parent-verification.json'),
                     (Path(receipt['log']['path']), 'parent-Agent10NineCarrySharp.log')]:
    assert source.read_bytes() == (REVIEW / 'evidence' / name).read_bytes()

source = Path(receipt['source']['path']).read_text()
assert re.findall(r'^import\s+(\S+)\s*$', source, re.M) == [
    'DifferenceObservability', 'Agent10EightCarryCounterexample']
assert re.findall(r'^theorem\s+(\w+)', source, re.M) == EXPECTED_NAMES
assert re.findall(r'^#print axioms\s+(\w+)', source, re.M) == EXPECTED_NAMES
without_comments = re.sub(r'/\-.*?\-/', '', source, flags=re.S)
without_prints = re.sub(r'^#print axioms.*$', '', without_comments, flags=re.M)
assert not re.search(r'\b(?:sorry|admit|axiom|unsafe|native_decide)\b|#eval', without_prints)

log = Path(receipt['log']['path']).read_text()
parsed = re.findall(r"'([^']+)' depends on axioms:\s*\[([^]]*)\]", log, re.S)
assert [name for name, _ in parsed] == [
    'Agent10NineCarrySharp.' + name for name in EXPECTED_NAMES]
axioms = []
for name, axiom_text in parsed:
    values = [v.strip() for v in axiom_text.split(',') if v.strip()]
    short_name = name.split('.')[-1]
    expected = {'propext', 'Quot.sound'} if short_name in TWO_AXIOM_NAMES else STANDARD
    assert set(values) == expected, (name, values, expected)
    axioms.append({'name': name, 'axioms': values})
assert 'error:' not in log

eight_path = next(Path(r['path']) for r in imports
                  if Path(r['path']).name == 'Agent10EightCarryCounterexample.lean')
eight = eight_path.read_text()
digits = {}
for side in ('left', 'right'):
    match = re.search(r'def ' + side + r'Digits\b.*?\(\[([^]]*)\] : List Nat\)',
                      eight, re.S)
    assert match
    digits[side] = [int(v) for v in match.group(1).split(',')]
    assert len(digits[side]) == 17
    assert all(0 <= digit <= 9 for digit in digits[side])
    assert digits[side][-1] != 0
integers = {side: sum(digit * 10**i for i, digit in enumerate(ds))
            for side, ds in digits.items()}
assert integers == {'left': 90000000560706169, 'right': 90000000806235169}
pairs = {side: [ds[i] + ds[-1-i] for i in range(17)]
         for side, ds in digits.items()}
assert pairs['left'][3] == 6 and pairs['right'][3] == 5
next_integers = {side: n + int(str(n)[::-1]) for side, n in integers.items()}
assert next_integers == {'left': 186160707060706178,
                         'right': 186153261606235178}
assert next_integers['left'] != next_integers['right']

output_position = receipt['command'].index('-o') + 1
compiled_paths = [Path(receipt['command'][output_position])]
compiled_paths += [Path(r['path']).with_suffix('.olean') for r in imports]
compiled = [pin(path) for path in compiled_paths]

result = {
    'status': 'PASS',
    'reviewer': 'Agent #10 semantic subagent /root/eight_carry_semantics',
    'reviewed_source_author': 'Agent #10 parent /root',
    'independence': 'The reviewer did not author or edit Agent10NineCarrySharp.lean.',
    'method': 'Read-only input hashing, retained parent build-output parsing, and initial-witness arithmetic sanity checks.',
    'new_lean_build_run_by_this_review': False,
    'direct_build_receipt': pin(receipt_path),
    'verified_build_inputs': verified,
    'live_source': live_source,
    'verified_direct_import_sources': imports,
    'copied_source_files': copied_records,
    'observed_compiled_artifacts': compiled,
    'compiled_artifact_scope': 'Current artifact hashes are identity pins only; this review does not independently reconstruct .olean files. The final fresh full-closure gate is separate.',
    'theorem_axiom_reports': axioms,
    'theorem_report_count': len(axioms),
    'axiom_union': sorted({a for entry in axioms for a in entry['axioms']}),
    'initial_witness_sanity': {
        'width': 17, 'integers': integers, 'active_difference_index': 3,
        'pair_values': {'left': pairs['left'][3], 'right': pairs['right'][3]},
        'next_integers': next_integers,
        'scope': 'Only initial values and next sums were recomputed here. The full eight-word trajectory is a separate kernel certificate and non-author review.'
    },
}
print(json.dumps(result, indent=2, sort_keys=True))
