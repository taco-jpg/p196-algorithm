// Exact bounded exterior-prefix necessary-graph search, Agent #10.
// No memoization, no approximate arithmetic, no Lean theorem claim.
// The K=3 and K=4 modes control against the preserved preceding searches.
// At K=5, q-r=(0,0,0,1,-3), and every shared bit at L-5 is explored.
// Derived additively from four_prefix_scan.cpp SHA256
// e40ca15a6b24360ad78cd3b238aa0c63346fd4330ed271f38e735481839acc6e.
// Observations at time t include all K low and all K reflected high carries.
// The decimal update is cross-checked against the source's column recurrences.
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

template <std::size_t N>
void array_json(std::ostream& out, const std::array<int, N>& a) {
    out << '[';
    for (std::size_t i = 0; i < N; ++i) {
        if (i) out << ',';
        out << a[i];
    }
    out << ']';
}

template <int K> struct Frame {
    std::array<int, K> left{}, right{}, next_left{}, next_right{};
    std::array<int, K+1> low_left{}, low_right{}, high_left{}, high_right{};
    int bit = 0;
};

template <int K> class Scan {
    using State = std::array<int, K>;
    using Carries = std::array<int, K+1>;
    using Path = std::array<Frame<K>, 8>;
    std::ofstream survivors;
    std::array<std::uint64_t, 8> survivor_counts{}, path_counts{}, attempted{};
    std::array<bool, 8> reached{};
    Path path{}, first_path{};
    std::vector<Path> examples;
    std::uint64_t start_count = 0, current_full_paths = 0;

    static void valid(const State& s) {
        if (!(1 <= s[0] && s[0] <= 18)) throw std::runtime_error("outer coefficient range");
        for (int v : s) if (!(0 <= v && v <= 18)) throw std::runtime_error("coefficient range");
    }

    static void carries(const State& s, int bit, Carries& low, Carries& high) {
        low[0] = 0;
        for (int i = 0; i < K; ++i) low[i+1] = (s[i]+low[i])/10;
        high[K] = bit;
        for (int i = K-1; i >= 0; --i) high[i] = (s[i]+high[i+1])/10;
        for (int c : low) if (c < 0 || c > 1) throw std::runtime_error("low carry range");
        for (int c : high) if (c < 0 || c > 1) throw std::runtime_error("high carry range");
    }

    static State advance(const State& s, const Carries& low, const Carries& high) {
        State lower{}, upper{}, next{};
        for (int i = 0; i < K; ++i) {
            lower[i] = (s[i]+low[i])%10;
            upper[i] = (s[i]+high[i+1])%10;
        }
        if (high[0] == 0) {
            for (int i = 0; i < K; ++i) next[i] = lower[i]+upper[i];
        } else {
            next[0] = lower[0]+1;
            for (int i = 1; i < K; ++i) next[i] = lower[i]+upper[i-1];
        }
        for (int i = 0; i < K; ++i) {
            int by_recurrence;
            if (high[0] == 0) {
                by_recurrence = 2*s[i]+low[i]+high[i+1]-10*(low[i+1]+high[i]);
            } else if (i == 0) {
                by_recurrence = s[0]+1-10*low[1];
            } else {
                by_recurrence = s[i]+s[i-1]+low[i]+high[i]
                                -10*(low[i+1]+high[i-1]);
            }
            if (next[i] != by_recurrence) throw std::runtime_error("recurrence cross-check");
        }
        valid(next);
        return next;
    }

    void dfs(int depth, const State& left, const State& right) {
        for (int bit = 0; bit < 2; ++bit) {
            ++attempted[depth];
            Frame<K> f;
            f.left = left;
            f.right = right;
            f.bit = bit;
            carries(left, bit, f.low_left, f.high_left);
            carries(right, bit, f.low_right, f.high_right);
            // low[0] is fixed zero; high[K] is the shared supplied inner bit.
            if (f.low_left != f.low_right || f.high_left != f.high_right) continue;
            ++path_counts[depth];
            reached[depth] = true;
            f.next_left = advance(left, f.low_left, f.high_left);
            f.next_right = advance(right, f.low_right, f.high_right);
            path[depth] = f;
            if (depth == 7) {
                if (current_full_paths == 0) first_path = path;
                ++current_full_paths;
            } else {
                dfs(depth+1, f.next_left, f.next_right);
            }
        }
    }

    void start(const State& left, const State& right) {
        valid(left);
        valid(right);
        for (int i = 0; i < K; ++i) {
            const int expected = i == K-2 ? 1 : (i == K-1 ? -3 : 0);
            if (left[i]-right[i] != expected) throw std::runtime_error("initial difference");
        }
        ++start_count;
        reached.fill(false);
        current_full_paths = 0;
        dfs(0, left, right);
        for (int i = 0; i < 8; ++i) if (reached[i]) ++survivor_counts[i];
        if (current_full_paths) {
            for (int i = 0; i < K; ++i) survivors << left[i] << ',';
            for (int i = 0; i < K; ++i) survivors << right[i] << ',';
            for (const auto& f : first_path) survivors << f.bit;
            survivors << ',' << current_full_paths << '\n';
            if (examples.size() < 5) examples.push_back(first_path);
        }
    }

    void counts_json(std::ostream& out, const std::array<std::uint64_t, 8>& counts) const {
        out << '[';
        for (int i = 0; i < 8; ++i) {
            if (i) out << ',';
            out << counts[i];
        }
        out << ']';
    }

    static void frame_json(std::ostream& out, const Frame<K>& f, int t) {
        out << "{\"time\":" << t << ",\"shared_inner_bit\":" << f.bit;
        out << ",\"left\":"; array_json(out, f.left);
        out << ",\"right\":"; array_json(out, f.right);
        out << ",\"low_left_with_zero\":"; array_json(out, f.low_left);
        out << ",\"low_right_with_zero\":"; array_json(out, f.low_right);
        out << ",\"high_left_with_inner_bit\":"; array_json(out, f.high_left);
        out << ",\"high_right_with_inner_bit\":"; array_json(out, f.high_right);
        out << ",\"terminal_overflow\":" << f.high_left[0];
        out << ",\"next_left\":"; array_json(out, f.next_left);
        out << ",\"next_right\":"; array_json(out, f.next_right);
        out << '}';
    }

public:
    explicit Scan(const std::string& survivor_path) : survivors(survivor_path) {
        if (!survivors) throw std::runtime_error("cannot open survivor CSV");
        for (int i = 0; i < K; ++i) survivors << "left_" << i << ',';
        for (int i = 0; i < K; ++i) survivors << "right_" << i << ',';
        survivors << "first_bits_time_0_to_7,full_eight_bit_path_count\n";
    }

    void run() {
        for (int p = 1; p <= 18; ++p) {
            for (int a = 0; a < (K >= 4 ? 19 : 1); ++a) {
                for (int a2 = 0; a2 < (K >= 5 ? 19 : 1); ++a2) {
                    for (int b = 0; b <= 17; ++b) {
                        for (int c = 3; c <= 18; ++c) {
                            State left{}, right{};
                            left[0] = right[0] = p;
                            if constexpr (K >= 4) left[1] = right[1] = a;
                            if constexpr (K >= 5) left[2] = right[2] = a2;
                            left[K-2] = b+1; right[K-2] = b;
                            left[K-1] = c-3; right[K-1] = c;
                            start(left, right);
                        }
                    }
                }
            }
        }
        const std::uint64_t expected = K == 5 ? 1871424 : (K == 4 ? 98496 : 5184);
        if (start_count != expected) throw std::runtime_error("enumeration count");
        for (int i = 1; i < 8; ++i) {
            if (survivor_counts[i] > survivor_counts[i-1]) throw std::runtime_error("nonmonotone survival");
            if (attempted[i] != 2*path_counts[i-1]) throw std::runtime_error("incomplete control enumeration");
        }
        if (attempted[0] != 2*start_count) throw std::runtime_error("incomplete initial enumeration");
        if constexpr (K == 3) {
            if (survivor_counts[6] != 37 || survivor_counts[7] != 0)
                throw std::runtime_error("three-prefix control mismatch");
        }
        survivors.close();
        if (!survivors) throw std::runtime_error("survivor CSV write failure");

        std::cout << "{\n\"prefix_length\":" << K << ",\n\"observation_count\":8,\n";
        std::cout << "\"initial_prefix_count\":" << start_count << ",\n\"initial_difference\":";
        State difference{}; difference[K-2] = 1; difference[K-1] = -3;
        array_json(std::cout, difference);
        std::cout << ",\n\"shared_inner_carry\":\"L-" << K << "\",\n";
        std::cout << "\"low_carries_observed\":[";
        for (int i = 1; i <= K; ++i) { if (i > 1) std::cout << ','; std::cout << i; }
        std::cout << "],\n\"high_carries_observed\":[\"L\"";
        for (int i = 1; i < K; ++i) std::cout << ",\"L-" << i << "\"";
        std::cout << "],\n\"surviving_starts_for_1_to_8_observations\":";
        counts_json(std::cout, survivor_counts);
        std::cout << ",\n\"compatible_bit_paths_for_1_to_8_observations\":";
        counts_json(std::cout, path_counts);
        std::cout << ",\n\"attempted_bit_edges_at_times_0_to_7\":";
        counts_json(std::cout, attempted);
        std::cout << ",\n\"method\":\"exhaustive depth-8 DFS; no memoization; fixed-size states; digit and arithmetic updates cross-checked\",\n";
        std::cout << "\"classification\":\"exact finite computational necessary-graph evidence; no Lean theorem or whole-word realization claimed\",\n";
        std::cout << "\"scope\":\"positive outer coefficient 1..18, all other coefficients 0..18, prescribed oriented difference; every shared Boolean inner-carry path, all low and high carries; center, overlap, and omitted-inner temporal constraints are not imposed\",\n";
        std::cout << "\"complete_path_examples\":[\n";
        for (std::size_t j = 0; j < examples.size(); ++j) {
            if (j) std::cout << ",\n";
            std::cout << '[';
            for (int t = 0; t < 8; ++t) {
                if (t) std::cout << ",\n";
                frame_json(std::cout, examples[j][t], t);
            }
            std::cout << ']';
        }
        std::cout << "\n]\n}\n";
        if (!std::cout) throw std::runtime_error("JSON output failure");
    }
};

int main(int argc, char** argv) {
    try {
        if (argc != 3) throw std::runtime_error("usage: five_prefix_scan 3|4|5 SURVIVORS.csv");
        if (std::string(argv[1]) == "3") { Scan<3> scan(argv[2]); scan.run(); }
        else if (std::string(argv[1]) == "4") { Scan<4> scan(argv[2]); scan.run(); }
        else if (std::string(argv[1]) == "5") { Scan<5> scan(argv[2]); scan.run(); }
        else throw std::runtime_error("prefix length must be 3, 4, or 5");
        return 0;
    } catch (const std::exception& e) {
        std::cerr << "ERROR: " << e.what() << '\n';
        return 1;
    }
}
