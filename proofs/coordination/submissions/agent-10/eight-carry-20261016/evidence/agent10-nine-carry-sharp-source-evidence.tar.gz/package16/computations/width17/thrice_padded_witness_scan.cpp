// Exhaustive width-17 lifts of the complete 1326-row five-prefix filter.
// The filter is computational evidence: its actual-history inclusion has
// not been formalized in Lean. The actual simulator below is copied byte
// for byte from Agent10's unchanged once-padded scan.
//
// Every symmetric center-even completion is enumerated. The CSV's first
// compatible bit string is metadata only and NEVER restricts actual paths.
// Swapping the two words covers the negated initial difference.
#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <fstream>
#include <iostream>
#include <map>
#include <set>
#include <sstream>
#include <stdexcept>
#include <string>
#include <utility>
#include <vector>

using Word = std::vector<int>;
using Prefix = std::array<int,5>;
constexpr int width = 17;
const Word difference{0,0,0,1,-3,5,-6,6,-6,6,-6,5,-3,1,0,0,0};
constexpr std::uint64_t extensions_per_prefix = 14ULL*13*13*7;
constexpr std::uint64_t full_domain_count = 18ULL*19*19*18*16*extensions_per_prefix;
std::array<std::uint64_t,9> survived{};
std::array<std::map<std::string,std::uint64_t>,9> patterns;
std::array<std::vector<std::pair<Word,Word>>,9> examples;
std::vector<Prefix> prefixes;
std::string first_collision_path;

#include "actual_simulator.inc"

void print_word(std::ostream& out,const Word& q) {
  out<<'[';
  for(std::size_t i=0;i<q.size();++i){if(i)out<<',';out<<q[i];}
  out<<']';
}

void print_pair(std::ostream& out,const Word& q,const Word& r) {
  out<<"{\"q\":";print_word(out,q);
  out<<",\"r\":";print_word(out,r);out<<'}';
}

void inspect(const Word& r) {
  Word q(width);
  for(int i=0;i<width;++i)q[i]=r[i]+difference[i];
  assert(admissible(q) && admissible(r));
  ++survived[0];
  Word a=q,b=r;
  std::string pattern;
  for(int t=0;t<8;++t) {
    Word ca=carries(a),cb=carries(b);
    if(ca!=cb)return;
    ++survived[t+1];
    pattern.push_back(ca.back() ? 'O':'N');
    ++patterns[t+1][pattern];
    if(examples[t+1].size()<3)examples[t+1].push_back({q,r});
    if(t!=7){a=next_pairs(a,ca);b=next_pairs(b,cb);}
  }
  if(survived[8]==1) {
    std::ofstream first(first_collision_path);
    if(!first)throw std::runtime_error("cannot write first collision");
    print_pair(first,q,r);first<<'\n';first.close();
    if(!first)throw std::runtime_error("first collision write failed");
    std::cerr<<"FIRST_EIGHT_WORD_COLLISION ";print_pair(std::cerr,q,r);
    std::cerr<<std::endl;
  }
}

void complete(Word& r,int i) {
  if(i==9){inspect(r);return;}
  int lo=std::max(0,-difference[i]);
  int hi=std::min(18,18-difference[i]);
  for(int v=lo;v<=hi;++v) {
    if(i==8 && v%2!=0)continue;
    r[i]=r[width-1-i]=v;
    complete(r,i+1);
  }
}

void read_prefixes(const std::string& path) {
  std::ifstream file(path);
  if(!file)throw std::runtime_error("cannot open prefix CSV");
  std::string line;
  std::getline(file,line);
  const std::string expected = "left_0,left_1,left_2,left_3,left_4,right_0,right_1,right_2,right_3,right_4,first_bits_time_0_to_7,full_eight_bit_path_count";
  if(line!=expected)throw std::runtime_error("prefix CSV header mismatch");
  std::set<Prefix> seen;
  while(std::getline(file,line)) {
    std::stringstream row(line);
    std::vector<std::string> fields;
    std::string field;
    while(std::getline(row,field,','))fields.push_back(field);
    if(fields.size()!=12)throw std::runtime_error("prefix CSV column count");
    Prefix q{},r{};
    for(int i=0;i<5;++i) {
      q[i]=std::stoi(fields[i]);r[i]=std::stoi(fields[i+5]);
      if(q[i]<0 || q[i]>18 || r[i]<0 || r[i]>18 || q[i]-r[i]!=difference[i])
        throw std::runtime_error("prefix range/difference mismatch");
    }
    if(q[0]==0 || r[0]==0)throw std::runtime_error("zero outer coefficient");
    if(fields[10].size()!=8 || fields[10].find_first_not_of("01")!=std::string::npos || std::stoull(fields[11])==0)
      throw std::runtime_error("invalid prefix path metadata");
    // No comparison of actual controls with fields[10] occurs anywhere.
    if(!seen.insert(r).second)throw std::runtime_error("duplicate prefix");
    prefixes.push_back(r);
  }
  if(prefixes.size()!=1326)throw std::runtime_error("prefix CSV row count");
}

int main(int argc,char** argv) {
  try {
    if(argc!=3)throw std::runtime_error("usage: thrice_padded_witness_scan SURVIVORS.csv FIRST_COLLISION.json");
    first_collision_path=argv[2];
    read_prefixes(argv[1]);
    for(const auto& prefix:prefixes) {
      Word r(width);
      for(int i=0;i<5;++i)r[i]=r[width-1-i]=prefix[i];
      const auto before=survived[0];
      complete(r,5);
      if(survived[0]-before!=extensions_per_prefix)
        throw std::runtime_error("incomplete center extension enumeration");
    }
    if(survived[0]!=21961212ULL || full_domain_count!=30994524288ULL)
      throw std::runtime_error("candidate count mismatch");
    std::cout<<"{\n  \"width\":17,\n  \"difference\":";print_word(std::cout,difference);
    std::cout<<",\n  \"complete_words_requested\":8,";
    std::cout<<"\n  \"full_admissible_domain_before_filter\":"<<full_domain_count<<',';
    std::cout<<"\n  \"full_domain_prefix_count\":1871424,";
    std::cout<<"\n  \"filtered_prefix_count\":"<<prefixes.size()<<',';
    std::cout<<"\n  \"extensions_per_filtered_prefix\":"<<extensions_per_prefix<<',';
    std::cout<<"\n  \"filter\":\"all five low and reflected high carries, shared actual bit at L-5, eight observations\",";
    std::cout<<"\n  \"filter_actual_inclusion_formalized_in_Lean\":false,";
    std::cout<<"\n  \"first_CSV_bit_path_restricts_actual_scan\":false,";
    std::cout<<"\n  \"negative_sign_coverage\":\"swap q and r\",";
    std::cout<<"\n  \"classification\":\"exact exhaustive actual-word scan inside the computational five-prefix filter; full-domain exclusion requires correctness of the necessary projection and complete filter generation\",";
    std::cout<<"\n  \"survivors_after_prefix_filter_and_n_complete_words\":[";
    for(int i=0;i<=8;++i){if(i)std::cout<<',';std::cout<<survived[i];}
    std::cout<<"],\n  \"history_patterns\":{";
    bool first=true;
    for(int i=1;i<=8;++i)for(const auto& [pattern,count]:patterns[i]) {
      if(!first)std::cout<<',';
      first=false;std::cout<<'\"'<<pattern<<"\":"<<count;
    }
    std::cout<<"},\n  \"examples_by_matched_word_count\":{";
    first=true;
    for(int i=1;i<=8;++i) {
      if(examples[i].empty())continue;
      if(!first)std::cout<<',';
      first=false;std::cout<<'\"'<<i<<"\":[";
      bool first_pair=true;
      for(const auto& [q,r]:examples[i]) {
        if(!first_pair)std::cout<<',';
        first_pair=false;print_pair(std::cout,q,r);
      }
      std::cout<<']';
    }
    std::cout<<"}\n}\n";
    if(!std::cout)throw std::runtime_error("result output failure");
    return 0;
  } catch(const std::exception& e) {
    std::cerr<<"ERROR: "<<e.what()<<'\n';
    return 1;
  }
}
