#include <algorithm>
#include <array>
#include <cassert>
#include <cstdint>
#include <iostream>
#include <map>
#include <string>
#include <utility>
#include <vector>

// Exact, exhaustive once-padded search. Width is 13, difference is
// [0,1,-3,5,-6,6,-6,6,-6,5,-3,1,0], and observations are t=0,...,7.
// Swapping the two words covers the opposite sign.
//
// Filter completeness: Agent10PrefixExclusion.actual_history_survives maps
// every actual complete eight-word agreement into the WEAK shared-bit prefix
// graph used below. All 324 possible initial prefixes are tested. The weaker
// graph is used for enumeration even though the stronger necessary graph
// leaves only six starts. No successful prefix is skipped or sampled.
using Word=std::vector<int>;
using Prefix=std::pair<int,int>;
constexpr int width=13;
const Word difference{0,1,-3,5,-6,6,-6,6,-6,5,-3,1,0};
std::array<std::uint64_t,9> survived{};
std::map<std::string,std::uint64_t> full_patterns;
std::vector<std::pair<Word,Word>> examples;
std::vector<Prefix> weak_prefixes,strong_prefixes;

std::array<int,4> observe(Prefix state,int e) {
  int p=state.first,q=state.second;
  int a=p/10,b=(q+a)/10,u=(q+e)/10,h=(p+u)/10;
  return {a,b,u,h};
}
Prefix next_prefix(Prefix state,int e) {
  int p=state.first,q=state.second;
  auto [a,b,u,h]=observe(state,e);
  Prefix result=h==0 ? Prefix{2*p+u-10*a,2*q+a+e-10*(b+u)}
                    : Prefix{p-10*a+1,p+q+a+u-10*(b+h)};
  assert(1<=result.first && result.first<=18);
  assert(0<=result.second && result.second<=18);
  return result;
}
bool prefix_survives(int n,Prefix q,Prefix r,bool strong) {
  if(n==0)return true;
  for(int e=0;e<2;++e) {
    auto a=observe(q,e),b=observe(r,e);
    bool match=strong ? a==b : a[0]==b[0] && a[1]==b[1] && a[3]==b[3];
    if(match && prefix_survives(n-1,next_prefix(q,e),next_prefix(r,e),strong))return true;
  }
  return false;
}
bool admissible(const Word& q) {
  if(q.empty() || q.front()==0)return false;
  for(std::size_t i=0;i<q.size();++i) {
    if(q[i]<0 || q[i]>18 || q[i]!=q[q.size()-1-i])return false;
    if(i==q.size()-1-i && q[i]%2!=0)return false;
  }
  return true;
}
Word carries(const Word& q) {
  Word c(q.size()+1,0);
  for(std::size_t i=0;i<q.size();++i)c[i+1]=(q[i]+c[i])/10;
  return c;
}
Word next_pairs(const Word& q,const Word& c) {
  Word d;
  for(std::size_t i=0;i<q.size();++i)d.push_back((q[i]+c[i])%10);
  if(c.back())d.push_back(c.back());
  Word result(d.size());
  for(std::size_t i=0;i<d.size();++i)result[i]=d[i]+d[d.size()-1-i];
  assert(admissible(result));
  return result;
}
void inspect(const Word& r) {
  Word q(width);
  for(int i=0;i<width;++i)q[i]=r[i]+difference[i];
  assert(admissible(q) && admissible(r));
  ++survived[0];
  Word a=q,b=r;
  std::string pattern;
  for(int t=0;t<8;++t) {
    Word ca=carries(a),cb=carries(b);
    if(ca!=cb)return;
    ++survived[t+1];
    pattern.push_back(ca.back() ? 'O':'N');
    if(t!=7) { a=next_pairs(a,ca); b=next_pairs(b,cb); }
  }
  assert(prefix_survives(8,{q[0],q[1]},{r[0],r[1]},true));
  ++full_patterns[pattern];
  if(examples.size()<5)examples.push_back({q,r});
}
void complete(Word& r,int i) {
  if(i==7) { inspect(r);return; }
  int lo=std::max(0,-difference[i]);
  int hi=std::min(18,18-difference[i]);
  for(int v=lo;v<=hi;++v) {
    if(i==6 && v%2!=0)continue;
    r[i]=r[width-1-i]=v;
    complete(r,i+1);
  }
}
void print_word(const Word& q) {
  std::cout<<'[';
  for(std::size_t i=0;i<q.size();++i){if(i)std::cout<<',';std::cout<<q[i];}
  std::cout<<']';
}
void print_prefixes(const std::vector<Prefix>& ps) {
  std::cout<<'[';
  bool first=true;
  for(auto [p,q]:ps){if(!first)std::cout<<',';first=false;std::cout<<'['<<p<<','<<q<<']';}
  std::cout<<']';
}
int main() {
  for(int p=1;p<=18;++p)for(int q=0;q<=17;++q) {
    if(prefix_survives(8,{p,q+1},{p,q},true))strong_prefixes.push_back({p,q});
    if(!prefix_survives(8,{p,q+1},{p,q},false))continue;
    weak_prefixes.push_back({p,q});
    Word r(width);
    r[0]=r[12]=p;r[1]=r[11]=q;
    complete(r,2);
  }
  assert(weak_prefixes.size()==30 && strong_prefixes.size()==6);
  assert(survived[0]==7949760);
  std::cout<<"{\n  \"width\":13,\n  \"difference\":";print_word(difference);
  std::cout<<",\n  \"complete_words_requested\":8,\n  \"all_admissible_candidates_before_filter\":85857408,";
  std::cout<<"\n  \"prefix_filter\":\"weak shared-bit graph, identical to compiled actual_history_survives\",";
  std::cout<<"\n  \"prefix_pairs_checked\":324,\n  \"weak_surviving_r_prefixes\":";print_prefixes(weak_prefixes);
  std::cout<<",\n  \"strong_surviving_r_prefixes\":";print_prefixes(strong_prefixes);
  std::cout<<",\n  \"survivors_after_prefix_filter_and_n_complete_words\":[";
  for(int i=0;i<=8;++i){if(i)std::cout<<',';std::cout<<survived[i];}
  std::cout<<"],\n  \"eight_word_overflow_patterns\":{";
  bool first=true;
  for(const auto& [k,v]:full_patterns){if(!first)std::cout<<',';first=false;std::cout<<'"'<<k<<"\":"<<v;}
  std::cout<<"},\n  \"eight_word_examples\":[";
  first=true;
  for(const auto& [q,r]:examples){
    if(!first)std::cout<<',';
    first=false;
    std::cout<<"{\"q\":";print_word(q);std::cout<<",\"r\":";print_word(r);std::cout<<'}';
  }
  std::cout<<"]\n}\n";
}
