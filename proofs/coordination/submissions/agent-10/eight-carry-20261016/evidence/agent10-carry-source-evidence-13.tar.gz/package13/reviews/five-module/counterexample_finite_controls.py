#!/usr/bin/env python3
"""Independent ordinary-integer check of the pinned six-carry certificate.

This script starts with decimal integers, performs n + reverse(n), and derives
every carry word directly from their digit additions. Lean certificate rows
are read only for comparison. This is finite corroboration, not a Lean proof.
"""

from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path
import re


HERE = Path(__file__).resolve().parent
SOURCE = HERE / "sources/Agent10SixCarryCounterexample.lean"
SOURCE_SHA256 = "b4277ca76c6ad874db41933735ae7b677990e120e0bc5be01f9c0579c882f869"
INPUTS = (80000571539, 70000817069)


def certificate_data(source: str) -> tuple[list[list[int]], list[list[int]], list[int]]:
    block = source.split("private def rows", 1)[1].split("private def trace", 1)[0]
    match = re.search(r"if b then\s*(\[.*?\])\s*else\s*(\[.*\])", block, re.S)
    assert match is not None
    right_rows, left_rows = map(ast.literal_eval, match.groups())
    width_block = source.split("def traceWidth", 1)[1].split("private theorem", 1)[0]
    width_match = re.search(r"\(\s*(\[[0-9,\s]+\])\s*:\s*List Nat", width_block)
    assert width_match is not None
    widths = ast.literal_eval(width_match.group(1))
    for name, n in zip(("leftDigits", "rightDigits"), INPUTS):
        digit_block = source.split(f"def {name}", 1)[1].split(".getD", 1)[0]
        digit_match = re.search(r"\(\s*(\[[0-9,\s]+\])\s*:\s*List Nat", digit_block)
        assert digit_match is not None
        digits = ast.literal_eval(digit_match.group(1))
        assert len(digits) == 11 and digits[-1] > 0
        assert all(0 <= d <= 9 for d in digits)
        assert digits == [int(d) for d in str(n)[::-1]]
        assert sum(d * 10**i for i, d in enumerate(digits)) == n
    assert len(left_rows) == len(right_rows) == len(widths) == 7
    return left_rows, right_rows, widths


def ordinary_addition(n: int) -> dict:
    digits = [int(d) for d in str(n)[::-1]]
    columns = [a + b for a, b in zip(digits, reversed(digits))]
    carries = [0]
    output = []
    for q in columns:
        total = q + carries[-1]
        output.append(total % 10)
        carries.append(total // 10)
    reversed_n = int(str(n)[::-1])
    next_n = n + reversed_n
    from_addition = sum(d * 10**i for i, d in enumerate(output))
    from_addition += carries[-1] * 10 ** len(digits)
    assert from_addition == next_n
    assert all(c in (0, 1) for c in carries)
    assert len(str(next_n)) == len(digits) + carries[-1]
    return {
        "integer": n,
        "reverse": reversed_n,
        "next_integer": next_n,
        "width": len(digits),
        "digits_lsd_first": digits,
        "pair_sums_lsd_first": columns,
        "complete_carry_word_c0_through_cL": carries,
        "observed_inner_bit_at_width_minus_two": carries[len(digits) - 2],
    }


def run() -> dict:
    data = SOURCE.read_bytes()
    assert hashlib.sha256(data).hexdigest() == SOURCE_SHA256
    left_rows, right_rows, widths = certificate_data(data.decode())
    trajectories = []
    for initial, rows in zip(INPUTS, (left_rows, right_rows)):
        n = initial
        states = []
        for t in range(7):
            state = ordinary_addition(n)
            assert state["pair_sums_lsd_first"] == rows[t]
            assert state["width"] == widths[t]
            state["time"] = t
            states.append(state)
            n = state["next_integer"]
        trajectories.append(states)
    left, right = trajectories
    assert left[0]["next_integer"] == 173518071547
    assert right[0]["next_integer"] == 166072617076
    assert left[0]["next_integer"] != right[0]["next_integer"]
    carry_positions_checked = 0
    for t in range(6):
        assert left[t]["width"] == right[t]["width"]
        assert left[t]["complete_carry_word_c0_through_cL"] == right[t]["complete_carry_word_c0_through_cL"]
        carry_positions_checked += len(left[t]["complete_carry_word_c0_through_cL"])
    assert left[6]["complete_carry_word_c0_through_cL"][1] == 1
    assert right[6]["complete_carry_word_c0_through_cL"][1] == 0
    difference = [a-b for a, b in zip(left_rows[0], right_rows[0])]
    assert difference == [1, -3, 5, -6, 6, -6, 6, -6, 5, -3, 1]
    assert max(map(abs, difference)) == 6
    shared_bits = [left[t]["observed_inner_bit_at_width_minus_two"] for t in range(6)]
    assert shared_bits == [right[t]["observed_inner_bit_at_width_minus_two"] for t in range(6)]
    return {
        "status": "PASS",
        "classification": "INDEPENDENT_FINITE_ARITHMETIC_CORROBORATION_NOT_KERNEL_PROOF",
        "source": str(SOURCE),
        "source_sha256": SOURCE_SHA256,
        "initial_integers": list(INPUTS),
        "next_integers": [left[0]["next_integer"], right[0]["next_integer"]],
        "widths_at_times_zero_through_six": widths,
        "complete_observation_times_equal": list(range(6)),
        "matching_carry_positions_including_initial_and_terminal": carry_positions_checked,
        "seventh_observation_separating_index": 1,
        "seventh_observation_values": [1, 0],
        "initial_pair_sum_difference": difference,
        "initial_difference_sup_norm": 6,
        "initial_terminal_overflows": [left[0]["complete_carry_word_c0_through_cL"][-1], right[0]["complete_carry_word_c0_through_cL"][-1]],
        "shared_inner_bits_for_first_six_observations": shared_bits,
        "relation_to_prefix_graph_control": "The actual shared-bit path need not equal the illustrative all-zero path found by the earlier necessary-graph BFS.",
        "left_trajectory": left,
        "right_trajectory": right,
        "scope": "Six complete observations are insufficient for exterior pair-sum or next-integer determination. This witness separates at the seventh observation and establishes no insufficiency result for seven or eight observations.",
    }


if __name__ == "__main__":
    record = run()
    destination = HERE / "counterexample-finite-controls.json"
    destination.write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({"status": record["status"], "output": str(destination), "source_sha256": SOURCE_SHA256,
                      "matched_carry_positions": record["matching_carry_positions_including_initial_and_terminal"],
                      "widths": record["widths_at_times_zero_through_six"],
                      "next_integers": record["next_integers"]}, indent=2))
