#!/usr/bin/env python3
"""Independent finite arithmetic controls for the reviewed count source.

These checks corroborate finite data and indexing. They are not Lean proofs.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import subprocess


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--repo', type=Path, required=True)
    p.add_argument('--commit', required=True)
    p.add_argument('--output', type=Path, required=True)
    a = p.parse_args()
    path = 'proofs/PrefixCarryBound__487522879609bf3a.lean'
    data = subprocess.check_output(['git', 'show', a.commit+':'+path], cwd=a.repo)
    blob = int(re.search(r'def rankBlob : Nat := (\d+)', data.decode()).group(1))
    states = [(p, q) for p in range(1, 19) for q in range(19)]
    def valid(s):
        return 1 <= s[0] <= 18 and 0 <= s[1] <= 18
    def overflow(s, v):
        return (s[0] + (s[1] + v) // 10) // 10
    def cost(s, v):
        return max(0, 1 - overflow(s, v))
    def nxt(s, v):
        p, q = s
        x, u = p // 10, (q + v) // 10
        b, h = (q + x) // 10, (p + u) // 10
        if h == 0:
            return max(0, 2*p+u-10*x), max(0, 2*q+x+v-10*(b+u))
        return max(0, p-10*x+1), max(0, p+q+x+u-10*(b+h))
    def rank(n, s):
        if n == 0:
            return 0
        if n == 9:
            return 4
        return (blob >> (3*((n-1)*342+(s[0]-1)*19+s[1]))) % 8
    edges = [(s, v, nxt(s, v), cost(s, v)) for s in states for v in (0, 1)]
    assert all(valid(ns) and overflow(s, v) in (0, 1) for s, v, ns, _ in edges)
    violations = [(n, s, v) for n in range(9) for s, v, ns, c in edges
                  if rank(n+1, s) > c + rank(n, ns)]
    assert not violations
    dp = [{s: 0 for s in states}]
    for n in range(1, 10):
        dp.append({s: min(cost(s, v)+dp[n-1][nxt(s, v)] for v in (0, 1)) for s in states})
    ranks7 = [rank(7, s) for s in states]
    assert min(ranks7) >= 3
    assert all(rank(n, s) <= dp[n][s] for n in range(10) for s in states)
    singleton = []
    for initial in range(1, 19):
        coefficients, count, pattern, widths = [initial], 0, [], [1]
        for _ in range(7):
            c, digits = 0, []
            for q in coefficients:
                total = q + c
                digits.append(total % 10)
                c = total // 10
            assert c in (0, 1)
            pattern.append(c)
            count += c == 0
            if c:
                digits.append(c)
            coefficients = [x+y for x, y in zip(digits, reversed(digits))]
            widths.append(len(coefficients))
        singleton.append({'initial_coefficient': initial, 'nonoverflow_count_7': count,
                          'outgoing_carries_t0_through_t6': pattern, 'widths_t0_through_t7': widths})
    assert min(x['nonoverflow_count_7'] for x in singleton) >= 3
    record = {'classification': 'INDEPENDENT_FINITE_CONTROL_NOT_LEAN_PROOF',
              'source_commit': a.commit, 'rank_source_path': path,
              'rank_source_sha256': hashlib.sha256(data).hexdigest(),
              'valid_states': len(states), 'bit_labelled_edges': len(edges),
              'next_valid_checks_passed': True, 'rank_step_inequalities_checked': 9*len(edges),
              'rank_step_violations': violations,
              'rank7_distribution': dict(sorted(Counter(ranks7).items())),
              'minimum_exact_graph_cost_by_horizon': {str(n): min(dp[n].values()) for n in range(10)},
              'rank_is_lower_bound_on_dp_horizons_0_through_9': True,
              'singleton_cases': singleton,
              'minimum_singleton_count_7': min(x['nonoverflow_count_7'] for x in singleton),
              'status': 'PASS'}
    a.output.write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps({k: record[k] for k in ['status', 'valid_states', 'bit_labelled_edges',
          'rank_step_inequalities_checked', 'rank7_distribution', 'minimum_exact_graph_cost_by_horizon',
          'minimum_singleton_count_7']}, indent=2))


if __name__ == '__main__':
    main()
