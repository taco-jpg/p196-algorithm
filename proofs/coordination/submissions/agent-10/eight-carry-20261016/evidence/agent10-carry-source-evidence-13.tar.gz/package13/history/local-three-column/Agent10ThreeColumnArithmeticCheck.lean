import Agent10PrefixExclusion
set_option maxHeartbeats 10000000
set_option maxRecDepth 100000
namespace Agent10ThreeColumnArithmeticCheck
open CarryObservability Agent10PrefixExclusion
open DifferenceObservability CarryObservabilityActual
open DecimalDigits FoldedDecimal OverflowCarryNormalization CarryHistory

abbrev State3 := Nat × Nat × Nat

def Valid3 (s : State3) : Prop :=
  1 ≤ s.1 ∧ s.1 ≤ 18 ∧ s.2.1 ≤ 18 ∧ s.2.2 ≤ 18

def state3Of (q : Nat → Nat) : State3 := (q 0, q 1, q 2)
def low1 (s : State3) : Nat := s.1 / 10
def low2 (s : State3) : Nat := (s.2.1 + low1 s) / 10
def low3 (s : State3) : Nat := (s.2.2 + low2 s) / 10
def highMiddle (s : State3) (v : Bool) : Nat := (s.2.2 + innerBit v) / 10
def highFirst (s : State3) (v : Bool) : Nat := (s.2.1 + highMiddle s v) / 10
def overflow3 (s : State3) (v : Bool) : Nat := (s.1 + highFirst s v) / 10

def next3 (s : State3) (v : Bool) : State3 :=
  if overflow3 s v = 0 then
    (2*s.1 + highFirst s v - 10*low1 s,
      2*s.2.1 + low1 s + highMiddle s v - 10*(low2 s + highFirst s v),
      2*s.2.2 + low2 s + innerBit v - 10*(low3 s + highMiddle s v))
  else
    (s.1 - 10*low1 s + 1,
      s.1 + s.2.1 + low1 s + highFirst s v - 10*(low2 s + overflow3 s v),
      s.2.1 + s.2.2 + low2 s + highMiddle s v - 10*(low3 s + highFirst s v))

def compatible3 (s r : State3) (v : Bool) : Bool :=
  decide (low1 s = low1 r ∧ low2 s = low2 r ∧ low3 s = low3 r ∧
    highFirst s v = highFirst r v ∧ overflow3 s v = overflow3 r v)

/-- Exact bounded-state coding forces each intermediate triple to normalize
before another transition; this changes no actual carry arithmetic. -/
def encode3 (s : State3) : Nat := 361*s.1 + 19*s.2.1 + s.2.2
def decode3 (n : Nat) : State3 := (n/361,n/19%19,n%19)
def nextCode (s : Nat) (v : Bool) : Nat := encode3 (next3 (decode3 s) v)
def compatibleCode (s r : Nat) (v : Bool) : Bool :=
  compatible3 (decode3 s) (decode3 r) v

def survivesCode : Nat → Nat → Nat → Bool
  | 0,_,_ => true
  | n+1,s,r =>
      (compatibleCode s r false && survivesCode n (nextCode s false) (nextCode r false)) ||
      (compatibleCode s r true && survivesCode n (nextCode s true) (nextCode r true))

def survives3 (n : Nat) (s r : State3) : Bool :=
  survivesCode n (encode3 s) (encode3 r)

theorem decode_encode3 (s : State3) (hs : Valid3 s) : decode3 (encode3 s) = s := by
  rcases s with ⟨p,q,r⟩
  rcases hs with ⟨hp,hp',hq,hr⟩
  dsimp only at hp hp' hq hr
  simp only [encode3,decode3]
  apply Prod.ext
  · dsimp only; omega
  · apply Prod.ext <;> dsimp only <;> omega

def observedBit3 (q : Nat → Nat) (L : Nat) : Bool :=
  decide (carry q (L-3) = 1)

theorem observedBit3_value (q : Nat → Nat) (L : Nat)
    (hq : ∀ i, i < L → q i ≤ 18) :
    innerBit (observedBit3 q L) = carry q (L-3) := by
  have hb := carry_bounded q L hq (L-3) (by omega)
  by_cases h : carry q (L-3) = 1
  · simp [innerBit,observedBit3,h]
  · have hz : carry q (L-3) = 0 := by omega
    simp [innerBit,observedBit3,hz]

theorem state3_valid (q : Nat → Nat) (L : Nat)
    (hq : Admissible L q) (hL : 3 ≤ L) : Valid3 (state3Of q) := by
  change 1 ≤ q 0 ∧ q 0 ≤ 18 ∧ q 1 ≤ 18 ∧ q 2 ≤ 18
  have h0 := hq.2.2.1 0 hq.1
  have h1 := hq.2.2.1 1 (by omega)
  have h2 := hq.2.2.1 2 (by omega)
  have hp := hq.2.1
  exact ⟨by omega,h0,h1,h2⟩

/-- The high coordinates are derived by exact symmetry, including overlap. -/
theorem prefix_carries3_exact (q : Nat → Nat) (L : Nat)
    (hq : Admissible L q) (hL : 3 ≤ L) :
    low1 (state3Of q) = carry q 1 ∧
    low2 (state3Of q) = carry q 2 ∧
    low3 (state3Of q) = carry q 3 ∧
    highMiddle (state3Of q) (observedBit3 q L) = carry q (L-2) ∧
    highFirst (state3Of q) (observedBit3 q L) = carry q (L-1) ∧
    overflow3 (state3Of q) (observedBit3 q L) = carry q L := by
  have hbit := observedBit3_value q L hq.2.2.1
  have h0 := (folded_carry_transition q L 0 hq.1 hq.2.2.2.1).2
  have h1 := (folded_carry_transition q L 1 (by omega) hq.2.2.2.1).2
  have h2 := (folded_carry_transition q L 2 (by omega) hq.2.2.2.1).2
  have hi1 : L-1-1=L-2 := by omega
  have hi2 : L-1-2=L-3 := by omega
  simp only [Nat.sub_zero] at h0
  rw [hi1] at h1
  rw [hi2] at h2
  have hm : highMiddle (state3Of q) (observedBit3 q L) = carry q (L-2) := by
    change (q 2 + innerBit (observedBit3 q L)) / 10 = _
    rw [hbit]
    exact h2.symm
  have hf : highFirst (state3Of q) (observedBit3 q L) = carry q (L-1) := by
    change (q 1 + highMiddle (state3Of q) (observedBit3 q L)) / 10 = _
    rw [hm]
    exact h1.symm
  refine ⟨?_,?_,?_,hm,hf,?_⟩
  · simp [low1,state3Of,carry]
  · simp [low2,low1,state3Of,carry]
  · simp [low3,low2,low1,state3Of,carry]
  · change (q 0 + highFirst (state3Of q) (observedBit3 q L)) / 10 = _
    rw [hf]
    exact h0.symm

/-- The next triple is exactly the repository's current normalization. -/
theorem prefix_step3_exact (q : Nat → Nat) (L : Nat)
    (hq : Admissible L q) (hL : 3 ≤ L) :
    state3Of (nextColumns q L) = next3 (state3Of q) (observedBit3 q L) := by
  rcases prefix_carries3_exact q L hq hL with ⟨ha,hb,hc,hu,hv,hh⟩
  have hbit := observedBit3_value q L hq.2.2.1
  have h0 : carry q 0 = 0 := rfl
  have hc2 : carry q (1+1) = carry q 2 := rfl
  have hc3 : carry q (2+1) = carry q 3 := rfl
  have hq1 : q (2-1) = q 1 := rfl
  have hfirst : carry q 1 = q 0 / 10 := by simp [carry]
  have hfirst_bound : 10*carry q 1 ≤ q 0 := by rw [hfirst]; omega
  unfold next3
  rw [ha,hb,hc,hu,hv,hh,hbit]
  simp only [state3Of]
  by_cases ho : carry q L = 0
  · rw [if_pos ho]
    have he0 := next_column_no_overflow q L 0 hq.1 hq.2.2.2.1 ho
    have he1 := next_column_no_overflow q L 1 (by omega) hq.2.2.2.1 ho
    have he2 := next_column_no_overflow q L 2 (by omega) hq.2.2.2.1 ho
    have hi1 : L-1-1=L-2 := by omega
    have hi2 : L-1-2=L-3 := by omega
    simp only [Nat.zero_add,Nat.sub_zero,h0,ho,hi1,hi2,hc2,hc3] at he0 he1 he2
    apply Prod.ext
    · dsimp only; omega
    · apply Prod.ext <;> dsimp only <;> omega
  · rw [if_neg ho]
    have hb' := carry_bounded q L hq.2.2.1 L (Nat.le_refl L)
    have hc' : carry q L = 1 := by omega
    have he0 := next_column_overflow_outer q L hq.1 hc'
    have he1 := next_column_overflow_interior q L 1 (by decide) (by omega) hq.2.2.2.1 hc'
    have he2 := next_column_overflow_interior q L 2 (by decide) (by omega) hq.2.2.2.1 hc'
    have hi1 : L-1+1=L := by omega
    have hi2 : L-2+1=L-1 := by omega
    simp only [Nat.zero_add,Nat.sub_zero,Nat.sub_self,h0,hc',hi1,hi2,hc2,hc3,hq1] at he0 he1 he2
    apply Prod.ext
    · dsimp only; omega
    · apply Prod.ext <;> dsimp only <;> omega


#print axioms prefix_carries3_exact
#print axioms prefix_step3_exact
end Agent10ThreeColumnArithmeticCheck
