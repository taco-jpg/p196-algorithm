#!/usr/bin/env python3
"""Validate retained canonical output; never edit proof sources or checker output."""
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path('/workspace/scratch/4b20b8469eb3/p196-algorithm')
BASE = Path('/workspace/scratch/4b20b8469eb3/agent10-eight/canonical-build-002')
RECEIPT = BASE.with_name(BASE.name + '-specialist-validation-corrected.json')
COMMIT = '9f5a2c1e19057b02193e95bdfc50421e89f53094'
PROJECT = 'agent10-carry-observability'
CHECKER = 'proofs/verify_project__214bf7673efe116b.py'
REGISTRY = 'proofs/Agent10CarryObservability.registry.json'
ALLOWED = {'Classical.choice', 'Quot.sound', 'propext'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git_bytes(path):
    return subprocess.check_output(['git', 'show', COMMIT + ':' + path], cwd=ROOT)


def axs(text):
    return sorted(x.strip() for x in text.strip()[1:-1].split(',') if x.strip())


report_bytes = (BASE / 'verification.json').read_bytes()
report = json.loads(report_bytes)
pr = report['projects'][PROJECT]
assert report['status'] == pr['status'] == 'PASS'
assert report['source_commit'] == COMMIT and report['source_tree_clean']
assert report['agent'] == 'Agent #1'
assert report['mathematical_proof_check'] is True
assert report['repository_wide_pass'] is False
assert report['catalogue_complete'] is False

registry_bytes = (ROOT / REGISTRY).read_bytes()
assert registry_bytes == git_bytes(REGISTRY)
assert sha(registry_bytes) == report['registry_sha256']
registry = json.loads(registry_bytes)
spec = registry['projects'][PROJECT]
checker_bytes = (ROOT / CHECKER).read_bytes()
assert checker_bytes == git_bytes(CHECKER)

manifest_bytes = (BASE / 'FILES.json').read_bytes()
manifest = json.loads(manifest_bytes)
actual_files = {str(p.relative_to(BASE)) for p in BASE.rglob('*')
                if p.is_file() and p.suffix != '.olean' and p.name != 'FILES.json'}
assert actual_files == set(manifest)
for rel, item in manifest.items():
    data = (BASE / rel).read_bytes()
    assert len(data) == item['bytes'] and sha(data) == item['sha256'], rel
assert len(manifest) == 25

sources = {}
for name, pin in spec['modules'].items():
    current = (ROOT / pin['path']).read_bytes()
    staged = (BASE / PROJECT / 'source' / (name + '.lean')).read_bytes()
    assert current == staged == git_bytes(pin['path']), name
    assert sha(current) == pin['sha256'] == pr['sources'][name]['sha256']
    assert sha(staged) == pr['sources'][name]['build_sha256']
    blob = hashlib.sha1(f'blob {len(current)}\0'.encode() + current).hexdigest()
    assert blob == pin['git_blob'], name
    assert not pin.get('adapter') and not pr['sources'][name].get('adapter')
    sources[name] = dict(path=pin['path'], sha256=sha(current), git_blob=blob,
                         bytes=len(current), commit_worktree_build_identical=True)
assert len(sources) == 11
assert [c['label'] for c in pr['commands']] == pr['build_order'] + ['ProjectAudit']
assert len(pr['commands']) == 12
for command in pr['commands']:
    assert command['exit_code'] == 0
    assert sha((BASE / command['log']).read_bytes()) == command['log_sha256']

audit_path = BASE / PROJECT / 'logs' / 'ProjectAudit.log'
audit_bytes = audit_path.read_bytes()
audit = audit_bytes.decode()
records = re.findall(r'^AUDIT_THEOREM (\S+) (\S+) :\s*(\[[^\]]*\])', audit, re.M)
headers = re.findall(r'^AUDIT_THEOREM (\S+) (\S+) :', audit, re.M)
summary = re.findall(r'^FULL_MODULE_AUDIT theorems=(\d+) union=(\[[^\]]*\])$', audit, re.M)
assert len(summary) == 1
assert len(records) == len(headers) == int(summary[0][0]) == pr['theorem_count']
assert len({name for _, name, _ in records}) == len(records)
assert {(mod, name) for mod, name, _ in records} == set(headers)
by_name = {name: {'origin_module': mod, 'axioms': axs(used)} for mod, name, used in records}
counts = dict(sorted(Counter(mod for mod, _, _ in records).items()))
assert set(counts) == set(sources)
union = set()
for mod, name, used in records:
    deps = set(axs(used))
    assert deps <= ALLOWED, name
    union.update(deps)
assert union == set(axs(summary[0][1])) == set(axs(pr['axiom_union'])) == ALLOWED
assert not re.search(r'^(CUSTOM_AXIOM|DISALLOWED_AXIOMS)', audit, re.M)
unsafe = re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$', audit, re.M)
assert len(unsafe) == 13 and len(set(unsafe)) == len(unsafe)
assert all(mod == 'Lychrel196Research' for mod, _ in unsafe)
assert [list(x) for x in unsafe] == pr['unsafe_implementation_axioms']
assert not {name for _, name in unsafe}.intersection(union)

endpoints = [e for claim in registry['claims'] if claim['project'] == PROJECT
             for e in claim.get('endpoints', [])]
assert len(endpoints) == len(set(endpoints)) == 49
assert endpoints == pr['endpoints']
audit_source = (BASE / PROJECT / 'source' / 'ProjectAudit.lean').read_text()
assert re.findall(r'^#check (\S+)$', audit_source, re.M) == endpoints
audit_start = re.search(r'^(?:AUDIT_THEOREM|UNSAFE_IMPLEMENTATION_AXIOM) ', audit, re.M).start()
positions = []
for endpoint in endpoints:
    found = list(re.finditer(r'^' + re.escape(endpoint) + r'(?=\s|:)', audit, re.M))
    assert len(found) == 1 and found[0].start() < audit_start, endpoint
    positions.append(found[0].start())
assert positions == sorted(positions)
endpoint_records = []
for index, endpoint in enumerate(endpoints):
    end = positions[index + 1] if index + 1 < len(positions) else audit_start
    formatted_type = audit[positions[index]:end].strip()
    item = by_name[endpoint]
    assert item['origin_module'] == endpoint.split('.')[0]
    module_log = (BASE / PROJECT / 'logs' / (item['origin_module'] + '.log')).read_text()
    pattern = r"^'" + re.escape(endpoint) + r"' (?:depends on axioms:\s*(\[[^\]]*\])|does not depend on any axioms)"
    printed = re.findall(pattern, module_log, re.M)
    assert len(printed) == 1, endpoint
    assert axs(printed[0] or '[]') == item['axioms'], endpoint
    endpoint_records.append(dict(name=endpoint, **item, type_output=formatted_type,
        type_output_sha256=sha(formatted_type.encode()),
        type_log_line_1_based=audit.count('\n', 0, positions[index]) + 1,
        print_axioms_matches_exhaustive_audit=True))

types = {e['name']: e['type_output'] for e in endpoint_records}
count_type = types['Agent10SevenStepCount.actual_seven_step_count_all_widths']
assert '(ha : FoldedDecimal.Admissible L q)' in count_type
assert '3 ≤ CarryObservabilityActual.orbitCount q L 7' in count_type
assert '(hL :' not in count_type
for suffix in ['small_difference', 'initial_nonoverflow']:
    text = types['Agent10EightCarry.eight_carry_words_determine_pair_sums_of_' + suffix]
    assert 't < 8' in text and 'i ≤ (OverflowCarryNormalization.iterPairs q L t).fst' in text
    assert 'orbitCount' not in text and '(i : Nat) : i < L → q i = r i' in text
numeric = types['Agent10EightCarry.eight_carry_words_determine_next_integer_of_initial_nonoverflow']
assert 'DecimalDigits.Canonical n d L' in numeric and 'DecimalDigits.Canonical m e L' in numeric
assert '(ho : DecimalDigits.carry (DecimalDigits.columnSum d L) L = 0)' in numeric
assert numeric.endswith('Lychrel196.step n = Lychrel196.step m')
for name in ['rank_seven_minimum_fin', 'singleton_seven_count']:
    assert by_name['Agent10SevenStepCount.' + name]['axioms'] == []

exterior = ' '.join(types['Agent10PrefixExclusion.eight_carries_determine_exterior_pair'].split())
assert 't < 8' in exterior and exterior.endswith(': q 0 = r 0')
assert 'orbitCount' not in exterior and '(ho :' not in exterior
counterexample = ' '.join(types['Agent10SixCarryCounterexample.six_carry_counterexample'].split())
assert 'Canonical 80000571539' in counterexample and 'Canonical 70000817069' in counterexample
assert 't < 6' in counterexample and 'i ≤' in counterexample
assert 'Lychrel196.step 80000571539 ≠ Lychrel196.step 70000817069' in counterexample
six_next = types['Agent10SixCarryCounterexample.next_integer_values']
assert '173518071547' in six_next and '166072617076' in six_next
for short in ['left_canonical', 'right_canonical', 'initial_pair_sums_differ', 'next_integer_values', 'next_integers_differ']:
    assert by_name['Agent10SixCarryCounterexample.' + short]['axioms'] == []

assert (BASE / 'verification.json').read_bytes() == report_bytes
assert (BASE / 'FILES.json').read_bytes() == manifest_bytes
receipt = {
    'status': 'PASS',
    'canonical_build_executor': 'Agent #10 parent /root',
    'validation_executor': 'Agent #10 specialist /root/formalization_scout',
    'initial_validation_receipt_path': '/workspace/scratch/4b20b8469eb3/agent10-eight/canonical-build-002-specialist-validation.json',
    'initial_validation_receipt_sha256': 'c5a5e2cb842b39610e0a48c0619e50acc6a7cf2d2fc54b2ee932d99822a40866',
    'initial_validation_script_path': '/workspace/scratch/4b20b8469eb3/agent10-count/validate_canonical_gate_002.py',
    'initial_validation_script_sha256': 'ba41e73f7def5aa6d9dd32e365af03d1d02a63493cee7ff022fe57f8f1694460',
    'attribution_revision_note': 'The parent launched canonical build-002; the specialist authored and executed this retained-output validation. Initial receipt and script remain unchanged.',
    'checker_inherited_agent_field': report['agent'],
    'checker_output_modified': False,
    'independent_external_acceptance': False,
    'source_commit': COMMIT,
    'project': PROJECT,
    'canonical_build_directory': str(BASE),
    'source_registry_sha256': sha(registry_bytes),
    'canonical_checker_path': CHECKER,
    'canonical_checker_sha256': sha(checker_bytes),
    'verification_report_sha256': sha(report_bytes),
    'files_manifest_sha256': sha(manifest_bytes),
    'audit_log_sha256': sha(audit_bytes),
    'manifest_entries_validated': len(manifest),
    'fresh_module_builds_passed': 11,
    'exhaustive_audit_passed': True,
    'successful_lean_commands': 12,
    'theorem_count': len(records),
    'theorem_count_includes_generated_theorems': True,
    'theorem_counts_by_origin_module': counts,
    'theorem_axiom_union': sorted(union),
    'unsafe_generated_implementation_declarations': [dict(origin_module=m, name=n) for m, n in unsafe],
    'unsafe_generated_declarations_occurring_in_theorem_axiom_union': [],
    'endpoint_count': len(endpoint_records),
    'all_endpoint_types_and_print_axioms_present': True,
    'endpoint_records': endpoint_records,
    'sources': sources,
    'semantic_checks': [
        'All-width count has only initial admissibility, including width one.',
        'Both combined pair-sum endpoints require all eight complete carry words and no count premise.',
        'The numeric endpoint uses a shared canonical width and initial nonoverflow; its conclusion is equality of the next ordinary step.',
        'The symmetric smoothing counterexample is abstract; it does not assert an actual eight-carry collision.',
        'The exterior pair is recovered universally by eight words, with no initial nonoverflow or count premise.',
        'The explicit width-eleven inputs collide for six complete words and have unequal next integers; the seventh observation separates them.',
    ],
    'validation_script_sha256': sha(Path(__file__).read_bytes()),
    'original_validation_script_preserved_sha256': '36c71472841f341ba4d4be392c11636920a1fb7809c14ffdb06adb8afa48ced8',
    'validated_at_utc': datetime.now(timezone.utc).isoformat(),
}
with RECEIPT.open('x') as stream:
    stream.write(json.dumps(receipt, indent=2, ensure_ascii=False) + '\n')
print(json.dumps({
    'status': receipt['status'], 'receipt': str(RECEIPT),
    'receipt_sha256': sha(RECEIPT.read_bytes()), 'theorem_count': len(records),
    'theorem_counts_by_origin_module': counts, 'axiom_union': sorted(union),
    'endpoints': len(endpoint_records), 'manifest_entries': len(manifest),
    'checker_sha256': sha(checker_bytes),
}, indent=2))
