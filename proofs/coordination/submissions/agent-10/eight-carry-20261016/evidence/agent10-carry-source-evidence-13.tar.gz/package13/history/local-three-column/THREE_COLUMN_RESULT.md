# Agent 10: eight complete carry words recover the first two active pair coefficients

## Checked result and exact scope

The final sources are `Agent10ThreeColumnExclusion.lean` and
`Agent10ThreeColumnCarry.lean`. Both compiled successfully with Lean 4.19.0
against the already checked dependencies in `agent10-eight/development`.
This is a local check of the two new modules; the integration writer's fresh
canonical closure check is a separate verification step.

For admissible pair words `q` and `r` with the same initial width `L`, assume
that their complete carry words agree at observations `t = 0, ..., 7`:

```lean
∀ t, t < 8 → ∀ i, i ≤ (iterPairs q L t).1 →
  carry (iterPairs q L t).2 i = carry (iterPairs r L t).2 i
```

The terminal carry is included. Equal evolving widths follow from the existing
`matched_widths` lemma. No initial nonoverflow assumption is used.

The new endpoint `eight_carries_determine_second_pair` concludes `q 1 = r 1`
when `2 ≤ L`. Together with the already checked exterior-coordinate theorem,
`eight_carries_determine_first_two_active_pairs` gives

```lean
∀ i, i < 2 → i < L → q i = r i
```

The active-coordinate restriction is necessary: at width one, the function
values at index one are outside the word and are not determined by the
observations. This result does not assert equality of the entire pair vector
at arbitrary width. It also does not assert equality of the original ordinary
integers.

Final frozen source SHA-256 values:

| Source | SHA-256 |
|---|---|
| `Agent10ThreeColumnExclusion.lean` | `965c4cb1dd1e32f6778fe144eb775814167d4379a9179e402f711cbc9bafce18` |
| `Agent10ThreeColumnCarry.lean` | `e884ec38e1561a27aa862ef857e7c65db99c0ed3c73fccefc2bec803cc51701d` |

## Finite relation and why it is sufficient

The three-coordinate state is `(p,a,b)`, with `1 ≤ p ≤ 18` and
`0 ≤ a,b ≤ 18`. Its low carries are

`c1 = p/10`, `c2 = (a+c1)/10`, and `c3 = (b+c2)/10`.

A shared Boolean control represents the actual carry entering the reflected
three-coordinate prefix, at position `L-3`. From that bit `v`, the high carries
are `u = (b+v)/10`, `h = (a+u)/10`, and `o = (p+h)/10`.
Two states are compatible when their low carries `c1,c2,c3`, high carry `h`
at `L-1`, and terminal carry `o` agree, using the same `v`.

The state update `next3` is proved to equal `state3Of (nextColumns q L)` for
every admissible actual word with `3 ≤ L`. The proof includes widths three
and four; it makes no assumption that the low and reflected prefixes are
disjoint. For these small widths, the abstract graph permits additional bit
paths, so it still contains every actual path.

The finite exclusion covers precisely all

```text
((p+1,a+1,b),(p+1,a,b+3)),
p in 0..17, a in 0..17, b in 0..15.
```

There are `18 * 18 * 16 = 5,184` starts. Each of the eighteen fixed-outer
families is checked by `decide +kernel`; the aggregate theorem combines
those exhaustive cases. Every start has no compatible path through eight
observations. The reversed difference is excluded by swapping the actual
words and transporting the complete-word hypothesis through `matched_widths`.

The implementation encodes `(p,a,b)` as `361*p + 19*a + b` and decodes by
quotient and remainder. `decode_encode3` is proved for every valid state.
The actual-trajectory induction establishes validity at every step, so this
encoding cannot drop an actual path. The finite computation is conducted on
the encoded recurrence, and the exact bridge—not an assumption of graph
closure—connects it to the actual normalizer.

The extra observed high carry is essential for this particular exclusion.
The exact Python comparison in `three_prefix_scan.py` gives:

| Observations retained in addition to low carries 1, 2, 3 | Starts surviving 1 through 8 observations |
|---|---|
| Terminal carry only | 3972, 2454, 1397, 820, 438, 181, 51, 13 |
| Terminal carry and carry at `L-1` (the Lean relation) | 3870, 2355, 1345, 774, 413, 160, 42, 0 |
| All three reflected outgoing carries | 3870, 2346, 1246, 692, 334, 134, 37, 0 |

The checked `seven_three_prefix_survival` supplies a seven-observation
abstract survivor `(16,6,0)/(16,5,3)`. This establishes that eight is the
first exclusion horizon for this finite relation. It is not a certificate
that this abstract path is realizable by complete actual words, and it is
not a global sharp-memory result.

## Composition with the smoothing argument

The existing exterior-coordinate theorem first gives `q 0 = r 0`. The
existing seven-transition count theorem gives at least three nonoverflow
steps. If there are at least four, the existing endpoint injectivity theorem
already gives all active coefficient equalities.

The remaining case has exactly three nonoverflow steps and four smoothing
steps. The matched-difference formula and the last observed carry word give
`|smoothPow 4 f| ≤ 1`, while the first observed word gives `|f| ≤ 9`, for
`f = cappedDiff q r L`. The zero exterior difference allows `smoothPow_tail`
to transfer the smoothing estimate to the shifted series `g(i)=f(1+i)`.
The checked first-coefficients lemma says that a nonzero `g(0)` would force
`(g(0),g(1))=(1,-3)` or `(-1,3)`.

For `L ≥ 3`, those are exactly the excluded initial three-coordinate
differences `(0,1,-3)` and `(0,-1,3)`. For `L=2`, the capped coefficient
`f(2)=0` directly contradicts either forced prefix. Thus the second active
coefficient agrees in every case.

## Attribution and foundation boundary

The arithmetic projection is not presented as a new discovery. Existing
projections include `P196.Agent4.WholeWord.nextColumns_prefix3` in
`WholeWordBridge__77dd94b84e64292d.lean` and
`Agent113.TwoDigit.nextTriple/high_carries` in
`TwoDigitProjection__4b87a2ef9877a4bc.lean`.

The new sources derive the precise interface needed here directly from the
unchanged standalone core already used by `Agent10PrefixExclusion`, avoiding
a second foundation definition from the alternate adapter closure. The new
contribution is the finite synchronized exclusion and its composition with
the established smoothing and count lemmas.

## Verification and preserved attempts

Each `exclusion_p0` through `exclusion_p17`, and
`seven_three_prefix_survival`, has no axioms. The aggregate finite exclusion,
arithmetic bridge, actual-history transport, and positive/negative shifted
prefix exclusions use only `propext` and `Quot.sound`. The reconstruction
endpoints use only `propext`, `Classical.choice`, and `Quot.sound`.
There are no occurrences of `sorry`, `admit`, `native_decide`, custom axiom
declarations, or `unsafe` in the final two proof sources.

The successful compiler logs are `Agent10ThreeColumnExclusion.build.log` and
`Agent10ThreeColumnCarry.build.log`. The sources were compiled sequentially
with the command shape below, from this directory:

```bash
LEAN_PATH=/workspace/scratch/4b20b8469eb3/agent10-semantic:/workspace/scratch/4b20b8469eb3/agent10-eight/development /tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean -o Agent10ThreeColumnExclusion.olean Agent10ThreeColumnExclusion.lean
LEAN_PATH=/workspace/scratch/4b20b8469eb3/agent10-semantic:/workspace/scratch/4b20b8469eb3/agent10-eight/development /tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean -o Agent10ThreeColumnCarry.olean Agent10ThreeColumnCarry.lean
```

Two raw triple-recursion attempts exited 137; their exact preserved or
explicitly reconstructed sources and classifications remain in `attempts`.
They are failed build attempts and support no verified conclusion. The
encoded eighteen-family source subsequently completed successfully in one
module; its total elapsed time and peak memory were not measured here.

An independent isolated fixed-outer encoded probe checked 288 starts in
2.814 seconds with a peak of 700,504 KiB. Its record is
`agent10-bridge/runtime-threecolumn/encoded-outer01-001/measurement.json`.
That measurement is an isolated runtime probe, not a full closure replay.
The runtime specialist's earlier two-family probe was stopped by its shared
memory guard, rather than failing a Lean proof check.

The prior successful Carry revision with SHA-256
`d515d9a27d8b84e1a5397c30512f69a52155200c2353529362dced614dae13d3`
and its log are preserved as
`attempts/three_column_carry_prior_success_d515d9a.{lean,log}`. The final
revision adds only the active-coordinate corollary and its axiom report.

## Earlier finite searches remain separately scoped

The width-eleven coefficient-six witness scan enumerated all 4,504,864
admissible ordered candidates and found no pair matching seven or eight
complete observations. Its negative sign is covered by swapping the words.
The now-checked all-width two-column prefix exclusion is stronger for that
unshifted witness.

The width-thirteen once-padded witness scan started from 85,857,408
admissible candidates. Its formally justified eight-survival prefix filter
retained 7,949,760 completions, all of which were checked exactly; none
shared eight words. Its zero count after seven observations is conditional
on that eight-survival filter and must not be stated as an unrestricted
seven-observation exclusion.

The independent ordinary-integer replay of `80000571539` and `70000817069`
matches six complete observations and first differs at the seventh. It is
a concrete lower-bound example. Its separate Lean certificate is owned by
the integration team's other specialist, not by these two new modules.
