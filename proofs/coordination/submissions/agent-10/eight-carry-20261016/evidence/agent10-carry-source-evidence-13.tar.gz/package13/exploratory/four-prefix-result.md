# Exact four-coordinate carry-prefix search

## Result and scope

All **98,496** valid oriented initial prefixes with difference `(0,0,1,-3)` were enumerated. **120** starts survive eight observations in the necessary prefix graph, along **2,744** shared-inner-bit paths. This is finite computational evidence. It is not a Lean certificate, an actual whole-word eight-carry collision, or a result about the orbit of 196.

The initial states are `left=(p,a,b+1,c-3)` and `right=(p,a,b,c)`, with `1≤p≤18`, `0≤a≤18`, `0≤b≤17`, and `3≤c≤18`. At every observed time, both sides receive the same Boolean carry at `L-4`. The scan requires equality of all low carries at indices `1,2,3,4` and all reflected high carries at `L,L-1,L-2,L-3`, including the terminal carry. Each width is the current width; terminal overflow determines the next prefix update.

| Number of observations | Surviving initial prefixes | Compatible shared-bit paths |
|---:|---:|---:|
| 1 | 73,530 | 141,246 |
| 2 | 43,919 | 143,311 |
| 3 | 23,096 | 129,588 |
| 4 | 13,059 | 98,993 |
| 5 | 6,001 | 100,588 |
| 6 | 2,621 | 83,365 |
| 7 | 739 | 27,871 |
| 8 | 120 | 2,744 |

The supplied inner bits are allowed to vary freely in time. An actual whole word must realize them through one coherent evolving inner region. Center constraints, possible overlap of low and reflected coordinates at small widths, and the omitted inner region are deliberately not imposed by this necessary graph. The four-coordinate inclusion has not been proved in Lean.

## A complete surviving path

The first retained start is `(13,6,4,5)/(13,6,3,8)`. Low carries below are ordered `1,2,3,4`; high carries are ordered `L,L-1,L-2,L-3`. Both sides have the listed carry vectors. Observation times are `0` through `7`.

| Time | Left prefix | Right prefix | Shared `L-4` bit | Common low carries | Common high carries |
|---:|---|---|---:|---|---|
| 0 | (13,6,4,5) | (13,6,3,8) | 0 | (1,0,0,0) | (1,0,0,0) |
| 1 | (4,10,10,9) | (4,10,9,11) | 1 | (0,1,1,1) | (0,1,1,1) |
| 2 | (9,1,2,0) | (9,1,0,4) | 0 | (0,0,0,0) | (0,0,0,0) |
| 3 | (18,2,4,0) | (18,2,0,8) | 0 | (1,0,0,0) | (1,0,0,0) |
| 4 | (9,11,6,4) | (9,11,2,8) | 0 | (0,1,0,0) | (1,1,0,0) |
| 5 | (10,1,8,10) | (10,1,4,10) | 0 | (1,0,0,1) | (1,0,0,1) |
| 6 | (1,2,9,9) | (1,2,5,5) | 0 | (0,0,0,0) | (0,0,0,0) |
| 7 | (2,4,18,18) | (2,4,10,10) | 0 | (0,0,1,1) | (0,0,1,1) |

The inner-bit string is `01000000`; the terminal-overflow string is `10011100`. Four further retained initial pairs are `(13,6,4,14)/(13,6,3,17)`, `(13,6,13,5)/(13,6,12,8)`, `(13,6,13,14)/(13,6,12,17)`, and `(13,15,4,5)/(13,15,3,8)`. They share the displayed continuation from time 1. All five complete paths, including next-state arrays, are present in `four-prefix-check-002/result-4.json`.

## Practical width-15 lift filter

For the twice-padded symmetric difference

`[0,0,1,-3,5,-6,6,-6,6,-6,5,-3,1,0,0]`,

take each surviving first-four-coordinate pair and enumerate the remaining independent right-hand coefficients as follows:

| Coordinate | Right coefficient choices | Left coefficient |
|---:|---|---|
| 4 | 0 through 13 | right + 5 |
| 5 | 6 through 18 | right - 6 |
| 6 | 0 through 12 | right + 6 |
| 7, the center | 6, 8, 10, 12, 14, 16, 18 | right - 6 |

Reflection supplies coordinates 8 through 14. Every center is even and every coefficient lies in `0..18`; the outer coefficient is positive. This gives `14×13×13×7 = 16,562` extensions per surviving prefix, hence **1,987,440** filtered candidates. Without the prefix filter, there are `98,496×16,562 = 1,631,290,752` candidates in this particular difference family.

The 120 surviving prefixes have outer values distributed as 13: 8 starts, 14: 8 starts, 17: 26 starts, and 18: 78 starts. The CSV retains only the first compatible bit string per prefix; a full-word lift search must allow every actual bit sequence and must not restrict itself to that sample string. The semantic specialist received this exact filter for a separate full-word scan. No lift result is asserted here.

## Reproduction and retained evidence

The C++ program uses exhaustive depth-8 DFS, fixed-size states, no memoization, integer arithmetic, and at most five retained example paths. Every accepted update is checked both as a sum of output digits and against the original standalone foundation's `next_column_no_overflow`, `next_column_overflow_outer`, and `next_column_overflow_interior` recurrences. The three-coordinate control reproduces the previously inspected exact counts `[3870,2346,1246,692,334,134,37,0]`. The five recorded four-coordinate paths were independently replayed with the prior Python simulator.

The successful four-coordinate process used 0.064315 CPU seconds and a measured peak resident size of 11,008 KiB in this environment. These are local run measurements, not performance guarantees. The first runner failed before compilation because `/usr/bin/time` is absent; its source and failure record remain in `four-prefix-check-001`. The successful additive runner uses `os.wait4` for per-process resource accounting.

All successful evidence is under `/workspace/scratch/4b20b8469eb3/agent10-count/four-prefix-check-002`:

| Artifact | SHA-256 |
|---|---|
| `four_prefix_scan.cpp` | `e40ca15a6b24360ad78cd3b238aa0c63346fd4330ed271f38e735481839acc6e` |
| `survivors-4.csv` | `4a2cf86b60799f25a45d0101c9db9dce39cae68c4467b3fdd9d6cf3da376f4a1` |
| `result-4.json` | `fca3dade6aa159ff214edfd01e3339b915e26a3f6f77a646fa031fc294efa4d5` |
| `verification.json` | `b53297cb1bbb8fbec5a4fa53a4a16190a8c914bea34fcb0b39d896f9bd199a8d` |

The receipt additionally pins the runner, compiler version, binary, commands, logs, resource measurements, prior control source and data, and the original standalone Lean foundation. The foundation SHA-256 is `f8950d138fa4231b536059e2334d36b6496de3d25a806f4cf3925941aa05144c`; its Git blob is `c6c1f5441c54a36f2d82b3ef78dff1ccdbc5a506`.
