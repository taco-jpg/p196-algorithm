# Agent 10: frozen thirteen-module source and evidence archive

This packet preserves the exact source and retained evidence for the
thirteen-module `agent10-two-pair-reconstruction` checkpoint. It includes a
small self-contained source snapshot, its additive patch, all three canonical
build records, internal non-author reviews, retained attempts, and separately
classified exploratory computations. No new Lean build was run to assemble it.

## Exact provenance

| Role | Commit |
|---|---|
| Original source baseline | `4b4edf976b2c7a9ba1dad80636c0e21c66350325` |
| Tested thirteen-module proof checkpoint | `b170358092047167fef8a5cee165366dbc1e8fd7` |
| Frozen local delivery checkpoint | `78ffdbbf66b3aa1be86e614b4ffc2ea0a8d29264` |

`snapshot/` contains all 25 added paths listed in
`delivery/patch-source.json`, taken directly from the delivery commit. It also
contains the four exact unchanged dependency files, the unchanged original
verifier, and the unchanged repository `AGENTS.md`: 31 files in total. Every
module byte was compared with the tested proof commit and its recorded pin.
The verifier and four dependencies also match the original baseline exactly.

The source patch is `delivery/source-expanded.patch`, SHA-256
`ae0fda1917bd16bb70435f6e929e0c7944ca94412f6b4bff5b47b0653477475f`.
The successful `delivery/patch-application.json` records isolated Git-index
checks against the original baseline and fetched-main commit
`58afcada8047e015b8f4233b96c44c7c5b9c4162`. It verifies exact added-file bytes,
module pins, and preservation of the verifier and repository rules. These
patch checks are transport evidence; the canonical Lean gates supply the
mathematical checking evidence.

`PROVENANCE.json` records the source of every selected file, its category,
byte count, and SHA-256. `FILES.json` hashes every regular package file except
itself. The enclosing archive verification receipt separately hashes
`FILES.json` and the complete archive, avoiding a self-referential manifest.

## Kernel-checked scope

The final project has thirteen modules:

```text
Lychrel196Research
PrefixCarryBound
ActualCarryObservability
DifferenceObservability
Agent10SmoothingBoundary
Agent10SmoothingBridge
Agent10SevenStepCount
Agent10EightCarry
Agent10PrefixWitness
Agent10PrefixExclusion
Agent10SixCarryCounterexample
Agent10ThreeColumnExclusion
Agent10ThreeColumnCarry
```

The exact declarations and endpoint lists are in the source snapshot and
registries. The checkpoint includes the seven-transition nonoverflow-count
bound; eight-word reconstruction under the stated small-difference or initial
nonoverflow premises; universal recovery of the first two active pair
coordinates; actual-history exclusions of the relevant exterior and shifted
prefixes; and an explicit six-word lower-bound example.

The universal two-coordinate endpoint asserts only
`∀ i, i < 2 → i < L → q i = r i`. The standalone second-coordinate theorem
requires `2 ≤ L`. Complete carry words include the terminal carry and use the
current evolving width. The reconstruction results do not assert equality
of the original input integers. The lower-bound examples use unrestricted
iteration, with no assumption that the intermediate integers avoid
palindromes. No result here resolves the 196 problem.

Later Seven and Eight counterexample modules, their reviews, later sharpness
composition, and width-seventeen work are outside this frozen kernel scope
and are not included. The width-fifteen numerical example remains included
only as part of its explicitly labeled exploratory computation record.

## Canonical builds and independent retained-output validation

| Retained gate | Project | Modules | Successful Lean commands, including audit | Audited theorem declarations | Public endpoint types |
|---|---|---:|---:|---:|---:|
| `canonical/canonical-build-001` | `agent10-eight-carry` | 8 | 9 | 1,041 | 26 |
| `canonical/canonical-build-002` | `agent10-carry-observability` | 11 | 12 | 1,122 | 49 |
| `canonical/canonical-build-003` | `agent10-two-pair-reconstruction` | 13 | 14 | 1,244 | 83 |

Each directory retains its exact generated source aliases, individual module
logs, `ProjectAudit.lean`, audit log, `verification.json`, and original
`FILES.json`. The counts include generated theorem declarations. The audited
theorem axiom union is `{propext, Classical.choice, Quot.sound}`. Original
records distinguish generated unsafe implementation declarations in the
unchanged foundation from theorem axiom dependencies; their classification
has not been altered here.

The unchanged verifier retains its inherited `Agent #1` output label.
Actual executor attribution is in the validation receipts. In particular,
build 002 was launched by the Agent 10 parent; the specialist authored and
executed the retained-output validation. The original build-002 validation
receipt and original validator are preserved unchanged alongside the
corrected attribution receipt and additive attribution validator. The
correction changes attribution, not the canonical checker output or proof
source. Build 003 likewise distinguishes the parent build executor from the
specialist validator.

`reviews/five-module` and `reviews/three-column` preserve the internal
non-author reviews, source pins, finite controls, and audit comparisons.
These are independent internal specialist checks, not external acceptance.

## Preserved failures, revisions, and limited checks

The file categories in `PROVENANCE.json` prevent earlier attempts from being
confused with final canonical certificates.

- `delivery/failed-disposable-checkouts.json` records generated checkout
  failures with exit 128 from exhausted disk space. It explicitly states
  that the checkout-based patch checks did not complete and that unique
  sources were not removed. The later isolated-index checks succeeded;
  both records are retained.
- `attempts/count-and-six/build-001` is the preliminary Count compile using
  an adapter closure. Its record says that no axiom audit was performed.
  `standalone-check-001` is a compatibility check using already compiled
  dependencies. Neither is relabeled as a clean canonical closure build.
- `six-check-001` and `six-check-002` retain their failed Lean sources and
  logs. `six-check-003` retains the successful revised source and audit.
- `attempts/three-column` retains the raw recursion attempts that exited
  137, their classifications, the earlier unsuccessful source revision,
  and the prior successful Carry revision `d515d9a…`. The unpartitioned
  source reconstruction is explicitly marked as reconstructed in its
  original receipt. Final successful source pins are separate.
- `runtime/three-column` preserves each probe's own status. A shared-memory
  guard stopped the two-family probe; that was not a Lean proof error.
  The isolated encoded outer family passed, and the complete encoded
  eighteen-family module subsequently passed. Runtime probes are not full
  closure replays.
- `inherited/` retains the original inherited bridge archive unchanged,
  replay source, and the original/repaired axiom-record-format provenance.
  The nested archive contains source and evidence, with no compiled Lean
  objects or toolchain binaries.

Existing evidence manifests may refer to `.olean` hashes that were recorded
when the checks ran. Those generated objects are deliberately absent from
this source archive. Their absence does not alter the original receipts.

## Exploratory computations

The original width-eleven, width-thirteen, two-prefix, and three-prefix
computations are preserved both in the delivery snapshot and under
`computations/original-width11-width13-three-prefix`.

The later `exploratory/` subtree is separate from the thirteen-module kernel
scope:

- `four-prefix-check-001` records a runner failure before compilation
  because `/usr/bin/time` was unavailable. The corrected, completed
  `four-prefix-check-002` is separately preserved.
- The completed four-prefix scan considers all 98,496 starts and retains
  120 through eight abstract observations.
- The completed five-prefix scan considers all 1,871,424 starts and retains
  1,326 through eight abstract observations.
- The width-fifteen lift checks all 1,987,440 symmetric center-even
  completions of the four-prefix filter. It records 126 seven-word matches
  and no eight-word match among those retained completions, including an
  independently replayed ordinary-integer example.

The four- and five-prefix actual-history inclusions are computationally
motivated necessary projections, not Lean inclusion theorems in this
packet. A zero result in a filtered lift has the filter scope stated in its
receipt. CSV example bit strings are metadata and do not restrict the
actual-word lift trajectories. The width-thirteen zero-after-seven count is
also conditional on its eight-survival prefix filter. Preserve these scope
conditions when reporting the results.

## Manual source replay

No compiler, `.olean`, `.ilean`, executable scan binary, or cache directory is
shipped. Use the official Lean 4.19.0 release identified by the retained
compiler pins. The scripts use Python's standard library.

### Replay from the small source snapshot

Work in a disposable copy of `snapshot/`. The unchanged verifier queries a
Git HEAD, so initialize and commit that snapshot first. This local replay
commit will have a different identifier; the original source identities
remain recorded in this packet's pins.

```bash
git init
git add .
git -c user.name='Source replay' -c user.email='source-replay@example.invalid' commit -m 'Initialize source-only replay snapshot'
python proofs/verify_project__214bf7673efe116b.py --lean /absolute/path/to/lean-4.19.0/bin/lean --output /absolute/new/replay-output --registry proofs/Agent10TwoPairReconstruction.registry.json --project agent10-two-pair-reconstruction
```

The output directory must be new. Selecting the explicit project preserves
the checker's project-scoped meaning; this is not a repository-wide census
or pass. The source snapshot contains the complete module closure required
by this selected registry.

### Replay from the baseline patch

Alternatively, in a fresh checkout of baseline
`4b4edf976b2c7a9ba1dad80636c0e21c66350325`, apply
`delivery/source-expanded.patch`, then invoke the same unchanged verifier
with the selected registry and project. The retained index-check script
shows the exact checks previously performed; it retains its original local
paths and historical commit targets rather than being silently rewritten.

## Archive verification and deterministic repacking

Run `python support/verify_package.py` from any directory to verify all file
hashes, sizes, inventory, and excluded artifact types. The archive was made
in lexicographic path order, with zero timestamps and fixed owner/mode
metadata. Its gzip header has an empty filename and zero timestamp.

`support/repack.py` regenerates those exact archive bytes from this package
without compiling or changing any source. The external archive verification
receipt records the archive SHA-256, byte count, file count, manifest hash,
and successful extraction/hash check.
