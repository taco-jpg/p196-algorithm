# Agent 10 carry-observability computations

These exact finite controls accompany the independently checked Lean sources. They are computational evidence, not substitutes for the actual-history inclusion theorems or kernel certificates. Sources and JSON outputs are retained byte-for-byte from the Agent 10 semantic specialist's work.

## Scope of each calculation

| Files | Complete finite domain | Result |
| --- | --- | --- |
| `witness_scan.cpp`, `witness_scan.json` | All 4,504,864 ordered admissible width-eleven word pairs with difference `[1,-3,5,-6,6,-6,6,-6,5,-3,1]` | 89 pairs survive six complete observations; none survive seven or eight. Swapping the pair covers the negated difference. |
| `prefix_scan.py`, `prefix_scan.json` | All 272 valid two-column starts with difference `(1,-3)`, every shared Boolean inner-carry path through the requested horizon | The weak necessary graph has survivor counts `202,119,60,35,14,5,0` after observations one through seven. The separate Lean certificate checks the exclusion and the actual-history theorem justifies its use. |
| `replay_numeric.py`, `replay_numeric.json` | The two ordinary integers `80000571539` and `70000817069`, observations zero through seven | Direct decimal reversal/addition confirms six equal complete carry words, then separation. `Agent10SixCarryCounterexample.lean` separately proves the actual numeric certificate. |
| `padded_witness_scan.cpp`, `padded_witness_scan.json` | All admissible width-thirteen pairs with the once-padded difference `[0,1,-3,5,-6,6,-6,6,-6,5,-3,1,0]`, after a complete necessary eight-observation prefix filter | No pair survives eight complete observations. The prefilter domain has 85,857,408 pairs; all 324 possible initial two-column pairs are checked. Thirty surviving weak prefixes yield 7,949,760 fully enumerated completions. |

The width-thirteen search uses the weak prefix filter whose actual-history inclusion is proved in `Agent10PrefixExclusion.actual_history_survives`. It also reports a stronger filter for comparison, but does not use that stronger filter to discard enumerated completions.

The width-thirteen survivor counts after the eight-observation filter and zero through eight additional complete-word checks are `[7949760,528456,111213,69129,15194,5592,734,0,0]`. The zero at seven is conditional on the eight-observation prefilter. It does **not** prove that no unrestricted width-thirteen pair with this difference survives seven observations. The complete conclusion of that search is the absence of an eight-observation pair in the stated width-thirteen domain.

The ordinary example's shared actual inner-bit path is `[0,0,1,1,0,0]`. A prefix BFS can display a different valid path, including an all-zero path, from the same initial outer states. An abstract path and its particular whole-word realization must not be conflated.

## Reproduce without overwriting retained results

The Python programs print JSON to standard output. The C++ programs use integer arithmetic and assertions; compile with assertions enabled.

```bash
python -B prefix_scan.py > /tmp/agent10-prefix-replay.json
python -B replay_numeric.py > /tmp/agent10-numeric-replay.json
c++ -std=c++17 -O2 witness_scan.cpp -o /tmp/agent10-witness-scan
/tmp/agent10-witness-scan > /tmp/agent10-witness-replay.json
c++ -std=c++17 -O2 padded_witness_scan.cpp -o /tmp/agent10-padded-scan
/tmp/agent10-padded-scan > /tmp/agent10-padded-replay.json
```

These controls make no claim about arbitrary widths, arbitrary coefficient differences, seven-observation optimality, or an infinite ordinary-integer trajectory. The separate source/evidence manifest records exact hashes of the programs and outputs.
