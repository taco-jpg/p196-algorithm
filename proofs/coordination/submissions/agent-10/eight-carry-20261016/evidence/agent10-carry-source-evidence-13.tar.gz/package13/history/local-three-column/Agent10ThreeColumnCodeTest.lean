import Agent10PrefixExclusion
set_option maxHeartbeats 0
set_option maxRecDepth 100000
namespace Agent10ThreeColumnCodeTest
open CarryObservability
abbrev State3 := Nat × Nat × Nat

def Valid3 (s : State3) : Prop :=
  1 ≤ s.1 ∧ s.1 ≤ 18 ∧ s.2.1 ≤ 18 ∧ s.2.2 ≤ 18

def state3Of (q : Nat → Nat) : State3 := (q 0, q 1, q 2)
def low1 (s : State3) : Nat := s.1 / 10
def low2 (s : State3) : Nat := (s.2.1 + low1 s) / 10
def low3 (s : State3) : Nat := (s.2.2 + low2 s) / 10
def highMiddle (s : State3) (v : Bool) : Nat := (s.2.2 + innerBit v) / 10
def highFirst (s : State3) (v : Bool) : Nat := (s.2.1 + highMiddle s v) / 10
def overflow3 (s : State3) (v : Bool) : Nat := (s.1 + highFirst s v) / 10

def next3 (s : State3) (v : Bool) : State3 :=
  if overflow3 s v = 0 then
    (2*s.1 + highFirst s v - 10*low1 s,
      2*s.2.1 + low1 s + highMiddle s v - 10*(low2 s + highFirst s v),
      2*s.2.2 + low2 s + innerBit v - 10*(low3 s + highMiddle s v))
  else
    (s.1 - 10*low1 s + 1,
      s.1 + s.2.1 + low1 s + highFirst s v - 10*(low2 s + overflow3 s v),
      s.2.1 + s.2.2 + low2 s + highMiddle s v - 10*(low3 s + highFirst s v))

def compatible3 (s r : State3) (v : Bool) : Bool :=
  decide (low1 s = low1 r ∧ low2 s = low2 r ∧ low3 s = low3 r ∧
    highFirst s v = highFirst r v ∧ overflow3 s v = overflow3 r v)


def encode3 (s : State3) : Nat := 361*s.1 + 19*s.2.1 + s.2.2
def decode3 (n : Nat) : State3 := (n/361,n/19%19,n%19)
def nextCode (s : Nat) (v : Bool) : Nat := encode3 (next3 (decode3 s) v)
def compatibleCode (s r : Nat) (v : Bool) : Bool := compatible3 (decode3 s) (decode3 r) v
def survivesCode : Nat → Nat → Nat → Bool
  | 0,_,_ => true
  | n+1,s,r =>
      (compatibleCode s r false && survivesCode n (nextCode s false) (nextCode r false)) ||
      (compatibleCode s r true && survivesCode n (nextCode s true) (nextCode r true))
def survives3 (n : Nat) (s r : State3) : Bool := survivesCode n (encode3 s) (encode3 r)

theorem decode_encode3 (s : State3) (hs : Valid3 s) : decode3 (encode3 s) = s := by
  rcases s with ⟨p,q,r⟩
  rcases hs with ⟨hp,hp',hq,hr⟩
  dsimp only at hp hp' hq hr
  simp only [encode3,decode3]
  apply Prod.ext
  · dsimp only; omega
  · apply Prod.ext <;> dsimp only <;> omega

theorem first_fixed_outer :
    ∀ q : Fin 18, ∀ r : Fin 16,
      survives3 8 (1,q.val+1,r.val) (1,q.val,r.val+3) = false := by decide +kernel
#print axioms first_fixed_outer

theorem last_fixed_outer :
    ∀ q : Fin 18, ∀ r : Fin 16,
      survives3 8 (18,q.val+1,r.val) (18,q.val,r.val+3) = false := by decide +kernel
#print axioms last_fixed_outer
end Agent10ThreeColumnCodeTest
