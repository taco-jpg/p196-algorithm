#!/usr/bin/env python3
"""Assemble the explicitly frozen Agent 10 thirteen-module evidence packet.

This copies only pinned source and small evidence files. It performs no Lean
build, repository edit, network operation, or patch application.
"""
from pathlib import Path
import hashlib
import json
import subprocess
import tarfile

ROOT = Path('/workspace/scratch/4b20b8469eb3')
REPO = ROOT / 'p196-algorithm'
OUT = ROOT / 'agent10-publication-final'
PACKAGE = OUT / 'package13'
DELIVERY = '78ffdbbf66b3aa1be86e614b4ffc2ea0a8d29264'
TESTED = 'b170358092047167fef8a5cee165366dbc1e8fd7'
BASELINE = '4b4edf976b2c7a9ba1dad80636c0e21c66350325'
TEXT_SUFFIXES = {'.lean', '.py', '.json', '.log', '.md', '.csv', '.txt',
                 '.patch', '.cpp', '.inc'}


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git_bytes(commit, path):
    return subprocess.check_output(['git', 'show', f'{commit}:{path}'], cwd=REPO)


def main():
    if PACKAGE.exists():
        raise RuntimeError('Refusing to overwrite an existing package13 directory')
    source = json.loads((OUT / 'patch-source.json').read_text())
    application = json.loads((OUT / 'patch-application.json').read_text())
    assert source['local_delivery_commit'] == DELIVERY
    assert source['tested_proof_commit'] == TESTED
    assert source['source_baseline'] == BASELINE
    assert len(source['added_paths']) == 25
    assert application['status'] == 'PASS'
    assert source['patch_sha256'] == sha((OUT / 'source-expanded.patch').read_bytes())
    added_records = {r['path']: r for r in application['checks'][0]['added_files']}
    pins = application['checks'][0]['verified_module_pins']
    assert len(pins) == 13
    baseline_pins = [p for p in pins if p['path'] not in source['added_paths']]
    assert len(baseline_pins) == 4
    entries = {}

    def put(dest, data, category, origin):
        dest = str(Path(dest))
        if Path(dest).is_absolute() or '..' in Path(dest).parts:
            raise RuntimeError('Unsafe output path')
        if dest in entries:
            raise RuntimeError('Duplicate output path: ' + dest)
        if data.startswith(b'\x7fELF'):
            raise RuntimeError('ELF binary selected: ' + dest)
        entries[dest] = {'data': data, 'category': category, 'origin': origin,
                         'bytes': len(data), 'sha256': sha(data)}

    def add_file(path, dest, category):
        path = Path(path)
        if not path.is_file() or path.is_symlink():
            raise RuntimeError('Expected regular input file: ' + str(path))
        put(dest, path.read_bytes(), category, str(path))

    def add_tree(path, dest, category):
        path = Path(path)
        for p in sorted(path.rglob('*')):
            if not p.is_file() or '__pycache__' in p.parts:
                continue
            if p.suffix not in TEXT_SUFFIXES:
                continue
            add_file(p, Path(dest) / p.relative_to(path), category)

    for path in source['added_paths']:
        data = git_bytes(DELIVERY, path)
        assert sha(data) == added_records[path]['sha256']
        assert len(data) == added_records[path]['bytes']
        put(Path('snapshot') / path, data, 'delivery-added-source',
            f'git:{DELIVERY}:{path}')
    for pin in baseline_pins:
        path = pin['path']
        data = git_bytes(DELIVERY, path)
        assert data == git_bytes(BASELINE, path) == git_bytes(TESTED, path)
        assert sha(data) == pin['sha256']
        put(Path('snapshot') / path, data, 'unchanged-pinned-dependency',
            f'git:{DELIVERY}:{path}')
    preserved = application['checks'][0]['preserved_files']
    for rec in preserved:
        path = rec['path']
        data = git_bytes(DELIVERY, path)
        assert data == git_bytes(BASELINE, path) == git_bytes(TESTED, path)
        assert sha(data) == rec['sha256']
        put(Path('snapshot') / path, data, 'unchanged-verifier-or-repository-rules',
            f'git:{DELIVERY}:{path}')
    assert len([p for p in entries if p.startswith('snapshot/')]) == 31
    for pin in pins:
        data = git_bytes(TESTED, pin['path'])
        assert sha(data) == pin['sha256']
        assert entries['snapshot/' + pin['path']]['data'] == data

    for name in ['source-expanded.patch', 'patch-source.json', 'patch-application.json',
                 'check_patch_indices.py', 'failed-disposable-checkouts.json']:
        category = ('failed-disposable-checkout-receipt' if name.startswith('failed-')
                    else 'patch-source-and-successful-index-application-evidence')
        add_file(OUT / name, Path('delivery') / name, category)

    eight = ROOT / 'agent10-eight'
    for number in ['001', '002', '003']:
        folder = 'canonical-build-' + number
        add_tree(eight / folder, Path('canonical') / folder,
                 'successful-canonical-kernel-build-' + number)
    for name, category in [
        ('canonical-build-001-specialist-validation.json', 'internal-retained-output-validation'),
        ('canonical-build-002-specialist-validation.json', 'preserved-original-002-attribution'),
        ('canonical-build-002-specialist-validation-corrected.json', 'corrected-002-executor-attribution'),
        ('canonical-build-003-specialist-validation.json', 'internal-retained-output-validation')]:
        add_file(eight / name, Path('validation') / name, category)
    add_tree(eight / 'document-history', 'history/document-history', 'preserved-prior-document-revision')
    add_file(eight / 'six-carry-checkpoint.json', 'history/six-carry-checkpoint.json',
             'preserved-six-carry-checkpoint')

    bridge = ROOT / 'agent10-bridge'
    archive = bridge / 'inherited-bridge-source-evidence.tar.gz'
    with tarfile.open(archive) as tf:
        for m in tf.getmembers():
            assert not m.name.endswith(('.olean', '.ilean', '.pyc'))
            assert '__pycache__' not in m.name
            if m.isfile():
                assert Path(m.name).suffix in TEXT_SUFFIXES
    add_file(archive, 'inherited/inherited-bridge-source-evidence.tar.gz',
             'unchanged-inherited-source-evidence-archive')
    for name in ['checkpoint-provenance.json', 'replay_inherited_bridge.py', 'Agent10ModuleAudit.lean']:
        add_file(bridge / name, Path('inherited') / name, 'inherited-bridge-replay-and-provenance')
    for name in ['build.json', 'axiom-audit.json', 'axiom-audit.initial-format.reconstructed.json',
                 'axiom-record-format-repair.json']:
        add_file(bridge / 'initial-build' / name, Path('inherited/initial-build') / name,
                 'inherited-bridge-build-and-preserved-format-repair')
    add_tree(bridge / 'review-combined', 'reviews/five-module', 'internal-non-author-five-module-review')
    add_tree(bridge / 'review-threecolumn', 'reviews/three-column', 'internal-non-author-three-column-review')
    add_tree(bridge / 'runtime-threecolumn', 'runtime/three-column',
             'runtime-probes-preserve-individual-pass-failure-and-guard-stop-status')

    count = ROOT / 'agent10-count'
    for name, category in [
        ('build-001', 'preliminary-adapter-closure-compile-without-axiom-audit'),
        ('standalone-check-001', 'standalone-compatibility-check-using-existing-dependencies'),
        ('six-check-001', 'failed-six-counterexample-attempt-001'),
        ('six-check-002', 'failed-six-counterexample-attempt-002'),
        ('six-check-003', 'successful-six-counterexample-attempt-003')]:
        add_tree(count / name, Path('attempts/count-and-six') / name, category)
    for name in ['verification.json', 'six-carry-verification.json']:
        add_file(count / name, Path('attempts/count-and-six') / name, 'count-or-six-verification-summary')
    for name in ['validate_canonical_gate.py', 'validate_canonical_gate_002.py',
                 'validate_canonical_gate_002_attribution.py', 'validate_canonical_gate_003.py']:
        category = ('preserved-original-002-validator' if name == 'validate_canonical_gate_002.py'
                    else 'retained-output-validator-source')
        add_file(count / name, Path('validation/scripts') / name, category)

    semantic = ROOT / 'agent10-semantic'
    add_tree(semantic / 'attempts', 'attempts/three-column',
             'preserved-three-column-failures-and-prior-success')
    for name in ['Agent10PrefixWitness.build.log', 'Agent10PrefixExclusion.build.log',
                 'Agent10ThreeColumnExclusion.build.log', 'Agent10ThreeColumnCarry.build.log',
                 'Agent10ThreeColumnArithmeticCheck.lean', 'Agent10ThreeColumnCodeTest.lean',
                 'THREE_COLUMN_RESULT.md', 'three_column_result_manifest.json']:
        add_file(semantic / name, Path('history/local-three-column') / name,
                 'local-development-evidence-separate-from-canonical-builds')
    for name in ['witness_scan.cpp', 'witness_scan.json', 'padded_witness_scan.cpp',
                 'padded_witness_scan.json', 'prefix_scan.py', 'prefix_scan.json',
                 'replay_numeric.py', 'replay_numeric.json', 'three_prefix_scan.py',
                 'three_prefix_scan.json']:
        add_file(semantic / name, Path('computations/original-width11-width13-three-prefix') / name,
                 'original-exact-finite-computation-with-stated-scope')
    for name in ['four-prefix-check-001', 'four-prefix-check-002', 'five-prefix-check-001']:
        category = ('exploratory-prefix-runner-failure-before-compilation' if name.endswith('001') and name.startswith('four')
                    else 'exploratory-prefix-computation-not-part-of-thirteen-module-kernel-scope')
        add_tree(count / name, Path('exploratory') / name, category)
    for name in ['four-prefix-result.md', 'five-prefix-result.md']:
        add_file(count / name, Path('exploratory') / name,
                 'exploratory-computation-scope-and-provenance')
    add_tree(semantic / 'twice-padded-width15-001', 'exploratory/twice-padded-width15-001',
             'exploratory-filtered-actual-word-computation-not-part-of-thirteen-module-kernel-scope')
    add_file(Path(__file__), 'support/assemble_package13.py', 'archive-assembly-source-no-proof-rebuild')

    for path in entries:
        assert 'Agent10SevenCarryCounterexample' not in path
        assert 'Agent10EightCarryCounterexample' not in path
        assert 'thrice-padded-width17' not in path
        assert not path.endswith(('.olean', '.ilean', '.pyc'))
        assert '__pycache__' not in path
    total = sum(v['bytes'] for v in entries.values())
    assert total < 9_500_000, total
    PACKAGE.mkdir()
    for path, record in sorted(entries.items()):
        dest = PACKAGE / path
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(record['data'])
    provenance = {
        'schema_version': 1,
        'scope': 'frozen thirteen-module source/evidence; exploratory computation separately classified',
        'source_baseline': BASELINE,
        'local_delivery_commit': DELIVERY,
        'tested_proof_commit': TESTED,
        'source_snapshot_files': 31,
        'delivery_added_paths': source['added_paths'],
        'unchanged_dependency_pins': baseline_pins,
        'kernel_module_pins': pins,
        'original_unchanged_files': preserved,
        'source_snapshot_identity_verified': True,
        'new_lean_build_performed': False,
        'new_patch_application_performed': False,
        'excluded': ['Seven counterexample module/review', 'Eight counterexample module/review',
                     'active or later width17 computations', '.olean', '.ilean',
                     'compiled executables', 'toolchain copies', '__pycache__'],
        'selected_file_count_before_archive_metadata': len(entries),
        'selected_payload_bytes_before_archive_metadata': total,
        'file_origins': {p: {k: v for k, v in r.items() if k != 'data'}
                         for p, r in sorted(entries.items())}
    }
    (PACKAGE / 'PROVENANCE.json').write_text(json.dumps(provenance, indent=2) + '\n')
    print(json.dumps({'status': 'ASSEMBLED', 'files_before_archive_metadata': len(entries),
                      'payload_bytes_before_archive_metadata': total,
                      'source_snapshot_files': 31, 'kernel_modules': 13}))


if __name__ == '__main__':
    main()
