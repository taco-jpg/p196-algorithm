#!/usr/bin/env python3
"""Compile the packaged exact closure and audit all new-module theorems.

Requires an independently installed official Lean 4.19.0 runtime. Use a new
output directory. No Git repository, downloads, or cached project objects are
required. The package's receipt and source SHA256 values are verified first.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import time


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--lean', type=Path, required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--seconds', type=int, default=600)
    a = p.parse_args()
    package, lean, out = Path(__file__).resolve().parent, a.lean.resolve(), a.output.resolve()
    receipt = json.loads((package / 'receipt.json').read_text())
    order = receipt['closure_order']
    sources = receipt['source_hashes']
    for name in [*order, 'Agent10ModuleAudit']:
        if not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*', name):
            raise ValueError('Invalid module name')
        if sha(package / 'sources' / (name + '.lean')) != sources[name]:
            raise ValueError('Source hash mismatch: ' + name)
    env = os.environ.copy()
    for key in ('LEAN_PATH', 'LEAN_SRC_PATH', 'LEAN_SYSROOT', 'LD_PRELOAD', 'LD_LIBRARY_PATH'):
        env.pop(key, None)
    version = subprocess.check_output([str(lean), '--version'], env=env, text=True).strip()
    if not re.search(r'version 4\.19\.0,.*commit 6caaee842e94, Release', version):
        raise ValueError('Wrong Lean release: ' + version)
    out.mkdir(parents=True, exist_ok=False)
    src, logs = out / 'source', out / 'logs'
    src.mkdir(); logs.mkdir()
    for name in [*order, 'Agent10ModuleAudit']:
        (src / (name + '.lean')).write_bytes((package / 'sources' / (name + '.lean')).read_bytes())
    env['LEAN_PATH'] = str(src)
    record = {'status': 'RUNNING', 'lean_version': version, 'lean_sha256': sha(lean),
              'source_hashes': sources, 'closure_order': order, 'commands': []}
    def save():
        (out / 'verification.json').write_text(json.dumps(record, indent=2) + '\n')
    save()
    for name in [*order, 'Agent10ModuleAudit']:
        command = [str(lean), '-j1', '-DElab.async=false', '-o', name+'.olean', name+'.lean']
        log = logs / (name + '.log')
        started = time.monotonic()
        with log.open('wb') as stream:
            try:
                rc = subprocess.run(command, cwd=src, env=env, stdout=stream, stderr=subprocess.STDOUT,
                                    timeout=a.seconds).returncode
            except subprocess.TimeoutExpired:
                rc = 124
        record['commands'].append({'module': name, 'argv': command, 'exit_code': rc,
                                   'seconds': round(time.monotonic()-started, 3),
                                   'log_sha256': sha(log)})
        print(name, 'exit='+str(rc), flush=True)
        if rc:
            record['status'] = 'FAIL'; save(); return rc
        save()
    text = (logs / 'Agent10ModuleAudit.log').read_text()
    rows = re.findall(r'^AUDIT_THEOREM (\S+) (\S+) : \[([^\]]*)\]', text, re.M)
    parsed = [{'module': m, 'theorem': n, 'axioms': [a.strip() for a in axes.split(',') if a.strip()]}
              for m, n, axes in rows]
    summaries = re.findall(r'^FULL_MODULE_AUDIT theorems=(\d+) union=\[([^\]]*)\]', text, re.M)
    counts = {m: sum(r['module'] == m for r in parsed) for m in receipt['new_module_theorem_counts']}
    allowed = set(receipt['allowed_axioms'])
    passed = (len(summaries) == 1 and int(summaries[0][0]) == len(parsed)
              and len({r['theorem'] for r in parsed}) == len(parsed)
              and counts == receipt['new_module_theorem_counts']
              and all(set(r['axioms']) <= allowed for r in parsed))
    for name, expected in receipt['explicit_endpoint_audits'].items():
        log = (logs / (name + '.log')).read_text()
        observed = log.count('depends on axioms:') + log.count('does not depend on any axioms')
        passed = passed and observed == expected
    for name, expected in sources.items():
        passed = passed and sha(src / (name + '.lean')) == expected
    passed = passed and sha(lean) == record['lean_sha256']
    record.update({'status': 'PASS' if passed else 'FAIL', 'module_counts': counts,
                   'theorem_count': len(parsed), 'axiom_union': sorted({a for r in parsed for a in r['axioms']}),
                   'theorem_records': parsed})
    save()
    return 0 if passed else 1


if __name__ == '__main__':
    raise SystemExit(main())
