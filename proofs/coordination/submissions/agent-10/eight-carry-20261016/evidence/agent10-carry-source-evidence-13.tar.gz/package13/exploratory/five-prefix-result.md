# Exact five-coordinate carry-prefix search

## Result and scope

All **1,871,424** initial pairs with oriented difference `(0,0,0,1,-3)` were enumerated. **1,326** initial prefixes survive eight observations in the necessary prefix graph, along **33,498** compatible shared-inner-bit paths. This is finite computational evidence; the five-coordinate inclusion has not been formalized in Lean, and a surviving prefix is not an actual whole-word eight-carry collision.

The enumerated states are `left=(p,a,a2,b+1,c-3)` and `right=(p,a,a2,b,c)`, with `1≤p≤18`, `0≤a,a2≤18`, `0≤b≤17`, and `3≤c≤18`. Their number is `18×19×19×18×16 = 1,871,424`.

At each observation, both sides receive the same Boolean carry at `L-5`, where `L` is the current width. Equality is required at all low carry indices `1,2,3,4,5` and all reflected high indices `L,L-1,L-2,L-3,L-4`, including the terminal carry. All possible eight-bit control paths are explored. Terminal overflow determines the next-prefix update.

| Number of observations | Surviving initial prefixes | Compatible shared-bit paths |
|---:|---:|---:|
| 1 | 1,397,070 | 2,683,674 |
| 2 | 835,407 | 2,726,444 |
| 3 | 436,263 | 2,438,133 |
| 4 | 246,682 | 1,877,801 |
| 5 | 110,986 | 1,864,316 |
| 6 | 48,146 | 1,554,292 |
| 7 | 12,549 | 573,798 |
| 8 | **1,326** | **33,498** |

The graph does not impose center parity, possible overlap of low and reflected coordinates at short widths, or coherent temporal evolution of the omitted inner region. Actual symmetric decimal words impose these further conditions. Consequently, the result supplies a necessary filter and does not settle whether eight complete carry observations reconstruct arbitrary inputs.

## A complete surviving path

The first retained initial pair is `(12,3,6,3,1)/(12,3,6,2,4)`. The shared-inner bit string is `01101001`; terminal overflow is `10010110`. Low carries below are ordered `1,2,3,4,5`; high carries are ordered `L,L-1,L-2,L-3,L-4`. Both sides have the listed carries.

| Time | Left prefix | Right prefix | Shared `L-5` bit | Common low carries | Common high carries |
|---:|---|---|---:|---|---|
| 0 | (12,3,6,3,1) | (12,3,6,2,4) | 0 | (1,0,0,0,0) | (1,0,0,0,0) |
| 1 | (3,6,9,9,4) | (3,6,9,8,6) | 1 | (0,0,0,0,0) | (0,0,0,0,0) |
| 2 | (6,12,18,18,9) | (6,12,18,16,13) | 1 | (0,1,1,1,1) | (0,1,1,1,1) |
| 3 | (13,5,18,18,0) | (13,5,18,14,8) | 0 | (1,0,1,1,0) | (1,0,1,1,0) |
| 4 | (4,9,14,18,9) | (4,9,14,14,13) | 1 | (0,0,1,1,1) | (0,1,1,1,1) |
| 5 | (9,9,9,18,0) | (9,9,9,10,8) | 0 | (0,0,0,1,0) | (1,1,1,1,0) |
| 6 | (10,9,9,8,9) | (10,9,9,0,9) | 0 | (1,1,1,0,0) | (1,0,0,0,0) |
| 7 | (1,0,9,18,17) | (1,0,9,10,9) | 1 | (0,0,0,1,1) | (0,0,1,1,1) |

Four other complete paths are retained in the result JSON. Their initial pairs and bit strings are:

| Left | Right | Shared-inner bits |
|---|---|---|
| (12,3,6,3,4) | (12,3,6,2,7) | 00011001 |
| (12,3,6,3,10) | (12,3,6,2,13) | 01101001 |
| (12,3,6,3,13) | (12,3,6,2,16) | 00011001 |
| (12,3,6,12,1) | (12,3,6,11,4) | 01101001 |

## Complete width-17 filter

The thrice-padded symmetric difference is

`[0,0,0,1,-3,5,-6,6,-6,6,-6,5,-3,1,0,0,0]`.

For each surviving first-five-coordinate pair, the remaining independent coefficients are:

| Coordinate | Right coefficient choices | Left coefficient |
|---:|---|---|
| 5 | 0 through 13 | right + 5 |
| 6 | 6 through 18 | right - 6 |
| 7 | 0 through 12 | right + 6 |
| 8, the center | 6, 8, 10, 12, 14, 16, 18 | right - 6 |

Reflection supplies coordinates 9 through 16. This gives `14×13×13×7 = 16,562` symmetric, center-even completions per prefix. Therefore:

- Before the prefix filter: `1,871,424×16,562 = 30,994,524,288` candidates in this prescribed difference family.
- After the prefix filter: `1,326×16,562 = 21,961,212` candidates.

The surviving outer coefficients are distributed as 12: 32 starts, 14: 32 starts, 17: 339 starts, and 18: 923 starts. The reduced set is roughly eleven times the size of the preceding filtered width-15 scan, before accounting for its greater width. This is a concrete input set for a compiled full-word scan; no such lift was launched by this task.

The CSV header is `left_0,left_1,left_2,left_3,left_4,right_0,right_1,right_2,right_3,right_4,first_bits_time_0_to_7,full_eight_bit_path_count`. Each of its 1,326 rows occurs once. The bit string is only the first compatible graph path: a full-word lift must use its actual carries and must not restrict itself to that sample path. Exact source and CSV pins were supplied to the parent and semantic specialist for a separately authorized lift.

## Implementation and retained evidence

The C++ implementation is an additive extension of the frozen four-coordinate source. It uses depth-eight DFS, fixed-size states, no memoization, integer arithmetic, streaming CSV output, and at most five retained example paths. Every accepted update is checked as both a digit sum and the corresponding arithmetic recurrence from the original standalone Lean foundation.

Both predecessor control modes passed. The three-coordinate mode reproduced `[3870,2346,1246,692,334,134,37,0]`; the four-coordinate mode reproduced all eight surviving-start counts and all eight compatible-path counts. The five recorded five-coordinate paths were independently replayed against the previous Python simulator, checking all 40 frames, carry vectors, and next states. The five-coordinate process used 2.231985 user CPU seconds, 0.006393 system CPU seconds, and a peak resident size of 11,136 KiB in this environment.

Successful evidence is under `/workspace/scratch/4b20b8469eb3/agent10-count/five-prefix-check-001`:

| Artifact | SHA-256 |
|---|---|
| `five_prefix_scan.cpp` | `f82f37337a734570a792225cb2b07932f6c2e4f95397d8fcefd5abd79f74acfe` |
| `survivors-5.csv` | `3b310524a4436c062eb66926dea3e78e6d15af7e4b9564ff6478fad5abe2bf3a` |
| `result-5.json` | `4f33bbdeb18ed4352f2d54803739637378ef5ec1c53591e906c2a1a3d94957b8` |
| `run_five_prefix_scan.py` | `b25896537abe28538a5db0c4648c129c6b9311b66a32f139a2438b7a050ae0eb` |
| `verification.json` | `7e46468426e2501709177e119028946fb6eeca3c51e639ec287e443244ac13c3` |

The receipt additionally pins the compiler version, binary, commands, process logs and resource measurements, preceding controls, and original foundation. The frozen four-coordinate source SHA-256 remains `e40ca15a6b24360ad78cd3b238aa0c63346fd4330ed271f38e735481839acc6e`. The foundation SHA-256 remains `f8950d138fa4231b536059e2334d36b6496de3d25a806f4cf3925941aa05144c`, Git blob `c6c1f5441c54a36f2d82b3ef78dff1ccdbc5a506`.
