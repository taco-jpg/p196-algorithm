#!/usr/bin/env python3
"""Independent breadth-first controls for the literal prefix exclusion.

Checks observations before each transition, with no terminal-state test.
This is finite corroboration of the Lean certificates, not a proof substitute.
"""
from collections import Counter
import hashlib
import itertools
import json
from pathlib import Path


def overflow(s, v):
    p, q = s
    return (p + (q+v)//10)//10


def nxt(s, v):
    p, q = s
    a, u, b = p//10, (q+v)//10, (q+p//10)//10
    h = (p+u)//10
    if h == 0:
        return max(0, 2*p+u-10*a), max(0, 2*q+a+v-10*(b+u))
    return max(0, p-10*a+1), max(0, p+q+a+u-10*(b+h))


def observations(s, v):
    return s[0]//10, (s[1]+s[0]//10)//10, overflow(s, v)


def layer(frontier):
    result = {}
    for (s, r), path in frontier.items():
        for v in (0, 1):
            if observations(s, v) == observations(r, v):
                result.setdefault((nxt(s, v), nxt(r, v)), path+[v])
    return result


def main():
    root = Path(__file__).resolve().parent
    starts = [((p+2, q), (p+1, q+3)) for p in range(17) for q in range(16)]
    assert len(starts) == 272 and len(set(starts)) == 272
    outcomes = []
    for s, r in starts:
        frontier, counts, first_empty = {(s, r): []}, [], None
        for n in range(1, 8):
            frontier = layer(frontier)
            counts.append(len(frontier))
            if not frontier and first_empty is None:
                first_empty = n
        assert not frontier
        outcomes.append({'s': s, 'r': r, 'reachable_pair_counts_after_each_observation': counts,
                         'first_impossible_observation_count': first_empty})
    frontier = {((17, 3), (16, 6)): []}
    for _ in range(6):
        frontier = layer(frontier)
    assert frontier
    end, witness = next(iter(frontier.items()))
    assert not layer(frontier)
    leading = []
    for f0, f1, f2, f3 in itertools.product(range(-9, 10), repeat=4):
        if f0 == 0:
            continue
        smoothed = [f0, 4*f0+f1, 6*f0+4*f1+f2, 4*f0+6*f1+4*f2+f3]
        if all(-1 <= g <= 1 for g in smoothed):
            leading.append((f0, f1, f2, f3))
    prefixes = sorted(set(x[:2] for x in leading))
    assert prefixes == [(-1, 3), (1, -3)]
    record = {'classification': 'INDEPENDENT_FINITE_CONTROL_NOT_LEAN_PROOF',
              'source_commit': '7442f0489e0e0ae9a23fb4461d1da55fd4ba033f',
              'source_sha256': {m: hashlib.sha256((root/'sources'/(m+'.lean')).read_bytes()).hexdigest()
                                for m in ['Agent10PrefixWitness','Agent10PrefixExclusion']},
              'algorithm': 'Breadth-first state-pair exploration with one shared bit, observation agreement before each edge, and no final-state constraint.',
              'observations': ['incoming carry at 1', 'incoming carry at 2', 'terminal overflow'],
              'literal_start_count': len(starts), 'excluded_after_seven_observations': len(outcomes),
              'first_impossible_observation_histogram': dict(sorted(Counter(x['first_impossible_observation_count'] for x in outcomes).items())),
              'six_observation_graph_witness': {'s': [17,3], 'r': [16,6], 'shared_bits': witness, 'terminal_pair': end,
                                               'seven_observation_extensions': 0, 'actual_decimal_realizability_claimed': False},
              'first_four_coefficient_tuples_enumerated': 19**4,
              'nonzero_leading_tuples_passing_unit_bounds': len(leading),
              'possible_nonzero_leading_pairs': prefixes,
              'literal_start_outcomes': outcomes, 'status': 'PASS'}
    (root/'prefix-finite-controls.json').write_text(json.dumps(record,indent=2)+'\n')
    print(json.dumps({k:record[k] for k in ['status','literal_start_count','excluded_after_seven_observations',
          'first_impossible_observation_histogram','six_observation_graph_witness','nonzero_leading_tuples_passing_unit_bounds',
          'possible_nonzero_leading_pairs']},indent=2))


if __name__ == '__main__':
    main()
