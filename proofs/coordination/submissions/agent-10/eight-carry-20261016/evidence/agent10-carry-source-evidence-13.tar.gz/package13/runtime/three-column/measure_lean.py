#!/usr/bin/env python3
"""Run one isolated Lean compiler while measuring and bounding its resources."""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import resource
import subprocess
import time


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def cgroup_memory() -> int | None:
    try:
        return int(Path('/sys/fs/cgroup/memory.current').read_text())
    except (FileNotFoundError, ValueError, PermissionError):
        return None


def proc_memory(pid: int) -> tuple[int, int]:
    try:
        fields = {}
        for line in Path(f'/proc/{pid}/status').read_text().splitlines():
            if ':' in line:
                key, value = line.split(':', 1)
                fields[key] = value.strip()
        return tuple(int(fields.get(k, '0 kB').split()[0]) * 1024 for k in ['VmRSS', 'VmHWM'])
    except (FileNotFoundError, ProcessLookupError):
        return (0, 0)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--module', required=True)
    parser.add_argument('--source-dir', type=Path, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--timeout-seconds', type=float, default=60)
    parser.add_argument('--rss-limit-mib', type=int, default=1200)
    parser.add_argument('--shared-memory-limit-mib', type=int, default=7400)
    args = parser.parse_args()
    source_dir = args.source_dir.resolve()
    out = args.output_dir.resolve()
    out.mkdir(parents=True, exist_ok=False)
    compiler = Path('/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean')
    source = source_dir / f'{args.module}.lean'
    compiled = source_dir / f'{args.module}.olean'
    command = [str(compiler), '--trust=0', '-j1', '-DElab.async=false',
               '-o', compiled.name, source.name]
    env = dict(os.environ)
    env['LEAN_PATH'] = str(source_dir)
    env.pop('LEAN_SRC_PATH', None)
    started_at = datetime.now(timezone.utc).isoformat()
    before = cgroup_memory()
    peak_rss = peak_hwm = 0
    peak_shared = before or 0
    stop_reason = None
    stop_sent_at = None
    samples = 0
    start = time.monotonic()
    log_path = out / 'compiler.log'
    with log_path.open('wb') as log:
        process = subprocess.Popen(command, cwd=source_dir, env=env,
                                   stdout=log, stderr=subprocess.STDOUT)
        while process.poll() is None:
            samples += 1
            now = time.monotonic()
            rss, hwm = proc_memory(process.pid)
            shared = cgroup_memory()
            peak_rss, peak_hwm = max(peak_rss, rss), max(peak_hwm, hwm)
            peak_shared = max(peak_shared, shared or 0)
            if stop_reason is None:
                if now - start > args.timeout_seconds:
                    stop_reason = 'SUPERVISOR_TIME_BOUND'
                elif rss > args.rss_limit_mib * 1024**2:
                    stop_reason = 'SUPERVISOR_CHILD_RSS_BOUND'
                elif shared is not None and shared > args.shared_memory_limit_mib * 1024**2:
                    stop_reason = 'SUPERVISOR_SHARED_CGROUP_GUARD'
                if stop_reason:
                    process.terminate()
                    stop_sent_at = now
            elif stop_sent_at is not None and now - stop_sent_at > 2:
                process.kill()
            time.sleep(0.1)
        exit_code = process.wait()
    elapsed = time.monotonic() - start
    usage = resource.getrusage(resource.RUSAGE_CHILDREN)
    report = {
        'module': args.module, 'started_at_utc': started_at,
        'status': 'PASS' if exit_code == 0 and not stop_reason else 'INCOMPLETE_PROBE',
        'source': str(source), 'source_sha256': sha(source),
        'compiler': str(compiler), 'compiler_sha256': sha(compiler),
        'command': command, 'cwd': str(source_dir), 'LEAN_PATH': str(source_dir),
        'exit_code': exit_code, 'stop_reason': stop_reason,
        'elapsed_seconds': elapsed, 'user_seconds': usage.ru_utime,
        'system_seconds': usage.ru_stime,
        'waited_child_ru_maxrss_kib': usage.ru_maxrss,
        'sampled_peak_rss_bytes': peak_rss, 'sampled_peak_vmhwm_bytes': peak_hwm,
        'sample_interval_seconds': 0.1, 'sample_count': samples,
        'cgroup_memory_before_bytes': before,
        'cgroup_memory_after_bytes': cgroup_memory(),
        'sampled_peak_shared_cgroup_bytes': peak_shared,
        'limits': {'wall_seconds': args.timeout_seconds,
                   'child_rss_mib': args.rss_limit_mib,
                   'shared_cgroup_guard_mib': args.shared_memory_limit_mib},
        'log': str(log_path), 'log_sha256': sha(log_path),
        'olean_sha256': sha(compiled) if exit_code == 0 and compiled.exists() else None,
        'classification': 'INTERNAL_ISOLATED_RUNTIME_PROBE_NOT_FULL_CLOSURE_REBUILD',
    }
    (out / 'measurement.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps(report, indent=2), flush=True)


if __name__ == '__main__':
    main()
