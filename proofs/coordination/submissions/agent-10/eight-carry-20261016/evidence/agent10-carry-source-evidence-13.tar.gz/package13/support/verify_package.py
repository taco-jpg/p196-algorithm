#!/usr/bin/env python3
"""Verify package13's exact regular-file inventory and content hashes."""
from pathlib import Path
import hashlib
import json


def verify(root):
    root = Path(root).resolve()
    manifest = json.loads((root / 'FILES.json').read_text())
    expected = {x['path']: x for x in manifest['files']}
    actual = {str(p.relative_to(root)) for p in root.rglob('*') if p.is_file()}
    assert actual == set(expected) | {'FILES.json'}, (actual - set(expected), set(expected) - actual)
    for relative, record in expected.items():
        p = root / relative
        assert not p.is_symlink()
        assert p.stat().st_size == record['bytes'], relative
        assert hashlib.sha256(p.read_bytes()).hexdigest() == record['sha256'], relative
        assert p.suffix not in {'.olean', '.ilean', '.pyc'}, relative
        assert '__pycache__' not in p.parts, relative
        assert not p.read_bytes().startswith(b'\x7fELF'), relative
        assert 'Agent10SevenCarryCounterexample' not in relative, relative
        assert 'Agent10EightCarryCounterexample' not in relative, relative
        assert 'thrice-padded-width17' not in relative, relative
    return {'status': 'PASS', 'manifested_files': len(expected),
            'regular_files_including_manifest': len(actual),
            'manifest_sha256': hashlib.sha256((root / 'FILES.json').read_bytes()).hexdigest()}


if __name__ == '__main__':
    print(json.dumps(verify(Path(__file__).resolve().parent.parent), indent=2))
