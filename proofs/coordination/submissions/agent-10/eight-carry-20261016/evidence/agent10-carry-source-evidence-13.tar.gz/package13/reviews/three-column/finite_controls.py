#!/usr/bin/env python3
"""Finite corroboration of the three-column graph and overlapping widths.

The primary transition below adds explicit decimal output digits using %10.
It is independent of the source's subtraction formula. Breadth-first graph
exploration checks observations before transitions and imposes no terminal
observation. This script is a review control, not a kernel proof.
"""
from __future__ import annotations

from collections import Counter
from itertools import product
import hashlib
import json
from pathlib import Path


HERE = Path(__file__).resolve().parent
PINS = {
    'Agent10ThreeColumnExclusion.lean': '965c4cb1dd1e32f6778fe144eb775814167d4379a9179e402f711cbc9bafce18',
    'Agent10ThreeColumnCarry.lean': 'e884ec38e1561a27aa862ef857e7c65db99c0ed3c73fccefc2bec803cc51701d',
}
State = tuple[int, int, int]


def valid(s: State) -> bool:
    p, q, r = s
    return 1 <= p <= 18 and 0 <= q <= 18 and 0 <= r <= 18


def encode(s: State) -> int:
    p, q, r = s
    return 361*p + 19*q + r


def decode(n: int) -> State:
    return (n // 361, n // 19 % 19, n % 19)


def local_carries(s: State, bit: int) -> tuple[int, ...]:
    p, q, r = s
    a = p // 10
    b = (q+a) // 10
    c = (r+b) // 10
    u = (r+bit) // 10
    w = (q+u) // 10
    h = (p+w) // 10
    return a, b, c, u, w, h


def next_by_decimal_digits(s: State, bit: int) -> State:
    p, q, r = s
    a, b, c, u, w, h = local_carries(s, bit)
    low_digits = (p % 10, (q+a) % 10, (r+b) % 10)
    high_digits = ((p+w) % 10, (q+u) % 10, (r+bit) % 10)
    if h == 0:
        return tuple(x+y for x, y in zip(low_digits, high_digits))
    return (low_digits[0]+1, low_digits[1]+high_digits[0], low_digits[2]+high_digits[1])


def source_subtraction_formula(s: State, bit: int) -> State:
    p, q, r = s
    a, b, c, u, w, h = local_carries(s, bit)
    if h == 0:
        values = (2*p+w-10*a, 2*q+a+u-10*(b+w), 2*r+b+bit-10*(c+u))
    else:
        values = (p-10*a+1, p+q+a+w-10*(b+h), q+r+b+u-10*(c+w))
    return tuple(max(0, x) for x in values)


def compatible(s: State, r: State, bit: int, high_first: bool) -> bool:
    a = local_carries(s, bit)
    b = local_carries(r, bit)
    indices = (0, 1, 2, 4, 5) if high_first else (0, 1, 2, 5)
    return all(a[i] == b[i] for i in indices)


def explore_pair(s: State, r: State, high_first: bool) -> tuple[list[bool], list[int] | None, int]:
    frontier = {(s, r): ()}
    survivors = []
    witness7 = None
    peak_frontier = 1
    for depth in range(1, 9):
        after = {}
        for (left, right), bits in frontier.items():
            for bit in (0, 1):
                if compatible(left, right, bit, high_first):
                    pair = (next_by_decimal_digits(left, bit), next_by_decimal_digits(right, bit))
                    assert valid(pair[0]) and valid(pair[1])
                    after.setdefault(pair, bits + (bit,))
        frontier = after
        peak_frontier = max(peak_frontier, len(frontier))
        survivors.append(bool(frontier))
        if depth == 7 and frontier:
            witness7 = list(next(iter(frontier.values())))
    return survivors, witness7, peak_frontier


def full_word_projection(word: list[int]) -> None:
    width = len(word)
    carry = [0]
    digits = []
    for q in word:
        total = q + carry[-1]
        digits.append(total % 10)
        carry.append(total // 10)
    if carry[-1]:
        digits.append(carry[-1])
    next_word = tuple(a+b for a, b in zip(digits, reversed(digits)))
    state = tuple(word[:3])
    bit = carry[width-3]
    assert valid(state)
    assert local_carries(state, bit) == (carry[1], carry[2], carry[3],
                                        carry[width-2], carry[width-1], carry[width])
    assert next_by_decimal_digits(state, bit) == next_word[:3]
    assert source_subtraction_formula(state, bit) == next_word[:3]


def run() -> dict:
    for name, pin in PINS.items():
        assert hashlib.sha256((HERE/'sources'/name).read_bytes()).hexdigest() == pin
    states = list(product(range(1, 19), range(19), range(19)))
    assert len(states) == 6498
    for state in states:
        assert decode(encode(state)) == state
        for bit in (0, 1):
            successor = next_by_decimal_digits(state, bit)
            assert successor == source_subtraction_formula(state, bit)
            assert valid(successor)
            assert decode(encode(successor)) == successor
    starts = [((p, q+1, r), (p, q, r+3))
              for p, q, r in product(range(1, 19), range(18), range(16))]
    assert len(starts) == len(set(starts)) == 5184
    results = {}
    for key, high_first in [('selected_high_first_and_overflow', True), ('weaker_overflow_only', False)]:
        counts = [0] * 8
        failure_at = Counter()
        peak_frontier = 0
        witness = None
        for left, right in starts:
            assert valid(left) and valid(right)
            survives, bits, peak = explore_pair(left, right, high_first)
            peak_frontier = max(peak_frontier, peak)
            for i, survives_i in enumerate(survives):
                counts[i] += int(survives_i)
            if False in survives:
                failure_at[survives.index(False)+1] += 1
            if left == (16, 6, 0) and right == (16, 5, 3):
                witness = {'left': list(left), 'right': list(right), 'seven_observation_shared_bits': bits,
                           'survives_seven': survives[6], 'survives_eight': survives[7]}
        results[key] = {'surviving_start_counts_after_1_through_8_observations': counts,
                        'first_failure_observation_histogram': dict(sorted(failure_at.items())),
                        'peak_frontier_pairs_for_one_start': peak_frontier,
                        'seven_observation_witness': witness}
    assert results['selected_high_first_and_overflow']['surviving_start_counts_after_1_through_8_observations'][-1] == 0
    assert results['weaker_overflow_only']['surviving_start_counts_after_1_through_8_observations'][-1] == 13
    witness = results['selected_high_first_and_overflow']['seven_observation_witness']
    assert witness['survives_seven'] and not witness['survives_eight']
    overlap_counts = {3: 0, 4: 0}
    for p in range(1, 19):
        for center in range(0, 19, 2):
            full_word_projection([p, center, p])
            overlap_counts[3] += 1
        for q in range(19):
            full_word_projection([p, q, q, p])
            overlap_counts[4] += 1
    assert overlap_counts == {3: 180, 4: 342}
    return {
        'status': 'PASS',
        'classification': 'INDEPENDENT_FINITE_CORROBORATION_NOT_KERNEL_PROOF',
        'source_pins': PINS,
        'valid_states_checked': len(states),
        'state_bit_transitions_checked': 2*len(states),
        'decode_encode_identity_checked_on_all_valid_states': True,
        'next_state_validity_checked_without_filtering_graph_paths': True,
        'subtraction_formula_matches_decimal_output_digits': True,
        'literal_initial_pair_count': len(starts),
        'initial_pair_difference': [0, 1, -3],
        'graph_checks': results,
        'all_admissible_width_three_and_four_projection_checks': overlap_counts,
        'scope': 'The selected necessary graph excludes all 5,184 starts after eight observations. Seven-step graph survival is not an actual decimal counterexample. Actual reconstruction scope comes from the reviewed Lean transport proof.',
    }


if __name__ == '__main__':
    record = run()
    path = HERE/'finite-controls.json'
    path.write_text(json.dumps(record, indent=2)+'\n')
    print(json.dumps({'status': record['status'], 'output': str(path),
                      'valid_states': record['valid_states_checked'],
                      'transitions': record['state_bit_transitions_checked'],
                      'initial_pairs': record['literal_initial_pair_count'],
                      'selected_survival_counts': record['graph_checks']['selected_high_first_and_overflow']['surviving_start_counts_after_1_through_8_observations'],
                      'overlapping_width_checks': record['all_admissible_width_three_and_four_projection_checks']}, indent=2))
