import Agent10PrefixExclusion

/-!
Agent #10: exact three-column synchronized-carry refinement.
The extra high carry at L-1 is an actual observed coordinate. Without that
coordinate, the weaker finite graph still has thirteen eight-word starts.
The actual transport below includes widths three and four without disjointness
assumptions on the low and reflected prefixes.

Existing three-column projections include P196.Agent4.WholeWord.nextColumns_prefix3
and Agent113.TwoDigit.nextTriple/high_carries. This file rederives only the
needed arithmetic interface directly from the accepted standalone core to avoid
importing a second foundation definition. The finite exclusion is the new result.
-/

set_option maxHeartbeats 0
set_option maxRecDepth 100000

namespace Agent10ThreeColumnExclusion
open CarryObservability Agent10PrefixExclusion
open DifferenceObservability CarryObservabilityActual
open DecimalDigits FoldedDecimal OverflowCarryNormalization CarryHistory

abbrev State3 := Nat × Nat × Nat

def Valid3 (s : State3) : Prop :=
  1 ≤ s.1 ∧ s.1 ≤ 18 ∧ s.2.1 ≤ 18 ∧ s.2.2 ≤ 18

def state3Of (q : Nat → Nat) : State3 := (q 0, q 1, q 2)
def low1 (s : State3) : Nat := s.1 / 10
def low2 (s : State3) : Nat := (s.2.1 + low1 s) / 10
def low3 (s : State3) : Nat := (s.2.2 + low2 s) / 10
def highMiddle (s : State3) (v : Bool) : Nat := (s.2.2 + innerBit v) / 10
def highFirst (s : State3) (v : Bool) : Nat := (s.2.1 + highMiddle s v) / 10
def overflow3 (s : State3) (v : Bool) : Nat := (s.1 + highFirst s v) / 10

def next3 (s : State3) (v : Bool) : State3 :=
  if overflow3 s v = 0 then
    (2*s.1 + highFirst s v - 10*low1 s,
      2*s.2.1 + low1 s + highMiddle s v - 10*(low2 s + highFirst s v),
      2*s.2.2 + low2 s + innerBit v - 10*(low3 s + highMiddle s v))
  else
    (s.1 - 10*low1 s + 1,
      s.1 + s.2.1 + low1 s + highFirst s v - 10*(low2 s + overflow3 s v),
      s.2.1 + s.2.2 + low2 s + highMiddle s v - 10*(low3 s + highFirst s v))

def compatible3 (s r : State3) (v : Bool) : Bool :=
  decide (low1 s = low1 r ∧ low2 s = low2 r ∧ low3 s = low3 r ∧
    highFirst s v = highFirst r v ∧ overflow3 s v = overflow3 r v)

def survives3 : Nat → State3 → State3 → Bool
  | 0, _, _ => true
  | n+1, s, r =>
      (compatible3 s r false && survives3 n (next3 s false) (next3 r false)) ||
      (compatible3 s r true && survives3 n (next3 s true) (next3 r true))


theorem runtime_raw_single : survives3 8 (16,6,0) (16,5,3) = false := by decide +kernel
#print axioms runtime_raw_single
end Agent10ThreeColumnExclusion
