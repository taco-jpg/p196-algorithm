import datetime, hashlib, json, os, pathlib, resource, subprocess, sys, time
ROOT = pathlib.Path(__file__).resolve().parent
LEAN = pathlib.Path("/workspace/scratch/f8aedc6d7adf/runtime-agent6/lean-4.19.0-linux/bin/lean")
MODULES = ["LychrelDigitSums", "Agent106CarryBudget", "Agent106CongruenceSeed", "Agent106SparseTarget", "Agent106CongruenceObstruction", "Agent106CongruenceControls"]
def now(): return datetime.datetime.now(datetime.timezone.utc).isoformat()
def bounded():
    resource.setrlimit(resource.RLIMIT_AS, (2 * 1024**3, 2 * 1024**3))
    resource.setrlimit(resource.RLIMIT_CPU, (900, 900))
env = dict(os.environ)
env["LEAN_PATH"] = str(ROOT)
env.pop("LEAN_SYSROOT", None)
initial = list(ROOT.glob("*.olean"))
assert not initial, initial
records = []
meta = {"start_utc": now(), "cwd": str(ROOT), "runtime": str(LEAN), "runtime_sha256": hashlib.sha256(LEAN.read_bytes()).hexdigest(), "project_oleans_before_build": [str(p) for p in initial], "LEAN_PATH": env["LEAN_PATH"], "LEAN_SYSROOT": "unset", "resource_limits": {"address_space_bytes": 2 * 1024**3, "cpu_seconds": 900, "timeout_seconds_per_child": 960}, "commands": records}
assert meta["runtime_sha256"] == "92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023"
def run(label, argv):
    started = now()
    wall = time.monotonic()
    result = subprocess.run(argv, cwd=ROOT, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=960, preexec_fn=bounded)
    (ROOT / (label + ".stdout.log")).write_bytes(result.stdout)
    (ROOT / (label + ".stderr.log")).write_bytes(result.stderr)
    row = {"label": label, "argv": argv, "start_utc": started, "end_utc": now(), "wall_seconds": time.monotonic() - wall, "returncode": result.returncode, "stdout": label + ".stdout.log", "stderr": label + ".stderr.log"}
    for stream in ["stdout", "stderr"]:
        data = getattr(result, stream)
        row[stream + "_sha256"] = hashlib.sha256(data).hexdigest()
        row[stream + "_bytes"] = len(data)
    records.append(row)
    meta["last_update_utc"] = now()
    (ROOT / "build-execution.json").write_text(json.dumps(meta, indent=2) + "\n")
    print(json.dumps(row), flush=True)
    if result.returncode: sys.exit(result.returncode)
run("lean-version", [str(LEAN), "--version"])
run("lean-prefix", [str(LEAN), "--print-prefix"])
for module in MODULES:
    run(module, [str(LEAN), "--trust=0", "-j1", "-DElab.async=false", "-M", "2048", "-o", module + ".olean", module + ".lean"])
meta["complete"] = True
meta["end_utc"] = now()
meta["outputs"] = [{"file": p.name, "bytes": p.stat().st_size, "sha256": hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(ROOT.glob("*.olean"))]
(ROOT / "build-execution.json").write_text(json.dumps(meta, indent=2) + "\n")
print("SIX_MODULE_BUILD_COMPLETE", flush=True)

