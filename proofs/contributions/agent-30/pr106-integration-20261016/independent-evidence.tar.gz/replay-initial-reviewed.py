#!/usr/bin/env python3
"""Replay the PR106 exact-source build and independent audits into a new directory.

Example:
  python3 replay.py --lean /path/to/lean-4.19.0-linux/bin/lean \
    --source-dir /path/to/checkout-at-ed9b9048 --work-dir /tmp/pr106-fresh

Only .lean sources are copied from source-dir. Project .olean files are never reused.
The two Agent30 audit harnesses must be adjacent to this script.
"""
import argparse
import datetime
import hashlib
import json
import os
from pathlib import Path
import resource
import shutil
import subprocess
import sys
import time

COMMIT = "ed9b9048adfdda70f699a8a40997a4330b76dc16"
LEAN_SHA256 = "92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023"
SOURCES = [
    ("LychrelDigitSums", "LychrelDigitSums__bf5247272a7e3b69.lean", "8a865176625283648a8a20dd2411ed77670eb0a2", "ca5f46523b7cff02c00918b6466a97963087b499fb5f184232b8b3d806dc0b57"),
    ("Agent106CarryBudget", "Agent106CarryBudget.lean", "8ab159e79cbd601bb0fad884f0ac392574f38d7b", "5eb8d4684584f3941bec9a7ea61b8ca3d7049a8f2ae60d02d64d9e2b6f2b7edc"),
    ("Agent106CongruenceSeed", "Agent106CongruenceSeed.lean", "4af21bdc673ffebfbad5bda77b79fc788f281259", "3c14410f4ccb7a7398c24ba5f24123197dfceb295d09b9aade9b4917e4aa36ed"),
    ("Agent106SparseTarget", "Agent106SparseTarget.lean", "d35c537d35bb12d63d2b338a7b8b8289129b4ae5", "6275b20e7648c309e3e9c3f412e2bbedd4f801f95d4a2b1631c1d1f4ee9bc193"),
    ("Agent106CongruenceObstruction", "Agent106CongruenceObstruction.lean", "1a1d6060087f9ba596d686a1e8ec76f81c8f3475", "c8b4e1567f93e3b8769348b92b33a8e847e4e32440ec6bcc0905f16411d5fb93"),
    ("Agent106CongruenceControls", "Agent106CongruenceControls.lean", "c95c7591e6363d6671818b208e442bf18da97929", "6ef0f20a8a18a0f35264d0007a735aa99b45e0e0f93de1ff865ad708d6cd31f0"),
]
HARNESSES = ["Agent30FullAudit.lean", "Agent30EndpointTypes.lean"]

def sha(data):
    return hashlib.sha256(data).hexdigest()

def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()

def fail(message):
    raise SystemExit(message)

def limits():
    resource.setrlimit(resource.RLIMIT_AS, (4 * 1024**3, 4 * 1024**3))
    resource.setrlimit(resource.RLIMIT_CPU, (900, 900))

def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--lean", required=True, type=Path)
    p.add_argument("--source-dir", required=True, type=Path)
    p.add_argument("--work-dir", required=True, type=Path)
    args = p.parse_args()
    lean = args.lean.resolve(strict=True)
    source = args.source_dir.resolve(strict=True)
    work = args.work_dir.resolve()
    if work.exists():
        fail("Refusing existing --work-dir; use a new directory.")
    if sha(lean.read_bytes()) != LEAN_SHA256:
        fail("Lean executable SHA256 differs from the audited official Linux binary.")
    checked = []
    for module, filename, blob_expected, sha_expected in SOURCES:
        candidates = [source / "proofs" / filename, source / filename, source / (module + ".lean")]
        selected = next((x for x in candidates if x.is_file()), None)
        if selected is None:
            fail("Missing exact source: " + filename)
        data = selected.read_bytes()
        blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        if blob != blob_expected or sha(data) != sha_expected:
            fail("Source identity mismatch: " + str(selected))
        checked.append((module, selected, data, blob_expected, sha_expected))
    harness_dir = Path(__file__).resolve().parent
    for name in HARNESSES:
        if not (harness_dir / name).is_file():
            fail("Missing adjacent harness: " + name)
    work.mkdir(parents=True)
    manifest = []
    for module, selected, data, blob, digest in checked:
        (work / (module + ".lean")).write_bytes(data)
        manifest.append({"module": module, "input_file": str(selected), "git_blob": blob, "sha256": digest, "bytes": len(data)})
    for name in HARNESSES:
        shutil.copyfile(harness_dir / name, work / name)
    env = dict(os.environ)
    env["LEAN_PATH"] = str(work)
    env.pop("LEAN_SYSROOT", None)
    receipt = {"commit": COMMIT, "runtime": str(lean), "runtime_sha256": LEAN_SHA256,
               "cwd": str(work), "LEAN_PATH": str(work), "LEAN_SYSROOT": "unset",
               "initial_project_oleans": [], "sources": manifest,
               "address_space_bytes": 4 * 1024**3, "cpu_seconds": 900,
               "timeout_seconds": 960, "start_utc": now(), "commands": []}
    def run(label, argv):
        started, wall = now(), time.monotonic()
        try:
            result = subprocess.run(argv, cwd=work, env=env, stdout=subprocess.PIPE,
                                    stderr=subprocess.PIPE, timeout=960, preexec_fn=limits)
            code, stdout, stderr = result.returncode, result.stdout, result.stderr
        except subprocess.TimeoutExpired as exc:
            code, stdout, stderr = 124, exc.stdout or b"", exc.stderr or b""
        row = {"label": label, "argv": argv, "start_utc": started,
               "end_utc": now(), "wall_seconds": time.monotonic() - wall, "returncode": code}
        for stream, data in [("stdout", stdout), ("stderr", stderr)]:
            name = label + "." + stream + ".log"
            (work / name).write_bytes(data)
            row[stream] = {"file": name, "sha256": sha(data), "bytes": len(data)}
        receipt["commands"].append(row)
        receipt["complete"] = False
        (work / "replay-execution.json").write_text(json.dumps(receipt, indent=2) + "\n")
        print(json.dumps(row), flush=True)
        if code:
            fail("Replay failed; retained logs in " + str(work))
        return stdout.decode("utf-8")
    version = run("lean-version", [str(lean), "--version"])
    if "version 4.19.0" not in version or "commit 6caaee842e94" not in version:
        fail("Unexpected runtime version.")
    run("lean-prefix", [str(lean), "--print-prefix"])
    for module, _, _, _, _ in checked:
        run(module, [str(lean), "--trust=0", "-j1", "-DElab.async=false",
                     "-o", module + ".olean", module + ".lean"])
    for harness in HARNESSES:
        run(Path(harness).stem, [str(lean), "--trust=0", "-j1", "-DElab.async=false", harness])
    summary = json.loads((work / "audit-summary.json").read_text())
    if summary["status"] != "PASS" or summary["endpoint_count"] != 36:
        fail("Audit summary failed.")
    receipt["complete"] = True
    receipt["end_utc"] = now()
    receipt["audit_summary"] = summary
    receipt["outputs"] = [{"file": f.name, "sha256": sha(f.read_bytes()), "bytes": f.stat().st_size}
                          for f in sorted(work.glob("*.olean"))]
    (work / "replay-execution.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print("EXACT_SOURCE_BUILD_AND_AUDIT_PASS")

if __name__ == "__main__":
    main()

