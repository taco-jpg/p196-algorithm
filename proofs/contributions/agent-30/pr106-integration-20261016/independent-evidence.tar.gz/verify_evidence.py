#!/usr/bin/env python3
"""Cross-check retained exact-source build and audit evidence without compiling."""
import collections
import hashlib
import json
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parent
def read(name): return json.loads((ROOT / name).read_text())
def sha(path): return hashlib.sha256(path.read_bytes()).hexdigest()
manifest = read("source-manifest.json")
build = read("build-execution.json")
execution = read("audit-execution.json")
summary = read("audit-summary.json")
roots = read("audit-roots.json")
implementations = read("audit-unsafe-selected.json")
graph = read("audit-dependency-graph.json")
endpoints = read("audit-endpoints.json")
expected_endpoints = read("endpoint-manifest.json")
assert manifest["commit"] == "ed9b9048adfdda70f699a8a40997a4330b76dc16"
modules = {row["module"] for row in manifest["sources"]}
assert len(modules) == 6
for row in manifest["sources"]:
    data = (ROOT / (row["module"] + ".lean")).read_bytes()
    assert hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest() == row["git_blob"]
    assert hashlib.sha256(data).hexdigest() == row["sha256"]
assert build["complete"] is True and build["project_oleans_before_build"] == []
assert sha(Path(build["runtime"])) == build["runtime_sha256"] == "92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023"
assert build["LEAN_PATH"] == str(ROOT) and build["LEAN_SYSROOT"] == "unset"
source_commands = [r for r in build["commands"] if r["label"] in modules]
assert len(source_commands) == 6 and {r["label"] for r in source_commands} == modules
for row in build["commands"]:
    assert row["returncode"] == 0
    for stream in ["stdout", "stderr"]:
        assert sha(ROOT / row[stream]) == row[stream + "_sha256"]
    if row["label"] in modules:
        assert all(x in row["argv"] for x in ["--trust=0", "-j1", "-DElab.async=false"])
for row in build["outputs"]:
    assert sha(ROOT / row["file"]) == row["sha256"]
assert len(execution["commands"]) == 2
for row in execution["commands"]:
    assert row["returncode"] == 0
    assert sha(ROOT / (row["module"] + ".lean")) == row["source_sha256"]
    assert all(x in row["argv"] for x in ["--trust=0", "-j1", "-DElab.async=false"])
    for stream in ["stdout", "stderr"]:
        assert sha(ROOT / row[stream]["file"]) == row[stream]["sha256"]
assert summary["status"] == "PASS" and summary["violations"] == []
assert summary["endpoint_count"] == 36
root_by_name = {row["name"]: row for row in roots}
graph_by_name = {row["name"]: row for row in graph}
assert len(root_by_name) == len(roots) == summary["selected_safe_constants"]
assert len(graph_by_name) == len(graph) == summary["reachable_kernel_constants"]
allowed = {"propext", "Classical.choice", "Quot.sound"}
assert set(summary["collectAxioms_union"]) == allowed
assert set(summary["independent_graph_axiom_union"]) == allowed
for row in roots:
    assert row["module"] in modules
    assert set(row["axioms"]) <= allowed
    assert set(row["direct_dependencies"]) == set(graph_by_name[row["name"]]["dependencies"])
for row in graph:
    assert row["unsafe"] is False and row["partial"] is False
    assert all(name in graph_by_name for name in row["dependencies"])
    if row["kind"] == "axiom":
        assert row["name"] in allowed
pending = list(root_by_name)
reachable = set()
while pending:
    name = pending.pop()
    if name not in reachable:
        reachable.add(name)
        pending.extend(graph_by_name[name]["dependencies"])
assert reachable == set(graph_by_name)
assert not ({row["name"] for row in implementations} & reachable)
assert len(implementations) == summary["selected_implementation_constants"]
assert sum(row["unsafe"] for row in implementations) == summary["selected_unsafe_constants"]
assert sum(row["partial"] for row in implementations) == summary["selected_partial_constants"]
assert summary["selected_implementation_dependencies"] == []
assert summary["unsafe_logical_dependencies"] == []
assert summary["partial_logical_dependencies"] == []
assert {row["name"] for row in graph if row["module"] in modules} == set(root_by_name)
census = []
for module in modules - {"LychrelDigitSums"}:
    text = (ROOT / (module + ".lean")).read_text()
    census.extend({"name": "Agent106.CongruenceBudget." + name, "module": module}
                  for name in re.findall(r"^theorem\s+([A-Za-z0-9_]+)", text, re.M))
expected = {r["name"]: r["module"] for r in expected_endpoints}
assert len(census) == len(expected) == len(endpoints) == 36
assert {r["name"]: r["module"] for r in census} == expected
assert {r["name"]: r["module"] for r in endpoints} == expected
printed = (ROOT / "Agent30EndpointTypes.stdout.log").read_text()
axiom_names = re.findall(r"^'([^']+)' (?:depends on axioms:|does not depend on any axioms)", printed, re.M)
assert len(axiom_names) == 36 and set(axiom_names) == set(expected)
for name, module in expected.items():
    assert root_by_name[name]["module"] == module and root_by_name[name]["kind"] == "theorem"
    assert re.search(r"^@?" + re.escape(name) + r"(?:\s|[.{:])", printed, re.M), name
counts = {}
for module in sorted(modules):
    selected = [r for r in roots if r["module"] == module]
    excluded = [r for r in implementations if r["module"] == module]
    counts[module] = {
        "theorems": sum(r["kind"] == "theorem" for r in selected),
        "safe_definitions": sum(r["kind"] == "definition" for r in selected),
        "other_safe_constants": sum(r["kind"] not in {"theorem", "definition"} for r in selected),
        "unsafe_definitions": sum(r["kind"] == "definition" and r["unsafe"] for r in excluded),
        "unsafe_axiom_placeholders": sum(r["kind"] == "axiom" and r["unsafe"] for r in excluded),
        "partial_implementations": sum(r["partial"] for r in excluded),
        "public_endpoints": sum(m == module for m in expected.values())
    }
out = {"status": "PASS", "checks": [
    "Exact six source Git blobs and SHA256 hashes",
    "Runtime identity and before/after six olean identities",
    "Six successful trust-zero single-worker asynchronous-elaboration-disabled builds",
    "Successful audit and endpoint-printer commands with matching harness/log hashes",
    "All graph edges resolved and independently recomputed safe-root reachability",
    "No unsafe/partial/excluded implementation in safe-root logical closure",
    "Module-origin census, exact 36 public endpoint census, literal type and axiom output",
    "Both axiom collectors have exactly propext, Classical.choice, Quot.sound"
], "module_counts": counts, "summary": summary}
(ROOT / "evidence-verification.json").write_text(json.dumps(out, indent=2) + "\n")
print(json.dumps(out, indent=2))

