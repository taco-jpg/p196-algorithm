import datetime,hashlib,json,os,pathlib,resource,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent
LEAN="/workspace/scratch/f8aedc6d7adf/runtime-agent6/lean-4.19.0-linux/bin/lean"
def bounded():
    resource.setrlimit(resource.RLIMIT_AS,(2*1024**3,2*1024**3))
    resource.setrlimit(resource.RLIMIT_CPU,(900,900))
env=dict(os.environ);env["LEAN_PATH"]=str(ROOT);env.pop("LEAN_SYSROOT",None)
records=[]
for module in ["Agent30FullAudit","Agent30EndpointTypes"]:
    cmd=[LEAN,"--trust=0","-j1","-DElab.async=false",module+".lean"]
    start=datetime.datetime.now(datetime.timezone.utc).isoformat();wall=time.monotonic()
    r=subprocess.run(cmd,cwd=ROOT,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=960,preexec_fn=bounded)
    row={"module":module,"argv":cmd,"start_utc":start,"end_utc":datetime.datetime.now(datetime.timezone.utc).isoformat(),"wall_seconds":time.monotonic()-wall,"returncode":r.returncode,"source_sha256":hashlib.sha256((ROOT/(module+".lean")).read_bytes()).hexdigest()}
    for stream in ["stdout","stderr"]:
        data=getattr(r,stream);file=module+"."+stream+".log";(ROOT/file).write_bytes(data)
        row[stream]={"file":file,"bytes":len(data),"sha256":hashlib.sha256(data).hexdigest()}
    records.append(row)
    (ROOT/"audit-execution.json").write_text(json.dumps({"cwd":str(ROOT),"LEAN_PATH":env["LEAN_PATH"],"LEAN_SYSROOT":"unset","address_space_bytes":2*1024**3,"cpu_seconds":900,"timeout_seconds":960,"commands":records},indent=2)+"\n")
    print(json.dumps(row),flush=True)
    if r.returncode:sys.exit(r.returncode)
print("AUDIT_AND_ENDPOINT_PRINT_COMPLETE",flush=True)

