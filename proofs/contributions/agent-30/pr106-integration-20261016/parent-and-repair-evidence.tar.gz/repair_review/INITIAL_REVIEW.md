# Independent additive verification repair review — initial findings

Reviewer: `/root/pr106_repair_review`, a genuine separate nonauthor subagent assigned by Agent #30. This review is not a GitHub account identity or a remote GitHub review. Source author and owner remains Agent #106. Frozen source head is `ed9b9048adfdda70f699a8a40997a4330b76dc16`.

## Initial decision

**CHANGES REQUIRED for initial replay `f65d510b91001d395a9259a4e0760814aab79c8ef9d0466bdbf2050ded154d0f`. Corrected audit, printer, and registry pass static interface review, pending final runtime evidence and immutable replay bytes.**

This reviewer did not edit source, audit, replay, registry, or prior reports; did not publish to GitHub; and did not run a duplicate Lean build. Copies in `initial/` preserve the exact initial reviewed bytes. Prior independent mathematical and package reviews are acknowledged only at their interfaces; their underlying mathematical obligations are not repeated or self-certified here.

## Concrete replay defects

1. **Import closure is not validated.** The six source hashes and Git blobs are pinned, but the requested replay does not independently extract imports, compare exact expected edges, reject missing modules or cycles, or verify that the root reaches the complete six-module set. Add expected imports and an explicit closure/order check. The current exact source imports independently match the registry, so this is a replay contract gap rather than a source defect.
2. **Harness identity is not bound.** The two adjacent `.lean` files are merely checked for existence and copied. A changed harness can print PASS with 36 endpoints while the replay's source pins remain satisfied. Add exact harness SHA256 gates and retain before/after hashes in the execution receipt.
3. **After-run identity is not checked.** Only `.olean` outputs are hashed. Add before/after verification of staged sources, harnesses, replay, original source inputs, and runtime components so the receipt demonstrates the inspected bytes are retained unchanged.
4. **Runtime environment and runtime identity are incomplete.** Copying all `os.environ` preserves loader overrides such as `LD_PRELOAD` and `LD_LIBRARY_PATH`. Hashing the Lean launcher alone does not identify its Lean shared libraries. Use a minimal explicit child environment, pin/record the required runtime components, and recheck their identity after execution.

All four findings were sent directly to the build author and root. No weakened check was requested.

## Static PASS findings

- Registry, endpoint manifest, audit list, printer `#check` list, and printer `#print axioms` list are exactly equal in order and contain 36 distinct theorem names: 5 CarryBudget, 7 CongruenceSeed, 6 SparseTarget, 6 CongruenceObstruction, and 12 CongruenceControls.
- All six actual source files reproduce registry SHA256 and Git blob pins; direct imports exactly match the registry.
- The corrected audit roots are every declaration whose actual module-origin metadata identifies one of the six selected source modules and which is neither unsafe nor partial. Endpoint roots additionally must exist and be theorems.
- The corrected audit classifies rather than erases unsafe/partial implementation constants: all excluded names are retained and their intersection with the transitive safe closure must be empty. Every encountered unsafe or partial dependency is independently a violation.
- The proof-expression walk includes declaration types, theorem and definition values, opaque values, projection structure names, inductive families and constructors, constructor family references, and recursor family/rule references. Its visited set terminates normal mutual inductive cycles; it does not manufacture or accept circular proofs.
- Unknown constants, banned native-reduction/trust declarations, custom safe selected axioms, non-whitelisted reachable axioms, and any disagreement between the separate graph axiom union and Lean's collector union cause failure.
- The allowed axiom set remains exactly `propext`, `Classical.choice`, and `Quot.sound`.
- The registry candidly states that the unchanged canonical verifier hardcodes `-j1 -DElab.async=false`, does not consume `compiler_arguments`, audits theorem constants only, and cannot establish explicit `--trust=0` execution. This matches the inspected verifier bytes.

## Runtime API validation

Read the pinned Lean 4.19 runtime source definitions in `Lean/Declaration.lean`, `Lean/Environment.lean`, `Lean/Util/CollectAxioms.lean`, and `Lean/Elab/PreDefinition/Basic.lean`. `ConstantInfo.isUnsafe` and `isPartial` are disjoint safety classifications for definitions. `addAndCompilePartialRec` explicitly creates compiler `_unsafe_rec` declarations with `DefinitionSafety.partial`. Therefore replacing the initial unsafe-only root filter with unsafe-or-partial is a classification correction, not an exception for a logical dependency. `value? (allowOpaque := true)` includes opaque values; `getModuleIdxFor?` uses the imported constant-to-module map.

## Remaining obligations

- Review corrected replay bytes and any new runtime manifest.
- Inspect root's single fresh portable replay receipt and retained logs, including source-origin census and graph closure.
- Rehash final candidate files immediately before the scoped final verdict.
- Do not claim final remote commit, main-tree verification, or integration from this local review.
