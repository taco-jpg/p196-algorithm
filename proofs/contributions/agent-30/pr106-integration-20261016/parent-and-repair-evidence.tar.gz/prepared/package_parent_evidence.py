#!/usr/bin/env python3
"""Preserve completed PR106 parent/review evidence without generated objects."""
from pathlib import Path
import gzip, hashlib, io, json, shutil, tarfile

ROOT = Path("/dev/shm/p196-agent30-4ab29b6d0234")
OUT = ROOT / "publication"
def digest(data):
    return hashlib.sha256(data).hexdigest()
def entry(name, data):
    return {"path": name, "bytes": len(data), "sha256": digest(data),
            "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}
def save(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n")

receipt = json.loads((ROOT / "parent-replay/replay-execution.json").read_text())
controller = json.loads((ROOT / "parent-replay-controller.json").read_text())
assert receipt["complete"] and controller["complete"] and controller["exit_code"] == 0
assert len(receipt["commands"]) == 10 and all(x["returncode"] == 0 for x in receipt["commands"])
assert receipt["audit_summary"]["status"] == "PASS"
assert digest((ROOT / "parent-replay/replay-execution.json").read_bytes()) == "35efa46d83fa75ba5e94d4542ad6f14d9dbed27890674db5996680ce32310e23"
archive = OUT / "parent-and-repair-evidence.tar.gz"
assert not archive.exists(), "Refuse to overwrite preserved evidence"
payload = {}
excluded = []
for directory in ["parent-replay", "parent-source", "repair_review", "prepared"]:
    for path in sorted((ROOT / directory).rglob("*")):
        if not path.is_file():
            continue
        assert not path.is_symlink(), str(path)
        name = str(path.relative_to(ROOT))
        data = path.read_bytes()
        if path.suffix in {".olean", ".pyc"} or "__pycache__" in path.parts:
            row = entry(name, data)
            row["reason"] = "Reproducible compiled output; exact source, commands and object identity remain retained."
            excluded.append(row)
        else:
            payload[name] = data
for name in ["parent-replay-controller.json", "parent-replay-controller.stdout.log", "parent-replay-controller.stderr.log"]:
    payload[name] = (ROOT / name).read_bytes()
for path in sorted((ROOT / "integration").iterdir()):
    if not path.is_file():
        continue
    name = str(path.relative_to(ROOT))
    data = path.read_bytes()
    if path.name in {"base-tree.json", "source-tree.json"}:
        row = entry(name, data)
        row["reason"] = "Regenerable Git-tree census cache from pinned public commits; combination receipt, exact commands and original changed-file map retained."
        excluded.append(row)
    else:
        payload[name] = data
payload["original-pr-body.md"] = (OUT / "ORIGINAL_PR_BODY.md").read_bytes()
payload["EXCLUDED_REPRODUCIBLE_OUTPUTS.json"] = (json.dumps(excluded, indent=2) + "\n").encode()
rows = [entry(name, payload[name]) for name in sorted(payload)]
with archive.open("xb") as raw:
    with gzip.GzipFile(fileobj=raw, mode="wb", filename="", mtime=0, compresslevel=9) as zipped:
        with tarfile.open(fileobj=zipped, mode="w", format=tarfile.USTAR_FORMAT) as tar:
            for name in sorted(payload):
                assert not name.startswith("/") and ".." not in Path(name).parts
                info = tarfile.TarInfo(name)
                info.size = len(payload[name]); info.mode = 0o644
                info.uid = info.gid = info.mtime = 0
                info.uname = info.gname = ""
                tar.addfile(info, io.BytesIO(payload[name]))
with tarfile.open(archive, "r:gz") as tar:
    members = tar.getmembers()
    assert len(members) == len(rows)
    assert len({m.name for m in members}) == len(rows)
    actual = []
    for member in members:
        assert member.isfile() and not member.name.startswith("/") and ".." not in Path(member.name).parts
        data = tar.extractfile(member).read()
        assert data == payload[member.name] and len(data) == member.size
        actual.append(entry(member.name, data))
    assert actual == rows
index = {"schema_version": 1, "status": "PASS_LOSSLESS_ARCHIVE",
         "archive": entry(archive.name, archive.read_bytes()),
         "member_count": len(rows), "files": rows, "exclusions": excluded,
         "source_head": "ed9b9048adfdda70f699a8a40997a4330b76dc16",
         "scope": "Completed parent replay, independent repair review, source fetch, initial combination, preparation and exact failures. No target integration claim."}
save(OUT / "parent-and-repair-evidence-index.json", index)
for dst, src in {"REPAIR_REVIEW.md": "repair_review/REVIEW.md",
                 "REPAIR_REVIEW_MANIFEST.json": "repair_review/FINAL_MANIFEST.json"}.items():
    target = OUT / dst
    assert not target.exists()
    shutil.copyfile(ROOT / src, target)
save(ROOT / "parent-package-result.json", {"status": "PASS", "archive": index["archive"],
     "member_count": len(rows), "index": entry("parent-and-repair-evidence-index.json",
     (OUT / "parent-and-repair-evidence-index.json").read_bytes())})
print(json.dumps({"status": "PASS", "archive": index["archive"], "members": len(rows), "excluded": len(excluded)}))
