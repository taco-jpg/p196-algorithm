# Agent #102 research-map：候选数学义务与排重记录

## 快照与执行边界

- 主干：`4b4edf976b2c7a9ba1dad80636c0e21c66350325`。
- 最新读取的协作分支：`142563ce83e36afe5ddaccb0e93ed821fd40eba0`。
- 真实 GitHub `fetch_issue_comments` 返回 #61 共 172 条；last-seen=`6224693893`。链接：https://github.com/taco-jpg/p196-algorithm/issues/61#issuecomment-6224693893
- 已读取当前四个入口文档 FINDINGS、REPORTS、REPRODUCE、PUBLICATION_SCOPE，主干浅层完整 proofs tree（2588 个条目），当前 coordination/tasks 列表（79 条），其中 30 余个相关任务完整内容，以及相应源文件。
- 以下是源级调查，不是 Lean 检查。我没有执行新的 Lean 构建、证明新定理、认领任务、改动仓库或发送外部评论。
- 候选的“未见认领”仅指本次真实读取的当前任务、相关保留分支与截至 last-seen 的协调信息；正式认领前仍需重新读取增量。历史文档的“未形式化”标签不能独立作为新任务依据。

## 推荐候选一：Group III 七核的全参数实际两步重叠修复

### 精确义务

沿用 `DelayedOverlapGate.component`、`initial`、`shiftOne`。定义新域：

`1 ≤ r ∧ 1 ≤ p ∧ p ≤ 4 ∧ 10 ≤ u ∧ u ≤ 13 ∧ (v = 5 ∨ v = 6) ∧ u + v ≤ 18`。

令 A 为长度 `2*r+6` 的 component，Q 为长度 `2*r+7` 的 initial。证明实际带宽度的 `iterPairs` 满足：

1. 第一步确实偏离：G(Q) 不等于 Phi1(G(A))；
2. 第二步恢复：G²(Q)=Phi1(G²(A))；
3. G²(A) 精确等于
   `[4*p] ++ 0^(r-1) ++ [2,4*u-39,4*v-17,4*v-17,4*u-39,2] ++ 0^(r-1) ++ [4*p]`；
4. 对 Q 的每个普通十进制 Canonical realization，正时间 1、2 的输出均非回文；
5. 给出至少一个正整数 realization，保留普通整数语义。

这补齐第三类高系数核心的 28 个参数化门（7 核 × 4 个 p），不是抽样的具体数值恒等式。

### 已有声明、源与归属

- 主干 `proofs/DelayedOverlapGate__61c024546b1d5b6d.lean`，Git blob `9ab1db741e07fc25e965dd17bb2e67e07a3c3eff`。
- 可重用：`carry_certificate`、`initial_is_overlap`、`fiveWord_admissible`、`columnSum_eq_of_antisymmetric_difference`、`no_overflow_next_congr`、`two_steps_of_explicit_columns`。
- 普通整数的现有桥：`numeric_middle`、`numeric_return`、`numeric_two_step_safety`、`realized_safe_gate` 的证明模式与底层 `PairDelayBridge`。原定理的 Domain 只涵盖 Group I，不能直接扩大原声明。
- 保留的完整书面证明：
  `2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5:proofs/research/main_existence_attempt/renewal_pass/constructive/STATUS.md`，blob `d684dc1865a3e59e1c699ad1ec28a4dbec0a74e2`，第 1 节。

### 排重和第一步

Agent #100 已正式认领 Group II 七核及 Group I(1,6)→Group II(5,5) 的一次组合；其 task blob 为 `69729731db957686d2b1dd67d80b40af232778df`。他的公开范围没有 Group III。Agent #8 拥有通用共同溢出 defect 公式；本目标两次 terminal carry 都为零，不应重做其通用溢出证明。Agent #2 的 core(1,6) first-hit11 也不重叠。

第一步应独立定义 GroupIII 的 first-component、first-whole 与 returned-component 支撑位置，并用 `carry_certificate` 得到实际 carry。与 Group I 的实质区别是 u≥10，第一分量已经产生内部进位，不能复用“所有系数≤9”的 component_carry。重点保留 r=1：第一步新增的 1 与外侧 2p 相邻，2p+1≤9 恰好阻止额外进位。先证明两步有限 pair-word 恒等式，再复用普通整数桥和安全判据。

## 推荐候选二：完整四列核心分类的否定方向

### 精确义务

固定原书面分类域：

`r ≥ 1, 1 ≤ p ≤ 18, 1 ≤ u ≤ 18, 0 ≤ v ≤ 9, u+v ≤ 18`，

A、Q 使用相同原始 component/initial。对实际宽度、实际 terminal carry 和有限支持词证明：

> 如果 Q 相对 A 第一步失配、第二步恢复 shiftOne 重叠，而且两次普通输出都安全，那么 p≤4 且 (u,v) 必属于 Group I、II、III 的那 20 个核心。

随后引用各组的正向定理，组成“恰好 80 个全参数门”的 iff。最有价值的新内容是排除整个规范参数域其余情形；不是重写已认领 Group II 的正向公式。

### 已有声明与证据

- 同一个 DelayedOverlapGate 主干模块及上述桥。
- 保留书面分类报告同 blob `d684dc1865a3e59e1c699ad1ec28a4dbec0a74e2` 第 5 节。
- 其明确记录 2430 个 (p,u,v) 参数三元组、对 r 的符号尾部和所有小边界处理。源级报告指出“结构不同的 affine RLE 表达式”本身不等于对所有参数不相等；必须提供非零系数且承载区间长度在全部参数上严格为正。
- 现有 `intermediate_overlap_fails`、`coefficient_defect_exact`、`normalized_digit_defect_exact` 只证明 Group I 特例；它们不是完整否定分类。

### 排重和第一步

截至 last-seen 没有看到整个四列核心族的 Lean 必要性分类认领。与 #100、GroupIII 正向定理以及 #8 通用 defect 算法都有依赖关系，因此 claim 应明确写成“全规范域的必要性/排除”，保留这些原作者和源接口。不要把正向 Group II 或通用 overflow transport 顺带纳入所有权。

第一步：读取并固定 `padded_core_classification.py` 及每个负例的实际 mismatch certificate，抽象出一条可由 Lean 检查的统一局部 carry/有限支撑否定证书。对 r≥5 的尾部做真正的全参数证明；r=1..4 作为明确有限边界。用 Std 的 Nat/Int、有限 List/Fin、逐位置 `omega` 和 kernel `decide` 即可推进；不得将 Python 的字符串比较或有限采样结论当作 kernel 证据。最终必须同时核对输出宽度，不能仅比较 Nat→Nat 函数的未约束窗外部分。

## 推荐候选三：实际 affine-RLE 轨道的最终稳定性，以及加性可变返回时间归约

### 精确义务

Q(k) 是固定有限符号列表、各段长度为 k 的仿射函数的规范 pair-word 家族，在某个尾部各段长度正，总长度斜率 A>0，固定 s>0。若每个足够大 k 存在正 t(k)，实际 G^t(k)(Q(k))=Q(k+s)，并且所选段每步普通输出安全，则证明存在固定正 t 与 K，使每个 k≥K 都有相同返回和安全段。

关键新增义务必须包含：

1. 对任意固定 t，实际 normalize/pair 迭代 G^t(Q(k)) 在某个 k 尾部具有固定符号列表和仿射段长度；
2. 两个正的规范 affine-RLE 家族的相等性，在某个尾部要么恒真、要么至多一个例外；
3. 中间普通 digit-word 的回文性有同样的最终二分，从而安全性也可作有限时刻的共同尾部化。

只写“有限 cover 有一个无限子集”不够；无限子集不等于整条尾部。这也是本候选区别于已有固定有限 seed-ensemble 紧致性定理之处。

### 已有 Lean 接口与书面来源

- `proofs/LychrelDigitSums__0810ace083af80c5.lean`，blob `8a865176625283648a8a20dd2411ed77670eb0a2`。
- `DecimalWidthGrowth.lower_potential_step`：
  `lowerPotential(nextColumns q L 0)+1+4*L ≤ lowerPotential(q 0)+4*nextWidth q L`。
- `DecimalWidthGrowth.width_lower_potential`：
  `K+4*L ≤ 4*(iterPairs q L K).1+lowerPotential(q 0)`。
- `lowerPotential_bounded` 给势至多 4，因此固定加性宽度增量已经把返回时间界在有限集合；同外部符号保留末端势可得到原书面的 4*A*s。
- 原书面定理：
  `2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5:proofs/research/main_existence_attempt/continuation_pass/variable_return/VARIABLE_RETURN_THEOREMS.md`，blob `af8a18bf44cebf0fa56904338087d2f58f15de19`，第 1 节。
- 当前完整浅层 Lean 源文件列表未发现 affine-RLE 表示或最终断点排序/overlay 形式化；相应 Python 符号运算不能替代这一步。

### 排重和第一步

Agent #1 的最新 specialist 提案（comment `6224692858`）正是 repeated-block normalization：固定块重复次数改变时 carry 与 digit blocks 的精确规律。这与本候选的基础 normalization 环节邻接，应该复用其发布的原声明，claim 只保留“仿射断点最终排序、反转/overlay、RLE 相等及安全二分、actual variable-time theorem”。Agent #17/#217/#317/#423 的 finite ensemble 提取不含这些实际参数族语义。Agent #14 的 finite-window 与 #414 的 cyclic temporal-word period 也不同。

第一步：定义一个基于 List 的 affine-run 词求值函数，使用 Int 保存可能为负的截距，并明确尾部正性。先证明有限个仿射端点之差在尾部有固定比较结果；随后对反转和两个 run 分区的 common refinement 做归纳。最后组合已有宽度界与 Agent #1 的 repeated-block 接口。此任务纯 Lean/Std 可表达，工作量明显大于前两项，但直接约束“用变化返回时间逃避固定返回失败”的构造路线。乘法参数更新、越来越长的符号目录和一般多参数区域必须保留为范围外。

## 已排除的旧缺口与被占用范围

1. “任意有限 word 的普通整数实现”：`Agent112.Eventual.arbitrary_eventual_realization` 与 `arbitrary_safe_symbolic_positive_seed` 已存在于 `CoefficientContraction__a7dcc0e676da69f2.lean`，不能新做一个包装就称补桥。
2. 证书到正整数 witness：现有 `Agent112.Admissibility.checked_positive_decimal_seed` 已存在；#11/#211/#21 的审查也定位真实缺口在具体接受的 certificate。
3. 全高区 actual bridge：`ActualHighReturn__05f989c630a9557e.lean` 已含 `numeric_high_returns_le_three` 等；安全三次的 sharpness 也有 `SafeHighWitness.exists_safe_three_returns` 和 `SafeHighFamily.safe_three_returns_family`。旧 FINDINGS 的 UNKNOWN 不能当作现状。
4. run ancestry：`AncestryExtinction__567be2f804ec7f4c.lean` 已有 `survival_bound`、`extinct_uniform`、`orbit_ancestry_extinct`。
5. cap-four：本次最初曾考虑，随后最新公开排重指出 Agent #114 retained ACTIVE 已拥有 canonical cap-four escape-by-15 和普通轨道 lift；Agent #1 正询问 unrestricted `BoundedEscapeAt 4`。因此整体暂不列入无人认领的候选。既有 `CertificateUnrestricted__598b358293f2eb9e.lean` 的 `accepted_exceeds_cap_unrestricted` 只是通用转移，不能把它重复包装为新结果。
6. 新 #100 = GroupII；新 #101 = 完整数字拆分 multiplicity；#2 = overflow-fiber maximum 加 firsthit11；#3 = overflow finite horizon 加深度二 incoming histories；#9 = no-overflow finite horizon；#7 = odd no-overflow；#8 = common overflow defect；#10 = eight-carry premise discharge。
7. #4 Int/Nat normalize/trim、#5 even-base repair 及 proposed literal digit streams、#6 gamma/rho 和 beta cycle telescope、#216 full correspondence、#411 native charge、#16 mod22、#14 finite windows、#15 fourth-column lift、#418 balanced multiblock continuation 均保持原所有权。

## 推荐优先级

若希望立即形成可检查的新数学包，优先 GroupIII。若希望输出完整结构分类，之后推进否定方向，并等待/复用 #100 和 #8 的适用接口。Affine-RLE 路线更接近方法层面的有限种子瓶颈，但应将新增核心严格限定到 endpoint ordering 与 actual overlay，不要再次证明已有有限集合量词引理或抢占 #1 的 repeated-block normalization。

