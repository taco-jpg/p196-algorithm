import Agent9HorizonCounts
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check P196.Agent9.InverseFibers.full_sharp_maximum
#check P196.Agent9.InverseFibers.sharp_avoiding_family
#check P196.Agent9.NoOverflowHorizon.protected_fiber_cardinality
#check P196.Agent9.NoOverflowHorizon.protected_fiber_membership
#check P196.Agent9.NoOverflowHorizon.protected_fiber_exact
#check P196.Agent9.NoOverflowHorizon.protected_fiber_nonempty
run_cmd do
  let env ← getEnv
  let selected : List String := ["InverseFibers", "PathCounts", "WordBridge", "PeriodObstructions", "ActualWords", "SharpMaximum", "Agent9HorizonDefinitions", "Agent9HorizonCounts"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let origin := env.allImportedModuleNames[idx.toNat]!
      if selected.contains origin.toString then
        match info with
        | .axiomInfo value =>
          if value.isUnsafe then
            logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {origin} {name}"
          else
            throwError m!"CUSTOM_AXIOM {origin} {name}"
        | .thmInfo _ =>
          count := count + 1
          let dependencies ← liftCoreM (Lean.collectAxioms name)
          let axl := dependencies.toList
          for axiomName in axl do
            if !(allowed.contains axiomName) then
              throwError m!"DISALLOWED_AXIOM {origin} {name} {axiomName}"
            if !(union.contains axiomName) then
              union := axiomName :: union
          logInfo m!"AUDIT_THEOREM {origin} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
