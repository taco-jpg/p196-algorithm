# Independent historical dependency / count review

Reviewer: Agent #9/runtime-audit. Result: **PASS for the selected eight-module count closure**. The exact command records, source identities, compiler identity, generated audit, 和 raw outputs are retained in [the independent count evidence](independent-counts/verification.json).

## Checked source scope

The five historical modules `InverseFibers`, `PathCounts`, `WordBridge`, `ActualWords`, 和 `SharpMaximum` were checked byte for byte against their paths at source commit `7be455c03d777e5e0ca1d44bea4d1330e3f764c7`. The imported `PeriodObstructions` source was checked against original blob `a89dda20e9a9b3452f7d0272b4fbd28f7d6ce119` at `2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5`. The two new modules were pinned by SHA-256 in the retained source manifest.

Every module was copied unchanged into a new source directory. The separate object directory initially contained zero project objects. All eight compiler invocations exited zero under Lean 4.19.0, commit `6caaee842e94`. The exhaustive audit covered 252 theorem constants, including generated auxiliaries. Their transitive axiom union was exactly `Classical.choice`, `Quot.sound`, 和 `propext`. Eight generated unsafe implementation constants were recorded separately; none appeared in a theorem's transitive axiom set. All selected source bytes stayed unchanged.

## What the historical proof establishes

[`InverseFibers`](../deps/InverseFibers.lean) derives its transition weights from the actual decimal carry equations for each of 19 output symbols 和 four carry states. Its finite transition table is a kernel-checked `decide` result. The state records the two boundary carry bits; acceptance at an even center requires their equality.

[`PathCounts`](../deps/PathCounts.lean) defines an explicit enumerator of input half-words. It proves that membership agrees with the arithmetic path predicate, that enumerator length equals the forward dynamic-programming total, 和 that the enumerator has no duplicates. The uniqueness argument covers both distinct labels 和 distinct guessed interior carry states.

[`WordBridge`](../deps/WordBridge.lean) proves both directions between this path predicate 和 full decimal normalization of the mirrored input word, retaining both boundary carries. [`ActualWords`](../deps/ActualWords.lean) then identifies the result with the existing `Agent8.stepWord`, whose definition is pair formation after ordinary normalization. The zero final carry is an explicit condition. Canonical input filtering requires a positive exterior coefficient.

[`SharpMaximum`](../deps/SharpMaximum.lean) transfers the result to complete mirrored coefficient words using injectivity of `mirror`. For positive half-width `n`, the global canonical-fiber maximum is `max 1 (fib (n - 1))`, with an explicit witness. Its separate next-normalization avoidance theorem requires a positive neutral-block length. These statements retain their stated finite scope.

## Why the new exact count follows

The new [definitions](../Agent9HorizonDefinitions.lean) use target half-word `11 :: (replicate m 9 ++ replicate k 18)`. The [count proof](../Agent9HorizonCounts.lean) establishes that an eighteen-symbol update preserves `Counts.U`, the total of the two accepted even-center states. It makes no claim that the entire four-state count vector is preserved.

Consequently, appending any finite block of eighteens leaves the accepted inverse count unchanged. The historical leading-eleven family already has exact count `fib m`. Its exterior input label is five, so every such preimage passes the positive-exterior filter. Combining those facts with the explicit enumerator-length theorem gives `protected_fiber_cardinality` for every `m, k : Nat`.

The result includes the boundary `m = 0`, where the fiber is empty because `fib 0 = 0`. `protected_fiber_nonempty` correctly adds the hypothesis `0 < m`. The parameter `k` may be zero. Adding a reservoir increases the half-width to `m + k + 1`; this family retains count `fib m` without claiming the enlarged-width global maximum.

## Intrinsic full-word completeness

`FullActualFiber m k q` explicitly requires length `2 * (m + k + 1)`, reversal symmetry, coefficients below 19, positive exterior, zero final carry, 和 the original transition to `targetWord m k`.

The reverse direction of `protected_fiber_membership` starts with these intrinsic conditions. It derives `mirror (q.take (m + k + 1)) = q` from the even length 和 symmetry, then establishes the half-word conditions required by the old enumerator. A pre-existing half-word representation is therefore absent from the theorem's assumptions. The forward direction proves the same intrinsic properties from enumerator membership. This closes the possible representation-completeness gap.

## Scope assessment

No semantic gap was found in the stated coefficient-word cardinality or membership result. The counted objects are complete coefficient words. A numerical predecessor claim requires a separate decimal realization bridge. In the combined finite-horizon construction, the integer whose safety is asserted realizes the target coefficient word; a further theorem is needed to identify numerical predecessors for each counted input word or claim an additional predecessor time step.

The cardinality theorem alone supplies no fixed seed with infinite palindrome avoidance 和 no result specific to the integer 196. The later safety module is outside this eight-module review record; its complete import closure has a separate verification record.
