#!/usr/bin/env python3
"""Independent, read-only source replay of the pinned consolidation core.

All writes are confined to a new audit output directory. Sources are selected
through the migration map and checked against both original pins. No repository
checker, generated object, or original-layout restoration is executed.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time
import traceback

PIN = "4b4edf976b2c7a9ba1dad80636c0e21c66350325"
PROJECT = "consolidation-core"
ALLOWED = ["propext", "Classical.choice", "Quot.sound"]
FORBIDDEN = re.compile(r"(?<![\w'])\b(?:sorry|admit|axiom|sorryAx|native_decide|ofReduceBool|skipKernelTC)\b(?![\w'])")
MODULE = re.compile(r"[A-Za-z_][\w]*(?:\.[A-Za-z_][\w]*)*\Z")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def code_only(source: str) -> str:
    """Remove nested comments and quoted strings, preserving line numbers."""
    chars = list(source)
    pos, depth, quoted = 0, 0, False
    while pos < len(source):
        pair = source[pos:pos + 2]
        if depth:
            if pair == "/-":
                chars[pos:pos + 2] = "  "
                depth += 1
                pos += 2
                continue
            if pair == "-/":
                chars[pos:pos + 2] = "  "
                depth -= 1
                pos += 2
                continue
            if chars[pos] != "\n":
                chars[pos] = " "
        elif quoted:
            if source[pos] == "\\":
                chars[pos:pos + 2] = "  "
                pos += 2
                continue
            if source[pos] == '"':
                quoted = False
            if chars[pos] != "\n":
                chars[pos] = " "
        elif pair == "/-":
            chars[pos:pos + 2] = "  "
            depth = 1
            pos += 2
            continue
        elif pair == "--":
            end = source.find("\n", pos)
            if end < 0:
                end = len(source)
            chars[pos:end] = " " * (end - pos)
            pos = end
            continue
        elif source[pos] == '"':
            chars[pos] = " "
            quoted = True
        pos += 1
    if depth or quoted:
        raise ValueError("Unterminated comment or string")
    return "".join(chars)


def safe_path(root: Path, rel: str) -> Path:
    result = root / rel
    if Path(rel).is_absolute() or not result.resolve().is_relative_to(root):
        raise ValueError("Path escapes source root: " + rel)
    if result.is_symlink():
        raise ValueError("Selected source is a symbolic link: " + rel)
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--lean", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    repo, lean, out = args.repo.resolve(), args.lean.resolve(), args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    source, build, logs, original = (out / n for n in ("source", "build", "logs", "original"))
    for directory in (source, build, logs, original):
        directory.mkdir()
    report = {
        "auditor": "Agent #9/runtime-audit",
        "project": PROJECT,
        "status": "RUNNING",
        "expected_commit": PIN,
        "repository_wide_pass": False,
        "invocation": [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]],
        "workflow_sha256": sha(Path(__file__).read_bytes()),
        "started_epoch": time.time(),
        "commands": [],
        "sources": {},
        "build_directory_initially_empty": not any(build.iterdir()),
        "forbidden_tokens": FORBIDDEN.pattern,
        "allowed_axioms": ALLOWED,
    }

    def save() -> None:
        (out / "verification.json").write_text(json.dumps(report, indent=2) + "\n")

    env = {"PATH": str(lean.parent) + ":/usr/bin:/bin", "LANG": "C.UTF-8", "LEAN_PATH": str(build)}
    report["build_environment"] = env

    def run(label: str, argv: list[str], cwd: Path = source, timeout: int = 1800, build_env: bool = True) -> str:
        logfile = logs / (label + ".log")
        start = time.monotonic()
        with logfile.open("wb") as stream:
            try:
                result = subprocess.run(argv, cwd=cwd, env=env if build_env else None,
                                        stdout=stream, stderr=subprocess.STDOUT, timeout=timeout)
                rc = result.returncode
            except subprocess.TimeoutExpired:
                rc = 124
        data = logfile.read_bytes()
        record = {"label": label, "argv": argv, "cwd": str(cwd), "exit_code": rc,
                  "seconds": round(time.monotonic() - start, 6),
                  "log": str(logfile.relative_to(out)), "log_sha256": sha(data)}
        report["commands"].append(record)
        save()
        print(f"{label}: exit={rc}, seconds={record['seconds']}", flush=True)
        if rc:
            raise RuntimeError(f"{label} failed with exit {rc}; see {logfile}")
        return data.decode("utf-8", "replace")

    def snapshot_sources() -> dict[str, str]:
        return {str(p): sha(p.read_bytes()) for p in selected_paths}

    selected_paths: set[Path] = set()
    try:
        head = run("source-head", ["git", "rev-parse", "HEAD"], repo, build_env=False).strip()
        report["source_commit"] = head
        if head != PIN:
            raise ValueError("Repository pin changed")
        initial_status = run("source-status-before", ["git", "status", "--porcelain"], repo, build_env=False)
        report["source_status_before"] = initial_status
        if initial_status:
            raise ValueError("Repository working tree is not initially clean")
        version = run("lean-version", [str(lean), "--version"]).strip()
        if not re.fullmatch(r"Lean \(version 4\.19\.0, x86_64-unknown-linux-gnu, commit 6caaee842e94, Release\)", version):
            raise ValueError("Unexpected Lean version: " + version)
        runtime = Path(run("lean-prefix", [str(lean), "--print-prefix"]).strip()).resolve()
        compiler_paths = sorted(set([lean, runtime / "lib/lean/Init.olean", runtime / "lib/lean/Std.olean",
                                     runtime / "lib/lean/Lean.olean", *list((runtime / "lib/lean").glob("*.so"))]))
        compiler_hashes = {str(p): sha(p.read_bytes()) for p in compiler_paths}
        report["compiler"] = {"version": version, "sysroot": str(runtime), "files": compiler_hashes}
        migration_path = repo / "proofs/SOURCE_MAP.json"
        migration_bytes = migration_path.read_bytes()
        migration = json.loads(migration_bytes)
        report["migration_base"] = migration["base"]
        report["migration_sha256"] = sha(migration_bytes)
        selected_paths.add(migration_path)

        def mapped_file(old: str) -> tuple[Path, bytes, dict]:
            rec = migration["paths"][old]
            current = rec.get("current")
            if not current:
                raise ValueError("No current source selected for " + old)
            path = safe_path(repo, current)
            data = path.read_bytes()
            if sha(data) != rec["sha256"]:
                raise ValueError("Migration source hash mismatch: " + current)
            selected_paths.add(path)
            return path, data, rec

        registry_path, registry_bytes, _ = mapped_file("proofs/ACCEPTED_BUILD.json")
        registry = json.loads(registry_bytes)
        if registry["schema_version"] != 1 or registry["toolchain"]["allowed_axioms"] != ALLOWED:
            raise ValueError("Unexpected registry format or axiom policy")
        report["registry_sha256"] = sha(registry_bytes)
        report["registry_path"] = str(registry_path)
        report["catalogue_complete"] = registry["catalogue_complete"]
        report["catalogue_blockers"] = registry["catalogue_blockers"]
        (original / "ACCEPTED_BUILD.json").write_bytes(registry_bytes)
        spec = registry["projects"][PROJECT]
        report["scope"] = spec["scope"]
        modules = spec["modules"]
        originals, imported, compiled = {}, {}, {}
        for name, rec in modules.items():
            if not MODULE.fullmatch(name):
                raise ValueError("Invalid module name: " + name)
            path, data, _ = mapped_file(rec["path"])
            blob = hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()
            if sha(data) != rec["sha256"] or blob != rec["git_blob"]:
                raise ValueError("Accepted registry source mismatch: " + name)
            originals[name] = data
            (original / (name + ".lean")).write_bytes(data)
            report["sources"][name] = {"current_path": str(path), "original_path": rec["path"],
                                       "original_sha256": sha(data), "git_blob": blob}
        for name, rec in modules.items():
            data = originals[name]
            adapter = rec.get("adapter")
            if adapter:
                if adapter["kind"] != "verified_embedded_foundation" or adapter["container_module"] == name:
                    raise ValueError("Unsupported compatibility adapter")
                container = originals[adapter["container_module"]]
                if sha(data) != adapter["original_source_sha256"] or sha(container) != adapter["container_source_sha256"]:
                    raise ValueError("Adapter pins differ")
                small, large = data.splitlines(keepends=True), container.splitlines(keepends=True)
                offset, count = adapter["embedded_start_line_1_based"] - 1, adapter["embedded_line_count"]
                if small[0] != b"import Std\n" or large[0] != b"import Std\n" or count != len(small) - 1:
                    raise ValueError("Adapter framing differs")
                if large[offset:offset + count] != small[1:]:
                    raise ValueError("Original foundation is not byte-identical inside container")
                data = ("/- Generated compatibility import; original foundation bytes remain retained and are verified in full inside the canonical module. -/\nimport "
                        + adapter["container_module"] + "\n").encode()
            for label, scanned in (("original", originals[name]), ("compiled", data)):
                code = code_only(scanned.decode())
                match = FORBIDDEN.search(code)
                if match:
                    raise ValueError(f"Forbidden source token {match.group()} in {label} {name}")
            imports = [word for line in re.findall(r"^\s*import\s+([^\n]+)", code_only(data.decode()), re.M) for word in line.split()]
            if imports != rec["imports"]:
                raise ValueError("Declared import list differs: " + name)
            for dep in imports:
                if not MODULE.fullmatch(dep):
                    raise ValueError("Invalid import: " + dep)
                if dep not in modules:
                    if dep.split(".")[0] not in {"Init", "Std", "Lean"}:
                        raise ValueError("Unregistered local dependency: " + dep)
                    if not (runtime / "lib/lean" / (dep.replace(".", "/") + ".olean")).is_file():
                        raise ValueError("Missing standard-library import: " + dep)
            imported[name], compiled[name] = imports, data
            target = source / (name.replace(".", "/") + ".lean")
            target.parent.mkdir(parents=True, exist_ok=True)
            target.write_bytes(data)
            report["sources"][name].update({"build_sha256": sha(data), "imports": imports, "adapter": adapter})
        order, active, visited = [], set(), set()

        def visit(name: str) -> None:
            if name not in modules or name in visited:
                return
            if name in active:
                raise ValueError("Import cycle: " + name)
            active.add(name)
            for dep in imported[name]:
                visit(dep)
            active.remove(name)
            visited.add(name)
            order.append(name)

        for root in spec["roots"]:
            if root not in modules:
                raise ValueError("Missing root " + root)
            visit(root)
        if visited != set(modules):
            raise ValueError("Not every registered module belongs to the root closure")
        report["build_order"] = order
        report["root_modules"] = spec["roots"]
        report["source_snapshot_before"] = snapshot_sources()
        report["precompile_object_count"] = len(list(build.rglob("*.olean")))
        save()
        for name in order:
            relative = name.replace(".", "/")
            target = build / (relative + ".olean")
            target.parent.mkdir(parents=True, exist_ok=True)
            run(name, [str(lean), "-j1", "-DElab.async=false", "-o", str(target), relative + ".lean"])
        endpoints = [endpoint for claim in registry["claims"] if claim["project"] == PROJECT for endpoint in claim.get("endpoints", [])]
        if not endpoints or any(not MODULE.fullmatch(n) for n in endpoints):
            raise ValueError("Invalid endpoint list")
        audit = "\n".join("import " + m for m in spec["roots"]) + "\nimport Lean\nopen Lean Elab Command\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\n"
        audit += "\n".join("#check " + n for n in endpoints) + "\n"
        audit += "run_cmd do\n  let env ← getEnv\n  let selected : List String := " + json.dumps(order) + "\n"
        audit += """  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let origin := env.allImportedModuleNames[idx.toNat]!
      if selected.contains origin.toString then
        match info with
        | .axiomInfo value =>
          if value.isUnsafe then
            logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {origin} {name}"
          else
            throwError m!"CUSTOM_AXIOM {origin} {name}"
        | .thmInfo _ =>
          count := count + 1
          let dependencies ← liftCoreM (Lean.collectAxioms name)
          let axioms := dependencies.toList
          for axiomName in axioms do
            if !(allowed.contains axiomName) then
              throwError m!"DISALLOWED_AXIOM {origin} {name} {axiomName}"
            if !(union.contains axiomName) then
              union := axiomName :: union
          logInfo m!"AUDIT_THEOREM {origin} {name} : {axioms}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
"""
        audit_path = source / "Agent9RuntimeAudit.lean"
        audit_path.write_text(audit)
        report["audit_source_sha256"] = sha(audit_path.read_bytes())
        audit_log = run("Agent9RuntimeAudit", [str(lean), "-j1", "-DElab.async=false", audit_path.name])
        totals = re.findall(r"^FULL_MODULE_AUDIT theorems=(\d+) union=(.+)$", audit_log, re.M)
        declarations = re.findall(r"^AUDIT_THEOREM (\S+) (\S+) : (.*)$", audit_log, re.M)
        if len(totals) != 1 or int(totals[0][0]) != len(declarations) or not declarations:
            raise ValueError("Missing or incomplete exhaustive theorem audit")
        if len({d[1] for d in declarations}) != len(declarations):
            raise ValueError("Duplicate theorem audit entry")
        report["theorem_count"] = len(declarations)
        report["axiom_union"] = totals[0][1]
        report["endpoints"] = endpoints
        report["unsafe_implementation_axioms"] = re.findall(r"^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$", audit_log, re.M)
        report["source_snapshot_after"] = snapshot_sources()
        if report["source_snapshot_after"] != report["source_snapshot_before"]:
            raise ValueError("Repository input changed during replay")
        for name, data in compiled.items():
            if (source / (name.replace(".", "/") + ".lean")).read_bytes() != data:
                raise ValueError("Build source changed during replay: " + name)
        if {str(p): sha(p.read_bytes()) for p in compiler_paths} != compiler_hashes:
            raise ValueError("Compiler input changed during replay")
        report["source_status_after"] = run("source-status-after", ["git", "status", "--porcelain"], repo, build_env=False)
        if report["source_status_after"] != initial_status:
            raise ValueError("Repository status changed during replay")
        report["status"] = "PASS_SCOPED_BASELINE"
        print(f"PASS_SCOPED_BASELINE: modules={len(order)}, audited_theorems={len(declarations)}", flush=True)
        return 0
    except Exception as error:
        report["status"] = "FAIL"
        report["error"] = str(error)
        (out / "failure.txt").write_text(traceback.format_exc())
        print("FAIL:", error, flush=True)
        return 1
    finally:
        report["finished_epoch"] = time.time()
        save()
        files = {str(p.relative_to(out)): {"sha256": sha(p.read_bytes()), "bytes": p.stat().st_size}
                 for p in sorted(out.rglob("*")) if p.is_file() and p.name != "FILES.json"}
        (out / "FILES.json").write_text(json.dumps(files, indent=2) + "\n")


if __name__ == "__main__":
    raise SystemExit(main())
