import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

ROOT = Path('/workspace/scratch/8dcaf4a67fa4/agent9-safety')
LEAN = Path('/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean')
MODULES = sys.argv[1:] or ['InverseFibers', 'PathCounts', 'WordBridge', 'PeriodObstructions', 'ActualWords', 'SharpMaximum', 'Agent9HorizonDefinitions', 'LychrelDigitSums', 'DecimalSafeRuns']
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
dest = ROOT / 'attempts' / stamp
dest.mkdir(parents=True)
env = os.environ.copy()
env['LEAN_PATH'] = str(ROOT / 'build')
records = []
for name in MODULES:
    src = ROOT / 'source' / (name + '.lean')
    out = ROOT / 'build' / (name + '.olean')
    shutil.copyfile(src, dest / src.name)
    command = [str(LEAN), '-o', str(out), str(src)]
    start = datetime.datetime.now(datetime.timezone.utc)
    result = subprocess.run(command, cwd=ROOT / 'source', env=env, capture_output=True, text=True)
    elapsed = (datetime.datetime.now(datetime.timezone.utc) - start).total_seconds()
    (dest / (name + '.stdout.log')).write_text(result.stdout)
    (dest / (name + '.stderr.log')).write_text(result.stderr)
    record = {'module': name, 'source_sha256': hashlib.sha256(src.read_bytes()).hexdigest(), 'command': command, 'cwd': str(ROOT / 'source'), 'LEAN_PATH': env['LEAN_PATH'], 'exit_code': result.returncode, 'seconds': elapsed, 'stdout_log': str(dest / (name + '.stdout.log')), 'stderr_log': str(dest / (name + '.stderr.log'))}
    if result.returncode == 0:
        record['olean_sha256'] = hashlib.sha256(out.read_bytes()).hexdigest()
    records.append(record)
    (dest / 'manifest.json').write_text(json.dumps(records, indent=2) + '\n')
    print(json.dumps(record), flush=True)
    if result.returncode:
        print(result.stdout, flush=True)
        print(result.stderr, flush=True)
        sys.exit(result.returncode)
print('Build complete: ' + str(dest), flush=True)
