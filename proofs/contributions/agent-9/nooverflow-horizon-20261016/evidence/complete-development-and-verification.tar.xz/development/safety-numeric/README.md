# Safety and numeric proof development evidence

This directory preserves the exact local development history for
`Agent9HorizonSafety.lean` and `Agent9HorizonNumeric.lean`. Neither delivered
mathematical module is changed by this evidence bundle.

`run-index.json` identifies every compiler invocation group and its exit
codes. Each `runs/<UTC timestamp>/` directory retains the original command
manifest, stdout, stderr, and every attempted Safety or Numeric source,
including failed attempts. The successful final sources are in runs
`20261016T210947898387Z` (Safety) and `20261016T211551798920Z` (Numeric).

The failed sources and their diagnostics are historical development
evidence, not accepted proofs. Their diagnostic axiom output may therefore
include the compiler's `sorryAx` placeholder after a proof error. Both final
successful audits contain only `propext`, `Classical.choice`, and
`Quot.sound`; their manifests record compiler exit code zero.

The dependency builds are preserved with their original logs and command
manifests. Duplicate copies of imported dependency sources are omitted:
`omitted-source-refs.json` records the repository path, exact Git blob,
SHA-256, and attempted source SHA-256 for every omitted copy. These agree
with `source-pins.json`. No compiled `.olean` artifact is stored here.

`build.py` is the unchanged driver that ran these checks. Its absolute
scratch paths, and those in the original manifests, are preserved as
historical evidence. For portable reproduction, use the contribution's
final verifier and the exact source mapping in `source-pins.json`.

All checks used Lean 4.19.0. The compiler executable SHA-256 was
`92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023`.

The original imports were rebuilt from source before the new modules.
No preexisting project `.olean` was supplied as a proof dependency. The
two extra Numeric imports are the unchanged published `TemplateStep` and
`Compat` modules; the numeric proof reuses
`Agent109.Compat.pairWord_step` and does not establish a new normalizer.

`SHA256SUMS` covers all preserved files except itself.
