from itertools import product
from math import floor

def normalize(q):
 out=[];c=0
 for x in q:
  v=x+c;out.append(v%10);c=v//10
 if c:out.append(c)
 return out

def pair(d):return [a+b for a,b in zip(d,d[::-1])]
def stepword(q):return pair(normalize(q))
def canon(q):
 L=len(q)
 d=[max(0,x-9) if i<L-1-i else min(x,9) if L-1-i<i else x//2 for i,x in enumerate(q)]
 return sum(x*10**i for i,x in enumerate(d))
def rev(n):return int(str(n)[::-1])
def step(n):return n+rev(n)
def fib(m):
 a,b=0,1
 for _ in range(m): a,b=b,a+b
 return a

def paths(ss,p=(0,0)):
 if not ss:return [[]] if p[0]==p[1] else []
 result=[];s=ss[0];a,b=p
 for x in range(19):
  for aa,bb in product(range(2),repeat=2):
   if (x+a)//10==aa and (x+bb)//10==b and (x+a)%10+(x+bb)%10==s:
    result += [[x]+tail for tail in paths(ss[1:],(aa,bb))]
 return result
checks=[]
for m in range(1,7):
 for k in range(1,5):
  ss=[11]+[9]*m+[18]*k; r=ss+ss[::-1]
  xs=paths(ss);assert len(xs)==fib(m) and len({tuple(x) for x in xs})==len(xs)
  targetseed=canon(r)
  assert pair(list(map(int,str(targetseed)[::-1])))==r
  z=targetseed
  for t in range(k+1):
   assert z!=rev(z)
   z=step(z)
  for x in xs:
   q=x+x[::-1];assert x[0]==5
   assert len(normalize(q))==len(q) and stepword(q)==r
   n=canon(q);z=n
   for t in range(k+2):
    assert z!=rev(z)
    z=step(z)
  checks.append((m,k,len(xs)))
print({'scope':'independent finite arithmetic control, not Lean proof','m_range':[1,6],'k_range':[1,4],'cases':len(checks),'all_passed':True,'total_preimage_words':sum(x[2] for x in checks)})
