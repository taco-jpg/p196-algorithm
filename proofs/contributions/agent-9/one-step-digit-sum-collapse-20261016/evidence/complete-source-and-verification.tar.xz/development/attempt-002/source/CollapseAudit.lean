import Agent9OneStepDigitSumCollapse
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check P196.Agent9.OneStepDigitSumCollapse.framedNine_prefix_wordSum
#check P196.Agent9.OneStepDigitSumCollapse.framedNine_wordSum
#check P196.Agent9.OneStepDigitSumCollapse.framedNine_realization_digitSum_double
#check P196.Agent9.OneStepDigitSumCollapse.framedNine_realization_digitSum
#check P196.Agent9.OneStepDigitSumCollapse.framedNine_output_prefix_wordSum
#check P196.Agent9.OneStepDigitSumCollapse.framedNine_realization_step_digitSum
#check P196.Agent9.OneStepDigitSumCollapse.framedNine_realization_digitSums
#check P196.Agent9.OneStepDigitSumCollapse.framedNine_digitSums_realized
#check P196.Agent9.OneStepDigitSumCollapse.arbitrarily_large_digitSum_and_width
#check P196.Agent9.OneStepDigitSumCollapse.arbitrarily_large_digitSum
#print axioms P196.Agent9.OneStepDigitSumCollapse.framedNine_prefix_wordSum
#print axioms P196.Agent9.OneStepDigitSumCollapse.framedNine_wordSum
#print axioms P196.Agent9.OneStepDigitSumCollapse.framedNine_realization_digitSum_double
#print axioms P196.Agent9.OneStepDigitSumCollapse.framedNine_realization_digitSum
#print axioms P196.Agent9.OneStepDigitSumCollapse.framedNine_output_prefix_wordSum
#print axioms P196.Agent9.OneStepDigitSumCollapse.framedNine_realization_step_digitSum
#print axioms P196.Agent9.OneStepDigitSumCollapse.framedNine_realization_digitSums
#print axioms P196.Agent9.OneStepDigitSumCollapse.framedNine_digitSums_realized
#print axioms P196.Agent9.OneStepDigitSumCollapse.arbitrarily_large_digitSum_and_width
#print axioms P196.Agent9.OneStepDigitSumCollapse.arbitrarily_large_digitSum
run_cmd do
  let env ← getEnv
  let selected : List String := ["LychrelDigitSums", "IncomingCarrySensitivity", "RawSymmetryObstruction", "IntrinsicSeam", "SeamAnnihilation", "Agent9OneStepDigitSumCollapse"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut definitionCount := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let origin := env.allImportedModuleNames[idx.toNat]!
      if selected.contains origin.toString then
        match info with
        | .axiomInfo value =>
          if value.isUnsafe then
            logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {origin} {name}"
          else
            throwError m!"CUSTOM_AXIOM {origin} {name}"
        | .thmInfo _ =>
          count := count + 1
          let dependencies ← liftCoreM (Lean.collectAxioms name)
          let axl := dependencies.toList
          for axiomName in axl do
            if !(allowed.contains axiomName) then
              throwError m!"DISALLOWED_AXIOM {origin} {name} {axiomName}"
            if !(union.contains axiomName) then
              union := axiomName :: union
          logInfo m!"AUDIT_THEOREM {origin} {name} : {axl}"
        | .defnInfo _ | .opaqueInfo _ =>
          if info.isUnsafe then
            logInfo m!"UNSAFE_IMPLEMENTATION_DEFINITION {origin} {name}"
          else
            definitionCount := definitionCount + 1
            let dependencies ← liftCoreM (Lean.collectAxioms name)
            let axl := dependencies.toList
            for axiomName in axl do
              if !(allowed.contains axiomName) then
                throwError m!"DISALLOWED_DEFINITION_AXIOM {origin} {name} {axiomName}"
              if !(union.contains axiomName) then
                union := axiomName :: union
            logInfo m!"AUDIT_DEFINITION {origin} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
  logInfo m!"FULL_DEFINITION_AUDIT definitions={definitionCount}"
