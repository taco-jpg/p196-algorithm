#!/usr/bin/env python3
"""Retain one fresh generic factorial-recurrence compiler attempt."""

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time
from datetime import datetime, timezone


def digest(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", required=True, type=Path)
    parser.add_argument("--attempt", required=True)
    parser.add_argument("--scratch-root", required=True, type=Path)
    args = parser.parse_args()
    package = Path(__file__).resolve().parent.parent
    report = package / "development" / args.attempt
    build = args.scratch_root.resolve() / (args.attempt + "-build")
    if report.exists() or build.exists():
        raise SystemExit("The report 和 build directories must be absent.")
    report.mkdir()
    build.mkdir(parents=True)
    module = "Agent9FactorialRecurrence"
    source = (package / (module + ".lean")).read_bytes()
    (report / (module + ".lean")).write_bytes(source)
    (build / (module + ".lean")).write_bytes(source)
    runner = Path(__file__).read_bytes()
    (report / "run_generic.py").write_bytes(runner)
    env = os.environ.copy()
    env["LEAN_PATH"] = str(build)
    lean = str(args.lean.resolve())
    record = {
        "status": "RUNNING",
        "started_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_sha256": digest(source),
        "runner_sha256": digest(runner),
        "lean_executable": lean,
        "lean_executable_sha256": digest(Path(lean).read_bytes()),
        "cwd": str(build),
        "LEAN_PATH": str(build),
        "fresh_build_directory": True,
        "copied_compiled_objects": False,
        "commands": [],
    }

    def save():
        (report / "record.json").write_text(json.dumps(record, indent=2) + "\n")

    save()
    try:
        commands = [
            ("version", [lean, "--version"]),
            ("compile", [lean, "--trust=0", "-j1", "-DElab.async=false", "-o",
                         module + ".olean", module + ".lean"]),
        ]
        for label, argv in commands:
            start = time.perf_counter()
            result = subprocess.run(argv, cwd=build, env=env, capture_output=True)
            (report / (label + ".stdout.log")).write_bytes(result.stdout)
            (report / (label + ".stderr.log")).write_bytes(result.stderr)
            record["commands"].append({
                "label": label, "argv": argv, "exit_code": result.returncode,
                "elapsed_seconds": time.perf_counter() - start,
                "stdout_sha256": digest(result.stdout),
                "stderr_sha256": digest(result.stderr),
            })
            save()
            print(result.stdout.decode(), end="", flush=True)
            print(result.stderr.decode(), end="", flush=True)
            if result.returncode != 0:
                raise RuntimeError("Compiler command failed: " + label)
            if label == "version":
                if b"4.19.0" not in result.stdout or b"6caaee842e94" not in result.stdout:
                    raise RuntimeError("Unexpected compiler release.")
        record["status"] = "LEAN_CHECKED"
    except Exception as error:
        record["status"] = "FAILED"
        record["failure"] = str(error)
        raise
    finally:
        record["finished_at_utc"] = datetime.now(timezone.utc).isoformat()
        save()


if __name__ == "__main__":
    main()
