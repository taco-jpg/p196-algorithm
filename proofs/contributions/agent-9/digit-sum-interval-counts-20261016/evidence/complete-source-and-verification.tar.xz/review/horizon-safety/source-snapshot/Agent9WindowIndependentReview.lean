import Agent9WindowIntervalCounts

namespace P196.Agent9.IntervalCountsReview

open P196.Agent9.IntervalCounts

/-- Membership in the counted list is precisely membership in the requested
half-open interval together with the predicate. -/
theorem counted_membership (P : Nat → Prop) [DecidablePred P] (s N t : Nat) :
    t ∈ (List.range' s N).filter (fun u => decide (P u)) ↔
      s ≤ t ∧ t < s + N ∧ P t := by
  simp only [List.mem_filter, List.mem_range'_1, decide_eq_true_eq, and_assoc]

/-- The list count counts distinct times. -/
theorem counted_times_nodup (P : Nat → Prop) [DecidablePred P] (s N : Nat) :
    ((List.range' s N).filter (fun u => decide (P u))).Nodup :=
  List.Pairwise.filter _ (List.nodup_range' (s := s) (n := N))

theorem empty_interval (P : Nat → Prop) [DecidablePred P] (s : Nat) :
    intervalCount P s 0 = 0 := by
  simp [intervalCount]

theorem left_endpoint_included (s : Nat) :
    intervalCount (fun t => t = s) s 1 = 1 := by
  simp [intervalCount, List.range'_succ]

theorem right_endpoint_excluded (s N : Nat) :
    intervalCount (fun t => t = s + N) s N = 0 := by
  unfold intervalCount
  have he : (List.range' s N).filter (fun t => decide (t = s + N)) = [] := by
    apply List.filter_eq_nil_iff.mpr
    intro t ht
    have hb := (List.mem_range'_1).mp ht
    simp only [decide_eq_true_eq]
    omega
  rw [he]
  rfl

theorem no_zero_window (P : Nat → Prop) :
    ¬ (∀ a, ∃ t, a ≤ t ∧ t < a + 0 ∧ P t) := by
  intro hw
  obtain ⟨t, hlo, hhi, _⟩ := hw 0
  omega

theorem count_le_interval_length (P : Nat → Prop) [DecidablePred P]
    (s N : Nat) : intervalCount P s N ≤ N := by
  simpa only [intervalCount, List.length_range'] using
    List.length_filter_le (fun t => decide (P t)) (List.range' s N)

/-- At H=1 the proved lower bound attains the full interval length. -/
theorem one_window_exact (P : Nat → Prop) [DecidablePred P]
    (hw : ∀ a, ∃ t, a ≤ t ∧ t < a + 1 ∧ P t) (s N : Nat) :
    intervalCount P s N = N := by
  apply Nat.le_antisymm (count_le_interval_length P s N)
  simpa only [Nat.div_one, intervalCount] using
    window_property_interval_count P 1 (by decide) hw s N

theorem multiples_three_window :
    ∀ a, ∃ t, a ≤ t ∧ t < a + 3 ∧ t % 3 = 0 := by
  intro a
  refine ⟨3 * ((a + 2) / 3), ?_, ?_, ?_⟩ <;> omega

theorem periodic_count_bound (s N : Nat) :
    N / 3 ≤ intervalCount (fun t => t % 3 = 0) s N :=
  window_property_interval_count _ 3 (by decide) multiples_three_window s N

/-- The left endpoint zero is counted and the right endpoint six is not. -/
theorem zero_start_example : intervalCount (fun t => t % 3 = 0) 0 6 = 2 := by
  decide

/-- A valid window property need not contribute inside a shorter remainder. -/
theorem short_remainder_example :
    intervalCount (fun t => t % 3 = 0) 1 2 = 0 := by
  decide

#check @window_property_interval_count
#print axioms intervalCount
#print axioms intervalCount_append
#print axioms intervalCount_mono_length
#print axioms intervalCount_positive_of_witness
#print axioms window_property_complete_blocks
#print axioms window_property_interval_count
#print axioms counted_membership
#print axioms counted_times_nodup
#print axioms empty_interval
#print axioms left_endpoint_included
#print axioms right_endpoint_excluded
#print axioms no_zero_window
#print axioms count_le_interval_length
#print axioms one_window_exact
#print axioms multiples_three_window
#print axioms periodic_count_bound
#print axioms zero_start_example
#print axioms short_remainder_example

end P196.Agent9.IntervalCountsReview
