import Agent9DigitSumIntervalCounts
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check P196.Agent9.IntervalCounts.intervalCount
#check P196.Agent9.IntervalCounts.intervalCount_append
#check P196.Agent9.IntervalCounts.intervalCount_mono_length
#check P196.Agent9.IntervalCounts.intervalCount_positive_of_witness
#check P196.Agent9.IntervalCounts.window_property_complete_blocks
#check P196.Agent9.IntervalCounts.window_property_interval_count
#check P196.Agent9.IntervalCounts.digitSum_interval_count
#check P196.Agent9.IntervalCounts.digitSum_interval_count_196
#check DecimalUniformEscape.sharpDigitSumEscapeBound
#check DecimalUniformEscape.digitSum_uniform_window_sharp
#check DecimalMass.digitSum
#check Lychrel196.orbit
run_cmd do
  let env ← getEnv
  let selected : List String := ["Agent9WindowIntervalCounts", "LychrelDigitSums", "SharedProfile", "ProfileDynamics", "ProfileIsolation", "UniformEscape", "SharpProfileBounds", "SharpUniformEscape", "DecimalEmbedding", "SharpUniformDecimal", "Agent9DigitSumIntervalCounts"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut definitionCount := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let origin := env.allImportedModuleNames[idx.toNat]!
      if selected.contains origin.toString then
        match info with
        | .axiomInfo value =>
          if value.isUnsafe then
            logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {origin} {name}"
          else
            throwError m!"CUSTOM_AXIOM {origin} {name}"
        | .thmInfo _ =>
          count := count + 1
          let dependencies ← liftCoreM (Lean.collectAxioms name)
          let axl := dependencies.toList
          for axiomName in axl do
            if !(allowed.contains axiomName) then
              throwError m!"DISALLOWED_AXIOM {origin} {name} {axiomName}"
            if !(union.contains axiomName) then
              union := axiomName :: union
          logInfo m!"AUDIT_THEOREM {origin} {name} : {axl}"
        | .defnInfo _ | .opaqueInfo _ =>
          if info.isUnsafe then
            logInfo m!"UNSAFE_IMPLEMENTATION_DEFINITION {origin} {name}"
          else
            definitionCount := definitionCount + 1
            let dependencies ← liftCoreM (Lean.collectAxioms name)
            let axl := dependencies.toList
            for axiomName in axl do
              if !(allowed.contains axiomName) then
                throwError m!"DISALLOWED_DEFINITION_AXIOM {origin} {name} {axiomName}"
              if !(union.contains axiomName) then
                union := axiomName :: union
            logInfo m!"AUDIT_DEFINITION {origin} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
  logInfo m!"FULL_DEFINITION_AUDIT definitions={definitionCount}"
