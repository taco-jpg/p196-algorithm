#!/usr/bin/env python3
"""Compile the review-only numeric boundary checks against this review's closure."""
import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import time


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--lean", required=True, type=Path)
    parser.add_argument("--closure", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    lean, closure, output = map(Path.resolve, (args.lean, args.closure, args.output))
    preceding = json.loads((closure / "verification.json").read_text())
    if preceding["status"] != "PASS_SELECTED_SOURCE_CLOSURE":
        raise RuntimeError("The independent complete-closure gate has not passed")
    if preceding["compiler"]["files"][str(lean)] != sha(lean.read_bytes()):
        raise RuntimeError("Compiler differs from the full-closure run")
    output.mkdir(parents=True, exist_ok=False)
    source_name = "Agent9DigitSumIndependentReview.lean"
    source_path = Path(__file__).resolve().parent / source_name
    data = source_path.read_bytes()
    (output / source_name).write_bytes(data)
    env = {"PATH": str(lean.parent) + ":/usr/bin:/bin", "LANG": "C.UTF-8",
           "LEAN_PATH": str(closure / "build")}
    argv = [str(lean), "--trust=0", "-j1", "-DElab.async=false", "-o",
            str(output / "Agent9DigitSumIndependentReview.olean"), source_name]
    started = time.time()
    result = subprocess.run(argv, cwd=output, env=env, capture_output=True)
    (output / "stdout.log").write_bytes(result.stdout)
    (output / "stderr.log").write_bytes(result.stderr)
    expected = ["zero_threshold_horizon", "zero_threshold_count", "empty_numeric_interval",
                "zero_seed_orbit", "zero_seed_no_excursions", "positive_seed_premise_required"]
    prefix = "P196.Agent9.IntervalCounts.IndependentNumericReview."
    text = result.stdout.decode()
    axioms = {name: sorted({a.strip() for a in ax.split(",") if a.strip()})
              for name, ax in re.findall(r"'([^']+)' depends on axioms: \[([^\]]*)\]", text)}
    axioms.update({name: [] for name in re.findall(r"'([^']+)' does not depend on any axioms", text)})
    expected = [prefix + name for name in expected]
    passed = result.returncode == 0 and all(
        name in axioms and set(axioms[name]) <= {"propext", "Quot.sound", "Classical.choice"}
        for name in expected)
    unchanged = source_path.read_bytes() == data
    record = {"status": "PASS" if passed and unchanged else "FAIL", "argv": argv,
              "invocation": [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]],
              "cwd": str(output), "environment": env, "exit_code": result.returncode,
              "started_epoch": started, "finished_epoch": time.time(),
              "compiler_sha256": sha(lean.read_bytes()), "source_sha256": sha(data),
              "source_unchanged": unchanged, "expected_exports": expected,
              "printed_axioms": axioms, "stdout_sha256": sha(result.stdout),
              "stderr_sha256": sha(result.stderr),
              "closure_verification_sha256": sha((closure / "verification.json").read_bytes()),
              "workflow_sha256": sha(Path(__file__).read_bytes()),
              "note": "Review-only boundary evidence, separate from the eleven mathematical modules. Uses only objects from the preceding independent trust-zero closure build."}
    (output / "verification.json").write_text(json.dumps(record, indent=2) + "\n")
    print(json.dumps({"status": record["status"], "exit_code": result.returncode,
                      "exports_checked": len(expected), "output": str(output)}))
    return 0 if passed and unchanged else 1


if __name__ == "__main__":
    raise SystemExit(main())
