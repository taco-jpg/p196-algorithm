import datetime
import hashlib
import json
import os
from pathlib import Path
import shutil
import subprocess

ROOT = Path('/workspace/scratch/8dcaf4a67fa4/agent9-safety/interval-review')
LEAN = Path('/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean')
stamp = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
run = ROOT / 'runs' / stamp
source = run / 'source'
build = run / 'build'
source.mkdir(parents=True)
build.mkdir()
environment = os.environ.copy()
environment['LEAN_PATH'] = str(build)
manifest = {'compiler': str(LEAN), 'compiler_sha256': hashlib.sha256(LEAN.read_bytes()).hexdigest(), 'fresh_build_directory': str(build), 'commands': []}
for module in ['Agent9WindowIntervalCounts', 'Agent9WindowIndependentReview']:
    path = source / (module + '.lean')
    shutil.copyfile(ROOT / 'source' / path.name, path)
    command = [str(LEAN), '-o', str(build / (module + '.olean')), str(path)]
    result = subprocess.run(command, cwd=source, env=environment, capture_output=True, text=True)
    (run / (module + '.stdout.log')).write_text(result.stdout)
    (run / (module + '.stderr.log')).write_text(result.stderr)
    content = path.read_bytes()
    entry = {'module': module, 'command': command, 'cwd': str(source), 'LEAN_PATH': environment['LEAN_PATH'], 'source_sha256': hashlib.sha256(content).hexdigest(), 'source_git_blob': hashlib.sha1(b'blob ' + str(len(content)).encode() + b'\0' + content).hexdigest(), 'exit_code': result.returncode}
    manifest['commands'].append(entry)
    (run / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps(entry), flush=True)
    if result.returncode:
        print(result.stdout, flush=True)
        print(result.stderr, flush=True)
        raise SystemExit(result.returncode)
print('Independent review checked: ' + str(run), flush=True)
