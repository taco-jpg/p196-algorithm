import Agent9DigitSumIntervalCounts

/-!
Independent boundary review of the exact pinned numeric statement.
This file is review evidence, outside the eleven mathematical source modules.
-/

namespace P196.Agent9.IntervalCounts.IndependentNumericReview

theorem zero_threshold_horizon :
    DecimalUniformEscape.sharpDigitSumEscapeBound 0 = 0 := rfl

/-- At threshold zero the lower bound counts every time, even when s or N is zero. -/
theorem zero_threshold_count (n : Nat) (hn : 0 < n) (s N : Nat) :
    ((List.range' s N).filter
      (fun t => decide (0 < DecimalMass.digitSum (Lychrel196.orbit n t)))).length = N := by
  apply Nat.le_antisymm
  · simpa only [List.length_range'] using
      List.length_filter_le
        (fun t => decide (0 < DecimalMass.digitSum (Lychrel196.orbit n t)))
        (List.range' s N)
  · simpa only [zero_threshold_horizon, Nat.zero_add, Nat.div_one] using
      digitSum_interval_count n hn 0 s N

theorem empty_numeric_interval (n B s : Nat) :
    ((List.range' s 0).filter
      (fun t => decide (B < DecimalMass.digitSum (Lychrel196.orbit n t)))).length = 0 := by
  simp

theorem zero_seed_orbit (t : Nat) : Lychrel196.orbit 0 t = 0 := by
  induction t with
  | zero => rfl
  | succ t ih =>
    simp [Lychrel196.orbit, ih, Lychrel196.step,
      Lychrel196.reverse10, Lychrel196.reverseFuel]

theorem zero_seed_no_excursions (s N : Nat) :
    ((List.range' s N).filter
      (fun t => decide (0 < DecimalMass.digitSum (Lychrel196.orbit 0 t)))).length = 0 := by
  simp [zero_seed_orbit, DecimalMass.digitSum_zero]

/-- Removing the positive-seed premise would make the finite bound false. -/
theorem positive_seed_premise_required :
    ¬ (1 / (DecimalUniformEscape.sharpDigitSumEscapeBound 0 + 1) ≤
      ((List.range' 0 1).filter
        (fun t => decide (0 < DecimalMass.digitSum (Lychrel196.orbit 0 t)))).length) := by
  simp [zero_threshold_horizon, zero_seed_no_excursions]

#print axioms zero_threshold_horizon
#print axioms zero_threshold_count
#print axioms empty_numeric_interval
#print axioms zero_seed_orbit
#print axioms zero_seed_no_excursions
#print axioms positive_seed_premise_required

end P196.Agent9.IntervalCounts.IndependentNumericReview
