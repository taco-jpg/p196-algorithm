#!/usr/bin/env python3
"""Read-only source/provenance preparation; never invokes the compiler."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import re
import subprocess
import traceback

review = Path(__file__).resolve().parent
package = review.parents[1]
repo = package.parents[3]
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--output', required=True, type=Path)
args = parser.parse_args()
output = args.output.resolve()
if not output.is_relative_to(review):
    raise SystemExit('Preparation output must stay inside the owned review directory.')
output.mkdir(parents=True, exist_ok=False)
(output / 'inputs').mkdir()
(output / 'logs').mkdir()

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(f'blob {len(data)}\0'.encode() + data).hexdigest()

report = {
    'reviewer': 'Agent #9/horizon-safety',
    'role': 'INDEPENDENT_REVIEWER',
    'status': 'PREPARING',
    'started_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'compiler_invocations': 0,
    'full_independent_gate': 'DEFERRED_UNTIL_COMPLETE_AUTHOR_SOURCE_FREEZE',
    'commands': [], 'snapshots': {}, 'original_dependencies': [],
}

def save():
    (output / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

def command(label, argv, required=True):
    p = subprocess.run(argv, cwd=repo, capture_output=True)
    (output / 'logs' / (label + '.stdout.log')).write_bytes(p.stdout)
    (output / 'logs' / (label + '.stderr.log')).write_bytes(p.stderr)
    report['commands'].append({
        'label': label, 'argv': argv, 'cwd': str(repo), 'exit_code': p.returncode,
        'stdout_sha256': sha(p.stdout), 'stderr_sha256': sha(p.stderr),
    })
    save()
    if required and p.returncode:
        raise RuntimeError(label + ': ' + p.stderr.decode())
    return p

try:
    expected = {
        'Agent9FiniteProducts.lean': 'b4d3b1f4b910438533186b60c0a88e946887aaa47978d730b7eedc5352a10ccf',
        'Agent9MarkerWords.lean': 'd90d48cf77ce6cc00706151f4b5b2e4b547e64b7af734397391050f28bd17a81',
        'Agent9MarkerEnumeration.lean': '285d8b085ff381c8bdc54c6bdbc2de1be59e28aa138fff8278d1c9d9fbc7704d',
    }
    names = ['CONTRACT.json', 'dependencies.json', 'Agent9FiniteProductsAudit.lean',
             'CHECKPOINT-001.md', 'compile_attempt.py', *expected]
    for name in names:
        data = (package / name).read_bytes()
        (output / 'inputs' / name).write_bytes(data)
        report['snapshots'][name] = {'sha256': sha(data), 'git_blob': blob(data), 'bytes': len(data)}
        if name in expected and sha(data) != expected[name]:
            raise RuntimeError('Announced snapshot changed; record a new version before review: ' + name)
    checkpoint = 'cf7935d24ce8180d6181de01d1050fc02b66802c'
    p = command('checkpoint-object-type', ['git', 'cat-file', '-t', checkpoint], required=False)
    report['generic_checkpoint'] = {'commit': checkpoint, 'locally_available': p.returncode == 0}
    if p.returncode == 0:
        if p.stdout.strip() != b'commit':
            raise RuntimeError('Checkpoint object is not a commit.')
        path = 'proofs/contributions/agent-9/finite-ensemble-marker-count-20261016/Agent9FiniteProducts.lean'
        data = command('checkpoint-generic-source', ['git', 'show', checkpoint + ':' + path]).stdout
        if data != (output / 'inputs/Agent9FiniteProducts.lean').read_bytes():
            raise RuntimeError('Published generic source differs from the reviewed snapshot.')
        report['generic_checkpoint']['bytes_match'] = True
    else:
        report['generic_checkpoint']['status'] = 'Local object missing; root informed, no fetch by reviewer.'
    contract = json.loads((output / 'inputs/CONTRACT.json').read_text())
    pin = contract['source']
    data = command('original-readme', ['git', 'show', pin['commit'] + ':' + pin['path']]).stdout
    if blob(data) != pin['git_blob'] or data != (package / 'source/README.original.md').read_bytes():
        raise RuntimeError('Original README source identity differs.')
    (output / 'inputs/README.original.md').write_bytes(data)
    report['source_readme'] = dict(pin, sha256=sha(data), bytes=len(data), local_copy_matches_original=True)
    for dep in json.loads((output / 'inputs/dependencies.json').read_text()):
        data = (repo / dep['current_path']).read_bytes()
        old = command(dep['module'] + '-original-source',
                      ['git', 'show', dep['source_commit'] + ':' + dep['original_path']]).stdout
        if data != old or sha(data) != dep['sha256'] or blob(data) != dep['git_blob']:
            raise RuntimeError('Original dependency identity differs: ' + dep['module'])
        imports = [x for line in re.findall(r'^\s*import\s+([^\n]+)', data.decode(), re.M) for x in line.split()]
        declarations = re.findall(r'^(?:private\s+|protected\s+)?(?:def|theorem|abbrev|opaque|axiom)\s+(\S+)', data.decode(), re.M)
        report['original_dependencies'].append(dict(dep, imports=imports, bytes=len(data),
                                                   source_declaration_count=len(declarations), original_bytes_match=True))
    registered = {d['module'] for d in report['original_dependencies']}
    for dep in report['original_dependencies']:
        if any(x not in registered and x.split('.')[0] not in {'Std', 'Lean', 'Init'} for x in dep['imports']):
            raise RuntimeError('Unregistered prospective original dependency: ' + dep['module'])
    shim = next(d for d in report['original_dependencies'] if d['module'] == 'Lychrel196Research')
    if shim['imports'] != ['LychrelDigitSums'] or shim['source_declaration_count'] != 0:
        raise RuntimeError('The claimed import-only compatibility adapter differs.')
    report['compatibility_route'] = {
        'adapter_is_unchanged_import_only_module': True,
        'adapter_may_have_zero_module_origin_declarations': True,
        'shared_decimal_definitions': True,
        'all_eleven_original_pins_match': True,
    }
    original_verifier = repo / 'proofs/contributions/agent-9/one-step-digit-sum-collapse-20261016/verify.py'
    old = original_verifier.read_bytes()
    new = old.decode().replace('CollapseAudit', 'EnsembleAudit').replace(
        'default="Agent #9/horizon-safety (author)"',
        'default="Agent #9/horizon-safety (independent reviewer)"')
    (review / 'verify.py').write_text(new)
    report['prepared_verifier'] = {
        'source_path': str(original_verifier.relative_to(repo)), 'source_sha256': sha(old),
        'owned_copy': 'review/horizon-safety/verify.py', 'owned_sha256': sha(new.encode()),
        'changes': ['Generated audit module renamed EnsembleAudit', 'Truthful independent-review auditor default'],
        'executed': False,
    }
    report['status'] = 'ORIGINAL_PROVENANCE_PREPARATION_PASS'
    report['complete_author_source_review'] = 'PENDING_NUMERIC_AND_POSITIVE_TIME_LAYERS'
except Exception as exc:
    report['status'] = 'FAILED_PREPARATION'
    report['error'] = str(exc)
    (output / 'failure.log').write_text(traceback.format_exc())
    raise
finally:
    report['finished_at_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    save()
    (output / 'prepare_review.py').write_bytes(Path(__file__).read_bytes())
    manifest = {str(f.relative_to(output)): {'sha256': sha(f.read_bytes()), 'bytes': f.stat().st_size}
                for f in sorted(output.rglob('*')) if f.is_file() and f.name != 'FILES.json'}
    (output / 'FILES.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({'status': report['status'], 'original_dependencies': len(report['original_dependencies']),
                      'compiler_invocations': 0, 'generic_checkpoint': report.get('generic_checkpoint')}, indent=2))
