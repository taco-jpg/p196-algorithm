#!/usr/bin/env python3
"""Snapshot the frozen author input and prepare the independent 16-module gate.

This script writes only this review directory.  It invokes no Lean compiler and
makes no Git mutations.  The separate verifier checks original Git provenance.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
from datetime import datetime, timezone


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def blob(data: bytes) -> str:
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()


def main() -> None:
    review = Path(__file__).resolve().parent
    contribution = review.parents[1]
    repo = contribution.parents[3]
    frozen = review / "frozen-source"
    inputs = review / "author-snapshot"
    verification = review / "verification"
    for folder in (frozen, inputs, verification):
        folder.mkdir(exist_ok=False)
    spec = importlib.util.spec_from_file_location("independent_verifier", review / "verify.py")
    verifier = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(verifier)
    freeze_data = (contribution / "AUTHOR_FREEZE.json").read_bytes()
    freeze = json.loads(freeze_data)
    assert freeze["status"] == "MATHEMATICAL_SOURCES_FROZEN"
    assert len(freeze["mathematical_modules"]) == 5
    assert len(freeze["dependencies"]) == 11
    copied = {}
    for filename in ["AUTHOR_FREEZE.json", "CONTRACT.json", "dependencies.json", "exports.json",
                     "Agent9EnsembleAudit.lean", "verify.py", "compile_attempt.py",
                     "build_dependencies.py", "CHECKPOINT-001.md", "source/README.original.md",
                     "verification/full-001/summary.json"]:
        data = (contribution / filename).read_bytes()
        destination = inputs / filename
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        copied[filename] = {"bytes": len(data), "sha256": sha(data)}
    assert copied["Agent9EnsembleAudit.lean"]["sha256"] == freeze["audit_sha256"]
    records = {}
    for dep in freeze["dependencies"]:
        data = (repo / dep["current_path"]).read_bytes()
        assert sha(data) == dep["sha256"], dep["module"]
        assert blob(data) == dep["git_blob"], dep["module"]
        code = verifier.code_only(data.decode())
        imports = [name for line in re.findall(r"^\s*import\s+([^\n]+)", code, re.M)
                   for name in line.split()]
        records[dep["module"]] = {
            "base": "repository", "path": dep["current_path"],
            "sha256": dep["sha256"], "git_blob": dep["git_blob"], "imports": imports,
            "historical_provenance": {"commit": dep["source_commit"], "path": dep["original_path"]}
        }
    endpoints = []
    extracted = {}
    for item in freeze["mathematical_modules"]:
        name = item["module"]
        data = (contribution / (name + ".lean")).read_bytes()
        assert sha(data) == item["sha256"], name
        (frozen / (name + ".lean")).write_bytes(data)
        code = verifier.code_only(data.decode())
        imports = [dep for line in re.findall(r"^\s*import\s+([^\n]+)", code, re.M)
                   for dep in line.split()]
        names = re.findall(r"^\s*(?:noncomputable\s+)?(?:def|theorem)\s+([A-Za-z_][\w]*)\b", code, re.M)
        extracted[name] = ["P196.Agent9.Ensemble." + value for value in names]
        assert extracted[name] == item["exports"], (name, extracted[name], item["exports"])
        endpoints.extend(extracted[name])
        records[name] = {"base": "package", "path": "frozen-source/" + name + ".lean",
                         "sha256": sha(data), "git_blob": blob(data), "imports": imports}
    assert len(endpoints) == len(set(endpoints)) == 100
    manifest = {
        "schema_version": 1,
        "project": "P196 finite-ensemble marker count: independent horizon-safety review",
        "scope": "Exact complete canonical numeric marker-complement count and positive-time finite-horizon upper bound; full 16-module mathematical import closure.",
        "new_modules": [item["module"] for item in freeze["mathematical_modules"]],
        "roots": ["Agent9FiniteHorizonCount"],
        "modules": records,
        "endpoints": endpoints,
        "permitted_empty_origins": freeze["permitted_empty_import"],
        "author_freeze_sha256": sha(freeze_data),
        "source_statement": freeze["source_statement"],
        "reviewer": "Agent #9/horizon-safety",
        "mathematical_author": "Agent #9/coverage_census"
    }
    registry = verification / "source-registry.json"
    registry.write_text(json.dumps(manifest, indent=2) + "\n")
    report = {
        "status": "FROZEN_GATE_PREPARED_NO_COMPILER_INVOCATION",
        "prepared_at_utc": datetime.now(timezone.utc).isoformat(),
        "invocation": [sys.executable, str(Path(__file__).resolve()), *sys.argv[1:]],
        "compiler_invocations": 0, "modules": len(records), "literal_exports": len(endpoints),
        "all_five_sources_match_author_freeze": True,
        "independently_extracted_exports_match_freeze": True,
        "extracted_exports": extracted, "author_snapshot": copied,
        "source_registry_sha256": sha(registry.read_bytes()),
        "checker_sha256": sha((review / "verify.py").read_bytes()),
        "preparation_script_sha256": sha(Path(__file__).read_bytes())
    }
    (verification / "frozen-preparation.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps({key: report[key] for key in ["status", "modules", "literal_exports", "source_registry_sha256", "checker_sha256"]}, indent=2))


if __name__ == "__main__":
    main()
