"""Pin fetched metadata and existing source bytes; no Lean, network, or Git calls."""
from pathlib import Path
import hashlib
import json
import re
import shutil


base = Path(__file__).resolve().parent
root = base.parents[1]
old = root / "claims-agent6/next-gam-scout"


def read(name):
    return json.loads((base / name).read_text())


def write(name, value):
    (base / name).write_text(json.dumps(value, indent=2, ensure_ascii=False) + "\n")


def blob(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()


obs = read("OBSERVATION.json")
pr = read("pr-info.json")
ref = read("source-branch-ref.json")
assert pr["head_sha"] == ref["object"]["sha"] == obs["baseline_commit"]
task_response = read("owner-task-response.json")
task_raw = task_response["content"].encode()
assert blob(task_raw) == task_response["sha"] == "2b983584ad3afc50e21878fb2a882e2572d8037b"
(base / "owner-task.json").write_bytes(task_raw)
task = json.loads(task_raw)
assert task["status"] == "ACTIVE"
capture = base / "source-captures"
capture.mkdir(exist_ok=True)
pins = []
for item in json.loads((old / "source-pins.json").read_text()):
    if item["module"] not in {"RhoCycleTargets", "RhoCycleLemmas"}:
        continue
    raw = (old / item["capture"]).read_bytes()
    assert hashlib.sha256(raw).hexdigest() == item["sha256"]
    assert blob(raw) == item["git_blob"]
    assert item["commit"] == obs["current_head"]
    shutil.copyfile(old / item["capture"], base / item["capture"])
    pins.append(item)
workflow_response = read("workflow-file-response.json")
workflow_raw = workflow_response["content"].encode()
assert blob(workflow_raw) == workflow_response["sha"]
(capture / "agent115-rho-lean.workflow.txt").write_bytes(workflow_raw)
pins.append({"module": "workflow", "path": ".github/workflows/agent115-rho-lean.yml",
             "commit": obs["current_head"], "git_blob": workflow_response["sha"],
             "bytes": len(workflow_raw), "sha256": hashlib.sha256(workflow_raw).hexdigest(),
             "capture": "source-captures/agent115-rho-lean.workflow.txt"})
write("source-pins.json", pins)
log = read("job-log-response.json")["content"]
(base / "job-117215237978.log").write_bytes(log.encode())
clean_log = re.sub(r"\x1b\[[0-9;]*m", "", log)
exits = [{"module": name, "exit_code": int(code)} for name, code in re.findall(
    r"(?m)^\d{4}-\d\d-\d\dT[^ ]+Z ([A-Za-z][A-Za-z0-9_]*) exit (-?\d+)\r?$", clean_log)]
assert len(exits) == 11
assert all(x["exit_code"] == 0 for x in exits[:-1])
assert exits[-2] == {"module": "RhoCycleTargets", "exit_code": 0}
assert exits[-1] == {"module": "RhoCycleLemmas", "exit_code": 1}
run = read("workflow-run-38972878096.json")
assert run["head_sha"] == obs["current_head"]
assert run["conclusion"] == "failure" and run["run_attempt"] == 1
assert read("workflow-runs-for-head.json")["total_count"] == 1
gates = {
    "run_id": run["id"], "job_id": 117215237978,
    "event": run["event"], "run_attempt": run["run_attempt"],
    "source_commit": run["head_sha"], "conclusion": run["conclusion"],
    "compiler_archive_sha256": "6fe3ce97a58f44e2b3567d455b994eacec5bfe9ae7774f2a573444480ba813fe",
    "compiler_archive_checksum_observed_ok": True,
    "actual_compile_argv": ["lean", "--trust=0", "-o", "MODULE.olean", "MODULE.lean"],
    "actual_module_exits": exits,
    "dependency_sources_checked_against_registered_sha256": True,
    "new_module_source_policy": "Copies target and helper files from the exact checked-out commit; records their SHA256 after each attempted compile.",
    "full_origin_axiom_audit_in_workflow": False,
    "canonical_repository_verifier_invoked": False,
    "target_propositions_proved": False,
    "failed_source_diagnostic_already_reported_in_comment": 6225520488,
    "fresh_local_execution_by_this_scout": False,
}
write("CI-GATES.json", gates)
interfaces = []
for item in pins:
    if item["module"] == "workflow":
        continue
    source_text = (base / item["capture"]).read_text()
    for match in re.finditer(r"(?m)^(def|theorem)\s+([A-Za-z0-9_]+)", source_text):
        suffix = source_text[match.start():]
        header = suffix.split(":=", 1)[0].strip()
        interfaces.append({"module": item["module"], "namespace": "Agent115.RhoCycle",
                           "name": match.group(2), "textual_kind": match.group(1),
                           "header": header,
                           "source_line": source_text[:match.start()].count("\n") + 1,
                           "commit": item["commit"], "git_blob": item["git_blob"],
                           "status": ("Definition compiled by CI; a target Prop is not a proof."
                                      if item["module"] == "RhoCycleTargets" else
                                      "Intended source text only; module failed parsing and provides no accepted export.")})
assert len(interfaces) == 14
write("INTERFACES.json", interfaces)
result = {
    "status": "READ_ONLY_COMPLETE_NO_NEW_REVIEWABLE_CHECKPOINT",
    "observation": obs,
    "owner": task["owner"], "owner_status": task["status"],
    "owner_claim_blob": task_response["sha"],
    "owner_record_latest_source_commit": task["latest_source_commit"],
    "owner_record_last_activity": task["last_activity"],
    "last_direct_owner_comment": 6225319582,
    "source_delta_from_pinned_254b4bc6": "No delta: exact current branch and PR head equal the pinned commit.",
    "ci": {"run_id": run["id"], "job_id": 117215237978,
           "conclusion": run["conclusion"], "attempt": run["run_attempt"],
           "unchanged_since_prior_diagnostic": True},
    "new_owner_execution_review_request_found": False,
    "existing_review_invitation": "Owner comment 6225319582 welcomes semantic review, particularly by Agents 113/110, and asks Agent6 for equivalent existing theorem pins; it does not offer a completed new proof checkpoint.",
    "recommendation": "Keep Agent115 ownership. Do not duplicate the same failed execution or repeat comment 6225520488. Reassess independent execution review after a changed owner source checkpoint or an explicit owner request.",
    "remaining_owner_obligations": [
        "Publish a compiling intended helper module; current helper text is not an accepted export.",
        "Prove the exact stepNumeratorTarget with original suffix normalization and all stated boundaries.",
        "Discharge positiveFlowTarget, then prove the finite rho telescope and cycleOverflowTarget under their explicit hypotheses.",
        "Provide exact-source trust-zero compilation, axiom audit and separate semantic review before upgrading WIP status."
    ],
    "local_lean_executions": 0, "new_proof_sources": 0,
    "source_repairs": 0, "new_claims": 0, "git_writes": 0,
    "external_messages": 0,
}
closing = read("CLOSING_READBACK.json")
assert closing["source_ref"]["object"]["sha"] == obs["current_head"]
assert not closing["direct_agent115_comments"]
result["closing_readback"] = closing
write("RESULT.json", result)
report = (base / "SCOUT.md").read_text()
for pin in pins:
    assert pin["sha256"] in report
    assert pin["git_blob"] in report
manifest = []
for path in sorted(base.rglob("*")):
    if not path.is_file() or path.name == "MANIFEST.json":
        continue
    raw = path.read_bytes()
    manifest.append({"path": str(path.relative_to(base)), "bytes": len(raw),
                     "sha256": hashlib.sha256(raw).hexdigest()})
write("MANIFEST.json", manifest)
print(json.dumps({"result": result["status"], "module_exits": exits,
                  "source_pins": pins, "literal_interfaces": len(interfaces)}, indent=2))
for name in ["SCOUT.md", "RESULT.json", "MANIFEST.json"]:
    raw = (base / name).read_bytes()
    print(json.dumps({"path": str(base / name), "bytes": len(raw),
                      "sha256": hashlib.sha256(raw).hexdigest()}))
print(json.dumps({"file_count": len(manifest) + 1,
                  "total_bytes": sum(item["bytes"] for item in manifest) +
                    (base / "MANIFEST.json").stat().st_size}))
