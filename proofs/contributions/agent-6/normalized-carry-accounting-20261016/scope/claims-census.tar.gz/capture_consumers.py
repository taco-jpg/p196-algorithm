"""Read the two frozen PR115 consumers needed for the refined interface census."""
from pathlib import Path
import hashlib
import json
import re
import urllib.request

scratch = Path(__file__).resolve().parent
records = json.loads((scratch / "source-pins.json").read_text())
commit = "937c33ba3a98b9778bfee45a0bf2f0c0b3765055"
items = [
    ("CoordinateCycle", "proofs/contributions/agent-6/exterior-coordinate-dynamics-20261016/CoordinateCycle.lean"),
    ("CertificateCoordinates", "proofs/contributions/agent-6/certificate-coordinate-audit-20261016/CertificateCoordinates.lean"),
]
for module, path in items:
    assert all(record["module"] != module for record in records)
    url = "https://raw.githubusercontent.com/taco-jpg/p196-algorithm/" + commit + "/" + path
    request = urllib.request.Request(url, headers={"User-Agent": "Agent6-read-only-source-census"})
    with urllib.request.urlopen(request, timeout=45) as response:
        raw = response.read()
    destination = scratch / "source-captures" / (module + ".source.txt")
    destination.write_bytes(raw)
    record = {"module": module, "path": path, "commit": commit,
              "git_blob": hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest(),
              "bytes": len(raw), "sha256": hashlib.sha256(raw).hexdigest(),
              "imports": re.findall(r"(?m)^import (\S+)", raw.decode()),
              "url": url, "capture": str(destination.relative_to(scratch))}
    records.append(record)
    print(json.dumps(record))
(scratch / "source-pins.json").write_text(json.dumps(records, indent=2) + "\n")
