"""Build source-interface metadata only; no Lean compiler or proof authoring."""
from pathlib import Path
import hashlib
import json
import re

scratch = Path(__file__).resolve().parent
workspace = scratch.parents[1]
pins = json.loads((scratch / "source-pins.json").read_text())
pin_by_module = {entry["module"]: entry for entry in pins}
selected = {
    "TemplateStep": ("Agent109", ["norm", "norm_append", "Bounded", "norm_carry_le", "kOf", "tOf", "Phase", "norm_band_tail", "data", "gamma_le"]),
    "ReturnCertificate": ("Agent109.Cert", ["State", "gam", "LocalOK", "Valid", "check_sound"]),
    "OuterBridge": ("Agent109.Outer", ["normalize7_eq", "kOf_eq", "stripSuffix_spec"]),
    "ExteriorCharge": ("Agent2Exterior", ["overflow"]),
    "CertificateCharge": ("Agent110.CertificateBudget", ["norm_eq_normalize", "kOf_eq_div", "gam_eq_overflow"]),
    "ExteriorNormalization": ("Agent116.Exterior", ["Br_append_phase", "Br_append_replicate", "outerNext_stripSuffix_eq"]),
    "CertificateExterior": ("Agent116.CertificateExterior", ["stateOuter", "local_outer_step"]),
    "ExteriorFactorizationProof": ("Agent115.ExteriorFactorization", ["rhoNum_append_replicate"]),
    "CoordinateThreshold": ("Agent6.ExteriorCoordinates", ["overflow", "overflow_eq_highValue", "overflow_le_one", "overflow_eq_rho_quotient", "overflow_eq_zero_iff", "overflow_eq_one_iff"]),
    "CoordinateCycle": ("Agent6.ExteriorCoordinates", ["overflowBit", "overflowCount", "weightedPhase", "weightedReverse", "closed_orbit_weighted_balance"]),
    "CertificateAccounting": ("Agent110.Accounting", ["sumPrefix", "totalGam", "sumPrefix_congr", "totalGam_eq_twice_gains"]),
    "CertificateCoordinates": ("Agent6.CertificateCoordinates", ["rowOuter", "rowSum_eq_orbitSum", "checked_row_weighted_balance"]),
    "RhoCycleLemmas": ("Agent115.RhoCycle", ["gamma_eq_overflow", "gamma_le_one"]),
}
declarations = []
for module, (namespace, names) in selected.items():
    pin = pin_by_module[module]
    path = scratch / pin["capture"]
    raw = path.read_bytes()
    assert hashlib.sha256(raw).hexdigest() == pin["sha256"]
    text = raw.decode()
    for name in names:
        match = re.search(r"(?m)^(?:@\[[^\n]*\]\s*)?(?:(?:private|protected)\s+)?(theorem|lemma|def|structure)\s+" + re.escape(name) + r"\b", text)
        assert match, (module, name)
        remainder = text[match.start():]
        if match.group(1) in ["theorem", "lemma"]:
            statement = remainder.split(":=", 1)[0].rstrip()
        else:
            boundaries = [m.start() for m in re.finditer(
                r"\n(?=(?:private )?(?:def|theorem|lemma|structure|instance)\s|end\s|#print|@\[)|\n\n(?=/--|/-!)", remainder)]
            statement = remainder[:min(boundaries) if boundaries else len(remainder)].rstrip()
        declarations.append({"name": namespace + "." + name, "kind": match.group(1),
                             "module": module, "commit": pin["commit"],
                             "path": pin["path"], "git_blob": pin["git_blob"],
                             "source_line": text.count("\n", 0, match.start()) + 1,
                             "literal_source_statement": statement})
(scratch / "INTERFACES.json").write_text(json.dumps(declarations, indent=2, ensure_ascii=False) + "\n")

baseline = json.loads((workspace / "runtime-agent6/review-certificate/baseline/source-manifest.json").read_text())
modules = {entry["module"]: entry for entry in baseline["modules"]}
modules.update(pin_by_module)
def closure(roots):
    seen = set()
    order = []
    def visit(module):
        if module in seen or module in ["Std", "Lean", "Init"]:
            return
        seen.add(module)
        assert module in modules, module
        for dependency in modules[module]["imports"]:
            visit(dependency)
        order.append(module)
    for module in roots:
        visit(module)
    return order
closures = {
    "raw_normalization_or_structural_padding_interface": closure(["OuterBridge", "CoordinateThreshold"]),
    "existing_stateOuter_and_overflowBit_interface": closure(["CertificateExterior", "CoordinateCycle"]),
    "existing_checked_weighted_balance_consumer": closure(["CertificateCoordinates"]),
}
assert [len(v) for v in closures.values()] == [8, 16, 18]
(scratch / "dependency-closures.json").write_text(json.dumps(closures, indent=2) + "\n")

tree = json.loads((scratch / "coordination-tree.json").read_text())
tree_blobs = {entry["path"]: entry["sha"] for entry in tree["tree"] if entry["type"] == "blob"}
claim_records = []
for path in sorted((scratch / "claims").glob("*.json")):
    raw = path.read_bytes()
    blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
    remote_path = "proofs/coordination/tasks/" + path.name
    assert tree_blobs[remote_path] == blob
    claim_records.append({"path": remote_path, "git_blob": blob,
                          "sha256": hashlib.sha256(raw).hexdigest(), "task": json.loads(raw)})
(scratch / "all-inspected-claims.json").write_text(json.dumps(claim_records, indent=2, ensure_ascii=False) + "\n")

candidates = {
    "status": "SOURCE-DESIGN ONLY; NO CLAIM, LEAN SOURCE, PROOF EXECUTION, OR THEOREM ASSERTION",
    "structural_phase_bound": "For every c : Nat and B : List Nat, c ≤ 18 implies overflow c (stripSuffix c B) = overflow c B. Coefficients may be unbounded.",
    "structural_coefficient_bound": "For every c : Nat and B : List Nat, Agent109.Bounded B implies overflow c (stripSuffix c B) = overflow c B. The phase may be arbitrary.",
    "state_indicator": "For every s : Agent109.Cert.State, Agent109.Bounded s.B implies overflowBit (Agent116.CertificateExterior.stateOuter s) = Agent109.Cert.gam s.",
    "checked_row_indicator": "check cert = true and i < cert.P imply overflowBit (rowOuter cert i) = gam (cert.st i).",
    "bounded_candidate_sum": "For any certificate whose listed raw B words are bounded, sumPrefix (fun i => (overflowBit (rowOuter cert i) : Int)) cert.P = totalGam cert; no acceptance or phase premise is needed. This includes the empty sum.",
    "checked_sum": "check cert = true implies sumPrefix (fun i => (overflowBit (rowOuter cert i) : Int)) cert.P = totalGam cert.",
    "checked_weighted_balance": "check cert = true implies sumPrefix (fun i => weightedPhase (rowOuter cert i)) cert.P = 9 * sumPrefix (fun i => weightedReverse (rowOuter cert i)) cert.P + 9 * totalGam cert.",
    "optional_gain_balance": "The previous final term may be rewritten to 18 * (totalG cert + totalH cert) using existing Agent110.Accounting.totalGam_eq_twice_gains.",
    "expected_structural_boundary": "c=19, B=[19]: raw overflow=2, trimmed overflow=1. This is a source-definition calculation, not a newly kernel-checked control.",
    "expected_indicator_boundary": "c=2, B=[20]: normalized overflowBit=1, raw gam=2. This is a source-definition calculation, not a newly kernel-checked control.",
    "expected_allowed_boundaries": "c=18, B=[18] strips to [] and both carries remain 1; c=9, B=[9] strips to [] and both carries remain 0. These are source-definition calculations, not newly kernel-checked controls.",
}
(scratch / "UNPROVED_TARGETS.json").write_text(json.dumps(candidates, indent=2, ensure_ascii=False) + "\n")
print(json.dumps({"literal_existing_declarations": len(declarations),
                  "source_captures": len(pins), "inspected_claims": len(claim_records),
                  "dependency_module_counts": {k: len(v) for k, v in closures.items()},
                  "new_lean_proof_work": False}, indent=2))
