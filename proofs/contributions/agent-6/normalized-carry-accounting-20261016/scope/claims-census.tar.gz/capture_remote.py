"""Read public GitHub refs and relevant claim blobs; never mutate Git state."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import base64
import hashlib
import json
import urllib.request
from datetime import datetime, timezone

root = Path(__file__).resolve().parent
api = "https://api.github.com/repos/taco-jpg/p196-algorithm"

def get_json(path):
    request = urllib.request.Request(api + path, headers={
        "Accept": "application/vnd.github+json", "User-Agent": "Agent6-read-only-source-census"})
    with urllib.request.urlopen(request, timeout=45) as response:
        return json.load(response)

with ThreadPoolExecutor(max_workers=2) as pool:
    coord_ref, main_ref = list(pool.map(get_json, [
        "/git/ref/heads/p196/coordination", "/git/ref/heads/main"]))
coord_head = coord_ref["object"]["sha"]
main_head = main_ref["object"]["sha"]
tree = get_json("/git/trees/" + coord_head + "?recursive=1")
assert not tree.get("truncated")
(root / "coordination-tree.json").write_text(json.dumps(tree, indent=2) + "\n")
tasks = [entry for entry in tree["tree"] if entry["type"] == "blob"
         and entry["path"].startswith("proofs/coordination/tasks/")]
relevant = [entry for entry in tasks if any(
    entry["path"].rsplit("/", 1)[-1].startswith(prefix)
    for prefix in ["agent109-", "agent110-", "agent115-", "agent116-", "agent6-"])]
(root / "claims").mkdir(exist_ok=True)

def save_claim(entry):
    payload = get_json("/git/blobs/" + entry["sha"])
    data = base64.b64decode(payload["content"])
    blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
    assert blob == entry["sha"]
    destination = root / "claims" / entry["path"].rsplit("/", 1)[-1]
    destination.write_bytes(data)
    body = json.loads(data)
    return {"path": entry["path"], "blob": blob, "bytes": len(data),
            "sha256": hashlib.sha256(data).hexdigest(), "task": body}

with ThreadPoolExecutor(max_workers=3) as pool:
    claims = list(pool.map(save_claim, relevant))
record = {"observed_at_utc": datetime.now(timezone.utc).isoformat(),
          "repository": "taco-jpg/p196-algorithm",
          "coordination_head": coord_head, "main_head": main_head,
          "all_task_count": len(tasks), "relevant_claims": claims,
          "selection": "task basenames beginning agent109-, agent110-, agent115-, agent116-, or agent6-"}
(root / "current-claims.json").write_text(json.dumps(record, indent=2) + "\n")
print(json.dumps({k: v for k, v in record.items() if k != "relevant_claims"}, indent=2))
for claim in claims:
    print(json.dumps({"path": claim["path"], "blob": claim["blob"],
                      "status": claim["task"].get("status"),
                      "scope": claim["task"].get("scope")}, ensure_ascii=False))
