"""Preserve read-only interface-source captures at explicit commit pins."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib
import json
import re
import urllib.request

scratch = Path(__file__).resolve().parent
workspace = scratch.parents[1]
claims = json.loads((scratch / "current-claims.json").read_text())
source_map = json.loads((workspace / "agent6-checker/proofs/SOURCE_MAP.json").read_text())
main = claims["main_head"]
items = [
    ("TemplateStep", "proofs/TemplateStep__8873883b39064515.lean"),
    ("ReturnCertificate", "proofs/ReturnCertificate__b037c18e81a43bb5.lean"),
    ("OuterFinite", "proofs/OuterFinite__1c852c0ed5b8d706.lean"),
    ("OuterBounds", "proofs/OuterBounds__4503f58658495015.lean"),
    ("OuterBridge", "proofs/OuterBridge__04b27506596f5de1.lean"),
    ("TARGET", "proofs/TARGET__c7bc3cfee999c64e.lean"),
    ("ExteriorFactorizationProof", "proofs/ExteriorFactorizationProof__c2d8a9a4ee47c405.lean"),
    ("ExteriorNormalization", "proofs/ExteriorNormalization__e03ef2b2c3a7fcaa.lean"),
    ("CertificateExterior", "proofs/CertificateExterior__94efd9fc73b36162.lean"),
    ("CertificateCharge", "proofs/CertificateCharge__46feaa8077e59426.lean"),
    ("ExteriorCharge", "proofs/ExteriorCharge__52cbb237030a07b3.lean"),
    ("CertificateAccounting", "proofs/CertificateAccounting__ad0d1bd9b0242036.lean"),
]
requests = [{"module": module, "path": path, "commit": main} for module, path in items]
requests += [
    {"module": "CoordinateThreshold", "path": "proofs/contributions/agent-6/exterior-coordinate-dynamics-20261016/CoordinateThreshold.lean",
     "commit": "937c33ba3a98b9778bfee45a0bf2f0c0b3765055"},
    {"module": "RhoCycleTargets", "path": "proofs/contributions/agent-115/rho-cycle-balance-20261016/development/RhoCycleTargets.lean",
     "commit": "254b4bc6b545aa9dd027c7bb46e7c4022b5d2f27"},
    {"module": "RhoCycleLemmas", "path": "proofs/contributions/agent-115/rho-cycle-balance-20261016/development/RhoCycleLemmas.lean",
     "commit": "254b4bc6b545aa9dd027c7bb46e7c4022b5d2f27"},
]
(scratch / "source-captures").mkdir(exist_ok=True)

def capture(item):
    url = "https://raw.githubusercontent.com/taco-jpg/p196-algorithm/" + item["commit"] + "/" + item["path"]
    request = urllib.request.Request(url, headers={"User-Agent": "Agent6-read-only-source-census"})
    with urllib.request.urlopen(request, timeout=45) as response:
        raw = response.read()
    blob = hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()
    destination = scratch / "source-captures" / (item["module"] + ".source.txt")
    destination.write_bytes(raw)
    record = dict(item, git_blob=blob, bytes=len(raw), sha256=hashlib.sha256(raw).hexdigest(),
                  url=url, capture=str(destination.relative_to(scratch)),
                  imports=re.findall(r"(?m)^import (\S+)", raw.decode()))
    origins = [{"path": path, "source_commit": source_map["base"], **mapping}
               for path, mapping in source_map["paths"].items()
               if mapping.get("current") == item["path"]]
    if origins:
        record["historical_source_map"] = origins
        record["matches_historical_blob"] = any(origin["oid"] == blob for origin in origins)
    local = workspace / "agent6-checker" / item["path"]
    if local.is_file():
        record["matches_local_published_checkpoint"] = local.read_bytes() == raw
    return record

with ThreadPoolExecutor(max_workers=3) as pool:
    records = list(pool.map(capture, requests))
(scratch / "source-pins.json").write_text(json.dumps(records, indent=2) + "\n")
for record in records:
    print(json.dumps({k: record[k] for k in ["module", "commit", "path", "git_blob", "bytes", "sha256", "imports"]}))
