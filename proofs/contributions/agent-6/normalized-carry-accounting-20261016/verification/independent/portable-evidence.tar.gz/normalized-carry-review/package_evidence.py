#!/usr/bin/env python3
"""Package the completed review without executing Lean or modifying sources."""

from __future__ import annotations

import gzip
import hashlib
import io
import json
import os
from pathlib import Path
import stat
import tarfile


ROOT = Path(__file__).resolve().parent
DEST = ROOT / "evidence-package"
ARCHIVE_NAME = "portable-evidence.tar.gz"
ARCHIVE_ROOT = "normalized-carry-review"
MANIFEST_NAME = "PORTABLE_MANIFEST.json"
COMPILED_SUFFIXES = {".olean", ".ilean", ".pyc", ".pyo", ".o", ".a", ".so", ".dll", ".dylib"}
READABLE = {
    "REVIEW_RESULT.json": "REVIEW_RESULT.json",
    "FORMAL_REVIEW.md": "FORMAL_REVIEW.md",
    "verification.json": "final/audit/verification.json",
    "binding.json": "final/publication/binding-affa037-final.json",
    "SEMANTIC_REVIEW.md": "final/SEMANTIC_REVIEW.md",
    "RECOVER.md": "RECOVER.md",
    "verify_package.py": "verify_package.py",
}


def hashes(data: bytes) -> dict:
    return {
        "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest(),
        "git_blob_sha1": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest(),
    }


def file_record(path: Path, data: bytes) -> dict:
    info = path.stat()
    return {
        "original_absolute_path": str(path),
        "relative_path": path.relative_to(ROOT).as_posix(),
        **hashes(data),
        "original_mode_octal": oct(stat.S_IMODE(info.st_mode)),
        "original_mtime_ns": info.st_mtime_ns,
    }


def write_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + ".tmp")
    temporary.write_bytes(data)
    os.replace(temporary, path)


def main() -> None:
    DEST.mkdir(exist_ok=True)
    result = json.loads((ROOT / "REVIEW_RESULT.json").read_text())
    if result["status"] != "PASS_INDEPENDENT_FRESH_BUILD_AXIOM_ORIGIN_SEMANTIC_AND_REMOTE_BINDING":
        raise RuntimeError("Refusing to package a review without its accepted PASS result")
    for record in result["evidence_references"].values():
        data = (ROOT / record["path"]).read_bytes()
        if len(data) != record["bytes"] or hashlib.sha256(data).hexdigest() != record["sha256"]:
            raise RuntimeError(f"Review-result reference changed: {record['path']}")

    included = []
    excluded = []
    snapshots = {}
    for path in sorted(ROOT.rglob("*")):
        if path == DEST or DEST in path.parents:
            continue
        if path.is_symlink():
            raise RuntimeError(f"Unexpected symbolic link in evidence: {path}")
        if path.is_dir():
            continue
        if not path.is_file():
            raise RuntimeError(f"Unexpected nonregular evidence entry: {path}")
        data = path.read_bytes()
        record = file_record(path, data)
        if path.suffix in COMPILED_SUFFIXES or "__pycache__" in path.parts:
            record["reason"] = "Compiled product or interpreter cache; omitted from portable evidence, original bytes and hashes retained here."
            excluded.append(record)
            continue
        record["archive_member"] = f"{ARCHIVE_ROOT}/{record['relative_path']}"
        included.append(record)
        snapshots[record["relative_path"]] = data

    archive_path = DEST / ARCHIVE_NAME
    temporary_archive = DEST / (ARCHIVE_NAME + ".tmp")
    with temporary_archive.open("wb") as raw:
        with gzip.GzipFile(filename="", mode="wb", fileobj=raw, compresslevel=9, mtime=0) as compressed:
            with tarfile.open(fileobj=compressed, mode="w", format=tarfile.PAX_FORMAT) as archive:
                for record in included:
                    data = snapshots[record["relative_path"]]
                    info = tarfile.TarInfo(record["archive_member"])
                    info.size = len(data)
                    info.mode = int(record["original_mode_octal"], 8)
                    info.mtime = 0
                    info.uid = info.gid = 0
                    info.uname = info.gname = ""
                    archive.addfile(info, io.BytesIO(data))
    os.replace(temporary_archive, archive_path)

    # Verify every stored member, including exact coverage and absence of links.
    with tarfile.open(archive_path, "r:gz") as archive:
        members = archive.getmembers()
        if [m.name for m in members] != [r["archive_member"] for r in included]:
            raise RuntimeError("Archive member inventory differs from original snapshot")
        for member, record in zip(members, included):
            if not member.isfile():
                raise RuntimeError(f"Nonregular archive member: {member.name}")
            stream = archive.extractfile(member)
            if stream is None:
                raise RuntimeError(f"Unreadable archive member: {member.name}")
            data = stream.read()
            if hashes(data) != {key: record[key] for key in ("bytes", "sha256", "git_blob_sha1")}:
                raise RuntimeError(f"Archive bytes differ: {member.name}")

    # Packaging must not change any original included or excluded file.
    for record in included + excluded:
        data = Path(record["original_absolute_path"]).read_bytes()
        if hashes(data) != {key: record[key] for key in ("bytes", "sha256", "git_blob_sha1")}:
            raise RuntimeError(f"Original evidence changed during packaging: {record['relative_path']}")

    readable = []
    for name, source in READABLE.items():
        data = snapshots[source]
        write_bytes(DEST / name, data)
        readable.append({
            "file": name,
            "original_absolute_path": str(ROOT / source),
            "original_relative_path": source,
            "archive_member": f"{ARCHIVE_ROOT}/{source}",
            **hashes(data),
            "copy_is_byte_identical": (DEST / name).read_bytes() == data,
        })

    archive_record = {"file": ARCHIVE_NAME, **hashes(archive_path.read_bytes())}
    manifest = {
        "schema": "agent6.portable-independent-review.v1",
        "status": "PASS_LOSSLESS_MEMBER_AND_ORIGINAL_BYTE_VERIFICATION",
        "scope": "Completed normalized-carry/accounting independent review; packaging only, no new Lean execution.",
        "source_review_root": str(ROOT),
        "actual_remote_source_commit": result["actual_remote_source_commit"],
        "archive": archive_record,
        "archive_root": ARCHIVE_ROOT,
        "included_file_count": len(included),
        "included_original_byte_total": sum(r["bytes"] for r in included),
        "excluded_file_count": len(excluded),
        "excluded_original_byte_total": sum(r["bytes"] for r in excluded),
        "selected_original_files_unchanged_after_packaging": True,
        "excluded_original_files_unchanged_after_packaging": True,
        "every_archive_member_bytes_and_hashes_match_original": True,
        "archive_has_exact_selected_file_inventory": True,
        "archive_metadata_policy": "File bytes and modes are retained. Archive mtime, owner names and IDs are normalized; original mtime_ns and mode are recorded for every file below.",
        "excluded_scope_policy": "Only compiled products or interpreter caches within the review root are excluded. The generated evidence-package directory is outside the original evidence selection to prevent recursion.",
        "external_runtime_policy": "The Lean runtime binaries are not bundled. The exact runtime recovery receipt, official archive hash, original smoke source/log, compiler hashes, and commands are retained. Older source paths in that historical runtime receipt are not the present source binding.",
        "recovery_command": f"tar -xzf {ARCHIVE_NAME}",
        "verification_command": "python3 verify_package.py",
        "included": included,
        "excluded": excluded,
        "readable_copies": readable,
        "publication_files_without_this_manifest": [archive_record] + [
            {key: record[key] for key in ("file", "bytes", "sha256", "git_blob_sha1")}
            for record in readable
        ],
        "manifest_self_hash_policy": "This manifest is external to the archive and has no recursive self-hash; its stored hash is supplied with the publication handoff.",
    }
    manifest_path = DEST / MANIFEST_NAME
    write_bytes(manifest_path, (json.dumps(manifest, indent=2, ensure_ascii=False) + "\n").encode())

    files = [
        {"file": p.name, **hashes(p.read_bytes())}
        for p in sorted(DEST.iterdir()) if p.is_file()
    ]
    print(json.dumps({
        "status": manifest["status"],
        "package_root": str(DEST),
        "included_files": len(included),
        "included_bytes": manifest["included_original_byte_total"],
        "excluded_files": len(excluded),
        "excluded_bytes": manifest["excluded_original_byte_total"],
        "publication_files": files,
    }, indent=2))


if __name__ == "__main__":
    main()
