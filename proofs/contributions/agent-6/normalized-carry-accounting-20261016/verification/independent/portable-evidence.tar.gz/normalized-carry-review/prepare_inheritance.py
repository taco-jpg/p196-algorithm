#!/usr/bin/env python3
"""Stage the exact inherited source/object subset without running Lean or Git.

Inherited objects are for author iteration only. The final independent review
uses compile_exact.py to create an entirely fresh 21-module object directory.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import re
import shutil
import sys
import time

HERE = Path(__file__).resolve().parent
RUNTIME = HERE.parent
WORKSPACE = RUNTIME.parent
PRIOR = RUNTIME / "review-certificate"
PRIOR_FINAL = PRIOR / "final"
WORKTREE = WORKSPACE / "agent6-carry"
PINNED_COMMIT = "937c33ba3a98b9778bfee45a0bf2f0c0b3765055"
CLAIM = "1bd2354c2447febf38df9b69fb670e988abfc72a"
PINS = {
    "source-manifest.json": "55f68ce9d0714e76e4d5ce7ccd12be1157b0d7fd02dae2751763e858e342bcbb",
    "build/compilation.json": "b88b93965f09e372964cdb40561f21c3477fb2c0445673dc2eac17e11a0897b2",
    "audit/verification.json": "7379d30f1ae0f22e4604ea78410745ab70ced84e13ea4cdccf97ab1f330525dd",
    "publication/binding-937c33ba.json": "54d7f67fa7949d4c6388bcfdbb688c18c25f1d4d3e5bee15704b131883183633",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, data: object) -> None:
    with path.open("x") as f:
        json.dump(data, f, indent=2)
        f.write("\n")


def main() -> None:
    for relative, expected in PINS.items():
        if sha(PRIOR_FINAL / relative) != expected:
            raise ValueError("Previously reviewed receipt changed: " + relative)
    manifest = json.loads((PRIOR_FINAL / "source-manifest.json").read_text())
    compilation = json.loads((PRIOR_FINAL / "build/compilation.json").read_text())
    audit = json.loads((PRIOR_FINAL / "audit/verification.json").read_text())
    binding = json.loads((PRIOR_FINAL / "publication/binding-937c33ba.json").read_text())
    assert audit["status"] == "PASS"
    assert compilation["status"] == "COMPILED_PENDING_INDEPENDENT_AXIOM_AUDIT"
    assert binding["status"] == "PASS_EXACT_REMOTE_SOURCE_BOUND"
    assert binding["actual_remote_source_commit"] == PINNED_COMMIT
    modules = {r["module"]: r for r in manifest["modules"]}
    bound = {r["module_or_document"]: r for r in binding["files"]}
    external = set(manifest["external_modules"])
    selected: set[str] = set()

    def visit(name: str) -> None:
        if name in external or name in selected:
            return
        if name not in modules:
            raise ValueError("Unknown project import: " + name)
        selected.add(name)
        for dependency in modules[name]["imports"]:
            visit(dependency)

    visit("CertificateCoordinates")
    order = [name for name in manifest["build_order"] if name in selected]
    assert len(order) == len(selected) == 18
    assert set(modules) - selected == {"CertificateFilter", "CertificateControls"}
    parser_path = Path(compilation["source_parser"]["path"])
    assert sha(parser_path) == compilation["source_parser"]["sha256"]
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location("pinned_inheritance_parser", parser_path)
    assert spec and spec.loader
    parser = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(parser)
    checked = set(external)
    prepared = []
    for name in order:
        old = modules[name]
        remote = bound[name]
        snapshot = PRIOR_FINAL / "source" / (name + ".lean")
        live = WORKTREE / remote["repository_path"]
        data = snapshot.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        assert digest == old["sha256"] == remote["sha256"]
        assert blob == old["git_blob"] == remote["git_blob"] == remote["api_git_blob"]
        assert live.read_bytes() == data
        code = parser.code_only(data.decode())
        imports = [word for line in re.findall(r"^\s*import\s+([^\n]+)", code, re.M)
                   for word in line.split()]
        assert imports == old["imports"] and set(imports) <= checked
        checked.add(name)
        old_object = compilation["objects"][name]
        object_path = Path(old_object["path"])
        assert sha(object_path) == old_object["sha256"]
        prepared.append({
            "module": name, "path": str(live),
            "repository_path": remote["repository_path"],
            "source_commit": PINNED_COMMIT, "original_source_commit": old["source_commit"],
            "original_path": old["original_path"],
            "sha256": digest, "git_blob": blob, "bytes": len(data), "imports": imports,
            "snapshot": "source/" + name + ".lean",
            "inherited_source": str(snapshot),
            "inherited_object": old_object,
        })

    base = HERE / "inherited"
    base.mkdir(exist_ok=False)
    for subdir in ["source", "objects", "provenance"]:
        (base / subdir).mkdir()
    object_records = {}
    for rec in prepared:
        name = rec["module"]
        dest_source = base / rec["snapshot"]
        dest_object = base / "objects" / (name + ".olean")
        shutil.copyfile(rec["inherited_source"], dest_source)
        shutil.copyfile(rec["inherited_object"]["path"], dest_object)
        assert sha(dest_source) == rec["sha256"]
        assert sha(dest_object) == rec["inherited_object"]["sha256"]
        object_records[name] = {"path": str(dest_object), "bytes": dest_object.stat().st_size,
                                "sha256": sha(dest_object),
                                "original_compilation_object": rec["inherited_object"]}
    copied_receipts = {}
    for relative in PINS:
        target = base / "provenance" / relative.replace("/", "__")
        shutil.copyfile(PRIOR_FINAL / relative, target)
        copied_receipts[relative] = {"source_path": str(PRIOR_FINAL / relative),
                                   "copy": str(target.relative_to(base)), "sha256": sha(target)}
    for relative in ["historical-receipt-correction.json", "baseline/module-origin-comparison.json"]:
        target = base / "provenance" / relative.replace("/", "__")
        shutil.copyfile(PRIOR / relative, target)
        copied_receipts[relative] = {"source_path": str(PRIOR / relative),
                                   "copy": str(target.relative_to(base)), "sha256": sha(target)}
    old_axioms = json.loads((PRIOR_FINAL / "audit/full-module-axioms.json").read_text())
    old_constants = json.loads((PRIOR_FINAL / "audit/module-constants.json").read_text())
    selected_axioms = [r for r in old_axioms if r["module"] in selected]
    selected_constants = [r for r in old_constants if r["module"] in selected]
    write_json(base / "provenance/inherited-axioms-from-prior-audit.json", selected_axioms)
    write_json(base / "provenance/inherited-origins-from-prior-audit.json", selected_constants)
    counts = {
        "status": "DERIVED_SUBSET_OF_PRIOR_SUCCESSFUL_AUDIT_NOT_A_NEW_EXECUTION",
        "explicit_public_theorem_exports": sum(len(audit["explicit_public_theorem_exports"][m]) for m in order),
        "explicit_named_declarations": sum(len(audit["explicit_named_declarations"][m]) for m in order),
        "theorem_constants": sum(r["kind"] == "theorem" for r in selected_axioms),
        "safe_definitions": sum(r["kind"] == "definition" for r in selected_axioms),
        "axiom_union": sorted({a for r in selected_axioms for a in r["axioms"]}),
        "module_constants": len(selected_constants),
        "unsafe_implementation_axioms": [r for r in audit["unsafe_implementation_axioms"] if r["module"] in selected],
    }
    source_manifest = {
        "status": "EXACT_INHERITED_SOURCES_AND_OBJECTS_VERIFIED_NO_NEW_LEAN_EXECUTION",
        "reviewer": "Agent #6 runtime/reproducibility specialist",
        "review_type": "inherited_eighteen_module_source_and_object_subset",
        "task": "agent6-normalized-carry-accounting-20261016",
        "claim_coordination_commit": CLAIM,
        "source_branch_commit": PINNED_COMMIT,
        "source_branch_tree": binding["remote_tree"],
        "current_worktree": str(WORKTREE),
        "parent_reported_worktree_baseline_short_commit": "dca30e7",
        "current_worktree_files_match_prior_exact_remote_source": True,
        "roots": ["CertificateCoordinates"], "build_order": order,
        "external_modules": sorted(external), "modules": prepared,
        "excluded_prior_modules": ["CertificateFilter", "CertificateControls"],
        "fresh_compilation": False, "inherited_objects_for_author_iteration_only": True,
        "future_independent_review": "Fresh 21-module source rebuild after all three authors freeze",
        "prior_compiler": compilation["compiler"],
        "prior_receipts": copied_receipts, "prior_audit_subset": counts,
        "runner": {"path": str(Path(__file__).resolve()), "sha256": sha(Path(__file__))},
        "created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    }
    write_json(base / "source-manifest.json", source_manifest)
    registry = {
        "status": "EXACT_INHERITED_MODULE_REGISTRY_FRAGMENT",
        "source_commit": PINNED_COMMIT,
        "roots": ["CertificateCoordinates"], "build_order": order,
        "external_modules": sorted(external),
        "modules": {r["module"]: {"path": r["repository_path"], "sha256": r["sha256"],
                     "git_blob": r["git_blob"], "imports": r["imports"]} for r in prepared},
    }
    write_json(base / "inheritance-registry.json", registry)
    write_json(base / "OBJECTS_READY.json", {
        "status": "INHERITED_VERIFIED_OBJECTS_READY_FOR_AUTHOR_ITERATION_ONLY",
        "object_directory": str(base / "objects"), "source_directory": str(base / "source"),
        "source_manifest": str(base / "source-manifest.json"),
        "source_manifest_sha256": sha(base / "source-manifest.json"),
        "module_count": len(order), "objects": object_records,
        "new_lean_execution": False, "new_independent_review_pass": False,
    })
    print(json.dumps({"status": source_manifest["status"], "build_order": order,
                      "source_bytes": sum(r["bytes"] for r in prepared),
                      "inherited_object_bytes": sum(r["bytes"] for r in object_records.values()),
                      "manifest": str(base / "source-manifest.json"),
                      "manifest_sha256": sha(base / "source-manifest.json"),
                      "registry_sha256": sha(base / "inheritance-registry.json"),
                      "objects": str(base / "objects"), "prior_audit_counts": counts}, indent=2))


if __name__ == "__main__":
    main()
