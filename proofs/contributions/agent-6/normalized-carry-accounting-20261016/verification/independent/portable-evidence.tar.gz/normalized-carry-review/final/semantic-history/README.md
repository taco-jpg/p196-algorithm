# Superseded semantic draft

`SEMANTIC_REVIEW-001.md` preserves the original semantic review byte-for-byte. It contained an additional numerical illustration about arbitrary incoming carry that had not been run in Lean. That illustration was removed from the accepted `../SEMANTIC_REVIEW.md` after the parent flagged the user's requirement that established counterexamples have Lean proofs. The precise scope observation that the input remains `kOf c` is retained.

The seven actual control theorems and all other reviewed source statements were independently compiled and axiom-audited. This documentation revision changes no Lean source, export, object, or execution result. `../SEMANTIC_SCOPE_CORRECTION.json` and the final publication binding distinguish the original draft and the accepted review by their exact hashes.
