#!/usr/bin/env python3
"""Snapshot the 21 frozen sources and exact registry; do not invoke Lean/Git."""
from __future__ import annotations

import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sys
import time

HERE = Path(__file__).resolve().parent
RUNTIME = HERE.parent
WORKTREE = RUNTIME.parent / "agent6-carry"
TASK = WORKTREE / "proofs/contributions/agent-6/normalized-carry-accounting-20261016"
NEW = {
    "NormalizedCarry": ("9bfef7cc4d805ac06631c730173da7e2def6611d7f9e0773f1b5ac8cb2891459", 3),
    "CertificateCarryAccounting": ("32404f75b0b740472825d3510dc52f5294a42ea89b75ddfe4a4b9629c932ec71", 6),
    "CarryControls": ("abac509aeef647003b9cc5d78ceecd5a9536b907285449d6dea9aa408ed333fb", 7),
}
DOCS = {
    "carry.registry.json": "e437e378bca3d93e6f3d03f66c0608fcc6af703e7e6b8c68957904889bc08a5a",
    "DEPENDENCIES.json": "7833de74a8ef182270cbbeb12d9e052d5a2c99d34f2e14941a83aa25162b61d4",
}


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def write_json(path: Path, value: object) -> None:
    with path.open("x") as f:
        json.dump(value, f, indent=2)
        f.write("\n")


def main() -> None:
    inherited_path = HERE / "inherited/source-manifest.json"
    assert sha(inherited_path) == "7b1322904536c16547435e8cd51adaf6478b9747636007e9d7514bc4bd420d97"
    inherited = json.loads(inherited_path.read_text())
    for name, expected in DOCS.items():
        assert sha(TASK / name) == expected, "Frozen document pin mismatch: " + name
    registry = json.loads((TASK / "carry.registry.json").read_text())
    assert registry["toolchain"]["version"] == "4.19.0"
    assert registry["toolchain"]["commit"] == "6caaee842e94"
    assert set(registry["toolchain"]["allowed_axioms"]) == {"propext", "Classical.choice", "Quot.sound"}
    assert list(registry["projects"]) == ["agent6-normalized-carry-accounting"]
    project = registry["projects"]["agent6-normalized-carry-accounting"]
    assert project["roots"] == ["CarryControls"]
    by_old = {r["module"]: r for r in inherited["modules"]}
    order = inherited["build_order"] + list(NEW)
    assert len(order) == 21 and set(project["modules"]) == set(order)
    claims = {c["module"]: c["endpoints"] for c in registry["claims"]}
    assert len(registry["claims"]) == 3 and set(claims) == set(NEW)
    parser_path = RUNTIME / "source-snapshot/p196-algorithm-4b4edf976b2c7a9ba1dad80636c0e21c66350325/proofs/archive/source-trees/2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5/proofs/verify_project.py"
    sys.dont_write_bytecode = True
    spec = importlib.util.spec_from_file_location("pinned_final_source_parser", parser_path)
    assert spec and spec.loader
    parser = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(parser)
    records, blobs, export_matches = [], {}, {}
    complete = set(inherited["external_modules"])
    for name in order:
        reg = project["modules"][name]
        live = WORKTREE / reg["path"]
        assert live.is_relative_to(WORKTREE)
        data = live.read_bytes()
        digest = hashlib.sha256(data).hexdigest()
        blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        assert digest == reg["sha256"] and blob == reg["git_blob"], "Registry/source mismatch: " + name
        code = parser.code_only(data.decode())
        imports = [x for line in re.findall(r"^\s*import\s+([^\n]+)", code, re.M) for x in line.split()]
        assert imports == reg["imports"] and set(imports) <= complete
        complete.add(name)
        rec = {"module": name, "path": str(live), "repository_path": reg["path"],
               "original_path": by_old[name]["original_path"] if name in by_old else reg["path"],
               "source_commit": inherited["source_branch_commit"] if name in by_old else None,
               "sha256": digest, "git_blob": blob, "bytes": len(data), "imports": imports,
               "snapshot": "source/" + name + ".lean"}
        if name in by_old:
            old = by_old[name]
            assert digest == old["sha256"] and blob == old["git_blob"]
            assert reg["path"] == old["repository_path"] and imports == old["imports"]
            assert (HERE / "inherited/source" / (name + ".lean")).read_bytes() == data
        else:
            expected, count = NEW[name]
            assert digest == expected
            namespaces = re.findall(r"^namespace\s+(\S+)", code, re.M)
            assert len(namespaces) == 1
            endpoints = [namespaces[0] + "." + n for n in re.findall(r"^theorem\s+([A-Za-z_][\w'.]*)", code, re.M)]
            assert endpoints == claims[name] and len(endpoints) == count
            assert not re.search(r"^private\s+theorem\s", code, re.M)
            rec.update({"author_status_at_snapshot": "FROZEN_AUTHOR_PASS",
                        "publication_binding_pending": True,
                        "expected_public_theorem_exports": count, "expected_private_theorems": 0})
            export_matches[name] = endpoints
        records.append(rec)
        blobs[name] = data
    final = HERE / "final"
    final.mkdir(exist_ok=False)
    (final / "source").mkdir()
    (final / "documents").mkdir()
    for name, data in blobs.items():
        (final / "source" / (name + ".lean")).write_bytes(data)
    documents = {}
    for name, expected in DOCS.items():
        data = (TASK / name).read_bytes()
        (final / "documents" / name).write_bytes(data)
        documents[name] = {"path": str(TASK / name), "snapshot": "documents/" + name,
                           "sha256": expected, "bytes": len(data),
                           "git_blob": hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()}
    manifest = {
        "status": "EXACT_FROZEN_SOURCE_SNAPSHOT_NOT_YET_INDEPENDENTLY_COMPILED",
        "reviewer": "Agent #6 runtime/reproducibility specialist",
        "review_type": "independent_fresh_twenty_one_module_normalized_carry_review",
        "task": "agent6-normalized-carry-accounting-20261016",
        "claim_coordination_commit": "1bd2354c2447febf38df9b69fb670e988abfc72a",
        "source_branch_commit": None, "source_branch_tree": None,
        "publication_binding_pending": True,
        "source_baseline_commit": inherited["source_branch_commit"],
        "parent_reported_repository_baseline_short_commit": "dca30e7",
        "roots": project["roots"], "build_order": order,
        "external_modules": inherited["external_modules"], "modules": records,
        "new_modules": list(NEW), "expected_new_public_theorem_exports": 16,
        "baseline_source_manifest_sha256": sha(inherited_path),
        "registry": documents["carry.registry.json"],
        "dependencies_document": documents["DEPENDENCIES.json"],
        "stage_runner": {"path": str(Path(__file__).resolve()), "sha256": sha(Path(__file__))},
        "snapshot_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "source_identity_note": "Exact frozen bytes precede independent compilation. Publication binding will be appended without changing the snapshot, source, or compilation receipt.",
    }
    write_json(final / "source-manifest.json", manifest)
    write_json(final / "REGISTRY_ALIGNMENT.json", {
        "status": "PASS_EXACT_FROZEN_SOURCE_AND_DECLARED_EXPORT_ALIGNMENT",
        "module_count": 21, "new_public_theorem_export_count": 16,
        "registry": documents["carry.registry.json"], "dependencies_document": documents["DEPENDENCIES.json"],
        "new_public_exports": export_matches, "build_order": order,
        "source_manifest_sha256": sha(final / "source-manifest.json"),
        "fresh_lean_execution_pending": True,
    })
    assert not (final / "build").exists()
    for rec in records:
        assert Path(rec["path"]).read_bytes() == (final / rec["snapshot"]).read_bytes()
    print(json.dumps({"status": manifest["status"], "module_count": len(order),
                      "source_bytes": sum(r["bytes"] for r in records),
                      "new_public_exports": sum(len(v) for v in export_matches.values()),
                      "source_manifest": str(final / "source-manifest.json"),
                      "source_manifest_sha256": sha(final / "source-manifest.json")}, indent=2))


if __name__ == "__main__":
    main()
