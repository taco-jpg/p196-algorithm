# Independent normalized-carry/accounting review preparation

The guarded claim is `1bd2354c2447febf38df9b69fb670e988abfc72a`. The parent owns Git and the contribution in `agent6-carry`; this reviewer owns only `runtime-agent6/review-carry` for the present review. The contribution authors are landscape (`NormalizedCarry`), root (`CertificateCarryAccounting`), and claims (`CarryControls`). This reviewer has authored no theorem source.

## Ready inheritance

The inherited root is `CertificateCoordinates`. Following its exact imports in the preceding independently reviewed source selects 18 modules and excludes the preceding contribution's `CertificateFilter` and `CertificateControls`. The selected source files total 165,357 bytes. Every current worktree file has been compared byte-for-byte with the source previously bound to remote `937c33ba3a98b9778bfee45a0bf2f0c0b3765055`.

`inherited/inheritance-registry.json` is the exact module-to-path/hash/import registry fragment. In particular, `ExteriorUpdateLaw` uses the published current path `proofs/ExteriorUpdateLaw.lean`, with original Agent115 blob `db2f3c5ea38b8d49ef7da82631b2ed7a95a29bea`. The 12 flattened inherited mappings, the four coordinate modules, and `CertificateCoordinates` keep their preceding exact source bytes.

`inherited/objects` contains 18 copies of the preceding independent build's objects, totaling 9,695,616 bytes. Each copied object matches its recorded SHA256. These inherited objects support author iteration; they are explicitly not a fresh build or a new independent review result. `prepare_inheritance.py` records and reproduces this selection without invoking Lean or Git.

The derived subset of the preceding complete audit contains 258 public theorem declarations, 359 explicitly named declarations, 682 theorem constants, 260 safe definitions, and 1,404 module constants. Its audited axiom union is `Classical.choice`, `Quot.sound`, and `propext`. Eleven generated unsafe implementation axioms remain separately recorded; they are not additional logical axioms of the audited theorem/safe-definition closure. These are inherited evidence counts, not new checks or counts of mathematical discoveries.

## Harness reuse

`compile_exact.py` is byte-identical to the preceding successful independent runner (SHA256 `1046d83b4e308632d916d53d1b686c9a227ca82834bded54fb180dc6b167cd0f`). It is manifest-driven, checks exact source/import/compiler pins, and starts with an empty project-object directory. Its path layout remains valid in this sibling review directory.

`audit_final.py` preserves the previous full environment-origin census, theorem and safe-definition axiom checks, private-helper handling, generated implementation inventory, and complete multiline parser. Its only substantive addition checks that every new public theorem has a literal source `#print axioms` command, validates the exact fresh compilation log, and compares those complete receipts with the separately executed full audit. Its scope text now names normalized-carry/accounting. The unmodified upstream copies and `harness-changes.patch` are retained, and `HARNESS_PREPARATION.json` records both versions' hashes. Python syntax parsing passed; the new review has not yet invoked Lean.

## Source review focus and initial observations

The preliminary source read matches the intended weak hypotheses. `gam_eq_overflow` has no premises. Structural suffix invariance is separated into a `c ≤ 18` theorem and a bounded-word theorem. The latter's suffix-length split uses identity when no letters were removed; a nonempty removed suffix puts `c` in the bounded original word and supplies the phase bound. It therefore does not need an upper bound on the original arbitrary phase.

The current accounting source separates the numeric-carry equality from the bound `gam ≤ 1`, then identifies the actual quotient-defined indicator. Its general row-sum equality uses only in-range boundedness. Validity and checker wrappers provide exactly that condition; the weighted consumer retains `check = true` as its sole certificate premise, with coefficients 9 for `totalGam` and 18 for the gains sum. The current seven controls address carry drift, unbounded indicator magnitude loss, empty final-word carry one, zero/neutral phases, and bounded phase 19. They assert no accepted-certificate instance.

At the preliminary read, the source declaration counts are 3, 6, and 7 public theorems respectively, with one helper definition in Controls. The Controls author explicitly reported that its import would change to `CertificateCarryAccounting` before final freezing. These observations will be reconciled to the actual frozen sources; this preliminary review is not the independent kernel result.

The pre-claim planning note and its source receipt are preserved byte-for-byte under `planning/`. The historical correction is also preserved: 25 of 1,991 earlier axiom lists were truncated by a physical-line parser; the complete raw lists had the same standard axiom union. This was a receipt-parser correction, not a theorem failure.

## Final gate

After all three authors provide frozen hashes and passing author receipts, stage the exact 21-module closure in a separate final source directory and run the fresh compiler followed by the independent audit. Use the existing genuine Lean 4.19.0 with `--trust=0 -j1 -DElab.async=false` through supported execution escalation. Preserve immutable source snapshots, exact commands and hashes, literal/structured/multiline logs, semantic review, and failures before any coordinated revision. Finally bind the reviewed bytes and registry to the parent's actual published remote commit. No unchanged baseline execution is needed before that final build.
