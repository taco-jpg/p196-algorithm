#!/usr/bin/env python3
"""Bind retained exact-ref GitHub responses to the successful frozen review."""
from __future__ import annotations

import base64
import hashlib
import json
from pathlib import Path
import time

HERE = Path(__file__).resolve().parent
FINAL = HERE / "final"
PUBLICATION = FINAL / "publication"
COMMIT = "affa037ad537f3ae66a97008991850ce397f613a"
TREE_REPORTED_BY_PARENT = "b611683b35881202c24f61b7e3b37636a3b0f1a1"


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def main() -> None:
    manifest = json.loads((FINAL / "source-manifest.json").read_text())
    audit = json.loads((FINAL / "audit/verification.json").read_text())
    compilation = json.loads((FINAL / "build/compilation.json").read_text())
    assert audit["status"] == "PASS" and audit["source_objects_compiler_unchanged_before_after"]
    assert audit["literal_source_prints_agree_with_full_independent_audit"]
    assert compilation["status"] == "COMPILED_PENDING_INDEPENDENT_AXIOM_AUDIT"
    assert sha(FINAL / "source-manifest.json") == "6959887b26d92f42b83f26df9603ce4b22f8d710efa5f5a88e4d56858eeddffa"
    assert sha(FINAL / "build/compilation.json") == "861af3cc104ec6da670db51687af9efa08345019fca814a1a69543d802f49ccc"
    assert sha(FINAL / "audit/verification.json") == "1a85f28098a7efac99a93e588635de3c95e1cf80a3f21bce2aabb9c194598c24"
    locked = {name: sha(FINAL / name) for name in [
        "source-manifest.json", "build/compilation.json", "audit/verification.json",
        "REGISTRY_ALIGNMENT.json", "MODULE_ORIGIN_COMPARISON.json", "SEMANTIC_REVIEW.md",
        "AUTHOR_ATTEMPT_CONTEXT.json"]}
    raw = json.loads((PUBLICATION / "fetch-responses.json").read_text())
    commit_response = json.loads((PUBLICATION / "commit-response.json").read_text())
    assert raw["actual_remote_source_commit"] == COMMIT and raw["encoding"] == "base64"
    assert commit_response["requested_commit"] == COMMIT
    assert not commit_response["response"]["isError"]
    commit = commit_response["response"]["structuredContent"]["commit"]
    assert commit["sha"] == COMMIT
    expected = {m["module"]: {**m, "target_name": m["module"] + ".lean"} for m in manifest["modules"]}
    worktree = HERE.parent.parent / "agent6-carry"
    for name, key in [("carry.registry.json", "registry"), ("DEPENDENCIES.json", "dependencies_document")]:
        rec = manifest[key]
        expected[name] = {**rec, "repository_path": str(Path(rec["path"]).relative_to(worktree)), "target_name": name}
    results = raw["results"]
    assert len(results) == len(expected) == 23
    assert {r["request"]["name"] for r in results} == set(expected)
    decoded, records = {}, []
    for item in results:
        request, response = item["request"], item["response"]
        name = request["name"]
        rec = expected[name]
        assert not response["isError"]
        remote = response["structuredContent"]
        assert remote["encoding"] == "base64"
        assert request["path"] == rec["repository_path"]
        assert request["snapshot"] == rec["snapshot"]
        assert request["sha256"] == rec["sha256"]
        assert request["git_blob"] == rec["git_blob"]
        data = base64.b64decode("".join(remote["content"].split()), validate=True)
        digest = hashlib.sha256(data).hexdigest()
        blob = hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()
        assert digest == rec["sha256"] and blob == rec["git_blob"] == remote["sha"]
        assert data == (FINAL / rec["snapshot"]).read_bytes() == Path(rec["path"]).read_bytes()
        decoded[rec["target_name"]] = data
        records.append({"module_or_document": name, "repository_path": rec["repository_path"],
                        "bytes": len(data), "sha256": digest, "git_blob": blob,
                        "api_git_blob": remote["sha"], "remote_url": remote["display_url"],
                        "saved_remote_source": "publication/source/" + rec["target_name"],
                        "review_snapshot": rec["snapshot"], "identical_to_review_snapshot": True})
    (PUBLICATION / "source").mkdir(exist_ok=False)
    for name, data in decoded.items():
        (PUBLICATION / "source" / name).write_bytes(data)
    for name, digest in locked.items():
        assert sha(FINAL / name) == digest
    for name, rec in compilation["objects"].items():
        assert sha(FINAL / "build/objects" / (name + ".olean")) == rec["sha256"]
    for path, digest in compilation["compiler"]["files"].items():
        assert sha(Path(path)) == digest
    report = {
        "status": "PASS_EXACT_REMOTE_SOURCE_BOUND", "actual_remote_source_commit": COMMIT,
        "remote_commit_url": commit["html_url"],
        "remote_tree": {"sha": TREE_REPORTED_BY_PARENT,
                        "provenance": "Parent's exact remote tree readback; this fetch_commit tool does not expose a tree field."},
        "parent_reported_local_same_tree_commit": "0ae6f56a5c8640e539fc425be7476c6dc41a4a83",
        "local_commit_is_not_claimed_as_remote": True,
        "read_only_fetch_tool": raw["tool"],
        "fetched_lean_modules": 21, "fetched_documents": 2, "files": records,
        "fetch_responses_sha256": sha(PUBLICATION / "fetch-responses.json"),
        "commit_response_sha256": sha(PUBLICATION / "commit-response.json"),
        "complete_retained_commit_response_file_count": len(commit["files"]),
        "unchanged_prior_receipt_hashes": locked,
        "all_original_staged_and_remote_sources_identical": True,
        "fresh_objects_and_compiler_still_unchanged": True,
        "binding_runner": {"path": str(Path(__file__).resolve()), "sha256": sha(Path(__file__))},
        "binding_created_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
        "note": "All 21 Lean files and both frozen documents were independently fetched at the exact published ref, decoded, and checked against actual bytes and Git blob identities. This appends publication provenance without changing initial snapshot, compilation, audit, or semantic receipts. No additional Lean execution was performed for binding.",
    }
    path = PUBLICATION / "binding-affa037.json"
    with path.open("x") as f:
        json.dump(report, f, indent=2)
        f.write("\n")
    print(json.dumps({"status": report["status"], "source_commit": COMMIT,
                      "lean_modules": 21, "documents": 2, "path": str(path), "sha256": sha(path)}, indent=2))


if __name__ == "__main__":
    main()
