from pathlib import Path
import hashlib, json, subprocess
root = Path(__file__).resolve().parent.parent
expected = {
    "proofs/FINDINGS.md": b"# Synthetic findings\nOriginal invented baseline.\n",
    "proofs/CONSOLIDATION.md": b"# Synthetic consolidation\nOriginal invented baseline.\n",
}
for name, content in expected.items():
    assert (root/name).read_bytes() == content, name
tracked = subprocess.check_output(["git", "ls-files"], cwd=root, text=True).splitlines()
assert set(tracked) == set(expected) | {"proofs/check_fixture.py"}
print(json.dumps({"status": "SYNTHETIC_FIXTURE_PASS", "baseline_files": len(tracked),
    "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
    "document_sha256": {name: hashlib.sha256((root/name).read_bytes()).hexdigest() for name in expected},
    "mathematical_proof_check": False}, sort_keys=True))
