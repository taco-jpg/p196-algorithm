# Synthetic findings
Original invented baseline.
