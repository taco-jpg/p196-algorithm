#!/usr/bin/env python3
"""Test preserved-byte selection in the unchanged public replay helper.

This creates an invented three-file baseline in a fresh local Git repository.
It is not a replay of the P196 repository, a Lean build, or mathematical evidence.
The caller supplies the inspected helper and a nonexistent output directory.
All phase inputs and logs are retained; publication logs redact only local paths.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys

PIN = "10a173cb635fa8d03e357f454232816fc3e77609"
EXPECTED_HELPER_BLOB = "4745990a5477a4b6a5c537b368bf78d214ce2622"


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def blob(data: bytes) -> str:
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--helper", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    helper = args.helper.read_bytes()
    assert blob(helper) == EXPECTED_HELPER_BLOB
    out = args.output.resolve()
    out.mkdir(parents=True, exist_ok=False)
    repo = out / "synthetic-repository"
    repo.mkdir()
    (out / "retained-replay-workspaces").mkdir()
    (out / "private-raw-logs").mkdir()
    (out / "publication-logs").mkdir()
    (out / "phase-inputs").mkdir()
    env = dict(os.environ, PYTHONDONTWRITEBYTECODE="1",
               TMPDIR=str(out / "retained-replay-workspaces"),
               GIT_AUTHOR_DATE="2026-10-17T00:00:00Z",
               GIT_COMMITTER_DATE="2026-10-17T00:00:00Z")

    def git(*argv: str) -> str:
        result = subprocess.run(
            ["git", "-c", "user.name=Agent 61 Synthetic Fixture",
             "-c", "user.email=agent61-fixture@example.invalid",
             "-c", "commit.gpgsign=false", "-c", "core.hooksPath=/dev/null",
             *argv], cwd=repo, env=env, capture_output=True, text=True,
            check=True)
        return result.stdout.strip()

    originals = {
        "proofs/FINDINGS.md": b"# Synthetic findings\nOriginal invented baseline.\n",
        "proofs/CONSOLIDATION.md": b"# Synthetic consolidation\nOriginal invented baseline.\n",
        "proofs/check_fixture.py": b'''from pathlib import Path
import hashlib, json, subprocess
root = Path(__file__).resolve().parent.parent
expected = {
    "proofs/FINDINGS.md": b"# Synthetic findings\\nOriginal invented baseline.\\n",
    "proofs/CONSOLIDATION.md": b"# Synthetic consolidation\\nOriginal invented baseline.\\n",
}
for name, content in expected.items():
    assert (root/name).read_bytes() == content, name
tracked = subprocess.check_output(["git", "ls-files"], cwd=root, text=True).splitlines()
assert set(tracked) == set(expected) | {"proofs/check_fixture.py"}
print(json.dumps({"status": "SYNTHETIC_FIXTURE_PASS", "baseline_files": len(tracked),
    "head": subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=root, text=True).strip(),
    "document_sha256": {name: hashlib.sha256((root/name).read_bytes()).hexdigest() for name in expected},
    "mathematical_proof_check": False}, sort_keys=True))
''',
    }
    git("init", "--initial-branch=fixture")
    for name, data in originals.items():
        dest = repo / name
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
    git("add", "--", *originals.keys())
    git("commit", "-m", "Create invented three-file replay baseline")
    base = git("rev-parse", "HEAD")
    mapping = {"base": base, "paths": {}}
    for name, data in originals.items():
        preserved = "proofs/archive/fixture-originals/" + name
        dest = repo / preserved
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(data)
        mapping["paths"][name] = {
            "preserved": preserved, "current": name,
            "sha256": sha(data), "mode": "100644", "oid": blob(data),
        }
    (repo / "proofs/replay_original_layout.py").write_bytes(helper)
    for name in list(originals)[:2]:
        (repo / name).write_text("# Corrected synthetic current page\nNot the historical baseline.\n")
    receipts = []

    def phase(label: str, expected_rc: int, marker: str) -> None:
        text = json.dumps(mapping, indent=2) + "\n"
        (repo / "proofs/SOURCE_MAP.json").write_text(text)
        (out / "phase-inputs" / (label + "-SOURCE_MAP.json")).write_text(text)
        command = [sys.executable, "-B", "proofs/replay_original_layout.py", "--",
                   sys.executable, "-B", "proofs/check_fixture.py"]
        result = subprocess.run(command, cwd=repo, env=env, capture_output=True,
                                text=True, timeout=30)
        entry = {"case": label, "command": ["python3", "-B", "proofs/replay_original_layout.py",
                 "--", "python3", "-B", "proofs/check_fixture.py"],
                 "exit_code": result.returncode, "expected_exit_code": expected_rc,
                 "map_sha256": sha(text.encode()), "logs": {}}
        for stream in ["stdout", "stderr"]:
            raw = getattr(result, stream)
            (out / "private-raw-logs" / (label + "." + stream + ".log")).write_text(raw)
            normalized = raw.replace(str(out), "<FIXTURE_ROOT>")
            public = out / "publication-logs" / (label + "." + stream + ".log")
            public.write_text(normalized)
            entry["logs"][stream] = {
                "published_path": str(public.relative_to(out)),
                "sha256": sha(normalized.encode()),
                "redaction": "Absolute fixture root replaced with <FIXTURE_ROOT>; other bytes unchanged.",
            }
        assert result.returncode == expected_rc, entry
        assert marker in result.stdout + result.stderr
        if expected_rc == 0:
            success = json.loads(next(line for line in result.stdout.splitlines()
                                      if line.startswith('{"baseline_files"')))
            assert success["head"] == base
            entry["checked_output"] = success
        entry["status"] = "EXPECTED_OUTPUT_CONFIRMED"
        receipts.append(entry)

    phase("edited-current-selected", 2, "Source changed; results for an old hash cannot be applied")
    for name in list(originals)[:2]:
        mapping["paths"][name]["current"] = None
    phase("edited-current-preserved-selected", 0, "SYNTHETIC_FIXTURE_PASS")
    damaged = "proofs/FINDINGS.md"
    archive = repo / mapping["paths"][damaged]["preserved"]
    damaged_bytes = originals[damaged] + b"Unexpected archive change.\n"
    (out / "phase-inputs/corrupted-preserved-FINDINGS.md").write_bytes(damaged_bytes)
    archive.write_bytes(damaged_bytes)
    phase("corrupted-preserved-selected", 2, "Source changed; results for an old hash cannot be applied")
    archive.write_bytes(originals[damaged])
    receipt = {"scope": "Invented three-file fixture, not the full P196 replay",
               "source_pin": PIN, "actual_helper_blob": blob(helper),
               "actual_helper_sha256": sha(helper), "synthetic_baseline": base,
               "synthetic_baseline_file_count": 3,
               "real_repository_replay_executed": False,
               "cases": receipts}
    (out / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps(receipt, indent=2))


if __name__ == "__main__":
    main()
