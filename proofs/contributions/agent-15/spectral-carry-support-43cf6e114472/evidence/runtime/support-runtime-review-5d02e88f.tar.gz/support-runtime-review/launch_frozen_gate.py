#!/usr/bin/env python3
"""Finite independent gate invocation; preserve exact commands and result."""
from pathlib import Path
import hashlib, json, os, signal, subprocess, sys, time
base = Path(__file__).resolve().parent
freeze = base / "freeze-inputs-001"
critical = json.loads((freeze / "critical-prerequisites.json").read_text())
modules = list(json.loads((freeze / "source-map.json").read_text()))
commit = "5d02e88f13f59f6fcd09cf75d8c7f188c6645727"
args = [sys.executable, "-B", str(base / "clean_review.py"),
        "--lean", "/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean",
        "--repo-root", "/dev/shm/p196-agent15-43cf6e114472/support-repo",
        "--source-map", str(freeze / "source-map.json"),
        "--source-commit", commit,
        "--evidence", str(base / "frozen-5d02e88f-attempt-001"),
        "--module", "ActualCarrySupport", "--new-module", "ActualCarrySupport",
        "--public-exports", str(freeze / "expected-public-exports.txt"),
        "--expected-public-export-count", "22"]
for module in modules:
    args += ["--exact-module", module]
for declaration in critical:
    args += ["--required-declaration", declaration]
command_file = base / "gate-invocation-001.json"
log_file = base / "gate-invocation-001.log"
if command_file.exists() or log_file.exists():
    raise SystemExit("Refuse to overwrite a prior invocation")
env = {"PATH": "/usr/bin:/bin", "LANG": "C.UTF-8", "PYTHONDONTWRITEBYTECODE": "1"}
report = {"schema_version": 1, "status": "RUNNING", "argv": args,
          "cwd": str(base), "environment": env, "executor_mode": "require_escalated",
          "source_commit": commit, "timeout_seconds": 1800,
          "python_executable": sys.executable,
          "python_sha256": hashlib.sha256(Path(sys.executable).read_bytes()).hexdigest(),
          "launcher_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
          "runner_sha256": hashlib.sha256((base / "clean_review.py").read_bytes()).hexdigest(),
          "started_at_epoch": time.time()}
def save():
    command_file.write_text(json.dumps(report, indent=2) + "\n")
save()
print("Starting the independently frozen eight-module gate; timeout 1800 seconds.", flush=True)
started = time.monotonic()
with log_file.open("wb") as stream:
    process = subprocess.Popen(args, cwd=base, env=env, stdout=stream, stderr=subprocess.STDOUT, start_new_session=True)
    report["pid"] = process.pid
    save()
    try:
        code = process.wait(timeout=1800)
    except subprocess.TimeoutExpired:
        report["timed_out"] = True
        os.killpg(process.pid, signal.SIGTERM)
        try:
            process.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(process.pid, signal.SIGKILL)
            process.wait()
        code = 124
report["status"] = "PASS_HELPER_EXIT_ZERO" if code == 0 else "FAILED_OR_TIMED_OUT"
report["exit_code"] = code
report["elapsed_seconds"] = time.monotonic() - started
report["finished_at_epoch"] = time.time()
report["log_sha256"] = hashlib.sha256(log_file.read_bytes()).hexdigest()
save()
print(json.dumps({"status": report["status"], "exit_code": code, "elapsed_seconds": report["elapsed_seconds"], "log": str(log_file)}), flush=True)
raise SystemExit(code)
