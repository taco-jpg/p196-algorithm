#!/usr/bin/env python3
"""Supplement the successful frozen build with unelided public/prerequisite prints."""
from pathlib import Path
import hashlib,json,os,re,subprocess,time,traceback
base=Path(__file__).resolve().parent
gate=base/"frozen-5d02e88f-attempt-001"
v=json.loads((gate/"verification.json").read_text())
assert v["status"]=="PASS_CLEAN_BUILD_AND_ALL_DECLARATIONS"
out=base/"supplemental-public-print-001"
out.mkdir(exist_ok=False)
names=v["explicit_printed_declarations"]
lean=Path("/tmp/p196-agent5-lean/lean-4.19.0-linux/bin/lean")
env={"PATH":str(lean.parent)+":/usr/bin:/bin","LANG":"C.UTF-8","LEAN_PATH":str(gate/"source")}
def sha(path):
    with Path(path).open("rb") as f:return hashlib.file_digest(f,"sha256").hexdigest()
checked={str(gate/path):info["sha256"] for path,info in v["artifacts"].items() if path.startswith("source/") and (path.endswith(".lean") or path.endswith(".olean"))}
checked.update(v["compiler"]["files"])
checked.update({x["path"]:x["sha256"] for x in v["standard_direct_imports"].values()})
checked[v["audit_harness_standard_import"]["path"]]=v["audit_harness_standard_import"]["sha256"]
for path,digest in checked.items():assert sha(path)==digest,path
source="import ActualCarrySupport\n\nset_option pp.all true\nset_option pp.proofs true\nset_option pp.deepTerms true\nset_option pp.maxSteps 1000000\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\n\n"
source+="\n".join("#print "+n+"\n#print axioms "+n for n in names)+"\n"
(out/"FullPublicPrint.lean").write_text(source)
option_path=lean.parent.parent/"src/lean/Lean/PrettyPrinter/Delaborator/Options.lean"
(out/"PinnedPrettyPrinterOptions.lean.txt").write_bytes(option_path.read_bytes())
argv=[str(lean),"--trust=0","-j1","-DElab.async=false","-o","FullPublicPrint.olean","FullPublicPrint.lean"]
report={"schema_version":1,"status":"RUNNING","source_commit":v["source_commit"],"reuses_only_objects_from_successful_fresh_gate":str(gate),"is_new_full_project_rebuild":False,"purpose":"Resolve observed pp.maxSteps=5000 output elisions in actual #print bodies; no mathematical source changes.","prior_public_print_elisions":(gate/"logs/public-exports.log").read_text().count("⋯"),"declarations":names,"expected_count":len(names),"argv":argv,"environment":env,"cwd":str(out),"executor_mode":"require_escalated","timeout_seconds":600,"input_identities":checked,"pretty_printer_options_provenance":{"path":str(option_path),"sha256":sha(option_path),"original_default_max_steps":5000,"supplement_max_steps":1000000},"source_sha256":sha(out/"FullPublicPrint.lean"),"started_at_epoch":time.time()}
def save():(out/"verification.json").write_text(json.dumps(report,indent=2)+"\n")
save()
print("Starting supplemental full public print using only the independently rebuilt frozen objects.",flush=True)
started=time.monotonic()
try:
    with (out/"full-public-prints.log").open("wb") as log:
        try:code=subprocess.run(argv,cwd=out,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=600).returncode
        except subprocess.TimeoutExpired:code=124
    report["exit_code"]=code
    assert code==0,f"Compiler exit {code}"
    text=(out/"full-public-prints.log").read_text()
    axioms=re.findall(r"^'(.+)' (?:does not depend on any axioms|depends on axioms: .*)$",text,re.M)
    assert len(axioms)==len(names) and set(axioms)==set(names),"Print axiom coverage changed"
    report["actual_print_axiom_count"]=len(axioms)
    report["remaining_elisions"]=text.count("⋯")
    assert report["remaining_elisions"]==0,"Remaining pretty-print elisions"
    for path,digest in checked.items():assert sha(path)==digest,path
    report["status"]="PASS_UNELIDED_PUBLIC_AND_PREREQUISITE_PRINTS"
except Exception as error:
    report["status"]="FAIL_SUPPLEMENTAL_PRINT"
    report["error"]=str(error)
    (out/"failure.txt").write_text(traceback.format_exc())
finally:
    report["elapsed_seconds"]=time.monotonic()-started
    report["finished_at_epoch"]=time.time()
    report["artifacts"]={str(p.relative_to(out)):{"bytes":p.stat().st_size,"sha256":sha(p)} for p in out.rglob("*") if p.is_file() and p.name!="verification.json"}
    save()
print(json.dumps({k:report.get(k) for k in ["status","exit_code","elapsed_seconds","actual_print_axiom_count","remaining_elisions"]}),flush=True)
raise SystemExit(0 if report["status"].startswith("PASS_") else 1)
