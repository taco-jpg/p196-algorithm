# Independent execution review preparation

Status: **READY_FOR_FROZEN_SOURCE; METADATA_ONLY**.

Reviewer: `support_runtime`, a genuine independent nonauthor subagent of Agent #15. The reviewer has authored no target Lean declaration, changed no target Lean source, and performed no Git mutation or external publication. The parent relays attributed coordination through issue #61. English is used for these durable review artifacts; conversational coordination is in Spanish.

The protected carry-support task is `agent15-spectral-carry-support-43cf6e114472`, claim commit `3de89d0bd03534c92f65886a29b7996525571ff5`, task-record blob `2707332dbc4dc1274bb8470b15e17f6350618bba`. The exact contract, claim record, and repository retention policy are preserved under `contract-inputs/`.

## Verified preparation

`metadata-001/verification.json` records a read-only comparison of the seven existing dependency sources with their original immutable commit bytes and explicit expected Git blob identifiers. All seven comparisons passed. Their real import graph has exactly the following project modules:

- `SpectralWeights`, `BinaryCode`, `ChargeSymmetry`, and `SourceFormula`, pinned to `e8d706dc8a67248e1531b0b828fbe05ff50052ed`.
- `LychrelDigitSums`, `IncomingCarrySensitivity`, and `RawSymmetryObstruction`, pinned to `5ff4f607535587d572fbc9e95ba9501d1fbe5fc5` and their original flattened repository paths.

Both subgraphs import only official `Std` externally. Adding the contract's new root `ActualCarrySupport`, importing `SourceFormula` and `RawSymmetryObstruction`, should give exactly eight project modules. This is an anticipated final closure, not a claim that the new source has yet been frozen or checked.

No target build has been executed during preparation. No existing compiled project object has been relabeled as a fresh build. The seven checked source copies, actual Git source outputs, commands, source scans, SHA256 hashes, and blob identities are retained in the metadata attempt.

## Infrastructure adaptation

The prior accepted reviewer helper and its complete report remain byte-preserved in `original-infrastructure/`. The adapted helper is `clean_review.py`; its first candidate snapshot, change list, and exact patch are in `infrastructure-001/`. Python syntax validation passed.

The adaptation uses a strict explicit map from each real import name to its repository path, original immutable commit, and expected blob. During the final gate it will require every source to match both that original pin and the final immutable source commit. It rejects unpinned imports, unexpected project modules, project shadowing of `Init`/`Std`/`Lean`, source changes during review, forbidden live constructs, and disallowed transitive axioms. Every selected project object will be compiled from copied source inside a newly created evidence directory, with an isolated `LEAN_PATH`.

All Lean invocations, including version and prefix identification, use `--trust=0 -j1 -DElab.async=false`. The official Lean 4.19.0 executable, top-level Lean shared libraries, directly imported official `Std` object, and official `Lean` audit import will be hashed and rechecked. The standard compiled runtime is reused; the complete selected project closure will be built fresh. These are distinct boundaries.

The origin-based audit retains signatures and real `#print axioms` output for every selected-module declaration, including private helpers and imported project declarations. Safe mathematical declarations are checked against only `propext`, `Classical.choice`, and `Quot.sound`. Generated unsafe/partial compiler implementations are inventoried separately rather than counted as safe mathematics. A separate exact endpoint pass executes literal `#print` and `#print axioms` for each new explicit public declaration and each required prerequisite endpoint.

## Execution mode and preservation

The ordinary executor sees a different `/dev/shm` view and initially returned missing-path errors. The approved `require_escalated` executor sees the assigned shared-memory workspace. Those observations are recorded in `preparation-inspection-failures.json`; they did not mutate or compile a source. No approval was denied. No mount, permission, toolchain, other review directory, or cache was modified, and no cleanup or deletion was attempted.

The final gate awaits the parent's frozen exact source commit and export list. Its execution result must be assessed together with the separate nonauthor semantic review. Preparation alone confers no mathematical acceptance or integration status.
