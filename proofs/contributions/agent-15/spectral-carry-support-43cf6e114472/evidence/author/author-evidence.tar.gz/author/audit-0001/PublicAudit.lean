import ActualCarrySupport

set_option pp.width 120
set_option pp.universes true

#check P196.Agent15.SpectralSupport.outgoing
#print axioms P196.Agent15.SpectralSupport.outgoing

#check P196.Agent15.SpectralSupport.actualCharge
#print axioms P196.Agent15.SpectralSupport.actualCharge

#check P196.Agent15.SpectralSupport.outgoing_length
#print axioms P196.Agent15.SpectralSupport.outgoing_length

#check P196.Agent15.SpectralSupport.outgoing_getElem
#print axioms P196.Agent15.SpectralSupport.outgoing_getElem

#check P196.Agent15.SpectralSupport.outgoing_getElem?
#print axioms P196.Agent15.SpectralSupport.outgoing_getElem?

#check P196.Agent15.SpectralSupport.outgoing_last
#print axioms P196.Agent15.SpectralSupport.outgoing_last

#check P196.Agent15.SpectralSupport.outgoing_binary
#print axioms P196.Agent15.SpectralSupport.outgoing_binary

#check P196.Agent15.SpectralSupport.outgoing_reverse_iff
#print axioms P196.Agent15.SpectralSupport.outgoing_reverse_iff

#check P196.Agent15.SpectralSupport.actualCharge_zero_iff
#print axioms P196.Agent15.SpectralSupport.actualCharge_zero_iff

#check P196.Agent15.SpectralSupport.outgoing_reflected_eq_of_nonnine
#print axioms P196.Agent15.SpectralSupport.outgoing_reflected_eq_of_nonnine

#check P196.Agent15.SpectralSupport.actualCharge_nonzero_iff_nine_asymmetry
#print axioms P196.Agent15.SpectralSupport.actualCharge_nonzero_iff_nine_asymmetry

#check P196.Agent15.SpectralSupport.actualCharge_zero_of_no_nine
#print axioms P196.Agent15.SpectralSupport.actualCharge_zero_of_no_nine

#check P196.Agent15.SpectralSupport.canonical_actualCharge_zero_iff
#print axioms P196.Agent15.SpectralSupport.canonical_actualCharge_zero_iff

#check P196.Agent15.SpectralSupport.canonical_outgoing_reflected_eq_of_nonnine
#print axioms P196.Agent15.SpectralSupport.canonical_outgoing_reflected_eq_of_nonnine

#check P196.Agent15.SpectralSupport.canonical_actualCharge_nonzero_iff_nine_asymmetry
#print axioms P196.Agent15.SpectralSupport.canonical_actualCharge_nonzero_iff_nine_asymmetry

#check P196.Agent15.SpectralSupport.canonical_actualCharge_zero_of_no_nine
#print axioms P196.Agent15.SpectralSupport.canonical_actualCharge_zero_of_no_nine

#check P196.Agent15.SpectralSupport.actualCharge_width_zero
#print axioms P196.Agent15.SpectralSupport.actualCharge_width_zero

#check P196.Agent15.SpectralSupport.actualCharge_width_one
#print axioms P196.Agent15.SpectralSupport.actualCharge_width_one

#check P196.Agent15.SpectralSupport.Controls.nine_zero_charge
#print axioms P196.Agent15.SpectralSupport.Controls.nine_zero_charge

#check P196.Agent15.SpectralSupport.Controls.even_overflow_zero_charge
#print axioms P196.Agent15.SpectralSupport.Controls.even_overflow_zero_charge

#check P196.Agent15.SpectralSupport.Controls.odd_free_center
#print axioms P196.Agent15.SpectralSupport.Controls.odd_free_center

#check P196.Agent15.SpectralSupport.Controls.odd_nine_asymmetry
#print axioms P196.Agent15.SpectralSupport.Controls.odd_nine_asymmetry

