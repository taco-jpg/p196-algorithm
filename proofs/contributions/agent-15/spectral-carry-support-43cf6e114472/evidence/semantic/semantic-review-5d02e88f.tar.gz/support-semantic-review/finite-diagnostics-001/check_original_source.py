"""Finite source-script diagnostics; not a universal proof or Lean execution."""
from itertools import product
from pathlib import Path
import hashlib
import json
import runpy

source = Path(__file__).parents[1] / "contract-snapshot-001" / "creative_global_spectral.py"
data = source.read_bytes()
assert hashlib.sha256(data).hexdigest() == "393545516c13d41c0416e560ec37bab6b1c1655357ae351b0f960dea76ff7448"
original = runpy.run_path(str(source))
qstep = original["qstep"]
carry_coordinates = original["carry_coordinates"]

def inspect(q):
    _, carries, final = qstep(q)
    _, charge = carry_coordinates(carries)
    assert len(carries) == len(q)
    assert all(c in (0, 1) for c in carries)
    assert (charge == 0) == (carries == carries[::-1])
    assert (charge == 0) == all(carries[i] == carries[len(q)-1-i] for i in range(len(q)))
    if q:
        assert carries[-1] == final
    else:
        assert final == 0
    return carries, charge, final

arbitrary_counts = {}
for length in range(4):
    count = 0
    for q in product(range(19), repeat=length):
        inspect(q)
        count += 1
    arbitrary_counts[str(length)] = count

symmetric_counts = {}
parity_overflow_counts = {}
for length in range(7):
    count = 0
    for half in product(range(19), repeat=(length+1)//2):
        q = half + half[:length//2][::-1]
        assert len(q) == length and q == q[::-1]
        carries, charge, final = inspect(q)
        assert all(q[i] == 9 or carries[i] == carries[length-1-i] for i in range(length))
        witness = any(q[i] == 9 and carries[i] != carries[length-1-i] for i in range(length))
        assert (charge != 0) == witness
        if all(x != 9 for x in q):
            assert charge == 0
        key = ("odd" if length % 2 else "even") + ":overflow=" + str(final)
        parity_overflow_counts[key] = parity_overflow_counts.get(key, 0) + 1
        count += 1
    symmetric_counts[str(length)] = count

canonical_examples = []
for n in [1, 5, 10, 18, 55, 158, 605, 11587, 1558, 115587]:
    digits = tuple(int(c) for c in str(n)[::-1])
    assert digits[-1] != 0 and sum(d*10**i for i,d in enumerate(digits)) == n
    q = tuple(a+b for a,b in zip(digits,digits[::-1]))
    carries, charge, final = inspect(q)
    canonical_examples.append({"n":n,"digits_lsf":digits,"q":q,"outgoing":carries,"J":charge,"overflow":final})
assert canonical_examples[3]["q"] == (9,9) and canonical_examples[3]["J"] == 0

nonsymmetric = (10,0)
carries, charge, final = inspect(nonsymmetric)
assert 9 not in nonsymmetric and charge != 0

print(json.dumps({
    "status":"PASS_FINITE_DIAGNOSTICS_ONLY",
    "scope":"Original Python qstep and carry_coordinates only; no Lean source is executed or generated.",
    "arbitrary_bounded_words_zero_iff_counts_by_length":arbitrary_counts,
    "arbitrary_bounded_words_total":sum(arbitrary_counts.values()),
    "symmetric_bounded_words_support_counts_by_length":symmetric_counts,
    "symmetric_bounded_words_total":sum(symmetric_counts.values()),
    "symmetric_parity_overflow_counts":parity_overflow_counts,
    "canonical_examples":canonical_examples,
    "symmetry_hypothesis_diagnostic":{"q":nonsymmetric,"outgoing":carries,"J":charge,"overflow":final},
    "limitations":["Finite enumeration is not the required universal Lean theorem.","Canonical examples are ordinary integer digit calculations, not Lean proofs of Canonical.","No theorem acceptance or transitive axiom audit is inferred from these diagnostics."]
},indent=2))
