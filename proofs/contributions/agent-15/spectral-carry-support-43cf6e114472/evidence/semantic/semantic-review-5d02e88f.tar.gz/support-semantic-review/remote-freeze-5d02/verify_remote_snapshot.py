"""Preserve and verify remote bytes; no Lean execution or source modification."""
from pathlib import Path
import hashlib
import json
import difflib
import re

base = Path(__file__).parent
review = base.parent
response_path = base / "remote-read-responses.json"
records = json.loads(response_path.read_text())
commit = "5d02e88f13f59f6fcd09cf75d8c7f188c6645727"
tree = "f0594cce1d8b4888561edb4ed22770ab4a6a991a"
expected = {
    "ActualCarrySupport.lean": "c0e5562e1661570546bced3dca82dd4fb459fa5f",
    "CONTRACT.md": "1b756b6a795f927043159e50e6c9c802ad86a66b",
    "CLAIM.json": "2707332dbc4dc1274bb8470b15e17f6350618bba",
    "SpectralWeights.lean": "40afa93196976972e5c0f6772a18e50c1e635a3f",
    "BinaryCode.lean": "35ba9bee5afb9bb47f39738e44860a02ea9b2469",
    "ChargeSymmetry.lean": "f69efd4bc0642759dddf99834d5d093c929761a5",
    "SourceFormula.lean": "1db4a109629abddf355d12e8a14f2cfb0e26a39b",
    "LychrelDigitSums__0810ace083af80c5.lean": "8a865176625283648a8a20dd2411ed77670eb0a2",
    "IncomingCarrySensitivity__5d4952e23e746f6d.lean": "9ccc745471fd509fb68652fef40454478087e92e",
    "RawSymmetryObstruction__5c1be305a04af2b7.lean": "9d4250f3e5daa5ff26f097a7e12ce98830dd9e89",
}
def hashes(data):
    return {"bytes":len(data), "sha256":hashlib.sha256(data).hexdigest(),
        "git_blob":hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()}

files = base / "files"
files.mkdir(exist_ok=False)
manifest = []
remote_commit = remote_branch = None
for record in records["records"]:
    response = record["response"]
    assert not response.get("isError", False)
    content = response["structuredContent"]["content"]
    label = record["request"].get("label")
    if label in ("commit", "branch"):
        parsed = json.loads(content)
        with (base / ("remote-"+label+".json")).open("x") as f:
            json.dump(parsed,f,indent=2); f.write("\n")
        if label == "commit":
            remote_commit = parsed
        else:
            remote_branch = parsed
        continue
    source_path = record.get("path") or "proofs/contributions/agent-15/spectral-carry-support-43cf6e114472/ActualCarrySupport.lean"
    name = Path(source_path).name
    data = content.encode("utf-8")
    info = hashes(data)
    assert info["git_blob"] == expected[name], (name, info["git_blob"], expected[name])
    with (files / name).open("xb") as f:
        f.write(data)
    local = review / ("source-snapshot-001" if name == "ActualCarrySupport.lean" else "contract-snapshot-001") / name
    info.update({"name":name,"repository_path":source_path,"remote_commit":commit,
        "read_url":response["structuredContent"]["url"],"local_comparison_path":str(local),
        "same_as_preliminary_snapshot":data==local.read_bytes()})
    manifest.append(info)

assert remote_commit["sha"] == commit
assert remote_commit["tree"]["sha"] == tree
assert remote_branch["object"]["sha"] == commit
assert len(manifest) == 10
for entry in manifest:
    if entry["name"] != "ActualCarrySupport.lean":
        assert entry["same_as_preliminary_snapshot"]

old = (review/"source-snapshot-001/ActualCarrySupport.lean").read_bytes()
new = (files/"ActualCarrySupport.lean").read_bytes()
old_doc = b"For every positive width, the last word entry is the actual overflow bit."
new_doc = b"For every positive width, the last word entry is the actual final outgoing carry."
assert old.count(old_doc)==1 and new.count(new_doc)==1
assert old.replace(old_doc,new_doc,1)==new
assert hashes(new)["sha256"] == "4c06522efae7aa254b6281003d042e49f6b60162d01d00881d50052c7a73c646"
delta = "".join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),
    fromfile="preliminary-bd35276/ActualCarrySupport.lean",tofile="frozen-5d02e88/ActualCarrySupport.lean"))
with (base/"delta-from-source-snapshot-001.diff").open("x") as f:
    f.write(delta)
text = new.decode()
names = re.findall(r"^(?:@\[[^\]\n]+\] )?(?:def|theorem)\s+([^\s(]+)",text,re.M)
assert len(names)==22
manifest_record = {
    "status":"PASS_REMOTE_BYTES_AND_SEMANTIC_DELTA",
    "reviewer":"support_semantics",
    "frozen_commit":commit,"tree":tree,"branch":remote_branch["ref"],
    "branch_at_frozen_commit_on_read":True,
    "contract_unchanged":True,"claim_unchanged":True,
    "all_seven_dependency_files_unchanged":True,
    "only_source_change_is_S1_docstring":True,
    "formal_definitions_statements_and_proof_text_unchanged":True,
    "source_declaration_count":len(names),"source_declaration_names":names,
    "files":manifest,
    "raw_response_sha256":hashes(response_path.read_bytes())["sha256"],
    "execution_limit":"Python byte/hash comparison only; reviewer performed no Lean run or independent axiom audit."
}
with (base/"manifest.json").open("x") as f:
    json.dump(manifest_record,f,indent=2); f.write("\n")
print(json.dumps(manifest_record,indent=2))
print(delta)
