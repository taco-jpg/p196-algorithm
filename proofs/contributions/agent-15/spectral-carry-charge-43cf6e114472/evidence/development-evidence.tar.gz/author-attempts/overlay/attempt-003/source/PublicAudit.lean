import ChargeSymmetry
#print P196.Agent15.SpectralCarry.recurrence
#print axioms P196.Agent15.SpectralCarry.recurrence
#print P196.Agent15.SpectralCarry.recurrence_zero
#print axioms P196.Agent15.SpectralCarry.recurrence_zero
#print P196.Agent15.SpectralCarry.recurrence_one
#print axioms P196.Agent15.SpectralCarry.recurrence_one
#print P196.Agent15.SpectralCarry.recurrence_step
#print axioms P196.Agent15.SpectralCarry.recurrence_step
#print P196.Agent15.SpectralCarry.U
#print axioms P196.Agent15.SpectralCarry.U
#print P196.Agent15.SpectralCarry.S
#print axioms P196.Agent15.SpectralCarry.S
#print P196.Agent15.SpectralCarry.U_zero
#print axioms P196.Agent15.SpectralCarry.U_zero
#print P196.Agent15.SpectralCarry.U_one
#print axioms P196.Agent15.SpectralCarry.U_one
#print P196.Agent15.SpectralCarry.U_step
#print axioms P196.Agent15.SpectralCarry.U_step
#print P196.Agent15.SpectralCarry.S_zero
#print axioms P196.Agent15.SpectralCarry.S_zero
#print P196.Agent15.SpectralCarry.S_one
#print axioms P196.Agent15.SpectralCarry.S_one
#print P196.Agent15.SpectralCarry.S_step
#print axioms P196.Agent15.SpectralCarry.S_step
#print P196.Agent15.SpectralCarry.oddWeight
#print axioms P196.Agent15.SpectralCarry.oddWeight
#print P196.Agent15.SpectralCarry.evenWeight
#print axioms P196.Agent15.SpectralCarry.evenWeight
#print P196.Agent15.SpectralCarry.oddWeight_zero
#print axioms P196.Agent15.SpectralCarry.oddWeight_zero
#print P196.Agent15.SpectralCarry.oddWeight_one
#print axioms P196.Agent15.SpectralCarry.oddWeight_one
#print P196.Agent15.SpectralCarry.oddWeight_step
#print axioms P196.Agent15.SpectralCarry.oddWeight_step
#print P196.Agent15.SpectralCarry.evenWeight_zero
#print axioms P196.Agent15.SpectralCarry.evenWeight_zero
#print P196.Agent15.SpectralCarry.evenWeight_one
#print axioms P196.Agent15.SpectralCarry.evenWeight_one
#print P196.Agent15.SpectralCarry.evenWeight_step
#print axioms P196.Agent15.SpectralCarry.evenWeight_step
#print P196.Agent15.SpectralCarry.weightSum
#print axioms P196.Agent15.SpectralCarry.weightSum
#print P196.Agent15.SpectralCarry.weightSum_zero
#print axioms P196.Agent15.SpectralCarry.weightSum_zero
#print P196.Agent15.SpectralCarry.weightSum_succ
#print axioms P196.Agent15.SpectralCarry.weightSum_succ
#print P196.Agent15.SpectralCarry.oddWeight_pos
#print axioms P196.Agent15.SpectralCarry.oddWeight_pos
#print P196.Agent15.SpectralCarry.evenWeight_pos
#print axioms P196.Agent15.SpectralCarry.evenWeight_pos
#print P196.Agent15.SpectralCarry.oddWeight_growth
#print axioms P196.Agent15.SpectralCarry.oddWeight_growth
#print P196.Agent15.SpectralCarry.evenWeight_growth
#print axioms P196.Agent15.SpectralCarry.evenWeight_growth
#print P196.Agent15.SpectralCarry.oddWeight_superincreasing
#print axioms P196.Agent15.SpectralCarry.oddWeight_superincreasing
#print P196.Agent15.SpectralCarry.evenWeight_superincreasing
#print axioms P196.Agent15.SpectralCarry.evenWeight_superincreasing
#print P196.Agent15.SpectralCarry.Binary
#print axioms P196.Agent15.SpectralCarry.Binary
#print P196.Agent15.SpectralCarry.weighted
#print axioms P196.Agent15.SpectralCarry.weighted
#print P196.Agent15.SpectralCarry.binary_nil
#print axioms P196.Agent15.SpectralCarry.binary_nil
#print P196.Agent15.SpectralCarry.binary_tail
#print axioms P196.Agent15.SpectralCarry.binary_tail
#print P196.Agent15.SpectralCarry.weighted_bounds
#print axioms P196.Agent15.SpectralCarry.weighted_bounds
#print P196.Agent15.SpectralCarry.weighted_lt_next
#print axioms P196.Agent15.SpectralCarry.weighted_lt_next
#print P196.Agent15.SpectralCarry.weighted_injective_binary
#print axioms P196.Agent15.SpectralCarry.weighted_injective_binary
#print P196.Agent15.SpectralCarry.reverse_take_half_iff
#print axioms P196.Agent15.SpectralCarry.reverse_take_half_iff
#print P196.Agent15.SpectralCarry.halfCharge
#print axioms P196.Agent15.SpectralCarry.halfCharge
#print P196.Agent15.SpectralCarry.oddCharge
#print axioms P196.Agent15.SpectralCarry.oddCharge
#print P196.Agent15.SpectralCarry.evenCharge
#print axioms P196.Agent15.SpectralCarry.evenCharge
#print P196.Agent15.SpectralCarry.carryCharge
#print axioms P196.Agent15.SpectralCarry.carryCharge
#print P196.Agent15.SpectralCarry.binary_reverse
#print axioms P196.Agent15.SpectralCarry.binary_reverse
#print P196.Agent15.SpectralCarry.binary_take
#print axioms P196.Agent15.SpectralCarry.binary_take
#print P196.Agent15.SpectralCarry.halfCharge_zero_iff
#print axioms P196.Agent15.SpectralCarry.halfCharge_zero_iff
#print P196.Agent15.SpectralCarry.oddCharge_zero_iff
#print axioms P196.Agent15.SpectralCarry.oddCharge_zero_iff
#print P196.Agent15.SpectralCarry.evenCharge_zero_iff
#print axioms P196.Agent15.SpectralCarry.evenCharge_zero_iff
#print P196.Agent15.SpectralCarry.carryCharge_zero_iff
#print axioms P196.Agent15.SpectralCarry.carryCharge_zero_iff
