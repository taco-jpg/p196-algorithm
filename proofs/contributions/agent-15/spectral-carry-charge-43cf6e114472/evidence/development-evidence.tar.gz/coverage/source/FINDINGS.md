<!-- AGENT1 CONSOLIDATION 20261015 -->

## Agent #1: Current accepted scopes, exclusions and remaining mathematical obligations

Start with [CONSOLIDATION.md](CONSOLIDATION.md). The core build is scoped; the global accepted catalogue remains incomplete. Historical sections below retain their original evidence scope and date.

# Findings and evidence matrix

**Neither decimal Lychrel existence nor the assertion for 196 is proved.** This matrix indexes the substantive result families. The linked original reports contain exact quantifiers, exceptional cases, parameters, source filenames, certificates, and failed alternatives. [REPORTS.md](REPORTS.md) additionally enumerates all written reports; [INVENTORY.tsv](INVENTORY.tsv) accounts for all retained and omitted computational files.

Here `T(n)=n+reverse(n)` in base ten, `S` is decimal digit sum, and all integers under discussion are finite. “All length” or “all period” always applies to the specified ansatz. “Lean” means the stated supporting theorem, not the unresolved existence claim.

| Finding or research family | Established scope and remaining limit | Primary record and evidence |
|---|---|---|
| Canonical mirrored pair words and carry transducer | Exact numeric semantics, realizability, palindrome-predecessor characterization, and conditional symbolic-to-numeric existence implication. No safe closed nonempty language instance is supplied. | [Research overview](research/README.md), [standalone Lean](research/Lychrel196Research.lean), [carry manuscript](research/CarryWordsResearch.tex) |
| Same-carry normalization | Every complete decimal first carry word has a same-width positive representative hitting a palindrome within four additions; four is sharp. This does not assert termination of all representatives. | [Resumed status](research/ResumedResearchStatus.txt), [normalization notes](research/resume_renewal_normalization_notes.txt), [Lean](research/Lychrel196Research.lean) |
| Carry-history reconstruction | Eleven consecutive complete carry words determine the original mirrored pair-sum word, not its individual digit splits. | [Carry-history proof](research/resume_renewal_carry_history.txt), [Lean](research/resume_carry_history.lean), [eleven-step support](research/resume_growth_eleven.lean) |
| Fixed-width numeric inverse injectivity | The reverse-add output determines the mirrored pair sums at a fixed input width. The next-pair-sum map can still have large fibers. | [Current historical status](research/CurrentResearchStatus.txt), [Lean](research/Lychrel196Research.lean), [inverse-fiber proof](research/persist_inverse_fibers_proof.txt) |
| Width growth | Checked upper and lower linear width bounds for every positive seed; improved constants for 196. These imply no palindrome-avoidance conclusion. | [Existence-search update](research/ExistenceSearchUpdate.txt), [growth proof](research/exist_count_notes.txt), [Lean](research/Lychrel196Research.lean) |
| General-base normalization | Written extensions of the sharp four-step normalization bound for the stated even and odd bases. These general-base statements are not Lean formalizations. | [Even-base proof](research/resume_even_base_normalization_proof.txt), [general-base proof](research/resume_general_base_normalization_proof.txt), [manuscript](research/CarryWordsResearch.tex) |
| Unbounded decimal digit sums | Every positive orbit has unbounded digit sums on every tail; an explicit initial-width-dependent escape bound is also formalized. Iteration continues after palindromes. | [Continuation report](research/continuation/LychrelContinuationUpdate.txt), [standalone Lean](research/continuation/LychrelDigitSums.lean), [axiom audit](research/continuation/ContinuationAxiomAudit.lean) |
| Uniform digit-sum escape | Explicit decimal bounds independent of seed, initial width, and starting time, including the sharper bound in the latest modules. The general-base written result has its separately documented scope. | [Formal status](research/main_existence_attempt/smart_pass/uniform_lean/FORMAL_STATUS.txt), [sharp formal theorem](research/main_existence_attempt/smart_pass/uniform_lean/SharpUniformDecimal.lean), [manuscript](research/continuation/UnboundedDigitSums.tex) |
| Sparse orbits and quantitative growth | Written sparse-profile and digit-mass consequences, including the stated running-maximum lower bound. Pointwise divergence is not claimed. | [Sparse-orbit proof](research/continuation/sparse_orbits_theorem.md), [strengthening notes](research/continuation/strengthening_notes.txt), [uniform audit](research/continuation/uniform_effective_audit.txt) |
| Moving walls and renewal | Fixed finite wall-distance proposals are obstructed by digit-sum growth; safe renewal examples exist, but their proposed repetition fails by a symbolic obstruction. | [Wall closure](research/continuation/wall_closure_notes.md), [wall renewal](research/continuation/wall_renewal_notes.md), [renewal search](research/continuation/renewal_search_notes.md) |
| Exact-length palindromes in residue classes | Written all-moduli construction rules out a nonempty universally safe forward invariant defined only by fixed residue and exact length. The all-moduli construction is not formalized in Lean. | [Proof](research/astra_modular_fixed_modulus_theorem.md), [independent audit](research/astra_audit_fixed_modulus_report.md), [manuscript](research/ExactLengthPalindromes.tex) |
| Divisibility by 11 and correlated columns | Every positive orbit is divisible by 11 from time six; sharpness and supporting compatible-residue/column statements are checked in Lean. They do not yield safety. | [Astra report](research/AstraResearchUpdate.txt), [modular formal report](research/astra_lean_modular_report.md), [correlated language notes](research/astra_languages_complement_notes.md) |
| Spectral carry coordinates | Lossless full-word coordinate identities, carry quotient calculations, and exclusions of specified spectral/residue simplifications. No persistent nonzero antisymmetric carry invariant was found. | [Spectral derivation](research/creative_global_spectral_notes.md), [carry quotient](research/astra_spectral_carry_quotient.md), [audit](research/astra_audit_spectral_quotient.md) |
| Affine encoders and transfer between bases | Exact local carry/output identities have Lean support; tested literal/affine base-transfer constructions fail or remain incomplete. No full-orbit binary-to-decimal conjugacy is supplied. | [Encoding analysis](research/novel_encoding_analysis.md), [base-transfer findings](research/astra_base_transfer_notes.md), [local Lean identities](research/novel_encoding_CarryEncoder.lean) |
| Projective, stack, and growing boundary constructions | Necessary clocks and prefix conditions; bounded searches and counterexamples do not close an all-time finite-seed family. | [Projective notes](research/novel_projective_notes.md), [aperiodic boundary notes](research/novel_stack_aperiodic_boundary.txt), [prefix-balance notes](research/novel_stack_prefix_balance.txt) |
| Complete period-four exteriors | No expanding safe cycle for the specified complete exteriors of widths 1 through 4, at any temporal period; larger templates remain open. | [Period-four report](research/PeriodFourResearchUpdate.txt), [independent check](research/next_period4_check_results.json), [full verification](research/next_period4_full_verified.json) |
| Uniform-core and geometric constructions | Includes the period-24/gain-9 all-finite-exterior-width obstruction and scoped graph checks for other clocks. Other bounded SAT/SMT outcomes and timeouts remain separately recorded. | [Existence-search report](research/ExistenceSearchUpdate.txt), [uniform notes](research/exist_uniform_notes.txt), [geometry notes](research/exist_geom_notes.txt), [periodic bulk notes](research/exist_periodic_bulk_notes.txt) |
| Affine runs and binary control | A known binary expanding family is rediscovered as a control; no decimal expanding family is obtained. | [Affine-run notes](research/exist_affine_runs_notes.txt), [binary control](research/exist_affine_runs_binary_control.json) |
| Neutral interface and finite-core erosion | Exact graph/width/potential certificates rule out every finite core behind the specified 11-step neutral interface, including changing/growing cores. This is not a universal decimal exclusion. | [Combined proof](research/persist_neutral_interface_exclusion.txt), [wake notes](research/persist_wake_notes.txt), [independent compensation record](research/persist_root_compensation_check.json) |
| Inverse-fiber bounds and unconditional linear scores | Sharp Fibonacci/power-of-two fiber bounds and exact rational dual obstructions to the specified score models. | [Inverse proof](research/persist_inverse_fibers_proof.txt), [spacetime notes](research/persist_spacetime_notes.txt), [certificate-check results](research/persist_spacetime_certificate_check_results.json) |
| Allowed-tile and adjacent-context grammars | Rank-free finite-seed repair and many concrete exclusions/derivations; resumed searches ended UNKNOWN, with no safe nonempty closed grammar. | [Resumed existence report](research/main_existence_attempt/RESUMED_STATUS.txt), [initial status](research/main_existence_attempt/STATUS.txt), [adjacent-context report](research/main_existence_attempt/context2_cegis/README.txt) |
| Arbitrary-group score obstruction | Exact presentation/cancellation certificate excludes the stated unconditional one-row group scores, including automorphism updates. It does not exclude conditional noninvertible monoids. | [Group theorem and replay](research/main_existence_attempt/group_invariant/README.md), [checker](research/main_existence_attempt/group_invariant/check_certificate.py) |
| Laurent-polynomial / positive scalar score obstructions | Exact exclusions of the corresponding scalar score families over the specified fields/scalings; all model restrictions are retained. | [Resumed status](research/main_existence_attempt/RESUMED_STATUS.txt), [initial existence status](research/main_existence_attempt/STATUS.txt), [finite-field source](research/main_existence_attempt/finite_field/) |
| Finite-defect symbolic construction | A safe finite prefix is checked for the stated symbolic parameter range; no recurrent safe return is established. | [Defect report](research/main_existence_attempt/defect_family/defect_family_report.md), [source](research/main_existence_attempt/defect_family/) |
| Conditional parity and two-state monoid scores | The specified nonempty conditional XOR model is excluded by a checked LRAT proof. Two-state transformation-monoid runs remain UNKNOWN. | [Conditional-score report](research/main_existence_attempt/conditional_score/README.md), [CNF](research/main_existence_attempt/conditional_score/any.cnf), [LRAT](research/main_existence_attempt/conditional_score/any.lrat), [checker](research/main_existence_attempt/conditional_score/check_lrat.py) |
| Safe centers and the 936 exterior | All stated center variants have exact checks. The missing prescribed 936 boundary is later excluded for every finite width and temporal period. | [Historical collision/conditional report](research/main_existence_attempt/COLLISION_AND_CONDITIONAL_STATUS.txt), [final boundary report](research/main_existence_attempt/boundary_resume/BOUNDARY_RESEARCH_STATUS.txt) |
| All-width boundary exclusion and Lean trust boundary | Eight reverse graphs and independent arithmetic checks exclude the explicit alternating 8/17 boundary. Concrete finite Lean checks use `native_decide`; generic soundness is separate. | [Reverse-language proof](research/main_existence_attempt/boundary_resume/reverse/SOFIC_ALL_PERIOD_PROOF.txt), [formal status](research/main_existence_attempt/boundary_resume/lean/FORMAL_STATUS.txt), [independent root audit](research/main_existence_attempt/boundary_resume/root_sofic_audit.py) |
| Other clocks, 525 exteriors, and structural constraints | Exclusions for 76 of 190 motifs in one new clock; specified 525 exteriors through width 17 and catalogued length-three motifs through width 14. Larger-width claims remain open where stated. | [New clock](research/main_existence_attempt/boundary_resume/new_clock/STATUS.txt), [reverse 525](research/main_existence_attempt/boundary_resume/reverse525/STATUS_AND_POWER_LIFT_PROOF.txt), [forward join](research/main_existence_attempt/boundary_resume/forward_join/STATUS_AND_PROOF.md), [structural derivations](research/main_existence_attempt/boundary_resume/structure/STRUCTURAL_DERIVATIONS.md) |
| Collision components and arbitrary-motif law | Exact finite safe collision components, including a thirteen-step mass-increasing gate and a motif law valid until its actual finite zero-gap collision. Proposed adjacent-parameter or regenerative returns fail. | [Gate report](research/main_existence_attempt/smart_pass/collision/STATUS.md), [return collision report](research/main_existence_attempt/return_pass/collision/STATUS.md), [earlier collision analysis](research/main_existence_attempt/collision_return/collision_checkpoint.md) |
| Moving-front conditional theorem | Conditional construction and independent obstruction to the specified finite-state front-potential criterion; no all-time family instance. | [Conditional front theorem](research/main_existence_attempt/smart_pass/constructive/CONDITIONAL_FRONT_THEOREM.md), [criterion audit](research/main_existence_attempt/smart_pass/constructive/INDEPENDENT_CRITERION_AUDIT.txt), [status](research/main_existence_attempt/smart_pass/constructive/STATUS.md) |
| Counting and contraction proposals | Exact finite counterexamples, including a length-16 obstruction to the proposed universal contraction. These do not disprove other counting approaches. | [Counting result](research/main_existence_attempt/smart_pass/counting/COUNTING_RESULT.md), [Astra safe-fiber result](research/astra_counting_safe_image_fibers.txt), [counting notes](research/exist_count_notes.txt) |
| Correlated full-word observation languages | Eight fixed transition tables have independently replayed empty safe kernels, totaling 978,016 terminal-class exclusions. Larger or different invariants are not excluded. | [Language status](research/main_existence_attempt/return_pass/language/STATUS.md), [method/proof](research/main_existence_attempt/return_pass/language/METHOD_AND_PROOF.md), [independent checker](research/main_existence_attempt/return_pass/language/check_eliminations.py) |
| Safe-ancestry repair and remaining correlations | Safe two-step ancestry removes a concrete splice missed by ordinary ancestry. The saved 6,680-state NFA is exact; incomplete determinization remains UNKNOWN. | [Language status](research/main_existence_attempt/return_pass/language/STATUS.md), [saved NFA](research/main_existence_attempt/return_pass/language/safe_image2_nfa.json) |
| Direct terminal-component NFA exclusion | Every one of 8,396 original terminal flags has a certified terminating member. No nonempty union of these whole terminal-component languages is safe and closed; conjunctive/configuration acceptance is outside this result. | [Direct ancestry status](research/main_existence_attempt/ancestry_direct_pass/language/STATUS.md), [complete witnesses](research/main_existence_attempt/ancestry_direct_pass/language/terminal_acceptance_result.json), [independent replay](research/main_existence_attempt/ancestry_direct_pass/root_nfa_audit.py) |
| Fixed-target finite ancestry | Unconditional numeric and finite pair-word bounds imply empty all-depth ancestry intersections. Formal safe predicates and the predecessor-tested language recurrence have different endpoint conventions. | [Formal scope](research/main_existence_attempt/ancestry_direct_pass/lean/STATUS.md), [Lean](research/main_existence_attempt/ancestry_direct_pass/lean/FiniteAncestry.lean) |
| Finite delay versus ancestry cutoff | Exact equivalences reduce all-depth obstruction to unbounded finite first-hit delay. The 289-step witness proves the stated finite-depth failures only. The bounded-delay/existence dichotomy does not choose a side. | [Delay proof/status](research/main_existence_attempt/ancestry_direct_pass/delay/STATUS.md), [exact checker](research/main_existence_attempt/ancestry_direct_pass/delay/check_delay.py) |
| Probabilistic deductions | Exact finite ensembles expose missing marginal/joint/correlation assumptions. Heuristic frequency or conditional probabilities do not become existence proofs. | [Probability result](research/main_existence_attempt/return_pass/probability/PROBABILITY_RESULT.md), [independent arithmetic replay](research/main_existence_attempt/return_pass/root_probability_audit.py) |
| Repository engine review | Source and arithmetic review plus explicitly scoped CPU emulation tests and minimal counterexamples; this is separate from mathematical existence and from untested GPU execution. | [Repository review directory](research/main_existence_attempt/ancestry_direct_pass/repository_review/), [source/math checks](research/main_existence_attempt/ancestry_direct_pass/repository_review/source_and_math_checks.json), [CPU provenance](research/main_existence_attempt/ancestry_direct_pass/repository_review/cpu/provenance.json) |
| Formal finite-delay / safe-ancestry equivalences | Actual decimal and admissible pair-word recurrence: safe-kernel closure is equivalent to the stated universal finite positive-delay bound. Finite attained delays form an initial segment; no boundedness or unboundedness assertion is selected. | [Formal scope](research/main_existence_attempt/correlation_pass/lean/STATUS.md), [generic bridge](research/main_existence_attempt/correlation_pass/lean/SafeDelay.lean), [numeric bridge](research/main_existence_attempt/correlation_pass/lean/DecimalDelayBridge.lean), [pair bridge](research/main_existence_attempt/correlation_pass/lean/PairDelayBridge.lean) |
| Explicit finite safe family and conditional witness | For all D, C_D=2*(10^(2D+1)-1) is safe at indices 0 through D; FiniteDelayBound D implies IsLychrel C_D. The safe family is unconditional; no D satisfying the bound is provided. The existence-or-unbounded-delay disjunction is nonexclusive. | [Safe-run proof](research/main_existence_attempt/correlation_pass/lean/DecimalSafeRuns.lean), [conditional theorem](research/main_existence_attempt/correlation_pass/lean/DecimalDelayBridge.lean), [complete 63-theorem audit](research/main_existence_attempt/correlation_pass/lean/verification.json), [independent rebuild](research/main_existence_attempt/correlation_pass/lean/root_verification.json) |
| Exact finite-kernel quantifiers | Every finite safe kernel is nonempty, yet no fixed finite pair word belongs to all kernels. This does not exclude changing targets along an infinite forward orbit. | [Pair theorem](research/main_existence_attempt/correlation_pass/lean/PairDelayBridge.lean), [formal status](research/main_existence_attempt/correlation_pass/lean/STATUS.md) |
| Full-configuration / observation class collisions | 146 exact collisions through depth ten exclude the listed whole classes on the first 101 words of the 196 trace. They do not prove that 196 terminates, exclude arbitrary refinements, or rule out later entry into an invariant. | [Language status](research/main_existence_attempt/correlation_pass/language/STATUS.md), [method and proof](research/main_existence_attempt/correlation_pass/language/METHOD_AND_PROOF.md), [independent collision checker](research/main_existence_attempt/correlation_pass/language/check_correlated_collisions.py) |
| Literal correlated closure test and antichain snapshot | F10 fails at 9948 -> 18447; the witness has minimum decimal width for that candidate. The 65,170-entry incomparable-configuration snapshot is independently verified, but global exploration and synthesis remain UNKNOWN. | [Focused checks](research/main_existence_attempt/correlation_pass/language/focused_checks.py), [retained compressed snapshot](research/main_existence_attempt/correlation_pass/language/antichain_depth0.json.gz), [independent antichain checker](research/main_existence_attempt/correlation_pass/language/check_antichain.py) |
| Exact arbitrary-motif seam normalization | Endpoint-overlap identity with neutral-run correction and mass loss; no fixed bounded repair radius covers all seams. Independent stepwise fixed overlaps with a duplicated positive component fail within five updates. Coupled or selected-time constructions remain open. | [Seam proof](research/main_existence_attempt/correlation_pass/constructive/STATUS.md), [ordinary-integer controls](research/main_existence_attempt/correlation_pass/constructive/seam_overlap.py) |
| Variable-overlap classification and positive two-step gate | Exact one-step closure forces zero normalization carry and unchanged physical shift. A distinct all-r two-step gate repairs a real intermediate defect and preserves whole-word safety through return; every returned core leaves its eligible domain, so recurrence is unproved. One core branch terminates at step three for every r. | [All-parameter proof and limits](research/main_existence_attempt/correlation_pass/constructive/VARIABLE_OVERLAP_AND_GATE.md), [classification controls](research/main_existence_attempt/correlation_pass/constructive/variable_overlap.py), [gate controls](research/main_existence_attempt/correlation_pass/constructive/delayed_overlap_gate.py) |
| Free-clock prefix extensions and cyclic inverse search | Nine explicitly prescribed schedules cannot extend by one column through a complete cycle. Sampling is not an exhaustive clock catalog. The surviving alternating candidate reaches cyclic depth 16 before a raw graph cap; unrestricted width remains UNKNOWN. | [Scope and quotient argument](research/main_existence_attempt/correlation_pass/free_clock/STATUS.md), [exact extension certificate](research/main_existence_attempt/correlation_pass/free_clock/prefix_extension_audit.json), [capped final summary](research/main_existence_attempt/correlation_pass/free_clock/bidirectional_language.json) |
| Exact later first hits of five original repair-core branches | Written all-r first-hit results: (1,5) at 3 and (2,5)/(2,6)/(3,5) at 4 for r>=1; (1,6) at 11 for r>=5. Independent algebraic replay verifies 26 symbolic transitions and 208 literal controls. Small-spacer and remaining-family UNKNOWN cases retain their finite scope; no Lean or all-time nontermination result is claimed. | [Exact statement, endpoints and proof](research/main_existence_attempt/renewal_pass/tails/STATUS.md), [symbolic certificate](research/main_existence_attempt/renewal_pass/tails/symbolic_tail_certificates.json), [independent checker](research/main_existence_attempt/renewal_pass/tails/check_symbolic_tails.py), [shared handoff](coordination/2026-10-14-tail-termination.md) |
| Checked all-length delayed overlap gate and exact defect cancellation | Lean proves the two-step component/whole return for r>=1, 1<=p<=4, u>=1, v>=5, u+v<=8; coefficient defect (1,-20,1) normalizes to antisymmetric digit defect (1,0,-1). Every ordinary realization is safe at positive steps 1/2, and step 3 is palindromic iff p<=2,u=1,v=5. The returned tuple leaves only the original six-core Domain; compatible second gates in larger domains are not excluded. Both audits pass for all 49 supporting declarations. No recurrent certificate is supplied. | [Statement and theorem map](research/main_existence_attempt/renewal_pass/lean/STATUS.md), [Lean source](research/main_existence_attempt/renewal_pass/lean/DelayedOverlapGate.lean), [fresh complete audit](research/main_existence_attempt/renewal_pass/lean/verification.json), [independent root audit](research/main_existence_attempt/renewal_pass/lean/root_verification.json), [shared formal handoff](coordination/2026-10-14-formal-gate.md) |
| Literature and novelty limitations | Primary-source provenance and prior-art limitations are recorded; no new priority or external peer-review claim is made. | [Literature findings](research/astra_literature_findings.md), [digit-sum prior art](research/continuation/digit_sum_prior_art_notes.txt), [publication addendum](research/continuation/publication_prior_art_addendum.txt) |

No failed model in this matrix is promoted to a statement about every possible model. No finite verification is promoted to an infinite nontermination theorem.

## Reviewed concurrent contribution pass

| Finding | Exact scope | Evidence |
|---|---|---|
| Overflow-sensitive safe-prefix improvement | For all R, C=2*(10^(floor(7R/4)+1)-1) avoids palindromes at indices 0 through R. Its conditional infinite-witness implication retains the unsupplied universal finite-delay bound. | [Proof and Lean audit](contributions/2026-10-14-safe-prefix/README.md) |
| Delayed-gate finite lifetimes | Cores (2,5),(2,6),(3,5) first hit at 4 for all r>=1; (1,6) first hits at 11 for all r>=5. The (1,7) family and short-spacer (1,6) cases remain outside this classification. | [Written proof and exact symbolic replay](contributions/2026-10-14-overlap-gate/EXACT_GATE_LIFETIMES.md) |
| Exact separated-block dynamics and exhaustion | Gap g reaches zero by 4g+P(B_0)-3; for the remaining (1,7) gate by 4r-3. Exact block update and palindrome criterion hold through the first zero gap. No post-collision or all-time safety conclusion. | [Written proof and independent controls](contributions/2026-10-14-overlap-gate/SEPARATION_EXHAUSTION.md) |
| Finite-horizon density-one avoidance | Exact block counting gives an upper bound on positive hits by H and density-one avoidance as width grows, including H(L)=max(1,floor(c log10 L)), 0<c<2/7. Deterministic implication checked in Lean; counting and limits are written proofs. No fixed infinite-safe seed follows. | [Bounds, quantifiers and evidence](contributions/2026-10-14-finite-horizon-density/README.md) |

The [root review](contributions/2026-10-14-root-review.json) and
[handoff](coordination/2026-10-14-checked-contributions.md) record exact
reproduction commands, source identities and retained limitations.

## Checked collision follow-up

| Finding | Exact scope | Evidence |
|---|---|---|
| Actual carry-response and transfer normal form | 24 Lean declarations: all-length incoming-carry response, actual interval semantics, and identity/constant transfer determined by the last non-nine coefficient. No collision invariant supplied. | [Formal scope and audit](contributions/2026-10-14-collision-formal/README.md) |
| Exact zero-gap collision and independent closure | N(BHB)-P=(x-10)F with actual-width reflection; exact mass loss and closure iff both isolated carries are zero or both outside coefficients are at least 10. Written unrestricted proof, 45,849 controls. | [Proof and controls](contributions/2026-10-14-collision/COLLISION_RESPONSE.md) |
| Zero-gap palindrome criterion and finite driver | Exact component criterion with 128,547 finite controls. All 10,000 driver states and 9,999 recorded transitions independently checked; no infinite-driver claim. | [Review](contributions/2026-10-14-collision-review/COLLISION_REVIEW.md), [complete trace recovery](contributions/2026-10-14-collision-review/ARCHIVE_README.md), [streaming audit](contributions/2026-10-14-collision-audit/README.md) |
| Explicit fixed-horizon family | n_r=10^(2r+6)+10^(2r+5)+10^(r+5)+8*10^(r+4)+7*10^(r+3) avoids palindromes at times 0 through 10000 for every r>=5078. Finite certificate plus written reduction; no all-time result. | [Proof and exact checks](contributions/2026-10-14-driver-family/FINITE_FAMILY.md) |
| Concurrent gate independent rebuild | Exact source-hash-checked fresh Lean rebuild and all 49 declaration audits pass; ordinary logical axioms only. | [Independent audit](contributions/2026-10-14-external-gate-audit/README.md) |

## Checked seven-step reset and collision mass

| Finding | Exact scope | Evidence |
|---|---|---|
| Actual collision digit mass | 17 Lean declarations for all-length incoming mass response and BHB mass correction, including actual numeric digitSum. No invariant conclusion. | [Formal proof and controls](contributions/2026-10-14-collision-mass/README.md) |
| Actual seven-step boundary return | 29 Lean declarations connect actual/numeric orbits to return iff actual controls are 00*0*01, the overflow schedule 0010101 and width gain three. Full middle map and safety are separate written proofs. | [Formal scope](contributions/2026-10-14-seven-step-formal/README.md) |
| Conditional reset and failed automatic recurrence | Exact padded-middle operator and safety iff both first middle states contain a coefficient at least 10. Complete 75,447-start catalog, 4,501 returns, counterexamples to automatic guard/safety preservation. No all-width exclusion. | [Proof and full evidence](contributions/2026-10-14-seven-step-reset/SEVEN_STEP_RESET.md), [independent 4,190-middle review](contributions/2026-10-14-seven-step-review/README.md) |
| Fixed boundary-clock classifications | Complete widths-one-through-three classifications; each tested constant/alternating schedule has safe two-column cycles. These are freely imposed clocks, not actual orbit realizations. | [Results](contributions/2026-10-14-prefix-controls/FIXED_CLOCK_RESULTS.md), [independent audit](contributions/2026-10-14-prefix-controls/INDEPENDENT_AUDIT.md) |

## Sharp seven-step clock obstruction

| Finding | Exact scope | Evidence |
|---|---|---|
| At most three consecutive (4,4,0) returns | Every admissible finite width at least six; four returns at 7,14,21,28 impossible, with no safety assumption. Actual three-safe-return witness and sharp 26-transition bound. | [Complete proof and graph certificate](contributions/2026-10-14-seven-step-extension/SEVEN_STEP_BOUND.md) |
| Full independent rank audit | All 96,026 controls, 61,731 edges and 48,013 ranks reconstructed. Macro and correlated-lift discovery records also retained. | [Independent audits](contributions/2026-10-14-seven-step-extension/INDEPENDENT_EXTENSION_AUDIT.md) |
| Formal actual local relation | Eight Lean theorems for actual carry extension and numeric interpretation at 1 <= k < L, including overlap. Does not kernel-check the finite graph/rank enumeration. | [Formal scope](contributions/2026-10-14-prefix-extension-formal/README.md) |

## All-branch seven-step two-column return obstruction

| Finding | Exact scope | Evidence |
|---|---|---|
| Complete return branching | All 128 controls give exactly 16 returns and three traces; the graph permits arbitrary branch changes. | [Independent control classification](contributions/2026-10-14-broader-return/TWO_COLUMN_CONTROL_AUDIT.md) |
| Uniform finite return bound | Every admissible width L >= 2 satisfies R <= 228 + max(0,ceil((14-L)/3)) <= 232. No safety assumption, conservative bound, no implication from exit to palindrome. | [All-width proof](contributions/2026-10-14-broader-return/BROADER_RETURN_BOUND.md) |
| Complete hierarchy and transient audit | All 127,824 local controls, every raw/recurrent graph through width fourteen, and 60,563 weighted condensation components independently checked. Uses published formal local necessity; the complete hierarchy is not yet a Lean theorem. | [Root review and retained hashes](contributions/2026-10-14-broader-return-root-review.json), [result handoff](coordination/2026-10-14-broader-return-results.md) |

## Complete scalar clock obstruction

| Finding | Exact scope | Evidence |
|---|---|---|
| Scalar sequence (4,8,16,7,15,6,13) excluded forever | Every admissible width L >= 1, unrestricted inner histories: R <= min(236,232+max(0,ceil((14-L)/3))). Requires every phase, not merely outer-4 endpoints. | [Full theorem](contributions/2026-10-14-scalar-clock/SCALAR_CLOCK_BOUND.md) |
| Independent complete hierarchy and ranks | All 128,644 local controls and 60,952 weighted components checked; entire raw/recurrent data retained. | [Independent scope](contributions/2026-10-14-scalar-clock/INDEPENDENT_SCALAR_AUDIT.md) |
| Generic weighted path formalization | Fifteen Lean declarations, with ordinary logical axioms. Does not instantiate numerical scalar tables or the whole hierarchy. | [Formal proof](contributions/2026-10-14-scc-bound-formal/README.md) |
| Other capped probes and exact recovery | primitive14 and seven_1 remain UNKNOWN. All completed graphs retained; two truncated records preserved and canonical replacements match original reported hashes. | [Root review](contributions/2026-10-14-scalar-clock-root-review.json), [handoff](coordination/2026-10-14-scalar-clock-results.md) |

## Completed generalized renewal and actual carry safety

| Finding | Established scope and remaining limit | Primary evidence |
|---|---|---|
| Twenty-core all-r repair classification | Exactly 80 genuine two-step repairs in the stated complete four-column class, with p=1,...,4. Written uniform affine certificates and boundary cases; not an unrestricted classification. | [Proof and classification](research/main_existence_attempt/renewal_pass/constructive/STATUS.md), [all comparison records](research/main_existence_attempt/renewal_pass/constructive/capture_witnesses.json) |
| Two repairs and a failed third | Four infinite spacer families have safe outputs through time 4 and exact repairs at times 2/4. The proposed time-6 repair fails uniformly by outside coefficients 14 versus 15; later unrelated returns are not excluded. | [Complete composition record](research/main_existence_attempt/renewal_pass/constructive/return_composition.json), [third-repair certificate](research/main_existence_attempt/renewal_pass/constructive/third_gate_check.json) |
| Finite-memory projection and finite-edit obstruction | Controllers with universal transition coverage saturated under the same word classes project to a safe closed union. An all-r ladder gives infinitely many F10 closure failures; finite symmetric-difference edits cannot fix F10. No positive invariant supplied. | [Written quantifiers and proof](research/main_existence_attempt/renewal_pass/language/METHOD_AND_PROOF.md), [independent ladder audit](research/main_existence_attempt/renewal_pass/language/inverse_ladder_audit.json) |
| Inverse ladder and selected-prefix obstruction | Stated all-r families have first hits 15,14,13,12,11. Every one-step output avoids prefix (1,6,2), and no ordinary orbit at time >=2 starts (2,12,4). All 16 Lean support declarations audited. An outside-cylinder ancestor is retained; all ancestry is not bounded by this result. | [Language report](research/main_existence_attempt/renewal_pass/language/STATUS.md), [formal source and scope](research/main_existence_attempt/renewal_pass/lean/prefix/STATUS.md), [full exploration archive](research/main_existence_attempt/renewal_pass/language/exploration_archive.json.gz) |
| Arbitrary-block exact seam response | D=E+(x-10)K with actual incoming carries and initial-nine runs; exact common-clock mass deficit 18K(1), and common-clock closure iff K=0. Actual final width and all-nine blocks included. Written theorem, not a full Lean polynomial formalization. | [Proof](research/main_existence_attempt/renewal_pass/constructive/collision_response/SEAM_RESPONSE.md), [2,737 complete controls](research/main_existence_attempt/renewal_pass/constructive/collision_response/seam_response_cases.json.gz) |
| Actual incoming-carry law | Additional carry persists exactly through the initial-nine run; exact digit defect, all-nine terminal case and arbitrary-offset actual-block bridge. All 28 Lean support declarations freshly and independently audited. | [Formal statement and checks](research/main_existence_attempt/renewal_pass/lean/incoming_carry/STATUS.md) |
| Positive active-seam safety and raw-symmetry rigidity | On every canonical whole pair word under every partition, K nonzero implies a nonpalindromic ordinary next output. Raw E symmetry is equivalent to output palindromicity and forces K=0. The actual partition/decimal bridge has 42 audited Lean declarations. The original impossible symmetric-E/nonzero-K shortcut is preserved as superseded history. | [Written proof and controls](research/main_existence_attempt/renewal_pass/seam_audit/STATUS.md), [formal source and scope](research/main_existence_attempt/renewal_pass/lean/raw_symmetry/STATUS.md), [original proposal snapshot](research/main_existence_attempt/renewal_pass/seam_audit/source_SEAM_RESPONSE_snapshot.md) |
| Independent component-closure failure implies safety | For canonical symmetric B,H, failure of G(BHB)=(1+x^(b+m))G(B)+x^bG(H) implies one safe ordinary next step. Equivalently, K nonzero or mismatched isolated final carries suffices. Written corollary combining the external closure theorem with exact palindrome-predecessor classes; not separately formalized and not necessary for safety. | [Proof, mixed-clock example and limit](research/main_existence_attempt/renewal_pass/external_review/COLLISION_SAFETY_COROLLARY.md) |
| Finite unresolved gate/196 join tests | 22 tested seeds have neither palindrome nor exact join to the tested 196 orbit through 1,500 additions. No all-time join exclusion or nontermination follows. | [Scope and complete result](research/main_existence_attempt/renewal_pass/tails/FINITE_JOIN_CHECK.md) |
| Sharp obstruction to four fixed seven-step returns | Independently reconstructed complete six-prefix graph: 48,013 vertices, 96,026 controls, 61,731 edges; phase-zero rank <=26. Four returns require 28 edges. All-width inclusion handles overlap, and the three-return example is sharp. Written proof plus complete finite certificate; full rank not Lean-kernel-checked. | [Independent sources, proof and full certificate](research/main_existence_attempt/renewal_pass/external_review/seven_step_graph/) |
| Independent review of concurrent evidence | Root rebuilt and audited the earlier external 24 safe-prefix/density declarations and replayed the stated separation/density controls. The later collision and r>=5078 finite-family reports were read; the other stream's full 10,000-state audit is preserved without claiming a new local full-trace replay. | [Review scope](research/main_existence_attempt/renewal_pass/external_review/README.md), [root review](research/main_existence_attempt/renewal_pass/ROOT_REVIEW.md) |

The completed renewal modules total 135 supporting theorem declarations (49+16+28+42), each with its exact source hash and audit. The count does not imply 135 independent major theorems. No indefinitely repeatable safe return, positive closed invariant or decimal Lychrel witness has been supplied.

## Refined component-specific clock bounds

| Hypothesis | New bound | Evidence |
|---|---|---|
| All three seven-step (4,4) return branches, arbitrary changes, initial L >= 2 | R <= 90 + max(0,ceil((14-L)/3)) <= 94 | [Complete proof](contributions/2026-10-14-component-specific-bound/COMPONENT_SPECIFIC_BOUND.md) |
| Full outer sequence (4,8,16,7,15,6,13), initial L >= 1 | R <= min(98,94+max(0,ceil((14-L)/3))) | [Full scope and evidence](coordination/2026-10-14-component-bounds-results.md) |
| Exact child-job recursion | 31 independently checked jobs, 128,234 vertex records and 212,453 edges; seven new generic formal declarations. Numerical application remains separately certified. | [Root review](contributions/2026-10-14-component-bound-root-review.json), [formal recursion](contributions/2026-10-14-component-hierarchy-formal/README.md) |

## All-base seam symmetry and interval safety

| Result | Exact scope | Evidence |
|---|---|---|
| Raw symmetry iff actual palindromicity | Every base b >= 3, arbitrary consecutive partition, actual final reflection width. Either symmetry forces E=D and no active seam. | [Complete written proof](contributions/2026-10-14-general-base-seams/GENERAL_BASE_SEAMS.md) |
| Interval carry-mismatch safety | Any two nonempty intervals with positive terminal coefficients; no symmetry/disjointness requirement. Positive-terminal hypothesis essential. | [Final independent review](contributions/2026-10-14-general-base-seams/independent_interval_review.json) |
| Full controls and supporting formal step | 58,221 decimal controls; 22,154 all-base controls and 52,734 independent block responses; nine Lean supporting declarations. Six binary failures retained. Full polynomial theorem remains written proof. | [Root review](contributions/2026-10-15-seam-base-root-review.json), [formal scope](contributions/2026-10-14-base-uniqueness-formal/README.md) |

## Accepted continuation: intrinsic seams and finite-seed quantifiers

| Finding | Established scope and remaining limit | Evidence |
|---|---|---|
| Intrinsic carry-defect criterion | For any finite word in 0..18, some active partition defect iff an adjacent coefficient >=10 is followed by 9, in low-to-high order. Singleton blocks maximize all defect coefficients. Canonical ordinary inputs get one-step safety; temporal closure is not supplied. | [Formal status and sources](research/main_existence_attempt/continuation_pass/lean/STATUS.md) |
| Arbitrary-width seam annihilation | Q_k=(10,9^k,10) has defect mass k and zero defect in every partition after one update. Every canonical realization for even k>0 first hits a palindrome at time 2. Initial mass alone cannot persist. | [Lean source](research/main_existence_attempt/continuation_pass/lean/SeamAnnihilation.lean), [independent audit](research/main_existence_attempt/continuation_pass/root_review/lean_rebuild.json) |
| Finite-seed extraction countermodel | For every prescribed finite horizon there exists a fully terminating artificial map sharing the stated exact predecessor set, growth, density and pair-word quotient properties. It is not actual reverse-and-add outside the stated agreement set; it identifies an insufficient set of extraction premises. | [Written proof](research/main_existence_attempt/continuation_pass/finite_seed/FINITE_SEED_OBSTRUCTIONS.md), [root review](research/main_existence_attempt/continuation_pass/root_review/finite_seed_review.json) |
| Safe inverse-fiber weight obstruction | Actual reverse-and-add has 9*10^(m-2) safe predecessors for the stated targets. No positive seed-size-nonincreasing weight admits a uniform finite incoming-fiber multiplier on the whole safe set. Other weights and restrictions remain open. | [All-parameter proof and exact finite audit](research/main_existence_attempt/continuation_pass/finite_seed/FINITE_SEED_OBSTRUCTIONS.md) |
| Fixed-target ancestry bound | Any t-step ancestor of p of width M satisfies t<=min(p-1,5M-1). This is a consequence of earlier growth results, not an existence theorem or exclusion of varying-target inverse constructions. | [Proof and scope](research/main_existence_attempt/continuation_pass/finite_seed/FINITE_SEED_OBSTRUCTIONS.md) |

The two new formal modules contain 31 supporting theorem declarations and 5 definitions, all audited with the three standard logical axioms. The written finite-seed results are not Lean formalizations. Decimal Lychrel existence and the 196 claim remain unproved.

## Sharp clock kernel proof and external symmetry replay

| Result | Exact scope | Evidence |
|---|---|---|
| Complete actual-orbit no-four-return theorem | Every admissible width at least six; all 96,026 local inputs and 6,859 initial bounds kernel checked; full endpoint-to-clock and descent proof. At most 26 clock steps and three seven-step returns. | [Formal proof and provenance](contributions/2026-10-14-seven-step-extension-formal/README.md) |
| Independent rank/source lineage review | Complete table/domain/edge coverage and repaired dependency-sensitive resume controls; final frozen-build reconciliation explicit. No claim of a second full finite kernel run. | [Rank review](contributions/2026-10-14-rank-review/RANK_REVIEW.md) |
| Reciprocal external raw-symmetry audit | Fresh exact 4c3970c source and both dependencies; all 42 target declarations audited. Not all 135 renewal declarations, no infinite safety invariant. | [Independent audit](contributions/2026-10-14-external-renewal-audit/REVIEW.md) |

## Whole-word bounded-state language exclusion

| Finding | Exact scope and limit | Evidence |
|---|---|---|
| At most four complete pair-reading states excluded | No nonempty safe forward-closed canonical folded decimal language with at most four deterministic reading states and eleven center/end predicates. Initial and dead states count. Both overflow cases included; no fixed seed or clock. Written all-width reduction plus audited CNF and checked primary LRAT refutation, without renaming assumptions. No new Lean claim. | [Proof and reduction](research/main_existence_attempt/continuation_pass/safe_language/METHOD_AND_PROOF.md), [root replay](research/main_existence_attempt/continuation_pass/root_review/safe_language_review.json) |
| Five-state capped continuation | UNKNOWN after 180 seconds. Complete formula, solver log and incomplete proof trace retained losslessly. No five-state or unrestricted regular-language exclusion follows. | [All outcomes](research/main_existence_attempt/continuation_pass/safe_language/OUTCOMES.json), [six-artifact archive manifest](research/main_existence_attempt/continuation_pass/safe_language/evidence_parts/MANIFEST.json) |
| Exact finite labels and unclassified inputs | All 3,706 terminating labels have complete replayed trajectories. The other 263 short words have full 60-addition UNKNOWN trajectories and impose no exclusion label. | [Status and controls](research/main_existence_attempt/continuation_pass/safe_language/STATUS.md) |

## Shared seam obstructions and formal bridges

| Result | Exact scope | Evidence |
|---|---|---|
| Seam mass does not imply renewal | Every base at least three; explicit nonpalindromic seeds with arbitrarily large active mass and first palindrome time two. Builds on the independently convergent external decimal family. | [Proof and 185 independently replayed controls](contributions/2026-10-15-seam-persistence-obstruction/SEAM_PERSISTENCE_OBSTRUCTION.md) |
| Exact high-region second-step test | Decimal canonical pair coefficients 9..18, outside at least 10: second output palindrome iff every adjacent sum is at most 27. All-base threshold 3b-3 separately written. | [13-theorem actual-integer Lean proof](contributions/2026-10-15-high-carry-reduction-formal/README.md) |
| All-base reflection and numeric bridge | Reset normalization, actual canonical width, raw symmetry equivalence and outgoing defect safety; one-step ordinary integer representation. No infinite iteration claim. | [58 new core declarations](contributions/2026-10-15-base-reflection-formal/README.md), [15 new numeric declarations](contributions/2026-10-15-base-reverse-add-formal/README.md) |
| Interval detection is exactly singleton mismatch | Arbitrary positive-terminal intervals; 15 safety declarations and 12 exact-reduction declarations. Longer intervals do not enlarge existential detection. | [Reduction](contributions/2026-10-15-overflow-mismatch-reduction-formal/README.md) |
| Every scalar-clock phase and offset | Written bound 98; 35 new actual-transition/growth/conditional-transfer Lean declarations. Wide-word numerical bound remains an explicit formal premise. | [Rotations](contributions/2026-10-15-clock-rotations/CLOCK_ROTATIONS.md), [formal scope](contributions/2026-10-15-scalar-clock-formal/README.md) |
| Reciprocal external continuation review | Exact e521255 intrinsic/annihilation source and finite-seed mathematical review; no new 31-theorem compile or catalog replay. | [Source review](contributions/2026-10-15-external-intrinsic-review/REVIEW.md), [finite-seed review](contributions/2026-10-15-external-finite-seed-review.md) |

## Accepted weight and free-clock mechanism follow-ups

| Finding | Exact scope and remaining limit | Evidence |
|---|---|---|
| Positive folded local weights fail | Exact binary safe fibers make every positive coefficient-product or fixed translation-invariant finite-window product weight have unbounded incoming ratio, even with arbitrary width-only factors. Does not cover other weight classes or deeper image restrictions. Written all-parameter proof with root-replayed rational controls. | [Proof and exact controls](research/main_existence_attempt/continuation_pass/finite_seed/FOLDED_WEIGHT_OBSTRUCTION.md), [review](research/main_existence_attempt/continuation_pass/root_review/folded_weights_review.json) |
| Every attainable seam mask and typed birth/transport | Each active maximal 9-run contributes an arbitrary terminal suffix; all masses from zero to total active length occur. Exact transport and 4/14/non-9 birth laws; mass or adaptive partitioning alone does not persist. | [Written proofs and complete controls](research/main_existence_attempt/continuation_pass/seam_persistence/METHOD_AND_PROOF.md) |
| Two-band variable-clock quotient | Exact all-gap transition; a valid cycle would have positive gap gain and imply a concrete infinite safe family. No cycle found. Complete graph from 1,705 stated seeds has 4,083 states and rank at most 22; for gaps>=10 all leave this tracked mechanism. No exclusion of larger interfaces or later regeneration. | [Proof and full graph](research/main_existence_attempt/continuation_pass/seam_persistence/METHOD_AND_PROOF.md), [root replay](research/main_existence_attempt/continuation_pass/root_review/seam_persistence_review.json) |
| Four-band two-parameter extension | Exact update; a successful cycle requires nonnegative gain in each gap. Complete graph from 765 singleton seeds has 1,389 states and rank at most 19, without reaching caps. For g,h>=10 all leave this mechanism. No general regular-language or decimal termination conclusion. | [Proof, certificate and witness](research/main_existence_attempt/continuation_pass/safe_language_followup/METHOD_AND_PROOF.md), [review](research/main_existence_attempt/continuation_pass/root_review/four_band_review.json) |
| Sharp three-zero exterior time bound | For actual positive decimal orbits, pair prefix (p,0,0,0), p>0, forces time<=4; prior history is no-overflow and outside doubling. Same positive outside symbol cannot return later with that exterior. Two-zero overflow counterexample retained. | [Lean scope](research/main_existence_attempt/continuation_pass/lean/zero_exterior/STATUS.md), [independent audit](research/main_existence_attempt/continuation_pass/root_review/zero_exterior_review.json) |

## All-base intrinsic carry-defect criterion

The [new formal package](contributions/2026-10-15-base-intrinsic-formal/README.md)
extends the external e521255 decimal theorem, with explicit attribution.
For b>=2, partition-defect existence is exactly a high/neutral adjacent pair,
and singleton partitions maximize all outgoing-carry defects. For b>=3, the
canonical numeric reverse-add bridge certifies a nonpalindromic output.
Binary output safety fails; odd-base input nonpalindromicity is not asserted.
The 27 new declarations and 82 prerequisites pass fresh standard-axiom audits.
This is a one-step theorem, not a persistent invariant.

## Actual hierarchy interfaces and construction obstructions

| Result | Exact scope | Evidence |
|---|---|---|
| Actual hierarchy path construction | Actual whole-word child intervals and carry-bit finite encoding; 26 new Lean theorems, original label-nine interface obstruction retained. Numerical 94/98 tables remain uninstantiated. | [Adapter and hierarchy](contributions/2026-10-15-bounded-prefix-lift-formal/README.md) |
| High-carry local regeneration | Exact mixed-certificate regeneration and sharp at-most-two bound for the stated restricted two-step return condition. Written all-parameter proof, independent controls. | [Renewal proof](contributions/2026-10-15-high-carry-renewal/HIGH_CARRY_RENEWAL.md) |
| Neutral-exterior overflow obstruction | Every base at least two: a symmetric neutral exterior that overflows produces a pair coefficient below neutral. Any two-step high-region return therefore has a nonoverflowing second addition. Written proof and 22,773 independent controls. | [Neutral exterior](contributions/2026-10-15-neutral-exterior-overflow/NEUTRAL_EXTERIOR.md) |
| Congruence-preserving delayed paths | Artificial finite paths preserve stated residues/growth/predicates; true first and last steps. The sparse jump violates genuine carry budget for every parameter at least three. | [Written proof and complete paths](contributions/2026-10-15-congruence-family-obstruction/CONGRUENCE_PATHS.md) |
| External four-state source review | Exact all-width proof and generator/checker review at fbbef306. No third LRAT replay; five-state UNKNOWN unchanged. | [Reciprocal review](contributions/2026-10-15-external-four-state-review/REVIEW.md) |

## Positive gate and variable-return limits

| Finding | Established scope and limit | Evidence |
|---|---|---|
| All-gap +4 neutral-band gate | Actual no-overflow identity for every g>=0, with two safe positive outputs; zero gap creates bands. The originating family has nine safe steps but the time-nine candidate return fails by an exact second-column mismatch. Written proof and independent sparse-polynomial controls; the separately audited formal gate is indexed below. | [Gate proof](research/main_existence_attempt/continuation_pass/variable_return/POSITIVE_REGENERATION_GATE.md), [root replays](research/main_existence_attempt/continuation_pass/root_review/variable_return_review.json) |
| Variable-time additive affine reduction | A safe variable-time return covering a tail of one fixed finite affine family with additive parameter update forces a fixed safe return time on a tail. Does not cover multiplicative maps or expanding run catalogues. | [Written theorem](research/main_existence_attempt/continuation_pass/variable_return/VARIABLE_RETURN_THEOREMS.md) |
| Exact 180-template r+1 reset exclusion | All source/target templates, all r>=1 and all positive times excluded for the stated spacer r+1 target. Width potential reduces times to <=12; complete affine comparisons and literal boundaries retained. | [Scope and certificates](research/main_existence_attempt/continuation_pass/variable_return/STATUS.md) |
| Broader mixed-band graph | Complete reachable DAG: 22,382 seeds, 83,679 states, 69,057 edges, rank<=50; no cap reached. Regeneration occurs but no cycle arises in this initial family. For gaps>=23, loss of the mechanism is bounded; loss does not mean palindrome. | [Full graph and independent checker](research/main_existence_attempt/continuation_pass/variable_return/STATUS.md) |
| Finite multiplicative and prefix probes | 5,400 finite multiplicative inputs, 493,927 additions, no tested target matches; exact fixed-width prefix graphs retained. These are not all-r multiplicative exclusions or infinite-safety proofs. | [All attempts and limits](research/main_existence_attempt/continuation_pass/variable_return/ATTEMPTS.json), [status](research/main_existence_attempt/continuation_pass/variable_return/STATUS.md) |

| Additional accepted finding | Exact scope and remaining limit | Evidence |
|---|---|---|
| Formal actual +4 gate | Every natural gap including zero: exact no-overflow pair successor, positive ordinary realizations, and nonpalindromicity at times 0,1,2. 29 supporting theorems and 5 definitions audited. Changed target interfaces supply no recurrence. | [Formal scope](research/main_existence_attempt/continuation_pass/lean/regeneration_gate/STATUS.md), [root audit](research/main_existence_attempt/continuation_pass/root_review/regeneration_gate_review.json) |
| Maximal 0/18-run ancestry | Exact boundary erosion and no-merging law, including singletons/endpoints. One initial length-ell ancestry dies within 5ell updates; new births can occur. Central-18 special case is prior work. No whole-orbit extinction or palindrome claim. | [Written proof and complete controls](research/main_existence_attempt/continuation_pass/seam_persistence/followup_absorbing_core/ABSORBING_CORE.md), [root review](research/main_existence_attempt/continuation_pass/root_review/absorbing_core_review.json) |
| Periodic guarded whole-word quotient | Exact all-exponent guard-period identity and conditional cycle criterion. Necessary 59/878/7024-state graphs do not supply a finite exterior lift. All eleven 128-step capped whole-word paths remain UNKNOWN, with every symbolic/ordinary outcome retained. | [Proof and limits](research/main_existence_attempt/continuation_pass/periodic_bulk_followup/METHOD_AND_PROOF.md), [root replay](research/main_existence_attempt/continuation_pass/root_review/periodic_bulk_review.json) |

## Complete high-region return obstruction

| Result | Exact scope | Evidence |
|---|---|---|
| Sharp at most three two-step returns | Every canonical decimal width, full high region; exact carry/neighbor iff. Actual sharp seed 80999 is palindromic at time 2, so safe-three sharpness stays UNKNOWN. | [Written actual-orbit proof](contributions/2026-10-15-full-high-return/FULL_HIGH_RETURN.md) |
| Kernel finite rank certificate | Five Std-only Lean theorems check the complete 900-state/1,800-control necessary relation, 258 edges, maximum rank 3. Actual-map bridge is not formalized in this package. | [Formal scope](contributions/2026-10-15-high-return-rank-formal/README.md) |
| External band and exterior reviews | Exact 60d434 source/written reviews; no repeated graph replay or fresh exterior compile. Conditional cycles remain uninstantiated. | [Band review](contributions/2026-10-15-external-band-review/BAND_REVIEW.md), [exterior review](contributions/2026-10-15-external-zero-exterior-review/REVIEW.md) |

## Final accepted results and incomplete scalar checkpoint

| Item | Status and exact scope | Evidence |
|---|---|---|
| Single absorbing-run ancestry | Accepted written corollary: extinction by `4*ell-3+psi(p_0)<=4*ell+1`; no global extinction or optimality claim. | [Bound and attribution](contributions/2026-10-15-ancestry-potential-bound/ANCESTRY_BOUND.md) |
| Complementary nonneutral bulk | Accepted written all-gap two-coordinate formulas and conditional cycle criterion; 31,360 retained integer controls. No cycle search or qualifying cycle. | [Whole-word proof](contributions/2026-10-15-complementary-bulk-quotient/METHOD_AND_PROOF.md) |
| Conditional scalar wrappers | Fresh 66-declaration report includes eight new wrappers, each numerical conclusion retaining the explicit root-certificate premise. | [Exact scope](contributions/2026-10-15-scalar-period-composition/README.md) |
| Concrete scalar numerical Lean instance | IN PROGRESS: 15 fresh modules completed, Data6 interrupted with exit130, no production row checks, no final combined audit. Unconditional 659/94/98 Lean endpoints unaccepted. | [Partial checkpoint and continuation](contributions/2026-10-15-scalar-finite-certificate-formal/README.md) |

## Seven-column prefix extension — 15 October 2026

| Result | Evidence and scope |
|---|---|
| [739 exclusion and four improved bounds](contributions/2026-10-15-seven-column-prefix/P196_739_Proof.md) | Written all-length carry coverage plus five checked finite rank certificates. Every palindrome beginning 739 has ancestry height at most 39; 196's first 39 steps then exclude this family at every time. Bounds for 217/218/620/777 improve to 23/34/12/25. The baseline prefix list grows from 396 to 397; no sharpness, Lean, novelty or main-conjecture claim. |
| [Development and incomplete searches](contributions/2026-10-15-seven-column-prefix/development/README.md) | Original scripts, four-/five-column graphs, raw capped/interrupted searches and 33/77 rediscovery certificates retained. The 33/77 results were already in the baseline and are not new. CAP and interrupted branches remain incomplete. |

## Agent #107 completed arbitrary-partition seam response

| Finding | Exact accepted scope | Evidence |
|---|---|---|
| Full seam response and its actual integer bridge | Finite coefficient identity including terminal carry; initial-nine-run support; digit/pair mass losses 9/18; same-clock raw pairing exact iff every defect vanishes. Canonical hypotheses retain the ordinary-integer interpretation. One update only, with no regenerative or infinite-time conclusion. | [Seven-module package](contributions/agent-107/partition-seam-response/README.md), [independent clean rebuild and statement review](contributions/agent-107/partition-seam-response/review/REVIEW.md), [merged-source build](contributions/agent-107/partition-seam-response/integration/verification.json) |

This entry completes the corresponding written-only universal seam response
interfaces in the historical collision-response report. Counts of 66 audited
public declarations describe coverage, not 66 distinct major results.

<!-- BEGIN AGENT104 REVIEWED INTEGRATION -->
## Agent 104: exact 739 Lean endpoints and separate bridge review

The independent fresh merged-source verification is **PASS** for the published candidate `4bdd59bdc8f3e8f0556c3decb0898e6c6f271b29`; the current 383 accepted source pins remain identical.

| Result | Exact scope | Evidence |
|---|---|---|
| 739-prefix palindrome ancestry | Every positive ordinary decimal seed A: if orbit A t is a palindrome beginning 739, then t ≤ 39. No width bound or finite-check premise remains. Attainment and optimality are not asserted. | [Exact theorem types and pins](contributions/agent-104/seven-column-kernel/integration/HANDOFF.md), [completed independent acceptance](contributions/agent-104/seven-column-kernel/review-final/acceptance.json) |
| Restricted-family avoidance by 196 | At every time t, orbit 196 is not a palindrome beginning 739. This does not settle P196. | `SevenColumnKernel.Finite739.no_196_739_palindrome`; same evidence |
| Terminal pair-sum obstruction | Positive-time admissible pair-word states of width at least three avoid leading pair sums [1,9,6]. These are pair sums, not the decimal digits of 196. | [TerminalObstruction.lean](contributions/agent-104/seven-column-kernel/TerminalObstruction.lean); same complete source rebuild |
| Independent review of Agent 4's whole-word bridge | The six `P196.Agent4.WholeWord` exports at source `4ffba5a60b6089075f6e3e4ab5952eb6bc46a4d7` passed semantic review and a five-module fresh build. Their actual-return-time divisibility conclusion retains the saturated-width-growth hypothesis. | [Review acceptance](contributions/agent-104/review-agent4-whole-word/execution/acceptance.json), [semantic scope](contributions/agent-104/review-agent4-whole-word/semantic/SEMANTIC_REVIEW.md) |

The 7,469 theorem constants are audit coverage, not a count of independent
results. The earlier seven-column written/Python record remains historical;
only its 739 formalization status is superseded. Concurrent files appear in
the byte inventory without acquiring a new mathematical acceptance label.
<!-- END AGENT104 REVIEWED INTEGRATION -->

<!-- BEGIN AGENT116 REVIEWED CAP3 -->
## Agent 116: certificate normalization and exact cap-three bounds

| Lean result | Exact scope | Verification |
|---|---|---|
| `Agent116.CertificateExterior.accepted_exceeds_three` | Original checker acceptance alone implies some maximally trimmed exterior has length at least four; all periods and internal blocks are allowed. | [Source and full review](contributions/agent-116/review/REVIEW.md) |
| `check_eq_false_of_normalized_cap_three`, `check_eq_false_of_raw_cap_three` | Every candidate satisfying the stated cap is rejected, including the empty candidate. | Same reviewed aggregate |
| `P196.Agent116.Cap3.cap3_exit_witness` | Valid eight-phase bounded exterior of length at most three exits within nine updates; `(8,[11,9])` attains nine. | Concrete kernel-checked batches and completeness proof |
| `P196.Agent116.Cap3.cap3_all_exit_witness` | Without positive-head or canonical-trim restrictions, the bound is ten; `(6,[0])` attains ten in this relaxed domain. | Separate complete kernel-checked batch assembly |
| `Agent116.ActualCap3.lychrel_cap3_exit` | Bounded ordinary decimal template with valid exterior and both bands at least eighteen: its specified exterior grows beyond three by actual time nine. | Formal correspondence to `Lychrel196.orbit` |

The 1,991 audited constants measure coverage, not independent discoveries.
All finite certificate hypotheses used by these endpoints are discharged in
Lean; the Python scan is only an independent diagnostic. None of these results
constructs an accepted cyclic certificate or settles 196.
<!-- END AGENT116 REVIEWED CAP3 -->

<!-- BEGIN AGENT110 REVIEWED PR39 -->
## Agent 110: exact accepted endpoints and evidence levels

Write `O = totalGam cert`, `Dg = totalG cert`, `Dh = totalH cert`, and `P = cert.P`.
The totals use the original raw formulas and certified trim counts; a local
signed gap increment may be negative. Six-phase membership is precisely
`{2,4,8,16,14,10}`.

| Endpoint or record | Hypotheses | Conclusion and scope |
|---|---|---|
| `Agent110.Checked.six_phase_constraints` | `check cert = true`; initial `SixPhase` | `O=2*(Dg+Dh)`; `Dg,Dh>=0`, each divisible by 9; `O>=18`, divisible by 18; `2*O<=P<=4*O`; `P%6=0`; `P>=42`. No separate admissibility, head positivity, arithmetic-budget, maximal-trim or width-cap premise. |
| `Agent110.Checked.saturated_period_constraints` | The preceding checker and phase premises; additionally `2*O=P` | `P%72=0` and `P>=72`. |
| `Agent110.Checked.period_at_least_four` | `check cert = true` only | `P>=4`, all phase classes. A two-phase lower bound of 12 is not established here. |
| `Agent110.RadixExterior.no_autonomous_radix_factor` | A proposed update on `(c,Z)` representing every exact step on canonical states reached after overflow | Contradiction: equal observations have different next observations. |
| `Agent110.RadixExterior.no_overflow_strict_radix_observable` and integer corollary | Potential depends only on `(c,Z)`; specified weak progress, strict progress at actual overflow and relation laws | Contradiction from a two-step observation return containing an overflow. The exterior states do not return. |
| Eight bounded exterior SAT runs | Exact recorded width/phase/period/overflow settings and short solver caps | Five unverified solver UNSAT reports and three UNKNOWN; no formal exclusion or cycle. |

[Checked semantic review](contributions/agent-110/review-checked/SEMANTIC_REVIEW.md) discharges
the checker-to-arithmetic interface using Agent112's automatic-admissibility
theorem from three byte-exact dependency snapshots. Its independently rebuilt
19-module closure includes Agent4's existing saturation certificate; previous
conditional work is reused with attribution. The phase-padded three-column
prefix is an exact formal transition quantity, not an unconditional assertion
about physical prefix columns at gap two. [Radix review](contributions/agent-110/review-radix/REVIEW.md)
is confined to its specified observable. Full exterior no-return remains open.
<!-- END AGENT110 REVIEWED PR39 -->
