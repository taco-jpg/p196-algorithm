# Read-only ownership and semantic deduplication review

## Decision for the current proposal

No equivalent reservation for the narrowly stated **U/S integer carry code and `J = 0` iff the complete binary carry word is symmetric** was identified in the complete 162-record coordination snapshot or its seven-record first delta. This is a bounded ownership finding, not a global mathematical novelty certificate and not a task claim.

The initially considered T/R fixed-width coefficient-code injectivity proposal is **excluded from the current session's scope**. The parent reported a newer Agent14 issue61 proposal and its own explicit withdrawal/cession at [issuecomment-6226185223](https://github.com/taco-jpg/p196-algorithm/issues/61#issuecomment-6226185223). That issue event is parent-relayed evidence; it is not one of the 162 baseline records and was not independently fetched by this scout. Consequently the earlier snapshot-level absence of a T/R task must not be used as permission to claim T/R now.

The current proposed scope, as supplied by the parent, is limited to:

- Integer sequences `U(0)=0`, `U(1)=1` and `S(0)=1`, `S(1)=21`, each obeying the original recurrence `a(n+2)=20*a(n+1)-a(n)`.
- The exact odd/even integer charge computed from the complete finite **binary outgoing-carry word** in the original `carry_coordinates` routine.
- The charge vanishes exactly when that complete word equals its reversal, with both length parities retained.

T/R coefficient-code injectivity, support of carry asymmetry on coefficient9, H, the four evolution cases, algebraic beta interpretation, the universal ideal/1782 quotient, persistence, ordinary-orbit closure and any 196 conclusion are outside this proposed scope. The parent remains the sole prospective remote writer. No source implementation, mathematical experiment, proof, branch reservation or remote write was performed by this scout.

## Exact coverage and preservation

| Item | Evidence |
| --- | --- |
| Repository | `taco-jpg/p196-algorithm` |
| Baseline coordination commit | `b0ee3d25fb1ddea0f741326b6401d81ae3d27626` |
| Source-main context | `5ff4f607535587d572fbc9e95ba9501d1fbe5fc5` |
| Baseline task paths | All 162 paths in the supplied `coord-task-listing.json` |
| Complete API fetches | 162 successful `GitHub.fetch_file` responses |
| Original saved content | 162 parsed JSON records; 609,229 UTF-8 bytes |
| Returned blob identities | 162/162 equal the supplied listing |
| Recomputed Git blob SHA-1 | 162/162 equal the supplied listing |
| Missing/failed baseline records | None |
| First delta endpoint | `d8aab676e88fa0a42a3a660687e4a7a4d26e64c4` |
| First delta read | Seven complete changed versions: six existing paths and one new path |
| Recomputed delta blob SHA-1 | 7/7 match the parent-provided exact contents |
| Total preserved versions | 169 versions across 163 distinct paths |

All baseline original JSON bytes are in `tasks/`. The original connector responses are retained in seventeen `fetched-batch-*.json` files. `fetch-manifest.json` records exact task paths, expected/returned blobs and immutable source URLs. The compact English index is `INDEX.md`; `semantic-index.json` retains original statement, source, dependency, interface, branch, status and exclusion fields. The latter is a detailed reference index, while the Markdown table provides the compact reading surface. `delta-01/` and `delta-01-review.json` preserve the later versions without overwriting the baseline. `build_index.py` reproduces this metadata extraction and byte verification; it contains no mathematical experiment.

Status and verification strings in these artifacts are attributed to their task records. They were not promoted to independently executed Lean acceptance. Active, stale, blocked, integrated and released records were all considered during deduplication. A blocked source package or an ended execution does not by itself authorize takeover.

## Source identity and the carry-word interface

The original source references below were read from the source scout's preserved manifest and exact local copies. The original script was inspected, not executed.

| Original source at the supplied main commit | Exact Git blob |
| --- | --- |
| `proofs/archive/source-trees/2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5/proofs/research/creative_global_spectral_notes.md` | `cb1c355fa05916a770816a4d5ef680e54079cccb` |
| `proofs/archive/source-trees/2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5/proofs/research/creative_global_spectral.py` | `730acd722bf017b6bf1e51e5a0411169a7804da4` |
| `proofs/archive/source-trees/2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5/proofs/research/astra_spectral_carry_quotient.md` | `eac5b8f61385a615d9cc3e7796a4d698c66b716b` |

The notes define `c_i` as the carry **leaving** column `i`, with zero incoming carry to the first column. The finite polynomial `C` has length `L` and includes the final outgoing carry `h=c_(L-1)`; the initial zero is not prepended as an additional coefficient. Thus “complete carry word” must preserve this exact L-entry convention rather than silently switching to an L+1 incoming/outgoing list.

The script's `carry_coordinates` uses `m=L//2` and the following exact integer formulas:

- Odd `L`: `J = sum((cs[L-1-i]-cs[i])*U[m-i] for i in range(m))`.
- Even `L`: `J = sum((cs[L-1-i]-cs[i])*S[m-1-i] for i in range(m))`.

The notes explicitly state the vanishing/symmetry equivalence. This supports formalizing that written claim with exact original indexing; it does not establish that any new Lean implementation is already correct. No floating-point or algebraic-real representation is required by the limited proposed interface. The wider spectral recurrence and its missing actual-orbit persistence obligation remain excluded.

## Closest existing scopes and the boundary to preserve

| Existing owner/task family | Actual recorded subject | Relationship to the proposed U/S charge result |
| --- | --- | --- |
| Agent6 `exterior-coordinate-dynamics`, `certificate-coordinate-audit`, `normalized-carry-accounting` | Scalar high-side carry quotient/threshold, signed beta contribution, normalized certificate row carries and gain accounting | Uses an exterior state and its normalization. It does not claim a superincreasing code of the full outgoing binary carry word or J-zero/symmetry. Preserve all carry/strip and certificate interfaces. |
| Agent115 `rho-cycle-balance` | Rational high-observation recurrence and a positive cycle telescope forcing an overflow | Different observable, state space and conclusion; no U/S integer charge in the recorded target. |
| Agent5 digit-stream tasks | Exact low decimal-adic/high fractional stream reconstruction of exterior/ordinary raw prefixes and sharp agreement window | Digit extraction and prefix transport remain owned. They do not encode reversal asymmetry of the full binary carry word. |
| Agent10 `four-smoothing-boundary` | Nine carry-history observations determine active pair sums and the next integer, with a sharp counterexample | Temporal observation threshold across iterates, not a same-word spectral carry-symmetry test. |
| Agent107 folded transducer and DFA/Horn tasks | Exact accepting histories, actual emitted pair word and all-length language closure | Existing scalar emission identities must be reused if needed. The parent/source scout identified the already supplied `actualCoeff_eq_raw` normalization identity; re-proving `E=Q+(x-10)C` is excluded. |
| Agent1 repeated-block normalization | Carry stabilization and symmetric-band specializations for repeated coefficient blocks | Normalization identity on a structured coefficient input, not U/S reversal-charge injectivity. |
| Agent8 `common-overflow-defect` | Paired-successor difference `(1-x^h)e` from an antisymmetric digit defect under equal actual terminal carry | Different signed object and actual two-input transport; no full binary-carry vanishing code. Preserve its finite-difference result. |
| Agent101/105 numerical inverse tasks | Decimal symmetric-value injectivity, canonical digit realization fibers, numerical decoder and predecessors | Ordinary base10 profile/numeral coding differs from U/S charge. Their generic profile and realization endpoints remain excluded. |
| Agent108 positive-window and positive-matrix weights | Weighted full safe incoming fibers and exponential original-family mass obstruction | Positive family weights and incoming sums, not a signed carry-reversal code. No matrix/scalar/window result is being reclaimed. |
| Newer Agent14 T/R proposal, parent-relayed | Fixed-length lossless coefficient code using T/R | Explicitly preserved outside current scope, despite absence from the older 162-record snapshot. |

This comparison used the original semantic target fields, related interfaces and exclusions, not only task names. A full-text check for spectral, quadratic, carry-blind,1782, superincreasing and the specific sequence seeds found no baseline record naming the proposed spectral family. Separate targeted checks for carry symmetry, injectivity, encoding and observables surfaced the neighbors above. The ownership conclusion rests on their actual statements rather than on a keyword absence alone.

## First-delta disposition

The complete first delta changes five Agent103 residual-five records, Agent6 normalized-carry accounting, and adds Agent11's PR126 manifest-pointer erratum. The six existing targets are unchanged. Agent103 status/evidence and remaining-work descriptions advance; Agent6 becomes REVIEWED and mentions an independently proposed adaptive safe horizon without claiming it in this record. The new Agent11 task is an additive evidence-manifest correction only. None reserves U/S carry charge or J-zero/symmetry.

## Ownership ambiguities that must remain explicit

The baseline contains two older Agent15 records, `agent15-fourth-column-temporal-obstruction` and `agent15-sixphase-temporal-profile`. They concern a bounded fourth-column lift checker/catalog and six-phase visit indexing respectively. Both retain ACTIVE labels and earlier source/branch history. Neither becomes current-session property by numeric identity.

Several neighboring mathematical areas have overlapping older records or multiple sessions: general-base normalization involves Agent4, Agent421 and Agent422; finite-ensemble extraction appears under several historical owners; two Agent100 sessions have distinct targets. This census preserves those identities and exclusions without adjudicating transfers. Agent4's General/Nat helper record explicitly declares nonexclusive support and retains Agent216's full correspondence ownership. None of these ambiguities licenses a duplicate new claim.

## Review limits and next gate

There are no gaps in the pinned 162-path task census or the seven-record first delta. This scout did not independently fetch every issue61 comment, inspect every branch/archive source, execute any proof, establish unrestricted mathematical novelty, or inspect coordination changes after `d8aab676e88fa0a42a3a660687e4a7a4d26e64c4`. The parent handles current issue deltas, live coordination refresh and optimistic-concurrency publication/readback. Until that succeeds, the U/S target remains a proposed scope rather than a claimed task.
