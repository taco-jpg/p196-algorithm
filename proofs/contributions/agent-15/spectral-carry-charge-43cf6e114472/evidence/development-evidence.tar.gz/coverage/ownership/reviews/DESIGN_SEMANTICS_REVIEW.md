# Independent semantic review of the proposed U/S carry-charge design

## Result and review identity

**PASS for the supplied mathematical design and its exact correspondence to the original integer formula.** No sign, orientation, parity or boundary mismatch was found. This report is a genuine nonauthor semantic review by the ownership scout. It is not a Lean build report and does not certify a Lean implementation that has not yet been inspected.

The parent reported a successful current-session reservation at coordination commit `9ff01fb85383833abe440d7f41bc7c249c332070`, with task-file blob `70340af5e48d1c965d012180c04bc6ea01f90b21`, before authorizing this review and its finite executable controls. This claim is parent-reported here; the original preclaim census report remains preserved as a historical snapshot. The reviewer did not edit proof code, original sources, task records, Git branches or remote state.

## Design reviewed

The parent supplied the following definitions in prose:

`eval w [] = 0`

`eval w (a :: xs) = (a : Int) * w(xs.length) + eval w xs`

The input order is outermost to innermost. For a finite complete carry word `cs`, set `L=cs.length`, `m=L/2`, use `oddWeight(n)=U(n+1)` if L is odd and `evenWeight(n)=S(n)` if L is even, and define:

`charge(cs) = eval chosenWeight (cs.reverse.take m) - eval chosenWeight (cs.take m)`.

The endpoint is `charge(cs)=0` iff `cs.reverse=cs`, under the explicit binary-coefficient hypothesis on the complete word. Both halves are compared at the same length. Integer subtraction is essential for the signed charge; a natural subtraction would change the design.

## Original source identity

The source script inspected is the unchanged `creative_global_spectral.py` at original archive path:

`proofs/archive/source-trees/2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5/proofs/research/creative_global_spectral.py`

The source context is main commit `5ff4f607535587d572fbc9e95ba9501d1fbe5fc5`; its Git blob is `730acd722bf017b6bf1e51e5a0411169a7804da4`. The reviewer recomputed that Git blob directly before the executable comparison. The file's SHA-256 is `393545516c13d41c0416e560ec37bab6b1c1655357ae351b0f960dea76ff7448`.

The companion `creative_global_spectral_notes.md`, blob `cb1c355fa05916a770816a4d5ef680e54079cccb`, explicitly states that the integer weights defining J dominate smaller weights and that J vanishes exactly when the carry polynomial is reciprocal. The notes define each `c_i` as the outgoing carry of column i and include the final outgoing carry in the length-L word. The initial incoming zero is separate. This convention is preserved by the proposed design.

No original experiment was reported as having been rerun. The reviewer loaded the unchanged script with a non-main module name to access its existing routine; its main exhaustive/random experiment was not invoked.

## Exact formula and sign

For a word of length m, the recursive evaluator assigns its ith coefficient the weight `w(m-1-i)`. This follows directly from the remaining tail length in the recursive clause. Consequently the left half receives coefficient `cs[i]` and the reversed right half receives `cs[L-1-i]` at the same weight.

| Length branch | Proposed per-pair weight | Original `carry_coordinates` weight | Sign |
| --- | --- | --- | --- |
| Odd L | `oddWeight(m-1-i)=U(m-i)` | `U[m-i]` | `cs[L-1-i]-cs[i]` |
| Even L | `evenWeight(m-1-i)=S(m-1-i)` | `S[m-1-i]` | `cs[L-1-i]-cs[i]` |

These match the original formula exactly. In the odd branch the smallest used weight is U(1)=1, not U(0)=0. The shifted odd sequence is therefore necessary. In the even branch the smallest used weight is S(0)=1. Swapping the two evaluations would negate J; that would preserve a vanishing-only endpoint but would fail the exact original charge and the +419 control. The supplied design uses the correct sign.

The original sequences satisfy the same second-order integer recurrence. Their initial terms are U(0)=0, U(1)=1 and S(0)=1, S(1)=21. The proposed design does not claim the coefficient-code T/R definitions or their fixed-width injectivity, which remain outside the current task.

## Binary evaluation injectivity: semantic conditions

For fixed length, binary coefficients and a strictly superincreasing positive weight sequence, the weighted evaluator is injective. The review of the intended argument identifies two conditions that the actual Lean theorem must retain:

1. The compared lists have equal length. Different-length all-zero lists have the same evaluation, so unrestricted list injectivity would be false.
2. The superincreasing property applies at every relevant index, and the proof has nonnegative weights/tail evaluations available. If the property is globally `weightSum(n)<w(n)` with the standard empty-prefix sum0, positivity can be derived inductively. It need not be added as an unexplained new hypothesis, but the bound argument cannot omit it.

At the first differing binary coefficient, one side has a contribution of the current weight while the other can contribute at most the sum of all smaller weights. Strict domination forbids cancellation. Equal leading coefficients reduce to the equal-length tails. This is a semantic validation of the proposed proof structure, not authorship or kernel acceptance of a Lean proof.

For the charge application, both `cs.take m` and `cs.reverse.take m` have length m because `m<=L` and reversal preserves L. Binary membership is inherited by these halves. Thus generic fixed-length injectivity applies without requiring additional assumptions about the terminal carry, the central carry or whether the word came from a particular integer.

## Half-word equality and complete reversal

The proposed charge vanishes iff the two integer evaluations agree. Under the binary fixed-length injection result, this is equality of the two outer-to-inner halves. Equality of those halves is equivalent to reversal symmetry of the full original word:

- For L=2m, the two halves cover every position. Each position in the second half is the reflection of one already checked in the first half.
- For L=2m+1, the same holds except for the single center position m. Its reflection is itself, so it adds no condition.

This reasoning covers L=0 and L=1 as well: both selected halves are empty and the full word is automatically symmetric. The actual implementation must retain the full word's length/parity rather than computing parity from a half. It must not drop the final carry or prepend an initial carry zero. Those transformations would generally change the reversal condition and the original J formula.

## Executed controls and bounded comparison

After the reported successful claim, the reviewer executed an independent direct weighted-sum implementation of the proposed design against the unchanged original routine. The exact command, exit status and output are preserved in `design-controls-execution.json`; the command completed with exit code0.

| Given complete word | Binary domain | Original and proposed J | Reversal symmetric |
| --- | --- | ---: | --- |
| `[]` | Yes | 0 | Yes |
| `[0]` | Yes | 0 | Yes |
| `[1]` | Yes | 0 | Yes |
| `[0,1,0]` | Yes | 0 | Yes |
| `[0,1,0,0,1,1]` | Yes | 419 | No |
| `[1,0,21,0]` | No | 0 | No |

The last row is an explicit control for the indispensable coefficient restriction. At length4, the two halves evaluate to21 using S(1)=21 and S(0)=1, despite differing as words. It is not an actual binary carry word and is not a counterexample to the stated theorem.

The reviewer also checked every binary word of lengths0 through12: **8,191 words**. For every one, the proposed charge agreed with the original script's J and the zero-charge/reversal predicate agreed. There were no failed cases. This finite comparison resolves concrete sign/indexing and short-boundary risks; it is not a universal proof and it is not evidence that any Lean source compiles.

The two nontrivial binary words were labeled by the parent as the carry controls for196 and187088. This execution checked their literal word charges only. It did not by itself establish Lean theorems extracting these words from those ordinary integers or identifying an actual orbit time. Any published number-specific interpretation needs its own original-definition bridge and kernel evidence.

## Scope and remaining review

The design is a faithful formalization target for the written J-zero/symmetry claim. It does not establish support on coefficient9, the H coordinate, the four evolution laws, algebraic beta interpretation, carry-blind quotient, palindrome avoidance, persistence or any conclusion about196. A generic fixed-length binary code lemma is supporting machinery for this narrow claim; it must not be presented as ownership of Agent14's T/R coefficient-code result.

The remaining independent review is to inspect the actual package contract and frozen Lean definitions/theorem types, verify that they implement this exact design and domain, and reconcile this semantic report with the separate source-pinned kernel/build/axiom evidence. Until that inspection, the result remains **design-level semantic PASS**, with **implementation review pending**.
