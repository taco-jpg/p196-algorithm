"""Build a faithful read-only task census index from preserved GitHub responses.

This script performs metadata extraction and byte verification only. It does not
execute mathematical experiments, modify proof sources, or write remote state.
"""
from pathlib import Path
import collections
import csv
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parent
BASE = "b0ee3d25fb1ddea0f741326b6401d81ae3d27626"
SOURCE_MAIN = "5ff4f607535587d572fbc9e95ba9501d1fbe5fc5"
REPOSITORY = "taco-jpg/p196-algorithm"

def blob_sha(raw):
    return hashlib.sha1(b"blob " + str(len(raw)).encode() + b"\0" + raw).hexdigest()

def sha256(raw):
    return hashlib.sha256(raw).hexdigest()

def select(data, pattern):
    return {key: value for key, value in data.items() if re.search(pattern, key, re.I)}

def owner_of(data):
    for key in ("owner", "owner_agent", "owning_agent", "agent", "agent_id"):
        if key in data:
            return data[key]
    return None

with (ROOT / "english-scopes.tsv").open() as handle:
    summaries = {row["task_id"]: row for row in csv.DictReader(handle, delimiter="\t")}

manifest = json.loads((ROOT / "fetch-manifest.json").read_text())
records = []
for item in manifest["records"]:
    original = ROOT / "tasks" / Path(item["path"]).name
    raw = original.read_bytes()
    data = json.loads(raw)
    assert blob_sha(raw) == item["expected_sha"] == item["returned_sha"]
    summary = summaries[data["task_id"]]
    records.append({
        "task_id": data["task_id"],
        "task_path": item["path"],
        "coordination_commit": BASE,
        "task_git_blob": item["expected_sha"],
        "raw_sha256": sha256(raw),
        "raw_bytes": len(raw),
        "original_record": str(original.relative_to(ROOT)),
        "github_record_url": item["url"],
        "owner_as_recorded": owner_of(data),
        "identity_fields": select(data, r"^(owner|owner_agent|owning_agent|agent|agent_id|session|session_id|role|claim_mode|claim_kind)$"),
        "status_as_recorded": data.get("status"),
        "area": summary["area"],
        "english_scope": summary["english_scope"],
        "exact_statement_fields": select(data, r"^(target_statement|target|scope|claimed_scope|exact_theorem_target|contract|exact_contract|assignment|original_assignment|objective|larger_obligation|completed_scope|scope_limit|scope_boundary|scope_label|result_scope|scope_refinement|correction|completed_support|findings)$"),
        "exact_exclusion_fields": select(data, r"exclusion|excluded_scope|not_claimed|nonoverlap|related_owner|overlap_disclosure"),
        "branch_fields": select(data, r"branch"),
        "source_and_dependency_fields": select(data, r"source|dependenc|current_basis|original_written_statement_blob|historical_source|checked_commit|published_commit"),
        "interface_fields": select(data, r"theorem|declaration|endpoint|interface"),
        "intended_path_fields": select(data, r"intended|owned_paths|new_source_module"),
        "remaining_fields": select(data, r"remaining_obligation|next_action|next_task"),
        "verification_fields": select(data, r"^(verification|verification_status|independent_review|integrated|last_activity|last_activity_utc|last_activity_timestamp)$"),
        "spectral_candidate_relation": "No equivalent U/S binary-carry code or J-zero/symmetry target identified in this record.",
    })
records.sort(key=lambda x: x["task_path"])
assert len(records) == len(summaries) == 162
assert len({record["task_path"] for record in records}) == 162

payload = {
    "schema_version": 1,
    "repository": REPOSITORY,
    "source_main_context": SOURCE_MAIN,
    "coordination_commit": BASE,
    "scope": "All 162 paths in the parent-provided coordination listing, at this immutable commit only.",
    "read_method": "GitHub connector fetch_file in bounded concurrent batches; complete returned UTF-8 content preserved and Git blob SHA-1 recomputed.",
    "ownership_semantics": "All listed scopes were considered irrespective of stale status or numeric agent ID. Status and verification values are attributed task reports, not independent fresh Lean acceptance or a current lease adjudication.",
    "coverage": {"expected_paths": 162, "fetched_paths": 162, "parsed_json": 162, "returned_blob_matches": 162, "recomputed_blob_matches": 162, "fetch_errors": 0, "missing_paths": [], "total_original_bytes": sum(r["raw_bytes"] for r in records)},
    "records": records,
}
(ROOT / "semantic-index.json").write_text(json.dumps(payload, ensure_ascii=False, indent=2) + "\n")

def cell(value):
    if value is None:
        return "Not recorded"
    return str(value).replace("|", "\\|").replace("\n", " ")

lines = [
    "# Coordination ownership scope index",
    "",
    f"Repository: `{REPOSITORY}`. Coordination commit: `{BASE}`.",
    f"Source-main context supplied by the parent: `{SOURCE_MAIN}`.",
    "",
    "All 162 original task records were fetched completely and every recomputed Git blob matches the pinned listing. This table is a compact English semantic index. Exact task paths, blobs, original statements, source pins, branch declarations and interface references are retained in `semantic-index.json` and the linked untouched records.",
    "",
    "Status labels below are copied from the records. They do not independently establish present execution, fresh proof acceptance, or permission to take another task. Integrated, blocked, released and older records were all considered during semantic deduplication. In particular, the older Agent15 records do not belong to the current session merely because the numeric identifier matches.",
    "",
    "## Coverage",
    "",
    "| Measure | Result |",
    "| --- | ---: |",
    "| Expected and fetched task paths | 162 / 162 |",
    "| Successfully parsed original JSON records | 162 |",
    "| Returned Git blob identities matching listing | 162 |",
    "| Git blob identities independently recomputed from saved bytes | 162 |",
    "| Fetch failures or missing paths | 0 |",
    f"| Preserved original task bytes | {payload['coverage']['total_original_bytes']:,} |",
    "",
    "## Exact scope index",
    "",
    "| Task | Recorded owner | Recorded status | Area and English scope |",
    "| --- | --- | --- | --- |",
]
for record in records:
    lines.append(f"| [{record['task_id']}]({record['original_record']}) | {cell(record['owner_as_recorded'])} | {cell(record['status_as_recorded'])} | **{cell(record['area'])}.** {cell(record['english_scope'])} |")
lines.extend([
    "",
    "## Additional delta read",
    "",
    "The separately preserved `delta-01` contains all seven changed records from this baseline through `d8aab676e88fa0a42a3a660687e4a7a4d26e64c4`: six existing paths and one new Agent11 manifest-erratum path. These are not silently substituted into the immutable 162-record table. See `delta-01-review.json` for exact old/new blobs and semantic disposition.",
    "",
    "## Limits",
    "",
    "This census is complete for its pinned 162-path listing. It is not a proof of semantic equivalence or non-equivalence over every archived source, every branch, or future coordination changes. Source and issue discussion checks outside this census are attributed separately. The parent alone may publish a new claim after inspecting intervening changes and receiving a successful optimistic-concurrency write/readback.",
])
(ROOT / "INDEX.md").write_text("\n".join(lines) + "\n")

delta = json.loads((ROOT.parent.parent / "coord-delta-01.json").read_text())
delta_records = []
for changed in delta["changes"]:
    filename = Path(changed["path"]).name
    raw = changed["content"].encode()
    assert blob_sha(raw) == changed["sha"]
    data = json.loads(raw)
    old_path = ROOT / "tasks" / filename
    old = json.loads(old_path.read_text()) if old_path.exists() else {}
    delta_records.append({
        "task_path": changed["path"],
        "old_task_git_blob": blob_sha(old_path.read_bytes()) if old_path.exists() else None,
        "new_task_git_blob": changed["sha"],
        "new_raw_sha256": sha256(raw),
        "new_path": not old_path.exists(),
        "original_record": "delta-01/" + filename,
        "owner_as_recorded": owner_of(data),
        "status_as_recorded": data.get("status"),
        "changed_keys": [key for key in sorted(set(old) | set(data)) if old.get(key) != data.get(key)],
        "exact_target_changed": any(old.get(key) != data.get(key) for key in ("target_statement", "target", "scope", "contract", "exact_contract")),
        "english_disposition": "New manifest-pointer erratum only; no mathematical claim." if not old else "Original target unchanged; status, source/evidence or remaining-work updates only.",
        "new_candidate_overlap": "No overlap with U/S complete binary-carry code or J-zero/symmetry target identified.",
    })
(ROOT / "delta-01-review.json").write_text(json.dumps({
    "previous": delta["previous"], "current": delta["current"],
    "changed_records": len(delta_records), "new_paths": sum(r["new_path"] for r in delta_records),
    "git_blob_checks_passed": len(delta_records), "records": delta_records,
}, indent=2) + "\n")

inventory = []
for file in sorted(ROOT.rglob("*")):
    if file.is_file() and file.name != "ARTIFACTS.json":
        raw = file.read_bytes()
        inventory.append({"path": str(file.relative_to(ROOT)), "bytes": len(raw), "sha256": sha256(raw)})
(ROOT / "ARTIFACTS.json").write_text(json.dumps(inventory, indent=2) + "\n")
print(json.dumps({"records": len(records), "delta_records": len(delta_records), "artifacts": len(inventory), "index_json_bytes": (ROOT / "semantic-index.json").stat().st_size, "index_md_bytes": (ROOT / "INDEX.md").stat().st_size}))
