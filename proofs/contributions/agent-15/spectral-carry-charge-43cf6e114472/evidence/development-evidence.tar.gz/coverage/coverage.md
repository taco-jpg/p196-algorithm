# Agent 15: scoped source coverage census

Repository: `taco-jpg/p196-algorithm`. Source pin: `5ff4f607535587d572fbc9e95ba9501d1fbe5fc5`. Session: `43cf6e114472`.

This is a source-inspection inventory, not a mathematical acceptance report. It records ten precise claims, existing neighboring declarations, original provenance, and missing bridges. No completeness claim is made for the repository or its archived research. The accompanying `coverage.json` contains the full statements, hypotheses, paths, blob identities, proposed interfaces, and exclusions for each entry.

## Selected scope and ownership change

The initial recommendation was fixed-width injectivity of the original T/R spectral coordinate. A subsequent announcement by Agent 14 in issue #61, comment `6226157675`, claimed that exact scope. Agent 15 ceded it in comment `6226185223`, before our session had claimed or implemented it. The earlier inventory is retained in `coverage-before-agent14-delta.json`; its no-overlap result must not be treated as current ownership evidence.

The complementary U/S binary carry-charge scope is now claimed by Agent 15. The parent reports successful guarded publication and exact readback at coordination commit `9ff01fb85383833abe440d7f41bc7c249c332070`, task `agent15-spectral-carry-charge-43cf6e114472`, task blob `70340af5e48d1c965d012180c04bc6ea01f90b21`. The preceding unclaimed inventory is preserved in `coverage-before-us-claim.json`.

For every binary carry word `c` of length `L`, the selected claim is precisely:

```
U(0) = 0, U(1) = 1;
S(0) = 1, S(1) = 21;
X(k+2) = 20*X(k+1) - X(k).

L = 2*m+1: J(c) = sum_(i<m) (c_(2*m-i)-c_i) * U(m-i).
L = 2*m:   J(c) = sum_(i<m) (c_(2*m-1-i)-c_i) * S(m-1-i).

J(c) = 0 if and only if reverse(c) = c.
```

The positive odd weights start at `U(1)`, not `U(0)`. The odd central carry is present in the full word and cancels from the charge. Empty and singleton words require explicit handling if the list interface is total. The binary hypothesis is essential. The complete outgoing word includes the last overflow carry; a separate incoming zero must not be appended.

This is the original source's carry-symmetry claim, extended from computed carry words to all binary finite words. It does not include T/R injectivity on coefficients 0 through 18, H, quadratic-field evaluation, the four-case evolution law, non-nine support, the carry ideal, an orbit invariant, or palindrome avoidance. After the verified claim, the scout was reassigned only the U/S weights module; the parent owns the binary evaluator and full-word bridge. Execution and semantic reviewers remain nonauthors.

## Exact original sources

The original files retain their mathematical provenance. Agent 15's contribution is formalization, not an original discovery claim. These files are archived unchanged beneath:

`proofs/archive/source-trees/2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5/proofs/research/`

| File | Exact Git blob | Source role |
| --- | --- | --- |
| `creative_global_spectral_notes.md` | `cb1c355fa05916a770816a4d5ef680e54079cccb` | Original integer spectral code, carry coordinates, domination and charge-symmetry statement; four-case and palindrome criteria. |
| `creative_global_spectral.py` | `730acd722bf017b6bf1e51e5a0411169a7804da4` | Literal U/S initial values, recurrence, parity-specific signs and indices in `carry_coordinates`. The current flattened copy is `proofs/creative_global_spectral__8de5a77a944d0d04.py`. |
| `astra_spectral_carry_quotient.md` | `eac5b8f61385a615d9cc3e7796a4d698c66b716b` | Carry-defect ideal, quotient labels, exact modular evolution and saturation constructions. |
| `astra_audit_spectral_quotient.md` | `11c17cb618b01dd3a41da56d14cf165e1cd0f8cd` | Historical written audit of the quotient claims. Its acceptance language is source evidence, not this session's independent kernel verification. |

The notes' lines 64–66 assert that the integer J weights dominate the sum of smaller weights, hence J vanishes exactly for symmetric carries. The script supplies the exact U/S recurrences absent from the prose statement. The notes additionally say that no coefficient 9 implies zero J, while the converse can fail. That additional arithmetic bridge is inventoried separately and excluded from the present task.

## Rolling queue

Every status below is scoped to inspected evidence. `PARTIALLY_FORMALIZED` means identified supporting source declarations already exist; it does not mean the named original theorem is accepted. Proposed future endpoint names in the JSON are contracts, not existing declarations.

| ID | Exact claim and key bounds | Status at handoff | Remaining reusable bridge |
| --- | --- | --- | --- |
| A15-SPEC-001 | For each fixed width, the original T/R integer code is injective on symmetric coefficients 0 through 18. Odd central weight is 1. | Agent 14 owns active formalization. | T/R domination, bounded code uniqueness, and full-word reconstruction. No Agent 15 implementation. |
| A15-SPEC-002 | Original U/S J vanishes exactly on symmetric binary carry words, both parities and all boundary lengths. | Agent 15 owns active formalization after verified claim. | Positive superincreasing used weights, binary finite evaluator uniqueness, exact parity indexing, and reversal equivalence. |
| A15-SPEC-003 | Actual next spectral A is `2A+198J`, `A-9H+99J`, `2A+9J`, or `22A-99H+99J`, according to current parity and overflow. | Partially formalized. | Reuse existing normalized coefficient and pairing semantics; prove H/J evaluation and the four exact identities at actual next width `L+h`. |
| A15-SPEC-004 | Next palindrome: no overflow iff `H=J=0`; overflow at odd width iff `J=0` and `A=11H`; overflow at even width iff `J=0` and `2A=11H`. | Partially formalized. | Combine exact coordinate equality with the existing 0/11 decimal palindrome criterion, preserving all hypotheses. |
| A15-SPEC-005 | Reciprocal moment identity `2Q'(1)=(L-1)Q(1)` and physical labels `s=Q(1)/2 mod 9`; odd `r=Q(-1)/2 mod 11`, even `r=0`. For ordinary input n, these are digit sum mod 9 and odd-width n mod 11. | Partially formalized. | Finite whole-word moment arithmetic and exact ordinary-input label identification; exterior moments are different existing objects. |
| A15-SPEC-006 | Whole-word triple `(u,v,w)` modulo `(9,9,22)` updates to `(2u,2v,2w)` without overflow and `(2u,2v+u,0)` with overflow; first overflow kills w permanently. | Partially formalized. | Derive the actual update from finite coefficient semantics and compose the finite-orbit extinction theorem. |
| A15-SPEC-007 | At every odd width at least 5, all 99 physical labels have carry-free canonical representatives; at every even width at least 2, all nine labels do. Realizations are positive nonpalindromic inputs with palindromic next output. | Unformalized in inspected corpus. | Uniform bounded symmetric construction, complete label surjectivity, canonical digit realization, actual no-carry and palindrome proofs. |
| A15-SPEC-008 | At every even width at least 18 and odd width at least 19, every label `(s,0)` has a nonpalindromic representative with actual overflow and palindromic next output. | Unformalized in inspected corpus. | Select 1 through 9 mirrored coefficient-11 pairs, including the outside pair; establish exact carries, residue labels and ordinary realization. |
| A15-SPEC-009 | Actual carry defects have the displayed finite certificates in generators `p=x²-20x+1` and `g=9(x+1)`; inputs 150, 109 and 159 provide the displayed generators. | Partially formalized. | Finite coefficient difference construction, exact reflected defect equations and fixed-degree certificate composition. This is expressly weaker than the full ideal/quotient theorem. |
| A15-SPEC-010 | For bounded symmetric original coefficients, a non-nine column has equal reflected outgoing carries; therefore absence of 9 implies J=0. | Partially formalized; outside current claim. | Reuse the existing local binary-division lemma and bridge both reflected computed carries; then apply the charge theorem. |

All ten contracts can first be stated with Std finite lists, natural indices, and integer arithmetic. The full real quadratic embedding and the full quotient-ring universal property are separate, larger interfaces. A syntactic declaration or a finite certificate fragment must not be reported as closing either stronger statement.

## Existing declarations that must be reused or respected

| Existing source | Exact declaration(s) | Consequence for this census |
| --- | --- | --- |
| `proofs/SeamCoefficients__e73d67d37698e702.lean`, blob `b4200954f47c13d30890673ecab7092578537fe5` | `Agent107.SeamCoefficients.actualCoeff_eq_raw` | The coefficientwise identity `E=Q+(x-10)C`, including the terminal carry, already exists. It is not a new spectral theorem to claim. |
| `proofs/PairResponse__18d2d58355ed97f4.lean`, blob `b7e822e798d873e9b51f7e97eb9c4c78821bd1c2` | `Agent107.PairResponse.nextColumns_actualCoeff`, `numeric_pair_response` | Actual-width normalized pairing and its ordinary arithmetic representation are already present. |
| `proofs/RawSymmetryObstruction__5c1be305a04af2b7.lean`, blob `9d4250f3e5daa5ff26f097a7e12ce98830dd9e89` | `RawSymmetryObstruction.nonnine_binary_div`, `resetOut_eq_actual_of_nonnine` | The local non-nine independence fact is already proved in source. A future full-word support corollary should reuse it. |
| `proofs/Lychrel196Research__c696e0ea3db39d92.lean`, blob `c6c1f5441c54a36f2d82b3ef78dff1ccdbc5a506` | `ReverseAddInverse.symmetric_value_injective`; `DecimalDigits.step_palindrome_iff_no_overflow`, `step_palindrome_iff_overflow`; ordinary carry bounds and canonical realization declarations | Ordinary base-ten injectivity is a different code. Decimal palindrome and carry foundations already exist and should support later arithmetic bridges. |
| `proofs/GeneralMomentAbsorption__d6c541c17a8aa76f.lean`, blob `8e6aac5d5450b68b98535fa90d5b828019068b69` | `P196.Agent5.General.Moment.altSum_reverse` and neighboring absorption declarations | These use the exterior normalization state; they do not close the full original-word Q claims merely because both use alternating sums. |

The old FINDINGS and REPORTS no-Lean labels are not current ownership or proof-status authorities by themselves. Searches excluded apparently attractive work already covered or owned: universal fixed-modulus saturation, general-base normalization, Agent 9's temporal counts and marker bounds, Agent 104's exact finite mass bounds, Agent 112's 10-adic discontinuity, Agent 13's incoming weights, Agent 108's fixed-window and matrix extensions, Agent 4's separated blocks, Agent 100/1's Group II/III repairs, and Agent 102/105's affine and return work. Full details and PR references are in `deduplicated_or_owned` in the JSON.

## Stronger statements and semantic traps

Fixed-width spectral injectivity recovers the paired coefficient word, not the input integer. The retained original manuscript gives 196 and 295 with the same paired word `(7,18,7)` and common first output 887. This is source evidence, not a newly executed experiment.

For the later palindrome criterion, the intermediate symmetric word `11*C` can have odd central coefficient 11. It therefore need not satisfy the canonical even-center admissibility predicate. T/R injectivity should use the genuinely sufficient domain of bounded symmetric words if it is to support that argument; a canonical-only theorem may leave a real gap.

The full quotient theorem states an isomorphism with `(Z/9)[epsilon]/epsilon² × Z/22`, of cardinality 1782. The finite coefficient certificates in A15-SPEC-009 cover a strict subclaim. Neither source inspection nor historical written audit upgrades these to a checked Lean result.

No listed coordinate identity establishes a nonzero invariant persisting along the 196 orbit. No residue saturation construction proves that a particular orbit visits those witnesses. The source's no-nine implication is one-way. The original general-base notes also explicitly correct an older restricted endpoint-pair model; that superseded statement should not be formalized as true.

## Corpus and evidence limits

The scout inspected the root policies and README, original FINDINGS and REPORTS, current consolidation/status/publication/reproduction documents, retained manuscript and formalization inventories, the targeted original research files, and thirteen relevant current Lean source files. The exact lists appear in `searched_corpus` in the JSON.

The complete nonrecursive proofs tree contains 2634 entries at tree `e81658dcfd40b5d635e164399c2f1339fe5165f3`; the complete contributions subtree contains 2308 entries at tree `3d13acfe57bfdcfccc8ba17121bb400de59838fd`. These are filename/path inventories, not a claim that every source body was read. The initial contents endpoint stopped at 1000 entries and was not treated as complete. Two root-recursive requests failed, and the large source map returned no content; direct verified archived paths supplied the relevant source identities instead.

The scout inspected 476 issue #61 comments through comment `6226101881`, then incorporated explicitly attributed parent deltas. It also read the 47 open PR records returned by the single complete 100-item page at the snapshot, through PR 143. Historical closed branch heads were not exhaustively searched by mathematical content.

The independent ownership specialist reported reading and Git-blob checking all 162 task files at `b0ee3d25fb1ddea0f741326b6401d81ae3d27626`, then a seven-record delta to `d8aab676e88fa0a42a3a660687e4a7a4d26e64c4`, preserving 163 paths and 169 versions. Parent inspected further changes, reaching 168 task files before the successful U/S claim. These delegated checks are attributed; this scout did not independently repeat them.

Eighteen locally preserved selected source files have exact recalculated Git blob SHA1 matches in `source-byte-audit.json`; `source-manifest.json` maps each to its pinned path. This proves preservation of the selected bytes, not mathematical correctness. No source build, import-closure audit, axiom check, computation experiment, or proof acceptance occurred during the read-only census. Any later weights implementation has its own separate attempt and verification record.

No compressed certificate archive was extracted. The manuscript corpus, historical false claims, closed PR content, and every flattened contribution were not exhausted. These limitations remain open; a ten-item focused inventory is not repository-wide closure.

## Artifact map

- `coverage.json`: exact ten-claim machine-readable inventory and twelve excluded or owned lanes.
- `coverage-before-agent14-delta.json`, `coverage-before-us-claim.json`: preserved scope-change history.
- `source-manifest.json`, `source-byte-audit.json`, `source/`: selected exact source copies and byte checks.
- `proofs-tree.json`, `contributions-tree.json`: complete scoped path inventories.
- `open-prs.json`, `issue61-snapshot.json`: coordination evidence at the stated read snapshot.

Future acceptance must compare the final exported statement with the exact original contract, compile its complete source closure with the required Lean flags, audit all public and module-origin mathematical declarations and transitive axioms, and obtain genuine nonauthor review. Forbidden proof shortcuts remain forbidden throughout; no new mathematical axiom or unchecked computational oracle can close a queue item.
