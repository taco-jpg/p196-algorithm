import Agent105NumericDecoder9df76b
import Agent105DecoderControls9df76b
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check Agent105DecoderLocal9df76b.validEdge_unique
#check Agent105DecoderLocal9df76b.validCenter_unique
#check Agent105DecoderLocal9df76b.decodePair_sound
#check Agent105DecoderLocal9df76b.decodePair_complete
#check Agent105DecoderLocal9df76b.decodePair_eq_some_iff
#check Agent105DecoderLocal9df76b.decodeCenter_eq_some_iff
#check Agent105DecoderLocal9df76b.decodePair_eq_none_iff
#check Agent105DecoderLocal9df76b.decodeCenter_eq_none_iff
#check Agent105DecoderTarget9df76b.payload_congr
#check Agent105DecoderTarget9df76b.realize_payload
#check Agent105DecoderTarget9df76b.canonical_predecessor_payload
#check Agent105DecoderTarget9df76b.positive_predecessor_iff_finite_payload
#check Agent105DecoderScan9df76b.digitFn_wrap_zero
#check Agent105DecoderScan9df76b.digitFn_wrap_last
#check Agent105DecoderScan9df76b.digitFn_wrap_inner
#check Agent105DecoderScan9df76b.wrap_word_conditions
#check Agent105DecoderScan9df76b.scan_sound
#check Agent105DecoderScan9df76b.scan_complete
#check Agent105DecoderScan9df76b.decodeAtWidth_eq_some_iff
#check Agent105DecoderScan9df76b.decodeAtWidth_isSome_iff
#check Agent105NumericDecoder9df76b.decodeNumerical_eq_some_iff_payload
#check Agent105NumericDecoder9df76b.decodeNumerical_eq_some_iff
#check Agent105NumericDecoder9df76b.decodeNumerical_isSome_iff
#check Agent105DecoderControls9df76b.five_to_ten
#check Agent105DecoderControls9df76b.one_to_two
#check Agent105DecoderControls9df76b.boundary_121
#check Agent105DecoderControls9df76b.retained_nonpalindromic_1197801
#check Agent105DecoderControls9df76b.truncated_subtraction_rejects
#check Agent105DecoderControls9df76b.output_digit_bound_contract
run_cmd do
  let env ← getEnv
  let selected : List String := ["Lychrel196Research", "Agent101DigitPairs", "Agent101MultiplicityBounds", "Agent101SplitEnumeration", "Agent101NumericFibers", "Agent105WidthSupport9df76b", "Agent105DecoderTarget9df76b", "Agent105DecoderLocal9df76b", "Agent105DecoderScan9df76b", "Agent105NumericDecoder9df76b", "Agent105CrossWidthWitness9df76b", "Agent105DecoderControls9df76b"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        match info with
        | .axiomInfo v =>
          if v.isUnsafe then logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {mod} {name}"
          else throwError m!"CUSTOM_AXIOM {mod} {name}"
        | .thmInfo _ =>
          count := count + 1
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          for ax in axl do
            if !(union.contains ax) then union := ax :: union
          if axl.any (fun ax => !(allowed.contains ax)) then throwError m!"DISALLOWED_AXIOMS {mod} {name} : {axl}"
          logInfo m!"AUDIT_THEOREM {mod} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
