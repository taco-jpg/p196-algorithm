import Agent105CrossWidth9df76b
import Agent105CrossWidthWitness9df76b
import Agent105PalindromeImage9df76b
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check Agent105WidthSupport9df76b.canonical_width_unique
#check Agent105WidthSupport9df76b.canonical_digits_unique
#check Agent105WidthSupport9df76b.canonical_width_and_digits_unique
#check Agent105WidthSupport9df76b.canonical_step_width
#check Agent105WidthSupport9df76b.step_width_cases
#check Agent105WidthSupport9df76b.canonical_step_exists
#check Agent105WidthSupport9df76b.cross_width_carries
#check Agent105CrossWidth9df76b.cross_width_outer
#check Agent105CrossWidth9df76b.cross_width_short_length
#check Agent105CrossWidth9df76b.cross_width_output_dvd_eleven
#check Agent105CrossWidth9df76b.cross_width_target_digits
#check Agent105CrossWidth9df76b.equal_step_widths_close
#check Agent105CrossWidth9df76b.three_preimages_share_pair_profile
#check Agent105.CrossWidthWitness9df76b.literalDigit_bounded
#check Agent105.CrossWidthWitness9df76b.short_canonical
#check Agent105.CrossWidthWitness9df76b.long_canonical
#check Agent105.CrossWidthWitness9df76b.target_canonical
#check Agent105.CrossWidthWitness9df76b.short_reverse
#check Agent105.CrossWidthWitness9df76b.long_reverse
#check Agent105.CrossWidthWitness9df76b.target_reverse
#check Agent105.CrossWidthWitness9df76b.short_step
#check Agent105.CrossWidthWitness9df76b.long_step
#check Agent105.CrossWidthWitness9df76b.target_not_palindrome
#check Agent105.CrossWidthWitness9df76b.retained_profiles
#check Agent105.CrossWidthWitness9df76b.terminal_carries
#check Agent105.CrossWidthWitness9df76b.nonpalindromic_cross_width_witness
#check Agent105.CrossWidthWitness9df76b.boundary_short_canonical
#check Agent105.CrossWidthWitness9df76b.boundary_long_canonical
#check Agent105.CrossWidthWitness9df76b.boundary_target_canonical
#check Agent105.CrossWidthWitness9df76b.boundary_reversals
#check Agent105.CrossWidthWitness9df76b.palindromic_boundary_witness
#check P196.Agent105.PalindromeImage9df76b.same_width_zero_carry_predecessor
#check P196.Agent105.PalindromeImage9df76b.no_overflow_palindrome_center_even
#check P196.Agent105.PalindromeImage9df76b.overflow_palindrome_center_zero_or_two
#check P196.Agent105.PalindromeImage9df76b.target_parity_of_positive_predecessor
#check P196.Agent105.PalindromeImage9df76b.palindrome_target_has_positive_predecessor_iff
#check P196.Agent105.PalindromeImage9df76b.same_width_first_hit_one_predecessor
#check P196.Agent105.PalindromeImage9df76b.palindrome_target_first_hit_one_iff
run_cmd do
  let env ← getEnv
  let selected : List String := ["Lychrel196Research", "Agent101DigitPairs", "Agent101MultiplicityBounds", "Agent101SplitEnumeration", "Agent101NumericFibers", "Agent105WidthSupport9df76b", "Agent105CrossWidth9df76b", "Agent105CrossWidthWitness9df76b", "Agent105PalindromeImage9df76b"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        match info with
        | .axiomInfo v =>
          if v.isUnsafe then logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {mod} {name}"
          else throwError m!"CUSTOM_AXIOM {mod} {name}"
        | .thmInfo _ =>
          count := count + 1
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          for ax in axl do
            if !(union.contains ax) then union := ax :: union
          if axl.any (fun ax => !(allowed.contains ax)) then throwError m!"DISALLOWED_AXIOMS {mod} {name} : {axl}"
          logInfo m!"AUDIT_THEOREM {mod} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
