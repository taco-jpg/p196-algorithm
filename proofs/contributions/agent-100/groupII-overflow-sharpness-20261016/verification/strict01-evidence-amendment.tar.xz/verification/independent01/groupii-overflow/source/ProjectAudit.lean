import Agent100GroupIIOverflowNumeric
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check Agent100.GroupIIOverflow.component_low
#check Agent100.GroupIIOverflow.component_carry
#check Agent100.GroupIIOverflow.initial_carry
#check Agent100.GroupIIOverflow.component_double_carry
#check Agent100.GroupIIOverflow.middle_carry
#check Agent100.GroupIIOverflow.redundant_carry
#check Agent100.GroupIIOverflow.component_no_overflow
#check Agent100.GroupIIOverflow.initial_no_overflow
#check Agent100.GroupIIOverflow.component_double_overflow
#check Agent100.GroupIIOverflow.middle_overflow
#check Agent100.GroupIIOverflow.redundant_overflow
#check Agent100.GroupIIOverflow.component_double_width
#check Agent100.GroupIIOverflow.middle_width
#check Agent100.GroupIIOverflow.redundant_width
#check Agent100.GroupIIOverflow.component_width
#check Agent100.GroupIIOverflow.initial_width
#check Agent100.GroupIIOverflow.component_admissible
#check Agent100.GroupIIOverflow.initial_admissible
#check Agent100.GroupIIOverflow.middle_admissible
#check Agent100.GroupIIOverflow.component_next
#check Agent100.GroupIIOverflow.component_double_admissible
#check Agent100.GroupIIOverflow.initial_next
#check Agent100.GroupIIOverflow.normalized_digit_defect_exact
#check Agent100.GroupIIOverflow.normalized_digit_defect_antisymmetric
#check Agent100.GroupIIOverflow.normalized_digit_defect_nonzero
#check Agent100.GroupIIOverflow.redundant_not_admissible
#check Agent100.GroupIIOverflow.component_digits_formula
#check Agent100.GroupIIOverflow.component_digits_zero_after_width
#check Agent100.GroupIIOverflow.redundant_extended_digits
#check Agent100.GroupIIOverflow.adjacent_normalized_sum_bounded
#check Agent100.GroupIIOverflow.finite_next_component_columns
#check Agent100.GroupIIOverflow.redundant_next_is_finite_overlap
#check Agent100.GroupIIOverflow.supported_digit_defect
#check Agent100.GroupIIOverflow.digit_defect_difference
#check Agent100.GroupIIOverflow.middle_redundant_defect
#check Agent100.GroupIIOverflow.finite_overlap_defect
#check Agent100.GroupIIOverflow.finite_overlap_witness
#check Agent100.GroupIIOverflow.finite_overlap_fails
#check Agent100.GroupIIOverflow.component_two_step_upper
#check Agent100.GroupIIOverflow.whole_two_step_upper
#check Agent100.GroupIIOverflow.upper_component_finite_eq
#check Agent100.GroupIIOverflow.returned_component_zero_after_width
#check Agent100.GroupIIOverflow.lower_component_finite_eq
#check Agent100.GroupIIOverflow.lower_two_step_overlap
#check Agent100.GroupIIOverflow.actual_two_step_defect
#check Agent100.GroupIIOverflow.upper_two_step_overlap_fails
#check Agent100.GroupIIOverflow.two_step_overlap_iff
#check Agent100.GroupIIOverflow.upper_initial_realizable
#check Agent100.GroupIIOverflow.numeric_two_step_representation
#check Agent100.GroupIIOverflow.numeric_two_step_defect
#check Agent100.GroupIIOverflow.numeric_two_step_overlap_fails
#check Agent100.GroupIIOverflow.realized_overflow_defect
run_cmd do
  let env ← getEnv
  let selected : List String := ["LychrelDigitSums", "SafeDelay", "DecimalSafeRuns", "DecimalDelayBridge", "PairDelayBridge", "DelayedOverlapGate", "Agent100GroupIIDynamics", "Agent100GroupIIDefect", "Agent100GroupIIOverflowProfiles", "Agent100GroupIIOverflowBridge", "IncomingCarrySensitivity", "RawSymmetryObstruction", "SeamCoefficients", "PairResponse", "Agent8DefectTransport", "Agent100GroupIIOverflowDefect", "Agent100GroupIIOverflowSharpness", "Agent100GroupIIOverflowNumeric"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        match info with
        | .axiomInfo v =>
          if v.isUnsafe then logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {mod} {name}"
          else throwError m!"CUSTOM_AXIOM {mod} {name}"
        | .thmInfo _ =>
          count := count + 1
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          for ax in axl do
            if !(union.contains ax) then union := ax :: union
          if axl.any (fun ax => !(allowed.contains ax)) then throwError m!"DISALLOWED_AXIOMS {mod} {name} : {axl}"
          logInfo m!"AUDIT_THEOREM {mod} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
