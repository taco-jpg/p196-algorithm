import Agent100GroupIIRebaseNumeric
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check Agent100.GroupIIRebase.rebase_delta_overlap
#check Agent100.GroupIIRebase.rebasedInt_actual_component
#check Agent100.GroupIIRebase.rebasedInt_overlap
#check Agent100.GroupIIRebase.finite_whole_rebasedInt
#check Agent100.GroupIIRebase.actual_whole_rebasedInt
#check Agent100.GroupIIRebase.finite_component_flank
#check Agent100.GroupIIRebase.finite_component_inner
#check Agent100.GroupIIRebase.finite_component_admissible
#check Agent100.GroupIIRebase.rebased_nonnegative
#check Agent100.GroupIIRebase.rebased_bounded
#check Agent100.GroupIIRebase.rebased_toNat_exact
#check Agent100.GroupIIRebase.rebased_zero_after_width
#check Agent100.GroupIIRebase.rebased_symmetric
#check Agent100.GroupIIRebase.rebased_center_eq
#check Agent100.GroupIIRebase.rebased_outer_eq
#check Agent100.GroupIIRebase.rebased_admissible
#check Agent100.GroupIIRebase.actual_whole_rebased
#check Agent100.GroupIIRebase.rebased_component_realizable
#check Agent100.GroupIIRebase.numeric_rebased_overlap
#check Agent100.GroupIIRebase.numeric_rebased_realization
#check Agent100.GroupIIRebase.realized_rebased_overlap
#check Agent100.GroupIIRebase.rebased_differs_at_flank
run_cmd do
  let env ← getEnv
  let selected : List String := ["LychrelDigitSums", "SafeDelay", "DecimalSafeRuns", "DecimalDelayBridge", "PairDelayBridge", "DelayedOverlapGate", "Agent100GroupIIDynamics", "Agent100GroupIIDefect", "Agent100GroupIIOverflowProfiles", "Agent100GroupIIOverflowBridge", "IncomingCarrySensitivity", "RawSymmetryObstruction", "SeamCoefficients", "PairResponse", "Agent8DefectTransport", "Agent100GroupIIOverflowDefect", "Agent100GroupIIOverflowSharpness", "Agent100GroupIIRebaseAlgebra", "Agent100GroupIIRebaseProfiles", "Agent100GroupIIOverflowNumeric", "Agent100GroupIIRebaseNumeric"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        match info with
        | .axiomInfo v =>
          if v.isUnsafe then logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {mod} {name}"
          else throwError m!"CUSTOM_AXIOM {mod} {name}"
        | .thmInfo _ =>
          count := count + 1
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          for ax in axl do
            if !(union.contains ax) then union := ax :: union
          if axl.any (fun ax => !(allowed.contains ax)) then throwError m!"DISALLOWED_AXIOMS {mod} {name} : {axl}"
          logInfo m!"AUDIT_THEOREM {mod} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
