import Agent100GroupIIDynamics

/-!
Agent #100, independent session 212248Z.

A strictly stronger *local* obstruction than the existing Agent #100
component/whole outer-column 14-vs-15 discrepancy: after the fourth-step
Group-II return with parameters (4,5,5), the *whole* two-step descendant
cannot be any shifted overlap of a nonnegative component, because its
first two columns are strictly decreasing.

This does NOT rule out a different non-overlap mechanism and proves
nothing about infinitely many reverse-add steps or the seed 196.

Proof development only until an actual Lean 4.19.0 compile and axiom
report has been recorded. Existing other-agent outer=15 ownership retained.
-/

namespace Agent100.ThirdGateDescent

open DecimalDigits FoldedDecimal OverflowCarryNormalization DelayedOverlapGate

set_option maxHeartbeats 4000000
set_option maxRecDepth 10000

def fourth (r : Nat) : Nat → Nat := Agent100.GroupII.returned r 4 5 5

def width4 (r : Nat) : Nat := 2 * r + 7

def fifth (r : Nat) : Nat → Nat := nextColumns (fourth r) (width4 r)

def width5 (r : Nat) : Nat := 2 * r + 8

def sixth (r : Nat) : Nat → Nat := nextColumns (fifth r) (width5 r)

def fourthCarry (r i : Nat) : Nat :=
  if i = 1 ∨ i = 2 ∨ i = 2 * r + 6 ∨ i = 2 * r + 7 then 1 else 0

/-- Exact overflow carry profile after the fourth-stage word,
including the shortest spacer r=1. -/
theorem fourth_carry (r : Nat) (hr : 1 ≤ r) :
    ∀ i, i ≤ width4 r → carry (fourth r) i = fourthCarry r i := by
  apply carry_certificate _ _ _ (by simp [fourthCarry])
  intro i hi
  simp only [fourth, Agent100.GroupII.returned, shiftOne,
    Agent100.GroupII.returnedComponent, fourthCarry, width4] at *
  repeat (first | omega | split)

theorem fourth_overflow (r : Nat) (hr : 1 ≤ r) :
    carry (fourth r) (width4 r) = 1 := by
  rw [fourth_carry r hr (width4 r) (Nat.le_refl _)]
  simp [fourthCarry, width4]

/-- The next pair word uses an appended *real* leading carry digit. -/
theorem fifth_symmetric (r : Nat) (hr : 1 ≤ r)
    (i : Nat) (hi : i < width5 r) :
    fifth r i = fifth r (width5 r - 1 - i) := by
  simp only [fifth, nextColumns, fourth_overflow r hr, if_false]
  exact columnSum_symmetric (extended (fourth r) (width4 r)) (width5 r) i hi

def fifthCarry (r i : Nat) : Nat :=
  if i = 2 ∨ i = 2 * r + 7 ∨
     (r = 1 ∧ (i = 3 ∨ i = 2 * r + 6)) then 1 else 0

/-- Exact carry pattern at the fifth-stage input; the exceptional
short spacer has two additional internal carries. -/
theorem fifth_carry (r : Nat) (hr : 1 ≤ r) :
    ∀ i, i ≤ width5 r → carry (fifth r) i = fifthCarry r i := by
  apply carry_certificate _ _ _ (by simp [fifthCarry])
  intro i hi
  have hc0 := fourth_carry r hr i (by dsimp [width4, width5] at *; omega)
  have hc1 := fourth_carry r hr (width4 r - i)
    (by dsimp [width4, width5] at *; omega)
  have he : width4 r + 1 - 1 - i = width4 r - i := by omega
  simp only [fifth, nextColumns, fourth_overflow r hr,
    Nat.one_ne_zero, if_false, columnSum, reflected, extended, output] at *
  rw [he, hc0, hc1]
  simp only [fourth, Agent100.GroupII.returned, shiftOne,
    Agent100.GroupII.returnedComponent, fourthCarry, fifthCarry, width4] at *
  repeat (first | omega | split)

theorem fifth_no_overflow (r : Nat) (hr : 1 ≤ r) :
    carry (fifth r) (width5 r) = 0 := by
  rw [fifth_carry r hr (width5 r) (Nat.le_refl _)]
  simp [fifthCarry, width5]

/-- The whole fifth-stage outer pair sum. -/
theorem fifth_outer_zero (r : Nat) (hr : 1 ≤ r) : fifth r 0 = 7 := by
  have hc0 := fourth_carry r hr 0 (by dsimp [width4]; omega)
  have hcL := fourth_overflow r hr
  simp only [fifth, nextColumns, hcL, Nat.one_ne_zero, if_false,
    columnSum, reflected, extended, output] at *
  rw [hc0]
  simp [fourth, Agent100.GroupII.returned, shiftOne,
    Agent100.GroupII.returnedComponent, fourthCarry, width4, width5] at *
  repeat (first | omega | split)

/-- The penultimate fifth-stage pair sum; r=1 is a genuine boundary case. -/
theorem fifth_outer_one (r : Nat) (hr : 1 ≤ r) :
    fifth r 1 = if r = 1 then 15 else 14 := by
  have hc1 := fourth_carry r hr 1 (by dsimp [width4]; omega)
  have hcMirror := fourth_carry r hr (width4 r - 1) (by dsimp [width4]; omega)
  have hcL := fourth_overflow r hr
  have he : width4 r + 1 - 1 - 1 = width4 r - 1 := by omega
  simp only [fifth, nextColumns, hcL, Nat.one_ne_zero, if_false,
    columnSum, reflected, extended, output] at *
  rw [he, hc1, hcMirror]
  simp [fourth, Agent100.GroupII.returned, shiftOne,
    Agent100.GroupII.returnedComponent, fourthCarry, width4] at *
  repeat (first | omega | split)

/-- The sixth-stage word, before any further arithmetic operation. -/
theorem sixth_outer_zero (r : Nat) (hr : 1 ≤ r) : sixth r 0 = 15 := by
  have hsym := fifth_symmetric r hr 0 (by dsimp [width5]; omega)
  have hcar0 := fifth_carry r hr 0 (by dsimp [width5]; omega)
  have hcarR := fifth_carry r hr (width5 r - 1) (by dsimp [width5]; omega)
  rw [show sixth r 0 = columnSum (output (fifth r)) (width5 r) 0 by
    simp [sixth, nextColumns, fifth_no_overflow r hr]]
  simp only [columnSum, reflected, output]
  have he : width5 r - 1 - 0 = width5 r - 1 := by omega
  rw [he, hcar0, hcarR]
  rw [← hsym, fifth_outer_zero r hr]
  simp [fifthCarry, width5]

/-- All spacers, not only bounded checked examples, have a strict outer
coefficient descent on the *whole* word after six updates. -/
theorem sixth_outer_one (r : Nat) (hr : 1 ≤ r) :
    sixth r 1 = if r = 1 then 11 else 8 := by
  have hsym := fifth_symmetric r hr 1 (by dsimp [width5]; omega)
  have hcar1 := fifth_carry r hr 1 (by dsimp [width5]; omega)
  have hcarR := fifth_carry r hr (width5 r - 2) (by dsimp [width5]; omega)
  rw [show sixth r 1 = columnSum (output (fifth r)) (width5 r) 1 by
    simp [sixth, nextColumns, fifth_no_overflow r hr]]
  simp only [columnSum, reflected, output]
  have he : width5 r - 1 - 1 = width5 r - 2 := by omega
  rw [he, hcar1, hcarR]
  rw [← hsym, fifth_outer_one r hr]
  simp only [fifthCarry, width5]
  by_cases h : r = 1
  · simp [h]
  · simp [h]

/-- The exact width of the sixth-stage pair state. -/
theorem width_six (r : Nat) (hr : 1 ≤ r) :
    (iterPairs (fourth r) (width4 r) 2).1 = width5 r := by
  change nextWidth (nextColumns (fourth r) (width4 r))
    (nextWidth (fourth r) (width4 r)) = width5 r
  have hov := fourth_overflow r hr
  have hn := fifth_no_overflow r hr
  rw [show nextWidth (fourth r) (width4 r) = width5 r by
    simp [nextWidth, hov, width4, width5]]
  change nextWidth (fifth r) (width5 r) = width5 r
  simp [nextWidth, hn]

theorem outer_descent (r : Nat) (hr : 1 ≤ r) :
    sixth r 1 < sixth r 0 := by
  rw [sixth_outer_zero r hr, sixth_outer_one r hr]
  by_cases h : r = 1
  · simp [h]
  · simp [h]

/-- Every nonnegative shifted overlap has a nondecreasing first pair. -/
theorem shiftOne_first_le_second (c : Nat → Nat) :
    shiftOne c 0 ≤ shiftOne c 1 := by
  simp [shiftOne]

/-- No nonnegative component, regardless of its shape or width, can
produce the sixth-step whole word in even the first two columns. -/
theorem no_third_overlap (r : Nat) (hr : 1 ≤ r) :
    ¬ ∃ c : Nat → Nat,
      ∀ i, i < 2 → sixth r i = shiftOne c i := by
  rintro ⟨c, h⟩
  have h0 := h 0 (by omega)
  have h1 := h 1 (by omega)
  have hc := shiftOne_first_le_second c
  have hd := outer_descent r hr
  omega

end Agent100.ThirdGateDescent

#print axioms Agent100.ThirdGateDescent.fourth_carry
#print axioms Agent100.ThirdGateDescent.fifth_carry
#print axioms Agent100.ThirdGateDescent.sixth_outer_zero
#print axioms Agent100.ThirdGateDescent.sixth_outer_one
#print axioms Agent100.ThirdGateDescent.width_six
#print axioms Agent100.ThirdGateDescent.no_third_overlap
