#!/usr/bin/env python3
"""Finite independent controls for Agent #100's third-gate conjecture.

The controls do NOT prove the forall-r Lean theorem. No external dependencies.
Two independent implementations are tested: decimal integer arithmetic and
an exact per-column carry transducer with changing width.
"""
from __future__ import annotations
import json
from pathlib import Path
from hashlib import sha256


def groupii_returned_component(r):
    assert r >= 1
    L = 2*r+6
    c = [0] * L
    assignments = [(0,16),(L-1,16),(r,1),(r+5,1),
                   (r+1,1),(r+4,1),(r+2,2),(r+3,2)]
    for i, v in assignments:
        assert c[i] == 0, (r,i)  # supports r=1 without conflating neighbors
        c[i] = v
    return c


def shifted(c):
    return [(c[i] if i<len(c) else 0)+(c[i-1] if i else 0)
            for i in range(len(c)+1)]


def step_pair(q):
    c = 0
    digit = []
    for x in q:
        y = x+c
        digit.append(y%10)
        c=y//10
    assert c in (0,1)
    if c:
        digit.append(c)
    L=len(digit)
    return digit, [digit[i]+digit[L-1-i] for i in range(L)]


def value(d):
    return sum(x * 10**i for i,x in enumerate(d))


def reverse_decimal(x):
    return int(str(x)[::-1])


def pair_from_number(n):
    d=list(map(int,str(n)[::-1]))
    return [d[i]+d[-1-i] for i in range(len(d))]


def inspect(r):
    q4=shifted(groupii_returned_component(r))
    digit5,q5=step_pair(q4)
    digit6,q6=step_pair(q5)
    assert len(q4)==2*r+7 and len(q5)==len(q6)==2*r+8
    assert q6[0]==15 and q6[1]==(11 if r==1 else 8)
    assert q6[1]<q6[0]
    n5=value(digit5)
    n6=n5+reverse_decimal(n5)
    assert n6==value(digit6), (r,"number comparison")
    assert q5==pair_from_number(n5), (r,"first pair")
    assert q6==pair_from_number(n6), (r,"second pair")
    return {"r":r, "width_q4":len(q4), "width_q6":len(q6),
            "q5_first_two":q5[:2],"q6_first_two":q6[:2],
            "q6_strict_descent":True}


def main():
    rows=[inspect(r) for r in range(1,301)]
    payload={"classification":"FINITE_DIAGNOSTIC_ONLY",
             "starting_word":"Agent100.GroupII.returned r 4 5 5",
             "n":len(rows),"r_min":1,"r_max":300,"results":rows,
             "all_controls_passed":True}
    path=Path(__file__).with_name('finite-control-300.json')
    path.write_text(json.dumps(payload,indent=2,ensure_ascii=False)+'\n')
    print(f"PASS 300 independent integer/column controls; "+
          f"report={path.name} sha256={sha256(path.read_bytes()).hexdigest()}")

if __name__=='__main__':
    main()
