import Agent14CarryfreeSaturation
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check Agent14.Carryfree.residue_parameters
#check Agent14.Carryfree.even_residue_parameters
#check Agent14.Carryfree.odd_three_digit_mod99
#check Agent14.Carryfree.threeDigits_canonical
#check Agent14.Carryfree.threeDigits_not_palindrome
#check Agent14.Carryfree.threeDigits_column_formula
#check Agent14.Carryfree.small_columns_actual_step
#check Agent14.Carryfree.odd_seed_spec
#check Agent14.Carryfree.one_digit_seed_spec
#check Agent14.Carryfree.odd_carryfree_classes
#check Agent14.Carryfree.even_carryfree_classes
#check Agent14.Carryfree.eval_one
#check Agent14.Carryfree.canonical_columns_eval_one
#check Agent14.Carryfree.odd_columns_eval_neg_one
#check Agent14.Carryfree.even_columns_eval_neg_one
#check Agent14.Carryfree.half_columns_eval_one
#check Agent14.Carryfree.odd_seed_half_neg_one
#check Agent14.Carryfree.odd_seed_half_mod_eleven
#check Agent14.Carryfree.odd_source_coordinate_saturation
#check Agent14.Carryfree.even_source_coordinate_saturation
#check Agent14.Carryfree.negative_half_control
#check Agent14.Carryfree.zero_classes_control
run_cmd do
  let env ← getEnv
  let selected : List String := ["Agent14CarryfreeResidues", "LychrelDigitSums", "Agent14CarryfreeDigits", "Agent14CarryfreeCoordinates", "Agent14CarryfreeSaturation"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        match info with
        | .axiomInfo v =>
          if v.isUnsafe then logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {mod} {name}"
          else throwError m!"CUSTOM_AXIOM {mod} {name}"
        | .thmInfo _ =>
          count := count + 1
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          for ax in axl do
            if !(union.contains ax) then union := ax :: union
          if axl.any (fun ax => !(allowed.contains ax)) then throwError m!"DISALLOWED_AXIOMS {mod} {name} : {axl}"
          logInfo m!"AUDIT_THEOREM {mod} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
