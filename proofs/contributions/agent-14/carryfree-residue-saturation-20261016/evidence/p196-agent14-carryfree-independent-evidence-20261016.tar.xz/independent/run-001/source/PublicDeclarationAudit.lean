import Agent14CarryfreeSaturation
set_option pp.fullNames true
set_option pp.universes true
set_option pp.explicit true
#check @Agent14.Carryfree.residue_parameters
#print axioms Agent14.Carryfree.residue_parameters
#check @Agent14.Carryfree.even_residue_parameters
#print axioms Agent14.Carryfree.even_residue_parameters
#check @Agent14.Carryfree.ten_pow_mod99
#print axioms Agent14.Carryfree.ten_pow_mod99
#check @Agent14.Carryfree.odd_three_digit_mod99
#print axioms Agent14.Carryfree.odd_three_digit_mod99
#check @Agent14.Carryfree.threeDigits
#print axioms Agent14.Carryfree.threeDigits
#check @Agent14.Carryfree.oneDigit
#print axioms Agent14.Carryfree.oneDigit
#check @Agent14.Carryfree.spike
#print axioms Agent14.Carryfree.spike
#check @Agent14.Carryfree.threeDigits_bounded
#print axioms Agent14.Carryfree.threeDigits_bounded
#check @Agent14.Carryfree.threeDigits_leading
#print axioms Agent14.Carryfree.threeDigits_leading
#check @Agent14.Carryfree.threeDigits_second
#print axioms Agent14.Carryfree.threeDigits_second
#check @Agent14.Carryfree.threeDigits_third
#print axioms Agent14.Carryfree.threeDigits_third
#check @Agent14.Carryfree.threeDigits_prefix_zero
#print axioms Agent14.Carryfree.threeDigits_prefix_zero
#check @Agent14.Carryfree.threeDigits_units_zero
#print axioms Agent14.Carryfree.threeDigits_units_zero
#check @Agent14.Carryfree.zero_digits_value
#print axioms Agent14.Carryfree.zero_digits_value
#check @Agent14.Carryfree.threeDigits_value
#print axioms Agent14.Carryfree.threeDigits_value
#check @Agent14.Carryfree.threeDigits_sum
#print axioms Agent14.Carryfree.threeDigits_sum
#check @Agent14.Carryfree.threeDigits_canonical
#print axioms Agent14.Carryfree.threeDigits_canonical
#check @Agent14.Carryfree.threeDigits_not_palindrome
#print axioms Agent14.Carryfree.threeDigits_not_palindrome
#check @Agent14.Carryfree.threeDigits_columns_bounded
#print axioms Agent14.Carryfree.threeDigits_columns_bounded
#check @Agent14.Carryfree.threeDigits_column_formula
#print axioms Agent14.Carryfree.threeDigits_column_formula
#check @Agent14.Carryfree.oneDigit_bounded
#print axioms Agent14.Carryfree.oneDigit_bounded
#check @Agent14.Carryfree.oneDigit_leading
#print axioms Agent14.Carryfree.oneDigit_leading
#check @Agent14.Carryfree.oneDigit_units_zero
#print axioms Agent14.Carryfree.oneDigit_units_zero
#check @Agent14.Carryfree.oneDigit_value
#print axioms Agent14.Carryfree.oneDigit_value
#check @Agent14.Carryfree.oneDigit_sum
#print axioms Agent14.Carryfree.oneDigit_sum
#check @Agent14.Carryfree.oneDigit_canonical
#print axioms Agent14.Carryfree.oneDigit_canonical
#check @Agent14.Carryfree.oneDigit_not_palindrome
#print axioms Agent14.Carryfree.oneDigit_not_palindrome
#check @Agent14.Carryfree.oneDigit_columns_bounded
#print axioms Agent14.Carryfree.oneDigit_columns_bounded
#check @Agent14.Carryfree.oneDigit_column_formula
#print axioms Agent14.Carryfree.oneDigit_column_formula
#check @Agent14.Carryfree.small_columns_actual_step
#print axioms Agent14.Carryfree.small_columns_actual_step
#check @Agent14.Carryfree.coefficientEval
#print axioms Agent14.Carryfree.coefficientEval
#check @Agent14.Carryfree.eval_one
#print axioms Agent14.Carryfree.eval_one
#check @Agent14.Carryfree.coefficientEval_congr
#print axioms Agent14.Carryfree.coefficientEval_congr
#check @Agent14.Carryfree.coefficientEval_add
#print axioms Agent14.Carryfree.coefficientEval_add
#check @Agent14.Carryfree.coefficientEval_spike
#print axioms Agent14.Carryfree.coefficientEval_spike
#check @Agent14.Carryfree.neg_one_pow_parity
#print axioms Agent14.Carryfree.neg_one_pow_parity
#check @Agent14.Carryfree.columns_eval_one
#print axioms Agent14.Carryfree.columns_eval_one
#check @Agent14.Carryfree.canonical_columns_eval_one
#print axioms Agent14.Carryfree.canonical_columns_eval_one
#check @Agent14.Carryfree.odd_columns_eval_neg_one
#print axioms Agent14.Carryfree.odd_columns_eval_neg_one
#check @Agent14.Carryfree.even_columns_eval_neg_one
#print axioms Agent14.Carryfree.even_columns_eval_neg_one
#check @Agent14.Carryfree.oddSeed
#print axioms Agent14.Carryfree.oddSeed
#check @Agent14.Carryfree.oddDigits
#print axioms Agent14.Carryfree.oddDigits
#check @Agent14.Carryfree.split_parameter
#print axioms Agent14.Carryfree.split_parameter
#check @Agent14.Carryfree.odd_seed_spec
#print axioms Agent14.Carryfree.odd_seed_spec
#check @Agent14.Carryfree.odd_carryfree_classes
#print axioms Agent14.Carryfree.odd_carryfree_classes
#check @Agent14.Carryfree.one_digit_seed_spec
#print axioms Agent14.Carryfree.one_digit_seed_spec
#check @Agent14.Carryfree.even_carryfree_classes
#print axioms Agent14.Carryfree.even_carryfree_classes
#check @Agent14.Carryfree.half_columns_eval_one
#print axioms Agent14.Carryfree.half_columns_eval_one
#check @Agent14.Carryfree.odd_seed_eval_neg_one
#print axioms Agent14.Carryfree.odd_seed_eval_neg_one
#check @Agent14.Carryfree.odd_seed_half_neg_one
#print axioms Agent14.Carryfree.odd_seed_half_neg_one
#check @Agent14.Carryfree.odd_seed_half_mod_eleven
#print axioms Agent14.Carryfree.odd_seed_half_mod_eleven
#check @Agent14.Carryfree.odd_source_coordinate_saturation
#print axioms Agent14.Carryfree.odd_source_coordinate_saturation
#check @Agent14.Carryfree.even_source_coordinate_saturation
#print axioms Agent14.Carryfree.even_source_coordinate_saturation
#check @Agent14.Carryfree.negative_half_control
#print axioms Agent14.Carryfree.negative_half_control
#check @Agent14.Carryfree.zero_classes_control
#print axioms Agent14.Carryfree.zero_classes_control
