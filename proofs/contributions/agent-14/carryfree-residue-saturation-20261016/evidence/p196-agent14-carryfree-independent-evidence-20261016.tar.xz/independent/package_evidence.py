#!/usr/bin/env python3
"""Losslessly package and stream-verify the complete carryfree review evidence."""
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import re
import stat
import tarfile


def file_digest(path):
    value = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1048576), b""):
            value.update(chunk)
    return value.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--independent", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--checkpoint")
    args = parser.parse_args()
    root = args.independent.resolve(strict=True)
    output = args.output.resolve()
    if output.parent != root:
        raise ValueError("The package output must be a direct child of the assigned evidence directory")
    if args.checkpoint is not None and not re.fullmatch(r"[0-9a-f]{40}", args.checkpoint):
        raise ValueError("A publication checkpoint must be a full commit identifier")
    output.mkdir(parents=False, exist_ok=True)
    archive_path = output / "p196-agent14-carryfree-independent-evidence-20261016.tar.xz"
    manifest_path = output / "MANIFEST.json"
    descriptor_path = output / "ARCHIVE.json"
    if any(path.exists() for path in [archive_path, manifest_path, descriptor_path]):
        raise ValueError("Refusing to overwrite a prior evidence package")
    receipt_path = root / "run-001" / "verification.json"
    receipt = json.loads(receipt_path.read_text())
    if receipt["status"] == "RUNNING" or not (root / "REVIEW.md").is_file():
        raise ValueError("Execution and the final review must finish before packaging")
    execution_manifest_path = root / "run-001" / "FILES.json"
    execution_manifest = json.loads(execution_manifest_path.read_text())
    for relative, rec in execution_manifest.items():
        path = (root / "run-001" / relative).resolve(strict=True)
        if not path.is_relative_to(root / "run-001"):
            raise ValueError("Execution manifest path escapes its scope")
        if path.stat().st_size != rec["bytes"] or file_digest(path) != rec["sha256"]:
            raise ValueError("Retained execution evidence changed: " + relative)

    selected, excluded = {}, []
    for folder, dirs, files in os.walk(root, followlinks=False):
        folder = Path(folder)
        for name in list(dirs):
            path = folder / name
            relative = "independent/" + path.relative_to(root).as_posix()
            if path == output:
                dirs.remove(name)
            elif path.is_symlink():
                raise ValueError("Unexpected evidence-directory symlink: " + relative)
            elif name in {"__pycache__", ".pytest_cache"}:
                dirs.remove(name)
                excluded.append({"path": relative, "kind": "reproducible_cache"})
        for name in files:
            path = folder / name
            relative = "independent/" + path.relative_to(root).as_posix()
            if path.is_symlink() or not stat.S_ISREG(path.stat().st_mode):
                raise ValueError("Unexpected nonregular evidence file: " + relative)
            rec = {"bytes": path.stat().st_size, "sha256": file_digest(path),
                   "mode": stat.S_IMODE(path.stat().st_mode)}
            if path.suffix in {".olean", ".ilean", ".o", ".pyc"}:
                excluded.append({"path": relative, "kind": "reproducible_compiled_object",
                                 "bytes": rec["bytes"], "sha256": rec["sha256"]})
            else:
                selected[relative] = dict(rec, source=path)
    expected_execution = {"independent/run-001/" + name for name in execution_manifest}
    if not expected_execution <= selected.keys():
        raise ValueError("The package selection omitted execution evidence")
    files = {
        name: {key: rec[key] for key in ["bytes", "sha256", "mode"]}
        for name, rec in sorted(selected.items())
    }
    manifest = {
        "schema_version": 1,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "scope": "Complete independent carryfree preparation, source contracts, unchanged canonical replay, fresh strict five-module build, exhaustive safe audit, public signatures and axiom reports, infrastructure, logs and review",
        "project": receipt["project"],
        "gate_status": receipt["status"],
        "repository_wide_pass": False,
        "target_published_source_commit": args.checkpoint,
        "source_binding": "The specialist verified the exact five retained local source hashes and registered Git blob identities. Any publication identifier supplied here is a parent-verified hash binding, not an independently fetched or checked-out commit.",
        "metadata_checkout_head": receipt.get("canonical", {}).get("metadata_checkout_head"),
        "source_roots": {"independent": str(root)},
        "execution_manifest_sha256": file_digest(execution_manifest_path),
        "execution_manifest_file_count": len(execution_manifest),
        "all_execution_manifest_files_verified": True,
        "file_count": len(files),
        "uncompressed_file_bytes": sum(rec["bytes"] for rec in files.values()),
        "files": files,
        "exclusions": excluded,
        "package_output_handling": "The generated package output directory is outside the input selection to avoid self-inclusion; MANIFEST.json is additionally included at the archive root and ARCHIVE.json remains external.",
        "runtime_handling": "The official distribution was not copied into this directory. Its release URL and verified digest are retained in PREPARATION.md and REVIEW.md; executed runtime identity is in run-001/verification.json.",
        "manifest_self_inclusion": "MANIFEST.json is not recursively listed in its own files map",
    }
    manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode()
    manifest_path.write_bytes(manifest_bytes)
    with tarfile.open(archive_path, mode="w:xz", preset=6) as archive:
        for name, rec in sorted(selected.items()):
            info = archive.gettarinfo(str(rec["source"]), arcname=name)
            with rec["source"].open("rb") as stream:
                archive.addfile(info, stream)
        info = tarfile.TarInfo("MANIFEST.json")
        info.size = len(manifest_bytes)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(manifest_bytes))

    expected = dict(files)
    expected["MANIFEST.json"] = {
        "bytes": len(manifest_bytes), "sha256": hashlib.sha256(manifest_bytes).hexdigest(),
    }
    verified = {}
    with tarfile.open(archive_path, mode="r|xz") as archive:
        for member in archive:
            name = member.name
            relative = PurePosixPath(name)
            if relative.is_absolute() or ".." in relative.parts or not member.isfile():
                raise ValueError("Unsafe or nonregular archive member: " + name)
            if name in verified or name not in expected:
                raise ValueError("Duplicate or unlisted archive member: " + name)
            value, count = hashlib.sha256(), 0
            with archive.extractfile(member) as stream:
                for chunk in iter(lambda: stream.read(1048576), b""):
                    value.update(chunk)
                    count += len(chunk)
            if count != expected[name]["bytes"] or value.hexdigest() != expected[name]["sha256"]:
                raise ValueError("Uncompressed archive member differs from its manifest: " + name)
            verified[name] = {"bytes": count, "sha256": value.hexdigest()}
    if set(verified) != set(expected):
        raise ValueError("The completed archive is missing an expected evidence member")
    descriptor = {
        "schema_version": 1,
        "status": "LOSSLESS_ARCHIVE_STREAM_VERIFIED",
        "archive": archive_path.name,
        "archive_path": str(archive_path),
        "archive_bytes": archive_path.stat().st_size,
        "archive_sha256": file_digest(archive_path),
        "manifest": manifest_path.name,
        "manifest_bytes": len(manifest_bytes),
        "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
        "evidence_file_count": len(files),
        "archive_member_count": len(verified),
        "uncompressed_evidence_bytes": manifest["uncompressed_file_bytes"],
        "all_execution_evidence_included": True,
        "verification_method": "Streaming tarfile r|xz extraction; every member's uncompressed byte count and SHA-256 compared in memory with MANIFEST.json; duplicates, extras and unsafe paths rejected",
        "extraction_to_disk_performed": False,
        "gate_status": receipt["status"],
        "target_published_source_commit": args.checkpoint,
        "recovery": [
            "Verify the archive and external manifest byte counts and SHA-256 digests against this descriptor.",
            "Create an empty extraction destination.",
            "Run: tar -xJf " + archive_path.name + " -C <destination>.",
            "Check each extracted path in MANIFEST.json by uncompressed byte count and SHA-256.",
            "Read independent/REVIEW.md and independent/run-001/verification.json. All gate commands, source snapshots, counts and literal public axiom reports are retained.",
            "Compiled project objects are reproducible and excluded. Recover the unmodified official Lean runtime from the release URL and archive digest in REVIEW.md, then use the documented fresh build command with source locations adjusted to the recovered identical files.",
        ],
        "exclusions": excluded,
        "descriptor_self_inclusion": "ARCHIVE.json is external because it records the completed archive digest; MANIFEST.json is both external and included at the archive root",
        "verified_at": datetime.now(timezone.utc).isoformat(),
    }
    descriptor_path.write_text(json.dumps(descriptor, indent=2) + "\n")
    print(json.dumps(descriptor, indent=2), flush=True)


if __name__ == "__main__":
    main()
