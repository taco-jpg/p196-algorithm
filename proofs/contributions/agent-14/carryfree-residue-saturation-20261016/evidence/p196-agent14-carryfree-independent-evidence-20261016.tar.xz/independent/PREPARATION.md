# Independent carryfree verification preparation

Status at preparation: **waiting for the final approved five-source contract**.
No mathematical compilation or new proof verification was performed during
preparation. This specialist authored only verification infrastructure.

The assigned reservation is `bdfdc25c3158b81e6c6e40109886cdf80c744e57`.
The expected closure is `LychrelDigitSums`, `Agent14CarryfreeResidues`,
`Agent14CarryfreeDigits`, `Agent14CarryfreeCoordinates`, and
`Agent14CarryfreeSaturation`, rooted at `Agent14CarryfreeSaturation`.
The final registry and the last two source hashes must be supplied before any
gate execution. The template intentionally cannot authorize execution.

## Infrastructure

`verify_carryfree.py` requires an approved contract, including every complete
source SHA-256, the registry path and digest, the exact registry project key,
and the source locations. It checks SHA-256 and the registered Git blob
identity of every original source, masks comments and strings for forbidden
source-token checks, and validates the exact import closure before compiling.
It permits no foundation adapter or additional project module.

`audit_support.py` retains the already executed exhaustive safe-constant audit
logic from the previous independent spectral gate. It inventories unsafe and
partial implementation declarations separately and checks all safe declaration
kinds, including theorem constants and definitions, by their actual imported
module origin. Its public-declaration parser uses `Agent14.Carryfree` and its
literal axiom parser accepts apostrophes in names and wrapped axiom lists.
The prior runner is retained in `development/` for provenance.

The original canonical verifier is copied without modification. Its SHA-256 is
`c047ff1ff1fe12b2c2094ca5f36af871b1c6faf89db593a102f9c2f7d48cc98a`.
Because its `ROOT` constant is derived from its own file path, execution uses
an exact copy inside a new minimal source snapshot. That snapshot contains
the registered source paths and unchanged registry bytes. It is not a complete
repository and is not a checkout of a publication commit.

The canonical script's existing `git rev-parse HEAD` and tracked-only
`git status` calls receive `GIT_DIR` and `GIT_WORK_TREE` pointing to the existing
checkout, with `GIT_OPTIONAL_LOCKS=0`. Their fields describe that checkout only.
No Git write or source publication is requested. The verification receipt
states this distinction explicitly; exact selected-source identity is supplied
by the independent SHA-256 and Git blob checks.

## Required executions after the final freeze

1. Replay the unchanged canonical verifier in a new directory. Its compiler
   flags remain `-j1 -DElab.async=false`; it does not use `--trust=0`.
2. Compile all five original mathematical sources again in a separate new
   directory with `--trust=0 -j1 -DElab.async=false`, starting with zero local
   project objects. No author or canonical project object is reused.
3. Audit every safe constant from all five module origins. Require the exact
   same theorem-name set as the canonical module audit and permit only
   `Classical.choice`, `Quot.sound`, and `propext` as transitive safe axioms.
4. Execute `#check @name` and literal `#print axioms name` for every explicit
   public declaration in all four new modules, verify its safe module origin,
   and compare its literal axiom set with the exhaustive audit.
5. Recheck original sources, snapshots, the approved contract, registry,
   verification infrastructure, and runtime identities. Preserve real commands,
   exit codes, timing, complete logs and a manifest excluding compiled objects.

Individual Lean commands use a 1800-second timeout; the wrapper around the
unchanged canonical run uses a 3600-second timeout. A failure is retained and
reported before any further attempt. Existing output directories cannot be
overwritten. All new sources, objects and reports remain below this
specialist's assigned memory-backed directory.

## Runtime provenance

The runtime is the unchanged official Lean 4.19.0 distribution, release commit
`6caaee842e94`, already verified during this session. The executable SHA-256 is
`92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023`.
The official source archive is
`https://github.com/leanprover/lean4/releases/download/v4.19.0/lean-4.19.0-linux.tar.zst`,
343842845 bytes, SHA-256
`6fe3ce97a58f44e2b3567d455b994eacec5bfe9ae7774f2a573444480ba813fe`.
The previous specialist verification compared all 4617 nondirectory archive
members with the installed distribution and recorded no mismatch or extra
installed file. This task reuses that verified distribution without copying it.

## Planned command

After the parent supplies and approves all final inputs, retain the resulting
contract as `frozen-inputs.json` and run:

```sh
python3 -B /dev/shm/agent14-carryfree-verification-d43e317f00d9/verify_carryfree.py \
  --contract /dev/shm/agent14-carryfree-verification-d43e317f00d9/frozen-inputs.json \
  --lean /workspace/scratch/d43e317f00d9/agent14-runtime/lean-4.19.0-linux/bin/lean \
  --output /dev/shm/agent14-carryfree-verification-d43e317f00d9/run-001
```

The scope is the selected five-module closure. No repository-wide proof result
or independently fetched publication commit is claimed.
