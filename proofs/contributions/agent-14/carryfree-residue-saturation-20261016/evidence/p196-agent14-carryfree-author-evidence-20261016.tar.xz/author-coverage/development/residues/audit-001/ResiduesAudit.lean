import Agent14CarryfreeResidues

#check (Agent14.Carryfree.residue_parameters :
  ∀ s r : Nat, s < 9 → r < 11 →
    ∃ u b : Nat, 1 ≤ u ∧ u ≤ 10 ∧ b ≤ 9 ∧
      (u + b) % 9 = s ∧ (u + 10 * b) % 11 = r)
#check (Agent14.Carryfree.even_residue_parameters :
  ∀ s : Nat, s < 9 → ∃ a : Nat, 1 ≤ a ∧ a ≤ 9 ∧ a % 9 = s)
#check (Agent14.Carryfree.ten_pow_mod99 :
  ∀ k : Nat, 10 ^ k % 99 = if k % 2 = 0 then 1 else 10)
#check (Agent14.Carryfree.odd_three_digit_mod99 :
  ∀ L a b c : Nat, 5 ≤ L → L % 2 = 1 →
    (a * 10 ^ (L - 1) + b * 10 ^ (L - 2) + c * 10 ^ (L - 3)) % 99 =
      (a + 10 * b + c) % 99)

#print axioms Agent14.Carryfree.residue_parameters
#print axioms Agent14.Carryfree.even_residue_parameters
#print axioms Agent14.Carryfree.ten_pow_mod99
#print axioms Agent14.Carryfree.odd_three_digit_mod99
