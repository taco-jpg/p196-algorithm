from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys

ROOT = Path('/dev/shm/agent14-carryfree-residues-d43e317f00d9')
DEVELOPMENT = ROOT / 'development/residues'
LEAN = Path('/workspace/scratch/f8aedc6d7adf/runtime-agent6/lean-4.19.0-linux/bin/lean')
IMPORTED = DEVELOPMENT / 'attempt-002'
AUDIT = DEVELOPMENT / 'audit-001'
AUDIT.mkdir()
source = AUDIT / 'ResiduesAudit.lean'
source.write_text(r"""import Agent14CarryfreeResidues

#check (Agent14.Carryfree.residue_parameters :
  ∀ s r : Nat, s < 9 → r < 11 →
    ∃ u b : Nat, 1 ≤ u ∧ u ≤ 10 ∧ b ≤ 9 ∧
      (u + b) % 9 = s ∧ (u + 10 * b) % 11 = r)
#check (Agent14.Carryfree.even_residue_parameters :
  ∀ s : Nat, s < 9 → ∃ a : Nat, 1 ≤ a ∧ a ≤ 9 ∧ a % 9 = s)
#check (Agent14.Carryfree.ten_pow_mod99 :
  ∀ k : Nat, 10 ^ k % 99 = if k % 2 = 0 then 1 else 10)
#check (Agent14.Carryfree.odd_three_digit_mod99 :
  ∀ L a b c : Nat, 5 ≤ L → L % 2 = 1 →
    (a * 10 ^ (L - 1) + b * 10 ^ (L - 2) + c * 10 ^ (L - 3)) % 99 =
      (a + 10 * b + c) % 99)

#print axioms Agent14.Carryfree.residue_parameters
#print axioms Agent14.Carryfree.even_residue_parameters
#print axioms Agent14.Carryfree.ten_pow_mod99
#print axioms Agent14.Carryfree.odd_three_digit_mod99
""")
argv = [str(LEAN), '--trust=0', '-j1', '-DElab.async=false', '-o', str(AUDIT / 'ResiduesAudit.olean'), str(source)]
env = os.environ.copy()
env['LEAN_PATH'] = str(IMPORTED)
expected = [
  'Agent14.Carryfree.residue_parameters',
  'Agent14.Carryfree.even_residue_parameters',
  'Agent14.Carryfree.ten_pow_mod99',
  'Agent14.Carryfree.odd_three_digit_mod99',
]
record = {
  'role': 'author import/type/axiom audit; not independent review',
  'argv': argv,
  'cwd': str(AUDIT),
  'environment_overrides': {'LEAN_PATH': str(IMPORTED)},
  'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
  'imported_source_sha256': hashlib.sha256((IMPORTED / 'Agent14CarryfreeResidues.lean').read_bytes()).hexdigest(),
  'imported_object_sha256': hashlib.sha256((IMPORTED / 'Agent14CarryfreeResidues.olean').read_bytes()).hexdigest(),
  'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
(AUDIT / 'command.json').write_text(json.dumps(record, indent=2) + '\n')
with (AUDIT / 'compiler.log').open('wb') as log:
  result = subprocess.run(argv, cwd=AUDIT, env=env, stdout=log, stderr=subprocess.STDOUT)
record['exit_code'] = result.returncode
record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
rows = []
for line in (AUDIT / 'compiler.log').read_text().splitlines():
  match = re.fullmatch(r"'([^']+)' depends on axioms: \[(.*)\]", line)
  if match:
    rows.append({'declaration': match.group(1), 'axioms': [a.strip() for a in match.group(2).split(',') if a.strip()]})
allowed = {'propext', 'Classical.choice', 'Quot.sound'}
record['expected_declarations'] = expected
record['actual_declarations'] = [r['declaration'] for r in rows]
record['exact_name_coverage'] = record['actual_declarations'] == expected
record['axiom_union'] = sorted({a for row in rows for a in row['axioms']})
record['allowed_axioms_only'] = set(record['axiom_union']) <= allowed
record['audit_pass'] = result.returncode == 0 and record['exact_name_coverage'] and record['allowed_axioms_only']
(AUDIT / 'parsed-axioms.json').write_text(json.dumps(rows, indent=2) + '\n')
(AUDIT / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record, indent=2))
print((AUDIT / 'compiler.log').read_text())
sys.exit(0 if record['audit_pass'] else 1)
