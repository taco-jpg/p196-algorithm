from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys

ROOT = Path('/dev/shm/agent14-carryfree-residues-d43e317f00d9')
DEVELOPMENT = ROOT / 'development/residues'
SOURCE = ROOT / 'Agent14CarryfreeResidues.lean'
LEAN = Path('/workspace/scratch/f8aedc6d7adf/runtime-agent6/lean-4.19.0-linux/bin/lean')
attempt_number = int(sys.argv[1])
attempt = DEVELOPMENT / f'attempt-{attempt_number:03d}'
attempt.mkdir()
snapshot = attempt / SOURCE.name
shutil.copyfile(SOURCE, snapshot)
argv = [str(LEAN), '--trust=0', '-j1', '-DElab.async=false', '-o', str(attempt / 'Agent14CarryfreeResidues.olean'), str(snapshot)]
env = os.environ.copy()
env.pop('LEAN_PATH', None)
record = {
    'argv': argv,
    'cwd': str(attempt),
    'source': str(snapshot),
    'source_sha256': hashlib.sha256(snapshot.read_bytes()).hexdigest(),
    'source_bytes': snapshot.stat().st_size,
    'executable_sha256': hashlib.sha256(LEAN.read_bytes()).hexdigest(),
    'environment_overrides': {'LEAN_PATH': None},
    'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
(attempt / 'command.json').write_text(json.dumps(record, indent=2) + '\n')
with (attempt / 'compiler.log').open('wb') as log:
    result = subprocess.run(argv, cwd=attempt, env=env, stdout=log, stderr=subprocess.STDOUT)
record['exit_code'] = result.returncode
record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
artifact = attempt / 'Agent14CarryfreeResidues.olean'
if artifact.exists():
    record['object_bytes'] = artifact.stat().st_size
    record['object_sha256'] = hashlib.sha256(artifact.read_bytes()).hexdigest()
(attempt / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({'attempt': str(attempt), 'exit_code': result.returncode, 'source_sha256': record['source_sha256']}))
print((attempt / 'compiler.log').read_text())
sys.exit(result.returncode)
