from pathlib import Path
import datetime
import hashlib
import json
import os
import re
import subprocess
import sys

ROOT = Path('/dev/shm/agent14-carryfree-residues-d43e317f00d9')
DEVELOPMENT = ROOT / 'development/coordinates'
DEPENDENCIES = ROOT / 'dependencies/coordinates'
LEAN = Path('/workspace/scratch/f8aedc6d7adf/runtime-agent6/lean-4.19.0-linux/bin/lean')
IMPORTED = DEVELOPMENT / 'attempt-002'
AUDIT = DEVELOPMENT / 'audit-001'
AUDIT.mkdir()
source = AUDIT / 'CoordinatesAudit.lean'
expected_short = [
  'coefficientEval', 'eval_one', 'coefficientEval_congr', 'coefficientEval_add',
  'coefficientEval_spike', 'neg_one_pow_parity', 'columns_eval_one',
  'canonical_columns_eval_one', 'odd_columns_eval_neg_one', 'even_columns_eval_neg_one',
]
implementation = ROOT / 'Agent14CarryfreeCoordinates.lean'
actual_short = re.findall(r'^(?:def|theorem) ([A-Za-z0-9_]+)', implementation.read_text(), re.MULTILINE)
assert actual_short == expected_short, actual_short
expected = ['Agent14.Carryfree.' + n for n in expected_short]
expected_sha = json.loads((IMPORTED / 'result.json').read_text())['source_sha256']
assert hashlib.sha256(implementation.read_bytes()).hexdigest() == expected_sha
checks = r"""import Agent14CarryfreeCoordinates

open DecimalDigits DecimalMass Agent14.Carryfree

#check (Agent14.Carryfree.coefficientEval : (Nat → Nat) → Nat → Int → Int)
#check (Agent14.Carryfree.eval_one :
  ∀ (q : Nat → Nat) (L : Nat), coefficientEval q L 1 = (wordSum q L : Int))
#check (Agent14.Carryfree.coefficientEval_congr :
  ∀ (q r : Nat → Nat) (L : Nat) (x : Int),
    (∀ i, i < L → q i = r i) → coefficientEval q L x = coefficientEval r L x)
#check (Agent14.Carryfree.coefficientEval_add :
  ∀ (q r : Nat → Nat) (L : Nat) (x : Int),
    coefficientEval (fun i => q i + r i) L x =
      coefficientEval q L x + coefficientEval r L x)
#check (Agent14.Carryfree.coefficientEval_spike :
  ∀ (k a L : Nat) (x : Int), coefficientEval (spike k a) L x =
    if k < L then (a : Int) * x ^ k else 0)
#check (Agent14.Carryfree.neg_one_pow_parity :
  ∀ k : Nat, (-1 : Int) ^ k = if k % 2 = 0 then 1 else -1)
#check (Agent14.Carryfree.columns_eval_one :
  ∀ (d : Nat → Nat) (L : Nat), coefficientEval (columnSum d L) L 1 =
    2 * (wordSum d L : Int))
#check (Agent14.Carryfree.canonical_columns_eval_one :
  ∀ (n : Nat) (d : Nat → Nat) (L : Nat), Canonical n d L →
    coefficientEval (columnSum d L) L 1 = 2 * (digitSum n : Int))
#check (Agent14.Carryfree.odd_columns_eval_neg_one :
  ∀ a b c L : Nat, 5 ≤ L → L % 2 = 1 →
    coefficientEval (columnSum (threeDigits a b c L) L) L (-1) =
      2 * ((a : Int) - (b : Int) + (c : Int)))
#check (Agent14.Carryfree.even_columns_eval_neg_one :
  ∀ a L : Nat, 2 ≤ L → L % 2 = 0 →
    coefficientEval (columnSum (oneDigit a L) L) L (-1) = 0)

"""
source.write_text(checks + ''.join('#print axioms ' + n + '\n' for n in expected))
argv = [str(LEAN), '--trust=0', '-j1', '-DElab.async=false', '-o', str(AUDIT / 'CoordinatesAudit.olean'), str(source)]
env = os.environ.copy()
env['LEAN_PATH'] = str(IMPORTED) + ':' + str(DEPENDENCIES)
record = {
  'role': 'author import/type/axiom audit; not independent review',
  'argv': argv,
  'cwd': str(AUDIT),
  'environment_overrides': {'LEAN_PATH': env['LEAN_PATH']},
  'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
  'imported_source_sha256': hashlib.sha256((IMPORTED / 'Agent14CarryfreeCoordinates.lean').read_bytes()).hexdigest(),
  'imported_object_sha256': hashlib.sha256((IMPORTED / 'Agent14CarryfreeCoordinates.olean').read_bytes()).hexdigest(),
  'dependencies': json.loads((DEVELOPMENT / 'dependency-copy.json').read_text()),
  'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
}
(AUDIT / 'command.json').write_text(json.dumps(record, indent=2) + '\n')
with (AUDIT / 'compiler.log').open('wb') as log:
  result = subprocess.run(argv, cwd=AUDIT, env=env, stdout=log, stderr=subprocess.STDOUT)
record['exit_code'] = result.returncode
record['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
rows = []
for line in (AUDIT / 'compiler.log').read_text().splitlines():
  match = re.fullmatch(r"'([^']+)' depends on axioms: \[(.*)\]", line)
  empty = re.fullmatch(r"'([^']+)' does not depend on any axioms", line)
  if match:
    rows.append({'declaration': match.group(1), 'axioms': [a.strip() for a in match.group(2).split(',') if a.strip()]})
  elif empty:
    rows.append({'declaration': empty.group(1), 'axioms': []})
allowed = {'propext', 'Classical.choice', 'Quot.sound'}
record['expected_declarations'] = expected
record['actual_declarations'] = [r['declaration'] for r in rows]
record['exact_name_coverage'] = record['actual_declarations'] == expected
record['axiom_union'] = sorted({a for row in rows for a in row['axioms']})
record['allowed_axioms_only'] = set(record['axiom_union']) <= allowed
record['audit_pass'] = result.returncode == 0 and record['exact_name_coverage'] and record['allowed_axioms_only']
(AUDIT / 'parsed-axioms.json').write_text(json.dumps(rows, indent=2) + '\n')
(AUDIT / 'result.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps({k: record[k] for k in ['exit_code','imported_source_sha256','imported_object_sha256','exact_name_coverage','axiom_union','allowed_axioms_only','audit_pass']}, indent=2))
print((AUDIT / 'compiler.log').read_text())
sys.exit(0 if record['audit_pass'] else 1)
