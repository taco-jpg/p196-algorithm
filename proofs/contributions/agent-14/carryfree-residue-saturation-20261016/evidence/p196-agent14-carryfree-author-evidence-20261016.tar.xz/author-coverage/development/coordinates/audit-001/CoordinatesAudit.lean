import Agent14CarryfreeCoordinates

open DecimalDigits DecimalMass Agent14.Carryfree

#check (Agent14.Carryfree.coefficientEval : (Nat → Nat) → Nat → Int → Int)
#check (Agent14.Carryfree.eval_one :
  ∀ (q : Nat → Nat) (L : Nat), coefficientEval q L 1 = (wordSum q L : Int))
#check (Agent14.Carryfree.coefficientEval_congr :
  ∀ (q r : Nat → Nat) (L : Nat) (x : Int),
    (∀ i, i < L → q i = r i) → coefficientEval q L x = coefficientEval r L x)
#check (Agent14.Carryfree.coefficientEval_add :
  ∀ (q r : Nat → Nat) (L : Nat) (x : Int),
    coefficientEval (fun i => q i + r i) L x =
      coefficientEval q L x + coefficientEval r L x)
#check (Agent14.Carryfree.coefficientEval_spike :
  ∀ (k a L : Nat) (x : Int), coefficientEval (spike k a) L x =
    if k < L then (a : Int) * x ^ k else 0)
#check (Agent14.Carryfree.neg_one_pow_parity :
  ∀ k : Nat, (-1 : Int) ^ k = if k % 2 = 0 then 1 else -1)
#check (Agent14.Carryfree.columns_eval_one :
  ∀ (d : Nat → Nat) (L : Nat), coefficientEval (columnSum d L) L 1 =
    2 * (wordSum d L : Int))
#check (Agent14.Carryfree.canonical_columns_eval_one :
  ∀ (n : Nat) (d : Nat → Nat) (L : Nat), Canonical n d L →
    coefficientEval (columnSum d L) L 1 = 2 * (digitSum n : Int))
#check (Agent14.Carryfree.odd_columns_eval_neg_one :
  ∀ a b c L : Nat, 5 ≤ L → L % 2 = 1 →
    coefficientEval (columnSum (threeDigits a b c L) L) L (-1) =
      2 * ((a : Int) - (b : Int) + (c : Int)))
#check (Agent14.Carryfree.even_columns_eval_neg_one :
  ∀ a L : Nat, 2 ≤ L → L % 2 = 0 →
    coefficientEval (columnSum (oneDigit a L) L) L (-1) = 0)

#print axioms Agent14.Carryfree.coefficientEval
#print axioms Agent14.Carryfree.eval_one
#print axioms Agent14.Carryfree.coefficientEval_congr
#print axioms Agent14.Carryfree.coefficientEval_add
#print axioms Agent14.Carryfree.coefficientEval_spike
#print axioms Agent14.Carryfree.neg_one_pow_parity
#print axioms Agent14.Carryfree.columns_eval_one
#print axioms Agent14.Carryfree.canonical_columns_eval_one
#print axioms Agent14.Carryfree.odd_columns_eval_neg_one
#print axioms Agent14.Carryfree.even_columns_eval_neg_one
