# Overflow residue saturation: read-only closure

Status: CLOSED AS OWNED BY AGENT #51. This is Agent #14's source reconnaissance and an unformalized sharpening suggestion, not a new ownership claim or a Lean contribution. No implementation, compilation, Git write, or external post was performed for this scout.

## Ownership and source pins

The exact task proofs/coordination/tasks/agent51-spectral-overflow-saturation-20261016.json was read at coordination commit 688c2115f8ddb55ab952f6a33dfc2ae0a9bb7051. Its Git blob is c6e10644a2398bdc19262a80bec7f06144b8f25d. Owner: Agent #51; status: CLAIMED; source snapshot: 54ac7c885e54ce74190b85ec82cceca2b23c2e38. Agent #51 owns the construction, the literal coefficient evaluations, and the saturation theorem. Any subsequent implementation of the suggestion below should remain with that owner unless coordination explicitly changes.

Original source: proofs/research/astra_spectral_carry_quotient.md at source snapshot 2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5; archived path proofs/archive/source-trees/2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5/proofs/research/astra_spectral_carry_quotient.md. Blob eac5b8f61385a615d9cc3e7796a4d698c66b716b; SHA-256 d39212c9ab98f4c5b0fccb733d3b662e41a09804878178c82b8762684e97fb09. The relevant source is Theorem 3, especially the overflow paragraphs.

Original decimal library: proofs/research/continuation/LychrelDigitSums.lean; blob 8a865176625283648a8a20dd2411ed77670eb0a2; SHA-256 ca5f46523b7cff02c00918b6466a97963087b499fb5f184232b8b3d806dc0b57.

## Exact source endpoint and scope

For each even width L >= 18, and each odd width L >= 19, all nine residue classes s in {0,...,8} have a positive canonical nonpalindromic integer input of exact width L whose actual terminal carry is one, whose next reverse-and-add output is a palindrome, and whose literal coefficient polynomial satisfies

    Q(1) / 2 mod 9 = s,
    Q(-1) / 2 mod 11 = 0.

The source chooses k in {1,...,9} symmetric pairs, including the outer pair, with coefficient 11; every other coefficient is zero, including the odd center. Then Q(1) = 22k and s = 11k mod 9. The digit split 2 at the low end and 9 at the high end realizes each selected pair. In the contiguous-pair specialization, the actual digits are 2 for i < k, 9 for L-k <= i < L, and zero elsewhere, with 2k <= L. This is the same family now claimed by Agent #51.

Only nine classes with alternating residue zero are covered, even at odd width. The source does not claim all 99 odd-width classes in the overflow branch. At even width the alternating residue is a property of Q, not the assertion n mod 11 = 0. The mention of a previous overflow describes the quotient component that has died; the witness theorem does not supply an actual predecessor history containing an earlier overflow.

All carries are actual outgoing carries c_i = carry q (i+1). The entrance carry zero is not inserted into that coefficient word. For these patterns c_i = q_i/11, so not every carry is one: unselected zero columns have outgoing carry zero.

## Existing exact coverage and minimal remaining construction

The original library already proves the complete zero-or-eleven overflow palindrome criterion, the actual width-L+1 canonical output bridge, canonical realizability of every admissible reciprocal coefficient word, and the pointwise identity q_i = 11*c_i in the exceptional branch.

In particular:
- DecimalCarry.zero_or_eleven_digit_sums_give_palindrome proves the terminal carry and reflected output equations from the full column recurrence.
- DecimalDigits.overflow_palindrome_iff and DecimalDigits.step_palindrome_iff_overflow provide the actual decimal criterion.
- FoldedDecimal.canonical_next_overflow establishes the canonical width of the actual next integer.
- FoldedDecimal.realizingDigit and valid_word_realizable already realize a symmetric word with bounded entries and even odd center. For a selected coefficient 11 this realizer uses exactly the digits 2 and 9.
- DecimalMass.columns_eq_eleven_carry identifies the coefficient word with eleven times the actual outgoing carry word.
- DecimalMass.wordSum_columns identifies Q(1) with twice the input digit sum.

Thus the useful new obligations are the chosen mask, its exact pair count, the actual witness package, and the literal evaluations/residue coverage. Reproving the general realizer or the complete exceptional-pattern criterion would not add new source coverage. The Agent #15 carry-support scope already covers the nine-free symmetry consequence and the associated zero charge; that theorem should be reused if needed.

For the contiguous-pair specialization the alternating coefficient sum is exactly zero when L is even. When L is odd it is zero for even k and 22 for odd k. Both cases give the required half-alternating residue zero modulo 11. A finite alternating-sum induction proves this directly.

A canonical witness with q_0 = 11 is automatically nonpalindromic: a palindromic input would have equal outer digits, making q_0 an even number. This is an optional short bridge, not a claim that the entire source family needs a new general classification.

## Additional read-only inference: the source thresholds are sharp

This paragraph is an inference from the existing library, not a statement of optimality made in the source note. It has not been formalized or compiled by Agent #14.

For every positive canonical input of width L with actual terminal overflow and palindromic next output, put S = digitSum n and C = carryCount q L. The existing exceptional-pattern criterion and columns_eq_eleven_carry give

    2*S = 11*C.

The existing carry_bounded theorem gives C <= L, because carryCount is the sum of exactly L binary outgoing carries. Also S > 0 by canonicity. If the retained residue class is zero, S mod 9 = 0, then S is a positive multiple of both 9 and 11. Therefore S >= 99, C >= 18, and L >= 18.

Consequently, the class s = 0 cannot have an overflow-palindrome witness below width 18. The source's all-nine-class threshold 18 is optimal; restricted to odd widths the first possible threshold is 19. This argument requires neither a nonpalindromicity hypothesis nor a special mask family.

Candidate contract, for Agent #51 to assess within its ownership:

    theorem zero_class_overflow_requires_width
        (n L : Nat) (d : Nat -> Nat)
        (hcan : DecimalDigits.Canonical n d L)
        (hcarry : DecimalDigits.carry
          (DecimalDigits.columnSum d L) L = 1)
        (hpal : Lychrel196.Palindrome (Lychrel196.step n))
        (hzero : DecimalMass.digitSum n % 9 = 0) :
        18 <= L

The fully qualified namespace of Palindrome should be checked against the owner's imports before using this schematic contract; the mathematical endpoint and quantifiers are exact. This is a candidate statement, not an assertion that a declaration with this name exists.

Minimal proof dependencies are the actual overflow palindrome criterion, wordSum_columns, columns_eq_eleven_carry, carry_bounded, the definition of carryCount, and positivity of canonical digit mass. A sum bound C <= L may need a short induction. The rest is elementary divisibility arithmetic. The mass disjunction palindrome_step_digitSum alone is weaker than needed because it forgets which actual carry branch occurred.

## Coordination disposition

The Agent #51 reservation explicitly includes the source parity-threshold corollaries, but does not explicitly claim optimality. The sharpening may be relayed by the parent on issue #61 with scout attribution to Agent #14. No new reservation is requested. This scout is closed, and the next authorized activity is read-only investigation of unowned spectral evolution obligations.
