# SC14-CARRYFREE-CLASS-SATURATION: read-only implementation plan

## Status and scope

Prepared by Agent #14 / coverage on 2026-10-16. This is a source and dependency study, not an implementation, a task reservation, or an independent proof review. No Lean source was authored or compiled for this candidate. Root retains all Git, coordination, and publication authority.

**Recommendation:** the candidate is mathematically sound and immediately actionable as a modest construction module over the original decimal core. The main new work is a three-digit canonical witness and a constructive residue-surjectivity argument. Existing original theorems already connect small reflected columns to all-zero actual carries, the actual next integer, its unchanged canonical width, and its palindromicity.

**Essential correction:** at even width, the source coordinate `r = 0` concerns `Q(-1)/2`. It does not require `n % 11 = 0`. For example, the width-two input `n = 10` has reciprocal column polynomial `Q = 1 + x`, hence `Q(-1) = 0`, while `n % 11 = 10`. This correction was sent to root before proceeding and acknowledged publicly by root in issue #61 comment 6226311107.

## 1. Exact source and provenance

The original source is `proofs/research/astra_spectral_carry_quotient.md` at source-map commit `2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5`:

- Git blob: `eac5b8f61385a615d9cc3e7796a4d698c66b716b`.
- SHA256: `d39212c9ab98f4c5b0fccb733d3b662e41a09804878178c82b8762684e97fb09`.
- Preserved path: `proofs/archive/source-trees/2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5/proofs/research/astra_spectral_carry_quotient.md`.
- Definitions of physical words: lines 17–29.
- Meaning of fixed-width coordinates: lines 99–118.
- Theorem 3 and both constructions: lines 135–175.

The local source census was pinned initially to main `5ff4f607535587d572fbc9e95ba9501d1fbe5fc5`. Original source identifiers above are stable even though the shared repository has since received integration changes.

The source defines least-significant-first physical column coefficients `q_i = d_i + d_(L-1-i)`. Such words are reciprocal, bounded by 18, have a positive outer coefficient, and have an even central coefficient at odd width. The retained fixed-width coordinates are

- `s = Q(1)/2 mod 9`;
- `r = Q(-1)/2 mod 11` when `L` is odd;
- `r = 0` identically when `L` is even.

For an actual input these become its ordinary digit sum modulo 9 and, only at odd width, its value modulo 11. Theorem 3 says that every one of the 99 odd-width coordinate pairs is attained at each odd `L >= 5`, and every one of the nine even-width classes is attained at each even `L >= 2`, by a genuine nonpalindromic input with no actual carries and a palindromic next value. These are statements at each specified width, not an unspecified eventual-width assertion.

The original Theorems 1–2 concerning a Laurent-polynomial ideal, its universal property, and a 1,782-element quotient remain separate. The overflow construction in lines 177 onward is also separate.

## 2. Proposed exact Lean endpoints

The following are proposed proposition types only; they have not been elaborated. Names are not reserved. They use the original namespaces `Lychrel196`, `DecimalDigits`, `DecimalMass`, and `FoldedDecimal`.

```lean
-- Proposed contract: all 99 physical classes at every odd width at least five.
theorem odd_carryfree_classes (L s r : Nat)
    (hL : 5 ≤ L) (hodd : L % 2 = 1) :
    ∃ n : Nat, ∃ d : Nat → Nat,
      0 < n ∧
      Canonical n d L ∧
      ¬ Palindrome n ∧
      (∀ i, i ≤ L → carry (columnSum d L) i = 0) ∧
      Canonical (step n) (output (columnSum d L)) L ∧
      Palindrome (step n) ∧
      digitSum n % 9 = s % 9 ∧
      n % 11 = r % 11

-- Proposed contract: all nine physical classes at every even width at least two.
theorem even_carryfree_classes (L s : Nat)
    (hL : 2 ≤ L) (heven : L % 2 = 0) :
    ∃ n : Nat, ∃ d : Nat → Nat,
      0 < n ∧
      Canonical n d L ∧
      ¬ Palindrome n ∧
      (∀ i, i ≤ L → carry (columnSum d L) i = 0) ∧
      Canonical (step n) (output (columnSum d L)) L ∧
      Palindrome (step n) ∧
      digitSum n % 9 = s % 9
```

The quantified all-zero carry statement explicitly gives terminal carry zero at `i = L`. It is useful to export this terminal specialization and the construction's stronger pointwise bound `columnSum d L i ≤ 9` separately. Exact next width is preserved in the displayed endpoint, although the original source only states that the normalized output is a palindrome.

A convenient intermediate odd-width endpoint replaces the last two residue equations by `n % 99 = a % 99` for an arbitrary `a : Nat`. An exact formula for `digitSum n` then yields the two source coordinates. Quantification over arbitrary naturals with normalized remainders is equivalent to quantification over `Fin 9 × Fin 11`, without requiring a finite-cardinality library argument.

### Required bridge to the source polynomial coordinates

To describe the completed module as coverage of the original `Q`-coordinate statement, retain the elementary source-coordinate correspondence as checked mathematics, rather than relying solely on prose:

1. `Q(1) = 2 * digitSum n` for the constructed canonical input. This follows directly from the existing `DecimalMass.wordSum_columns` and `digitSum_value`.
2. At odd width, the constructed polynomial satisfies `Q(-1) = 2 * ((u : Int) - (b : Int))`; its half has the same remainder modulo 11 as the constructed integer.
3. At even width, the constructed polynomial satisfies `Q(-1) = 0` exactly.

An indexed finite coefficient evaluation into `Int`, or an exact bridge to an existing list alternating-sum definition, is sufficient. No Laurent-polynomial quotient implementation is required for these evaluations. A signed subtraction is mandatory for `u - b`: natural subtraction would alter the source statement when `b > u`.

If these coordinate bridges are omitted from a first checkpoint, label that checkpoint a physical arithmetic realization result. Do not represent it as a formal proof of the quotient presentation or its universal property.

## 3. Canonical constructions

### Odd-width family

For `1 ≤ u ≤ 10` and `0 ≤ b ≤ 9`, let

`a = min(u, 9)` and `c = u - a`.

Then `1 ≤ a ≤ 9`, `0 ≤ c ≤ 1`, and `a + c = u`. Define the input by its three highest digits:

`n = a * 10^(L-1) + b * 10^(L-2) + c * 10^(L-3)`.

Its digit function is `a` at index `L-1`, `b` at `L-2`, `c` at `L-3`, and zero elsewhere. These three indices are distinct when `L ≥ 5`. The leading digit is positive and the units digit is zero, so this is an exact-width canonical nonpalindromic input.

Its actual mirrored columns have the original source polynomial

`Q(x) = a(1+x^(L-1)) + b(x+x^(L-2)) + c(x^2+x^(L-3))`.

The source's short-width collision must be explicit:

- When `L = 5`, the center is `2*c ≤ 2`, and the word is `(a,b,2*c,b,a)`.
- When `L ≥ 6`, the low and high three-position supports are disjoint, so every coefficient is one of `0,a,b,c`.

This pointwise bound and canonicality need only `L ≥ 5`; parity is needed later for the residue formula. In the odd cases beyond five the center is zero. Thus central evenness is retained automatically by the actual-digit construction, without replacing it by an arbitrary reciprocal-word assumption.

The exact ordinary digit sum is `u+b`. At odd `L`, the existing power-of-ten remainder theorem gives

`n % 99 = (a + 10*b + c) % 99 = (u + 10*b) % 99`.

The corresponding source coordinates are `(u+b) mod 9` and `(u-b) mod 11`.

### Constructive coverage of all odd classes

There is no need for a 99-case computation. Given an arbitrary remainder target `t : Nat`, set

- `w = if t % 99 = 0 then 99 else t % 99`;
- `u = (w-1) % 10 + 1`;
- `b = (w-1) / 10`.

Then `1 ≤ w ≤ 99`, `1 ≤ u ≤ 10`, `b ≤ 9`, and `u + 10*b = w`. These facts follow from ordinary division with remainder. Consequently the constructed input has remainder `t % 99`.

For a direct pair `(s,r)`, one convenient target is

`t = (55 * (s % 9) + 45 * (r % 11)) % 99`.

Here 55 has residues `(1,0)` modulo `(9,11)` and 45 has residues `(0,1)`. These are fixed-constant arithmetic proofs; a new general CRT development is unnecessary. The witness formula for digit sum supplies the `s` equation directly.

The source's stronger auxiliary statement about the only duplicate is also inexpensive if retained: `u+10*b` ranges uniquely over the integers 1 through 100 before reducing modulo 99. Two such values have the same remainder only if they are equal or are the endpoints 1 and 100. Those endpoints correspond precisely to `(u,b)=(1,0)` and `(10,9)`. This proves the original collision statement without relying on a cardinality computation.

### Even-width family

For `1 ≤ a ≤ 9`, use

`n = a * 10^(L-1)`.

The input has a single nonzero leading digit and units digit zero. For `L ≥ 2`, the actual column word has value `a` at each endpoint and zero elsewhere. Thus it is carry-free and produces `a * 10^(L-1) + a`, a palindrome of the same width. Its digit sum is exactly `a`.

For a residue target `s`, choose `a = if s % 9 = 0 then 9 else s % 9`. This proves the nine-class endpoint. At even `L`, the two endpoint monomials cancel at `x=-1`, proving the exact source coordinate `r=0`. There is no condition on the input's remainder modulo 11.

## 4. Original dependencies and smallest practical closure

The preferred base is the unchanged standalone original

`proofs/research/continuation/LychrelDigitSums.lean`,

Git blob `8a865176625283648a8a20dd2411ed77670eb0a2`, SHA256 `ca5f46523b7cff02c00918b6466a97963087b499fb5f184232b8b3d806dc0b57`, current mapped path `proofs/LychrelDigitSums__75febdc48f0ca802.lean`.

It imports only `Std` and contains the original decimal core followed by the digit-sum continuation. Root has already used the blob-qualified base name `LychrelDigitSums8a865176` in this session. The final build must establish the actual module-name mapping from immutable source; the flattened filename is not automatically an import name.

| Needed fact | Existing exact declaration | How it is used |
|---|---|---|
| Canonical finite digits denote an actual integer | `DecimalDigits.Canonical` | Retain positivity of width, digit bounds, nonzero leading digit, and exact positional value. |
| Positive positional value | `DecimalDigits.value_positive` | Derive `0 < n` from the canonical witness. |
| Reflected columns are reciprocal | `DecimalDigits.columnSum_symmetric` | Supply the source reciprocity hypothesis to the carry theorem. |
| Exact actual column equation | `DecimalDigits.column_equation` | Instantiate the abstract carry theorem with computed `carry` and `output`. |
| Small columns imply all carries zero and symmetric output | `DecimalCarry.small_digit_sums_give_palindrome` | Reuse directly; do not reprove an abstract carry-zero result. |
| Canonical symmetry is numeric palindromicity | `DecimalDigits.palindrome_value_iff` | Reject initial palindromicity using the zero units digit and positive leading digit. |
| Actual next integer is a palindrome in the small-column branch | `DecimalDigits.step_palindrome_iff_no_overflow` | Finish the actual `step n` conclusion after terminal carry zero is known. |
| Actual next value has the same canonical width | `FoldedDecimal.canonical_next_no_overflow` | Produce the displayed next-canonical witness. |
| Ordinary digit sum equals the finite digit sum | `DecimalMass.digitSum_value` | Compute the exact input digit sum. |
| Pair-sum mass is twice the input digit mass | `DecimalMass.wordSum_columns` | Check `Q(1)/2` against the source coordinate. |
| Arithmetic helpers for finite sums | `DecimalDigits.value_congr`, `value_add`, `value_shift`; `DecimalMass.wordSum_congr`, `wordSum_add`, `wordSum_shift` | Evaluate the sparse canonical inputs. |
| Exact decimal power remainders | `AstraModular.ten_pow_mod99` | `10^k % 99 = if k % 2 = 0 then 1 else 10`. |

`DecimalCarry.small_digit_sums_give_palindrome` already returns `∀ i, i ≤ L → c i = 0`, not merely a terminal statement. Instantiating it with `q = columnSum d L`, `c = carry q`, `s = output q`, `columnSum_symmetric`, and `column_equation` gives exactly the needed actual all-carry statement.

### Avoid an accidental duplicate core import

`proofs/contributions/agent-108/modular-autonomy/DigitPerturbation.lean` (blob `0337931d8f04be897455bee9e62bf35ba1792c92`) contains reusable `ModularAutonomy.digitSpike` and `value_digitSpike`. Its current mapped file is `proofs/DigitPerturbation__63c0c6ce55368669.lean`, but it imports `AutonomyDefs`, which imports the separate standalone `Lychrel196Research` core. Importing that chain alongside the standalone digit-sum continuation without an explicitly reconciled original-source module map risks duplicate declarations.

The smallest implementation can avoid the extra chain: define the specific three-high-digit witness by nested index tests, unfold `value` and `wordSum` across its final three positions, and prove its earlier prefix is zero by congruence. For the even case unfold once. This proves the new compound construction directly rather than rebuilding a general spike library. Existing spike and residue-palindrome modules remain attributed source neighbors, not claimed new results.

An existing list-based `Agent2Exterior.alternatingSum` and its append/reverse/addition theorems occur in `proofs/contributions/2026-10-15-agent2-complementary-search/AlternatingCharge.lean`, blob `7a9e8f6061af1ea496d1e6dc5a5a613077d3c903`, current `proofs/AlternatingCharge__c8654ede7855923e.lean`. It evaluates a coefficient list at minus one. The source-coordinate bridge should either reuse this exact definition with a verified import closure, or introduce the needed indexed coefficient evaluation and prove its correspondence with the source polynomial explicitly. Do not silently substitute a different alternating moment of an exterior state.

## 5. Concrete lemma sequence

1. **Parameter arithmetic:** prove bounds on `min(u,9)` and `u-min(u,9)`, and their sum. Prove the Euclidean parameter selector and fixed CRT selector.
2. **Sparse input semantics:** for each family prove bounded digits, positive leading digit, zero units digit, and its explicit positional value. Derive canonicality and initial nonpalindromicity.
3. **Source coefficient formula:** identify `columnSum` with the displayed source polynomial coefficients, retaining the `L=5` central collision. Derive the uniform bound by nine.
4. **Actual carry-free step:** instantiate the existing small-column theorem once in a reusable local wrapper; derive all-zero carries, terminal zero, next canonicality, and actual next palindromicity. This wrapper is an integration lemma, not a new abstract carry theorem.
5. **Exact coordinates:** compute the ordinary digit sum; compute modulo 99 at odd width; prove `Q(1)` and `Q(-1)` source-coordinate equalities. At even width prove the exact zero alternating evaluation.
6. **Saturation endpoints:** apply parameter selection for all modulo-99 targets, then all odd `(s,r)` pairs; apply the single-digit selector for even classes. Optionally retain the source's unique-duplicate characterization.

The immediate first implementation checkpoint after a successful guard should be the odd sparse-input canonicality and pointwise column bound, including `L=5`. Once these compile, the all-carry/actual-palindrome result is mostly direct application of existing declarations. The residue step is fixed-constant natural arithmetic; the only signed arithmetic needed is the original alternating coordinate.

## 6. Semantic deduplication and ownership freshness

The initial complete task snapshot was `/workspace/scratch/d43e317f00d9/agent14-state`, 162 records at coordination `b0ee3d25fb1ddea0f741326b6401d81ae3d27626`. The earlier scout report `coverage-shortlist.md` records the source census and initial comparison.

A fresh connector comparison from Agent14's successful spectral claim `82b9e59b5efa82fa463b9084da270ef646e39aeb` to the later exact coordination commit `79b3fef00746105bb0622b793243a2d6be2c71eb` returned 17 commits. The only added or modified task paths were Agent1 periodic stripping/phase/outer/width scopes, Agent11 periodic review/manifest records, and Agent15's spectral carry-charge task. The new outer and width contracts were read; neither includes the present construction.

Agent15's actual `CLAIMED` task `agent15-spectral-carry-charge-43cf6e114472`, blob `70340af5e48d1c965d012180c04bc6ea01f90b21`, exclusively owns U/S weights and the original `J=0` iff complete binary carry-word symmetry result. It excludes the quotient and its class construction. Root's T/R fixed-width injectivity claim is also distinct. Agent15 must retain attribution and ownership of J.

The issue #61 refresh returned 513 comments through comment `6226350049`; the inspected new comments contain the explicit Agent14/Agent15 scope agreement, review/integration updates, and the shared-disk blocker. There was no newly announced carry-free class-saturation reservation. A current open-PR search returned 16 items (97, 109, 110, 115, 121, 122, 123, 127, 129, 130, 131, 133, 137, 139, 141, 143); none asserts this full construction. These are read-time observations, not a permanent ownership guarantee. Root must refresh the actual task head before any guarded claim.

Meaningful existing mathematical neighbors were compared by hypotheses and conclusions:

| Existing result | Why it does not complete this candidate |
|---|---|
| `Agent105.ResiduePalindromes.matching_even_palindrome` in original `proofs/contributions/agent-105/residue-trap/ResiduePalindromes.lean`, blob `19614d9a8fdf29bd068dea47554ca6f8aa8ef478` | Produces an already-palindromic number in every allowed even-width modulo-99 residue. It does not supply a nonpalindromic predecessor, its carry word, or all nine input digit-sum classes. Its edge-palindrome formula agrees with this candidate's output and must not be republished as novel. |
| `ExactLengthResidues.exact_length_palindrome_residues` in original `proofs/contributions/agent-111/exact-length-residues/Saturation.lean`, blob `d09021588e3fc9c3c456d4276762613c30a68be1` | Gives eventual-width existence of already-palindromic residue representatives for a general modulus. It does not give the specified every-width thresholds five/two, a carry-free nonpalindromic predecessor, or these physical input coordinates. |
| `FoldedDecimal.valid_word_realizable` | Supplies actual digit realizations for valid coefficient words. The present task must additionally control the leading/units split to obtain a nonpalindromic input and compute its exact residues. |
| `RawSymmetryObstruction.carry_zero_of_small` | The abstract no-carry consequence already exists. It should not be claimed as new; the smaller common base already provides the needed result through `DecimalCarry.small_digit_sums_give_palindrome`. |
| Existing alternating-charge modules | Prove evaluation and exterior-dynamics relations, not the 99/nine-class canonical witness construction. |

No lexical match for a carry-free saturation theorem was found in the current Lean files, and the related mathematical endpoints above do not subsume it.

## 7. Risks and acceptance conditions

- **Even coordinate confusion:** keep `Q(-1)=0` separate from the input's modulo-11 remainder. The invalid extra hypothesis/conclusion would destroy nine-class saturation.
- **Width five:** the two central monomials coincide. A proof that assumes six distinct coefficient positions is false at the minimum source width.
- **Truncated natural subtraction:** justify each index subtraction from `L ≥ 5` or `L ≥ 2`. Use integer subtraction for the signed alternating coordinate.
- **Exact width:** padded words are insufficient. `Canonical` must retain a positive leading digit, and the actual next width must use the verified no-overflow bridge.
- **Actual map:** reciprocal polynomial symmetry alone is not the endpoint. Retain computed `carry`, ordinary `step`, and numeric `Palindrome` explicitly.
- **Source scope:** a ring-isomorphism or universal carry-forgetting theorem is outside this candidate. No orbit reachability, recurrence of witnesses, or conclusion about 196 follows.
- **Dependencies:** do not mix two concatenated standalone decimal cores. Verify the exact immutable base and import closure before a build.
- **Proof accounting:** after a guarded reservation, preserve every meaningful failed source and compiler log. Acceptance requires actual Lean 4.19.0 `--trust=0 -j1 -DElab.async=false` success, fresh dependency closure, all explicit public declaration axiom checks, and genuine nonauthor semantic/execution review. No such new compilation has been attempted here.
- **Current execution resource:** two ordinary sandbox launches failed before reading files because their temporary mount-directory creation returned `No space left on device`. The same read-only commands succeeded through the authorized escalation path. This is an observed environment fault, not a mathematical defect. No files belonging to another agent were removed.

The candidate is ready for a root-owned guarded claim after the latest coordination refresh. The exact odd/even coordinate distinction and the required source-polynomial bridges should appear in that contract before implementation begins.
