import Agent14CarryfreeResidues
import Agent14CarryfreeDigits

/-! Exact ordinary-integer realizations for every retained carryfree class. -/

namespace Agent14.Carryfree

open DecimalDigits DecimalMass FoldedDecimal

def oddSeed (u b L : Nat) : Nat :=
  min u 9 * 10 ^ (L - 1) + b * 10 ^ (L - 2) + (u - min u 9) * 10 ^ (L - 3)

def oddDigits (u b L : Nat) : Nat → Nat := threeDigits (min u 9) b (u - min u 9) L

theorem split_parameter (u : Nat) (hu1 : 1 ≤ u) (hu10 : u ≤ 10) :
    1 ≤ min u 9 ∧ min u 9 ≤ 9 ∧ u - min u 9 ≤ 1 ∧ min u 9 + (u - min u 9) = u := by
  by_cases h : u ≤ 9
  · rw [Nat.min_eq_left h]
    omega
  · rw [Nat.min_eq_right (by omega : 9 ≤ u)]
    omega

/-- The source's same explicit input simultaneously meets every ordinary condition. -/
theorem odd_seed_spec (u b L : Nat) (hL : 5 ≤ L) (hodd : L % 2 = 1)
    (hu1 : 1 ≤ u) (hu10 : u ≤ 10) (hb : b ≤ 9) :
    Canonical (oddSeed u b L) (oddDigits u b L) L ∧
      ¬ Lychrel196.Palindrome (oddSeed u b L) ∧
      (∀ i, i ≤ L → carry (columnSum (oddDigits u b L) L) i = 0) ∧
      Canonical (Lychrel196.step (oddSeed u b L))
        (output (columnSum (oddDigits u b L) L)) L ∧
      Lychrel196.Palindrome (Lychrel196.step (oddSeed u b L)) ∧
      digitSum (oddSeed u b L) = u + b ∧
      oddSeed u b L % 99 = (u + 10 * b) % 99 ∧
      (∀ i, i < L → columnSum (oddDigits u b L) L i ≤ 9) := by
  rcases split_parameter u hu1 hu10 with ⟨ha0, ha, hc, hac⟩
  have hd : Canonical (oddSeed u b L) (oddDigits u b L) L :=
    threeDigits_canonical (min u 9) b (u - min u 9) L hL ha0 ha hb hc
  have hn := threeDigits_not_palindrome (min u 9) b (u - min u 9) L hL ha0 ha hb hc
  rw [threeDigits_value _ _ _ _ (by omega : 3 ≤ L)] at hn
  have hq : ∀ i, i < L → columnSum (oddDigits u b L) L i ≤ 9 :=
    threeDigits_columns_bounded (min u 9) b (u - min u 9) L hL ha hb hc
  rcases small_columns_actual_step (oddSeed u b L) (oddDigits u b L) L hd hq with
    ⟨hz, hnext, hp⟩
  have hs : digitSum (oddSeed u b L) = u + b := by
    rw [← hd.2.2.2, digitSum_value _ _ hd.2.1]
    change wordSum (threeDigits (min u 9) b (u - min u 9) L) L = u + b
    rw [threeDigits_sum _ _ _ _ (by omega : 3 ≤ L)]
    omega
  have hm : oddSeed u b L % 99 = (u + 10 * b) % 99 := by
    unfold oddSeed
    rw [odd_three_digit_mod99 L (min u 9) b (u - min u 9) hL hodd]
    congr 1
    omega
  exact ⟨hd, hn, hz, hnext, hp, hs, hm, hq⟩

/-- All 99 physical odd-width classes have nonpalindromic carryfree predecessors. -/
theorem odd_carryfree_classes (L s r : Nat) (hL : 5 ≤ L) (hodd : L % 2 = 1)
    (hs : s < 9) (hr : r < 11) :
    ∃ n : Nat, ∃ d : Nat → Nat,
      Canonical n d L ∧ ¬ Lychrel196.Palindrome n ∧
      (∀ i, i ≤ L → carry (columnSum d L) i = 0) ∧
      Canonical (Lychrel196.step n) (output (columnSum d L)) L ∧
      Lychrel196.Palindrome (Lychrel196.step n) ∧
      digitSum n % 9 = s ∧ n % 11 = r ∧
      (∀ i, i < L → columnSum d L i ≤ 9) := by
  obtain ⟨u, b, hu1, hu10, hb, hs9, hr11⟩ := residue_parameters s r hs hr
  rcases odd_seed_spec u b L hL hodd hu1 hu10 hb with
    ⟨hd, hn, hz, hnext, hp, hsum, hmod, hq⟩
  refine ⟨oddSeed u b L, oddDigits u b L, hd, hn, hz, hnext, hp, ?_, ?_, hq⟩
  · rw [hsum]
    exact hs9
  · omega

/-- A single positive leading digit supplies the source's even-width family. -/
theorem one_digit_seed_spec (a L : Nat) (hL : 2 ≤ L) (ha0 : 1 ≤ a) (ha : a ≤ 9) :
    Canonical (a * 10 ^ (L - 1)) (oneDigit a L) L ∧
      ¬ Lychrel196.Palindrome (a * 10 ^ (L - 1)) ∧
      (∀ i, i ≤ L → carry (columnSum (oneDigit a L) L) i = 0) ∧
      Canonical (Lychrel196.step (a * 10 ^ (L - 1)))
        (output (columnSum (oneDigit a L) L)) L ∧
      Lychrel196.Palindrome (Lychrel196.step (a * 10 ^ (L - 1))) ∧
      digitSum (a * 10 ^ (L - 1)) = a ∧
      (∀ i, i < L → columnSum (oneDigit a L) L i ≤ 9) := by
  have hd := oneDigit_canonical a L hL ha0 ha
  have hn := oneDigit_not_palindrome a L hL ha0 ha
  rw [oneDigit_value a L (by omega)] at hn
  have hq := oneDigit_columns_bounded a L hL ha
  rcases small_columns_actual_step (a * 10 ^ (L - 1)) (oneDigit a L) L hd hq with
    ⟨hz, hnext, hp⟩
  have hs : digitSum (a * 10 ^ (L - 1)) = a := by
    rw [← hd.2.2.2, digitSum_value _ _ hd.2.1, oneDigit_sum a L (by omega)]
  exact ⟨hd, hn, hz, hnext, hp, hs, hq⟩

/-- The nine even-width physical classes impose no divisibility-by-eleven condition. -/
theorem even_carryfree_classes (L s : Nat) (hL : 2 ≤ L) (_heven : L % 2 = 0)
    (hs : s < 9) :
    ∃ n : Nat, ∃ d : Nat → Nat,
      Canonical n d L ∧ ¬ Lychrel196.Palindrome n ∧
      (∀ i, i ≤ L → carry (columnSum d L) i = 0) ∧
      Canonical (Lychrel196.step n) (output (columnSum d L)) L ∧
      Lychrel196.Palindrome (Lychrel196.step n) ∧ digitSum n % 9 = s ∧
      (∀ i, i < L → columnSum d L i ≤ 9) := by
  obtain ⟨a, ha0, ha, has⟩ := even_residue_parameters s hs
  rcases one_digit_seed_spec a L hL ha0 ha with ⟨hd, hn, hz, hnext, hp, hsum, hq⟩
  refine ⟨a * 10 ^ (L - 1), oneDigit a L, hd, hn, hz, hnext, hp, ?_, hq⟩
  rw [hsum]
  exact has

end Agent14.Carryfree
