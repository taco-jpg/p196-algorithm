#!/usr/bin/env python3
"""Complete the preserved audit after repairing multiline log parsing only.

The original fresh --trust=0 compilation and Lean audit are not repeated or
relabeled. Their exact sources, objects, commands and logs are checked before
this continuation adds the public type and literal #print axioms checks.
"""

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import runpy
import subprocess
import time
import traceback


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def now():
    return datetime.now(timezone.utc).isoformat()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--original", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--repository", type=Path, required=True)
    args = parser.parse_args()
    original = args.original.resolve(strict=True)
    output = args.output.resolve()
    repository = args.repository.resolve(strict=True)
    output.mkdir(parents=True, exist_ok=False)
    source = output / "source"
    source.mkdir()
    runner = Path(__file__).resolve().parent / "rebuild.py"
    helpers = runpy.run_path(str(runner), run_name="independent_audit_helpers")
    report = {
        "executed_by": "Agent #14 / runtime specialist",
        "status": "RUNNING",
        "started_at": now(),
        "original_build_directory": str(original),
        "scope": "Continuation of the same independent fresh strict build; no new proof authorship",
        "reason": "The initial Python parser expected single-line axiom lists, while Lean pretty-printed the final list over three lines",
        "original_failure_preserved": True,
        "proof_source_changes": False,
        "compilation_repeated": False,
        "author_objects_reused": False,
        "rebuild_runner_sha256": digest(runner),
        "continuation_runner_sha256": digest(Path(__file__).resolve()),
        "repository_wide_pass": False,
    }
    try:
        prior = json.loads((original / "verification.json").read_text())
        if prior["status"] != "FAIL" or prior.get("error") != "ValueError('Safe audit output is absent or incomplete')":
            raise ValueError("Unexpected original failure; automatic continuation is not permitted")
        preserved_runner = runner.parent / "development/rebuild-initial.py"
        if digest(preserved_runner) != prior["runner_sha256"]:
            raise ValueError("The exact original runner is not preserved")
        manifest = json.loads((original / "FILES.json").read_text())
        for name, rec in manifest.items():
            if digest(original / name) != rec["sha256"]:
                raise ValueError("Original evidence changed: " + name)
        report["original_manifest_sha256"] = digest(original / "FILES.json")
        report["original_report_sha256"] = digest(original / "verification.json")
        registry_bytes = (original / "registry.snapshot.json").read_bytes()
        if hashlib.sha256(registry_bytes).hexdigest() != prior["registry_sha256"]:
            raise ValueError("Original registry identity changed")
        registry = json.loads(registry_bytes)
        project = registry["projects"][helpers["PROJECT"]]
        pins = dict(helpers["FIXED_PINS"], Agent14SpectralDecimal=prior["approved_decimal_sha256"])
        if set(project["modules"]) != set(pins):
            raise ValueError("Unexpected module closure")
        stage = original / "source"
        objects_before = {}
        commands = {record["label"]: record for record in prior["commands"]}
        if len(commands) != len(prior["commands"]):
            raise ValueError("Original command labels are duplicated")
        for module, expected in pins.items():
            rec = project["modules"][module]
            if expected != rec["sha256"] or digest(stage / (module + ".lean")) != expected:
                raise ValueError("Staged source changed: " + module)
            if digest(repository / rec["path"]) != expected:
                raise ValueError("Current mathematical source differs from the frozen source: " + module)
            command = commands["build-" + module]
            if command["exit_code"] != 0 or command["cwd"] != str(stage):
                raise ValueError("The original strict module compilation did not pass")
            if not {"--trust=0", "-j1", "-DElab.async=false"} <= set(command["argv"]):
                raise ValueError("The original compilation lacks required strict flags")
            object_path = stage / (module + ".olean")
            if not object_path.is_file() or object_path.is_symlink():
                raise ValueError("The independently compiled object is unavailable")
            objects_before[module] = {"path": str(object_path), "bytes": object_path.stat().st_size,
                                      "sha256": digest(object_path)}
        if prior["fresh_object_count_before_independent_build"] != 0 or prior["author_project_objects_reused"]:
            raise ValueError("The original object build was not fresh")
        audit_command = commands["safe-constant-audit"]
        if audit_command["exit_code"] != 0 or "--trust=0" not in audit_command["argv"]:
            raise ValueError("The strict Lean safe-constant audit did not pass")
        for name, sha in prior["runtime"]["files"].items():
            if digest(Path(name)) != sha:
                raise ValueError("Runtime identity changed")
        constants, summary, unsafe, partial = helpers["parse_safe_audit"](
            (original / audit_command["log"]).read_text())
        public = prior["public_declarations"]
        public_names = [item["name"] for item in public]
        constants_by_name = {record["name"]: record for record in constants}
        if not set(public_names) <= constants_by_name.keys():
            raise ValueError("A public source declaration is absent from the safe audit")
        for declaration in public:
            if constants_by_name[declaration["name"]]["module"] != declaration["module"]:
                raise ValueError("Public declaration origin mismatch")
        canonical_report = json.loads((original / "canonical/verification.json").read_text())
        canonical_project = canonical_report["projects"][helpers["PROJECT"]]
        if canonical_report["status"] != "PASS" or canonical_project["theorem_count"] != summary["theorem"]:
            raise ValueError("Canonical and strict theorem audit counts disagree")
        (output / "safe-constants.json").write_text(json.dumps(constants, indent=2) + "\n")
        (output / "implementation-inventory.json").write_text(json.dumps({"unsafe": unsafe, "partial": partial}, indent=2) + "\n")
        text = "\n".join("import " + module for module in project["roots"]) + "\n"
        text += "set_option pp.fullNames true\nset_option pp.universes true\nset_option pp.explicit true\n"
        for name in public_names:
            text += "#check @" + name + "\n#print axioms " + name + "\n"
        public_source = source / "PublicDeclarationAudit.lean"
        public_source.write_text(text)
        lean = Path(prior["runtime"]["lean"])
        command = [str(lean), "--trust=0", "-j1", "-DElab.async=false", public_source.name]
        environment = {"PATH": str(lean.parent) + os.pathsep + os.defpath,
                       "LANG": "C.UTF-8", "LEAN_PATH": str(stage)}
        log = output / "public-types-and-axioms.log"
        started_at = now()
        started = time.monotonic()
        with log.open("xb") as stream:
            result = subprocess.run(command, cwd=source, env=environment,
                                    stdout=stream, stderr=subprocess.STDOUT,
                                    timeout=1800, check=False)
        report["public_audit_command"] = {"argv": command, "cwd": str(source),
                                          "lean_path": str(stage), "exit_code": result.returncode,
                                          "started_at": started_at, "finished_at": now(),
                                          "elapsed_seconds": round(time.monotonic() - started, 6),
                                          "log": log.name, "log_sha256": digest(log)}
        if result.returncode != 0:
            raise RuntimeError("Public type and axiom audit failed")
        public_axioms = helpers["parse_public_axioms"](log.read_text(), public_names)
        for name, axioms in public_axioms.items():
            if set(axioms) != set(constants_by_name[name]["axioms"]):
                raise ValueError("Literal #print axioms and safe-constant audit disagree: " + name)
        (output / "public-axioms.json").write_text(json.dumps(public_axioms, indent=2) + "\n")
        for module, rec in objects_before.items():
            if digest(Path(rec["path"])) != rec["sha256"]:
                raise ValueError("An independently compiled object changed during the continuation")
        for module, rec in project["modules"].items():
            if digest(repository / rec["path"]) != pins[module] or digest(stage / (module + ".lean")) != pins[module]:
                raise ValueError("Mathematical source changed during continuation")
        for name, sha in prior["runtime"]["files"].items():
            if digest(Path(name)) != sha:
                raise ValueError("Runtime changed during continuation")
        if digest(repository / "proofs/Agent14Spectral.registry.json") != prior["registry_sha256"]:
            raise ValueError("Current registry differs from the frozen snapshot")
        report.update({
            "status": "INDEPENDENT_BUILD_AND_AXIOM_PASS",
            "local_checkout_head_recorded_at_build": prior["source_commit_before"],
            "checkout_clean_flag_scope": "The original tracked-only flags used --untracked-files=no; source identity is established by explicit source hashes, not by a claim that new files were locally committed",
            "frozen_source_hashes": pins,
            "registry_sha256": prior["registry_sha256"],
            "canonical_status": "PASS",
            "canonical_uses_trust_zero": False,
            "independent_flags": prior["independent_lean_flags"],
            "independent_fresh_module_count": len(pins),
            "independent_build_commands": [commands["build-" + module] for module in prior["build_order"]],
            "safe_audit_command": audit_command,
            "safe_audit": summary,
            "public_declaration_count": len(public_names),
            "public_theorem_count": sum(record["source_kind"] in {"theorem", "lemma"} for record in public),
            "public_definition_count": sum(record["source_kind"] not in {"theorem", "lemma"} for record in public),
            "claim_endpoint_count": len(prior["claim_endpoints"]),
            "objects": objects_before,
            "semantic_review": "Separate specialist assignment; this record covers build identity, safe dependency audit and exact public signatures",
        })
        return 0
    except Exception as exc:
        report["status"] = "BLOCKED_DISK" if isinstance(exc, OSError) and exc.errno == 28 else "FAIL"
        report["error"] = repr(exc)
        report["traceback"] = traceback.format_exc()
        print(report["traceback"], flush=True)
        return 1
    finally:
        report["finished_at"] = now()
        try:
            (output / "verification.json").write_text(json.dumps(report, indent=2) + "\n")
            files = {str(path.relative_to(output)): {"bytes": path.stat().st_size, "sha256": digest(path)}
                     for path in sorted(output.rglob("*"))
                     if path.is_file() and path.suffix not in {".olean", ".ilean", ".o", ".pyc"} and path.name != "FILES.json"}
            (output / "FILES.json").write_text(json.dumps(files, indent=2) + "\n")
        except OSError as exc:
            print("Could not preserve final continuation evidence:", repr(exc), flush=True)
        print(json.dumps({key: report.get(key) for key in ["status", "error", "safe_audit", "public_declaration_count", "claim_endpoint_count"]}, indent=2), flush=True)


if __name__ == "__main__":
    raise SystemExit(main())
