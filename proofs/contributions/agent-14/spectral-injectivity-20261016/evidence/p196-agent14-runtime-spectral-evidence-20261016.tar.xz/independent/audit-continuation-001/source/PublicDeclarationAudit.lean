import Agent14SpectralDecimal
set_option pp.fullNames true
set_option pp.universes true
set_option pp.explicit true
#check @Agent14.Spectral.T
#print axioms Agent14.Spectral.T
#check @Agent14.Spectral.R
#print axioms Agent14.Spectral.R
#check @Agent14.Spectral.T_zero
#print axioms Agent14.Spectral.T_zero
#check @Agent14.Spectral.T_one
#print axioms Agent14.Spectral.T_one
#check @Agent14.Spectral.R_zero
#print axioms Agent14.Spectral.R_zero
#check @Agent14.Spectral.R_one
#print axioms Agent14.Spectral.R_one
#check @Agent14.Spectral.T_monotone_step
#print axioms Agent14.Spectral.T_monotone_step
#check @Agent14.Spectral.R_monotone_step
#print axioms Agent14.Spectral.R_monotone_step
#check @Agent14.Spectral.T_recurrence_exact
#print axioms Agent14.Spectral.T_recurrence_exact
#check @Agent14.Spectral.R_recurrence_exact
#print axioms Agent14.Spectral.R_recurrence_exact
#check @Agent14.Spectral.T_positive
#print axioms Agent14.Spectral.T_positive
#check @Agent14.Spectral.R_positive
#print axioms Agent14.Spectral.R_positive
#check @Agent14.Spectral.T_growth_from_one
#print axioms Agent14.Spectral.T_growth_from_one
#check @Agent14.Spectral.R_growth
#print axioms Agent14.Spectral.R_growth
#check @Agent14.Spectral.oddWeight
#print axioms Agent14.Spectral.oddWeight
#check @Agent14.Spectral.oddWeight_zero
#print axioms Agent14.Spectral.oddWeight_zero
#check @Agent14.Spectral.oddWeight_succ
#print axioms Agent14.Spectral.oddWeight_succ
#check @Agent14.Spectral.oddWeight_positive
#print axioms Agent14.Spectral.oddWeight_positive
#check @Agent14.Spectral.oddWeight_growth
#print axioms Agent14.Spectral.oddWeight_growth
#check @Agent14.Spectral.prefixSum
#print axioms Agent14.Spectral.prefixSum
#check @Agent14.Spectral.prefixSum_zero
#print axioms Agent14.Spectral.prefixSum_zero
#check @Agent14.Spectral.prefixSum_succ
#print axioms Agent14.Spectral.prefixSum_succ
#check @Agent14.Spectral.dominates_of_nineteen_growth
#print axioms Agent14.Spectral.dominates_of_nineteen_growth
#check @Agent14.Spectral.oddWeight_dominates
#print axioms Agent14.Spectral.oddWeight_dominates
#check @Agent14.Spectral.R_dominates
#print axioms Agent14.Spectral.R_dominates
#check @Agent14.Spectral.initial_weight_values
#print axioms Agent14.Spectral.initial_weight_values
#check @Agent14.Spectral.prefixSum_congr
#print axioms Agent14.Spectral.prefixSum_congr
#check @Agent14.Spectral.prefixSum_shift
#print axioms Agent14.Spectral.prefixSum_shift
#check @Agent14.Spectral.descendingScore
#print axioms Agent14.Spectral.descendingScore
#check @Agent14.Spectral.descendingScore_zero
#print axioms Agent14.Spectral.descendingScore_zero
#check @Agent14.Spectral.descendingScore_succ
#print axioms Agent14.Spectral.descendingScore_succ
#check @Agent14.Spectral.descendingScore_le
#print axioms Agent14.Spectral.descendingScore_le
#check @Agent14.Spectral.descendingScore_injective
#print axioms Agent14.Spectral.descendingScore_injective
#check @Agent14.Spectral.evenCoordinate
#print axioms Agent14.Spectral.evenCoordinate
#check @Agent14.Spectral.oddCoordinate
#print axioms Agent14.Spectral.oddCoordinate
#check @Agent14.Spectral.evenCoordinate_eq_descending
#print axioms Agent14.Spectral.evenCoordinate_eq_descending
#check @Agent14.Spectral.oddCoordinate_eq_descending
#print axioms Agent14.Spectral.oddCoordinate_eq_descending
#check @Agent14.Spectral.even_coordinate_half_injective
#print axioms Agent14.Spectral.even_coordinate_half_injective
#check @Agent14.Spectral.odd_coordinate_half_injective
#print axioms Agent14.Spectral.odd_coordinate_half_injective
#check @Agent14.Spectral.even_coordinate_injective
#print axioms Agent14.Spectral.even_coordinate_injective
#check @Agent14.Spectral.odd_coordinate_injective
#print axioms Agent14.Spectral.odd_coordinate_injective
#check @Agent14.Spectral.coordinate
#print axioms Agent14.Spectral.coordinate
#check @Agent14.Spectral.coordinate_injective
#print axioms Agent14.Spectral.coordinate_injective
#check @Agent14.Spectral.coordinate_zero
#print axioms Agent14.Spectral.coordinate_zero
#check @Agent14.Spectral.coordinate_one
#print axioms Agent14.Spectral.coordinate_one
#check @Agent14.Spectral.coordinate_two
#print axioms Agent14.Spectral.coordinate_two
#check @Agent14.Spectral.admissible_coordinate_injective
#print axioms Agent14.Spectral.admissible_coordinate_injective
#check @Agent14.Spectral.canonical_column_sums_injective
#print axioms Agent14.Spectral.canonical_column_sums_injective
#check @Agent14.Spectral.coordinate_196_column_sums
#print axioms Agent14.Spectral.coordinate_196_column_sums
#check @Agent14.Spectral.distinct_canonical_inputs_same_coordinate
#print axioms Agent14.Spectral.distinct_canonical_inputs_same_coordinate
