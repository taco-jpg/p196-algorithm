#!/usr/bin/env python3
"""Create and stream-verify a lossless archive of Agent #14 verification evidence."""

import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import stat
import tarfile


def digest_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as source:
        for chunk in iter(lambda: source.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--independent", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    roots = {"runtime": args.runtime.resolve(strict=True),
             "independent": args.independent.resolve(strict=True)}
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=True)
    archive_path = output / "p196-agent14-runtime-spectral-evidence-20261016.tar.xz"
    manifest_path = output / "MANIFEST.json"
    descriptor_path = output / "ARCHIVE.json"
    if any(path.exists() for path in [archive_path, manifest_path, descriptor_path]):
        raise ValueError("Refusing to overwrite an existing evidence package")

    runtime_manifest_path = roots["runtime"] / "evidence-files.json"
    prior = json.loads(runtime_manifest_path.read_text())
    if prior["file_count"] != 35 or len(prior["files"]) != 35:
        raise ValueError("The requested original 35-file runtime manifest changed")
    for relative, rec in prior["files"].items():
        path = roots["runtime"] / relative
        if path.stat().st_size != rec["bytes"] or digest_file(path) != rec["sha256"]:
            raise ValueError("Original runtime evidence changed: " + relative)

    selected = {}
    excluded = []
    for prefix, root in roots.items():
        for base, dirs, files in os.walk(root, followlinks=False):
            base = Path(base)
            for name in list(dirs):
                path = base / name
                relative = str(PurePosixPath(prefix) / path.relative_to(root).as_posix())
                if path.is_symlink():
                    if prefix != "runtime" or path.relative_to(root).as_posix() != "lean-4.19.0-linux":
                        raise ValueError("Unexpected evidence-directory symlink: " + relative)
                    excluded.append({"path": relative, "kind": "external_official_toolchain_reference",
                                     "target": os.readlink(path),
                                     "reason": "The official runtime distribution is reproducible and was explicitly excluded from publication; its complete provenance remains in runtime/"})
                    dirs.remove(name)
                elif name in {"__pycache__", ".pytest_cache"}:
                    excluded.append({"path": relative, "kind": "reproducible_cache"})
                    dirs.remove(name)
            for name in files:
                path = base / name
                relative = str(PurePosixPath(prefix) / path.relative_to(root).as_posix())
                if path.is_symlink() or not stat.S_ISREG(path.stat().st_mode):
                    raise ValueError("Unexpected nonregular evidence file: " + relative)
                if path.suffix in {".olean", ".ilean", ".o", ".pyc"}:
                    excluded.append({"path": relative, "kind": "reproducible_compiled_object",
                                     "bytes": path.stat().st_size, "sha256": digest_file(path)})
                    continue
                selected[relative] = {"source": path, "bytes": path.stat().st_size,
                                      "sha256": digest_file(path), "mode": stat.S_IMODE(path.stat().st_mode)}
    missing = {"runtime/" + name for name in prior["files"]} - selected.keys()
    if missing:
        raise ValueError("The package omitted original runtime evidence: " + repr(sorted(missing)))
    files = {name: {key: rec[key] for key in ["bytes", "sha256", "mode"]}
             for name, rec in sorted(selected.items())}
    manifest = {
        "schema_version": 1,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "scope": "Complete runtime/baseline evidence and complete independent spectral verification evidence; lossless source and log bytes",
        "target_published_source_commit": "1418f5c176582435d6aa824da72513117da2832b",
        "source_binding": "Four frozen source hashes were independently checked locally; the parent verified their remote publication. The specialist's local checkout HEAD remained 5ff4f607535587d572fbc9e95ba9501d1fbe5fc5.",
        "source_roots": {name: str(root) for name, root in roots.items()},
        "original_runtime_manifest_sha256": digest_file(runtime_manifest_path),
        "original_runtime_file_count": 35,
        "all_original_runtime_files_verified": True,
        "file_count": len(files),
        "uncompressed_file_bytes": sum(rec["bytes"] for rec in files.values()),
        "files": files,
        "exclusions": excluded,
        "manifest_self_inclusion": "MANIFEST.json is additionally stored at the archive root; it is not recursively included in its own files map",
    }
    manifest_bytes = (json.dumps(manifest, indent=2) + "\n").encode()
    manifest_path.write_bytes(manifest_bytes)
    with tarfile.open(archive_path, mode="w:xz", preset=6) as archive:
        for relative, rec in sorted(selected.items()):
            info = archive.gettarinfo(str(rec["source"]), arcname=relative)
            with rec["source"].open("rb") as source:
                archive.addfile(info, source)
        info = tarfile.TarInfo("MANIFEST.json")
        info.size = len(manifest_bytes)
        info.mode = 0o644
        archive.addfile(info, io.BytesIO(manifest_bytes))

    expected = dict(files)
    expected["MANIFEST.json"] = {"bytes": len(manifest_bytes),
                                 "sha256": hashlib.sha256(manifest_bytes).hexdigest()}
    verified = {}
    with tarfile.open(archive_path, mode="r|xz") as archive:
        for member in archive:
            name = member.name
            parts = PurePosixPath(name)
            if parts.is_absolute() or ".." in parts.parts or not member.isfile():
                raise ValueError("Unexpected archive member: " + name)
            if name in verified or name not in expected:
                raise ValueError("Duplicate or unlisted archive member: " + name)
            stream = archive.extractfile(member)
            digest = hashlib.sha256()
            size = 0
            for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(chunk)
                size += len(chunk)
            if size != expected[name]["bytes"] or digest.hexdigest() != expected[name]["sha256"]:
                raise ValueError("Extracted source or log bytes differ: " + name)
            verified[name] = {"bytes": size, "sha256": digest.hexdigest()}
    if set(verified) != set(expected):
        raise ValueError("The archive is incomplete")

    descriptor = {
        "schema_version": 1,
        "status": "LOSSLESS_ARCHIVE_STREAM_VERIFIED",
        "archive": archive_path.name,
        "archive_path": str(archive_path),
        "archive_bytes": archive_path.stat().st_size,
        "archive_sha256": digest_file(archive_path),
        "manifest": manifest_path.name,
        "manifest_bytes": len(manifest_bytes),
        "manifest_sha256": hashlib.sha256(manifest_bytes).hexdigest(),
        "evidence_file_count": len(files),
        "archive_member_count": len(verified),
        "uncompressed_evidence_bytes": manifest["uncompressed_file_bytes"],
        "all_35_original_runtime_files_included": True,
        "all_new_independent_evidence_included": True,
        "verification_method": "Streaming extraction with tarfile r|xz; every member's uncompressed byte count and SHA-256 checked in memory against MANIFEST.json; no unverified member or duplicate accepted",
        "extraction_to_disk_performed": False,
        "recovery": [
            "Verify archive_sha256 and manifest_sha256 against this descriptor.",
            "Create an empty destination directory.",
            "Run: tar -xJf " + archive_path.name + " -C <destination>.",
            "Verify each path in the extracted MANIFEST.json files map by uncompressed byte count and SHA-256.",
            "Read independent/REVIEW.md. The final success record is independent/audit-continuation-001/verification.json; independent/run-001 retains the original parser failure and all successful strict Lean commands.",
            "Runtime installation and project .olean files are reproducible and excluded. Runtime source URL and digest are retained under runtime/provenance/; the complete corrected fresh build command is in independent/REVIEW.md.",
        ],
        "exclusions": excluded,
        "descriptor_self_inclusion": "ARCHIVE.json is external because it records the completed archive digest; MANIFEST.json is both external and included in the archive",
        "verified_at": datetime.now(timezone.utc).isoformat(),
    }
    descriptor_path.write_text(json.dumps(descriptor, indent=2) + "\n")
    print(json.dumps(descriptor, indent=2), flush=True)


if __name__ == "__main__":
    main()
