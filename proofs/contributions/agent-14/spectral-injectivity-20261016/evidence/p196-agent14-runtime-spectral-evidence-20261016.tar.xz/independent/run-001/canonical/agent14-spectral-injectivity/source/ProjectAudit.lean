import Agent14SpectralDecimal
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check Agent14.Spectral.T_recurrence_exact
#check Agent14.Spectral.R_recurrence_exact
#check Agent14.Spectral.oddWeight_dominates
#check Agent14.Spectral.R_dominates
#check Agent14.Spectral.oddCoordinate_eq_descending
#check Agent14.Spectral.even_coordinate_injective
#check Agent14.Spectral.odd_coordinate_injective
#check Agent14.Spectral.coordinate_injective
#check Agent14.Spectral.coordinate_zero
#check Agent14.Spectral.coordinate_one
#check Agent14.Spectral.coordinate_two
#check Agent14.Spectral.admissible_coordinate_injective
#check Agent14.Spectral.canonical_column_sums_injective
#check Agent14.Spectral.coordinate_196_column_sums
#check Agent14.Spectral.distinct_canonical_inputs_same_coordinate
run_cmd do
  let env ← getEnv
  let selected : List String := ["Agent14SpectralWeights", "Agent14SpectralInjectivity", "LychrelDigitSums", "Agent14SpectralDecimal"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        match info with
        | .axiomInfo v =>
          if v.isUnsafe then logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {mod} {name}"
          else throwError m!"CUSTOM_AXIOM {mod} {name}"
        | .thmInfo _ =>
          count := count + 1
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          for ax in axl do
            if !(union.contains ax) then union := ax :: union
          if axl.any (fun ax => !(allowed.contains ax)) then throwError m!"DISALLOWED_AXIOMS {mod} {name} : {axl}"
          logInfo m!"AUDIT_THEOREM {mod} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
