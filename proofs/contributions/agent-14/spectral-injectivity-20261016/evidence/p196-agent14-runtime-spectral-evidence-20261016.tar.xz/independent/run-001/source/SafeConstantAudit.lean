import Agent14SpectralDecimal
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
run_cmd do
  let env ← getEnv
  let selected : List String := ["Agent14SpectralWeights", "Agent14SpectralInjectivity", "LychrelDigitSums", "Agent14SpectralDecimal"]

  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut safeCount := 0
  let mut theoremCount := 0
  let mut definitionCount := 0
  let mut opaqueCount := 0
  let mut otherCount := 0
  let mut unsafeCount := 0
  let mut partialCount := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        let kind : String := match info with
          | .axiomInfo _ => "axiom"
          | .thmInfo _ => "theorem"
          | .defnInfo _ => "definition"
          | .opaqueInfo _ => "opaque"
          | .inductInfo _ => "inductive"
          | .ctorInfo _ => "constructor"
          | .recInfo _ => "recursor"
          | .quotInfo _ => "quotient"
        if info.isUnsafe then
          unsafeCount := unsafeCount + 1
          logInfo m!"INVENTORY_UNSAFE {mod} {kind} {name}"
        else if info.isPartial then
          partialCount := partialCount + 1
          logInfo m!"INVENTORY_PARTIAL {mod} {kind} {name}"
        else
          if kind == "axiom" then
            throwError m!"CUSTOM_SAFE_AXIOM {mod} {name}"
          safeCount := safeCount + 1
          if kind == "theorem" then theoremCount := theoremCount + 1
          else if kind == "definition" then definitionCount := definitionCount + 1
          else if kind == "opaque" then opaqueCount := opaqueCount + 1
          else otherCount := otherCount + 1
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          for ax in axl do
            if !(union.contains ax) then union := ax :: union
          if axl.any (fun ax => !(allowed.contains ax)) then
            throwError m!"DISALLOWED_AXIOMS {mod} {kind} {name} : {axl}"
          logInfo m!"SAFE_CONSTANT {mod} {kind} {name} : {axl}"
  logInfo m!"FULL_SAFE_AUDIT safe={safeCount} theorem={theoremCount} definition={definitionCount} opaque={opaqueCount} other={otherCount} unsafe={unsafeCount} partial={partialCount} union={union}"
