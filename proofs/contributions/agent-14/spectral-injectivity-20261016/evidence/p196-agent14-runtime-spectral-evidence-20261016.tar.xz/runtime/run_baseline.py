#!/usr/bin/env python3
"""Run the unchanged registered six-module baseline and retain actual status."""

from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys


root = Path(__file__).resolve().parent
repository = root.parent / "p196"
verifier = repository / "proofs/verify_project__214bf7673efe116b.py"
registry = repository / "proofs/Agent104ExactMass.registry.json"
lean = (root / "lean-4.19.0-linux/bin/lean").resolve(strict=True)
output = root / "baseline-exact-mass"
log = root / "baseline-exact-mass.stdout.log"
receipt_path = root / "baseline-execution.json"
if output.exists() or log.exists() or receipt_path.exists():
    raise SystemExit("Refusing to overwrite a previous baseline execution")
command = [sys.executable, "-B", str(verifier), "--registry", str(registry),
           "--project", "agent104-exact-mass", "--lean", str(lean),
           "--output", str(output)]
receipt = {
    "executed_by": "Agent #14 / runtime specialist",
    "source_authorship": "No proof source authored or modified by this runner",
    "runner": str(verifier),
    "runner_sha256": hashlib.sha256(verifier.read_bytes()).hexdigest(),
    "runner_unmodified": True,
    "runner_legacy_agent_field": "The canonical verifier emits Agent #1; that field is preserved as original runner metadata, not the executor identity",
    "registry_sha256": hashlib.sha256(registry.read_bytes()).hexdigest(),
    "source_commit_before": subprocess.check_output(
        ["git", "rev-parse", "HEAD"], cwd=repository, text=True).strip(),
    "command": command,
    "cwd": str(repository),
    "execution_mode": "Approved require_escalated",
    "lean_flags": ["-j1", "-DElab.async=false"],
    "trust_zero_flag_used_in_baseline": False,
    "started_at": datetime.now(timezone.utc).isoformat(),
}
environment = os.environ.copy()
for name in ["LEAN_PATH", "LEAN_SYSROOT", "LD_PRELOAD", "LD_LIBRARY_PATH"]:
    environment.pop(name, None)
try:
    with log.open("xb") as stream:
        process = subprocess.run(command, cwd=repository, env=environment,
                                 stdout=stream, stderr=subprocess.STDOUT, check=False)
    receipt["exit_code"] = process.returncode
except OSError as exc:
    receipt.update({"exit_code": None, "os_error": repr(exc), "errno": exc.errno})
    print(json.dumps(receipt, indent=2), flush=True)
    raise
finally:
    receipt["finished_at"] = datetime.now(timezone.utc).isoformat()
    if log.is_file():
        receipt["stdout_log_sha256"] = hashlib.sha256(log.read_bytes()).hexdigest()
    try:
        receipt_path.write_text(json.dumps(receipt, indent=2) + "\n")
    except OSError as exc:
        print("Could not save baseline execution receipt:", repr(exc), flush=True)
        print(json.dumps(receipt, indent=2), flush=True)
print(json.dumps(receipt, indent=2), flush=True)
print(log.read_text(), end="", flush=True)
raise SystemExit(receipt["exit_code"])
