#!/usr/bin/env python3
"""Record actual Lean runtime identity and a standard-library import check."""

import hashlib
import json
import os
from pathlib import Path
import subprocess
from datetime import datetime, timezone


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


root = Path(__file__).resolve().parent
runtime = (root / "lean-4.19.0-linux").resolve(strict=True)
lean = runtime / "bin/lean"
lake = runtime / "bin/lake"
smoke = root / "smoke"
logs = root / "logs"
smoke.mkdir(exist_ok=True)
logs.mkdir(exist_ok=True)
source = smoke / "RuntimeSmoke.lean"
source.write_text("import Std\nimport Lean\n#check Nat.add_assoc\n#print axioms Nat.add_assoc\n")
environment = os.environ.copy()
cleared_variables = ["LEAN_PATH", "LEAN_SYSROOT", "LD_PRELOAD", "LD_LIBRARY_PATH"]
for name in cleared_variables:
    environment.pop(name, None)
commands = [
    ("lean-version", [str(lean), "--version"]),
    ("lean-prefix", [str(lean), "--print-prefix"]),
    ("lake-version", [str(lake), "--version"]),
    ("standard-library-check", [str(lean), "--trust=0", "-j1", "-DElab.async=false",
                                "-o", str(smoke / "RuntimeSmoke.olean"), str(source)]),
]
records = []
for name, command in commands:
    log = logs / f"{name}.log"
    started_at = datetime.now(timezone.utc).isoformat()
    result = subprocess.run(command, cwd=smoke, env=environment,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            timeout=60, check=False)
    log.write_bytes(result.stdout)
    records.append({
        "name": name, "command": command, "cwd": str(smoke),
        "started_at": started_at,
        "finished_at": datetime.now(timezone.utc).isoformat(),
        "exit_code": result.returncode, "log": str(log.relative_to(root)),
        "log_sha256": sha256(log), "output": result.stdout.decode(errors="replace"),
    })
report = {
    "scope": "Runtime verification only; no P196 theorem build",
    "execution": "Approved require_escalated execution; default sandbox failed to locate the application",
    "binary_patch_or_host_readlink_adapter": False,
    "cleared_process_environment_variables": cleared_variables,
    "local_runtime_reference": str(root / "lean-4.19.0-linux"),
    "resolved_runtime_root": str(runtime),
    "runtime_reference_type": "Directory symlink to an existing complete official distribution; no files modified",
    "lean_binary_sha256": sha256(lean),
    "lake_binary_sha256": sha256(lake),
    "smoke_source_sha256": sha256(source),
    "smoke_object_created": (smoke / "RuntimeSmoke.olean").is_file(),
    "commands": records,
    "all_commands_passed": all(record["exit_code"] == 0 for record in records),
}
(root / "runtime-verification.json").write_text(json.dumps(report, indent=2) + "\n")
print(json.dumps(report, indent=2))
raise SystemExit(0 if report["all_commands_passed"] and report["smoke_object_created"] else 1)
