#!/usr/bin/env python3
"""Compare an installed Lean runtime to an official release without extracting it."""

import argparse
import hashlib
import json
import os
from pathlib import Path, PurePosixPath
import subprocess
import tarfile
import threading
from datetime import datetime, timezone


def sha256_file(path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--runtime", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)
    runtime = args.runtime.resolve(strict=True)
    official_url = "https://github.com/leanprover/lean4/releases/download/v4.19.0/lean-4.19.0-linux.tar.zst"
    expected_archive_sha256 = "6fe3ce97a58f44e2b3567d455b994eacec5bfe9ae7774f2a573444480ba813fe"
    expected_archive_bytes = 343842845
    started = datetime.now(timezone.utc).isoformat()
    compressed_digest = hashlib.sha256()
    transfer = {"bytes": 0, "errors": []}
    records = []
    archive_paths = set()
    failures = []
    curl_errors = (args.output / "curl.stderr.log").open("wb")
    zstd_errors = (args.output / "zstd.stderr.log").open("wb")
    curl = subprocess.Popen(
        ["curl", "--fail", "--location", "--silent", "--show-error",
         "--connect-timeout", "15", "--max-time", "180", official_url],
        stdout=subprocess.PIPE, stderr=curl_errors,
    )
    zstd = subprocess.Popen(
        ["zstd", "--decompress", "--stdout"], stdin=subprocess.PIPE,
        stdout=subprocess.PIPE, stderr=zstd_errors,
    )

    def transfer_compressed():
        try:
            for chunk in iter(lambda: curl.stdout.read(1024 * 1024), b""):
                compressed_digest.update(chunk)
                transfer["bytes"] += len(chunk)
                zstd.stdin.write(chunk)
        except Exception as exc:
            transfer["errors"].append(repr(exc))
        finally:
            zstd.stdin.close()
            curl.stdout.close()

    copier = threading.Thread(target=transfer_compressed)
    copier.start()
    try:
        with tarfile.open(fileobj=zstd.stdout, mode="r|") as archive:
            for member in archive:
                archive_path = PurePosixPath(member.name)
                if (archive_path.is_absolute() or ".." in archive_path.parts
                        or not archive_path.parts
                        or archive_path.parts[0] != "lean-4.19.0-linux"):
                    raise ValueError(f"Unexpected archive path: {member.name}")
                relative = PurePosixPath(*archive_path.parts[1:])
                local = runtime / str(relative)
                if member.isdir():
                    if not local.is_dir():
                        failures.append({"path": str(relative), "error": "missing_directory"})
                    continue
                archive_paths.add(str(relative))
                record = {"path": str(relative), "archive_bytes": member.size}
                if member.isfile():
                    stream = archive.extractfile(member)
                    digest = hashlib.sha256()
                    size = 0
                    for chunk in iter(lambda: stream.read(1024 * 1024), b""):
                        digest.update(chunk)
                        size += len(chunk)
                    record.update({"type": "file", "archive_sha256": digest.hexdigest()})
                    if local.is_symlink() or not local.is_file():
                        record["matches"] = False
                        record["error"] = "missing_file_or_type_mismatch"
                    else:
                        record["local_sha256"] = sha256_file(local)
                        record["local_bytes"] = local.stat().st_size
                        record["matches"] = (
                            record["archive_sha256"] == record["local_sha256"]
                            and record["archive_bytes"] == record["local_bytes"] == size
                        )
                elif member.issym():
                    record.update({"type": "symlink", "archive_target": member.linkname})
                    record["local_target"] = os.readlink(local) if local.is_symlink() else None
                    record["matches"] = record["local_target"] == record["archive_target"]
                else:
                    record.update({"type": str(member.type), "matches": False,
                                   "error": "unsupported_archive_member_type"})
                records.append(record)
                if not record["matches"]:
                    failures.append(record)
        # Drain compressed padding after tar end markers so both subprocesses finish.
        for _ in iter(lambda: zstd.stdout.read(1024 * 1024), b""):
            pass
    except Exception as exc:
        failures.append({"error": repr(exc)})
        zstd.kill()
        curl.kill()
    finally:
        zstd.stdout.close()
        copier.join(timeout=30)
        if copier.is_alive():
            curl.kill()
            zstd.kill()
            copier.join(timeout=10)
            failures.append({"error": "transfer_thread_timeout"})
        curl_status = curl.wait(timeout=10)
        zstd_status = zstd.wait(timeout=10)
        curl_errors.close()
        zstd_errors.close()

    local_paths = set()
    for base, dirs, files in os.walk(runtime, followlinks=False):
        for name in files:
            local_paths.add(str((Path(base) / name).relative_to(runtime)))
        for name in dirs:
            path = Path(base) / name
            if path.is_symlink():
                local_paths.add(str(path.relative_to(runtime)))
    extras = sorted(local_paths - archive_paths)
    archive_hash_matches = compressed_digest.hexdigest() == expected_archive_sha256
    archive_size_matches = transfer["bytes"] == expected_archive_bytes
    report = {
        "scope": "Runtime byte comparison only; no P196 theorem verification",
        "started_at": started,
        "finished_at": datetime.now(timezone.utc).isoformat(),
        "runtime_root": str(runtime),
        "official_archive_url": official_url,
        "official_archive_bytes": transfer["bytes"],
        "official_archive_sha256": compressed_digest.hexdigest(),
        "expected_archive_sha256": expected_archive_sha256,
        "expected_hash_source": "Previously recorded runtime receipt; independently recomputed from the official URL in this run",
        "archive_hash_matches": archive_hash_matches,
        "archive_size_matches_official_metadata": archive_size_matches,
        "curl_exit_code": curl_status,
        "zstd_exit_code": zstd_status,
        "transfer_errors": transfer["errors"],
        "checked_nondirectory_members": len(records),
        "mismatches": failures,
        "extra_local_files": extras,
        "all_passed": (not failures and not extras and not transfer["errors"]
                       and curl_status == zstd_status == 0
                       and archive_hash_matches and archive_size_matches),
    }
    (args.output / "official-runtime-members.json").write_text(json.dumps(records, indent=2) + "\n")
    (args.output / "official-runtime-comparison.json").write_text(json.dumps(report, indent=2) + "\n")
    print(json.dumps(report, indent=2))
    return 0 if report["all_passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
