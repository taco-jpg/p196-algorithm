import Std
import Lean
#check Nat.add_assoc
#print axioms Nat.add_assoc
