# Agent #14 runtime verification

## Scope and ownership

This directory contains runtime setup and execution evidence prepared by the
genuine Agent #14 runtime specialist. It contains no new P196 mathematical proof
authored by this specialist. The root agent owns repository changes, task
coordination and publication. This specialist's issue #61 communications are
relayed with attribution by the root agent.

The source baseline is repository commit
`5ff4f607535587d572fbc9e95ba9501d1fbe5fc5`, inspected in the root-owned `p196`
checkout. `proofs/CONSOLIDATION.md`, `proofs/ACCEPTED_BUILD.json` and
`proofs/Agent104ExactMass.registry.json` specify Lean 4.19.0, release commit prefix
`6caaee842e94`. Their accepted foundational axioms are `propext`,
`Classical.choice` and `Quot.sound`.

## Verified runtime

The official release is
<https://github.com/leanprover/lean4/releases/tag/v4.19.0>.
The official Linux archive is
<https://github.com/leanprover/lean4/releases/download/v4.19.0/lean-4.19.0-linux.tar.zst>.

| Item | Verified value |
|---|---|
| Archive size | 343842845 bytes |
| Archive SHA-256 | `6fe3ce97a58f44e2b3567d455b994eacec5bfe9ae7774f2a573444480ba813fe` |
| Lean version | `Lean (version 4.19.0, x86_64-unknown-linux-gnu, commit 6caaee842e94, Release)` |
| Lake version | `Lake version 5.0.0-6caaee8 (Lean version 4.19.0)` |
| Lean executable SHA-256 | `92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023` |
| Lake executable SHA-256 | `5111aee5c9434ab05d4265606475ef22e8bda69aaf3a0657b61a7eec6e550bed` |

The release metadata was retrieved from the official GitHub API and is retained
in `provenance/official-release-v4.19.0.json`. That metadata does not publish an
asset digest. The digest above was independently calculated from a successful
stream of the official download during this execution; the bytes were not taken
on trust from an earlier agent receipt.

The stream comparison examined all 4,617 nondirectory archive members, including
symlinks, against the existing complete distribution at:

```text
/workspace/scratch/f8aedc6d7adf/runtime-agent6/lean-4.19.0-linux
```

Every member matched. There were no extra local files. The local reference
`agent14-runtime/lean-4.19.0-linux` is a directory symlink to that distribution;
the existing distribution was not modified or copied. `lean --print-prefix`
returned the resolved distribution path above. This reuse avoids consuming
another 1.6 GB in a workspace whose available disk space reached zero during
setup. The runtime therefore depends on that pre-existing local directory
remaining available; the official URL and digest permit reconstruction.

Full member hashes are retained in `provenance/official-runtime-members.json`.
`provenance/official-runtime-comparison.json` records the fresh transfer hash,
size, successful curl/zstd exit statuses, comparison counts and absence of
mismatches. `verify_official_runtime.py` reproduces this comparison without
extracting an archive or modifying the runtime.

## Actual execution

Direct invocation under the ordinary sandbox returned:

```text
error: failed to locate application
```

Execution using the supported, approved `require_escalated` route succeeded.
No executable patch, binary interposer or host readlink adapter was introduced.
`verify_runtime.py` also removes `LD_PRELOAD`, `LD_LIBRARY_PATH`, `LEAN_PATH` and
`LEAN_SYSROOT` from its child-process environment to prevent inherited runtime
overrides. It does not modify any system environment or path.

`runtime-verification.json` preserves the four executed commands, timestamps,
exit codes and full output hashes. They verify Lean version, Lean prefix, Lake
version, and import of `Std` and `Lean`. The import smoke file checks the existing
`Nat.add_assoc` theorem and prints its axiom report. The smoke invocation used:

```sh
lean --trust=0 -j1 -DElab.async=false -o RuntimeSmoke.olean RuntimeSmoke.lean
```

All four commands exited zero. The smoke axiom output is
`'Nat.add_assoc' does not depend on any axioms`. This smoke result alone is not a
P196 theorem verification.

## Registered baseline execution

The root agent assigned the existing six-module project
`agent104-exact-mass`. `run_baseline.py` invokes the canonical verifier unchanged:

```sh
python3 -B proofs/verify_project__214bf7673efe116b.py \
  --registry proofs/Agent104ExactMass.registry.json \
  --project agent104-exact-mass \
  --lean /workspace/scratch/d43e317f00d9/agent14-runtime/lean-4.19.0-linux/bin/lean \
  --output /workspace/scratch/d43e317f00d9/agent14-runtime/baseline-exact-mass
```

The canonical verifier's SHA-256 is
`c047ff1ff1fe12b2c2094ca5f36af871b1c6faf89db593a102f9c2f7d48cc98a`.
The registry's SHA-256 is
`92b684db0a5883522d886e31747301c012f463e14bd93fd9eb2660d593219624`.
The canonical verifier uses `-j1 -DElab.async=false` and does **not** pass
`--trust=0`. The stronger smoke flag must not be attributed to this baseline.
The canonical report's literal `Agent #1` field belongs to the unchanged
historical verifier; the execution wrapper identifies the current executor as
Agent #14 / runtime specialist.

Fresh project source copies and generated objects are confined to the new
baseline output. The verifier checks registered source hashes, import closure,
named endpoints and all compiled project theorem axioms, then checks source and
compiler identities again. The run completed with exit code zero and scoped
`PASS`. All six module compilations and `ProjectAudit` exited zero. The audit
checked 11 named claim endpoints and 1,254 compiled theorem declarations,
including generated auxiliaries. The axiom union was
`[Classical.choice, Quot.sound, propext]`. The canonical runner separately
inventoried 14 unsafe compiler implementation axioms; none appears in any
audited theorem's axiom dependencies. Their exact names remain in the raw report
and `SUMMARY.json`. The source checkout was clean when the canonical runner
recorded it.

`baseline-execution.json` and `baseline-exact-mass/verification.json` retain the
actual commands and results. `SUMMARY.json` provides the exact execution counts
and trust flags. This is a successful fresh baseline replay of the registered
exact-mass project, not a claim of a complete repository census or a new
formalization. The registry and canonical report explicitly retain
`repository_wide_pass: false`.

## Reproduction on a normal Linux host

For an existing matching runtime, rerun `verify_official_runtime.py` against its
root, set the local directory reference, and execute `verify_runtime.py`.
For a fresh installation, download the exact official archive above, verify its
SHA-256 before extraction, and extract into an owned directory with at least
2 GB free. Use its absolute `bin/lean` path in the canonical baseline command and
a new, nonexistent output directory. Normal Linux hosts need no sandbox-specific
adapter. In this hosted environment, request supported execution escalation if
the ordinary sandbox repeats the recorded application-location failure.

The scripts in this directory neither publish to GitHub nor modify proof
sources. Runtime binaries and `.olean` files are reproducible local products and
should not be committed as source evidence.
