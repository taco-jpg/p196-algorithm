import Agent101NonpalindromicFibers

namespace Agent101.IndependentNonpalReview

open Lychrel196

/-- The subtraction in the count theorem never relies on saturation. -/
theorem indicator_le_profileCount (h : List Nat) (c : Option Nat) :
    palindromeIndicator h c ≤ profileCount h c := by
  have hp := numericFiber_length_partition h c
  rw [length_palindromeNumericFiber] at hp
  omega

theorem indicator_le_one (h : List Nat) (c : Option Nat) :
    palindromeIndicator h c ≤ 1 := by
  unfold palindromeIndicator
  split <;> omega

theorem palindrome_members_positive (h : List Nat) (c : Option Nat) (n : Nat)
    (hn : n ∈ palindromeNumericFiber h c) : 0 < n := by
  have hm := ((mem_palindromeNumericFiber h c n).mp hn).1
  obtain ⟨ds, hd, _, hv⟩ := (mem_numericFiber_digits h c n).mp hm
  rw [← hv]
  exact natValue_positive ds hd

theorem empty_profile :
    numericFiber [] none = [] ∧ palindromeIndicator [] none = 0 ∧
    nonpalindromicNumericFiber [] none = [] := by decide

theorem zero_singleton_profile :
    numericFiber [] (some 0) = [] ∧ palindromeIndicator [] (some 0) = 0 := by decide

theorem positive_single_digit :
    numericFiber [] (some 2) = [1] ∧
    palindromeNumericFiber [] (some 2) = [1] ∧
    nonpalindromicNumericFiber [] (some 2) = [] ∧
    palindromeIndicator [] (some 2) = 1 := by decide

theorem largest_single_digit :
    numericFiber [] (some 18) = [9] ∧
    palindromeNumericFiber [] (some 18) = [9] := by decide

theorem odd_single_center :
    numericFiber [] (some 1) = [] ∧ palindromeIndicator [] (some 1) = 0 := by decide

theorem oversized_even_center :
    numericFiber [] (some 20) = [] ∧ palindromeIndicator [] (some 20) = 0 := by decide

theorem positive_outer_odd_center :
    numericFiber [2] (some 3) = [] ∧ palindromeIndicator [2] (some 3) = 0 := by decide

theorem zero_outer_even_width :
    numericFiber [0] none = [] ∧ palindromeIndicator [0] none = 0 := by decide

theorem zero_outer_positive_center :
    numericFiber [0] (some 2) = [] ∧ palindromeIndicator [0] (some 2) = 0 := by decide

theorem oversized_even_outer :
    numericFiber [20] none = [] ∧ palindromeIndicator [20] none = 0 := by decide

/-- Zero low digits are permitted; ordinary reversal discards those zeros. -/
theorem trailing_zero_and_unique_palindrome :
    numericFiber [2] none = [20, 11] ∧
    palindromeNumericFiber [2] none = [11] ∧
    nonpalindromicNumericFiber [2] none = [20] ∧
    palindromeIndicator [2] none = 1 := by decide

theorem inner_zero_and_unique_palindrome :
    numericFiber [2, 0] none = [2000, 1001] ∧
    palindromeNumericFiber [2, 0] none = [1001] ∧
    nonpalindromicNumericFiber [2, 0] none = [2000] := by decide

theorem zero_center_is_valid_with_positive_outer :
    numericFiber [2] (some 0) = [200, 101] ∧
    palindromeNumericFiber [2] (some 0) = [101] ∧
    nonpalindromicNumericFiber [2] (some 0) = [200] := by decide

theorem odd_outer_has_no_initial_palindrome :
    numericFiber [3] none = [30, 21, 12] ∧
    palindromeNumericFiber [3] none = [] ∧
    nonpalindromicNumericFiber [3] none = [30, 21, 12] ∧
    palindromeIndicator [3] none = 0 := by decide

theorem eighteen_pair_is_single_palindrome :
    numericFiber [18] none = [99] ∧
    palindromeNumericFiber [18] none = [99] ∧
    nonpalindromicNumericFiber [18] none = [] := by decide

/-- Initial nonpalindromicity alone gives no next-step safety theorem. -/
theorem initial_only_scope :
    20 ∈ nonpalindromicNumericFiber [2] none ∧ Palindrome (step 20) := by decide

end Agent101.IndependentNonpalReview
