import Agent101NonpalindromicFibers
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check Agent101.palindrome_natValue_iff_reverse
#check Agent101.digitPairSums_of_reverse_eq
#check Agent101.even_digitPairSums_of_reverse_eq
#check Agent101.half_digitPairSums_of_reverse_eq
#check Agent101.digitFn_half_map
#check Agent101.digitPairSums_bounded
#check Agent101.canonical_half_pairSums
#check Agent101.digitPairSums_half_of_reverse_even
#check Agent101.canonical_half_coefficientWord
#check Agent101.half_coefficientWord_mem_numericFiber
#check Agent101.palindrome_mem_numericFiber_iff
#check Agent101.palindrome_numericFiber_exists_iff
#check Agent101.palindrome_numericFiber_eq_half
#check Agent101.palindrome_numericFiber_unique
#check Agent101.mem_palindromeNumericFiber
#check Agent101.mem_nonpalindromicNumericFiber
#check Agent101.palindromeNumericFiber_nodup
#check Agent101.nonpalindromicNumericFiber_nodup
#check Agent101.length_filter_partition
#check Agent101.numericFiber_length_partition
#check Agent101.mem_nonpalindromicNumericFiber_numeric
#check Agent101.palindromePossible_iff
#check Agent101.list_eq_singleton_of_nodup_mem_iff
#check Agent101.list_eq_nil_of_forall_not_mem
#check Agent101.palindromeNumericFiber_eq
#check Agent101.length_palindromeNumericFiber
#check Agent101.length_nonpalindromicNumericFiber
#check Agent101.nonpalindromicNumericFiber_exact
run_cmd do
  let env ← getEnv
  let selected : List String := ["Lychrel196Research", "Agent101DigitPairs", "Agent101MultiplicityBounds", "Agent101SplitEnumeration", "Agent101NumericFibers", "Agent101PalindromeFibers", "Agent101NonpalindromicFibers"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        match info with
        | .axiomInfo v =>
          if v.isUnsafe then logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {mod} {name}"
          else throwError m!"CUSTOM_AXIOM {mod} {name}"
        | .thmInfo _ =>
          count := count + 1
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          for ax in axl do
            if !(union.contains ax) then union := ax :: union
          if axl.any (fun ax => !(allowed.contains ax)) then throwError m!"DISALLOWED_AXIOMS {mod} {name} : {axl}"
          logInfo m!"AUDIT_THEOREM {mod} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
