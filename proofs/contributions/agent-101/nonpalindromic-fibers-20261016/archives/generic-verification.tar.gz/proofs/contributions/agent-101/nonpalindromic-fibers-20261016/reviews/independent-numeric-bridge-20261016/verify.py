#!/usr/bin/env python3
"""Independent fresh-source audit of two modules not authored by this reviewer."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import tempfile
import time

HERE = Path(__file__).resolve().parent
REPO = HERE.parents[5]
LEAN = Path('/workspace/scratch/2a8a87fd78df/agent101-runtime/toolchain/lean-4.19.0-linux/bin/lean')
EXPECTED = {
    'Agent101PalindromeFibers': '27ebcd2a7b790d87e45f19e51d0d7e2ff977f297742936503b9552026e3ea633',
    'Agent101NonpalindromicFibers': '22e33259394d275175a02a90a887e3fa49af488a3931e3518fc99899a59154e5',
}
SOURCES = [
    ('Lychrel196Research', 'proofs/Lychrel196Research__c696e0ea3db39d92.lean'),
    ('Agent101DigitPairs', 'proofs/Agent101DigitPairs.lean'),
    ('Agent101MultiplicityBounds', 'proofs/Agent101MultiplicityBounds.lean'),
    ('Agent101SplitEnumeration', 'proofs/Agent101SplitEnumeration.lean'),
    ('Agent101NumericFibers', 'proofs/Agent101NumericFibers.lean'),
    ('Agent101PalindromeFibers', 'proofs/Agent101PalindromeFibers.lean'),
    ('Agent101NonpalindromicFibers', 'proofs/Agent101NonpalindromicFibers.lean'),
]
ALLOWED = {'propext', 'Classical.choice', 'Quot.sound'}

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def declarations(text):
    return re.findall(r'^(?:theorem|def|abbrev)\s+([A-Za-z0-9_]+)', text, re.M)

def main():
    build = Path(tempfile.mkdtemp(prefix='nonpal-independent-',
        dir='/workspace/scratch/2a8a87fd78df/agent101-runtime'))
    logs = HERE / 'logs'
    logs.mkdir(exist_ok=True)
    report = {
        'reviewer': 'Agent #101 numeric-bridge subagent',
        'independence': 'Reviewer did not author either reviewed new module; reviewer authored the already checked Agent101NumericFibers dependency and discloses that limitation.',
        'source_policy': 'Read-only review of original sources; byte-identical fresh copies; no inherited oleans; LEAN_PATH contains only this fresh directory.',
        'fresh_build_directory': str(build),
        'compiler': str(LEAN), 'compiler_sha256': sha(LEAN),
        'sources': [], 'commands': [], 'result': 'RUNNING',
    }
    assert report['compiler_sha256'] == '92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023'
    names = []
    for module, rel in SOURCES:
        source = REPO / rel
        actual = sha(source)
        if module in EXPECTED:
            assert actual == EXPECTED[module], (module, actual)
            names.extend('Agent101.' + n for n in declarations(source.read_text()))
        if module == 'Lychrel196Research':
            assert actual == 'f8950d138fa4231b536059e2334d36b6496de3d25a806f4cf3925941aa05144c'
        if module == 'Agent101NumericFibers':
            assert actual == 'bba80a597345f7f3bd207698a6e6b338ee20335e647f518604fa43654b13fd97'
        target = build / (module + '.lean')
        shutil.copyfile(source, target)
        assert sha(target) == actual
        report['sources'].append({'module': module, 'source': str(source), 'sha256': actual, 'build_copy': str(target)})
    assert len(names) == 32, len(names)
    review = HERE / 'BoundaryReview.lean'
    review_names = ['Agent101.IndependentNonpalReview.' + n for n in declarations(review.read_text())]
    shutil.copyfile(review, build / review.name)
    audit = 'import BoundaryReview\n\n' + '\n'.join('#print axioms ' + n for n in names + review_names) + '\n'
    (HERE / 'ExportAudit.lean').write_text(audit)
    (build / 'ExportAudit.lean').write_text(audit)
    env = os.environ.copy()
    env['LEAN_PATH'] = str(build)
    def save():
        (HERE / 'verification.json').write_text(json.dumps(report, indent=2) + '\n')
    save()
    for module in [x[0] for x in SOURCES] + ['BoundaryReview', 'ExportAudit']:
        argv = [str(LEAN), '--trust=0', '-j1', '-DElab.async=false', '-o', module + '.olean', module + '.lean']
        start = time.monotonic()
        print('START', module, flush=True)
        result = subprocess.run(argv, cwd=build, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        duration = time.monotonic() - start
        log = logs / (module + '.log')
        log.write_text(result.stdout)
        record = {'module': module, 'argv': argv, 'cwd': str(build), 'LEAN_PATH': str(build), 'exit_code': result.returncode, 'seconds': duration, 'log': str(log)}
        report['commands'].append(record)
        save()
        print('DONE', module, 'exit', result.returncode, 'seconds', round(duration, 3), flush=True)
        if result.returncode:
            report['result'] = 'FAIL'
            save()
            print(result.stdout, flush=True)
            raise SystemExit(result.returncode)
        assert 'sorryAx' not in result.stdout and 'Lean.ofReduceBool' not in result.stdout
    audit_log = (logs / 'ExportAudit.log').read_text()
    audited = re.findall(r"'([^']+)' (?:depends on axioms|does not depend on any axioms)", audit_log)
    assert sorted(audited) == sorted(names + review_names), (audited, names + review_names)
    axioms = {a.strip() for group in re.findall(r'axioms: \[([^\]]*)\]', audit_log) for a in group.split(',')}
    assert axioms <= ALLOWED, axioms
    for rec in report['sources']:
        assert sha(Path(rec['source'])) == rec['sha256'], 'Source changed during review: ' + rec['source']
    report.update({'result': 'PASS', 'reviewed_module_exports': names, 'boundary_review_theorems': review_names, 'axiom_union': sorted(axioms), 'sources_unchanged_after_review': True})
    save()
    print('PASS:', len(names), 'original exports and', len(review_names), 'independent review theorems; axioms', sorted(axioms), flush=True)

if __name__ == '__main__':
    main()
