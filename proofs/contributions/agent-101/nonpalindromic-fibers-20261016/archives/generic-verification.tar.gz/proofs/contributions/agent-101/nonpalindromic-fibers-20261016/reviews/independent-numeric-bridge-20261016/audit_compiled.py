#!/usr/bin/env python3
"""Audit the actual compiled declarations after verify.py's fresh rebuild."""
from pathlib import Path
import hashlib
import json
import os
import re
import shutil
import subprocess
import time

HERE = Path(__file__).resolve().parent

def main():
    report = json.loads((HERE / 'verification.json').read_text())
    assert report['result'] == 'PASS'
    build = Path(report['fresh_build_directory'])
    lean = report['compiler']
    source = HERE / 'CompiledAudit.lean'
    shutil.copyfile(source, build / source.name)
    env = os.environ.copy()
    env['LEAN_PATH'] = str(build)
    argv = [lean, '--trust=0', '-j1', '-DElab.async=false', '-o', 'CompiledAudit.olean', source.name]
    start = time.monotonic()
    result = subprocess.run(argv, cwd=build, env=env, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    log = HERE / 'logs/CompiledAudit.log'
    log.write_text(result.stdout)
    audited = re.findall(r'COMPILED_(THEOREM|DEFINITION|OPAQUE) (\S+) (\S+)', result.stdout)
    unsafe = re.findall(r'UNSAFE_COMPILER_IMPLEMENTATION (\S+) (\S+)', result.stdout)
    axioms = {a.strip() for group in re.findall(r'axioms: \[([^\]]*)\]', result.stdout) for a in group.split(',')}
    data = {'command': argv, 'cwd': str(build), 'LEAN_PATH': str(build), 'exit_code': result.returncode,
            'seconds': time.monotonic() - start, 'source_sha256': hashlib.sha256(source.read_bytes()).hexdigest(),
            'log': str(log), 'audited_declarations': [{'kind': k, 'module': m, 'name': n} for k, m, n in audited],
            'unsafe_compiler_implementation_declarations': [{'module': m, 'name': n} for m, n in unsafe],
            'axiom_union': sorted(axioms), 'result': 'PASS' if result.returncode == 0 else 'FAIL'}
    assert result.returncode == 0, result.stdout
    assert len(audited) >= 32
    assert set(report['reviewed_module_exports']) <= {n for _, _, n in audited}
    assert all(re.search(r'\._cstage[12]$', n) or re.fullmatch(r'List\.filterTR\.loop\._at\.Agent101\.(?:palindromeNumericFiber|nonpalindromicNumericFiber)\._spec_1', n) for _, n in unsafe), unsafe
    assert axioms <= {'propext', 'Classical.choice', 'Quot.sound'}, axioms
    assert 'CUSTOM_AXIOM' not in result.stdout and 'sorryAx' not in result.stdout and 'Lean.ofReduceBool' not in result.stdout
    for rec in report['sources']:
        assert hashlib.sha256(Path(rec['source']).read_bytes()).hexdigest() == rec['sha256']
    data['sources_unchanged_after_audit'] = True
    (HERE / 'compiled-audit-verification.json').write_text(json.dumps(data, indent=2) + '\n')
    print('PASS:', len(audited), 'compiled logical declarations;', len(unsafe), 'separately recorded unsafe compiler implementations; axioms', sorted(axioms))

if __name__ == '__main__':
    main()
