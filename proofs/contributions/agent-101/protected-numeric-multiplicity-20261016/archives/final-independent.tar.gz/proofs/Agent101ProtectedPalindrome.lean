import Agent101ProtectedMultiplicity
import Agent101PalindromeFibers

/-!
Agent #101. Exactly one initial palindrome in the complete protected seed
family. This module specializes the generic palindrome-fiber theorem; it
does not change the protected coefficient words or their transition.
The statements hold for k = 0 as well as positive k.
-/

namespace Agent101.Protected

open P196.Agent3.OverflowHorizon

/-- Least-significant-first half of the unique palindromic seed. -/
def palindromeHalf (m k : Nat) : List Nat :=
  [7] ++ List.replicate m 7 ++ List.replicate k 9

/-- The complete canonical digits of the unique palindromic seed. -/
def palindromeDigits (m k : Nat) : List Nat :=
  palindromeHalf m k ++ (palindromeHalf m k).reverse

/-- The unique initial palindrome among all protected-family digit splits. -/
def palindromeSeed (m k : Nat) : Nat := natValue (palindromeDigits m k)

theorem all_true_eq_replicate (xs : List Bool)
    (h : ∀ b ∈ xs, b = true) : xs = List.replicate xs.length true := by
  induction xs with
  | nil => rfl
  | cons b xs ih =>
    have hb := h b (by simp)
    have ht : ∀ c ∈ xs, c = true := fun c hc => h c (by simp [hc])
    simp only [List.length_cons, List.replicate_succ]
    rw [hb]
    exact congrArg (List.cons true) (ih ht)

theorem inputWord_all_true_even (m k : Nat) :
    ∀ s ∈ inputWord (List.replicate m true) k, s % 2 = 0 := by
  intro s hs
  simp only [inputWord, inputHalf, List.mem_append, List.mem_reverse,
    List.mem_singleton, List.map_replicate, List.mem_replicate, choice] at hs
  simp only [↓reduceIte] at hs
  omega

/-- An odd coefficient 5 prevents an initial palindrome. Every coefficient
is even exactly when every Boolean choice selected 14. -/
theorem inputWord_even_iff (xs : List Bool) (k : Nat) :
    (∀ s ∈ inputWord xs k, s % 2 = 0) ↔
      xs = List.replicate xs.length true := by
  constructor
  · intro he
    apply all_true_eq_replicate
    intro b hb
    have hm : choice b ∈ inputHalf xs k := by
      simp only [inputHalf, List.mem_append]
      exact Or.inl (Or.inr (List.mem_map.mpr ⟨b, hb, rfl⟩))
    have hs := he (choice b) (List.mem_append_left _ hm)
    cases b with
    | false => simp [choice] at hs
    | true => rfl
  · intro hx
    simpa only [← hx] using inputWord_all_true_even xs.length k

theorem coefficientWord_inputHalf_even_iff (xs : List Bool) (k : Nat) :
    (∀ s ∈ coefficientWord (inputHalf xs k) none, s % 2 = 0) ↔
      xs = List.replicate xs.length true := by
  rw [coefficientWord_inputHalf]
  exact inputWord_even_iff xs k

/-- Halving the sole even profile explicitly gives the mirror of
`[7] ++ replicate m 7 ++ replicate k 9`. -/
theorem half_inputWord_all_true (m k : Nat) :
    (inputWord (List.replicate m true) k).map (fun s => s / 2) =
      palindromeDigits m k := by
  simp [inputWord, inputHalf, palindromeDigits, palindromeHalf,
    choice, List.map_reverse]

theorem profileCount_inputHalf_all_true (m k : Nat) :
    profileCount (inputHalf (List.replicate m true) k) none = 5 * 5 ^ m := by
  rw [← length_numericFiber, length_inputFiber]
  simp [choice, pairCount, natProduct_replicate]

theorem profileCount_inputHalf_all_true_positive (m k : Nat) :
    0 < profileCount (inputHalf (List.replicate m true) k) none := by
  rw [profileCount_inputHalf_all_true]
  exact Nat.mul_pos (by decide) (Nat.pow_pos (by decide))

/-- The explicit candidate is a member of the complete counted family and
is a palindrome under the unchanged ordinary decimal reversal. -/
theorem palindromeSeed_member_palindrome (m k : Nat) :
    palindromeSeed m k ∈ protectedSeeds m k ∧
      Lychrel196.Palindrome (palindromeSeed m k) := by
  have he : ∀ s ∈ coefficientWord (inputHalf (List.replicate m true) k) none,
      s % 2 = 0 := by
    rw [coefficientWord_inputHalf]
    exact inputWord_all_true_even m k
  have h := half_coefficientWord_mem_numericFiber
    (inputHalf (List.replicate m true) k) none
    (profileCount_inputHalf_all_true_positive m k) he
  rw [coefficientWord_inputHalf, half_inputWord_all_true] at h
  refine ⟨(mem_protectedSeeds m k _).mpr ?_, h.2⟩
  exact ⟨List.replicate m true, List.length_replicate, h.1⟩

/-- Exactly one member of the complete numerical family is initially
palindromic; the statement includes both its existence and uniqueness. -/
theorem protectedSeeds_palindrome_iff (m k n : Nat) :
    (n ∈ protectedSeeds m k ∧ Lychrel196.Palindrome n) ↔
      n = palindromeSeed m k := by
  constructor
  · rintro ⟨hn, hp⟩
    obtain ⟨xs, hlen, hx⟩ := (mem_protectedSeeds m k n).mp hn
    have hs := (palindrome_mem_numericFiber_iff (inputHalf xs k) none n).mp ⟨hx, hp⟩
    have hxtrue := (coefficientWord_inputHalf_even_iff xs k).mp hs.2.1
    have hxrep : xs = List.replicate m true := by simpa only [hlen] using hxtrue
    have hnval := hs.2.2
    rw [coefficientWord_inputHalf, hxrep, half_inputWord_all_true] at hnval
    exact hnval
  · intro hn
    rw [hn]
    exact palindromeSeed_member_palindrome m k

theorem palindromeSeed_mem (m k : Nat) :
    palindromeSeed m k ∈ protectedSeeds m k :=
  (palindromeSeed_member_palindrome m k).1

theorem palindromeSeed_palindrome (m k : Nat) :
    Lychrel196.Palindrome (palindromeSeed m k) :=
  (palindromeSeed_member_palindrome m k).2

theorem protectedSeeds_palindrome_unique (m k n p : Nat)
    (hn : n ∈ protectedSeeds m k ∧ Lychrel196.Palindrome n)
    (hp : p ∈ protectedSeeds m k ∧ Lychrel196.Palindrome p) : n = p :=
  ((protectedSeeds_palindrome_iff m k n).mp hn).trans
    ((protectedSeeds_palindrome_iff m k p).mp hp).symm

#print axioms palindromeHalf
#print axioms palindromeDigits
#print axioms palindromeSeed
#print axioms all_true_eq_replicate
#print axioms inputWord_all_true_even
#print axioms inputWord_even_iff
#print axioms coefficientWord_inputHalf_even_iff
#print axioms half_inputWord_all_true
#print axioms profileCount_inputHalf_all_true
#print axioms profileCount_inputHalf_all_true_positive
#print axioms palindromeSeed_member_palindrome
#print axioms protectedSeeds_palindrome_iff
#print axioms palindromeSeed_mem
#print axioms palindromeSeed_palindrome
#print axioms protectedSeeds_palindrome_unique

end Agent101.Protected
