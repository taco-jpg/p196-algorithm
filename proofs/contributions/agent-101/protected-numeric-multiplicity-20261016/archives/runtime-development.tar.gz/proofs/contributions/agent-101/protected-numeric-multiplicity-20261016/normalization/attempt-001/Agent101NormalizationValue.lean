import Agent101NumericFibers
import PeriodObstructions
import SafeHighFamily

/-!
Agent 101 compatibility between finite decimal evaluation and the existing
Agent 8 list normalizer. The carry value-preservation theorem is reused
from `SafeHighFamily.value_normalize`; this file only connects definitions.
-/

namespace Agent101

theorem natValue_nil : natValue [] = 0 := rfl

theorem natValue_cons (a : Nat) (ds : List Nat) :
    natValue (a :: ds) = a + 10 * natValue ds := by
  unfold natValue
  rw [List.length_cons, DecimalDigits.value_shift]
  simp only [digitFn, List.getElem?_cons_zero, List.getElem?_cons_succ,
    Option.getD_some]

theorem natValue_eq_safeHighValue (ds : List Nat) :
    natValue ds = SafeHighFamily.value ds := by
  induction ds with
  | nil => rfl
  | cons a ds ih => rw [natValue_cons, ih, SafeHighFamily.value]

theorem normalize_eq_safeHighNormalize (w : List Nat) (e : Nat) :
    Agent8.normalize w e = SafeHighFamily.normalize w e := by
  induction w generalizing e with
  | nil => rfl
  | cons x xs ih => simp only [Agent8.normalize, SafeHighFamily.normalize, ih]

/-- Transport the existing all-word, all-carry value-preservation theorem. -/
theorem natValue_normalize (w : List Nat) (e : Nat) :
    natValue (Agent8.normalize w e) = natValue w + e := by
  rw [normalize_eq_safeHighNormalize, natValue_eq_safeHighValue,
    SafeHighFamily.value_normalize, natValue_eq_safeHighValue]

theorem natValue_normalize_zero (w : List Nat) :
    natValue (Agent8.normalize w 0) = natValue w := by
  simpa only [Nat.add_zero] using natValue_normalize w 0

theorem step_eq_normalized_pair_value (ds : List Nat)
    (hd : canonicalDigits ds) :
    Lychrel196.step (natValue ds) =
      natValue (Agent8.normalize (digitPairSums ds) 0) := by
  rw [natValue_normalize_zero, step_natValue ds hd]

/-- Any enumerated predecessor has precisely this normalized first value. -/
theorem numericFiber_first_step (h : List Nat) (c : Option Nat) (n : Nat)
    (hn : n ∈ numericFiber h c) :
    Lychrel196.step n = natValue (Agent8.normalize (coefficientWord h c) 0) := by
  obtain ⟨ds, hd, hp, hv⟩ := (mem_numericFiber_digits h c n).mp hn
  rw [← hv, step_eq_normalized_pair_value ds hd, hp]

#print axioms natValue_nil
#print axioms natValue_cons
#print axioms natValue_eq_safeHighValue
#print axioms normalize_eq_safeHighNormalize
#print axioms natValue_normalize
#print axioms natValue_normalize_zero
#print axioms step_eq_normalized_pair_value
#print axioms numericFiber_first_step

end Agent101
