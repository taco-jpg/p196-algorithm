"""Explicit trust-zero audits of the sole canonical build; never rebuild modules."""

from pathlib import Path
from collections import Counter
import hashlib
import json
import os
import re
import shutil
import subprocess
import time


REVIEWS = Path(__file__).resolve().parent
REPO = REVIEWS.parents[4]
OUT = Path("/workspace/scratch/2a8a87fd78df/agent101-all-width-canonical-review-01")
PROJECT = "agent101-all-width-maximum"
SOURCE = OUT / PROJECT / "source"
LEAN = Path("/workspace/scratch/2a8a87fd78df/agent101-runtime/toolchain/lean-4.19.0-linux/bin/lean")
COMMIT = "0a746261de31531b3ed1dc3d754cd3093753ff56"
REGISTRY_SHA = "496908a7d53c6a09b7a82dfae3c5e10339ef699072e5c97c0e591dc4e2c2cfcc"
ORIGINAL_AUDITOR = "proofs/contributions/agent-101/nonpalindromic-fibers-20261016/reviews/independent-numeric-bridge-20261016/CompiledAudit.lean"
ALLOWED = {"propext", "Classical.choice", "Quot.sound"}
ENV = os.environ.copy()
ENV["LEAN_PATH"] = str(SOURCE)
ENV["GIT_NO_LAZY_FETCH"] = "1"
RECORDS = []


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def save(name, data):
    target = REVIEWS / name
    with target.open("xb") as handle:
        handle.write(data if isinstance(data, bytes) else data.encode())
    return target


def run(label, source_path):
    command = [str(LEAN), "--trust=0", "-j1", "-DElab.async=false", str(source_path)]
    started = time.monotonic()
    proc = subprocess.run(command, cwd=SOURCE, env=ENV, stdout=subprocess.PIPE,
        stderr=subprocess.STDOUT)
    log = save("final-" + label + ".log", proc.stdout)
    record = {"label": label, "command": command, "cwd": str(SOURCE),
        "LEAN_PATH": str(SOURCE), "returncode": proc.returncode,
        "seconds": time.monotonic() - started,
        "source": str(source_path), "source_sha256": sha(source_path),
        "log": str(log.relative_to(REPO)), "log_sha256": sha(log)}
    RECORDS.append(record)
    (REVIEWS / "final-audit-commands.json").write_text(json.dumps(RECORDS, indent=2) + "\n")
    print(json.dumps(record), flush=True)
    assert proc.returncode == 0, proc.stdout.decode(errors="replace")
    text = proc.stdout.decode()
    assert "sorryAx" not in text and "Lean.ofReduceBool" not in text
    return text


def printed_axioms(log):
    printed = re.findall(r"^'([^']+)' (?:depends on axioms:|does not depend on any axioms)", log, re.M)
    union = {a.strip() for group in re.findall(r"depends on axioms: \[([^]]*)\]", log)
        for a in group.split(",") if a.strip()}
    assert union <= ALLOWED, union
    return printed, union


def main():
    canonical = json.loads((OUT / "verification.json").read_text())
    assert canonical["status"] == "PASS"
    assert canonical["source_commit"] == COMMIT
    assert canonical["registry_sha256"] == REGISTRY_SHA
    pr = canonical["projects"][PROJECT]
    assert pr["status"] == "PASS" and len(pr["build_order"]) == 17
    original_files = json.loads((OUT / "FILES.json").read_text())
    for path, pin in original_files.items():
        assert sha(OUT / path) == pin["sha256"], path
        assert (OUT / path).stat().st_size == pin["bytes"], path
    assert all(not path.endswith(".olean") for path in original_files)
    readback = json.loads((REVIEWS / "final-source-readback.json").read_text())
    assert readback["status"] == "PASS_EXACT_SOURCE_AND_METADATA_IDENTITY_ONLY"
    assert readback["published_commit"] == COMMIT
    exports_metadata = json.loads((REVIEWS / "final-public-exports.json").read_text())
    exports = [{"module": module, **decl}
        for module, data in exports_metadata["modules"].items()
        for decl in data["public_declarations"]]
    public_names = [decl["name"] for decl in exports]
    assert len(exports) == len(set(public_names)) == 41
    assert Counter(decl["kind"] for decl in exports) == {"theorem": 36, "def": 5}
    assert public_names == pr["endpoints"]
    assert len(pr["commands"]) == 18
    assert all("--trust=0" not in command["argv"] for command in pr["commands"])
    save("final-canonical-verification.json", (OUT / "verification.json").read_bytes())
    save("final-canonical-FILES.json", (OUT / "FILES.json").read_bytes())
    for path in (OUT / PROJECT / "logs").glob("*.log"):
        dest = REVIEWS / "final-build-logs" / path.name
        dest.parent.mkdir(exist_ok=True)
        with dest.open("xb") as handle:
            handle.write(path.read_bytes())

    original_project_audit_sha = sha(SOURCE / "ProjectAudit.lean")
    save("final-ProjectAudit.lean", (SOURCE / "ProjectAudit.lean").read_bytes())
    project_log = run("ProjectAudit-trust0", SOURCE / "ProjectAudit.lean")
    assert sha(SOURCE / "ProjectAudit.lean") == original_project_audit_sha
    theorems = re.findall(r"^AUDIT_THEOREM (\S+) (\S+) : (.*)$", project_log, re.M)
    summaries = re.findall(r"^FULL_MODULE_AUDIT theorems=(\d+) union=([^\n]*)$", project_log, re.M)
    assert len(summaries) == 1
    assert int(summaries[0][0]) == len(theorems) == pr["theorem_count"]
    assert len({name for _, name, _ in theorems}) == len(theorems)
    theorem_union = {x.strip() for x in summaries[0][1].strip("[]").split(",") if x.strip()}
    assert theorem_union <= ALLOWED

    prelude = "import Agent101AllWidthMaximum\nimport Lean\nopen Lean Elab Command\nset_option maxRecDepth 100000\nset_option maxHeartbeats 0\n\n"
    public_audit = prelude + "".join("#check " + name + "\n#print axioms " + name + "\n" for name in public_names)
    public_audit += "\nrun_cmd do\n  let env ← getEnv\n  let publicNames : List String := " + json.dumps(public_names) + "\n"
    public_audit += '''  let mut seen := 0
  for (name, info) in env.constants.toList do
    if publicNames.contains name.toString then
      if info.isUnsafe then throwError m!"UNSAFE_PUBLIC_DECLARATION {name}"
      let kind := match info with
        | .thmInfo _ => "theorem"
        | .defnInfo _ => "def"
        | .opaqueInfo _ => "opaque"
        | .axiomInfo _ => "axiom"
        | _ => "other"
      if kind == "axiom" then throwError m!"PUBLIC_CUSTOM_AXIOM {name}"
      let some idx := env.getModuleIdxFor? name
        | throwError m!"PUBLIC_MODULE_MISSING {name}"
      let mod := env.allImportedModuleNames[idx.toNat]!
      seen := seen + 1
      logInfo m!"PUBLIC_SAFE {mod} {kind} {name}"
  if seen != publicNames.length then throwError m!"PUBLIC_CENSUS_MISMATCH {seen}"
  logInfo m!"PUBLIC_COUNT {seen}"
'''
    public_file = save("final-PublicAudit.lean", public_audit)
    public_log = run("PublicAudit-trust0", public_file)
    printed, public_union = printed_axioms(public_log)
    public_safe = re.findall(r"^PUBLIC_SAFE (\S+) (\S+) (\S+)$", public_log, re.M)
    expected_public = {(decl["module"], decl["kind"], decl["name"]) for decl in exports}
    assert len(printed) == len(public_safe) == 41
    assert set(printed) == set(public_names)
    assert set(public_safe) == expected_public
    assert re.findall(r"^PUBLIC_COUNT (\d+)$", public_log, re.M) == ["41"]

    # Adapt the earlier independent compiled-environment auditor. The unchanged
    # ProjectAudit has already covered every theorem, so this additional pass
    # checks every safe definition/opaque and records unsafe implementations.
    original_auditor_bytes = (REPO / ORIGINAL_AUDITOR).read_bytes()
    save("final-original-CompiledAudit.lean.txt", original_auditor_bytes)
    compiled_audit = prelude + "run_cmd do\n  let env ← getEnv\n  let selected : List String := " + json.dumps(pr["build_order"]) + "\n"
    compiled_audit += '''  let mut definitions := 0
  let mut opaques := 0
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        if info.isUnsafe then
          logInfo m!"UNSAFE_COMPILER_IMPLEMENTATION {mod} {name}"
        else
          match info with
          | .axiomInfo _ => throwError m!"CUSTOM_AXIOM {mod} {name}"
          | .defnInfo _ =>
            definitions := definitions + 1
            logInfo m!"COMPILED_DEFINITION {mod} {name}"
            elabCommand (← `(command| #print axioms $(mkIdent name)))
          | .opaqueInfo _ =>
            opaques := opaques + 1
            logInfo m!"COMPILED_OPAQUE {mod} {name}"
            elabCommand (← `(command| #print axioms $(mkIdent name)))
          | _ => pure ()
  logInfo m!"SAFE_DEFINITION_CENSUS definitions={definitions} opaques={opaques}"
'''
    compiled_file = save("final-CompiledDefinitionsAudit.lean", compiled_audit)
    compiled_log = run("CompiledDefinitionsAudit-trust0", compiled_file)
    compiled = re.findall(r"^COMPILED_(DEFINITION|OPAQUE) (\S+) (\S+)$", compiled_log, re.M)
    unsafe = re.findall(r"^UNSAFE_COMPILER_IMPLEMENTATION (\S+) (\S+)$", compiled_log, re.M)
    compiled_printed, compiled_union = printed_axioms(compiled_log)
    census = re.findall(r"^SAFE_DEFINITION_CENSUS definitions=(\d+) opaques=(\d+)$", compiled_log, re.M)
    assert len(census) == 1
    definitions, opaques = map(int, census[0])
    assert definitions + opaques == len(compiled) == len(compiled_printed)
    assert len({name for _, _, name in compiled}) == len(compiled)
    assert {name for _, _, name in compiled} == set(compiled_printed)
    assert sum(kind == "DEFINITION" for kind, _, _ in compiled) == definitions
    assert sum(kind == "OPAQUE" for kind, _, _ in compiled) == opaques
    assert {decl["name"] for decl in exports if decl["kind"] == "def"} <= set(compiled_printed)
    assert not (set(public_names) & {name for _, name in unsafe})
    save("final-compiled-definition-inventory.json", json.dumps({
        "safe": [{"kind": k, "module": m, "name": n} for k, m, n in compiled],
        "unsafe_implementation": [{"module": m, "name": n} for m, n in unsafe],
        "safe_definition_count": definitions, "safe_opaque_count": opaques,
        "safe_axiom_union": sorted(compiled_union)}, indent=2) + "\n")

    for module, rec in pr["sources"].items():
        assert sha(REPO / rec["path"]) == rec["sha256"]
        assert sha(SOURCE / (module.replace(".", "/") + ".lean")) == rec["build_sha256"]
        assert rec["adapter"] is None
    for rec in readback["metadata"]:
        assert sha(REPO / rec["path"]) == rec["sha256"]
    for filename, expected in canonical["compiler"]["files"].items():
        assert sha(filename) == expected
    for path, pin in original_files.items():
        assert sha(OUT / path) == pin["sha256"], path
    selected = [row["path"] for row in readback["sources"] + readback["metadata"]]
    selected_status = subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=all", "--", *selected], cwd=REPO, env=ENV, text=True)
    tracked_status = subprocess.check_output(["git", "status", "--porcelain", "--untracked-files=no"], cwd=REPO, env=ENV, text=True)
    actual_head = subprocess.check_output(["git", "rev-parse", "HEAD"], cwd=REPO, env=ENV, text=True).strip()
    assert selected_status == "" and actual_head == COMMIT
    result = {
        "result": "PASS", "reviewer": "/root/research_inventory",
        "published_commit": COMMIT, "published_tree": readback["published_tree"],
        "math_commit": readback["math_commit"], "registry_sha256": REGISTRY_SHA,
        "canonical_output_directory": str(OUT), "canonical_verifier_status": canonical["status"],
        "canonical_verifier_sha256": readback["verifier_sha256"],
        "canonical_compile_policy": "The sole unchanged canonical verifier freshly compiled all 17 modules and its initial ProjectAudit with -j1 -DElab.async=false; none of those commands explicitly passed --trust=0.",
        "explicit_trust_zero_policy": "Reused that one fresh closure for the unchanged ProjectAudit, all 41 public declarations, and all safe definitions/opaque declarations originating in the 17 modules; each of these three audit commands explicitly passed --trust=0.",
        "module_count": 17, "canonical_module_compile_count": 17,
        "transitive_theorem_count": len(theorems),
        "theorems_by_origin_module": dict(sorted(Counter(module for module, _, _ in theorems).items())),
        "theorem_axiom_union": sorted(theorem_union),
        "all_transitive_theorems_audited_at_trust_zero": True,
        "public_declarations": 41, "public_theorems": 36, "public_definitions": 5,
        "all_public_declarations_safe_and_origin_kind_matched": True,
        "public_axiom_union": sorted(public_union),
        "safe_definitions": definitions, "safe_opaques": opaques,
        "safe_definitions_and_opaques_axiom_union": sorted(compiled_union),
        "unsafe_compiler_implementation_count": len(unsafe),
        "unsafe_implementation_axioms_from_original_audit": pr["unsafe_implementation_axioms"],
        "extra_compiled_auditor_original": ORIGINAL_AUDITOR,
        "extra_compiled_auditor_original_sha256": hashlib.sha256(original_auditor_bytes).hexdigest(),
        "extra_compiled_auditor_adaptation": "Imported the maximum root, selected all 17 exact origin modules, counted safe definitions/opaques, omitted theorem reprinting already handled by unchanged ProjectAudit, and retained ConstantInfo.isUnsafe separation without name-based heuristics.",
        "sources_metadata_verifier_compiler_unchanged_after_audits": True,
        "canonical_FILES_member_count": len(original_files),
        "canonical_FILES_excludes_olean": True,
        "all_original_canonical_FILES_members_unchanged": True,
        "original_canonical_source_tree_clean": canonical["source_tree_clean"],
        "selected_source_and_metadata_clean": True,
        "selected_source_and_metadata_status_after": selected_status,
        "repository_tracked_status_after": tracked_status,
        "repository_tracked_tree_clean_after": tracked_status == "",
        "cleanliness_explanation": "Two unrelated existing PR114 README edits were deliberately preserved; they make the original verifier repository-wide tracked source_tree_clean false. All 17 selected sources and 8 metadata files are exact committed bytes and have empty selected git status.",
        "initial_precheck_failure": "The first Git-object read failed because the partial clone lacked a promisor blob. Both commit trees contained the correct entry. Root hydrated objects without refs/index/worktree changes; the same unmodified readback script then passed with GIT_NO_LAZY_FETCH=1. No Lean build had been attempted during this failure.",
        "audit_commands": RECORDS,
        "independence": "Reviewer authored none of the four new maximum modules. Reviewer authored the older SplitEnumeration and PalindromeFibers dependencies, independently reviewed by other workers; that authorship is not represented as independent review of those older modules.",
        "no_mathematical_source_edits": True, "no_git_writes_by_reviewer": True,
        "script_sha256": sha(__file__),
    }
    save("final-verification.json", json.dumps(result, indent=2) + "\n")
    print(json.dumps({key: result[key] for key in ["result", "module_count", "transitive_theorem_count", "public_declarations", "safe_definitions", "safe_opaques", "unsafe_compiler_implementation_count"]}), flush=True)


if __name__ == "__main__":
    main()
