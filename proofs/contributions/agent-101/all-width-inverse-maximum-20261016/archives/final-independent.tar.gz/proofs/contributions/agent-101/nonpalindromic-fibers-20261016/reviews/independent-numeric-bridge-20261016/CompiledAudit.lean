import Agent101NonpalindromicFibers
import Lean

open Lean Elab Command

set_option maxRecDepth 100000
set_option maxHeartbeats 0

run_cmd do
  let env ← getEnv
  let selected : List String := ["Agent101PalindromeFibers", "Agent101NonpalindromicFibers"]
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        if info.isUnsafe then
          logInfo m!"UNSAFE_COMPILER_IMPLEMENTATION {mod} {name}"
        else
          match info with
          | .axiomInfo _ => throwError m!"CUSTOM_AXIOM {mod} {name}"
          | .thmInfo _ =>
            logInfo m!"COMPILED_THEOREM {mod} {name}"
            elabCommand (← `(command| #print axioms $(mkIdent name)))
          | .defnInfo _ =>
            logInfo m!"COMPILED_DEFINITION {mod} {name}"
            elabCommand (← `(command| #print axioms $(mkIdent name)))
          | .opaqueInfo _ =>
            logInfo m!"COMPILED_OPAQUE {mod} {name}"
            elabCommand (← `(command| #print axioms $(mkIdent name)))
          | _ => pure ()
