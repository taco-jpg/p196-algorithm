import Agent101AllWidthMaximum
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0

#check Agent101.reverse_wrapDigits
#print axioms Agent101.reverse_wrapDigits
#check Agent101.exists_coefficientWord_of_reverse
#print axioms Agent101.exists_coefficientWord_of_reverse
#check Agent101.coefficientWord_half_length
#print axioms Agent101.coefficientWord_half_length
#check Agent101.digitFn_coefficientWord_cons_zero
#print axioms Agent101.digitFn_coefficientWord_cons_zero
#check Agent101.digitPairSums_reverse
#print axioms Agent101.digitPairSums_reverse
#check Agent101.digitPairSums_profile
#print axioms Agent101.digitPairSums_profile
#check Agent101.digitPairSums_profile_cons
#print axioms Agent101.digitPairSums_profile_cons
#check Agent101.mem_numericFiber_of_same_width_step
#print axioms Agent101.mem_numericFiber_of_same_width_step
#check Agent101.fixed_width_profile_length_le
#print axioms Agent101.fixed_width_profile_length_le
#check Agent101.profileCount_cons_outer_le
#print axioms Agent101.profileCount_cons_outer_le
#check Agent101.fixed_width_preimages_outer_bound
#print axioms Agent101.fixed_width_preimages_outer_bound
#check Agent101.fixed_width_preimages_bound
#print axioms Agent101.fixed_width_preimages_bound
#check Agent101.one_digit_preimages_bound
#print axioms Agent101.one_digit_preimages_bound
#check Agent101.MaximumWitnesses.maximumHalf
#print axioms Agent101.MaximumWitnesses.maximumHalf
#check Agent101.MaximumWitnesses.maximumCenter
#print axioms Agent101.MaximumWitnesses.maximumCenter
#check Agent101.MaximumWitnesses.maximumWord
#print axioms Agent101.MaximumWitnesses.maximumWord
#check Agent101.MaximumWitnesses.maximumTarget
#print axioms Agent101.MaximumWitnesses.maximumTarget
#check Agent101.MaximumWitnesses.maximumPreimages
#print axioms Agent101.MaximumWitnesses.maximumPreimages
#check Agent101.MaximumWitnesses.maximumHalf_cons
#print axioms Agent101.MaximumWitnesses.maximumHalf_cons
#check Agent101.MaximumWitnesses.length_maximumWord
#print axioms Agent101.MaximumWitnesses.length_maximumWord
#check Agent101.MaximumWitnesses.maximumWord_bounded
#print axioms Agent101.MaximumWitnesses.maximumWord_bounded
#check Agent101.MaximumWitnesses.maximumWord_canonical
#print axioms Agent101.MaximumWitnesses.maximumWord_canonical
#check Agent101.MaximumWitnesses.maximumWord_units
#print axioms Agent101.MaximumWitnesses.maximumWord_units
#check Agent101.MaximumWitnesses.maximumTarget_width
#print axioms Agent101.MaximumWitnesses.maximumTarget_width
#check Agent101.MaximumWitnesses.maximumCenter_count
#print axioms Agent101.MaximumWitnesses.maximumCenter_count
#check Agent101.MaximumWitnesses.maximumPreimages_nodup
#print axioms Agent101.MaximumWitnesses.maximumPreimages_nodup
#check Agent101.MaximumWitnesses.length_maximumPreimages
#print axioms Agent101.MaximumWitnesses.length_maximumPreimages
#check Agent101.MaximumWitnesses.mem_maximumPreimages_fixed
#print axioms Agent101.MaximumWitnesses.mem_maximumPreimages_fixed
#check Agent101.MaximumWitnesses.maximumPreimages_nonempty
#print axioms Agent101.MaximumWitnesses.maximumPreimages_nonempty
#check Agent101.MaximumWitnesses.mem_maximumPreimages
#print axioms Agent101.MaximumWitnesses.mem_maximumPreimages
#check Agent101.MaximumWitnesses.all_width_maximum_witness
#print axioms Agent101.MaximumWitnesses.all_width_maximum_witness
#check Agent101.MaximumWitnesses.one_digit_preimages
#print axioms Agent101.MaximumWitnesses.one_digit_preimages
#check Agent101.MaximumWitnesses.one_digit_maximum_witness
#print axioms Agent101.MaximumWitnesses.one_digit_maximum_witness
#check Agent101.Maximum.predecessor_width_cases
#print axioms Agent101.Maximum.predecessor_width_cases
#check Agent101.Maximum.predecessor_one_digit_width
#print axioms Agent101.Maximum.predecessor_one_digit_width
#check Agent101.Maximum.width_bound_mono
#print axioms Agent101.Maximum.width_bound_mono
#check Agent101.Maximum.two_width_bound_arithmetic
#print axioms Agent101.Maximum.two_width_bound_arithmetic
#check Agent101.Maximum.all_width_preimages_bound
#print axioms Agent101.Maximum.all_width_preimages_bound
#check Agent101.Maximum.one_digit_target_preimages_bound
#print axioms Agent101.Maximum.one_digit_target_preimages_bound
#check Agent101.Maximum.all_width_inverse_maximum
#print axioms Agent101.Maximum.all_width_inverse_maximum
#check Agent101.Maximum.one_digit_inverse_maximum
#print axioms Agent101.Maximum.one_digit_inverse_maximum

run_cmd do
  let env ← getEnv
  let publicNames : List String := ["Agent101.reverse_wrapDigits", "Agent101.exists_coefficientWord_of_reverse", "Agent101.coefficientWord_half_length", "Agent101.digitFn_coefficientWord_cons_zero", "Agent101.digitPairSums_reverse", "Agent101.digitPairSums_profile", "Agent101.digitPairSums_profile_cons", "Agent101.mem_numericFiber_of_same_width_step", "Agent101.fixed_width_profile_length_le", "Agent101.profileCount_cons_outer_le", "Agent101.fixed_width_preimages_outer_bound", "Agent101.fixed_width_preimages_bound", "Agent101.one_digit_preimages_bound", "Agent101.MaximumWitnesses.maximumHalf", "Agent101.MaximumWitnesses.maximumCenter", "Agent101.MaximumWitnesses.maximumWord", "Agent101.MaximumWitnesses.maximumTarget", "Agent101.MaximumWitnesses.maximumPreimages", "Agent101.MaximumWitnesses.maximumHalf_cons", "Agent101.MaximumWitnesses.length_maximumWord", "Agent101.MaximumWitnesses.maximumWord_bounded", "Agent101.MaximumWitnesses.maximumWord_canonical", "Agent101.MaximumWitnesses.maximumWord_units", "Agent101.MaximumWitnesses.maximumTarget_width", "Agent101.MaximumWitnesses.maximumCenter_count", "Agent101.MaximumWitnesses.maximumPreimages_nodup", "Agent101.MaximumWitnesses.length_maximumPreimages", "Agent101.MaximumWitnesses.mem_maximumPreimages_fixed", "Agent101.MaximumWitnesses.maximumPreimages_nonempty", "Agent101.MaximumWitnesses.mem_maximumPreimages", "Agent101.MaximumWitnesses.all_width_maximum_witness", "Agent101.MaximumWitnesses.one_digit_preimages", "Agent101.MaximumWitnesses.one_digit_maximum_witness", "Agent101.Maximum.predecessor_width_cases", "Agent101.Maximum.predecessor_one_digit_width", "Agent101.Maximum.width_bound_mono", "Agent101.Maximum.two_width_bound_arithmetic", "Agent101.Maximum.all_width_preimages_bound", "Agent101.Maximum.one_digit_target_preimages_bound", "Agent101.Maximum.all_width_inverse_maximum", "Agent101.Maximum.one_digit_inverse_maximum"]
  let mut seen := 0
  for (name, info) in env.constants.toList do
    if publicNames.contains name.toString then
      if info.isUnsafe then throwError m!"UNSAFE_PUBLIC_DECLARATION {name}"
      let kind := match info with
        | .thmInfo _ => "theorem"
        | .defnInfo _ => "def"
        | .opaqueInfo _ => "opaque"
        | .axiomInfo _ => "axiom"
        | _ => "other"
      if kind == "axiom" then throwError m!"PUBLIC_CUSTOM_AXIOM {name}"
      let some idx := env.getModuleIdxFor? name
        | throwError m!"PUBLIC_MODULE_MISSING {name}"
      let mod := env.allImportedModuleNames[idx.toNat]!
      seen := seen + 1
      logInfo m!"PUBLIC_SAFE {mod} {kind} {name}"
  if seen != publicNames.length then throwError m!"PUBLIC_CENSUS_MISMATCH {seen}"
  logInfo m!"PUBLIC_COUNT {seen}"
