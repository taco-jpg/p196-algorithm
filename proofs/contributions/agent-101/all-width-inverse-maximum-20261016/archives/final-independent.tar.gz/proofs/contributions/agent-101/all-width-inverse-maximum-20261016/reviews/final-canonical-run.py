"""Run the unchanged original verifier exactly once in a new empty output path."""

from pathlib import Path
import hashlib
import json
import os
import subprocess
import time


reviews = Path(__file__).resolve().parent
repo = reviews.parents[4]
out = Path("/workspace/scratch/2a8a87fd78df/agent101-all-width-canonical-review-01")
lean = Path("/workspace/scratch/2a8a87fd78df/agent101-runtime/toolchain/lean-4.19.0-linux/bin/lean")
readback = json.loads((reviews / "final-source-readback.json").read_text())
assert readback["status"] == "PASS_EXACT_SOURCE_AND_METADATA_IDENTITY_ONLY"
assert not out.exists(), f"Output already exists; preserving it: {out}"
assert hashlib.sha256((repo / readback["verifier_path"]).read_bytes()).hexdigest() == readback["verifier_sha256"]
command = ["python3", readback["verifier_path"], "--lean", str(lean),
    "--output", str(out), "--project", "agent101-all-width-maximum",
    "--registry", readback["registry_path"]]
env = os.environ.copy()
env["GIT_NO_LAZY_FETCH"] = "1"
record = {"command": command, "cwd": str(repo), "output": str(out),
    "output_absent_before_run": True, "original_verifier_unchanged": True,
    "policy": "Original module and initial ProjectAudit commands use -j1 -DElab.async=false, without an explicit --trust=0 flag.",
    "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
log_path = reviews / "final-canonical-command.log"
start = time.monotonic()
print(json.dumps({"status": "STARTING_SINGLE_CANONICAL_BUILD", **record}), flush=True)
with log_path.open("xb") as log:
    proc = subprocess.run(command, cwd=repo, env=env, stdout=log, stderr=subprocess.STDOUT)
record.update({"returncode": proc.returncode, "seconds": time.monotonic() - start,
    "finished_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
    "log": str(log_path.relative_to(repo)),
    "log_sha256": hashlib.sha256(log_path.read_bytes()).hexdigest()})
with (reviews / "final-canonical-command.json").open("x") as handle:
    handle.write(json.dumps(record, indent=2) + "\n")
print(json.dumps(record), flush=True)
raise SystemExit(proc.returncode)
