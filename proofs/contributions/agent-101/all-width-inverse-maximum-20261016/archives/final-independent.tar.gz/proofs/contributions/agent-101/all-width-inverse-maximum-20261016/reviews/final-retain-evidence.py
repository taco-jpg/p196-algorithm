"""Index frozen review files and original canonical text artifacts losslessly."""

from pathlib import Path
import hashlib
import json


reviews = Path(__file__).resolve().parent
repo = reviews.parents[4]
receipt = reviews / "final-verification.json"
result = json.loads(receipt.read_text())
assert result["result"] == "PASS"
canonical = Path(result["canonical_output_directory"])
index_path = reviews / "final-retained-evidence.json"


def record(path, display):
    data = path.read_bytes()
    return {"path": display, "bytes": len(data),
        "sha256": hashlib.sha256(data).hexdigest()}


review_files = []
for path in sorted(reviews.rglob("*")):
    if not path.is_file() or path == index_path:
        continue
    assert path.suffix not in {".olean", ".ilean", ".pyc"}, path
    assert "__pycache__" not in path.parts, path
    review_files.append(record(path, str(path.relative_to(repo))))

canonical_files = []
excluded_objects = []
for path in sorted(canonical.rglob("*")):
    if not path.is_file():
        continue
    if path.suffix == ".olean":
        excluded_objects.append(str(path.relative_to(canonical)))
    else:
        assert path.suffix not in {".ilean", ".pyc"}, path
        canonical_files.append(record(path, str(path.relative_to(canonical))))
assert len(excluded_objects) == 17
assert len(canonical_files) == 38
assert len([x for x in canonical_files if x["path"].endswith(".lean")]) == 18
assert len([x for x in canonical_files if x["path"].endswith(".log")]) == 18
data = {"status": "PASS_FROZEN_EVIDENCE_INDEX", "lean_invoked": False,
    "final_receipt": record(receipt, str(receipt.relative_to(repo))),
    "semantic_review": record(reviews / "final-semantic-review.md",
        str((reviews / "final-semantic-review.md").relative_to(repo))),
    "review_files": review_files,
    "review_file_count": len(review_files),
    "review_bytes": sum(x["bytes"] for x in review_files),
    "canonical_root": str(canonical), "canonical_files": canonical_files,
    "canonical_non_object_file_count": len(canonical_files),
    "canonical_non_object_bytes": sum(x["bytes"] for x in canonical_files),
    "excluded_compiler_objects": excluded_objects,
    "original_canonical_FILES_entries": result["canonical_FILES_member_count"],
    "original_canonical_FILES_excludes_olean_and_itself": True,
    "index_excludes_itself_to_avoid_recursive_hash": True,
    "script_sha256": hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
with index_path.open("x") as handle:
    handle.write(json.dumps(data, indent=2) + "\n")
print(json.dumps({"status": data["status"], "review_files": len(review_files),
    "canonical_non_object_files": len(canonical_files),
    "final_receipt_sha256": data["final_receipt"]["sha256"],
    "semantic_review_sha256": data["semantic_review"]["sha256"],
    "index_sha256": hashlib.sha256(index_path.read_bytes()).hexdigest()}))
