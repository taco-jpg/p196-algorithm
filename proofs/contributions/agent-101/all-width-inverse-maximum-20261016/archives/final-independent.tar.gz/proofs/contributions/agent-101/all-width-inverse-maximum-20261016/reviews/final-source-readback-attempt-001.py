"""Independent exact-Git source check; no Lean, network, or Git mutations."""

from pathlib import Path
import hashlib
import json
import os
import subprocess
import time


REVIEWS = Path(__file__).resolve().parent
REPO = REVIEWS.parents[4]
PACKET = "proofs/contributions/agent-101/all-width-inverse-maximum-20261016"
REGISTRY = "proofs/Agent101AllWidthMaximum.registry.json"
PROJECT = "agent101-all-width-maximum"
MATH_COMMIT = "0fcbe9973659f178e9c834c68d45f660241d6fbd"
MATH_TREE = "15556f672ab08a0198d3bd334aa034741572c1e6"
PUBLISHED_COMMIT = "0a746261de31531b3ed1dc3d754cd3093753ff56"
PUBLISHED_TREE = "a51cfaf14f39cf58d0294a0f71964f8a86724d45"
REGISTRY_SHA = "496908a7d53c6a09b7a82dfae3c5e10339ef699072e5c97c0e591dc4e2c2cfcc"
VERIFIER = "proofs/verify_project__214bf7673efe116b.py"
VERIFIER_SHA = "c047ff1ff1fe12b2c2094ca5f36af871b1c6faf89db593a102f9c2f7d48cc98a"
ENV = os.environ.copy()
ENV["GIT_NO_LAZY_FETCH"] = "1"
GIT_COMMANDS = []


def sha(data):
    return hashlib.sha256(data).hexdigest()


def blob(data):
    return hashlib.sha1(b"blob " + str(len(data)).encode() + b"\0" + data).hexdigest()


def save(name, data):
    target = REVIEWS / name
    with target.open("xb") as handle:
        handle.write(data)
    return target


def git(*args):
    command = ["git", *args]
    proc = subprocess.run(command, cwd=REPO, env=ENV, capture_output=True)
    GIT_COMMANDS.append({
        "command": command, "returncode": proc.returncode,
        "stdout_bytes": len(proc.stdout), "stdout_sha256": sha(proc.stdout),
        "stderr": proc.stderr.decode(errors="replace"),
    })
    if proc.returncode:
        raise RuntimeError(f"Git read failed: {command}: {proc.stderr!r}")
    return proc.stdout


def main():
    report = {"status": "IN_PROGRESS", "reviewer": "/root/research_inventory"}
    try:
        head = git("rev-parse", "HEAD").decode().strip()
        assert head == PUBLISHED_COMMIT, head
        assert git("rev-parse", MATH_COMMIT + "^{tree}").decode().strip() == MATH_TREE
        assert git("rev-parse", PUBLISHED_COMMIT + "^{tree}").decode().strip() == PUBLISHED_TREE
        registry_bytes = (REPO / REGISTRY).read_bytes()
        assert sha(registry_bytes) == REGISTRY_SHA
        registry = json.loads(registry_bytes)
        modules = registry["projects"][PROJECT]["modules"]
        assert len(modules) == 17
        sources = []
        for module, pin in modules.items():
            path = pin["path"]
            local = (REPO / path).read_bytes()
            math_bytes = git("show", MATH_COMMIT + ":" + path)
            published_bytes = git("show", PUBLISHED_COMMIT + ":" + path)
            assert local == math_bytes == published_bytes, path
            assert sha(local) == pin["sha256"], path
            assert blob(local) == pin["git_blob"], path
            sources.append({"module": module, "path": path, "bytes": len(local),
                "sha256": sha(local), "git_blob": blob(local),
                "math_commit_exact_bytes": True, "published_commit_exact_bytes": True,
                "local_exact_bytes": True})
        metadata_paths = [REGISTRY, PACKET + "/PUBLIC_EXPORTS.json",
            PACKET + "/REGISTRY.md", PACKET + "/make_registry.py", VERIFIER,
            "proofs/Agent101Nonpalindromic.registry.json",
            PACKET + "/bounds/dependencies/agent2/PROVENANCE.json",
            "proofs/contributions/agent-101/all-width-max-scout-20261016/source-provenance.json"]
        metadata = []
        for path in metadata_paths:
            local = (REPO / path).read_bytes()
            published = git("show", PUBLISHED_COMMIT + ":" + path)
            assert local == published, path
            metadata.append({"path": path, "bytes": len(local), "sha256": sha(local),
                "git_blob": blob(local), "published_commit_exact_bytes": True})
        assert sha((REPO / VERIFIER).read_bytes()) == VERIFIER_SHA
        selected_paths = [pin["path"] for pin in modules.values()] + metadata_paths
        selected_status = git("status", "--porcelain", "--untracked-files=all", "--", *selected_paths).decode()
        tracked_status = git("status", "--porcelain", "--untracked-files=no").decode()
        assert selected_status == "", selected_status
        command = ["python3", PACKET + "/make_registry.py", "--check",
            "--check-published-commit", PUBLISHED_COMMIT]
        started = time.monotonic()
        proc = subprocess.run(command, cwd=REPO, env=ENV, stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT)
        elapsed = time.monotonic() - started
        log = save("final-metadata-check.log", proc.stdout)
        check_record = {"command": command, "cwd": str(REPO),
            "returncode": proc.returncode, "seconds": elapsed,
            "log": str(log.relative_to(REPO)), "log_sha256": sha(proc.stdout)}
        report["metadata_checker"] = check_record
        assert proc.returncode == 0, proc.stdout.decode(errors="replace")
        checker_result = json.loads(proc.stdout)
        assert checker_result["status"] == "METADATA_AND_SOURCE_IDENTITY_CHECK_ONLY"
        assert checker_result["mathematical_proof_check"] is False
        assert checker_result["lean_invoked"] is False
        save("final-registry.json", registry_bytes)
        save("final-public-exports.json", (REPO / (PACKET + "/PUBLIC_EXPORTS.json")).read_bytes())
        report.update({"status": "PASS_EXACT_SOURCE_AND_METADATA_IDENTITY_ONLY",
            "lean_invoked": False, "mathematical_proof_check": False,
            "math_commit": MATH_COMMIT, "math_tree": MATH_TREE,
            "published_commit": PUBLISHED_COMMIT, "published_tree": PUBLISHED_TREE,
            "actual_head": head, "registry_path": REGISTRY, "registry_sha256": REGISTRY_SHA,
            "verifier_path": VERIFIER, "verifier_sha256": VERIFIER_SHA,
            "module_count": len(sources), "sources": sources, "metadata": metadata,
            "selected_source_and_metadata_status": selected_status,
            "selected_source_and_metadata_clean": True,
            "repository_tracked_status": tracked_status,
            "repository_tracked_tree_clean": tracked_status == "",
            "tracked_status_explanation": "The two pre-existing unrelated PR114 README edits are preserved. Original canonical source_tree_clean is repository-wide tracked status, not selected-source identity.",
            "git_reads_only": True, "network_used": False,
            "script_sha256": sha(Path(__file__).read_bytes())})
    except BaseException as error:
        report.update({"status": "FAIL", "error": repr(error)})
        raise
    finally:
        report["git_commands"] = GIT_COMMANDS
        save("final-source-readback.json", (json.dumps(report, indent=2) + "\n").encode())
    print(json.dumps({key: report[key] for key in ["status", "published_commit",
        "module_count", "selected_source_and_metadata_clean", "repository_tracked_tree_clean"]}), flush=True)


if __name__ == "__main__":
    main()
