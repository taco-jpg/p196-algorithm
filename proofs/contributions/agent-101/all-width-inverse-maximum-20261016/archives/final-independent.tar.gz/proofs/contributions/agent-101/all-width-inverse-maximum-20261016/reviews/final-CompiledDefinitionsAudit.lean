import Agent101AllWidthMaximum
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0

run_cmd do
  let env ← getEnv
  let selected : List String := ["Lychrel196Research", "Agent101DigitPairs", "Agent101MultiplicityBounds", "Agent101SplitEnumeration", "Agent101NumericFibers", "Agent105WidthSupport9df76b", "Agent105CrossWidth9df76b", "Agent101PalindromeFibers", "Agent101NonpalindromicFibers", "Agent101ProfileExtraction", "PeriodObstructions", "Agent2OverflowActual", "Agent2OverflowLocal", "Agent2OverflowBound", "Agent101WidthFiberBounds", "Agent101MaximumWitnesses", "Agent101AllWidthMaximum"]
  let mut definitions := 0
  let mut opaques := 0
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        if info.isUnsafe then
          logInfo m!"UNSAFE_COMPILER_IMPLEMENTATION {mod} {name}"
        else
          match info with
          | .axiomInfo _ => throwError m!"CUSTOM_AXIOM {mod} {name}"
          | .defnInfo _ =>
            definitions := definitions + 1
            logInfo m!"COMPILED_DEFINITION {mod} {name}"
            elabCommand (← `(command| #print axioms $(mkIdent name)))
          | .opaqueInfo _ =>
            opaques := opaques + 1
            logInfo m!"COMPILED_OPAQUE {mod} {name}"
            elabCommand (← `(command| #print axioms $(mkIdent name)))
          | _ => pure ()
  logInfo m!"SAFE_DEFINITION_CENSUS definitions={definitions} opaques={opaques}"
