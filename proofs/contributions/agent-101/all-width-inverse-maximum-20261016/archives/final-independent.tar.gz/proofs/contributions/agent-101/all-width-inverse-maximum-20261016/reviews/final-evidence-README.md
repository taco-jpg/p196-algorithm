# Final independent maximum evidence

The final result is **PASS** for the exact 17-module project
`agent101-all-width-maximum` at published commit
`0a746261de31531b3ed1dc3d754cd3093753ff56`.

Read `final-semantic-review.md` for the mathematical review and boundaries,
and `final-verification.json` for actual counts, commands, hashes, and
the precise distinction between the original verifier's flags and the
three later explicit `--trust=0` audits. The independent reviewer authored
none of the four new mathematical modules.

## Evidence map

| Files | Content |
| --- | --- |
| `final-source-readback.py`, `final-source-readback.json` | Independent exact Git bytes for 17 sources at both mathematical and registry commits; eight metadata checks; selected-path and whole-tracked-tree statuses. |
| `final-source-readback-attempt-001.py`, `.json` | Preserved first precheck failure caused by a missing partial-clone blob, before any Lean attempt. |
| `final-source-readback-attempt-002.log`, `final-metadata-check.log` | Actual successful unchanged readback and prescribed published-commit metadata check. |
| `final-pre-review-snapshot-check.json` | All four prior semantic source snapshots match the final accepted hashes. |
| `final-registry.json`, `final-public-exports.json` | Exact reviewed registry and complete 41-public source inventory. |
| `final-canonical-run.py`, `final-canonical-command.json`, `.log` | Single unchanged canonical invocation, exit zero, original flags, elapsed time. |
| `final-canonical-verification.json`, `final-canonical-FILES.json`, `final-build-logs/` | Unmodified report and manifest, plus all 18 original raw logs. |
| `final-audits.py`, `final-audit-commands.json` | Reuse of the single fresh closure for the three explicit trust-zero audits. |
| `final-ProjectAudit.lean`, `final-ProjectAudit-trust0.log` | Unchanged generated full-module theorem audit, 1,305 theorems. |
| `final-PublicAudit.lean`, `final-PublicAudit-trust0.log` | All 41 public declarations, complete axioms plus origin/kind/safety checks. |
| `final-CompiledDefinitionsAudit.lean`, `final-CompiledDefinitionsAudit-trust0.log`, `final-compiled-definition-inventory.json` | All 225 safe definitions, no safe opaque declarations, and the separate unsafe implementation inventory. |
| `final-original-CompiledAudit.lean.txt` | Exact prior independent auditor from which the definition/opaque pass was adapted. |
| `final-verification.json`, `final-semantic-review.md` | Final structured and semantic conclusions. |
| `final-retain-evidence.py`, `final-retained-evidence.json` | Reproducible per-file evidence inventory, excluding compiler objects and the inventory itself. |

The complete original canonical output remains at
`/workspace/scratch/2a8a87fd78df/agent101-all-width-canonical-review-01`.
It contains 17 exact mathematical source copies, the original generated
ProjectAudit source, 18 raw logs, `verification.json`, and `FILES.json`,
as well as 17 compiled objects. Compiled objects are excluded from the
evidence index and archival payload. The original `FILES.json` itself
already excludes `.olean`; all 37 entries were rechecked byte-for-byte.

## Reproduction and preservation

The exact canonical and audit commands are retained in the structured
receipts. `final-canonical-run.py` refuses an existing output directory.
It never changes the original verifier and never adds trust flags to that
verifier's commands. `final-audits.py` requires the canonical PASS and pins
before invoking the extra audits. The scripts deliberately use the actual
review paths and refuse to overwrite raw logs. A future independent replay
should use a new output/evidence location and the same pinned original
verifier command from `REGISTRY.md`; do not erase this completed run.

`source_tree_clean: false` in the preserved original report is expected:
the two unrelated PR114 README edits were retained. The 25 selected source
and metadata paths were clean and exactly committed. The current packet
does not convert that limited identity conclusion into a repository-wide
cleanliness or verification claim.

The archive worker may consume these frozen receipts and raw artifacts
without running Lean again. Earlier author attempts and older PR114
archives remain separate evidence; no author run is substituted for this
independent canonical execution.
