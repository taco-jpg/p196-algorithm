import Agent101AllWidthMaximum
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
#check Agent101.reverse_wrapDigits
#check Agent101.exists_coefficientWord_of_reverse
#check Agent101.coefficientWord_half_length
#check Agent101.digitFn_coefficientWord_cons_zero
#check Agent101.digitPairSums_reverse
#check Agent101.digitPairSums_profile
#check Agent101.digitPairSums_profile_cons
#check Agent101.mem_numericFiber_of_same_width_step
#check Agent101.fixed_width_profile_length_le
#check Agent101.profileCount_cons_outer_le
#check Agent101.fixed_width_preimages_outer_bound
#check Agent101.fixed_width_preimages_bound
#check Agent101.one_digit_preimages_bound
#check Agent101.MaximumWitnesses.maximumHalf
#check Agent101.MaximumWitnesses.maximumCenter
#check Agent101.MaximumWitnesses.maximumWord
#check Agent101.MaximumWitnesses.maximumTarget
#check Agent101.MaximumWitnesses.maximumPreimages
#check Agent101.MaximumWitnesses.maximumHalf_cons
#check Agent101.MaximumWitnesses.length_maximumWord
#check Agent101.MaximumWitnesses.maximumWord_bounded
#check Agent101.MaximumWitnesses.maximumWord_canonical
#check Agent101.MaximumWitnesses.maximumWord_units
#check Agent101.MaximumWitnesses.maximumTarget_width
#check Agent101.MaximumWitnesses.maximumCenter_count
#check Agent101.MaximumWitnesses.maximumPreimages_nodup
#check Agent101.MaximumWitnesses.length_maximumPreimages
#check Agent101.MaximumWitnesses.mem_maximumPreimages_fixed
#check Agent101.MaximumWitnesses.maximumPreimages_nonempty
#check Agent101.MaximumWitnesses.mem_maximumPreimages
#check Agent101.MaximumWitnesses.all_width_maximum_witness
#check Agent101.MaximumWitnesses.one_digit_preimages
#check Agent101.MaximumWitnesses.one_digit_maximum_witness
#check Agent101.Maximum.predecessor_width_cases
#check Agent101.Maximum.predecessor_one_digit_width
#check Agent101.Maximum.width_bound_mono
#check Agent101.Maximum.two_width_bound_arithmetic
#check Agent101.Maximum.all_width_preimages_bound
#check Agent101.Maximum.one_digit_target_preimages_bound
#check Agent101.Maximum.all_width_inverse_maximum
#check Agent101.Maximum.one_digit_inverse_maximum
run_cmd do
  let env ← getEnv
  let selected : List String := ["Lychrel196Research", "Agent101DigitPairs", "Agent101MultiplicityBounds", "Agent101SplitEnumeration", "Agent101NumericFibers", "Agent105WidthSupport9df76b", "Agent105CrossWidth9df76b", "Agent101PalindromeFibers", "Agent101NonpalindromicFibers", "Agent101ProfileExtraction", "PeriodObstructions", "Agent2OverflowActual", "Agent2OverflowLocal", "Agent2OverflowBound", "Agent101WidthFiberBounds", "Agent101MaximumWitnesses", "Agent101AllWidthMaximum"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut count := 0
  let mut union : List Name := []
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        match info with
        | .axiomInfo v =>
          if v.isUnsafe then logInfo m!"UNSAFE_IMPLEMENTATION_AXIOM {mod} {name}"
          else throwError m!"CUSTOM_AXIOM {mod} {name}"
        | .thmInfo _ =>
          count := count + 1
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          for ax in axl do
            if !(union.contains ax) then union := ax :: union
          if axl.any (fun ax => !(allowed.contains ax)) then throwError m!"DISALLOWED_AXIOMS {mod} {name} : {axl}"
          logInfo m!"AUDIT_THEOREM {mod} {name} : {axl}"
        | _ => pure ()
  logInfo m!"FULL_MODULE_AUDIT theorems={count} union={union}"
