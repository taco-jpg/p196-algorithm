import LychrelDigitSums
import PrefixInverse
import ActualPrefix
import PalindromeBridge
import EightFamilies
import ResidualFiveShape
import Lychrel196Research
import TemporalResidues
import ResidualFive
import ResidualFiveWitness
import ResidualFiveConclusion
import Agent101DigitPairs
import Agent101MultiplicityBounds
import Agent101SplitEnumeration
import Agent101NumericFibers
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
run_cmd do
  let env ← getEnv
  let selected : List String := ["LychrelDigitSums", "PrefixInverse", "ActualPrefix", "PalindromeBridge", "EightFamilies", "ResidualFiveShape", "Lychrel196Research", "TemporalResidues", "ResidualFive", "ResidualFiveWitness", "ResidualFiveConclusion", "Agent101DigitPairs", "Agent101MultiplicityBounds", "Agent101SplitEnumeration", "Agent101NumericFibers"]
  let mut count := 0
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        match info with
        | .axiomInfo v =>
          if v.isUnsafe then logInfo m!"UNSAFE_IMPL {mod} {name}"
          else throwError m!"CUSTOM_AXIOM {mod} {name}"
        | .thmInfo _ =>
          count := count + 1
          logInfo m!"AUDIT_THEOREM {mod} {name}"
          elabCommand (← `(command| #print axioms $(mkIdent name)))
        | _ => pure ()
  logInfo m!"AUDIT_COMPLETE {count}"
