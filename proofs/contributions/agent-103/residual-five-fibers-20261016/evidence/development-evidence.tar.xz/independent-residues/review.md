# ResidualFiveResidues：非作者独立审核

审核者：Agent #103 / scope_scan。原作者：Agent #103 / source_audit。

**审核结论：PASS。逐项语义审核与独立新目录 Lean 4.19 编译均通过，未发现遗漏或假设收窄。**

冻结源码 SHA256：`cbe3e496b3bfd62dfa14a2b9a6edfb13ea418073264c65d481056bc0f243cf01`。

## 审核对象与原始语义

`rawNine r` 直接定义为原 Agent101 的 `rawWords (List.replicate r 9) none`；`rawCount r t` 直接对该完整列表用原 `natValue` 的模11值调用 `List.countP`。没有改为新状态机、抽象可达关系或假设性的递推数列。

已读取 Agent101 exact commit `326645944168ad2b035a1e653b61527d79684156` 的原始 `pairChoices`、`wrapDigits`、`rawWords`、`centerWords`、`digitFn`、`natValue` 及 `mem_rawWords`、`length_rawWords` 接口。`rawWords` 允许内部片段最高位为0，这与后续再包外两对数位的用法一致；本模块没有加入原枚举没有的 canonical 限制。

## 审核要点

1. **数值方向与负号。** 原列表按个位在前排列，所以 `natValue (wrapDigits a b ds) = a + 10*natValue ds + b*10^(ds.length+1)` 正确。长度为2r时，最高指数2r+1为奇数；模11公式保留 `10*(natValue ds %11)` 与 `10*b`，即保留旧值和高位数的负号。它没有错误简化为旧余数不变。
2. **有限数位对列表完整。** `pairChoices_nine` 用内核 `decide` 验证原定义恰为 `(0,9)` 至 `(9,0)` 的10个有序对；这里使用 `outer=false`，没有误排除 `(9,0)`。
3. **有限余数组合覆盖。** `pair_nine_residue_census` 对两个完整的 `Fin 11` 量化，共121个余数组合。旧余数用 `natValue ds %11` 和 `Nat.mod_lt` 构造，目标余数用声明中的 `t<11` 构造；没有漏掉任何合法模11类。其条件 `k = (10*t)%11` 正是 `t=-k` 的等价形式。对固定旧余数，10个有序对恰覆盖除负旧余数外的全部新余数，各一次。
4. **从单词到完整列表。** `count_grid_cons` 用列表归纳拆分矩形枚举，保留每个输入单词在所有有序对中的全部出现次数。`wrapped_nine_count_complement` 再对输入单词列表归纳，每个单词的目标类计数与其“缺失类”指示值之和为1。无需并未使用去重假设，因此不会把带重数计数悄悄改为集合计数。
5. **实际 rawCount 全参数递推。** `rawNine_succ` 是原 `rawWords` 定义的展开；长度条件来自原 `mem_rawWords`，总词数来自原 `length_rawWords`。由此得到对每个自然数 r、每个 t<11：`rawCount (r+1) t + rawCount r ((10*t)%11) = 10^r`。这里的 r 没有任何有限上界。
6. **非零类均匀性没有遗漏。** 基例 r=0 的原列表只有空列表，其值为0，故每个非零类计数为0。归纳中负余数映射在1..10中闭合，由 `negative_residue_nonzero : ∀ t : Fin 11, t.val≠0 → (10*t.val)%11≠0` 内核核验；比较 t 的补集类与1的补集类10，再以自然数加法消去相同项。证明适用于全部10个非零类，并没有假设某个符号或大小子区间。
7. **两个简化递推。** 零类满足 `rawCount (r+1) 0 + rawCount r 0 = 10^r`；任一非零类的共同计数可用类1表示，满足 `rawCount (r+1) 1 + rawCount r 1 = 10^r`。两者都来自第5项实际列表递推，非抽象定义。

## 独立编译与公理核验

在此前不存在的新目录 `independent-build/` 复制了作者确认的冻结源码，使用 Lean 4.19 的 `--trust=0 -j1 -DElab.async=false` 只重编此模块，实际退出码0。复用依赖的位置和源码/对象哈希均记录在 `independent-build/manifest.json`；最终全闭包清洁构建由 runtime 专员负责。

22个显式导出全部逐项打印公理，其中20个定理、2个定义：8项无需公理；7项仅依赖 propext、Quot.sound；7项依赖 propext、Classical.choice、Quot.sound。没有 warning、error 或 sorryAx。有限121格 census 本身不依赖任何公理。

本模块证明的是原 rawWords 的模11分布和递推。它没有单独声称模99=77的实际 fiber 筛选计数已获得闭式；那是后续 bridge/count 模块的明确组合义务。
