# Agent #103 只读研究地图：196 前缀与残余稀疏回文族

基线：`main=4b4edf976b2c7a9ba1dad80636c0e21c66350325`。当前源码根为 `/workspace/scratch/a1d46b1077ac/agent103-runtime/current-repo`。原布局快照为 `/tmp/p196-original-layout-8dl2u_sq/repo`。远端认领读到父代理提供的 `current-claims.json`，coordination head `e71729edf505923884afab6a35e43bd4a18d5b6b`；147条评论缓存及额外最新评论由父代理统一管理。

## 结论与最重要纠正

**不能把218、217、777或eight-family当作新缺口。** 当前 `FINDINGS.md` 的旧表只提升了739，但 `proofs/archive/versions` 另外保存后续分支的认领和源码。仅查 `SOURCE_MAP.json` 不够：该表主要映射原mainline baseline，并不覆盖所有后来从分支保存的版本。

* Agent118 已完成 `Agent118.Finite218.ancestry_bound34` 与 `no_196_218_palindrome`；同一认领包含777和217。
* Agent119 已发布八个稀疏回文族的 `orbit196_ne_fam` 开发构建，明确不包含 `d=5`。
* Agent104另有620认领；Agent119负责229个四列基线类，Agent124负责33个五/六列基线类及四位细分类，Agent117负责剩余三位类的循环诊断和进一步七列四位类。

未开始任何新Lean证明、未改原源码、未评论issue、未写Git。以下候选须由父代理再核对实时远端后认领。

## 优先候选1：d=5残余族的实际196前驱与时刻必要条件

### 精确目标

令 `P5 r = 55 * (10^(2*r+2)+1)`。证明若 `orbit 196 t = P5 r`，则：

1. `t % 6 = 3`。
2. `orbit 196 (t-1) = 33 * 10^(2*r+2) + 22`。
3. `orbit 196 (t-2)` 的完整镜像对和字为 `[2,12] ++ replicate (2*r) 9 ++ [12,2]`，宽度 `2*r+4`。
4. 最后两次reverse-add均不增位；具体 `t≥5` 或更强下界必须由现有有限轨道检查推出，避免Nat减法边界。

这属于书面定理的Lean形式化，不是排除d=5，也不声称新数学发现。它直接约束196可能到达的未解决回文族，比重复已完成的模3不变量更有内容。

### 原始依据与依赖

原布局 `proofs/chat-6acee928/originals/p196_all_palindromes_and_eight_families.md` 第4节，式(20)、(21)给出上述前驱和对和形状，并指出 `t≡3 (mod 6)`。在第3节中，增位后不增位的支路用模11排除，不能默默假定两步均不增位。

可以直接复用当前这些原语：

* `proofs/PalindromeBridge__c6bbb7ab7e8b1c29.lean`：`SevenColumnKernel.PalindromeBridge.canonical_last_step`、`numeric_last_step`、`canonical_unique`。它们从真实canonical数位与末项回文推出末步同宽及零进位。
* `proofs/ActualPrefix__787f92e1c3116646.lean`：实际镜像对和到无进位/增位折叠关系的接口。
* `proofs/PrefixInverse__d258d04cb6f2792b.lean`：完整前驱列方程。
* `proofs/LychrelDigitSums__75febdc48f0ca802.lean`：`Lychrel196.step_mod9`，`AstraModular.step_preserves_dvd11`、`orbit_preserves_dvd11`，`DecimalDigits.Canonical`、`FoldedDecimal.Admissible`，`Lychrel196.no_palindrome_through_100`。
* Agent423现有 `TemporalResidues` 模块已证明mod99六周期及196精确phase表，source checkpoint `6b4cd0c9863b384babdc1daeed3f77cd41d6987a`。此源码不在当前本地选定平铺文件中；若需要，可由父代理从 `proofs/coordination/submissions/agent423/` 恢复并核对。
* Agent119八族源码checkpoint `1d542eb5b3d18785f00b303a7577459969e949e6`：`fam_canonical`、`last_step_no_overflow`、`middle_overflow` 等应能减少重复。当前本地Git不存在该对象，且只找到认领记录，不能声称已阅读源码本身。

### 第一步和撞车风险

先恢复Agent119精确源码，核对其 `middle_overflow` 是否已经对任意d给出了需要的否定支路，然后只认领d=5结构推论及数值桥。父代理提供的全部当前任务以及历史task内容扫描没有发现d=5认领；Agent119 task明确写 `d=5 ... not claimed`。Agent315/423已经拥有mod3/mod99基本结论，应引用其结果而不重复声称拥有。Agent101拥有一般数字拆分计数，本候选只做该具体目标的必要前驱结构，应在claim内明确。

## 候选2：完整回文的两步非回文前驱充要判据

### 精确目标

对任意正回文P，形式化

`(∃ n > 0, ¬ Palindrome (step n) ∧ orbit n 2 = P)`

当且仅当以下至少一个成立：

* `11 ∣ P`，`Palindrome (P/11)`，且P不在例外集 `{22,44,66,88,242} ∪ {22*(10^(2*r+2)+1) | r : Nat}`；
* P含奇数数位，且其折叠数位通过书面四状态判定器（包括首位不能为1，偶宽接合状态00/11，奇宽中心偶数及其进位奇偶条件）。

精确书面依据同上第2节。Agent119的八族认领只取该论证的具体族分支；现有扫描未发现完整“所有回文两步前驱iff”的认领或Lean端点。不过无溢出四状态局部算术与Agent9/7计数路线相邻，认领前必须说明复用接口，不重复计数或任意整数拆分枚举。

第一阶段可先形式化全偶数数位回文的简化iff，随后再补四状态分支。风险在于原文充分性要构造真实正整数，并处理奇数中心；仅有pair-word存在不能省略realizability桥。

## 候选3：剩余d=5族的模99反例证书

形式化原文第4节的六步有限轨道：

`71647625487907287180977453773517`

从模99余11起步，六次reverse-add首次到达 `55*(10^32+1)`，中间模99序列为 `22,44,88,77,55,11`。该证书证明“与196晚期相同的模99周期”不足以排除残余d=5族。它与候选1可组合为一个研究包的精确限制证据，不宜单独夸大为重大新理论。用现有 `Lychrel196.step/orbit/Palindrome` 和逐步kernel数值等式即可；不需要native_decide，不涉及大表或新数论公理。

未找到该精确种子的Lean声明。全文书面轨道已给出全部七个整数；应保持r=15和六步量词，不能从一条轨道推断任意r的可达性。

## 218既有证书：交接信息及为何不能重做

### 数据

原布局路径：`proofs/contributions/2026-10-15-seven-column-prefix/certificate_218.json`。

当前保留路径：

`proofs/archive/source-trees/2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5/proofs/contributions/2026-10-15-seven-column-prefix/certificate_218.json`

SHA256 `b1945d1f67ad76549c5496ba24b935386d476ea9bc99460eceed718abc384dd6`，1,552,267字节，38,587节点、38,799边，初始最大rank33，回文祖先深度界34。34包含全部短宽。

短初始状态是 `[2,1,8,1,2]`（宽5）与 `[2,1,8,8,1,2]`（宽6）。短节点共有三个：

| word | rank |
|---|---:|
| `[1,0,14,0,1]` | 0 |
| `[2,1,8,1,2]` | 1 |
| `[2,1,8,8,1,2]` | 0 |

独立读取原Python正向函数并枚举全部10467个短源，得到唯一入树短边 `[1,0,14,0,1] → [2,1,8,1,2]`。这是诊断，不是新的Lean证明。它说明739旧的“所有短源的像都不入树”假设不能用于218；Agent118已经证明正确的 `ShortDescent` 泛化。

### 实际已完成源

* `proofs/archive/versions/9e7e14e1da94ea05eb979518a764d449536e0345dcf96140a99d45df1234311d/proofs/contributions/agent-118/prefix-kernel/PrefixAncestry.lean`
  * `Agent118.PrefixKernel.shortDescentOK`、`ShortDescent`、`actual_iterPairs_rank_desc`
  * `short_target_mem`、`target_project_mem_initialWords`、`canonical_last_step_initial`
  * `ancestry_bound_of_finite_checks`、`no_196_of_finite_checks`
* `proofs/archive/versions/ab034017b3cf5b6dcd5fe4638b5c6d04bccd8aae75f37ab17eb50c4c38dc2bc6/proofs/contributions/agent-118/prefix-kernel/cert218/Conclusion218.lean`
  * `Agent118.Finite218.ancestry_bound34`
  * `Agent118.Finite218.no_196_218_palindrome`
  * `Agent118.Finite218.no_196_218_palindrome_unfolded`
* 同一模块的记录日志位于 `proofs/archive/versions/f7f6ca599d60bbbc4c68bc1f4a130fb51911ffacc407fdb1cfd87da757627743/proofs/contributions/agent-118/prefix-kernel/logs/dev218/Conclusion218.log`，三个endpoint的axioms只有propext/Classical.choice/Quot.sound。
* 完成范围记录：`proofs/archive/versions/bc36e2b4449ee104c4292c8dd4c6017d940733ec9042b1c178ded45b911a9460/proofs/coordination/tasks/agent118-prefix-kernel-218-777-217.json`。source9e618cc，167模块全新编译，6336定理审计；后续source2fb5b00生成777/217。

因此独立恢复并复核该包仍有工程价值，但属于非独占复核/可复现性恢复，不能认领为新的218形式化。

### 739复用组件映射

| 原布局模块 | 当前平铺路径 |
|---|---|
| LychrelDigitSums | `proofs/LychrelDigitSums__75febdc48f0ca802.lean` |
| ActualPrefix | `proofs/ActualPrefix__787f92e1c3116646.lean` |
| PrefixCertificate | `proofs/PrefixCertificate__e9b7977c16c1e5fb.lean` |
| PrefixInverse | `proofs/PrefixInverse__d258d04cb6f2792b.lean` |
| ShortBoundary | `proofs/ShortBoundary__e45721d7399affd9.lean` |
| LongRowsBase | `proofs/LongRowsBase__148bc418a5a3872f.lean` |
| PalindromeBridge | `proofs/PalindromeBridge__c6bbb7ab7e8b1c29.lean` |
| ActualAncestry | `proofs/ActualAncestry__600f7f4c7a310d35.lean` |
| FastRowsBase | `proofs/FastRowsBase__ac528c32cc5c23d9.lean` |
| FastInverse | `proofs/FastInverse__21d46f14cdb6a0d2.lean` |
| Initial739Base | `proofs/Initial739Base__57d122278ae39c5f.lean` |
| ShortChecksBase | `proofs/ShortChecksBase__76a7b1acbee88666.lean` |
| generate_rank739.py | `proofs/generate_rank739__df7f36f3b9d711fd.py` |
| generate_checks739.py | `proofs/generate_checks739__afa65bdf9b1922ec.py` |
| generate_short_checks.py | `proofs/generate_short_checks__061332a4eabb1076.py` |
| split_row_batches.py | `proofs/split_row_batches__a5d75790a6f86d97.py` |
| check.py | `proofs/check__ce84e3608e662235.py` |

生成器的原策略是RankTree数据的64节点leaf分块、每批4个leaf和branch行、初始10000个free-digit条目按100分块，全部 `decide +kernel`。`lookup` 检查实际word，不相信pivot编码或树排序；`CheckedRows` 检查完整Lean前驱枚举，不只检查Python提供的边。739已有完整纯内核证据，不存在这里需要替换的native_decide。

