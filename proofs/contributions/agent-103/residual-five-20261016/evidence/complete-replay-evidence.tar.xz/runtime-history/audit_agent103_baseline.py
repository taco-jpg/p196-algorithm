#!/usr/bin/env python3
"""Supplement the unchanged Agent119 checker with all seven project-module theorem audits."""
import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import time
import traceback

WORK = Path("/workspace/scratch/a1d46b1077ac/agent103-work")
BASE = WORK / "baseline"
SNAP = BASE / "evidence/snapshot"
OUT = BASE / "full-dependency-audit"
LEAN = "/workspace/scratch/a1d46b1077ac/agent103-runtime/toolchain/lean-4.19.0-linux/bin/lean"
MODULES = ["LychrelDigitSums", "PrefixInverse", "ActualPrefix", "PalindromeBridge",
           "EightFamilies", "Lychrel196Research", "TemporalResidues"]
ENV = {"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8", "TZ": "UTC", "LEAN_PATH": str(SNAP)}
OUT.mkdir(exist_ok=False)
spec = importlib.util.spec_from_file_location("agent103_check", WORK / "check.py")
driver = importlib.util.module_from_spec(spec)
spec.loader.exec_module(driver)
report = {"status": "RUNNING", "modules": MODULES, "driver_sha256": driver.file_sha(WORK / "check.py"),
          "scope": "Supplemental audit of every theorem constant from the freshly rebuilt seven-module dependency closure."}
def save():
    (OUT / "verification.json").write_text(json.dumps(report, indent=2) + "\n")
try:
    original = json.loads((BASE / "evidence/verification.json").read_text())
    temporal = json.loads((BASE / "provenance/temporal/build.json").read_text())
    assert original["status"] == "PASS" and temporal["status"] == "PASS"
    pins = {m: r["sha256"] for m, r in original["sources"].items()}
    pins.update({m: r["source_sha256"] for m, r in temporal["sources"].items()})
    for m in MODULES:
        assert driver.file_sha(SNAP / (m + ".lean")) == pins[m]
        driver.imports_of((SNAP / (m + ".lean")).read_bytes())
    report["source_sha256"] = pins
    report["object_sha256"] = {m: driver.file_sha(SNAP / (m + ".olean")) for m in MODULES}
    audit = SNAP / "AuditAllBaselineModules.lean"
    audit.write_text(driver.audit_source(MODULES))
    (OUT / audit.name).write_bytes(audit.read_bytes())
    argv = [LEAN, "-j1", "-DElab.async=false", audit.name]
    log = OUT / "audit.log"
    start = time.monotonic()
    with log.open("w") as stream:
        result = subprocess.run(argv, cwd=SNAP, env=ENV, stdout=stream, stderr=subprocess.STDOUT, timeout=1800)
    report["command"] = {"argv": argv, "cwd": str(SNAP), "environment": ENV, "exit_code": result.returncode,
                         "seconds": round(time.monotonic() - start, 3), "log": str(log),
                         "log_sha256": driver.file_sha(log), "audit_source_sha256": driver.file_sha(audit)}
    if result.returncode:
        raise RuntimeError("Full baseline audit Lean invocation failed")
    report.update(driver.parse_audit(log.read_text(), MODULES))
    for m in MODULES:
        assert driver.file_sha(SNAP / (m + ".lean")) == pins[m]
        assert driver.file_sha(SNAP / (m + ".olean")) == report["object_sha256"][m]
    report.update(status="PASS", all_source_and_object_hashes_unchanged=True)
    print(json.dumps({k: report[k] for k in ["status", "theorem_count", "module_theorem_counts", "axiom_union"]}), flush=True)
except Exception as error:
    report.update(status="FAIL", error=str(error))
    (OUT / "failure.txt").write_text(traceback.format_exc())
    raise
finally:
    save()
