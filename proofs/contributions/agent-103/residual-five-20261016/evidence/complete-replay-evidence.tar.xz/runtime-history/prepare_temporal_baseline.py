#!/usr/bin/env python3
"""Verify the original foundation is byte-contained before creating the approved import forwarding module."""
import hashlib
import json
from pathlib import Path
import subprocess
import time

REPO = Path("/workspace/scratch/a1d46b1077ac/agent103-runtime/current-repo")
BASE = Path("/workspace/scratch/a1d46b1077ac/agent103-work/baseline")
SNAP = BASE / "evidence/snapshot"
REF = "6fae6e659e5c08c59666588c71a4ed06760de85e"
PATH = "proofs/coordination/submissions/agent423/TemporalResidues.lean"
FOUNDATION = "c6c1f5441c54a36f2d82b3ef78dff1ccdbc5a506"
ENV = {"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8",
       "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_TERMINAL_PROMPT": "0"}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()

def read_blob(spec):
    return subprocess.run(["git", "-C", str(REPO), "cat-file", "blob", spec],
                          env=ENV, capture_output=True, check=True).stdout

target = BASE / "provenance/temporal"
target.mkdir(exist_ok=False)
report = {"status": "VERIFYING", "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
try:
    temporal = read_blob(REF + ":" + PATH)
    original = read_blob(FOUNDATION)
    container = (SNAP / "LychrelDigitSums.lean").read_bytes()
    if blob(temporal) != "93dec0e8bb09dc8deaa5766214d3e02ca758db4c" or sha(temporal) != "f3a215bb9ee54628e83d0591bff2ed7f73980821931d56de99f0b3da5d4ab8ab":
        raise ValueError("TemporalResidues source pin mismatch")
    if blob(original) != FOUNDATION or sha(original) != "f8950d138fa4231b536059e2334d36b6496de3d25a806f4cf3925941aa05144c":
        raise ValueError("Original foundation source pin mismatch")
    if sha(container) != "ca5f46523b7cff02c00918b6466a97963087b499fb5f184232b8b3d806dc0b57":
        raise ValueError("LychrelDigitSums source pin mismatch")
    if not original.startswith(b"import Std\n") or not container.startswith(b"import Std\n"):
        raise ValueError("Expected exact import Std header")
    body = original[len(b"import Std\n"):]
    offset = container.find(body)
    if offset < 0 or container.find(body, offset + 1) >= 0:
        raise ValueError("Original foundation body is absent or not uniquely contained")
    if not temporal.startswith(b"import Lychrel196Research\n"):
        raise ValueError("Unexpected original TemporalResidues import")
    adapter = b"import LychrelDigitSums\n"
    (target / "OriginalLychrel196Research.lean").write_bytes(original)
    (target / "TemporalResidues.original.lean").write_bytes(temporal)
    for name, data in [("Lychrel196Research.lean", adapter), ("TemporalResidues.lean", temporal)]:
        path = SNAP / name
        if path.exists():
            raise ValueError("Refusing to overwrite baseline module: " + name)
        path.write_bytes(data)
    report.update(
        status="BYTE_CONTAINMENT_VERIFIED",
        temporal={"ref": REF, "original_path": PATH, "git_blob": blob(temporal), "sha256": sha(temporal),
                  "snapshot_path": str(SNAP / "TemporalResidues.lean"), "source_unchanged": True},
        original_foundation={"git_blob": FOUNDATION, "sha256": sha(original), "bytes": len(original),
                             "preserved_path": str(target / "OriginalLychrel196Research.lean")},
        container={"module": "LychrelDigitSums", "sha256": sha(container),
                   "snapshot_path": str(SNAP / "LychrelDigitSums.lean")},
        containment={"excluded_exact_prefix_utf8": "import Std\n", "body_bytes": len(body),
                     "body_sha256": sha(body), "body_line_count": len(body.splitlines(keepends=True)),
                     "container_start_byte_0_based": offset,
                     "container_start_line_1_based": container[:offset].count(b"\n") + 1,
                     "complete_body_byte_identical": True, "unique_match": True},
        adapter={"kind": "verified_embedded_foundation_import_forwarder", "module": "Lychrel196Research",
                 "exact_utf8": adapter.decode(), "sha256": sha(adapter), "path": str(SNAP / "Lychrel196Research.lean"),
                 "authority": "Explicit parent task instruction for the TemporalResidues import compatibility step."},
    )
    print(json.dumps(report, indent=2), flush=True)
except Exception as error:
    report.update(status="FAIL", error=str(error))
    raise
finally:
    (target / "adapter-evidence.json").write_text(json.dumps(report, indent=2) + "\n")
