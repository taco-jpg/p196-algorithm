#!/usr/bin/env python3
import hashlib
import json
from pathlib import Path
import subprocess
import time

BASE = Path("/workspace/scratch/a1d46b1077ac/agent103-work/baseline")
SNAP = BASE / "evidence/snapshot"
LEAN = "/workspace/scratch/a1d46b1077ac/agent103-runtime/toolchain/lean-4.19.0-linux/bin/lean"
OUT = BASE / "provenance/temporal"
ENV = {"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8", "TZ": "UTC", "LEAN_PATH": str(SNAP)}
status = json.loads((BASE / "evidence/verification.json").read_text())
assert status["status"] == "PASS", "Original five-module checker has not passed"
adapter = json.loads((OUT / "adapter-evidence.json").read_text())
assert adapter["status"] == "BYTE_CONTAINMENT_VERIFIED"
report = {"status": "RUNNING", "commands": [], "sources": {}}
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
def save():
    (OUT / "build.json").write_text(json.dumps(report, indent=2) + "\n")
for name, pin in [("Lychrel196Research", adapter["adapter"]["sha256"]), ("TemporalResidues", adapter["temporal"]["sha256"])]:
    source = SNAP / (name + ".lean")
    assert sha(source) == pin, "Source pin changed"
    argv = [LEAN, "-j1", "-DElab.async=false", "-o", name + ".olean", name + ".lean"]
    log = OUT / (name + ".log")
    started = time.monotonic()
    with log.open("w") as stream:
        p = subprocess.run(argv, cwd=SNAP, env=ENV, stdout=stream, stderr=subprocess.STDOUT)
    report["commands"].append({"argv": argv, "cwd": str(SNAP), "environment": ENV, "exit_code": p.returncode,
                               "seconds": round(time.monotonic() - started, 3), "log": str(log), "log_sha256": sha(log)})
    if p.returncode:
        report.update(status="FAIL", failed_module=name); save()
        raise SystemExit(p.returncode)
    assert sha(source) == pin, "Source changed during compile"
    report["sources"][name] = {"source_sha256": pin, "olean_sha256": sha(SNAP / (name + ".olean"))}
    save()
    print(name, "exit=0", flush=True)
report["status"] = "PASS"
save()
print("PASS: exact forwarding module and unchanged TemporalResidues compiled", flush=True)
