#!/usr/bin/env python3
"""Restore the exact claimed Agent119 package and its four original dependencies."""
import ast
import hashlib
import json
from pathlib import Path
import subprocess
import time

REPO = Path("/workspace/scratch/a1d46b1077ac/agent103-runtime/current-repo")
DEPS = Path("/workspace/scratch/a1d46b1077ac/agent103-work/deps119")
BASE = Path("/workspace/scratch/a1d46b1077ac/agent103-work/baseline")
REF = "913441a936a437e5f4b82d03d7e7fae32da877af"
OWN = "proofs/contributions/agent-119/eight-families"
ENV = {"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8", "TZ": "UTC",
       "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_TERMINAL_PROMPT": "0"}

def sha(data):
    return hashlib.sha256(data).hexdigest()

def blob(data):
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()

def git(repo, *args):
    p = subprocess.run(["git", "-C", str(repo), *args], env=ENV, capture_output=True)
    if p.returncode:
        raise RuntimeError(p.stderr.decode("utf-8", "replace"))
    return p.stdout

resume = BASE.exists()
BASE.mkdir(parents=True, exist_ok=True)
(BASE / "provenance").mkdir(exist_ok=True)
if resume:
    previous = BASE / "provenance/restore.json"
    if previous.exists():
        (BASE / "provenance/restore-preparation-failed-001.json").write_bytes(previous.read_bytes())
report = {"status": "PREPARING", "ref": REF, "sources": {}, "commands": [],
          "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
def save():
    (BASE / "provenance" / "restore.json").write_text(json.dumps(report, indent=2) + "\n")

try:
    mapping_data = (REPO / "proofs/SOURCE_MAP.json").read_bytes()
    mapping = json.loads(mapping_data)
    report["source_map_sha256"] = sha(mapping_data)
    checker = git(REPO, "show", REF + ":" + OWN + "/check.py")
    if checker != (DEPS / "check.py").read_bytes():
        raise ValueError("Provided check.py does not match claimed Git ref")
    pins = None
    for statement in ast.parse(checker).body:
        if isinstance(statement, ast.Assign) and any(isinstance(t, ast.Name) and t.id == "REUSED" for t in statement.targets):
            pins = ast.literal_eval(statement.value)
    if pins is None or len(pins) != 4:
        raise ValueError("Expected original four-module REUSED pins")
    layout = BASE / "repo"
    command = ["git", "-c", "credential.helper=", "-c", "core.askpass=", "clone", "--shared", "--no-checkout", str(REPO), str(layout)]
    if not layout.exists():
        p = subprocess.run(command, env=ENV, capture_output=True, text=True)
        report["commands"].append({"argv": command, "exit_code": p.returncode, "stdout": p.stdout, "stderr": p.stderr})
        if p.returncode:
            raise RuntimeError("Local source-object clone failed")
    else:
        report["resumed_partial_local_clone"] = True
        if list(layout.glob("proofs/**/*.lean")):
            raise ValueError("Resume allowed only before any Lean source has been restored")
    git(layout, "fetch", "--update-shallow", "--no-tags", str(REPO), REF)
    report["commands"].append({"argv": ["git", "-C", str(layout), "fetch", "--update-shallow", "--no-tags", str(REPO), REF], "exit_code": 0})
    for args in [("update-ref", "--no-deref", "HEAD", REF), ("read-tree", REF)]:
        git(layout, *args)
        report["commands"].append({"argv": ["git", "-C", str(layout), *args], "exit_code": 0})
    inventory = {name: (path, pin) for name, (path, pin) in pins.items()}
    for file in ["EightFamilies.lean", "README.md", "check.py"]:
        inventory[file] = (OWN + "/" + file, None)
    for name, (original, required_sha) in inventory.items():
        original_bytes = git(REPO, "show", REF + ":" + original)
        original_blob = git(REPO, "rev-parse", REF + ":" + original).decode().strip()
        if blob(original_bytes) != original_blob:
            raise ValueError("Original Git blob check failed: " + original)
        if required_sha and sha(original_bytes) != required_sha:
            raise ValueError("Original dependency does not match check.py pin: " + original)
        entry = mapping["paths"].get(original)
        selected = None
        data = original_bytes
        if entry is not None:
            current = entry.get("current")
            if current:
                candidate = (REPO / current).read_bytes()
                if candidate != original_bytes or sha(candidate) != entry["sha256"] or blob(candidate) != entry["oid"]:
                    raise ValueError("Current SOURCE_MAP bytes do not match original ref: " + original)
                selected, data = current, candidate
        if original.startswith(OWN + "/") and (DEPS / Path(original).name).read_bytes() != original_bytes:
            raise ValueError("Provided Agent119 file does not match ref: " + original)
        destination = layout / original
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes(data)
        report["sources"][name] = {"original_path": original, "ref": REF, "git_blob": original_blob,
                                   "sha256": sha(data), "required_sha256": required_sha,
                                   "current_source_map_path": selected, "bytes": len(data),
                                   "restored_path": str(destination), "matches_original_git_bytes": True}
    if git(layout, "rev-parse", "HEAD").decode().strip() != REF:
        raise ValueError("Restored source metadata HEAD differs from the claimed ref")
    clean = subprocess.run(["git", "-C", str(layout), "diff", "--quiet", "HEAD", "--", OWN], env=ENV).returncode == 0
    if not clean:
        raise ValueError("Restored Agent119 package differs from original Git tree")
    report.update(status="READY", source_layout=str(layout), package_clean=True,
                  baseline_import_path=str(BASE / "evidence" / "snapshot"))
    print(json.dumps(report, indent=2), flush=True)
except Exception as error:
    report.update(status="FAIL", error=str(error))
    raise
finally:
    save()
