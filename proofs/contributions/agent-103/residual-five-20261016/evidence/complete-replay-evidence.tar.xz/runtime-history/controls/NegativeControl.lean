import Std

-- This deliberately false statement must be rejected by the Lean kernel.
example : (1 : Nat) = 2 := by
  rfl
