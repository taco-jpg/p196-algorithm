# Agent #103：Lean 4.19.0 运行环境恢复记录

本目录只记录运行环境恢复与最小验证，不包含新的 P196 数学结论。

## 可用路径

- Lean：`/workspace/scratch/a1d46b1077ac/agent103-runtime/toolchain/lean-4.19.0-linux/bin/lean`
- Lake：`/workspace/scratch/a1d46b1077ac/agent103-runtime/toolchain/lean-4.19.0-linux/bin/lake`
- 当前仓库只读基线：`/workspace/scratch/a1d46b1077ac/agent103-runtime/current-repo`
- 验证脚本：`/workspace/scratch/a1d46b1077ac/agent103-runtime/verify_runtime.py`

该环境中的普通沙箱执行 Lean 会报 `error: failed to locate application` 并退出 1。
使用 `exec_command` 的 `sandbox_permissions="require_escalated"` 正规受审执行路径后，
原始可执行文件直接启动成功。不需要运行时适配器或 `LD_PRELOAD`。

真实版本输出，退出码 0：

```text
Lean (version 4.19.0, x86_64-unknown-linux-gnu, commit 6caaee842e94, Release)
```

## 本次实际验证

通过上述受审执行路径运行：

```sh
python3 /workspace/scratch/a1d46b1077ac/agent103-runtime/verify_runtime.py
```

该脚本于 2026-10-16 21:01:25–21:01:26 UTC 完成，整体退出码为 0。
脚本给 Lean 子进程显式传入只含 PATH、LANG、TZ 的环境，不读取或输出凭据。

| 检查 | 结果 |
| --- | --- |
| Lean 版本 | 4.19.0，commit 6caaee842e94，退出 0 |
| Lake 版本 | 5.0.0-6caaee8，Lean 4.19.0，退出 0 |
| `Smoke.lean` 编译 | 退出 0，生成 `Smoke.olean` |
| `Agent103.RuntimeSmoke.reflexive` | 不依赖公理 |
| `Agent103.RuntimeSmoke.finiteArithmetic` | 不依赖公理 |
| `Agent103.RuntimeSmoke.cancellation` | 仅依赖 `propext`、`Quot.sound` |
| 错误证明 `1 = 2 := by rfl` | 按预期拒绝，退出 1 |

核心编译命令：

```sh
/workspace/scratch/a1d46b1077ac/agent103-runtime/toolchain/lean-4.19.0-linux/bin/lean \
  -j1 -DElab.async=false \
  -o /workspace/scratch/a1d46b1077ac/agent103-runtime/Smoke.olean \
  /workspace/scratch/a1d46b1077ac/agent103-runtime/Smoke.lean
```

`controls/NegativeControl.lean` 是专门保留的失败对照，不应加入成功构建集合。

## 恢复来源与完整性

本次从已有本地 Agent #101 checker 归档恢复；不是本轮重新下载完整官方发行包。

- 来源：`/workspace/scratch/2a8a87fd78df/agent101-runtime/lean-4.19.0-checker.tar.zst`
- 来源归档 SHA-256：`a3e6677802ece6e399e6d9bf4be475d7f4af37d0a629d44cca2d968ba7ec640a`
- 安全解压成功，1694 个成员，退出码 0。
- `bin/lean` SHA-256：`92c3d35b5bfaa5e0fea413a775d504cf46cd95e1345df61c2274f76779e7e023`
- `bin/lake` SHA-256：`5111aee5c9434ab05d4265606475ef22e8bda69aaf3a0657b61a7eec6e550bed`
- `libleanshared.so` SHA-256：`2ab605c74c78f9ba4431a7b5305a4b28a9071d8a826f223eb14fe5530f78e14d`

没有修改 Lean 二进制、Lean 内核、标准库或系统配置。

## 当前源码获取

公开仓库：`https://github.com/taco-jpg/p196-algorithm.git`

普通沙箱的 `git ls-remote` 因无法连接已配置代理退出 128；
经 `require_escalated` 受审执行后，禁用凭据助手和交互提示的只读访问成功。
之后执行了相同限制下的 `git clone --depth=1 --no-tags`，退出 0。

- 本轮读取并检出的 HEAD：`4b4edf976b2c7a9ba1dad80636c0e21c66350325`
- `git rev-parse HEAD`：退出 0，与上面的 HEAD 相同。
- `git status --porcelain`：退出 0，输出为空。
- 仓库根 `AGENTS.md` 已读取：当前源码在 `proofs`，历史在 `proofs/archive`；
  使用单一 canonical `main` 和单一 integration writer，其他研究用本地工作区与补丁。

本子任务未修改远端、未发布评论、未创建分支或提交、未设置 Git 身份。
本目录的 `current-repo` 作为只读源码基线使用，证明开发应放在单独工作目录。

## 证据文件

- `logs/restore.json`：恢复源、路径、时间、成员数与退出码。
- `logs/lean-version.json`：普通沙箱启动失败记录。
- `logs/lean-approved-version.json`：受审路径版本成功记录。
- `logs/lake-approved-version.json`：Lake 版本记录。
- `logs/smoke.json`：成功编译命令与完整 `#print axioms` 输出。
- `logs/negative-control.json`：失败对照命令与完整错误输出。
- `logs/runtime-verification.json`：检查结果与源码、二进制、产物 SHA-256。
- `logs/repository-access.json`：克隆参数、禁用凭据配置、退出码与 HEAD 验证。

这些检查只确认此运行环境可以执行 Lean 标准库证明并拒绝错误证明。
具体 P196 源码仍应从固定版本重新编译并审计其所有目标定理。
