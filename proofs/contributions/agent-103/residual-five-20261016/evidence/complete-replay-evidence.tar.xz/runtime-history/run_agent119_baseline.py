#!/usr/bin/env python3
"""Run the unchanged Agent119 checker with a minimal, credential-free environment."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

BASE = Path("/workspace/scratch/a1d46b1077ac/agent103-work/baseline")
CHECK = BASE / "repo/proofs/contributions/agent-119/eight-families/check.py"
LEAN = "/workspace/scratch/a1d46b1077ac/agent103-runtime/toolchain/lean-4.19.0-linux/bin/lean"
ENV = {"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8", "TZ": "UTC",
       "GIT_CONFIG_NOSYSTEM": "1", "GIT_CONFIG_GLOBAL": "/dev/null", "GIT_TERMINAL_PROMPT": "0"}
argv = [sys.executable, str(CHECK), LEAN, "--evidence", str(BASE / "evidence"), "--jobs", "2"]
record = {"argv": argv, "environment": ENV, "cwd": str(BASE),
          "check_sha256": hashlib.sha256(CHECK.read_bytes()).hexdigest(),
          "started_utc": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())}
log = BASE / "provenance/original-check.log"
with log.open("w") as stream:
    proc = subprocess.Popen(argv, cwd=BASE, env=ENV, text=True, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    for line in proc.stdout:
        stream.write(line); stream.flush()
        print(line, end="", flush=True)
    code = proc.wait()
record.update(exit_code=code, log=str(log), log_sha256=hashlib.sha256(log.read_bytes()).hexdigest(),
              finished_utc=time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()),
              checker_unchanged=record["check_sha256"] == hashlib.sha256(CHECK.read_bytes()).hexdigest())
(BASE / "provenance/original-check-command.json").write_text(json.dumps(record, indent=2) + "\n")
raise SystemExit(code)
