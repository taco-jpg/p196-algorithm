#!/usr/bin/env python3
"""Agent #103 local helper: build only an exact, source-pinned Lean import closure.

No remote writes, old-layout checkout, project object reuse, or source rewriting.
Use --plan-only for source/import checks without claiming a Lean verification.
"""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path, PurePosixPath
import re
import subprocess
import sys
import time
import traceback


NAME = re.compile(r"[A-Za-z_][\w']*(?:\.[A-Za-z_][\w']*)*\Z", re.ASCII)
IDENT = re.compile(r"[A-Za-z_][\w']*(?:\.[A-Za-z_][\w']*)*", re.ASCII)
FORBIDDEN = re.compile(r"(?<![\w'])\b(?:sorry|admit|axiom|sorryAx|native_decide|ofReduceBool|skipKernelTC)\b(?![\w'])")
BUILTIN = {"Init", "Std", "Lean", "Lake"}
ALLOWED_AXIOMS = {"propext", "Classical.choice", "Quot.sound"}
BASE_ENV = {"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8", "TZ": "UTC"}
GIT_ENV = dict(BASE_ENV, GIT_CONFIG_NOSYSTEM="1", GIT_CONFIG_GLOBAL="/dev/null", GIT_TERMINAL_PROMPT="0")
PARSER_REFERENCE = "https://github.com/leanprover/lean4/blob/v4.19.0/src/Lean/Parser/Module.lean"
SCANNER_REFERENCE = {
    "path": "proofs/verify_project__214bf7673efe116b.py",
    "sha256": "c047ff1ff1fe12b2c2094ca5f36af871b1c6faf89db593a102f9c2f7d48cc98a",
    "method": "Nested comment/string masking adapted from the inspected code_only function.",
}


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def blob(data: bytes) -> str:
    return hashlib.sha1(f"blob {len(data)}\0".encode() + data).hexdigest()


def now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def checked_name(value: str) -> str:
    if not NAME.fullmatch(value):
        raise ValueError(f"Unsupported module/declaration name: {value!r}")
    return value


def relative(value: str) -> str:
    p = PurePosixPath(value)
    if p.is_absolute() or not p.parts or any(x in {".git", ".."} for x in p.parts) or "\\" in value:
        raise ValueError(f"Unsafe repository-relative path: {value!r}")
    return str(p)


def regular(path: Path, root: Path | None = None) -> bytes:
    if path.is_symlink():
        raise ValueError(f"Source is a symbolic link: {path}")
    if root is not None:
        if not path.resolve().is_relative_to(root):
            raise ValueError(f"Source escapes repository: {path}")
        for ancestor in path.parents:
            if ancestor == root:
                break
            if ancestor.is_symlink():
                raise ValueError(f"Source ancestor is a symbolic link: {ancestor}")
    return path.read_bytes()


def code_only(text: str) -> str:
    """Mask nested comments and strings, preserving token boundaries/newlines."""
    out, i, depth, string = [], 0, 0, False
    while i < len(text):
        pair = text[i:i + 2]
        if depth:
            if pair == "/-":
                depth += 1; out.extend("  "); i += 2
            elif pair == "-/":
                depth -= 1; out.extend("  "); i += 2
            else:
                out.append("\n" if text[i] == "\n" else " "); i += 1
        elif string:
            if text[i] == "\\":
                out.extend("  "); i += 2
            else:
                string = text[i] != '"'
                out.append("\n" if text[i] == "\n" else " "); i += 1
        elif pair == "/-":
            depth = 1; out.extend("  "); i += 2
        elif pair == "--":
            end = text.find("\n", i)
            end = len(text) if end < 0 else end
            out.extend(" " * (end - i)); i = end
        elif text[i] == '"':
            string = True; out.append(" "); i += 1
        else:
            out.append(text[i]); i += 1
    if depth or string:
        raise ValueError("Unterminated Lean comment or string")
    return "".join(out)


def imports_from(data: bytes) -> tuple[list[str], bool]:
    """Lean 4.19 header: optional prelude, then import [runtime] identifier."""
    text = code_only(data.decode("utf-8"))
    bad = FORBIDDEN.search(text)
    if bad:
        raise ValueError(f"Forbidden source token: {bad.group()}")
    p, imports, prelude = 0, [], False

    def skip(i: int) -> int:
        while i < len(text) and text[i].isspace():
            i += 1
        return i

    def keyword(word: str, i: int) -> bool:
        return re.match(re.escape(word) + r"(?![\w'.])", text[i:]) is not None

    p = skip(p)
    if keyword("prelude", p):
        prelude = True
        p = skip(p + len("prelude"))
    while keyword("import", p):
        p += len("import")
        if p >= len(text) or not text[p].isspace():
            raise ValueError("Unsupported Lean import header")
        p = skip(p)
        if keyword("runtime", p):
            raise ValueError("Runtime-only imports are outside this exact-source helper")
        match = IDENT.match(text, p)
        if not match:
            raise ValueError("Unsupported or incomplete import module identifier")
        name = checked_name(match.group())
        p = match.end()
        if p < len(text) and not text[p].isspace():
            raise ValueError(f"Unsupported import suffix after {name}")
        imports.append(name)
        p = skip(p)
    return imports, prelude


class Resolver:
    def __init__(self, repo: Path, expected_head: str):
        self.repo = repo
        self.head = self.git("rev-parse", "HEAD").decode().strip()
        if self.head != expected_head:
            raise ValueError(f"HEAD mismatch: expected {expected_head}, found {self.head}")
        self.tree = {}
        for entry in self.git("ls-tree", "-r", "-z", "--full-tree", "HEAD").split(b"\0"):
            if entry:
                info, name = entry.split(b"\t", 1)
                mode, kind, oid = info.decode().split()
                self.tree[name.decode()] = (mode, kind, oid)
        self.map_path = repo / "proofs/SOURCE_MAP.json"
        self.map_data = regular(self.map_path, repo)
        self.check_head("proofs/SOURCE_MAP.json", self.map_data)
        self.mapping = json.loads(self.map_data)
        self.paths = self.mapping["paths"]
        self.reverse = {}
        for old, entry in self.paths.items():
            relative(old)
            for key in ("current", "preserved"):
                if entry.get(key):
                    self.reverse.setdefault(relative(entry[key]), set()).add(old)

    def git(self, *args: str) -> bytes:
        p = subprocess.run(["git", "-C", str(self.repo), *args], env=GIT_ENV, capture_output=True)
        if p.returncode:
            raise RuntimeError(p.stderr.decode("utf-8", "replace"))
        return p.stdout

    def check_head(self, path: str, data: bytes) -> str:
        spec = self.tree.get(path)
        actual = blob(data)
        if spec is None or spec[0] not in {"100644", "100755"} or spec[1] != "blob" or spec[2] != actual:
            raise ValueError(f"Source does not match the captured Git HEAD: {path}")
        return actual

    def source(self, selector: str, optional: bool = False) -> tuple[bytes, dict] | None:
        path = Path(selector)
        if path.is_absolute():
            if path.is_relative_to(self.repo):
                selector = str(path.relative_to(self.repo))
            else:
                if not path.is_file():
                    if optional:
                        return None
                    raise ValueError(f"Missing local source: {path}")
                data = regular(path)
                return data, {"kind": "explicit_local_source", "selector": selector,
                              "selected_path": str(path), "sha256": sha(data),
                              "git_blob_sha1_of_bytes": blob(data), "matches_head": None}
        selector = relative(selector)
        old = selector if selector in self.paths else None
        if old is None and selector in self.reverse:
            candidates = sorted(self.reverse[selector])
            if len(candidates) != 1:
                raise ValueError(f"Ambiguous SOURCE_MAP origins for {selector}: {candidates}")
            old = candidates[0]
        if old is not None:
            entry = self.paths[old]
            if entry["mode"] not in {"100644", "100755"}:
                raise ValueError(f"Mapped source is not a regular file: {old}")
            selected = relative(entry.get("current") or entry["preserved"])
            path = self.repo / selected
            data = regular(path, self.repo)
            actual_blob = self.check_head(selected, data)
            if sha(data) != entry["sha256"] or actual_blob != entry["oid"]:
                raise ValueError(f"SOURCE_MAP identity mismatch: {old} -> {selected}")
            return data, {"kind": "source_map", "selector": selector, "original_path": old,
                          "map_base": self.mapping["base"], "current_path": entry.get("current"),
                          "preserved_path": entry["preserved"], "selected_repository_path": selected,
                          "selected_path": str(path), "sha256": sha(data), "git_blob": actual_blob,
                          "matches_head": True, "selection": "current" if entry.get("current") else "preserved"}
        path = self.repo / selector
        if not path.is_file():
            if optional:
                return None
            raise ValueError(f"Missing repository source or SOURCE_MAP entry: {selector}")
        data = regular(path, self.repo)
        actual_blob = self.check_head(selector, data)
        return data, {"kind": "current_repository_source", "selector": selector,
                      "selected_repository_path": selector, "selected_path": str(path),
                      "sha256": sha(data), "git_blob": actual_blob, "matches_head": True}

    def suggestions(self, module: str) -> list[str]:
        suffix = module.replace(".", "/") + ".lean"
        return sorted(k for k in self.paths if k == suffix or k.endswith("/" + suffix))[:12]


def parse_bindings(values: list[str]) -> dict[str, str]:
    bindings = {}
    for item in values:
        name, separator, path = item.partition("=")
        checked_name(name)
        if not separator or not path or name in bindings:
            raise ValueError(f"Expected one unique MODULE=SOURCE binding: {item!r}")
        if name.split(".")[0] in BUILTIN:
            raise ValueError(f"Cannot shadow a toolchain module: {name}")
        if not path.endswith(".lean"):
            raise ValueError(f"Expected a .lean source: {path}")
        bindings[name] = path
    return bindings


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--repo", type=Path, required=True)
    ap.add_argument("--expected-head", required=True)
    ap.add_argument("--lean", type=Path, required=True)
    ap.add_argument("--output", type=Path, required=True)
    ap.add_argument("--source", action="append", default=[], metavar="MODULE=SOURCE", help="Exact source binding, also a build root")
    ap.add_argument("--root", action="append", default=[], metavar="MODULE", help="Root resolved by bindings, selected registry, or import roots")
    ap.add_argument("--bind", action="append", default=[], metavar="MODULE=SOURCE", help="Exact dependency binding")
    ap.add_argument("--import-root", action="append", default=[], help="Original repository-relative import directory or absolute local directory")
    ap.add_argument("--registry", help="Optional exact registry path; does not confer acceptance")
    ap.add_argument("--project", help="Exactly one project from --registry")
    ap.add_argument("--axiom", action="append", default=[], metavar="NAME", help="Print and validate axioms for this exact declaration after building")
    ap.add_argument("--plan-only", action="store_true")
    ap.add_argument("--timeout-seconds", type=int, default=600)
    args = ap.parse_args()
    repo, out, lean = args.repo.resolve(), args.output.resolve(), args.lean.resolve()
    if out.is_relative_to(repo):
        ap.error("--output must be outside the repository")
    if args.timeout_seconds <= 0:
        ap.error("--timeout-seconds must be positive")
    out.mkdir(parents=True, exist_ok=False)
    logs = out / "logs"; logs.mkdir()
    report = {"agent": "Agent #103", "status": "RUNNING", "started_utc": now(),
              "scope": "Exact-source development closure only; no repository-wide or independent semantic review claim.",
              "argv": sys.argv, "helper_sha256": sha(Path(__file__).read_bytes()),
              "parser_reference": PARSER_REFERENCE, "scanner_reference": SCANNER_REFERENCE,
              "plan_only": args.plan_only, "repository_wide_pass": False, "sources": {}, "commands": []}

    def save():
        (out / "manifest.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")

    def execute(label: str, argv: list[str], cwd: Path, env: dict) -> str:
        log = logs / f"{len(report['commands']):03d}-{label.replace('.', '_')}.log"
        start = time.monotonic()
        with log.open("wb") as stream:
            try:
                code = subprocess.run(argv, cwd=cwd, env=env, stdout=stream, stderr=subprocess.STDOUT, timeout=args.timeout_seconds).returncode
            except subprocess.TimeoutExpired:
                code = 124
        record = {"label": label, "argv": argv, "cwd": str(cwd), "environment": env,
                  "exit_code": code, "seconds": round(time.monotonic() - start, 6),
                  "log": str(log.relative_to(out)), "log_sha256": sha(log.read_bytes())}
        report["commands"].append(record); save()
        print(f"{label}: exit={code}", flush=True)
        if code:
            raise RuntimeError(f"{label} failed; retained log: {log}")
        return log.read_text()

    try:
        resolver = Resolver(repo, args.expected_head)
        report.update(repo=str(repo), repo_head=resolver.head, source_map_sha256=sha(resolver.map_data),
                      source_map_base=resolver.mapping["base"])
        bindings = parse_bindings(args.bind + args.source)
        roots = [checked_name(x) for x in args.root] + list(parse_bindings(args.source))
        if not roots or len(set(roots)) != len(roots):
            raise ValueError("Provide at least one unique --root or --source")
        query_names = [checked_name(x) for x in args.axiom]
        if len(set(query_names)) != len(query_names):
            raise ValueError("Duplicate --axiom declaration")
        registry_records, registry_data = {}, None
        if bool(args.registry) != bool(args.project):
            raise ValueError("--registry and --project must be supplied together")
        if args.registry:
            registry_data, registry_origin = resolver.source(args.registry)
            registry = json.loads(registry_data)
            if registry.get("schema_version") != 1 or args.project not in registry["projects"]:
                raise ValueError("Unsupported registry schema or unknown project")
            registry_records = registry["projects"][args.project]["modules"]
            report["registry"] = {"origin": registry_origin, "project": args.project,
                                  "catalogue_complete": registry.get("catalogue_complete"),
                                  "catalogue_blockers": registry.get("catalogue_blockers"),
                                  "registered_modules": len(registry_records)}
        import_roots = []
        for value in args.import_root:
            normalized = str(Path(value)) if Path(value).is_absolute() else relative(value)
            if normalized in import_roots:
                raise ValueError("Repeated --import-root: " + normalized)
            import_roots.append(normalized)
        report.update(roots=roots, import_roots=import_roots, explicit_bindings=bindings)
        runtime = lean.parent.parent
        if not args.plan_only:
            version = execute("version", [str(lean), "--version"], out, BASE_ENV).strip()
            if not re.search(r"version 4\.19\.0,.*commit 6caaee842e94, Release", version):
                raise ValueError("Wrong Lean toolchain: " + version)
            runtime = Path(execute("prefix", [str(lean), "--print-prefix"], out, BASE_ENV).strip()).resolve()
            report["lean_version"] = version
        report["compiler"] = {"path": str(lean), "sha256": sha(regular(lean)),
                              "runtime_prefix": str(runtime), "executed": not args.plan_only}
        stdlib = runtime / "lib/lean"
        if not (stdlib / "Init.olean").is_file():
            raise ValueError("Cannot locate the toolchain standard library")
        objects, source = out / "objects", out / "source"
        sources, origin_by_module, active, order = {}, {}, set(), []
        report["toolchain_imports"] = {}

        def locate(name: str):
            pinned = []
            rec = registry_records.get(name)
            if rec:
                if rec.get("adapter"):
                    raise ValueError(f"Registry adapter for {name} is outside this byte-exact helper; use the original registry verifier")
                candidate = resolver.source(rec["path"])
                if sha(candidate[0]) != rec["sha256"] or blob(candidate[0]) != rec["git_blob"]:
                    raise ValueError("Registry hash/blob mismatch: " + name)
                pinned.append(candidate)
            if name in bindings:
                pinned.append(resolver.source(bindings[name]))
            if pinned:
                identities = {(x[1]["selected_path"], x[1]["sha256"]) for x in pinned}
                if len(identities) != 1:
                    raise ValueError(f"Conflicting exact bindings for {name}: {sorted(identities)}")
                result = pinned[0]
                result[1]["resolution"] = "explicit/registry pin"
                return result
            candidates = {}
            for folder in import_roots:
                selector = str(Path(folder) / (name.replace(".", "/") + ".lean"))
                candidate = resolver.source(selector, optional=True)
                if candidate is not None:
                    candidates.setdefault(candidate[1]["selected_path"], candidate)
            if len(candidates) != 1:
                if candidates:
                    detail = [{"original_path": x[1].get("original_path"), "selected_path": x[1]["selected_path"],
                               "sha256": x[1]["sha256"]} for x in candidates.values()]
                    raise ValueError(f"Ambiguous module {name}; provide one exact binding. Candidates: {detail}")
                raise ValueError(f"Unresolved module {name}; provide --bind or --import-root. SOURCE_MAP candidates: {resolver.suggestions(name)}")
            result = next(iter(candidates.values()))
            result[1]["resolution"] = "unique import-root candidate"
            return result

        def visit(name: str):
            checked_name(name)
            if name.split(".")[0] in BUILTIN:
                path = stdlib / (name.replace(".", "/") + ".olean")
                data = regular(path)
                report["toolchain_imports"][name] = {"path": str(path), "sha256": sha(data)}
                return
            if name in active:
                raise ValueError("Import cycle: " + " -> ".join([*active, name]))
            if name in sources:
                return
            data, origin = locate(name)
            deps, prelude = imports_from(data)
            rec = registry_records.get(name)
            if rec and deps != rec["imports"]:
                raise ValueError(f"Registry import mismatch for {name}: parsed={deps}, registry={rec['imports']}")
            active.add(name)
            origin.update(imports=deps, prelude=prelude, bytes=len(data), build_sha256=sha(data),
                          source_copy=str(Path("source") / (name.replace(".", "/") + ".lean")))
            report["sources"][name] = origin
            for dep in deps:
                visit(dep)
            if not prelude:
                visit("Init")
            active.remove(name)
            sources[name], origin_by_module[name] = data, origin
            order.append(name)

        for root in roots:
            if root.split(".")[0] in BUILTIN:
                raise ValueError("A build root must be a project module")
            visit(root)
        report.update(build_order=order, module_count=len(order))
        source.mkdir(); objects.mkdir()
        for name in order:
            dest = source / (name.replace(".", "/") + ".lean")
            dest.parent.mkdir(parents=True, exist_ok=True)
            dest.write_bytes(sources[name])
        save()
        if args.plan_only:
            report["status"] = "SOURCE_AND_IMPORT_PLAN_ONLY"
        else:
            env = dict(BASE_ENV, LEAN_PATH=str(objects))
            for name in order:
                rel = Path(name.replace(".", "/"))
                obj = objects / rel.with_suffix(".olean")
                obj.parent.mkdir(parents=True, exist_ok=True)
                execute(name, [str(lean), "-j1", "-DElab.async=false", "-o", str(obj), str(rel.with_suffix(".lean"))], source, env)
                if not obj.is_file():
                    raise ValueError("Lean did not produce object: " + name)
                origin_by_module[name]["object"] = str(obj.relative_to(out))
                origin_by_module[name]["object_sha256"] = sha(obj.read_bytes())
                save()
            if query_names:
                audit_name = "__Agent103ExactBuildAudit"
                if audit_name in sources:
                    raise ValueError("Reserved audit module name already selected")
                audit = "\n".join("import " + m for m in roots) + "\n\n" + "\n".join("#print axioms " + n for n in query_names) + "\n"
                (source / (audit_name + ".lean")).write_text(audit)
                output = execute("axioms", [str(lean), "-j1", "-DElab.async=false", audit_name + ".lean"], source, env)
                entries = [(n, []) for n in re.findall(r"^'([^\n]+)' does not depend on any axioms$", output, re.M)]
                entries += [(n, sorted(a.strip() for a in values.split(",") if a.strip()))
                            for n, values in re.findall(r"^'([^\n]+)' depends on axioms:\s*\[([^\]]*)\]$", output, re.M)]
                if Counter(n for n, _ in entries) != Counter(query_names):
                    raise ValueError("Missing, repeated, or unexpected #print axioms result")
                if any(not set(ax) <= ALLOWED_AXIOMS for _, ax in entries):
                    raise ValueError("Disallowed axiom dependency")
                report["axiom_queries"] = dict(entries)
            report["status"] = "PASS_EXACT_CLOSURE_BUILD"
        for name, data in sources.items():
            if regular(Path(origin_by_module[name]["selected_path"])) != data:
                raise ValueError("Source changed during this run: " + name)
            if (source / (name.replace(".", "/") + ".lean")).read_bytes() != data:
                raise ValueError("Build snapshot changed: " + name)
        if regular(resolver.map_path, repo) != resolver.map_data or resolver.git("rev-parse", "HEAD").decode().strip() != resolver.head:
            raise ValueError("Repository HEAD or SOURCE_MAP changed during this run")
        if registry_data is not None and resolver.source(args.registry)[0] != registry_data:
            raise ValueError("Registry changed during this run")
        if sha(regular(lean)) != report["compiler"]["sha256"]:
            raise ValueError("Compiler changed during this run")
        report["source_hashes_unchanged"] = True
        print(f"{report['status']}: {len(order)} modules; manifest={out / 'manifest.json'}", flush=True)
        return 0
    except Exception as error:
        report.update(status="FAIL", error=str(error))
        (out / "failure.txt").write_text(traceback.format_exc())
        print("FAIL: " + str(error), file=sys.stderr, flush=True)
        return 1
    finally:
        report["finished_utc"] = now()
        save()


if __name__ == "__main__":
    raise SystemExit(main())
