import Std

namespace Agent103.RuntimeSmoke

theorem reflexive (n : Nat) : n = n := rfl

theorem finiteArithmetic : (17 : Nat) + 25 = 42 := by
  decide

theorem cancellation (a b : Nat) (h : a + 7 = b + 7) : a = b := by
  omega

#print axioms reflexive
#print axioms finiteArithmetic
#print axioms cancellation

end Agent103.RuntimeSmoke
