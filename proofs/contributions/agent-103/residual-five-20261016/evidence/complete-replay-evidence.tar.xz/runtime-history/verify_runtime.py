#!/usr/bin/env python3
"""Record real Lean invocations for the Agent #103 runtime smoke check."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
import re
import subprocess
import time


ROOT = Path(__file__).resolve().parent
LEAN_ROOT = ROOT / "toolchain" / "lean-4.19.0-linux"
LEAN = LEAN_ROOT / "bin" / "lean"
LOGS = ROOT / "logs"
LOGS.mkdir(exist_ok=True)
ENV = {"PATH": "/usr/local/bin:/usr/bin:/bin", "LANG": "C.UTF-8", "TZ": "UTC"}


def now() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime())


def run(name: str, args: list[str]) -> dict:
    start = now()
    process = subprocess.run(
        args, cwd=ROOT, env=ENV, text=True, capture_output=True, timeout=60
    )
    record = {
        "name": name,
        "argv": args,
        "cwd": str(ROOT),
        "environment": ENV,
        "started_utc": start,
        "finished_utc": now(),
        "exit_code": process.returncode,
        "stdout": process.stdout,
        "stderr": process.stderr,
    }
    (LOGS / (name + ".json")).write_text(
        json.dumps(record, ensure_ascii=False, indent=2) + "\n"
    )
    print(json.dumps(record, ensure_ascii=False), flush=True)
    return record


def sha256(path: Path) -> str:
    with path.open("rb") as stream:
        return hashlib.file_digest(stream, "sha256").hexdigest()


version = run("lean-approved-version", [str(LEAN), "--version"])
lake_version = run("lake-approved-version", [str(LEAN_ROOT / "bin" / "lake"), "--version"])
smoke = run(
    "smoke",
    [str(LEAN), "-j1", "-DElab.async=false", "-o", str(ROOT / "Smoke.olean"), str(ROOT / "Smoke.lean")],
)
negative = run(
    "negative-control",
    [str(LEAN), "-j1", "-DElab.async=false", str(ROOT / "controls" / "NegativeControl.lean")],
)

expected_names = {
    "Agent103.RuntimeSmoke.reflexive",
    "Agent103.RuntimeSmoke.finiteArithmetic",
    "Agent103.RuntimeSmoke.cancellation",
}
axioms = {}
for line in smoke["stdout"].splitlines():
    empty = re.fullmatch(r"'([^']+)' does not depend on any axioms", line)
    dependent = re.fullmatch(r"'([^']+)' depends on axioms: \[(.*)\]", line)
    if empty:
        axioms[empty[1]] = []
    elif dependent:
        axioms[dependent[1]] = [s.strip() for s in dependent[2].split(",") if s.strip()]

allowed = {"propext", "Quot.sound", "Classical.choice"}
checks = {
    "requested_version": version["exit_code"] == 0 and "version 4.19.0," in version["stdout"] and "commit 6caaee842e94," in version["stdout"],
    "lake_version": lake_version["exit_code"] == 0 and "Lean version 4.19.0" in lake_version["stdout"],
    "smoke_compilation": smoke["exit_code"] == 0 and (ROOT / "Smoke.olean").is_file(),
    "axioms_all_reported": set(axioms) == expected_names,
    "axioms_allowed": all(set(values) <= allowed for values in axioms.values()),
    "false_proof_rejected": negative["exit_code"] != 0 and "tactic 'rfl' failed" in negative["stdout"],
}
paths = [LEAN, LEAN_ROOT / "bin" / "lake", LEAN_ROOT / "lib" / "lean" / "libleanshared.so", ROOT / "Smoke.lean", ROOT / "controls" / "NegativeControl.lean", Path(__file__).resolve()]
if (ROOT / "Smoke.olean").is_file():
    paths.append(ROOT / "Smoke.olean")
summary = {
    "execution_mode": "Unmodified release binary executed through exec_command require_escalated approval; no LD_PRELOAD adapter.",
    "checked_utc": now(),
    "lean_path": str(LEAN),
    "checks": checks,
    "axioms": axioms,
    "hashes": {str(p.relative_to(ROOT)): sha256(p) for p in paths},
    "passed": all(checks.values()),
}
(LOGS / "runtime-verification.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
raise SystemExit(0 if summary["passed"] else 1)
