#!/usr/bin/env python3
"""Preserve each real, isolated author build without altering earlier attempts."""
from pathlib import Path
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

ROOT = Path('/workspace/scratch/a1d46b1077ac')
SOURCE = ROOT / 'agent103-work/third-source/ResidualFiveThirdWidth.lean'
LEAN = ROOT / 'agent103-runtime/toolchain/lean-4.19.0-linux/bin/lean'
DEST = Path(__file__).resolve().parent / sys.argv[1]
LEAN_PATH = sys.argv[2]
DEST.mkdir(parents=True, exist_ok=False)
COPY = DEST / SOURCE.name
shutil.copy2(SOURCE, COPY)
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
argv = [str(LEAN), '--trust=0', '-j1', '-DElab.async=false',
        '-o', 'ResidualFiveThirdWidth.olean', SOURCE.name]
env = dict(os.environ)
env['LEAN_PATH'] = LEAN_PATH
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
tic = time.monotonic()
p = subprocess.run(argv, cwd=DEST, env=env, text=True,
                   stdout=subprocess.PIPE, stderr=subprocess.PIPE)
(DEST / 'stdout.log').write_text(p.stdout)
(DEST / 'stderr.log').write_text(p.stderr)
(DEST / 'compile.log').write_text(p.stdout + p.stderr)
manifest = {
    'source': str(SOURCE), 'frozen_source': str(COPY),
    'source_sha256': sha(COPY), 'argv': argv, 'cwd': str(DEST),
    'environment_overrides': {'LEAN_PATH': LEAN_PATH},
    'started_utc': start,
    'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'elapsed_seconds': time.monotonic() - tic, 'exit_code': p.returncode,
    'stdout_sha256': sha(DEST / 'stdout.log'),
    'stderr_sha256': sha(DEST / 'stderr.log'),
    'combined_log_sha256': sha(DEST / 'compile.log'),
}
obj = DEST / 'ResidualFiveThirdWidth.olean'
if obj.exists():
    manifest['object_sha256'] = sha(obj)
(DEST / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(p.stdout, end='')
print(p.stderr, end='', file=sys.stderr)
print(json.dumps({'attempt': str(DEST), 'exit_code': p.returncode,
                  'source_sha256': manifest['source_sha256']}))
sys.exit(p.returncode)
