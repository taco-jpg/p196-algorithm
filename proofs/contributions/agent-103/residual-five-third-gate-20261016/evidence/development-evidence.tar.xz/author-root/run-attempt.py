from pathlib import Path
import datetime, hashlib, json, os, shutil, subprocess, sys

root = Path('/workspace/scratch/a1d46b1077ac')
module, group, number = sys.argv[1], sys.argv[2], int(sys.argv[3])
base = root / 'agent103-work/third-dev' / group
out = base / f'attempt-{number:03d}'
out.mkdir(parents=True, exist_ok=False)
src = root / 'agent103-work/third-source' / f'{module}.lean'
frozen = out / src.name
shutil.copy2(src, frozen)
lean = root / 'agent103-runtime/toolchain/lean-4.19.0-linux/bin/lean'
deps = [root / 'agent103-work/third-check/development-001/snapshot',
        root / 'agent103-audit/third-dev/attempt-001',
        root / 'agent103-scope/third-dev/attempt-003']
if group == 'conclusion':
    deps.append(root / 'agent103-work/third-dev/overflow/attempt-001')
argv = [str(lean), '--trust=0', '-j1', '-DElab.async=false',
        '-o', f'{module}.olean', src.name]
env = os.environ.copy()
env['LEAN_PATH'] = ':'.join(str(p) for p in deps)
start = datetime.datetime.now(datetime.timezone.utc).isoformat()
p = subprocess.run(argv, cwd=out, env=env, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
(out / 'stdout.log').write_bytes(p.stdout)
(out / 'stderr.log').write_bytes(p.stderr)
record = {'argv': argv, 'cwd': str(out), 'LEAN_PATH': env['LEAN_PATH'],
          'source_sha256': hashlib.sha256(frozen.read_bytes()).hexdigest(),
          'started_utc': start, 'finished_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
          'exit_code': p.returncode, 'lean_sha256': hashlib.sha256(lean.read_bytes()).hexdigest(),
          'development_dependencies_reused': True}
(out / 'invocation.json').write_text(json.dumps(record, indent=2) + '\n')
print(json.dumps(record))
print(p.stdout.decode())
print(p.stderr.decode())
sys.exit(p.returncode)
