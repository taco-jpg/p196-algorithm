from pathlib import Path
import datetime
import hashlib
import json
import os
import subprocess
import sys
import time

root = Path('/workspace/scratch/a1d46b1077ac')
module = 'ResidualFiveThirdDecoder'
source = root / 'agent103-work/third-source' / (module + '.lean')
target = root / 'agent103-scope/third-dev' / sys.argv[1]
target.mkdir(parents=True, exist_ok=False)
frozen = target / source.name
frozen.write_bytes(source.read_bytes())
lean = root / 'agent103-runtime/toolchain/lean-4.19.0-linux/bin/lean'
dependency_path = sys.argv[2]
argv = [str(lean), '--trust=0', '-j1', '-DElab.async=false',
        '-o', module + '.olean', module + '.lean']
invocation = {'argv': argv, 'cwd': str(target), 'LEAN_PATH': dependency_path}
(target / 'argv.json').write_text(json.dumps(invocation, indent=2) + '\n')
env = dict(os.environ)
env['LEAN_PATH'] = dependency_path
started = datetime.datetime.now(datetime.timezone.utc).isoformat()
before = time.monotonic()
result = subprocess.run(argv, cwd=target, env=env, text=True, capture_output=True)
(target / 'stdout.log').write_text(result.stdout)
(target / 'stderr.log').write_text(result.stderr)
(target / 'compile.log').write_text(result.stdout + result.stderr)
meta = {'module': module, 'started_at': started, 'elapsed_seconds': time.monotonic()-before,
        'exit_code': result.returncode, **invocation,
        'source_sha256': hashlib.sha256(frozen.read_bytes()).hexdigest(),
        'files': {}}
for path in target.iterdir():
    if path.is_file():
        meta['files'][path.name] = {'bytes': path.stat().st_size,
                                   'sha256': hashlib.sha256(path.read_bytes()).hexdigest()}
(target / 'manifest.json').write_text(json.dumps(meta, indent=2) + '\n')
print(json.dumps({'attempt': str(target), 'exit_code': result.returncode,
                  'source_sha256': meta['source_sha256'],
                  'elapsed_seconds': meta['elapsed_seconds']}))
print(result.stdout)
if result.stderr:
    print(result.stderr, file=sys.stderr)
sys.exit(result.returncode)
