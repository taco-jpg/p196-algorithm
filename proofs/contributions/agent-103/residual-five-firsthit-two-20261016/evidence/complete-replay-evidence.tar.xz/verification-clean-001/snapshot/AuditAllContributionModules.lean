import LychrelDigitSums
import PrefixInverse
import ActualPrefix
import PalindromeBridge
import EightFamilies
import ResidualFiveShape
import Lychrel196Research
import Agent101DigitPairs
import Agent101MultiplicityBounds
import Agent101SplitEnumeration
import Agent101NumericFibers
import ResidualFiveFibers
import TemporalResidues
import ResidualFive
import ResidualFiveWitness
import ResidualFiveConclusion
import ResidualFiveFiberConclusion
import ResidualFiveHitDynamics
import Agent101PalindromeFibers
import ResidualFiveInitialPalindromes
import ResidualFiveResidues
import ResidualFiveResidueBridge
import ResidualFiveCountArithmetic
import ResidualFiveResidueCount
import ResidualFiveFilteredConclusion
import ResidualFivePhaseCompatibility
import ResidualFiveFirstHitConclusion
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
run_cmd do
  let env ← getEnv
  let selected : List String := ["LychrelDigitSums", "PrefixInverse", "ActualPrefix", "PalindromeBridge", "EightFamilies", "ResidualFiveShape", "Lychrel196Research", "Agent101DigitPairs", "Agent101MultiplicityBounds", "Agent101SplitEnumeration", "Agent101NumericFibers", "ResidualFiveFibers", "TemporalResidues", "ResidualFive", "ResidualFiveWitness", "ResidualFiveConclusion", "ResidualFiveFiberConclusion", "ResidualFiveHitDynamics", "Agent101PalindromeFibers", "ResidualFiveInitialPalindromes", "ResidualFiveResidues", "ResidualFiveResidueBridge", "ResidualFiveCountArithmetic", "ResidualFiveResidueCount", "ResidualFiveFilteredConclusion", "ResidualFivePhaseCompatibility", "ResidualFiveFirstHitConclusion"]
  let newModules : List String := ["ResidualFiveHitDynamics", "ResidualFiveInitialPalindromes", "ResidualFivePhaseCompatibility", "ResidualFiveFirstHitConclusion"]
  let mut count := 0
  let mut definitionCount := 0
  let mut newSafeCount := 0
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        match info with
        | .axiomInfo v =>
          if v.isUnsafe then logInfo m!"UNSAFE_IMPL {mod} {name}"
          else throwError m!"CUSTOM_AXIOM {mod} {name}"
        | .thmInfo _ =>
          count := count + 1
          logInfo m!"AUDIT_THEOREM {mod} {name}"
          elabCommand (← `(command| #print axioms $(mkIdent name)))
        | .defnInfo v =>
          definitionCount := definitionCount + 1
          let safety := match v.safety with
            | .safe => "safe"
            | .unsafe => "unsafe"
            | .partial => "partial"
          logInfo m!"AUDIT_DEFINITION {mod} {name} {safety} definition"
          match v.safety with
          | .safe =>
            if newModules.contains mod.toString then
              newSafeCount := newSafeCount + 1
              logInfo m!"AUDIT_NEW_SAFE_DEFINITION {mod} {name}"
              elabCommand (← `(command| #print axioms $(mkIdent name)))
          | _ => pure ()
        | .opaqueInfo v =>
          definitionCount := definitionCount + 1
          let safety := if v.isUnsafe then "unsafe" else "safe"
          logInfo m!"AUDIT_DEFINITION {mod} {name} {safety} opaque"
          if !v.isUnsafe && newModules.contains mod.toString then
            newSafeCount := newSafeCount + 1
            logInfo m!"AUDIT_NEW_SAFE_DEFINITION {mod} {name}"
            elabCommand (← `(command| #print axioms $(mkIdent name)))
        | _ => pure ()
  logInfo m!"AUDIT_COMPLETE {count}"
  logInfo m!"AUDIT_DEFINITIONS_COMPLETE {definitionCount} {newSafeCount}"
