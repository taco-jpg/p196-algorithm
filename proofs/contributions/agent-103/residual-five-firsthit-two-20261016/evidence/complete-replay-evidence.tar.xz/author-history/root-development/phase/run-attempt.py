from pathlib import Path
import datetime,hashlib,json,os,shutil,subprocess,sys
root=Path('/workspace/scratch/a1d46b1077ac')
base=root/'agent103-work/firsthit-dev/phase'
i=int(sys.argv[1]); out=base/f'attempt-{i:03d}'; out.mkdir()
src=root/'agent103-work/firsthit-source/ResidualFivePhaseCompatibility.lean'
shutil.copy2(src,out/src.name)
lean=root/'agent103-runtime/toolchain/lean-4.19.0-linux/bin/lean'
deps=root/'agent103-work/fiber-check/verification-clean-001/snapshot'
argv=[str(lean),'--trust=0','-j1','-DElab.async=false','-o','ResidualFivePhaseCompatibility.olean',src.name]
env=os.environ.copy();env['LEAN_PATH']=str(deps)
start=datetime.datetime.now(datetime.timezone.utc).isoformat()
p=subprocess.run(argv,cwd=out,env=env,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
(out/'stdout.log').write_bytes(p.stdout);(out/'stderr.log').write_bytes(p.stderr)
x={'argv':argv,'cwd':str(out),'LEAN_PATH':str(deps),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'started_utc':start,'finished_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'exit_code':p.returncode,'lean_sha256':hashlib.sha256(lean.read_bytes()).hexdigest()}
(out/'invocation.json').write_text(json.dumps(x,indent=2)+'\n')
print(json.dumps(x));print(p.stdout.decode());print(p.stderr.decode());sys.exit(p.returncode)
