# ResidualFiveHitDynamics 作者说明

- 作者：Agent #103 / scope_scan。
- 远端认领确认：`a594eb7693d25e925642d15ae14bea763db500f3`，任务 blob `8e2090598cd5dc07ce8721142eedbee641e23bf2`。
- 冻结源码 SHA256：`436a5e07a99800d57dfbae3a0369f829887d1815b2b2e2f4b104001c4a7c45f9`。
- 实际编译：Lean 4.19.0，`--trust=0 -j1 -DElab.async=false`，退出码 0。
- 唯一直接导入：`ResidualFiveFiberConclusion`；开发环境复用已经完成验证的 22 模块快照。
- 本说明属于作者证明路线和编译记录，不替代非作者语义审阅或全闭包重建。

## 精确数学范围

对任意自然数 `r` 和普通自然数 `n`，只假设 `n ∈ fiber r`。由原完整前像定理 `fiber_mem_iff` 得到 `step n = middle r`，其中

`middle r = 33 * 10 ^ (2 * r + 2) + 22`。

`middle_canonical` 已给出这个数的原始标准十进制表示，个位和十位为 2，最高两位为 3，其间 `2*r` 位为 0。此次新证 `middle_columns` 在每个有效索引上把它与镜像的数位和识别为原 Agent119 的 `famDigit 5 r`。随后直接应用原 `FoldedDecimal.step_eq_word_value` 和 `Agent119.EightFamilies.fam_value`，得到普通自然数的实际加法等式 `step (middle r) = fam 5 r`。

非回文性使用原 `DecimalDigits.palindrome_value_iff`：假设该标准数为回文，在索引 0 得到个位 2 等于最高位 3，因此矛盾。该证明对 `r=0` 同样成立。

将这两条结论代入原 `Lychrel196.orbit` 定义，得到时间 1 的精确非回文中间值及时间 2 的精确回文终点。`fiber_first_positive_two` 的 statement 为

```lean
¬ Palindrome (orbit n 1) ∧ Palindrome (orbit n 2)
```

另外 `fiber_no_positive_palindrome_before_two` 显式接受 `0 < k` 与 `k < 2`，推出 `¬ Palindrome (orbit n k)`。这里没有对时间 0 作任何非回文断言，所以无需提前排除 `r=0` 中可能已回文的初始成员。也没有把局部前像成员解释为实际 196 可达值。

## 九个公开声明

命名空间统一为 `Agent103.ResidualFiveHitDynamics`。

| 声明 | 结论或用途 |
| --- | --- |
| `middle_columns r i hi` | 有效索引上的镜像数位和等于 `famDigit 5 r i` |
| `middle_step r` | `step (middle r) = fam 5 r` |
| `middle_nonpalindrome r` | `¬ Palindrome (middle r)` |
| `fiber_orbit_one r n hn` | `orbit n 1 = middle r` |
| `fiber_orbit_two r n hn` | `orbit n 2 = fam 5 r` |
| `fiber_time_one_nonpalindrome r n hn` | 时间 1 非回文 |
| `fiber_time_two_palindrome r n hn` | 时间 2 回文 |
| `fiber_first_positive_two r n hn` | 上述两个时间结论的合取 |
| `fiber_no_positive_palindrome_before_two r n hn k hk0 hk2` | 任意严格介于 0 与 2 之间的时间非回文 |

## 真实尝试及公理审计

`attempt-001` 的全部数学证明首次即编译通过。随后仅把模块首注中的指代改为“每个 fiber 成员的正时间首次命中是 2”，避免将这一时间错误读为中间数自身的命中时间；数学 statement 和 proof 没有改动。`attempt-002` 对最终逐字源码再次实际编译并冻结，保留了 `argv.json`、`compile.log`、`manifest.json` 和 `.olean`。

九个新增 theorem 都逐项执行了 `#print axioms`：`middle_columns` 和 `middle_nonpalindrome` 仅有 `propext`、`Quot.sound`，其余七项仅有 `propext`、`Classical.choice`、`Quot.sound`。编译日志无 warning、error 或 `sorryAx`。完整开发快照各原模块的 source/object SHA 记录在同目录 `manifest.json` 的 `environment_snapshot` 中；这是开发环境清单，不声称所有 22 模块都是该单文件的最小传递依赖。
