import pathlib,json,hashlib,re,collections,difflib,ast,datetime
root=pathlib.Path('/dev/shm/p196-agent31-02893e4f368d/review104')
def sha(b): return hashlib.sha256(b).hexdigest()
def blob(b): return hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
fetched={}; manifest=[]
for path in sorted((root/'raw').rglob('*.connector.json')):
    d=json.loads(path.read_text()); b=d['content'].encode()
    p=root/'extracted'/d['path']; p.parent.mkdir(parents=True,exist_ok=True); p.write_bytes(b)
    row={'path':d['path'],'bytes':len(b),'sha256':sha(b),'computed_git_blob':blob(b),**d['metadata']}
    if row.get('sha'): assert row['sha']==row['computed_git_blob'],row
    manifest.append(row); fetched[d['path']]=b
def data(k): return json.loads(fetched[k])
pins=data('repair-review/source-pins.json'); report=data('repair-review/clean-001/report.json')
files=data('repair-review/clean-001/FILES.json')
for key,b in fetched.items():
    prefix='repair-review/clean-001/'
    if key.startswith(prefix) and key[len(prefix):] in files:
        e=files[key[len(prefix):]]
        assert len(b)==e['bytes'] and sha(b)==e['sha256'],key
sourceChecks=[]
for name,p in pins.items():
    key='source/'+p['source']; b=fetched[key]
    assert sha(b)==p['sha256'] and blob(b)==p['git_blob'],name
    assert report['source_snapshot'][name]['sha256']==p['sha256']
    assert report['source_snapshot'][name]['git_blob']==p['git_blob']
    assert files['source/'+name+'.lean']['sha256']==p['sha256']
    sourceChecks.append({'module':name,**p,'bytes':len(b),'imports':re.findall(r'^import\s+([^\n]+)',b.decode(),re.M),'matches_executed_snapshot':True})
old=fetched['original-author-source']; new=fetched['repaired/Agent114ShortRFirst11.lean']
assert sha(old)=='b5712b2051605a0ff95a1f6d8e18927d2aea4c91fbf2e8d38b688205033874cd'
assert sha(new)=='e2557923cdbe694ab4a21463ab765bd0d609623f98e77e5c3aac593ed101bd81'
before=b'  dsimp [DecimalDigits.columnSum, DecimalDigits.reflected] at hq\n'
after='  have htwice : d 0 + d 0 = 1 := by\n    calc\n      d 0 + d 0 = columnSum d (2 * r + 7) 0 := by\n        unfold columnSum reflected\n        rw [← hends]\n      _ = 1 := hq\n'.encode()
assert old.count(before)==1 and old.replace(before,after)==new
statement=lambda b:re.findall(r'^theorem\s+.*?:=',b.decode(),re.M|re.S)
# Non-greedy anchored matches preserve complete parameter and proposition text.
assert statement(old)==statement(new) and len(statement(new))==6
actual_diff=''.join(difflib.unified_diff(old.decode().splitlines(True),new.decode().splitlines(True),fromfile='original-687e6c79',tofile='repair-50ce06bc'))
assert actual_diff==fetched['repair-review/independent-source-diff.patch'].decode()
audit=fetched['repair-review/clean-001/logs/IndependentAudit.log'].decode()
rows={kind:re.findall(r'^AUDIT_'+kind+r' (\S+) (\S+) : (.*)$',audit,re.M) for kind in ['THEOREM','SAFE_DEFINITION','SAFE_OPAQUE']}
allowed={'propext','Classical.choice','Quot.sound'}; union=set()
for kind,entries in rows.items():
    for mod,name,axs in entries:
        terms={x.strip() for x in axs.strip('[]').split(',') if x.strip()}
        assert terms<=allowed,(kind,mod,name,terms)
        union|=terms
    expected=report[{'THEOREM':'theorem_count','SAFE_DEFINITION':'safe_definition_count','SAFE_OPAQUE':'safe_opaque_count'}[kind]]
    assert len(entries)==expected,(kind,len(entries),expected)
allnames=[v[1] for entries in rows.values() for v in entries]
assert len(set(allnames))==len(allnames)==1694
for ep in report['public_new_endpoints']: assert ep in allnames
for c in report['commands']:
    assert c['exit_code']==0 and all(x in c['argv'] for x in ['--trust=0','-j1','-DElab.async=false'])
    assert sha(fetched['repair-review/clean-001/logs/'+c['label']+'.log'])==c['log_sha256']
assert report['status']=='PASS_INDEPENDENT_FRESH_BUILD_AND_AXIOM_AUDIT'
assert fetched['repair-review/public-types-and-axioms.txt'].decode() in audit
assert not re.search(r'\b(?:DISALLOWED_AXIOMS|CUSTOM_AXIOM|error:|sorryAx)\b',audit)
assert sha(fetched['repair-review/independent_build.py'])==report['runner_sha256']
assert sha(fetched['scanner'])==report['scanner_sha256']
assert sha(fetched['repair-review/source-pins.json'])==report['pins_sha256']
unsafe=re.findall(r'^UNSAFE_IMPLEMENTATION_AXIOM (\S+) (\S+)$',audit,re.M)
non_safe=re.findall(r'^NON_SAFE_DEFINITION (\S+) (\S+) (.*)$',audit,re.M)
assert len(unsafe)==14 and len(non_safe)==822
assert not any(e[0]=='Agent114ShortRFirst11' for e in unsafe+non_safe)
assert not re.findall(r'^UNSAFE_OPAQUE ',audit,re.M)
assert len([e for e in non_safe if e[2]=='Lean.DefinitionSafety.unsafe'])==803
assert len([e for e in non_safe if e[2]=='Lean.DefinitionSafety.partial'])==19
original_report=data('clean-001/report.json')
original_log=fetched['clean-001/logs/Agent114ShortRFirst11.log']
assert original_report['status']=='FAIL'
assert original_report['commands'][-1]['exit_code']==1
assert sha(original_log)==original_report['commands'][-1]['log_sha256']
assert b'52:2: error: omega could not prove the goal' in original_log and b'sorryAx' in original_log
runtime=pathlib.Path('/tmp/p196-agent5-lean/lean-4.19.0-linux')
runtimeChecks=[]
for oldpath,digest in report['compiler']['files'].items():
    rel=oldpath.split('/lean-4.19.0-linux/',1)[1]; p=runtime/rel
    actual=sha(p.read_bytes()); assert actual==digest
    runtimeChecks.append({'file':str(p),'sha256':actual,'matches_retained_compiler':True})
provenance={}
for name in ['install-record.json','download.log','version.log','smoke.log']:
    p=runtime.parent/name; b=p.read_bytes()
    (root/'extracted'/('trusted-runtime-'+name)).write_bytes(b)
    provenance[name]={'bytes':len(b),'sha256':sha(b)}
result={'status':'PASS_RETAINED_EVIDENCE_REUSE','reviewer':'Agent #31 independent evidence-review specialist /root/pr104_repair_evidence',
 'publication_commit':'36f3a58b22c93bef9f6fbc234d9bab8b5ebd43d0',
 'prior_review_source_commit':report['source_commit'],'original_pr_head':'687e6c79ed86377cf2f8d6d49bf6860b064dd1fa',
 'fresh_Lean_execution':'NOT_RUN; intentionally reused qualifying unchanged-source execution',
 'sources':sourceChecks,'all_fetched_git_blobs_verified':True,'all_retrieved_manifest_entries_match':True,
 'all_six_statement_texts_identical':True,'single_repair_exact_byte_substitution':True,
 'theorem_count':len(rows['THEOREM']),'safe_definition_count':len(rows['SAFE_DEFINITION']),'safe_opaque_count':len(rows['SAFE_OPAQUE']),
 'counts_by_module':{k:dict(collections.Counter(v[0] for v in es)) for k,es in rows.items()},
 'axiom_union':sorted(union),'unsafe_implementation_axiom_count':len(unsafe),'non_safe_definition_count':len(non_safe),
 'compiler_version':report['compiler']['version'],'runtime_identity_checks':runtimeChecks,'runtime_provenance_files':provenance,
 'retained_all_eight_commands_exit_zero':True,'retained_command_seconds':sum(c['seconds'] for c in report['commands']),
 'original_failure_retained_and_hash_verified':True,'all_other_five_proof_bodies_unchanged':True,
 'original_error':original_log.decode(),'scope':'Canonical short-spacer families r=1,2,3,4: time zero and positive times 1 through 11. No first-hit, 3000-step, r>=5, unbounded, or seed-196 theorem.',
 'independence':'Prior repair author Agent #1; distinct specialist performed prior execution and did not edit source; shared GitHub account, COMMENT not external APPROVE. Current evidence reviewer authored no source.',
 'remaining_integration_obligation':'Exact repaired bytes must be adopted, build inclusion and current-main combination verified, current PR/platform/ownership gates satisfied. No fresh independent Lean rebuild of unchanged selected closure required by this evidence audit.'}
(root/'validation.json').write_text(json.dumps(result,indent=2)+'\n')
(root/'FETCH_MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({k:v for k,v in result.items() if k not in ['original_error','sources','runtime_identity_checks']},indent=2))
print('ORIGINAL_LOG\n'+original_log.decode())
print('RUNTIME_PROVENANCE\n'+(runtime.parent/'install-record.json').read_text())

