from pathlib import Path
import hashlib,json
base=Path('/dev/shm/p196-agent31-02893e4f368d')
review=base/'review104'; task=base/'root104'
out=review/'wiring-review';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
regp=task/'prepared-integration/BUILD_REGISTRY.json';docp=task/'prepared-integration/REPRODUCE.md'
reg=json.loads(regp.read_text()); pins=json.loads((review/'extracted/repair-review/source-pins.json').read_text())
prior=json.loads((review/'extracted/repair-review/clean-001/report.json').read_text())
run=json.loads((task/'registry-check-001/verification.json').read_text())
receipt=json.loads((task/'registry-check-receipt.json').read_text())
fixture=json.loads((task/'registry-fixture-provenance.json').read_text())
project='agent114-short-r-first-eleven'; spec=reg['projects'][project]
assert list(reg['projects'])==[project] and len(spec['modules'])==7
assert spec['roots']==['Agent114ShortRFirst11']
assert reg['schema_version']==1 and not reg['catalogue_complete'] and reg['catalogue_blockers']
assert reg['toolchain']['allowed_axioms']==['propext','Classical.choice','Quot.sound']
for name,pin in pins.items():
    m=spec['modules'][name]
    assert m['sha256']==pin['sha256'] and m['git_blob']==pin['git_blob']
    assert m['imports']==prior['source_snapshot'][name]['imports'] and not m.get('adapter')
    expected=pin['source'] if name!='Agent114ShortRFirst11' else 'proofs/contributions/agent-114/short-r-firsthit-20261016/Agent114ShortRFirst11.wip.lean'
    assert m['path']==expected
    staged=task/'registry-fixture'/expected
    assert sha(staged)==pin['sha256']
assert reg['claims'][0]['endpoints']==prior['public_new_endpoints'] and len(reg['claims'])==1
assert reg['claims'][0]['project']==project
assert receipt['status']==run['status']=='SOURCE_AND_IMPORT_CHECK_ONLY'
assert receipt['exit_code']==0 and '--check-only' in receipt['command']
assert receipt['report_sha256']==sha(task/'registry-check-001/verification.json')
assert not run['mathematical_proof_check'] and not run['repository_wide_pass']
assert run['source_commit']==fixture['local_synthetic_commit']==receipt['local_synthetic_commit']
assert run['source_tree_clean']
assert len(run['projects'])==1 and run['projects'][project]['commands']==[]
assert run['projects'][project]['build_order']==prior['module_order']
assert run['registry_sha256']==fixture['registry_sha256']==sha(regp)
assert sha(regp)=='78f4ca4b5b23c0aed22e69f7564d35caed8e3a3c368243837dd29a48679ba20d'
assert sha(docp)=='d010335245fe80e25b21235a1d7261c19df2c51aef7f959de863d7ba3ebce6dd'
assert sha(task/'registry-fixture/proofs/verify_project__214bf7673efe116b.py')==prior['scanner_sha256']
for k,v in json.loads((task/'registry-check-001/FILES.json').read_text()).items():
 p=task/'registry-check-001'/k
 assert p.stat().st_size==v['bytes'] and sha(p)==v['sha256']
files=[(regp,'BUILD_REGISTRY.json'),(docp,'REPRODUCE.md'),(task/'registry-check-receipt.json','registry-check-receipt.json'),(task/'registry-fixture-provenance.json','registry-fixture-provenance.json'),(task/'registry-check-001/verification.json','verification.json'),(task/'registry-check-001/FILES.json','FILES.json')]
for p,name in files:(out/name).write_bytes(p.read_bytes())
result={'status':'PASS_SCOPED_REGISTRY_AND_REPRODUCTION_REVIEW','reviewer':'Agent #31 /root/pr104_repair_evidence','author':'Separate Agent #31 coordination_scout specialist','registry_sha256':sha(regp),'reproduce_sha256':sha(docp),'seven_source_pins_match_strict_review':True,'six_endpoints_match_strict_review':True,'only_root_repository_path_remapped':True,'no_adapters':True,'source_and_import_check_retained_exit':0,'source_and_import_check_status':run['status'],'source_and_import_check_mathematical_proof_check':False,'source_and_import_check_repository_wide_pass':False,'local_synthetic_commit':run['source_commit'],'verifier_unchanged_sha256':prior['scanner_sha256'],'fresh_Lean_compilation_or_new_theorem_audit_in_this_review':'NOT_RUN','frozen_main_review_sha256':sha(review/'REVIEW.md'),'scope_limit':'Accepts the prepared registry/document bytes and retained structural check only; not a full main checkout, combined-tree acceptance, remote publication or merge.','findings':[]}
(out/'review.json').write_text(json.dumps(result,indent=2)+'\n')
report="""# Independent scoped wiring review: PASS

The proposed BUILD_REGISTRY.json and REPRODUCE.md correctly register the already reviewed seven-module closure and all six public endpoints without changing source bytes, imports, theorem statements, verifier code, or axiom policy.

- BUILD_REGISTRY.json SHA-256: 78f4ca4b5b23c0aed22e69f7564d35caed8e3a3c368243837dd29a48679ba20d.
- REPRODUCE.md SHA-256: d010335245fe80e25b21235a1d7261c19df2c51aef7f959de863d7ba3ebce6dd.
- Exact root: Agent114ShortRFirst11; seven modules; six matching claim endpoints; no adapters.
- The root path maps the byte-identical reviewed repair to the author .wip.lean path. All dependency paths and all seven SHA-256/Git-blob pins match the frozen strict-execution evidence.
- The catalogue explicitly remains incomplete and scoped. Neither file asserts a repository-wide pass.
- Retained source/import check exits 0 and reports SOURCE_AND_IMPORT_CHECK_ONLY, mathematical_proof_check=false, repository_wide_pass=false, and an empty module command list.
- The checker fixture is explicitly synthetic local commit 77a115f7d42b9b5e119bb6d12b9d7d4cce3699eb. The source/base publication identities are separate metadata. The preparation check is not presented as a complete checkout, combined tree or merge result.
- All retained source/import inventory file hashes and the receipt's verification-report hash match actual files. The canonical verifier is unchanged at SHA-256 c047ff1ff1fe12b2c2094ca5f36af871b1c6faf89db593a102f9c2f7d48cc98a.
- The unchanged verifier's hardcoded report agent is Agent #1; the additional receipt identifies executor/owner Agent #31. This is preserved source provenance, not a claim that Agent #1 performed this preparation run.
- Reproduction instructions use the actual supported flags. They correctly state that the canonical optional full mode lacks explicit --trust=0 and safe-definition auditing, and distinguish it from the stricter independent execution already retained. No weakened checker is substituted for that existing proof evidence.
- Scope text preserves the conditional canonical-realization and finite-horizon result. It does not claim a 3,000-step theorem, exact later first hit, infinite avoidance or the 196 conjecture.

This reviewer authored neither proposed file and made no source changes. Fresh Lean source compilation and theorem audit: **NOT_RUN**; the known strict mathematical review remains frozen and was not repeated. The inspected preparation run queries compiler identity only. No remote mutation was performed.

No material wiring defect was found. The exact prepared files are suitable for the delivery owner's additive publication and subsequent integration checks. Current-main combination, actual publication readback, active coordination ownership, platform gates and merge/post-merge certification remain the delivery owner's responsibilities.

The original REVIEW.md and its PACKAGE_MANIFEST.json were left unchanged. This appendix has separate raw copies, validation receipt and manifest.
"""
(out/'REVIEW.md').write_text(report)
manifest={p.name:{'bytes':p.stat().st_size,'sha256':sha(p)} for p in sorted(out.iterdir()) if p.is_file()}
(out/'MANIFEST.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(result,indent=2))
print('appendix_report_sha256='+sha(out/'REVIEW.md'))
