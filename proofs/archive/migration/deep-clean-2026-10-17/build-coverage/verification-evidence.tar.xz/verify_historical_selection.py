#!/usr/bin/env python3
"""Check that the one-row selector repair retains every historical mapped byte."""
from pathlib import Path
import hashlib
import json
import subprocess

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'p196-work'
BASE = 'ed5202b2839b5fedf3d97309481ac7a4bd556675'


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


before_bytes = git('show', f'{BASE}:proofs/SOURCE_MAP.json')
after_bytes = (REPO / 'proofs/SOURCE_MAP.json').read_bytes()
before, after = json.loads(before_bytes), json.loads(after_bytes)
expected = json.loads(before_bytes)
expected['paths']['proofs/ACCEPTED_BUILD.json']['current'] = None
assert after == expected and after['paths']['proofs/REPORTS.md']['current'] is None
tree = {}
for line in git('ls-tree', '-rz', '--full-tree', BASE).split(b'\0'):
    if not line:
        continue
    meta, path = line.split(b'\t', 1)
    mode, kind, oid = meta.decode().split()
    tree[path.decode()] = (mode, kind, oid)
records, objects = [], {}
for old, record in after['paths'].items():
    previous = before['paths'][old]
    old_selected = previous.get('current') or previous['preserved']
    selected = record.get('current') or record['preserved']
    old_entry, entry = tree[old_selected], tree[selected]
    assert entry == old_entry == (record['mode'], 'blob', record['oid'])
    # A modified current file must not be selected under its historical hash.
    if selected in ('proofs/verify_project.py', 'proofs/ACCEPTED_BUILD.json',
                    'proofs/README.md', 'proofs/SOURCE_MAP.json'):
        raise AssertionError('Historical replay selects a modified current file: ' + selected)
    objects[entry[2]] = record['sha256']
    records.append({'historical_path': old, 'before_selected': old_selected,
                    'after_selected': selected, 'mode': record['mode'],
                    'git_blob': entry[2], 'sha256': record['sha256']})

batch = subprocess.Popen(['git', 'cat-file', '--batch'], cwd=REPO,
                         stdin=subprocess.PIPE, stdout=subprocess.PIPE)
total_bytes = 0
for oid, expected_hash in objects.items():
    batch.stdin.write((oid + '\n').encode())
    batch.stdin.flush()
    got_oid, kind, length = batch.stdout.readline().decode().strip().split()
    assert got_oid == oid and kind == 'blob'
    left = int(length)
    total_bytes += left
    h = hashlib.sha256()
    while left:
        chunk = batch.stdout.read(min(left, 1024 * 1024))
        assert chunk
        h.update(chunk)
        left -= len(chunk)
    assert batch.stdout.read(1) == b'\n'
    assert h.hexdigest() == expected_hash, oid
batch.stdin.close()
assert batch.wait() == 0

result = {
    'status': 'PASS', 'check': 'Complete historical selection byte and mode equivalence',
    'integration_base': BASE, 'historical_layout_base': after['base'],
    'before_source_map_sha256': hashlib.sha256(before_bytes).hexdigest(),
    'after_source_map_sha256': hashlib.sha256(after_bytes).hexdigest(),
    'mapped_paths': len(records), 'unique_hashed_blobs': len(objects),
    'unique_blob_bytes_hashed': total_bytes,
    'changed_selectors': sum(r['before_selected'] != r['after_selected'] for r in records),
    'changed_selected_bytes_or_modes': 0,
    'method': 'All before/after selected Git blob identities and modes compared; every unique selected blob streamed and independently SHA-256 checked. No historical compiler rerun is claimed.',
    'records': records,
}
(HERE / 'historical-selection-equivalence.json').write_text(json.dumps(result, indent=2) + '\n')
print(json.dumps({k: v for k, v in result.items() if k != 'records'}, indent=2))
