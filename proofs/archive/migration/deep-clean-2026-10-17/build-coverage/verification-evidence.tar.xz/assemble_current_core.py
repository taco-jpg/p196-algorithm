#!/usr/bin/env python3
"""Assemble the isolated Agent 3 repair from reviewed bytes and exact Git originals."""
from pathlib import Path
import hashlib
import io
import json
import subprocess
import tarfile

HERE = Path(__file__).resolve().parent
REPO = HERE.parent / 'p196-work'
BASELINE = '74a1c3922eb7af438fe40b23d2105ad07556e3f5'
BASE = 'ed5202b2839b5fedf3d97309481ac7a4bd556675'
DEST = REPO / 'proofs/archive/migration/deep-clean-2026-10-17/build-coverage'


def sha(data):
    return hashlib.sha256(data).hexdigest()


def git(*args):
    return subprocess.check_output(['git', *args], cwd=REPO)


def main():
    assert git('rev-parse', 'HEAD').decode().strip() == BASE
    assert not git('status', '--porcelain', '--untracked-files=no')
    DEST.mkdir(parents=True, exist_ok=False)
    paths = ['proofs/verify_project.py', 'proofs/ACCEPTED_BUILD.json',
             'proofs/README.md', 'proofs/SOURCE_MAP.json']
    originals = []
    archive = DEST / 'originals.tar.xz'
    with tarfile.open(archive, 'w:xz', preset=6) as tf:
        for commit, selected, prefix in [
            (BASELINE, paths, 'baseline'),
            (BASE, ['proofs/SOURCE_MAP.json'], 'integration-base'),
        ]:
            for path in selected:
                mode, kind, oid = git('ls-tree', commit, '--', path).decode().split('\t')[0].split()
                assert mode == '100644' and kind == 'blob'
                data = git('cat-file', 'blob', oid)
                member = f'{prefix}/{path}'
                info = tarfile.TarInfo(member)
                info.size, info.mode = len(data), 0o644
                info.mtime = info.uid = info.gid = 0
                tf.addfile(info, io.BytesIO(data))
                originals.append({'source_commit': commit, 'path': path, 'member': member,
                                  'mode': mode, 'git_blob': oid, 'bytes': len(data), 'sha256': sha(data)})
    with tarfile.open(archive, 'r:xz') as tf:
        assert len(tf.getmembers()) == len(originals)
        for record in originals:
            member = tf.getmember(record['member'])
            data = tf.extractfile(member).read()
            assert member.isfile() and member.mode == 0o644
            assert len(data) == record['bytes'] and sha(data) == record['sha256']
            assert data == git('cat-file', 'blob', record['git_blob'])
    manifest = {
        'campaign_id': 'deep-clean-2026-10-17',
        'scope': 'Current-tree build wiring; no mathematical source changed',
        'baseline_commit': BASELINE, 'integration_base_commit': BASE,
        'archive': archive.name, 'archive_sha256': sha(archive.read_bytes()),
        'archive_bytes': archive.stat().st_size, 'originals': originals,
        'unchanged_baseline_paths_at_integration_base': paths[:3],
        'restoration_status': 'Author byte/mode/member comparison passed; independent fresh extraction is a separate receipt.',
        'external_global_backup_status': 'Coordinator-owned external upload blocked by automatic approval review at assembly; no durable-baseline certification.',
    }
    for path in paths[:3]:
        assert git('show', f'{BASELINE}:{path}') == git('show', f'{BASE}:{path}')
    (DEST / 'originals-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')

    candidates = {
        'proofs/verify_project.py': ('verify_project_final.py', 'be5bb3fd12cccec307ce83329985dc1b1180c160272f532fd8fe949f666dd457'),
        'proofs/ACCEPTED_BUILD.json': ('core-direct-final-registry.json', 'a93cc006dca408fc357441d37d8ab4718970b3ab16f7ff1acaee8a16cdb9845b'),
        'proofs/README.md': ('core-readme-candidate.md', '1d75dac15ba3d19befc8f17cb98ee94f2d0cfa713dcfcad05f763a8bab6b26dd'),
    }
    for target, (source, expected) in candidates.items():
        data = (HERE / source).read_bytes()
        assert sha(data) == expected
        (REPO / target).write_bytes(data)

    map_path = REPO / 'proofs/SOURCE_MAP.json'
    before_bytes = git('show', f'{BASE}:proofs/SOURCE_MAP.json')
    before = json.loads(before_bytes)
    old_selector = b'"current": "proofs/ACCEPTED_BUILD.json"'
    assert before_bytes.count(old_selector) == 1
    after_bytes = before_bytes.replace(old_selector, b'"current": null', 1)
    after = json.loads(after_bytes)
    expected = json.loads(before_bytes)
    expected['paths']['proofs/ACCEPTED_BUILD.json']['current'] = None
    assert after == expected
    assert after['paths']['proofs/REPORTS.md']['current'] is None
    map_path.write_bytes(after_bytes)

    context = {
        'campaign_id': 'deep-clean-2026-10-17', 'session': 'agent-3-b09751a92b96',
        'tested_source_base': BASELINE, 'integration_base': BASE,
        'source_map_before_sha256': sha(before_bytes), 'source_map_after_sha256': sha(after_bytes),
        'source_map_changed_row': 'proofs/ACCEPTED_BUILD.json.current',
        'source_map_change': {'from': 'proofs/ACCEPTED_BUILD.json', 'to': None},
        'pr160_reports_selector_preserved': after['paths']['proofs/REPORTS.md']['current'] is None,
        'final_files': {path: {'sha256': sha((REPO / path).read_bytes()), 'bytes': (REPO / path).stat().st_size} for path in paths},
        'effective_proof_context_unchanged': True,
        'core_sources': [],
    }
    registry = json.loads((REPO / 'proofs/ACCEPTED_BUILD.json').read_bytes())
    for module, record in registry['projects']['consolidation-core']['modules'].items():
        data = git('show', f'{BASE}:{record["path"]}')
        mode, kind, oid = git('ls-tree', BASE, '--', record['path']).decode().split('\t')[0].split()
        assert sha(data) == record['sha256'] and oid == record['git_blob'] and mode == '100644'
        assert data == git('show', f'{BASELINE}:{record["path"]}')
        context['core_sources'].append({'module': module, 'path': record['path'], 'git_blob': oid,
                                        'sha256': sha(data), 'mode': mode})
    (HERE / 'installed-core-context.json').write_text(json.dumps(context, indent=2) + '\n')
    print(json.dumps({key: context[key] for key in context if key != 'core_sources'}, indent=2))
    print('Originals archive:', archive.stat().st_size, sha(archive.read_bytes()))


if __name__ == '__main__':
    main()
