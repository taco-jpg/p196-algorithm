#!/usr/bin/env python3
"""Reproduce the exact initially executed verifier and registry input bytes."""
from pathlib import Path
import argparse
import hashlib
import importlib.util
import sys

here = Path(__file__).resolve().parent
parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--checkout', type=Path, required=True)
parser.add_argument('--lean', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
candidate = here / 'verify_project_candidate.py'
registry = here / 'core-direct-candidate-registry.json'
for path, expected in [
    (candidate, 'bd3381cd90c0c524e5f1b8951b7cc3835f9c4ce2df0344d0f3a305bf6105cc43'),
    (registry, '1e464406672e3cd9ff4caa0aa9c0c5855956a10d04956bfea68662c7ab337c75'),
]:
    if hashlib.sha256(path.read_bytes()).hexdigest() != expected:
        raise SystemExit('Input hash mismatch: ' + str(path))
spec = importlib.util.spec_from_file_location('executed_verifier', candidate)
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.ROOT = args.checkout.resolve()
sys.argv = [str(candidate), '--lean', str(args.lean.resolve()), '--registry', str(registry),
            '--project', 'consolidation-core', '--output', str(args.output.resolve())]
raise SystemExit(module.main())
