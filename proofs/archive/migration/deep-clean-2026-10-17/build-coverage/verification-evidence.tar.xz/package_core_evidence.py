#!/usr/bin/env python3
"""Preserve reviewed input versions and complete substantive core execution evidence."""
from pathlib import Path
import hashlib
import io
import json
import tarfile

HERE = Path(__file__).resolve().parent
DEST = HERE.parent / 'p196-work/proofs/archive/migration/deep-clean-2026-10-17/build-coverage'
DIRECTORIES = [
    'core-strict-candidate-1', 'baseline-source-check', 'final-source-check',
    'incomplete-catalogue-check', 'legacy-registry-check', 'reject-trust-bypass',
    'installed-source-check', 'review-direct-core', 'core-preservation',
]
FILES = [
    'EVIDENCE.md', 'replay_executed_candidate.py', 'assemble_current_core.py',
    'verify_historical_selection.py', 'package_core_evidence.py',
    'verify_project_candidate.py', 'verify_project_final.py',
    'core-direct-baseline-registry.json', 'core-direct-candidate-registry.json',
    'core-direct-final-registry.json', 'core-readme-candidate.md',
    'invalid-trust-registry.json', 'entrypoint-checks.json',
    'core-38-path-closure.json', 'installed-core-context.json',
    'historical-selection-equivalence.json', 'verifier-candidate.diff',
    'review-preservation/originals-restoration-review.json',
    'review-preservation/pr160-source-map-review.json',
    'review-preservation/integration-base-core-context.json',
    'review-preservation/final-originals-restoration-review.json',
    'review-preservation/installed-four-path-review.json',
    'review-preservation/installed-reviewed-file-identities.json',
]


def sha(data):
    return hashlib.sha256(data).hexdigest()


def main():
    selected = set(FILES)
    for name in DIRECTORIES:
        for path in (HERE / name).rglob('*'):
            if path.is_file() and path.suffix not in ('.olean', '.pyc') and '__pycache__' not in path.parts:
                selected.add(str(path.relative_to(HERE)))
    missing = [name for name in selected if not (HERE / name).is_file()]
    if missing:
        raise SystemExit('Missing frozen evidence inputs: ' + repr(missing))
    archive = DEST / 'verification-evidence.tar.xz'
    if archive.exists():
        raise SystemExit('Refusing to overwrite existing evidence archive')
    records = []
    with tarfile.open(archive, 'w:xz', preset=6) as tf:
        for name in sorted(selected):
            path = HERE / name
            assert not path.is_symlink()
            data = path.read_bytes()
            info = tarfile.TarInfo(name)
            info.size, info.mode = len(data), 0o644
            info.mtime = info.uid = info.gid = 0
            tf.addfile(info, io.BytesIO(data))
            records.append({'member': name, 'bytes': len(data), 'sha256': sha(data), 'mode': '100644'})
    with tarfile.open(archive, 'r:xz') as tf:
        members = tf.getmembers()
        assert len(members) == len(records)
        for member, record in zip(members, records):
            assert member.isfile() and member.mode == 0o644 and member.name == record['member']
            restored = tf.extractfile(member).read()
            assert len(restored) == record['bytes'] and sha(restored) == record['sha256']
            assert restored == (HERE / record['member']).read_bytes(), record['member']
    manifest = {
        'campaign_id': 'deep-clean-2026-10-17', 'scope': 'consolidation-core, 38 pinned source modules',
        'contributor': 'Agent #3 / agent-3-b09751a92b96',
        'archive': archive.name, 'archive_sha256': sha(archive.read_bytes()),
        'archive_bytes': archive.stat().st_size,
        'member_count': len(records), 'uncompressed_member_bytes': sum(r['bytes'] for r in records),
        'member_modes': 'Preservation container files normalized to regular 100644; original Git modes are separately recorded and verified in originals-manifest.json.',
        'excluded_reproducible_infrastructure': ['Compiled .olean objects', 'Python .pyc/__pycache__'],
        'excluded_mathematical_or_substantive_evidence': [],
        'tested_source_base': '74a1c3922eb7af438fe40b23d2105ad07556e3f5',
        'integration_base': 'ed5202b2839b5fedf3d97309481ac7a4bd556675',
        'actual_execution': {
            'report': 'core-strict-candidate-1/verification.json',
            'report_sha256': '88eb39938a20f8cc5db667c08179f9c33abe20cf92504dc26a01c52169a712c3',
            'runner_sha256': 'bd3381cd90c0c524e5f1b8951b7cc3835f9c4ce2df0344d0f3a305bf6105cc43',
            'registry_sha256': '1e464406672e3cd9ff4caa0aa9c0c5855956a10d04956bfea68662c7ab337c75',
            'commands_exited_zero': 41, 'theorems': 3491, 'kernel_safe_constants': 3843,
            'separate_consumer_endpoints': 25, 'repository_wide_pass': False,
        },
        'final_input_reuse': {
            'runner_sha256': 'be5bb3fd12cccec307ce83329985dc1b1180c160272f532fd8fe949f666dd457',
            'registry_sha256': 'a93cc006dca408fc357441d37d8ab4718970b3ab16f7ff1acaee8a16cdb9845b',
            'independent_qualification': 'review-direct-core/REVIEW.json',
            'qualification': 'Unchanged mathematical source/import/root/adapter/claim/compiler/audit context; later metadata and input-compatibility corrections explicitly distinguished from actual run inputs.',
        },
        'author_archive_roundtrip': 'PASS: all members, modes, hashes and source bytes checked after compression',
        'members': records,
    }
    (DEST / 'verification-evidence-manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
    print(json.dumps({k: v for k, v in manifest.items() if k != 'members'}, indent=2))


if __name__ == '__main__':
    main()
