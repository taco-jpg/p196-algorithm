# Current-tree core build repair: execution evidence

Campaign: `deep-clean-2026-10-17`; contributor: Agent #3,
`agent-3-b09751a92b96`. Original verifier and registry attribution is retained.

## What actually ran

`core-strict-candidate-1/verification.json` records the fresh author-run Lean
4.19.0 execution against source base
`74a1c3922eb7af438fe40b23d2105ad07556e3f5`. It used the exact adjacent
`verify_project_candidate.py` and `core-direct-candidate-registry.json` bytes,
loaded outside the checkout with `ROOT` explicitly set to the source checkout.
The source checkout was clean; the candidate was not a committed source at that
time. This record must not be described as a run of the later final file bytes.

All 41 compiler commands exited zero with `--trust=0 -j1 -DElab.async=false`:
38 source compilations, one generated aggregate, one separately located consumer,
and one full audit. The audit reports 3,491 theorems and 3,843 kernel-safe
constants, with a structural interface record for every such constant. The
transitive axiom union is exactly `Classical.choice`, `Quot.sound`, and `propext`.

The independent reviewer inspected the implementation, every retained execution
hash, source and compiler identities, complete historical theorem-name/module/
axiom equality, and the 25 consumer signatures. The reviewer did not execute a
second full build. The historical original audit remains in the captured Git
history; its identity and parsed complete mapping are retained in the review.

## Later corrections and current-base binding

The final runner `verify_project_final.py` differs only in accepting omitted or
exact legacy registry flags while always executing the hardcoded strict flags,
and in reporting declared and effective flags separately. The compilation,
consumer, and full audit code is unchanged. The final registry changes only
historical metadata and pointers from the initial direct-path candidate. Every
module, source identity, import, root, foundation adapter, claim, compiler policy,
and catalogue blocker in the proof context remains equal. The independent
`review-direct-core/REVIEW.json` explicitly qualifies this reuse.

`installed-source-check` ran the final ordinary checkout entry point against
integration base `ed5202b2839b5fedf3d97309481ac7a4bd556675` and the uncommitted
four-path repair. Its dirty-tree flag is intentional and its file identities
are recorded. It is a source/import check, not another Lean proof execution.
`installed-core-context.json` binds all 38 mathematical source blobs and modes
to both tested and integration bases.

The historical selection check verifies all 9,161 mapped paths, streams all
6,850 unique selected blobs (478,709,880 bytes), and compares SHA-256 and Git
modes. The only changed selector is the old registry's fallback to its archived
original. No selected historical byte or mode changes. PR160's REPORTS selector
is retained. This is preservation verification, not a historical compiler rerun.

## Retained failures and limited checks

The baseline direct-path source/import check, final source/import checks, default
incomplete-catalogue exit 2, legacy registry compatibility check, and intentionally
rejected `--trust=1` registry input remain separately labeled. The policy rejection
has exit 1 and retains its traceback; it is an expected negative validation result.
No source-only result is relabeled as a mathematical proof check.

The shared official toolchain was executed with the environment's approved
escalated process launch because its sandboxed launch reported `error: failed to
locate application`. This environment observation is not a Lean proof failure.
The compiler's actual version and five runtime file hashes are in the execution
reports. The reused official release archive SHA-256 is
`6fe3ce97a58f44e2b3567d455b994eacec5bfe9ae7774f2a573444480ba813fe`.

## Reproduce

The ordinary supported command is documented in the repaired `proofs/README.md`.
To rerun the precise initial candidate from this extracted evidence, use the
adjacent `replay_executed_candidate.py`, supplying a checkout with the pinned
mathematical sources, the official Lean binary, and a new output path:

```sh
python3 replay_executed_candidate.py \
  --checkout /absolute/path/to/p196-algorithm \
  --lean /absolute/path/to/lean-4.19.0-linux/bin/lean \
  --output /absolute/new/output
```

The helper verifies candidate and registry hashes before loading them. The
candidate independently verifies all source pins and the runtime. A different
checkout commit is not retroactively the recorded execution's commit, even when
the qualified source closure is unchanged.

Compiled `.olean` objects and Python cache files are reproducible build
infrastructure and are excluded from the evidence archive. Exact Lean sources,
generated aggregate/audit/consumer sources, all substantive logs, structural
interfaces, commands, exit statuses, input versions, and manifests are retained.
No existing evidence file or prior execution directory was overwritten.

## Scope and publication boundary

This is the 38-source `consolidation-core` scope. The accepted catalogue remains
incomplete, with its existing open blocker. No repository-wide PASS, semantic
source consolidation, branch retirement, or completion of the campaign follows
from this packet. The external global backup upload was blocked by automatic
approval review at packaging; this local Git-backed repair does not certify that
separate durable baseline. Publication and actual remote readback belong to the
coordinator's serialized delivery record.
