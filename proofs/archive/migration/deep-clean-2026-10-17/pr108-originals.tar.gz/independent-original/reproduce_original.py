#!/usr/bin/env python3
"""Independent exact-source PR108 baseline reproduction; never edits proof source."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import time

ROOT = Path(__file__).resolve().parent
LEAN = ROOT.parent / 'toolchains/lean-4.19.0-linux/bin/lean'
OUT = ROOT / 'original-clean-build-v1'
OUT.mkdir(exist_ok=False)
SOURCE = OUT / 'source'
SOURCE.mkdir()
LOGS = OUT / 'logs'
LOGS.mkdir()
os.sched_setaffinity(0, {min(os.sched_getaffinity(0))})
contribution = ROOT / 'head/proofs/contributions/agent-113/descending-prefix-maximality-20261016'
inputs = [
    ROOT / 'baseline/proofs/research/continuation/LychrelDigitSums.lean',
    ROOT / 'baseline/proofs/contributions/agent-113/two-digit-prefix/TwoDigitProjection.lean',
    contribution / 'Agent113TripleCycles.lean',
    contribution / 'Agent113TripleRepeat.lean',
]
hashes = [
    'ca5f46523b7cff02c00918b6466a97963087b499fb5f184232b8b3d806dc0b57',
    '712e7df580b6cfc455aa159ba844487189984f54c738353984820f24bd8ed279',
    '9edf6d08e30fd996c7243b59c1b0b80082f46d1d56622ce81fee7419faf5d3f7',
    '942054efb7b6d45180049649480fcda3e98971292badbbdb199f4a69bb8fbcc6',
]
report = {
    'scope': 'Independent reproduction of unchanged published PR108 failure; not approval',
    'source_head': '6deb8522c14fa2127d5d565bafec0cff781ccdd3',
    'dependency_commit': '2eb05ef47671d6b1883e54fec9f6a4f8de9ed8f5',
    'toolchain': json.loads((ROOT.parent / 'toolchains/runtime-identity.json').read_text()),
    'cpu_affinity': sorted(os.sched_getaffinity(0)),
    'sources': [],
    'commands': [],
    'status': 'RUNNING',
}
for path, expected in zip(inputs, hashes):
    data = path.read_bytes()
    actual = hashlib.sha256(data).hexdigest()
    assert actual == expected, path
    (SOURCE / path.name).write_bytes(data)
    report['sources'].append({'original': str(path), 'build': path.name, 'sha256': actual})

def save():
    (OUT / 'report.json').write_text(json.dumps(report, indent=2) + '\n')

save()
env = {'PATH': str(LEAN.parent) + ':/usr/bin:/bin', 'LANG': 'C.UTF-8', 'LEAN_PATH': str(SOURCE)}
for path in inputs:
    name = path.stem
    args = [str(LEAN), '-j1', '-DElab.async=false', '--trust=0', '-o', name + '.olean', name + '.lean']
    start = time.monotonic()
    with (LOGS / (name + '.log')).open('wb') as stream:
        result = subprocess.run(args, cwd=SOURCE, env=env, stdout=stream, stderr=subprocess.STDOUT)
    data = (LOGS / (name + '.log')).read_bytes()
    report['commands'].append({'argv': args, 'exit_code': result.returncode,
        'elapsed_seconds': round(time.monotonic() - start, 6),
        'log': str(LOGS / (name + '.log')), 'log_sha256': hashlib.sha256(data).hexdigest()})
    print(name, 'exit', result.returncode, flush=True)
    save()
    if result.returncode:
        report['status'] = 'ORIGINAL_FAILURE_REPRODUCED' if name == 'Agent113TripleRepeat' and b'112:8: error: no goals to be solved' in data and b'sorryAx' in data else 'UNEXPECTED_FAILURE'
        break
else:
    report['status'] = 'UNEXPECTED_ORIGINAL_PASS'
for record in report['sources']:
    assert hashlib.sha256(Path(record['original']).read_bytes()).hexdigest() == record['sha256']
    assert hashlib.sha256((SOURCE / record['build']).read_bytes()).hexdigest() == record['sha256']
save()
print(report['status'], flush=True)
