#!/usr/bin/env python3
"""Package exact PR108 execution evidence without compiled infrastructure."""
from __future__ import annotations

import gzip
import hashlib
import io
import json
from pathlib import Path
import stat
import subprocess
import tarfile

WORK = Path('/workspace/scratch/a4d0d7a022a0')
REPO = WORK / 'pr108-work'
REVIEW = WORK / 'independent-pr108'
FROZEN = '98a41cdf9a86918533c4798e668e3c15bfe86b71'
PACKAGE = Path('proofs/contributions/agent-113/descending-prefix-maximality-20261016')
ARCHIVE = Path('proofs/archive/migration/deep-clean-2026-10-17/pr108-verification.tar.gz')

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

members: dict[str, tuple[bytes, int, dict]] = {}

def add_file(path: Path, name: str, classification: str) -> None:
    assert path.is_file() and not path.is_symlink(), path
    data = path.read_bytes()
    mode = stat.S_IMODE(path.stat().st_mode)
    assert name not in members, name
    members[name] = (data, mode, {
        'source_path': str(path.relative_to(WORK)),
        'classification': classification,
    })

for path in sorted((REVIEW / 'repaired-clean-v1').rglob('*')):
    if not path.is_file() or path.suffix in {'.olean', '.ilean', '.pyc'} or '__pycache__' in path.parts:
        continue
    add_file(path, 'execution/' + path.relative_to(REVIEW / 'repaired-clean-v1').as_posix(),
             'Actual fresh independent four-module strict execution')

already_preserved = {
    'artifact12077732963.zip', 'artifact12078265043.zip',
    'inspection.json', 'job117217088762.log', 'reproduce_original.py',
}
for path in sorted(REVIEW.iterdir()):
    if path.is_file() and path.name not in already_preserved:
        add_file(path, 'independent-review/' + path.name, 'Independent review or original inspection result')

frozen_paths = [
    PACKAGE / 'verify.py', PACKAGE / 'README.md', PACKAGE / 'ORIGINALS.json',
    Path('.github/workflows/agent113-triple-cycles.yml'),
    Path('proofs/verify_project__214bf7673efe116b.py'),
]
for path in frozen_paths:
    data = subprocess.check_output(['git', 'show', f'{FROZEN}:{path.as_posix()}'], cwd=REPO)
    entry = subprocess.check_output(['git', 'ls-tree', FROZEN, '--', path.as_posix()], cwd=REPO, text=True)
    git_mode, _, blob_and_path = entry.strip().split(' ', 2)
    blob = blob_and_path.split('\t', 1)[0]
    members['frozen-control/' + path.as_posix()] = (data, int(git_mode[-3:], 8), {
        'source_commit': FROZEN, 'source_path': path.as_posix(),
        'git_blob': blob, 'git_mode': git_mode,
        'classification': 'Exact control/documentation bytes inspected during independent execution',
    })

add_file(WORK / 'campaign-state/pr108-platform-preflight.json',
         'publication-preparation/platform-preflight.json', 'Timestamped public platform observation; no platform PASS claim')
add_file(Path(__file__).resolve(), 'publication-preparation/package_pr108.py', 'Evidence packaging reproducer')

manifest = {
    'schema_version': 1,
    'campaign': 'deep-clean-2026-10-17',
    'contribution': 'PR108',
    'status': 'PASS_LOCAL_SCOPED_ACCEPTANCE',
    'original_source_head': '6deb8522c14fa2127d5d565bafec0cff781ccdd3',
    'tested_candidate_commit': FROZEN,
    'reviewer': '/root/pr108_review',
    'repository_wide_pass': False,
    'remote_publication_or_merge_claimed': False,
    'verification_level': 'Fresh four-module trust-zero build, complete safe declaration audit, exact finite replay, separate 42-export consumer, independent original preservation restoration',
    'archive_path': ARCHIVE.as_posix(),
    'members': {},
    'recovery': 'Extract to a new empty directory and independently compare every member path, size, SHA256 and mode with this manifest. Execution/FILES.json supplies the execution producer pins; independent-review contains separate checks. The original failed source and workflow ZIPs remain in pr108-originals.tar.gz with ORIGINALS.json.',
    'excluded': 'Only reproducible compiled .olean/.ilean objects, Python caches, source checkouts already bound by source snapshots, and runtime installations. Exact substantive source/log/review bytes are retained.',
    'effective_context_reuse': 'The subsequent README, destination-map and original job-name amendments do not change proof, dependency, generator, registry or runner inputs. Finalization review separately validates those amendments. No remote or full-main success is inferred.',
}

target = REPO / ARCHIVE
target.parent.mkdir(parents=True, exist_ok=True)
with target.open('wb') as raw:
    with gzip.GzipFile(fileobj=raw, mode='wb', mtime=0, filename='') as compressed:
        with tarfile.open(fileobj=compressed, mode='w', format=tarfile.PAX_FORMAT) as tar:
            for name, (data, mode, provenance) in sorted(members.items()):
                info = tarfile.TarInfo(name)
                info.size, info.mode, info.mtime = len(data), mode, 0
                tar.addfile(info, io.BytesIO(data))
                manifest['members'][name] = {
                    'bytes': len(data), 'sha256': sha(data),
                    'mode': format(mode, '04o'), **provenance,
                }
archive_data = target.read_bytes()
manifest.update(archive_bytes=len(archive_data), archive_sha256=sha(archive_data), member_count=len(members))
(REPO / PACKAGE / 'VERIFICATION.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps({k: manifest[k] for k in ['archive_path', 'archive_bytes', 'archive_sha256', 'member_count']}))
