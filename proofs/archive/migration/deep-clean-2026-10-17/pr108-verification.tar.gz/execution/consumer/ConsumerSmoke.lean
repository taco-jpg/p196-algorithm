import Agent113TripleRepeat
#check Agent113.TripleMaximality.cycle01
#print axioms Agent113.TripleMaximality.cycle01
#check Agent113.TripleMaximality.cycle12
#print axioms Agent113.TripleMaximality.cycle12
#check Agent113.TripleMaximality.cycle23
#print axioms Agent113.TripleMaximality.cycle23
#check Agent113.TripleMaximality.cycle30
#print axioms Agent113.TripleMaximality.cycle30
#check Agent113.TripleMaximality.path21_valid
#print axioms Agent113.TripleMaximality.path21_valid
#check Agent113.TripleMaximality.path30_valid
#print axioms Agent113.TripleMaximality.path30_valid
#check Agent113.TripleMaximality.path31_valid
#print axioms Agent113.TripleMaximality.path31_valid
#check Agent113.TripleMaximality.path42_valid
#print axioms Agent113.TripleMaximality.path42_valid
#check Agent113.TripleMaximality.path43_valid
#print axioms Agent113.TripleMaximality.path43_valid
#check Agent113.TripleMaximality.path50_valid
#print axioms Agent113.TripleMaximality.path50_valid
#check Agent113.TripleMaximality.path51_valid
#print axioms Agent113.TripleMaximality.path51_valid
#check Agent113.TripleMaximality.path52_valid
#print axioms Agent113.TripleMaximality.path52_valid
#check Agent113.TripleMaximality.path53_valid
#print axioms Agent113.TripleMaximality.path53_valid
#check Agent113.TripleMaximality.path54_valid
#print axioms Agent113.TripleMaximality.path54_valid
#check Agent113.TripleMaximality.path61_valid
#print axioms Agent113.TripleMaximality.path61_valid
#check Agent113.TripleMaximality.path62_valid
#print axioms Agent113.TripleMaximality.path62_valid
#check Agent113.TripleMaximality.path63_valid
#print axioms Agent113.TripleMaximality.path63_valid
#check Agent113.TripleMaximality.path70_valid
#print axioms Agent113.TripleMaximality.path70_valid
#check Agent113.TripleMaximality.path71_valid
#print axioms Agent113.TripleMaximality.path71_valid
#check Agent113.TripleMaximality.path72_valid
#print axioms Agent113.TripleMaximality.path72_valid
#check Agent113.TripleMaximality.path73_valid
#print axioms Agent113.TripleMaximality.path73_valid
#check Agent113.TripleMaximality.path74_valid
#print axioms Agent113.TripleMaximality.path74_valid
#check Agent113.TripleMaximality.path75_valid
#print axioms Agent113.TripleMaximality.path75_valid
#check Agent113.TripleMaximality.path84_valid
#print axioms Agent113.TripleMaximality.path84_valid
#check Agent113.TripleMaximality.path85_valid
#print axioms Agent113.TripleMaximality.path85_valid
#check Agent113.TripleMaximality.path86_valid
#print axioms Agent113.TripleMaximality.path86_valid
#check Agent113.TripleMaximality.path87_valid
#print axioms Agent113.TripleMaximality.path87_valid
#check Agent113.TripleMaximality.path90_valid
#print axioms Agent113.TripleMaximality.path90_valid
#check Agent113.TripleMaximality.path91_valid
#print axioms Agent113.TripleMaximality.path91_valid
#check Agent113.TripleMaximality.path92_valid
#print axioms Agent113.TripleMaximality.path92_valid
#check Agent113.TripleMaximality.path93_valid
#print axioms Agent113.TripleMaximality.path93_valid
#check Agent113.TripleMaximality.path94_valid
#print axioms Agent113.TripleMaximality.path94_valid
#check Agent113.TripleMaximality.path95_valid
#print axioms Agent113.TripleMaximality.path95_valid
#check Agent113.TripleMaximality.path96_valid
#print axioms Agent113.TripleMaximality.path96_valid
#check Agent113.TripleMaximality.path97_valid
#print axioms Agent113.TripleMaximality.path97_valid
#check Agent113.TripleMaximality.path98_valid
#print axioms Agent113.TripleMaximality.path98_valid
#check Agent113.TripleMaximality.cover_descending_45
#print axioms Agent113.TripleMaximality.cover_descending_45
#check Agent113.TripleMaximality.remaining32_path_exists
#print axioms Agent113.TripleMaximality.remaining32_path_exists
#check Agent113.TripleMaximality.cycle_unbounded
#print axioms Agent113.TripleMaximality.cycle_unbounded
#check Agent113.TripleMaximality.extend_chain
#print axioms Agent113.TripleMaximality.extend_chain
#check Agent113.TripleMaximality.extend_first
#print axioms Agent113.TripleMaximality.extend_first
#check Agent113.TripleMaximality.all_32_unbounded_inverse_layers
#print axioms Agent113.TripleMaximality.all_32_unbounded_inverse_layers
