import Agent113TripleRepeat
import Lean
open Lean Elab Command
set_option maxRecDepth 100000
set_option maxHeartbeats 0
run_cmd do
  let env ← getEnv
  let selected : List String := ["LychrelDigitSums", "TwoDigitProjection", "Agent113TripleCycles", "Agent113TripleRepeat"]
  let allowed : List Name := [``propext, ``Classical.choice, ``Quot.sound]
  let mut safeCount := 0
  let mut implementationCount := 0
  for (name, info) in env.constants.toList do
    if let some idx := env.getModuleIdxFor? name then
      let mod := env.allImportedModuleNames[idx.toNat]!
      if selected.contains mod.toString then
        if info.isUnsafe || info.isPartial then
          implementationCount := implementationCount + 1
          logInfo m!"AUDIT_IMPLEMENTATION {mod} {name} unsafe={info.isUnsafe} partial={info.isPartial}"
        else
          if let .axiomInfo _ := info then
            throwError m!"CUSTOM_AXIOM {mod} {name}"
          let kind := match info with
            | .thmInfo _ => "theorem"
            | .defnInfo _ => "definition"
            | .opaqueInfo _ => "opaque"
            | .inductInfo _ => "inductive"
            | .ctorInfo _ => "constructor"
            | .recInfo _ => "recursor"
            | .quotInfo _ => "quotient"
            | .axiomInfo _ => "axiom"
          let axs ← liftCoreM (Lean.collectAxioms name)
          let axl := axs.toList
          if axl.any (fun ax => !(allowed.contains ax)) then
            throwError m!"DISALLOWED_AXIOMS {mod} {name} : {axl}"
          safeCount := safeCount + 1
          logInfo m!"AUDIT_SAFE {mod} {name} {kind} : {axl}"
  logInfo m!"FULL_MODULE_AUDIT safe={safeCount} implementation={implementationCount}"
