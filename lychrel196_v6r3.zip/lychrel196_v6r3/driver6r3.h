// driver6r3.h - host logic shared by cuda196_v6r3 (GPU) and emu196_v6r3 (CPU emulator). Same as driver6r2.h except names.
//
// BENCH MODE (same positional arguments as v4 / old main.cu):
//   PROG INPUT STEPS OUTPUT [START_ITER=0] [K=256] [CHECKPOINT_INTERVAL=0] [--mode=tb|step] [--tile=W]
//        [--halo=W] [--window=S] [--batch=B]
// RUN MODE (one long-lived process, checkpoints written by a background thread):
//   PROG run INPUT START_ITER OUTDIR [--chunk=20000] [--steps=0(forever)] [--keep=3] [same options]
//   writes OUTDIR/checkpoint_<iter>.txt and OUTDIR/latest.json (same fields as run_forever.py).
//
// Exactness: tb windows are verified (certification + palindrome counts); any failure or flag
// restores the window's backup and replays it with the GPU-validated v4 per-step kernel.
#pragma once
#include <algorithm>
#include <atomic>
#include <chrono>
#include <climits>
#include <csignal>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <deque>
#include <fstream>
#include <stdexcept>
#include <string>
#include <thread>
#include <vector>
#include "bits_tb6r3.h"
#include "sha256.h"

namespace d5 {
using bits::u32;
using Clock = std::chrono::steady_clock;
static const long long MAX_DIGITS = INT_MAX - 65536;  // 32-bit pair indices: ~2.147e9 digits
static double secs(Clock::time_point a) { return std::chrono::duration<double>(Clock::now() - a).count(); }

inline std::string readNumber(const std::string& f) {
  if (f == "196") return "196";
  std::ifstream in(f, std::ios::binary);
  if (!in) throw std::runtime_error("cannot open input " + f);
  std::string s;
  std::getline(in, s);
  while (!s.empty() && (s.back() == '\r' || s.back() == ' ')) s.pop_back();
  if (s.empty() || s[0] == '0' || s.find_first_not_of("0123456789") != std::string::npos)
    throw std::runtime_error("input must be a positive decimal without leading zeros");
  return s;
}
inline std::vector<u32> encode(const std::string& s, int Wcap) {
  int n = (int)s.size(), h = (n + 1) / 2;
  std::vector<u32> pl(5 * (size_t)Wcap, 0);
  for (int j = 0; j < h; ++j) {
    int v = (s[n - 1 - j] - '0') + (s[j] - '0');
    for (int q = 0; q < 5; ++q)
      if ((v >> q) & 1) pl[(size_t)q * Wcap + (j >> 5)] |= 1u << (j & 31);
  }
  return pl;
}
// pairs of N_k (bit-planes, n digits) -> decimal N_{k+1}; throws if inconsistent
inline std::string materializeNext(const std::vector<u32>& pl, int Wcap /*plane stride*/, int n) {
  int h = (n + 1) / 2;
  std::vector<uint8_t> S(h);
  for (int j = 0; j < h; ++j) {
    int v = 0;
    for (int q = 0; q < 5; ++q) v |= (int)((pl[(size_t)q * Wcap + (j >> 5)] >> (j & 31)) & 1u) << q;
    if (v > 18) throw std::runtime_error("corrupt state: pair sum > 18");
    S[j] = (uint8_t)v;
  }
  int c = 0;
  std::string v(n + 1, '0');
  for (int i = 0; i < n; ++i) {
    int a = S[i < n - 1 - i ? i : n - 1 - i] + c;
    v[n - i] = char('0' + a % 10);
    c = a / 10;
  }
  if (c) { v[0] = '1'; return v; }
  return v.substr(1);
}
inline bool isPalindrome(const std::string& s) {
  for (size_t i = 0, j = s.size() - 1; i < j; ++i, --j) if (s[i] != s[j]) return false;
  return true;
}
inline void writeFileAtomic(const std::string& f, const std::string& s, bool newline = true) {
  std::string tmp = f + ".tmp";
  {
    std::ofstream out(tmp, std::ios::binary);
    if (!out) throw std::runtime_error("cannot write " + tmp);
    out << s;
    if (newline) out << '\n';
    out.flush();
    if (!out) throw std::runtime_error("write failed " + tmp);
  }
  if (std::rename(tmp.c_str(), f.c_str())) throw std::runtime_error("rename failed " + f);
}

struct Opts {
  std::string mode = "tb";
  int K = 256, tile = 0, halo = 0, window = 0, batch = 64, keep = 3;
  long long chunk = 20000, runSteps = 0;
};
struct TBResult { int fail; long long palAt; int n; };

// Backend concept (cuda196_v5.cu / emu196_v5.cpp):
//   const char* name(); int numSMs(); int tbBlocksPerSM(size_t smem);
//   void init(const std::vector<u32>& planes, int n0, int Wcap, const tb::Conf& c, int batch);
//   void stepRun(int count, std::vector<unsigned>& bad, int gridWords);  // v4 kernel, synchronous
//   void tbLaunch(int k, long long baseIter, int blocks);      // asynchronous
//   TBResult tbSync();                                         // flags reset after reading
//   int currentN();
//   void backup(int words); void restore();                    // restore also clears the other buffer
//   void download(bool previous, std::vector<u32>& planes, int& stride, int& n);  // compact copy
//   double deviceSeconds();                                    // GPU event time of all step/tb launches
template <class BE>
struct Engine {
  BE& be;
  Opts o;
  tb::Conf conf{};
  int Wcap = 0, nHost = 0;
  long long it = 0, replays = 0, windows = 0;
  double computeSec = 0;
  explicit Engine(BE& b, const Opts& op) : be(b), o(op) {}

  void setup(const std::string& input, long long start, long long maxSteps) {
    if (o.K < 1 || o.K > tb::KMAX) throw std::runtime_error("K must be 1..1024");
    if (o.mode != "tb" && o.mode != "step") throw std::runtime_error("--mode must be tb or step");
    const int n0 = (int)input.size();
    long long maxDigits = (long long)n0 + maxSteps + 64;
    if (maxDigits > MAX_DIGITS) throw std::runtime_error("too many digits for 32-bit pair indices (limit ~2.147e9)");
    Wcap = (int)((maxDigits + 1) / 2 / 32) + 8 + (o.K / 64) + 4;
    conf.K = o.K;
    conf.HW = o.halo ? o.halo : tb::halo_words(o.K);
    if (conf.HW % 4) throw std::runtime_error("--halo must be a multiple of 4 words");
    conf.PW = tb::prefix_words(conf.HW);
    conf.plenMax = tb::plen_max(conf.PW, o.K);
    conf.Wcap = Wcap;
    conf.TW = o.tile ? o.tile : autoTile((n0 + 1) / 2);
    if (conf.TW < 4 || conf.TW % 4) throw std::runtime_error("--tile must be a positive multiple of 4 words");
    conf.lenMax = tb::len_max(conf.TW, conf.HW, o.K);
    if (!o.window) o.window = std::max(o.K, (8192 / o.K) * o.K);
    be.init(encode(input, Wcap), n0, Wcap, conf, o.batch);
    it = start;
    nHost = n0;
  }
  // Cost model: blocks on the busiest SM x words per block; all groups in one pass per step.
  int autoTile(int h) {
    const int W = (h + 31) / 32 + 1, sms = std::max(1, be.numSMs());
    int best = 64;
    double bestCost = 1e300;
    for (int TW = 32; TW <= 1 << 20; TW += 32) {
      tb::Conf c = conf; c.TW = TW; c.lenMax = tb::len_max(TW, conf.HW, o.K);
      // v6r: all tile + prefix groups in one pass over the worker threads
      if (c.lenMax / 4 + conf.plenMax / 4 > tb::num_workers(tb::THREADS)) break;
      int occ = be.tbBlocksPerSM(tb::smem_bytes(c));
      if (occ < 1) continue;
      long long blocks = (W + TW - 1) / TW;
      long long perSM = (blocks + sms - 1) / sms;
      long long waves = (blocks + (long long)sms * occ - 1) / ((long long)sms * occ);
      double cost = (double)perSM * (TW + 2 * conf.HW) * (waves > 1 ? 1.05 : 1.0);
      if (cost < bestCost) { bestCost = cost; best = TW; }
    }
    return best;
  }

  // words that can be non-zero for a number of n digits (+ margin used by the v4 kernel's skip rule)
  int wordsFor(long long n) const { return (int)std::min<long long>(Wcap, ((n + 2) / 2 + 32) / 32 + 2); }

  // v4 per-step kernel; returns p>0 if N_p is a palindrome (device state left at S_{p-1}).
  long long stepAdvance(long long m) {
    std::vector<unsigned> bad;
    const long long it0 = it;
    const int n0 = nHost;
    be.backup(wordsFor(nHost));  // one backup per call (v5 copied the state every batch)
    long long done = 0;
    while (done < m) {
      int cnt = (int)std::min<long long>(o.batch, m - done);
      be.stepRun(cnt, bad, wordsFor(n0 + done + cnt));
      int first = -1;
      for (int i = 0; i < cnt; ++i) if (!bad[i]) { first = i; break; }
      if (first >= 0) {  // N_{it0+done+first+1} is a palindrome: rebuild S_{p-1} exactly
        const long long off = done + first;
        be.restore();
        long long r = 0;
        while (r < off) {
          int c2 = (int)std::min<long long>(o.batch, off - r);
          be.stepRun(c2, bad, wordsFor(n0 + r + c2));
          r += c2;
        }
        it = it0 + off;
        nHost = be.currentN();
        return it + 1;
      }
      done += cnt;
    }
    it = it0 + m;
    nHost = be.currentN();
    return 0;
  }
  // Advance m steps exactly. Returns p>0 on a palindrome (state at S_{p-1}).
  long long advance(long long m) {
    auto t0 = Clock::now();
    long long p = 0;
    if (o.mode == "step") {
      long long done = 0;
      while (done < m && !p) {
        long long win = std::min<long long>(o.window, m - done);
        p = stepAdvance(win);
        done += win;
      }
    } else {
      long long done = 0;
      while (done < m && !p) {
        long long win = std::min<long long>(o.window, m - done);
        be.backup(wordsFor(nHost));
        long long w = 0;
        while (w < win) {
          int k = (int)std::min<long long>(o.K, win - w);
          long long hB = (nHost + w + k + 2) / 2 + 2;
          int blocks = (int)(((hB + 31) / 32 + 1 + conf.TW - 1) / conf.TW);
          be.tbLaunch(k, it + w, blocks);
          w += k;
        }
        TBResult r = be.tbSync();
        ++windows;
        if (r.fail || r.palAt >= 0) {
          be.restore();
          ++replays;
          fprintf(stderr, "[engine] %s in iterations %lld..%lld: exact replay with per-step kernel\n",
                  r.fail ? "certification failure" : "palindrome flag", it + 1, it + win);
          p = stepAdvance(win);
          if (!p && r.palAt >= 0 && !r.fail)
            throw std::runtime_error("time-blocked kernel flagged a palindrome that the exact replay did not");
        } else {
          it += win;
          nHost = r.n;
        }
        done += win;
      }
    }
    computeSec += secs(t0);
    return p;
  }
  // Advance to `target` and return N_target (decimal). p>0 means N_p palindrome found first.
  long long advanceTo(long long target, std::vector<u32>& prevPlanes, int& stride, int& prevN) {
    long long p = advance(target - 1 - it);
    if (p) return p;
    auto t0 = Clock::now();
    p = stepAdvance(1);  // keep S_{target-1} in the previous buffer
    computeSec += secs(t0);
    if (p) return p;
    be.download(true, prevPlanes, stride, prevN);
    return 0;
  }
  int reportPalindrome(long long p, const std::string& outPrefix) {
    std::vector<u32> pl; int n, stride;
    be.download(false, pl, stride, n);
    std::string N = materializeNext(pl, stride, n);
    std::string f = outPrefix + ".palindrome_" + std::to_string(p) + ".txt";
    writeFileAtomic(f, N);
    bool ok = isPalindrome(N);
    fprintf(stderr, "PALINDROME at iteration %lld digits=%zu cpu_check=%s file=%s\n", p, N.size(), ok ? "PASS" : "FAIL",
            f.c_str());
    return ok ? 3 : 2;
  }
};

inline void parseOpt(Opts& o, const std::string& a) {
  auto val = [&](const char* k) -> const char* {
    size_t L = strlen(k);
    return a.compare(0, L, k) == 0 ? a.c_str() + L : nullptr;
  };
  const char* v;
  if ((v = val("--mode="))) o.mode = v;
  else if ((v = val("--tile="))) o.tile = atoi(v);
  else if ((v = val("--halo="))) o.halo = atoi(v);
  else if ((v = val("--window="))) o.window = atoi(v);
  else if ((v = val("--batch="))) o.batch = atoi(v);
  else if ((v = val("--K="))) o.K = atoi(v);
  else if ((v = val("--keep="))) o.keep = atoi(v);
  else if ((v = val("--chunk="))) o.chunk = atoll(v);
  else if ((v = val("--steps="))) o.runSteps = atoll(v);
  else throw std::runtime_error("unknown option " + a);
}

static std::atomic<int> g_stop{0};
inline void onSignal(int) { g_stop = 1; }

template <class BE>
int benchMode(BE& be, std::vector<std::string> pos, Opts o) {
  if (pos.size() < 3) throw std::runtime_error("usage: INPUT STEPS OUTPUT [START] [K] [CHECKPOINT]");
  auto tAll = Clock::now();
  std::string input = readNumber(pos[0]);
  long long steps = std::stoll(pos[1]);
  std::string output = pos[2];
  long long start = pos.size() > 3 ? std::stoll(pos[3]) : 0;
  if (pos.size() > 4) { o.K = std::stoi(pos[4]); if (o.mode == "step") o.batch = o.K; }
  long long save = pos.size() > 5 ? std::stoll(pos[5]) : 0;
  if (steps < 1 || save < 0 || o.batch < 1) throw std::runtime_error("bad arguments");
  Engine<BE> E(be, o);
  E.setup(input, start, steps);
  double setupSec = secs(tAll);
  fprintf(stderr, "backend=%s mode=%s digits=%zu start=%lld steps=%lld K=%d tile=%d halo=%d window=%d batch=%d\n",
          be.name(), o.mode.c_str(), input.size(), start, steps, E.conf.K, E.conf.TW, E.conf.HW, E.o.window, o.batch);
  const long long end = start + steps;
  double ioSec = 0;
  while (E.it < end) {
    long long target = end;
    if (save) target = std::min(end, start + ((E.it - start) / save + 1) * save);
    std::vector<u32> pl; int n, stride;
    long long p = E.advanceTo(target, pl, stride, n);
    if (p) return E.reportPalindrome(p, output);
    auto t0 = Clock::now();
    std::string N = materializeNext(pl, stride, n);
    std::string f = target == end ? output : output + ".next_" + std::to_string(target) + ".txt";
    writeFileAtomic(f, N);
    ioSec += secs(t0);
    const double dev = be.deviceSeconds();
    fprintf(stderr, "iteration=%lld digits=%zu device_seconds=%.4f device_us_per_step=%.3f compute_seconds=%.4f "
            "us_per_step=%.3f io_seconds=%.4f setup_seconds=%.4f total_seconds=%.4f windows=%lld replays=%lld file=%s\n",
            target, N.size(), dev, 1e6 * dev / (target - start), E.computeSec, 1e6 * E.computeSec / (target - start),
            ioSec, setupSec, secs(tAll), E.windows, E.replays, f.c_str());
    if (isPalindrome(N)) { fprintf(stderr, "PALINDROME at iteration %lld (checkpoint value)\n", target); return 3; }
  }
  return 0;
}

template <class BE>
int runMode(BE& be, std::vector<std::string> pos, Opts o) {
  if (pos.size() < 3) throw std::runtime_error("usage: run INPUT START_ITER OUTDIR [--chunk=N] [--steps=N] [--keep=N]");
  std::string input = readNumber(pos[0]);
  long long start = std::stoll(pos[1]);
  std::string dir = pos[2];
  if (o.chunk < 1 || o.keep < 1) throw std::runtime_error("bad --chunk/--keep");
  if (system(("mkdir -p '" + dir + "'").c_str()) != 0) throw std::runtime_error("cannot create " + dir);
  // Size buffers for a long horizon; the process re-sizes by restarting from its own checkpoint.
  long long horizon = o.runSteps ? o.runSteps : 100000000LL;  // buffers sized for 100M steps; then resume
  horizon = std::min<long long>(horizon, MAX_DIGITS - (long long)input.size() - 4096);
  Engine<BE> E(be, o);
  E.setup(input, start, horizon);
  fprintf(stderr, "backend=%s mode=%s digits=%zu start=%lld chunk=%lld K=%d tile=%d halo=%d keep=%d horizon=%lld\n",
          be.name(), o.mode.c_str(), input.size(), start, o.chunk, E.conf.K, E.conf.TW, E.conf.HW, o.keep, horizon);
  std::signal(SIGINT, onSignal);
  std::signal(SIGTERM, onSignal);
  std::thread writer;
  std::deque<std::string> written;
  std::atomic<int> writerError{0};
  auto tRun = Clock::now();
  long long lastIt = start;
  double lastT = 0, lastDev = 0;
  const long long end = start + horizon;
  int rc = 0;
  while (E.it < end && !g_stop) {
    long long target = std::min(end, start + ((E.it - start) / o.chunk + 1) * o.chunk);
    std::vector<u32> pl; int n, stride;
    long long p = E.advanceTo(target, pl, stride, n);
    if (p) {
      if (writer.joinable()) writer.join();
      return E.reportPalindrome(p, dir + "/candidate");
    }
    if (writer.joinable()) writer.join();  // at most one checkpoint in flight
    if (writerError) { rc = 2; break; }
    double now = secs(tRun);
    double rate = (target - lastIt) / std::max(1e-9, now - lastT);
    const double devNow = be.deviceSeconds();
    const double devUs = 1e6 * (devNow - lastDev) / std::max<long long>(1, target - lastIt);
    lastIt = target; lastT = now; lastDev = devNow;
    writer = std::thread([&, target, n, stride, rate, devUs, pl = std::move(pl)]() {
      try {
        std::string N = materializeNext(pl, stride, n);
        if (isPalindrome(N)) fprintf(stderr, "PALINDROME at iteration %lld (checkpoint value)\n", target);
        std::string f = dir + "/checkpoint_" + std::to_string(target) + ".txt";
        writeFileAtomic(f, N);
        std::string hash = sha::hex(N);
        char json[1024];
        snprintf(json, sizeof json,
                 "{\"iteration\": %lld, \"digits\": %zu, \"sha256\": \"%s\", \"path\": \"%s\", "
                 "\"steps_per_second_last_chunk\": %.1f, \"device_us_per_step_last_chunk\": %.3f, \"engine\": \"%s\"}",
                 target, N.size(), hash.c_str(), f.c_str(), rate, devUs, "cuda196_v6r3");
        writeFileAtomic(dir + "/latest.json", json);
        printf("%s\n", json);
        fflush(stdout);
        written.push_back(f);
        while ((int)written.size() > o.keep) { std::remove(written.front().c_str()); written.pop_front(); }
      } catch (const std::exception& e) {
        fprintf(stderr, "checkpoint writer error: %s\n", e.what());
        writerError = 1;
      }
    });
  }
  if (writer.joinable()) writer.join();
  if (!g_stop && E.it >= end)
    fprintf(stderr, "buffer horizon reached at iteration %lld; restart run mode from latest.json\n", E.it);
  if (g_stop) fprintf(stderr, "stopped by signal after iteration %lld; resume from latest.json\n", lastIt);
  if (writerError) rc = 2;
  return rc;
}

template <class BE>
int mainEntry(BE& be, int argc, char** argv) {
  std::vector<std::string> pos;
  Opts o;
  for (int i = 1; i < argc; ++i) {
    std::string a = argv[i];
    if (a.rfind("--", 0) == 0) parseOpt(o, a);
    else pos.push_back(a);
  }
  if (pos.empty()) {
    fprintf(stderr,
            "bench: %s INPUT STEPS OUTPUT [START] [K=256] [CHECKPOINT] [--mode=tb|step] [--tile=W] [--halo=W] [--window=S] [--batch=B]\n"
            "run:   %s run INPUT START OUTDIR [--chunk=20000] [--steps=0] [--keep=3] [options]\n",
            argv[0], argv[0]);
    return 1;
  }
  if (pos[0] == "run") { pos.erase(pos.begin()); return runMode(be, pos, o); }
  return benchMode(be, pos, o);
}
}  // namespace d5
