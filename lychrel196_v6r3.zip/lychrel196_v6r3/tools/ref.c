// Plain schoolbook reverse-and-add reference: ref INPUT STEPS OUTPUT
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
int main(int c, char** v){ FILE*f=fopen(v[1],"r"); long steps=atol(v[2]);
 size_t cap=strlen("x")+ 64<<20; char*a=malloc(cap),*b=malloc(cap);
 if(!fgets(a,cap,f))return 1; size_t n=strcspn(a,"\r\n"); a[n]=0;
 for(long s=0;s<steps;s++){ int cy=0; for(size_t i=0;i<n;i++){ int z=a[n-1-i]-'0'+a[i]-'0'+cy; b[n-i]='0'+z%10; cy=z/10; }
   if(cy){ b[0]='1'; memcpy(a,b,n+1); n++; } else { memcpy(a,b+1,n); } a[n]=0; }
 FILE*o=fopen(v[3],"w"); fprintf(o,"%s\n",a); fclose(o); return 0; }
