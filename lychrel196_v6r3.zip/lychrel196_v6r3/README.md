# 196 reverse-and-add v6r3: v6r2 cleanup from the Nsight Compute profile, plus wider tiles

```bash
nvcc -O3 -std=c++17 -arch=sm_89 cuda196_v6r3.cu -o cuda196_v6r3
./cuda196_v6r3 checkpoint_4942464.txt 20000 out.txt 4942464 128 --tile=860            # benchmark (same CLI)
./cuda196_v6r3 run <checkpoint> <iteration> search --chunk=1000000 --keep=3 --K=128 --tile=860   # long search
```

Same arithmetic, certification, replay, command line, checkpoint format and `latest.json` fields as
v6r2 (the engine field reads `cuda196_v6r3`). Results are byte-identical to v6r2.

## What the profile said (v6r2, K=128, tile 736, ~236M digits)

- DRAM 1.8%, L2 0.7%: memory is not the limit.
- Each warp issues one instruction every ~8 cycles; 51% of scheduler cycles have no ready warp.
  Biggest stalls: `wait` (dependent instructions) 1.65, `barrier` 1.54, `math_pipe_throttle` 0.87,
  `short_scoreboard` (shared memory) 0.72 cycles per issued instruction.
- #1 hotspot: the per-step `__syncthreads_or` (warps finished, waiting for the slowest warp).
- Each worker thread does exactly **one** 4-word group per step: at tile 736 a block has 193 groups
  for 224 worker threads, so 31 workers idle every step.
- The GPU sits at its 35 W cap 99.8% of the time (`sw_power_cap`), at ~1.9 GHz. Extra activity per
  cycle lowers the clock: 3 blocks/SM was 8.7% slower.

## What v6r3 changes

1. **Tile geometry and item mapping in registers** (`WorkCtx`), read from shared memory once per
   launch instead of every step. They are constant during a launch.
2. **Growth bit through the barrier.** `__syncthreads_count(tid == 0 && g_next)` hands g_{t+1} to
   every thread in a register, so nothing reads it back from shared memory right after the barrier.
3. **Palindrome vote off the barrier.** Each warp ORs its lanes with `__any_sync` into a register
   bitmask, flushed to shared memory every 32 steps; `quiet[]` is updated once per launch (v6r2
   issued a global atomic from thread 0 every step).
4. **Thread 0 checks new word 0 first** for the growth bit (words 1..3 only if word 0 is all 9s).
5. **ph_load without an integer division per element** (plane by plane).

**Wider tiles (works for v6r2 too).** Step time is roughly the time of one group, since each worker
does one group. Up to 224 groups per block cost about the same step time, and that is tile 860
(4·224 − 36). Tile 860 needs 42 KB shared memory per block; 2 blocks still fit per SM. On paper
that is 860/736 = 1.17× more work per block-step. Under the 35 W cap the busier lanes draw more
power, so the real gain will be smaller, possibly zero. The A/B measures it, with energy per step.

## Checked here (no NVIDIA GPU: CPU emulator running the same kernel code, clang + ptxas for sm_89)

- Exactness suite ALL PASS on the self-check emulator (growth bit vs shared-memory search on every
  step) in step, tb, tiny tile, two forced-failure configurations and tile=64/K=1000.
- Differential v6r2 vs v6r3: 120/120 byte-identical. Growth edge cases 195/195 exact (33 replays
  where the first 128 pairs all sum to 9, as designed).
- Soundness checker: 0 violations; certified/failed block counts identical to v6r2 in 3 configurations.
- +2000 steps on the 2.05M checkpoint at tile 856 and 860 == CPU reference.
- Compiled tb_kernel (clang): 128 registers, 0 spills, local-memory use identical to v6r2.
  The per-step loop has about the same instruction count (1,090 vs 1,102); v6r3 removes waits,
  not work. The first build moved a register array to local memory (a dynamic index in the
  growth check); the shipped code is unrolled and back to v6r2's footprint.

## Expected speed (honest)

My previous six estimates were all too high. The code changes shorten the critical path a little; I
expect **0–3%** from them. Tile 860 is the larger unknown: anything from 0 to ~15%. The A/B decides,
not this estimate. If nothing is at least 3% faster, keep v6r2 at tile 736.

## Files

| file | purpose |
|---|---|
| `cuda196_v6r3.cu` | CUDA backend: v4 per-step kernel (verification/replay), v6r3 time-blocked kernel |
| `emu196_v6r3.cpp` | CPU emulator, same kernel code (`EMU_CERTCHECK=1` soundness; `-DTB_CHECK_GROWTH` self-check) |
| `bits_tb6r3.h` | v6r3 engine (v6r2 + the changes above) |
| `driver6r3.h` | bench mode, run mode, verification windows, replay (v6r2 driver, renamed) |
| `bench_v6r3.sh` | `build`, `resources`, `gate`, `ab`, `sustained`, `prof`, `runmode` |
| `tests/` | exactness suite, differential test, growth edge cases |
| `baseline_v6r2/` | the production engine, for A/B |
| `tools/ref.c` | independent schoolbook reference |
