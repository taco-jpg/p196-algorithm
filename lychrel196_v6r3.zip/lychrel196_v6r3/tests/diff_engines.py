#!/usr/bin/env python3
"""Differential test: engine B must produce byte-identical output to engine A on random numbers with long
runs of pair-sum 9 (incl. across the middle), random K/tile, sizes where both fast and general
paths run.  usage: python3 tests/diff_engines.py A_BINARY B_BINARY [SEED] [CASES]"""
import random, subprocess, sys, filecmp, tempfile, os
v5, v6 = sys.argv[1], sys.argv[2]
random.seed(int(sys.argv[3]) if len(sys.argv) > 3 else 1); cases = int(sys.argv[4]) if len(sys.argv) > 4 else 100
T = tempfile.mkdtemp(); bad = 0
for t in range(cases):
    n = random.choice([600, 1500, 4000, 12000, 30000])
    d = [random.randint(0, 9) for _ in range(n)]
    for _ in range(random.randint(0, 6)):
        a = random.randint(0, n // 2); L = random.randint(1, 400)
        for j in range(a, min(a + L, n // 2)): d[n - 1 - j] = 9 - d[j]
    if d[0] == 0: d[0] = 1
    open(f'{T}/in.txt', 'w').write(''.join(map(str, d)) + '\n')
    steps = random.randint(50, 900); K = random.choice([7, 32, 64, 200, 256]); tile = random.choice([4, 8, 32, 96, 0])
    r = []
    for b, o in ((v5, 'o5'), (v6, 'o6')):
        r.append(subprocess.run([b, f'{T}/in.txt', str(steps), f'{T}/{o}.txt', '0', str(K), '0', f'--tile={tile}'], capture_output=True).returncode)
    same = r[0] == r[1] and (r[0] != 0 or filecmp.cmp(f'{T}/o5.txt', f'{T}/o6.txt', shallow=False))
    if not same: bad += 1; print('DIFF', n, steps, K, tile, r)
print(f'differential {os.path.basename(v5)} vs {os.path.basename(v6)}: {cases - bad}/{cases} identical'); sys.exit(1 if bad else 0)
