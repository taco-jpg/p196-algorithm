# Task for the local agent (RTX 4050): v6r3 and wider tiles

Production runs v6r2 (K=128, tile 736) toward the 999,999,999 milestone. **Do this after the
milestone comparison report is done**, unless the user says otherwise. Results must be
byte-identical to v6r2.

Timing needs the GPU to itself: pause with `search/STOP` (finishes the current chunk), run the task,
resume from `latest.json`, and confirm the service is running again. Only one GPU job at a time.

## What changes (README.md has the reasoning)
- v6r3 = v6r2 with five small changes from the Nsight profile: per-launch constants in registers,
  growth bit through the barrier (`BAR.RED.POPC`), palindrome vote off the barrier, cheaper growth
  check, and no division in the tile load. Same arithmetic, certification and replay.
- **Wider tiles**: up to 224 groups per block (tile 860) should cost about the same step time as
  193 (tile 736). This works for v6r2 too, and would be a parameter-only change (`--tile=`).
- Expected: 0–3% from the code; tile 860 anywhere from 0 to ~15%. The 35 W cap may eat it.
  My estimates have been too high six times. Measure.

## Steps
1. `./bench_v6r3.sh build` then `./bench_v6r3.sh resources`. Report the lines. Expect v6r3 to
   show `BAR.RED.POPC`, and STL/LDL equal to v6r2.
2. `./bench_v6r3.sh gate`. **Everything must PASS**: 7 exactness configurations (incl. tile 860),
   the profiling build, 100-case differential vs v6r2, growth edge cases, +2000 vs CPU reference
   for v6r3 and v6r2 at tiles 736 and 860, self-check emulator.
3. `./bench_v6r3.sh ab <COPY of the newest checkpoint> <its iteration>`. Defaults: K=128, 5,000
   steps, 3 interleaved rounds of v6r2 at tiles 736/800/832/860 and v6r3 at 736/860. Every output
   is compared with v6r2:736's. Reports median and mean µs/step, mean power, clock and energy
   per step (mJ). **This is the deciding table.**
4. If any configuration is at least 3% faster than v6r2:736 by median:
   `./bench_v6r3.sh sustained <COPY> <iteration> <best cfg>` (100,000 steps each).
5. `./bench_v6r3.sh prof <COPY> <iteration> v6r3:860` and `./bench_v6r3.sh runmode`.
6. Resume production unchanged and confirm it is running. Send back `bench/summary.txt`,
   `bench/ab.tsv` and `bench/log.txt`.

## Deciding (the user's call)
- Best is v6r2 at a wider tile: production keeps the same binary; only `--tile=` changes.
- Best is v6r3: switch binary and tile; keep the v6r2 binary for rollback.
- Nothing ≥ 3% faster in the sustained run: keep v6r2 at 736.
- A switch happens only with the user's go-ahead, at a chunk boundary, resuming from `latest.json`.
  Changing the tile does not change any result, only speed.

## Rules
- Benchmarks only on a copy of a checkpoint, never the live file.
- Every step's palindrome status is checked; certification failures replay.
- Measured numbers only.
