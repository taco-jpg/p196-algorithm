// bits_core.h - bit-sliced exact reverse-and-add step.
// Compiled unchanged into the CUDA kernel (cuda196_bits.cu) and the CPU
// emulator (emu196_bits.cpp); the emulator therefore tests the GPU arithmetic.
//
// STATE: pair sums S_j = d_j + d_{n-1-j} (0..18), j < h = ceil(n/2), stored as
// 5 bit-planes of 32-bit words: plane q, word k holds bit q of S_{32k..32k+31}.
// Layout: s[q*Wcap + k].
//
// ONE STEP (proved in README; verified numerically):
//   G_j = (S_j >= 10), P_j = (S_j == 9)
//   low carries  a_j : a_0 = 0,  a_{j+1} = G_j | P_j a_j     -> carries of binary (G|P) + G
//   high carries b_j : b_{h-1} = (n even ? a_h : a_{h-1}),
//                      b_{j-1} = G_j | P_j b_j               -> same add on bit-reversed words
//   growth g = b_{-1}
//   no growth:  S'_j = 2 S_j + a_j + b_j - 10 (a_{j+1} + b_{j-1})
//   growth:     S'_j = lo_j + hi_{j-1},  lo_j = S_j + a_j - 10 a_{j+1},
//               hi_j = S_j + b_j - 10 b_{j-1},  hi_{-1} = 1,  (n even) S'_h = 2 hi_{h-1}
//   palindrome: no growth -> N_{t+1} palindromic  <=>  a_j == b_j for all j
//               growth    -> lo_j == hi_{j-1} for all j < h'
// Carries crossing word boundaries are resolved by scanning neighbouring words
// for the first word that is not "all propagate" (probability ~1e-32 per word),
// so the result is exact with no cutoff.
#pragma once
#include <stdint.h>

#ifdef __CUDACC__
#define BHD __host__ __device__ __forceinline__
#else
#define BHD static inline
#endif

namespace bits {
typedef uint32_t u32;
typedef uint64_t u64;

BHD u32 brev32(u32 x) {
#ifdef __CUDA_ARCH__
  return __brev(x);
#else
  x = ((x >> 1) & 0x55555555u) | ((x & 0x55555555u) << 1);
  x = ((x >> 2) & 0x33333333u) | ((x & 0x33333333u) << 2);
  x = ((x >> 4) & 0x0F0F0F0Fu) | ((x & 0x0F0F0F0Fu) << 4);
  x = ((x >> 8) & 0x00FF00FFu) | ((x & 0x00FF00FFu) << 8);
  return (x >> 16) | (x << 16);
#endif
}
// bits of word k that are pairs < h
BHD u32 hmask(int k, int h) {
  long long lo = 32LL * k;
  if (lo + 32 <= h) return 0xFFFFFFFFu;
  if (lo >= h) return 0u;
  return (1u << (int)(h - lo)) - 1u;
}
BHD void ld(const u32* s, int Wcap, int k, u32 p[5]) {
  if (k < 0 || k >= Wcap) { p[0] = p[1] = p[2] = p[3] = p[4] = 0; return; }
  for (int q = 0; q < 5; ++q) p[q] = s[q * Wcap + k];
}
BHD u32 Gof(const u32 p[5]) { return p[4] | (p[3] & (p[2] | p[1])); }   // S >= 10
BHD u32 Pof(const u32 p[5]) { return ~p[4] & p[3] & ~p[2] & ~p[1] & p[0]; }  // S == 9

// Word summary for a carry chain: 1 = generates, 0 = kills, 2 = propagates its carry-in.
BHD int low_summary(const u32 p[5]) {
  u32 G = Gof(p), X = G | Pof(p);
  u64 t = (u64)X + G;
  if (t >> 32) return 1;
  return ((u32)t == 0xFFFFFFFFu) ? 2 : 0;
}
BHD int high_summary(const u32 p[5], int j, int h) {
  u32 m = hmask(j, h);
  u32 G = Gof(p) & m, X = (Gof(p) | Pof(p)) | ~m;  // pairs >= h pass the middle carry through
  u32 Xr = brev32(X), Gr = brev32(G);
  u64 t = (u64)Xr + Gr;
  if (t >> 32) return 1;
  return ((u32)t == 0xFFFFFFFFu) ? 2 : 0;
}
// Low carry entering word k (a_{32k}); prev = planes of word k-1.
BHD u32 low_cin(const u32* s, int Wcap, int k, const u32 prev[5]) {
  int j = k - 1;
  if (j < 0) return 0;
  int r = low_summary(prev);
  while (r == 2) {
    if (--j < 0) return 0;
    u32 p[5]; ld(s, Wcap, j, p);
    r = low_summary(p);
  }
  return (u32)r;
}
BHD u32 low_bit(const u32* s, int Wcap, int j) {  // a_j
  int k = j >> 5;
  u32 p[5], q[5];
  ld(s, Wcap, k, p); ld(s, Wcap, k - 1, q);
  u32 c = low_cin(s, Wcap, k, q);
  u32 G = Gof(p), X = G | Pof(p);
  u64 t = (u64)X + G + c;
  u32 A = (u32)t ^ X ^ G;
  return (A >> (j & 31)) & 1u;
}
BHD u32 mid_cin(const u32* s, int Wcap, int n) {  // b_{h-1}
  int h = (n + 1) / 2;
  return low_bit(s, Wcap, (n % 2 == 0) ? h : h - 1);
}
// High carry entering word k from above (b_{32k+31}); next = planes of word k+1.
BHD u32 high_cin(const u32* s, int Wcap, int n, int k, const u32 next[5]) {
  int h = (n + 1) / 2, j = k + 1;
  if (32LL * j >= h) return mid_cin(s, Wcap, n);
  int r = high_summary(next, j, h);
  while (r == 2) {
    ++j;
    if (32LL * j >= h) return mid_cin(s, Wcap, n);
    u32 p[5]; ld(s, Wcap, j, p);
    r = high_summary(p, j, h);
  }
  return (u32)r;
}
// digit = S + c - 10*k, known to be 0..9  (4 output planes)
BHD void digit4(const u32 p[5], u32 c, u32 k, u32 o[4]) {
  u32 cc = c;
  u32 w0 = p[0] ^ cc; cc &= p[0];
  u32 w1 = p[1] ^ cc; cc &= p[1];
  u32 w2 = p[2] ^ cc; cc &= p[2];
  u32 w3 = p[3] ^ cc;
  u32 r1 = w1 ^ k, bo = ~w1 & k;      // subtract 10 = 0b1010
  u32 r2 = w2 ^ bo; bo = ~w2 & bo;
  u32 dd = w3 ^ k; u32 r3 = dd ^ bo;
  o[0] = w0; o[1] = r1; o[2] = r2; o[3] = r3;
}

// Growth bit of the step from state s (all threads compute it identically).
BHD int growth_of(const u32* s, int Wcap, int n) {
  u32 w0[5]; ld(s, Wcap, 0, w0);
  return (int)high_cin(s, Wcap, n, -1, w0);
}

// Compute word w of the next state. Returns 1 if a palindrome mismatch is seen
// in this word. *gOut = growth of this step.
BHD u32 step_word(const u32* __restrict__ s, u32* __restrict__ d, int Wcap, int n, int w, int* gOut) {
  const int h = (n + 1) / 2;
  u32 pw[5], cw[5], nw[5];
  ld(s, Wcap, w - 1, pw); ld(s, Wcap, w, cw); ld(s, Wcap, w + 1, nw);
  const int g = growth_of(s, Wcap, n);
  *gOut = g;
  const u32 m = hmask(w, h);
  const u32 G = Gof(cw), P = Pof(cw), X = G | P;
  // low carries for this word: one 32-bit add
  const u32 cl = low_cin(s, Wcap, w, pw);
  const u64 tl = (u64)X + G + cl;
  const u32 A = (u32)tl ^ X ^ G, aOut = (u32)(tl >> 32);  // aOut = a_{32w+32}
  // high carries: same add on the bit-reversed word
  const u32 ch = high_cin(s, Wcap, n, w, nw);
  const u32 Xr = brev32(X | ~m), Gr = brev32(G & m);
  const u64 th = (u64)Xr + Gr + ch;
  const u32 B = brev32((u32)th ^ Xr ^ Gr), bOut = (u32)(th >> 32);  // bOut = b_{32w-1}
  const u32 a = A & m, b = B & m;
  const u32 aup = ((A >> 1) | (aOut << 31)) & m;  // a_{j+1}
  const u32 bdn = ((b << 1) | bOut) & m;          // b_{j-1}  (b_{-1} = g)
  u32 out[5], mism;
  if (!g) {
    // S' = 2S + a + b - 10*(aup + bdn)
    u32 t0 = a ^ b, t1 = a & b;
    u32 v0 = t0;
    u32 v1 = cw[0] ^ t1, cc = cw[0] & t1;
    u32 v2 = cw[1] ^ cc; cc &= cw[1];
    u32 v3 = cw[2] ^ cc; cc &= cw[2];
    u32 v4 = cw[3] ^ cc; cc &= cw[3];
    u32 v5 = cw[4] ^ cc; (void)v5;
    u32 k1 = aup ^ bdn, k2 = aup & bdn;  // subtrahend bits (1,2,3,4) = (k1,k2,k1,k2)
    u32 r1 = v1 ^ k1, bo = ~v1 & k1;
    u32 dd = v2 ^ k2; u32 r2 = dd ^ bo; bo = (~v2 & k2) | (~dd & bo);
    dd = v3 ^ k1;     u32 r3 = dd ^ bo; bo = (~v3 & k1) | (~dd & bo);
    dd = v4 ^ k2;     u32 r4 = dd ^ bo;
    out[0] = v0 & m; out[1] = r1 & m; out[2] = r2 & m; out[3] = r3 & m; out[4] = r4 & m;
    mism = (a ^ b) != 0;
  } else {
    const int h1 = (n + 2) / 2;
    const u32 m1 = hmask(w, h1);
    u32 lo[4], hi[4], hp[4], hs[4];
    digit4(cw, a, aup, lo);
    digit4(cw, b, bdn, hi);
    if (w == 0) { hp[0] = 1; hp[1] = hp[2] = hp[3] = 0; }  // the new leading digit 1
    else {  // high digit of pair 32w-1
      int v = 0;
      for (int q = 0; q < 5; ++q) v |= (int)((pw[q] >> 31) & 1u) << q;
      int bj = (int)bOut, bj1 = (v >= 10) | ((v == 9) & bj);
      int hv = v + bj - 10 * bj1;
      if (hv < 0) hv = 0;  // only possible for pairs >= h (masked garbage)
      for (int q = 0; q < 4; ++q) hp[q] = (u32)(hv >> q) & 1u;
    }
    for (int q = 0; q < 4; ++q) hs[q] = (hi[q] << 1) | hp[q];  // hi_{j-1}
    if (!(n & 1)) {  // even n: new centre pair h = 2*hi_{h-1}
      int hb = h - 32 * w;
      if (hb >= 0 && hb < 32) {
        u32 bm = 1u << hb;
        for (int q = 0; q < 4; ++q) lo[q] = (lo[q] & ~bm) | (hs[q] & bm);
      }
    }
    u32 diff = 0, cc = 0;
    for (int q = 0; q < 4; ++q) {
      diff |= (lo[q] ^ hs[q]) & m1;
      u32 x = lo[q], y = hs[q];
      out[q] = (x ^ y ^ cc) & m1;
      cc = (x & y) | (cc & (x ^ y));
    }
    out[4] = cc & m1;
    mism = diff != 0;
  }
  if (w >= 0 && w < Wcap)
    for (int q = 0; q < 5; ++q) d[q * Wcap + w] = out[q];
  return mism;
}

}  // namespace bits
