// emu196_v6.cpp - CPU emulator of cuda196_v6: runs the same bits_core.h / bits_tb.h code with the
// kernels' block/thread/barrier structure reproduced sequentially (blocks in parallel via OpenMP).
// Build: g++ -O3 -march=native -fopenmp -std=c++17 emu196_v6.cpp -o emu196_v6
// EMU_CERTCHECK=1 : after every time-blocked launch, recompute the same steps with the per-step
//                   kernel and verify every block that claimed certification (soundness test).
#include <atomic>
#include <climits>
#include <cstring>
#include "driver6r2.h"
using bits::u32;

struct EmuBackend {
  std::vector<u32> s[2], bk;
  int n[2] = {0, 0}, nbk = 0, cur = 0, Wcap = 0, bkWords = 0;
  tb::Conf conf{};
  size_t smem = 0;
  std::vector<unsigned> quiet;
  std::atomic<unsigned> fail{0};
  long long pal = -1;
  bool certcheck = false;
  long long ccBlocksOk = 0, ccBlocksFail = 0, ccViolations = 0;

  double devSec = 0;
  double deviceSeconds() const { return devSec; }  // host time of the emulated launches
  const char* name() { return certcheck ? "cpu-emulator(v6r2, certcheck)" : "cpu-emulator(v6r2)"; }
  int numSMs() { return 20; }  // behave like an RTX 4050 Laptop for tile auto-selection
  int tbBlocksPerSM(size_t bytes) {
    int bySmem = (int)((100 * 1024) / (bytes + 1024));
    return std::min(2, bySmem);  // the CUDA build caps tb_kernel at 2 blocks/SM (TB_MINBLOCKS=2)
  }
  void init(const std::vector<u32>& pl, int n0, int W, const tb::Conf& c, int) {
    Wcap = W; conf = c; smem = tb::smem_bytes(c);
    s[0] = pl; s[1].assign(pl.size(), 0); bk.assign(pl.size(), 0);
    n[0] = n[1] = n0; cur = 0;
    quiet.assign(tb::KMAX, 0);
    const char* e = getenv("EMU_CERTCHECK");
    certcheck = e && *e == '1';
    if (smem > 99 * 1024) throw std::runtime_error("tile does not fit in shared memory; lower --tile or --K");
  }
  // one v4 step over all words, src -> dst
  static unsigned v4step(const u32* src, u32* dst, int W, int nn, int* nOut) {
    int g0 = 0;
    unsigned any = 0;
#pragma omp parallel for reduction(| : any) schedule(static)
    for (int w = 0; w < W; ++w) {
      int g = 0;
      if (32LL * w > (nn + 2) / 2 + 32) continue;
      any |= bits::step_word(src, dst, W, nn, w, &g);
      if (w == 0) g0 = g;
    }
    *nOut = nn + g0;
    return any;
  }
  void stepRun(int count, std::vector<unsigned>& bad, int) {
    auto t0 = d5::Clock::now();
    bad.assign(count, 0);
    for (int i = 0; i < count; ++i) {
      bad[i] = v4step(s[cur].data(), s[1 - cur].data(), Wcap, n[cur], &n[1 - cur]);
      cur ^= 1;
    }
    devSec += d5::secs(t0);
  }
  // Emulates one CUDA block of tb_kernel. Returns verdict (1 = certified).
  int tbBlock(int blk, int K, const u32* src, u32* dst, int nIn, int* nOut, std::vector<std::atomic<unsigned>>& q) {
    tb::Conf c = conf; c.K = K;
    std::vector<unsigned char> mem(tb::smem_bytes(c) + 16);
    tb::State& S = *reinterpret_cast<tb::State*>(mem.data());
    u32* base = reinterpret_cast<u32*>(mem.data() + tb::state_bytes());
    tb::ph_setup(S, c, blk, nIn);
    if (S.dead) { for (int t = 0; t < K; ++t) q[t]++; return 1; }
    for (int tid = 0; tid < tb::THREADS; ++tid) tb::ph_load(S, c, base, src, tid, tb::THREADS);
    tb::ph_init(S, c, base);
    int nn = S.n0;
    for (int t = 0; t < K; ++t) {
      for (int tid = 0; tid < tb::THREADS; ++tid) tb::ph_track(S, c, base, t, nn, tid);  // threads 32/33 track
      unsigned any = 0;
      for (int tid = 0; tid < tb::THREADS; ++tid) any |= tb::ph_work(S, c, base, t, nn, tid, tb::THREADS);
      if (!any) q[t]++;
      nn += S.gS[t];
    }
    int ok = tb::ph_verdict(S, nn);
    for (int tid = 0; tid < tb::THREADS; ++tid) tb::ph_store(S, c, base, dst, K, tid, tb::THREADS);
    if (blk == 0) *nOut = nn;
    return ok;
  }
  void tbLaunch(int k, long long baseIter, int blocks) {
    auto t0 = d5::Clock::now();
    const u32* src = s[cur].data();
    u32* dst = s[1 - cur].data();
    std::vector<std::atomic<unsigned>> q(k);
    for (auto& x : q) x = 0;
    std::vector<int> ok(blocks, 1);
    int nOut = n[cur];
#pragma omp parallel for schedule(dynamic, 1)
    for (int b = 0; b < blocks; ++b) ok[b] = tbBlock(b, k, src, dst, n[cur], &nOut, q);
    for (int b = 0; b < blocks; ++b) if (!ok[b]) fail = 1;
    for (int t = 0; t < k; ++t)
      if (q[t] == (unsigned)blocks && pal < 0) pal = baseIter + t + 1;
    if (certcheck) certCheck(k, blocks, ok, nOut);
    n[1 - cur] = nOut;
    cur ^= 1;
    devSec += d5::secs(t0);
  }
  // Soundness: every block that claimed certification must equal the per-step result.
  void certCheck(int k, int blocks, const std::vector<int>& ok, int nTB) {
    std::vector<u32> a = s[cur], b(a.size(), 0);
    int nn = n[cur];
    for (int t = 0; t < k; ++t) { int n2; v4step(a.data(), b.data(), Wcap, nn, &n2); nn = n2; std::swap(a, b); }
    for (int bl = 0; bl < blocks; ++bl) {
      if (!ok[bl]) { ++ccBlocksFail; continue; }
      ++ccBlocksOk;
      int o0 = bl * conf.TW, o1 = std::min(o0 + conf.TW, Wcap);
      for (int x = o0; x < o1; ++x)
        for (int qq = 0; qq < 5; ++qq)
          if (a[(size_t)qq * Wcap + x] != s[1 - cur][(size_t)qq * Wcap + x]) { ++ccViolations; qq = 5; x = o1; }
    }
    bool allOk = true;
    for (int v : ok) allOk &= v != 0;
    if (allOk && nn != nTB) ++ccViolations;
  }
  d5::TBResult tbSync() {
    d5::TBResult r{(int)fail.load(), pal, n[cur]};
    fail = 0; pal = -1;
    return r;
  }
  int currentN() { return n[cur]; }
  void backup(int words) {
    bkWords = std::min(words, Wcap);
    for (int q = 0; q < 5; ++q)
      memcpy(&bk[(size_t)q * Wcap], &s[cur][(size_t)q * Wcap], sizeof(u32) * bkWords);
    nbk = n[cur];
  }
  void restore() {
    for (int q = 0; q < 5; ++q) {
      memcpy(&s[cur][(size_t)q * Wcap], &bk[(size_t)q * Wcap], sizeof(u32) * bkWords);
      memset(&s[cur][(size_t)q * Wcap + bkWords], 0, sizeof(u32) * (Wcap - bkWords));
    }
    std::fill(s[1 - cur].begin(), s[1 - cur].end(), 0u);
    n[cur] = nbk;
  }
  void download(bool previous, std::vector<u32>& pl, int& stride, int& nn) {
    int k = previous ? 1 - cur : cur;
    nn = n[k];
    stride = std::min(Wcap, (nn + 1) / 2 / 32 + 2);
    pl.assign(5 * (size_t)stride, 0);
    for (int q = 0; q < 5; ++q) memcpy(&pl[(size_t)q * stride], &s[k][(size_t)q * Wcap], sizeof(u32) * stride);
  }
  ~EmuBackend() {
#ifdef TB_CHECK_GROWTH
    fprintf(stderr, "[growth-check] register results verified=%lld\n", tb::g_growth_checks.load());
#endif
#ifdef TB_COUNT_PATHS
    fprintf(stderr, "[paths] fast groups=%lld slow groups=%lld\n", tb::g_fast.load(), tb::g_slow.load());
#endif
    if (certcheck)
      fprintf(stderr, "[certcheck] blocks certified=%lld failed=%lld violations=%lld %s\n", ccBlocksOk, ccBlocksFail,
              ccViolations, ccViolations ? "UNSOUND" : "SOUND");
  }
};

int main(int argc, char** argv) {
  int rc;
  {
    EmuBackend be;
    try {
      rc = d5::mainEntry(be, argc, argv);
    } catch (const std::exception& e) {
      fprintf(stderr, "ERROR %s\n", e.what());
      rc = 2;
    }
    if (be.ccViolations) rc = 4;
  }
  return rc;
}
